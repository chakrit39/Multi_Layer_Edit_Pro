# -*- coding: utf-8 -*-
"""ฟังก์ชันช่วยที่ไม่ผูกกับหน้าจอ: ค่า NULL/ข้อความ, คีย์ UTM, ระวาง, วันที่, เวอร์ชัน, log และข้อความเหตุผิดพลาด

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import itertools as _it
import math
import re
import unicodedata
from qgis.PyQt import QtCore
from qgis.core import (Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsExpression, QgsMessageLog,
                       QgsProject)
from ..lock_rules import is_l1_type, norm_type


_VER_RE = re.compile(r"\d+(?:\.\d+)*")


def _parse_version(v):
    """เลขรุ่นจากข้อความ -> tuple อย่างน้อย 3 ส่วน หรือ None ถ้าอ่านไม่ได้

    ★ 2.3.7 (review DI-42) — เดิม '\ufeff2.3.7' (BOM) / 'v2.3.7' / '2.3.7-hotfix' / '' กลายเป็น (0,) หมด
      ⇒ version.txt บน GitHub มี BOM ตัวเดียว ตัวเช็คอัตโนมัติเงียบ และปุ่ม 🚀 บอกพนักงานทุกคนว่า "ใช้รุ่นล่าสุดแล้ว"
      '2.3' = '2.3.0' (เติมให้ครบ 3 ส่วน) · ส่วนต่อท้ายหลังตัวเลข (-hotfix) ไม่นับ"""
    if v is None:
        return None
    if isinstance(v, (bytes, bytearray)):
        v = bytes(v).decode("utf-8-sig", "replace")
    s = str(v).replace("\ufeff", "").strip()
    if s[:1] in ("v", "V"):
        s = s[1:].strip()
    m = _VER_RE.match(s)
    if not m:
        return None
    parts = [int(x) for x in m.group(0).split(".")]
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def _vkey(v):
    """แปลงเลขเวอร์ชัน '1.4.3' -> (1,4,3) เพื่อเทียบเชิงตัวเลข · อ่านไม่ได้ = (0, 0, 0) (★ 2.3.7 ผ่าน _parse_version)"""
    return _parse_version(v) or (0, 0, 0)


def _resp_text(res):
    """ข้อความจากคำตอบ HTTP — ★ 2.3.7 (review DI-42) ถอดรหัส bytes ด้วย utf-8-sig (ตัด BOM) · ตัดช่องว่างหัวท้าย"""
    c = getattr(res, "content", None)
    if isinstance(c, (bytes, bytearray)):
        return bytes(c).decode("utf-8-sig", "replace").strip()
    return str(getattr(res, "text", "") or "").replace("\ufeff", "").strip()


def _meta_value(text, key, strict=False):
    """ค่าใน [general] ของ metadata.txt (ไม่มี = '')

    strict=False (ปริยาย) — ผ่อนปรน: ตัด BOM · ยอม 'version = 2.3.7' · configparser อ่านไม่ได้ก็ไล่ทีละบรรทัด
    strict=True — อ่าน **แบบเดียวกับ QGIS** (qgis.utils.findPlugins: ConfigParser() ปริยาย + ไม่ตัด BOM)
      ⇒ อ่านไม่ได้ = โยน error (ใช้ตรวจซิปอัปเดต: ไฟล์ที่ QGIS อ่านไม่ได้ = ปลั๊กอินหายหลังรีสตาร์ต)"""
    import configparser
    if strict:
        cp = configparser.ConfigParser()
        cp.read_string(text)
        return cp.get("general", key, fallback="").strip()
    t = str(text).lstrip("\ufeff")
    try:
        cp = configparser.ConfigParser(interpolation=None, strict=False)
        cp.read_string(t)
        return cp.get("general", key, fallback="").strip()
    except Exception:
        pass
    for line in t.splitlines():
        k, sep, val = line.partition("=")
        if sep and k.strip().lower() == key.lower():
            return val.strip()
    return ""


_UTM_FIELD_NAMES = {'utm', 'utm_code', 'utm_id'}


# ★★ 2.3.5 — **ค่า NULL จากฐานไม่ใช่ `None` ของ Python**
#   provider คืน `QVariant` ที่ `str()` ออกมาเป็นสตริงว่า **`'NULL'`**
#   ⇒ โค้ดที่เขียน `"" if v is None else str(v)` จะได้คำว่า `'NULL'` แล้วนึกว่า "มีค่าแล้ว"
#   ผู้ตรวจ Windows ยืนยันบนฐานจริง 24 ก.ย. 69: พนักงานเห็น
#   "หมุดนี้มีชื่อ 'NULL' อยู่แล้ว" ⇒ **ตั้งชื่อหมุด 957 ดวงไม่ได้** (ของเก่าตั้งแต่ 2.2.9)
def _txt(v):
    """ค่าข้อความจาก provider -> str · **NULL/None = ว่าง**"""
    if v is None:
        return ""
    s = str(v).strip()
    return "" if s.upper() == "NULL" else s


_TH_NO_LINE_START = "ะาำๅฯๆ"     # ★ 2.3.9 — สระหลัง/ไม้ยมก/ไปยาลน้อย เป็นหมวด Lo/Lm (ไม่ใช่ Mn) แต่ห้ามขึ้นต้นบรรทัดเหมือนกัน


def _wrap_th(s, width=60):
    """★ 2.3.8 — ตัดข้อความยาวเป็นท่อน ≤ width ตัวอักษร โดยไม่ตัดหน้าตัวอักษรที่ซ้อน (สระบน/ล่าง · วรรณยุกต์ = หมวด Mn)
    ชอบตัดที่ช่องว่างถ้ามีในครึ่งหลังของท่อน · บรรทัดใหม่ในข้อความเดิมคงไว้
    ★ 2.3.9 — ไม่ตัดหน้า ะ า ำ ๅ ฯ ๆ ด้วย (2.3.8 ดูแค่หมวด Mn จึงมี "ำ" ขึ้นต้นบรรทัดได้ — ผู้ตรวจ Windows 9 ต.ค.)
             · ไม่เติมท่อนว่างท้าย เมื่อการเลื่อนจุดตัดกินไปจนสุดข้อความ"""
    import unicodedata
    out = []
    for line in str(s).splitlines() or [""]:
        line = line.rstrip()
        ตัดแล้ว = False
        while len(line) > width:
            cut = width
            while cut < len(line) and (unicodedata.category(line[cut]) == "Mn" or line[cut] in _TH_NO_LINE_START):
                cut += 1                       # อย่าให้สระ/วรรณยุกต์หลุดไปขึ้นต้นบรรทัดใหม่
            while cut > 1 and line[cut - 1] in "เแโใไ":
                cut -= 1                       # สระหน้า (เ แ โ ใ ไ) ต้องไปกับพยัญชนะตัวถัดไป
            sp = line.rfind(" ", width // 2, cut)
            if sp > 0:
                cut = sp
            out.append(line[:cut].rstrip())
            line = line[cut:].lstrip()
            ตัดแล้ว = True
        if line or not ตัดแล้ว:                # บรรทัดว่างของต้นฉบับยังคงไว้ · ท่อนว่างที่เกิดจากการตัดไม่เติม
            out.append(line)
    return out


def _probe_xy_24047(geom, crs):
    """★ 2.3.9 — จุดที่อยู่ "ใน" แปลงแน่นอน (pointOnSurface — centroid ของแปลงเว้า/หลายก้อนอาจตกนอกแปลง) ใน EPSG:24047
    ใช้ถาม iLands (UDM) ที่ตำแหน่งแปลงเมื่อ ArcGIS ไม่มีคีย์นี้ · ทำไม่ได้ = None"""
    try:
        c = geom.pointOnSurface().asPoint()
        dst = QgsCoordinateReferenceSystem("EPSG:24047")
        if crs != dst:
            c = QgsCoordinateTransform(crs, dst, QgsProject.instance()).transform(c)
        return (c.x(), c.y())
    except Exception:
        return None


def _dol_here_hint(res):
    """★ 2.3.9 — ข้อความบอก "ที่ตำแหน่งแปลงนี้ระบบกรมมีแปลงอะไร" (จากทางสำรอง iLands เมื่อคีย์ไม่ตรง) · ไม่มี = ''
    ไม่แสดงชื่อเจ้าของ (คำตอบของ dol_api ไม่ส่งมาอยู่แล้ว)"""
    here = (res or {}).get("udm_here") or {}
    if not (here.get("rawang") or here.get("land_no")):
        return ""
    # ★ 2.3.9 rc6 (ผู้ตรวจ Windows rc5) — มีผลชั้นประวัติแล้ว ⇒ ไม่แสดงบรรทัดนี้: เดิมขึ้นคู่กับ "เลขที่ดินนี้ถูกยกเลิกแล้ว … ตอนนี้ที่ตำแหน่งเดิม
    #   เป็นแปลง …" (แปลงเดียวกัน) สองบรรทัดแนะนำคนละทาง · แปลงที่ตำแหน่งนี้ต่างจากที่ตำแหน่งเดิม ⇒ _dol_more_hint ต่อท้ายในบรรทัดประวัติแทน
    if (res or {}).get("history"):
        return ""
    # ★ 2.3.10 ล็อกสาขา — แปลงที่ตำแหน่งนี้เป็นของสำนักงานอื่น ⇒ บอกด้วย (ไม่ใช่แปลงของสาขานี้)
    _bo, _ho = str((res or {}).get("branch_office") or ""), str(here.get("office_seq") or "")
    _ต่าง = " · เป็นแปลงของสำนักงานที่ดินอื่น (รหัส %s)" % _ho if (_bo and _ho and _ho != _bo) else ""
    if here.get("same_key") and _ho:
        # ★ 2.3.11 — จุดนี้เป็นแปลงเลขเดียวกันแต่ของสำนักงานอื่น (dol_api ติด same_key) ⇒ คีย์ของเราไม่ได้ผิด
        #   (2.3.10 ลงท้าย "ถ้าเป็นแปลงเดียวกัน คีย์ของแปลงนี้อาจผิด" ⇒ พนักงานอาจไปแก้คีย์ที่ถูกอยู่แล้ว · ผู้ตรวจคู่มือ 2.3.10)
        return ("\n\nที่ตำแหน่งแปลงนี้ ระบบกรม (iLands) มีแปลงเลขเดียวกันนี้ (ระวาง %s ที่ดิน %s%s) แต่เป็นแปลงของสำนักงานที่ดินอื่น"
                " (รหัส %s) — คีย์ของแปลงนี้ไม่ได้ผิด"
                % (here.get("rawang") or "-", here.get("land_no") or "-",
                   (" (%s)" % here["parcel_type"]) if here.get("parcel_type") else "", _ho))
    return ("\n\nที่ตำแหน่งแปลงนี้ ระบบกรม (iLands) มีแปลง ระวาง %s ที่ดิน %s%s%s — ถ้าเป็นแปลงเดียวกัน คีย์ของแปลงนี้อาจผิด"
            % (here.get("rawang") or "-", here.get("land_no") or "-",
               (" (%s)" % here["parcel_type"]) if here.get("parcel_type") else "", _ต่าง))


def _dol_more_hint(res, skip_other=False):
    """★ 2.3.9 rc5 — ข้อความเพิ่มเมื่อหาไม่เจอ: เลขถูกยกเลิก (ชั้นประวัติ) · รอจด (ชั้นชั่วคราว) · ผลของทะเบียน iLands
    ไม่มีชื่อเจ้าของ (dol_api ไม่ส่งมาอยู่แล้ว)
    skip_other: ★ 2.3.11 — ผู้เรียกบอกเรื่องสำนักงานอื่นในหัวข้อความเองแล้ว ⇒ ไม่ซ้ำบรรทัด ℹ️ สำนักงานอื่น"""
    res = res or {}
    out = []
    oo = res.get("other_office") or {}
    if oo.get("office_seq") and not skip_other:    # ★ 2.3.10 ล็อกสาขา
        out.append("\n\nℹ️ ระวาง/เลขที่ดินนี้มีบนแผนที่กรมของสำนักงานที่ดินอื่น (รหัส %s) — ปลั๊กอินค้นเฉพาะแปลงของสาขาตามชั้นข้อมูลนี้"
                   % oo["office_seq"])
    if res.get("history"):
        now = (res.get("history") or {}).get("now") or {}
        # ★ 2.4.1 — แผนที่ปัจจุบัน (ArcGIS ชั้น 6) ยังมีเลขนี้ (arc_miss) ⇒ เลขเดียวกันในชั้นประวัติอาจเป็นแค่ประวัติแก้รูป
        #   ห้ามบอกว่า "ถูกยกเลิกแล้ว" โดยไม่มีหลักฐาน (เคส 5137 3 8052 ที่ดิน 201 · 14 ต.ค. 69)
        # ★ 2.4.2 (ผลตรวจ Windows 2.4.1 rc1 ข้อสังเกต 4 · ปทุม 174439) — เลขนี้อยู่ในชั้นแปลงรอจดทะเบียนด้วย (temp)
        #   = มีงานรังวัดเลขนี้ที่ยังไม่จด ⇒ เลขเดียวกันในชั้นประวัติอาจเป็นรูปเก่าของแปลงเดียวกัน · เดิมขึ้น "ถูกยกเลิกแล้ว" คู่กับ
        #   "พบในชั้นแปลงรอจดทะเบียน" (สองบรรทัดบอกคนละทาง) ⇒ ใช้ถ้อยคำ "สรุปไม่ได้" แบบ arc_miss
        _unsure = res.get("arc_miss") or res.get("temp")
        s = (("\n\nℹ️ เลขที่ดินนี้มีในประวัติแผนที่กรมด้วย (%s — สรุปไม่ได้ว่าถูกยกเลิก)"
              % ("แผนที่ปัจจุบันยังมีเลขนี้" if res.get("arc_miss") else "มีในชั้นแปลงรอจดทะเบียนด้วย"))
             if _unsure else "\n\nℹ️ เลขที่ดินนี้ถูกยกเลิกแล้ว (มีในประวัติแผนที่กรม)")
        if now.get("rawang") or now.get("land_no"):
            # ★ 2.4.1 rc2 (ผลตรวจ Windows rc1 ข้อสังเกต 3) — arc_miss: แปลงยังอยู่บนแผนที่ปัจจุบัน ⇒ "ตำแหน่งเดิม" อ่านได้ว่าแปลงย้าย/ถูกแทนแล้ว
            #   ขัดกับ "สรุปไม่ได้ว่าถูกยกเลิก" ในบรรทัดเดียวกัน ⇒ บอกว่าเป็นตำแหน่งตามประวัติ · เลขถูกยกเลิกจริงใช้ถ้อยคำเดิม
            s += (" — ตำแหน่งตามประวัติ ตอนนี้เป็นแปลง ระวาง %s ที่ดิน %s%s" if _unsure
                  else " — ตอนนี้ที่ตำแหน่งเดิมเป็นแปลง ระวาง %s ที่ดิน %s%s") % (
                now.get("rawang") or "-", now.get("land_no") or "-",
                (" (%s)" % now["parcel_type"]) if now.get("parcel_type") else "")
        # ★ rc6 — บรรทัด "ที่ตำแหน่งแปลงนี้" ไม่แสดงเมื่อมีประวัติ (_dol_here_hint) ⇒ ถ้าเป็นคนละแปลงกับที่ตำแหน่งเดิม ต่อท้ายที่นี่ (ไม่ให้ข้อมูลหาย)
        s += _dol_here_vs_now(res, now)
        out.append(s)
    if res.get("temp"):
        out.append("\n\nℹ️ พบในชั้นแปลงรอจดทะเบียนของกรม — ยังไม่มีข้อมูลทะเบียน")
    out.append(_dol_lis_hint(res))
    return "".join(out)


def _dol_here_vs_now(res, now):
    """' · ที่ตำแหน่งแปลงนี้เป็นแปลง ระวาง … ที่ดิน …' จาก res['udm_here'] (แปลงใต้รูปของเรา) เมื่อเป็นคนละแปลงกับ now
    (เลขปัจจุบันที่ตำแหน่งเดิมตามประวัติ) · ไม่มี/แปลงเดียวกัน = '' · ★ 2.4.4 แยกจาก _dol_more_hint ให้ข้อความ [1] ของ ➕/📝 ใช้ด้วย"""
    res, now = res or {}, now or {}
    here = res.get("udm_here") or {}
    if not (here.get("rawang") or here.get("land_no")) or \
            (str(here.get("rawang") or "").strip(), str(here.get("land_no") or "").strip()) == \
            (str(now.get("rawang") or "").strip(), str(now.get("land_no") or "").strip()):
        return ""
    s = " · ที่ตำแหน่งแปลงนี้เป็นแปลง ระวาง %s ที่ดิน %s%s" % (
        here.get("rawang") or "-", here.get("land_no") or "-",
        (" (%s)" % here["parcel_type"]) if here.get("parcel_type") else "")
    # ★ 2.3.11 — ค้นแบบล็อกสาขาแล้วแปลงตรงนั้นเป็นของสำนักงานอื่น ⇒ บอกด้วย (เลขเดียวกันกับเรา ไม่ได้แปลว่าเป็นแปลงของสาขานี้)
    _bo, _ho = str(res.get("branch_office") or "").strip(), str(here.get("office_seq") or "").strip()
    if _bo and _ho and _ho != _bo:
        s += " ของสำนักงานที่ดินอื่น (รหัส %s)" % _ho
    return s + _dol_in_layer_note(here)              # ★ 2.4.6


def _dol_lis_hint(res):
    """★ 2.4.2 E8 — บรรทัดผลของทะเบียน iLands (LIS) ต่อท้ายกล่อง: ไม่มีเลขนี้ · ค้นไม่สำเร็จ · ไม่ได้เข้าสู่ระบบ (ไม่ได้ค้น)
    (เดิมอยู่ใน _dol_more_hint ของกรณีไม่พบเท่านั้น — ตอนนี้ใช้กับกล่องไม่มีทะเบียน/รอจด/ยืนยันแปลงไม่ได้ด้วย)"""
    v = (res or {}).get("lis")
    if v == "none":
        return "\n\nทะเบียนของ iLands ก็ไม่มีเลขนี้"
    if v == "error":
        return "\n\nค้นในทะเบียน iLands ไม่สำเร็จ: %s" % ((res or {}).get("lis_error") or "-")
    if v == "skipped":
        return "\n\nยังไม่ได้ค้นในทะเบียน iLands (ไม่ได้เข้าสู่ระบบ)"
    if v == "busy":                 # ★ 2.4.3 (review ⚪6)
        return "\n\nยังไม่ได้ค้นในทะเบียน iLands (มีงานค้นทะเบียนอื่นหรือกล่องเข้าสู่ระบบค้างอยู่ — ปิดงานนั้นแล้วลองใหม่)"
    return ""


def _dol_in_layer_note(p):
    """★ 2.4.6 (เคสองครักษ์ #730 26 ต.ค. 69 — ข้อความให้แก้คีย์เป็น #718 ที่มีแปลงในฐานอยู่แล้ว) — แปลงของแผนที่กรมที่ตำแหน่งนี้
    มีคีย์ในชั้นของเราแล้ว (ผู้เรียกเติม p['in_layer'] = [gid] · _ep_mark_in_layer) ⇒ ' (มีแปลงเลขนี้ในชั้นของเราแล้ว …)' · ไม่มี = ''"""
    g = (p or {}).get("in_layer") or []
    if not g:
        return ""
    return " (มีแปลงเลขนี้ในชั้นของเราแล้ว: gid %s — แก้คีย์ไปเลขนี้จะซ้ำ)" % ", ".join(str(x) for x in g[:3])


def _dol_history_now(res):
    """★ 2.4.3 rc4 (ผลตรวจ Windows rc3 🟡3) — ' · ตอนนี้ที่ตำแหน่งเดิมเป็นแปลง ระวาง … ที่ดิน …' จาก res['history']['now'] · ไม่มี = ''"""
    now = (((res or {}).get("history") or {}).get("now")) or {}
    if not (now.get("rawang") or now.get("land_no")):
        return ""
    return " · ตอนนี้ที่ตำแหน่งเดิมเป็นแปลง ระวาง %s ที่ดิน %s%s" % (
        now.get("rawang") or "-", now.get("land_no") or "-",
        (" (%s)" % now["parcel_type"]) if now.get("parcel_type") else "") + _dol_in_layer_note(now)


def _dol_history_where(res):
    """★ 2.4.4 (ผลตรวจ Windows 2.4.3 rc5 ⚪1) — ท้ายข้อความ [1] ของ ➕/📝 (คีย์ชั้นประวัติ): เลขปัจจุบันที่ตำแหน่งเดิม + เลขใต้รูปของเรา
    เมื่อเป็นคนละแปลง (โฉนดแม่ถูกแบ่งแยก ⇒ เลขใต้รูปคือเลขที่ควรแก้คีย์ไป) + เลขนี้มีบนแผนที่ของสำนักงานอื่น
    (rc5 บอกแค่ตำแหน่งเดิม — ทางไม่เข้าสู่ระบบของ rc4 เคยบอกสองอย่างนี้ผ่าน _dol_more_hint)"""
    res = res or {}
    hv = _dol_here_vs_now(res, (res.get("history") or {}).get("now"))
    here = res.get("udm_here") or {}
    _bo, _ho = str(res.get("branch_office") or "").strip(), str(here.get("office_seq") or "").strip()
    if hv and here.get("same_key") and _bo and _ho and _ho != _bo:
        # ★ 2.4.5 (ผลตรวจ Windows 2.4.4 rc1 ⚪4) — แปลงใต้รูปเป็นเลขเดียวกันกับคีย์ของเราแต่เป็นของสำนักงานอื่น ⇒ ไม่ใช่เลขที่ต้องแก้คีย์ไป
        #   (เดิมต่อท้าย "แก้คีย์เป็นเลขปัจจุบันก่อน" ด้วยเลขเดียวกัน ⇒ อ่านเหมือนให้แก้ไปเลขนั้น) · เฉพาะ ➕/📝 — 🔍 ใช้ _dol_here_vs_now ตามเดิม
        hv = " · ที่ตำแหน่งแปลงนี้เป็นแปลงเลขเดียวกันนี้ของสำนักงานที่ดินอื่น (รหัส %s) — ไม่ใช่เลขที่ต้องแก้คีย์ไป" % _ho
    s = _dol_history_now(res) + hv
    _oo = str((res.get("other_office") or {}).get("office_seq") or "").strip()
    if _oo and ("(รหัส %s)" % _oo) not in s:          # ★ 2.4.5 (⚪4) ส่วนแปลงใต้รูปบอกสำนักงานนี้แล้ว ⇒ ไม่ซ้ำ
        s += " · ระวาง/เลขที่ดินนี้มีบนแผนที่กรมของสำนักงานที่ดินอื่น (รหัส %s)" % _oo
    return s


def _dol_history_lis_note(res):
    """★ 2.4.3 rc3/rc4 — ผลทะเบียน iLands ของคีย์ที่อยู่ชั้นประวัติอย่างเดียว (lis_reason 'history') — ที่มา + คำเตือน + เลขปัจจุบัน"""
    return ("พบในทะเบียน iLands — แต่เลขที่ดินนี้ถูกยกเลิก/เปลี่ยนเลขบนแผนที่กรมแล้ว (มีในประวัติแผนที่) · "
            "เนื้อที่ในทะเบียนอาจเป็นของเดิมก่อนแบ่งแยก ตรวจกับรูปแปลงก่อนใช้" + _dol_history_now(res))


_EP_HIST_WHY = ("เลขที่ดินนี้ถูกยกเลิก/เปลี่ยนเลขบนแผนที่กรมแล้ว (มีในประวัติแผนที่) — ทะเบียน iLands ที่พบอาจเป็นโฉนดแม่ก่อนแบ่งแยก "
                "ใช้เป็นเนื้อที่ทะเบียนของ ➕/📝 ไม่ได้ · แก้คีย์เป็นเลขปัจจุบันก่อน")
# ★ 2.4.3 rc5 (ผลตรวจ Windows rc4 🟡1) — คีย์ชั้นประวัติที่ไม่ได้ผลจากทะเบียน iLands (ไม่ได้เข้าสู่ระบบ · ทะเบียนไม่มี · ค้นไม่สำเร็จ)
_EP_HIST_MAP_WHY = ("เลขที่ดินนี้ถูกยกเลิก/เปลี่ยนเลขบนแผนที่กรมแล้ว (มีในประวัติแผนที่) — ใช้เป็นโฉนดที่ดิน/เนื้อที่ทะเบียนของ ➕/📝 ไม่ได้ "
                    "· แก้คีย์เป็นเลขปัจจุบันก่อน")


def _ep_hist_key(res):
    """★ 2.4.3 rc5 (ผลตรวจ Windows rc4 🟡1) — คีย์อยู่ชั้นประวัติของแผนที่กรมอย่างเดียว (lis_reason 'history') ไม่ว่าผลจะมาทางไหน
    (rc4 ตรวจเฉพาะ via='lis' ⇒ ยกเลิกกล่องเข้าสู่ระบบแล้วด่านโฉนดบอกแค่ "ไม่พบ · ยกเลิกการเข้าสู่ระบบ" ไม่บอกให้แก้คีย์)"""
    return isinstance(res, dict) and res.get("lis_reason") == "history"


# ★ 2.4.6 (เจ้าของงาน 26 ต.ค. 69 "ทำข้อ 1 2" — เคสองครักษ์ 5137 II 1266-00 1:4000 #730 โฉนด 83894: บัญชีทะเบียนยังมี เนื้อที่ 1,600 ตร.ม.
#   ต่างจากรูป 1.5% แต่แผนที่กรมย้ายรูปไปชั้นประวัติ ที่ตำแหน่งเป็น #718 ซึ่งมีงานแก้แผนที่ค้างชั้นรอจด) — คีย์ชั้นประวัติที่ทะเบียน iLands
#   ยืนยันว่าโฉนดยังใช้อยู่ ⇒ ➕/📝 ใช้ได้พร้อมคำเตือน (ถามยืนยันอีกครั้ง ปุ่มตั้งต้น No) · ยืนยัน = ทะเบียนพบรายการเดียวตรงทุกท่อน + ได้เนื้อที่
#   จากหน้ารายละเอียด (คีย์ในหน้าตรง) + เนื้อที่ต่างจากรูปไม่เกิน ±_EP_HIST_OK_PCT % · โฉนดแม่ก่อนแบ่งแยกเนื้อที่ต่างจากรูปมาก
#   (คลองหลวง gid 224704 #58: ทะเบียน 20-0-01 ไร่ กับรูป 7.5 ไร่) ⇒ บล็อกตามเดิม
_EP_HIST_OK_PCT = 10.0


def _dol_area_diff(shape_m2, reg_m2):
    """★ 2.4.6 DIFF_AREA (ร้อยละ) = (เนื้อที่รูป − เนื้อที่ทะเบียน) / เนื้อที่ทะเบียน × 100 ปัด 2 ตำแหน่ง — สูตรเดียวกับ trigger ของฐาน
    และค่าที่ ➕/📝 เขียน · ค่าไม่ครบ/ทะเบียน ≤ 0 = None"""
    try:
        s, r = float(shape_m2), float(reg_m2)
    except (TypeError, ValueError):
        return None
    if not (r > 0) or s != s or math.isinf(s):
        return None
    return round((s - r) / r * 100.0, 2)


def _ep_hist_deed(res, shape_m2):
    """★ 2.4.6 คีย์ชั้นประวัติ — ทะเบียน iLands ยืนยันว่าโฉนดยังใช้อยู่ไหม -> (ใช้ได้, DIFF ร้อยละ หรือ None, เหตุ ' · …' หรือ '')
    ใช้ได้ = ผลจากทะเบียน (via='lis') ของชั้นที่ล็อกสาขา รายการเดียว ไม่คร่อมสาขา + ได้เนื้อที่จากหน้ารายละเอียด + ต่างจากรูปไม่เกิน
    ±_EP_HIST_OK_PCT %"""
    res = res or {}
    if res.get("via") != "lis":
        return False, None, ""
    if not _txt(res.get("branch_office")):
        # ★ (ตรวจอิสระ ⚪8) ชั้นไม่ล็อกสาขา ⇒ ทะเบียนตอบสำนักงานแรกที่เจอ (โฉนดเลขเดียวกันของสำนักงานอื่นได้) ⇒ ไม่ยืนยัน
        return False, None, " · ชั้นนี้ไม่ได้ล็อกสาขา — ยืนยันไม่ได้ว่าเป็นโฉนดของสำนักงานที่ดินนี้"
    if res.get("cross_office") or (res.get("match_count") or 1) > 1:
        return False, None, " · ทะเบียนมีเลขนี้หลายรายการ — ยืนยันไม่ได้ว่าเป็นโฉนดของรูปนี้"
    m2 = _dol_area_m2(res.get("area"))
    if m2 is None or m2 <= 0:
        _w = _txt(res.get("area_why"))
        return False, None, " · ไม่ได้เนื้อที่ทะเบียน" + (f" ({_w})" if _w else "") + " — ยืนยันไม่ได้ว่าโฉนดยังใช้อยู่"
    d = _dol_area_diff(shape_m2, m2)
    if d is None:
        return False, None, " · ไม่รู้เนื้อที่รูป — เทียบกับทะเบียนไม่ได้"
    if abs(d) > _EP_HIST_OK_PCT:
        return False, d, (f" · เนื้อที่ทะเบียน {m2:,.2f} ตร.ม. · DIFF_AREA {d:+.2f}% (เกิน ±{_EP_HIST_OK_PCT:g}%) "
                          "— น่าจะเป็นโฉนดแม่ก่อนแบ่งแยก")
    return True, d, ""


def _ep_hist_ok_note(res, shape_m2):
    """★ 2.4.6 คำเตือนของคีย์ชั้นประวัติที่ทะเบียน iLands ยืนยัน (_ep_hist_deed ผ่าน) — หมายเหตุ ➕/📝 + กล่องยืนยัน"""
    res = res or {}
    m2 = _dol_area_m2(res.get("area")) or 0.0
    d = _dol_area_diff(shape_m2, m2)
    return ("เลขที่ดินนี้อยู่ในชั้นประวัติของแผนที่กรม (แผนที่ยกเลิก/เปลี่ยนเลขแล้ว) แต่ทะเบียน iLands ยังมีโฉนดนี้ "
            f"(โฉนด {_txt(res.get('parcel_no')) or '-'} · หน้าสำรวจ {_txt(res.get('survey_no')) or '-'} · "
            f"เนื้อที่ {_rngw(m2)} ไร่-งาน-วา = {m2:,.2f} ตร.ม. · DIFF_AREA "
            + (f"{d:+.2f}%" if d is not None else "-") + ") — ใช้ได้เมื่อโฉนดนี้ยังใช้อยู่จริง (เช่น แผนที่กรมกำลังแก้) "
            "· ตรวจภาพลักษณ์โฉนดก่อน · ถ้าเป็นโฉนดแม่ที่แบ่งแยกแล้ว ให้แก้คีย์เป็นเลขปัจจุบัน" + _dol_history_where(res))


def _ep_hist_block_note(res, detail=""):
    """★ 2.4.6 ข้อความบล็อกของคีย์ชั้นประวัติ (ไม่ผ่าน _ep_hist_deed) — เหตุ + ทางไปต่อ + เลขปัจจุบัน/แปลงใต้รูป
    (เดิม _EP_HIST_WHY/_EP_HIST_MAP_WHY + _dol_history_where · ยังไม่ได้ผลทะเบียน ⇒ บอกว่าเข้าสู่ระบบแล้วค้นใหม่ได้)"""
    res = res or {}
    if res.get("via") == "lis":
        s = _EP_HIST_WHY + detail
    else:
        s = _EP_HIST_MAP_WHY
        if res.get("lis") in ("login", "skipped", "hist"):
            s += (" · ถ้าโฉนดนี้ยังใช้อยู่ (เช่น แผนที่กรมกำลังแก้) ให้เข้าสู่ระบบ DOL แล้วค้นใหม่ — ทะเบียน iLands ยืนยันได้ "
                  f"(DIFF_AREA ไม่เกิน ±{_EP_HIST_OK_PCT:g}%) จะใช้ได้พร้อมคำเตือน")
        else:
            s += _dol_lis_hint(res).replace("\n\n", " · ")
    return s + _dol_history_where(res)


def _dol_via_note(res):
    """★ 2.3.9 rc5 — ที่มาของผลที่ไม่ได้มาจากแผนที่ปัจจุบันของกรม (ต่อท้ายแถบข้อความ/หมายเหตุ)
    ★ 2.3.10 — ยืนยันด้วยระวาง+เลขที่ดิน (เลขแปลงในแผนที่ของกรมสองระบบไม่ตรงกัน) ก็บอกด้วย"""
    if not (res or {}).get("via") and (res or {}).get("verify_by") == "key":
        return "ยืนยันด้วยระวาง+เลขที่ดิน (เลขแปลงในแผนที่ของระบบกรมไม่ตรงกัน)"
    if (res or {}).get("via") == "udm_point" and (res or {}).get("arc_miss"):
        # ★ 2.4.1 — แผนที่ ArcGIS มีคีย์นี้ แต่ถามทะเบียนที่จุดกลางของมันไม่ได้ ⇒ พบจากตำแหน่งแปลงของเราแทน
        return ("พบจาก iLands ที่ตำแหน่งแปลง (แผนที่ ArcGIS ของกรมมีคีย์นี้ แต่"
                + ("ไม่มีข้อมูลทะเบียนที่จุดกลางของแปลง)" if res.get("arc_miss") == "udm_empty" else "ไม่มีพิกัดจุดกลางของแปลง)"))
    if (res or {}).get("via") == "lis":
        # ★ 2.4.3 rc3 — แผนที่ปัจจุบันมีเลขนี้ (arc_miss) แต่ถามทะเบียนที่จุดกลางไม่ได้ ⇒ ไม่ใช่ "ไม่มีรูปบนแผนที่กรม"
        if res.get("arc_miss") and res.get("lis_reason") in (None, "", "not_found"):
            return ("พบในทะเบียน iLands — แผนที่กรมมีเลขนี้ แต่" + ("ระบบทะเบียนไม่มีข้อมูลที่จุดกลางของแปลง"
                    if res.get("arc_miss") == "udm_empty" else "ไม่มีพิกัดจุดกลางของแปลง"))
        # ★ 2.4.2 E8 — ทะเบียน iLands ใช้กับกรณีอื่นนอกจาก "แผนที่ไม่มีคีย์" แล้ว ⇒ บอกว่าแผนที่ตอบอะไรไว้
        if res.get("lis_reason") == "history":
            return _dol_history_lis_note(res)
        return {"temp": "พบในทะเบียน iLands — แผนที่กรมยังแสดงเป็นแปลงรอจดทะเบียน",
                "not_registered": "พบในทะเบียน iLands — แผนที่กรมแจ้งว่าแปลงนี้ไม่มีทะเบียน",
                "unverified": "ยืนยันด้วยทะเบียน iLands (ระวาง+เลขที่ดินตรงทุกท่อน) — แผนที่กรมตอบแปลงที่ยืนยันไม่ได้",
                "air": "ค้นในทะเบียน iLands ด้วยคีย์ระวางรูปถ่าย (หน้า น.ส.3 ก)",                  # ★ 2.4.8 ขั้น D
                "docsearch": "ค้นในทะเบียน iLands ด้วยเลขที่เอกสาร",                                 # ★ 2.4.8 ขั้น E
                "utmdoc": "ค้นในทะเบียน iLands ด้วยคีย์ UTM (หน้าตราจอง)",                          # ★ 2.4.8 ขั้น E1
                }.get(res.get("lis_reason"), "พบในทะเบียน iLands — แปลงนี้ไม่มีรูปบนแผนที่กรม")
    return {"udm_point": "พบจาก iLands ที่ตำแหน่งแปลง (แผนที่ ArcGIS ของกรมไม่มีคีย์นี้)",
            "arcgis_temp": "พบจากชั้นแปลงรอจดทะเบียนของกรม",
            "arcgis_history": "พบจากชั้นประวัติของแผนที่กรม (ตำแหน่งเดิมยังเป็นเลขนี้)"}.get((res or {}).get("via"), "")


def _branch_office_of(layer):
    """★ 2.3.10 (เจ้าของงานสั่ง 12 ต.ค. 69 "ล็อคตามสาขา") — สาขาของชั้นแปลงที่ใช้ค้น → รหัสสำนักงานที่ดิน (dol_api.branch_office)
    ดูจากชื่อตาราง (<สาขา>_POLYGON) → ชื่อฐาน (Move_<สาขา>) → ชื่อชั้น · ไม่รู้ = None ⇒ ค้นแบบเดิม (ไม่ล็อก)"""
    if layer is None:
        return None
    try:
        from .. import dol_api
        names = []
        try:
            from qgis.core import QgsDataSourceUri
            u = QgsDataSourceUri(layer.dataProvider().dataSourceUri())
            names += [u.table(), u.database()]
        except Exception:
            pass
        names.append(layer.name())
        for n in names:
            o = dol_api.branch_office(n)
            if o:
                return o
    except Exception:
        pass
    return None


def _is_chor(v):
    """ชื่อตระกูล `ชร` (ชำรุด): ชร · ช.ร. · ชร- · 'ชร .' … (★ 2.3.6)
    ไม่นับชื่อที่มีตัวเลขอย่าง ชร83980 — memory marker-names: อาจเป็นชื่อจริง"""
    return re.sub(r"[\s.\-]", "", _txt(v)) == "ชร"


# ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค. 69) — หมุดซ้อน (คีย์แปลงเดียวกัน มุมเดียวกัน) ชื่อต่างกัน ⇒ เก็บชื่อของหมุดที่ "วันที่ใหม่สุด"
#   วันที่ของหมุด = ค่าที่ใหม่กว่าระหว่าง SURV_DATE กับ ISSUE_DATE (timestamp บนชั้นหมุด · มักว่าง — ปทุมฯ 91% ไม่มีทั้งคู่)
#   ชั้นที่ไม่มีคอลัมน์เหล่านี้ (ชั้นทดสอบ/หน่วยความจำ) = ไม่มีวันที่ · ตัดสินไม่ได้ ⇒ ให้ผู้ใช้เลือก (popup)
_DATE_COLS = ("SURV_DATE", "ISSUE_DATE")


def _date_val(v):
    """ค่าวันที่/เวลาจาก provider ⇒ datetime (เทียบกันได้) · NULL/ว่าง/อ่านไม่ออก ⇒ None
    รับ QDateTime · QDate · datetime/date · ข้อความแบบ ISO ('2024-05-01' · '2024-05-01 10:30:00' · '2024-05-01T10:30')"""
    import datetime as _dt
    try:
        if v is None:
            return None
        if isinstance(v, _dt.datetime):
            return v.replace(tzinfo=None)
        if isinstance(v, _dt.date):
            return _dt.datetime(v.year, v.month, v.day)
        if isinstance(v, QtCore.QDateTime):
            return v.toPyDateTime().replace(tzinfo=None) if v.isValid() else None
        if isinstance(v, QtCore.QDate):
            return _dt.datetime(v.year(), v.month(), v.day()) if v.isValid() else None
    except Exception:
        return None
    s = _txt(v)
    if not s:
        return None
    try:
        return _dt.datetime.fromisoformat(s.replace("Z", "")).replace(tzinfo=None)
    except ValueError:
        pass
    for fmt in ("%Y/%m/%d %H:%M:%S", "%Y/%m/%d", "%d/%m/%Y"):
        try:
            return _dt.datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def _date_txt(d):
    """datetime ⇒ ข้อความสั้นในรายการ popup ('2024-05-01' · มีเวลาไม่ใช่เที่ยงคืนต่อท้าย HH:MM) · None ⇒ '-'"""
    if d is None:
        return "-"
    try:
        return d.strftime("%Y-%m-%d %H:%M") if (d.hour or d.minute) else d.strftime("%Y-%m-%d")
    except Exception:
        return "-"


_TH_MONTHS = ("ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.")


def _date_th(d):
    """★ 2.4.7 datetime ⇒ วันที่แบบไทยปี พ.ศ. ('2 เม.ย. 2551') ไว้แสดงใน ℹ️ · None/อ่านไม่ได้ ⇒ '-'
    (ISSUE_DATE/SURV_DATE ในฐานเก็บปี ค.ศ. — ตรวจ 5 สาขา 26 ต.ค. 69: ไม่มีค่าปี ≥ 2400)"""
    if d is None:
        return "-"
    try:
        # ★ 2.4.8 (ผลตรวจ Windows 2.4.7 rc1 ⚪8) ปีที่เป็น พ.ศ. อยู่แล้ว (≥ 2400) ไม่บวกซ้ำ
        return f"{d.day} {_TH_MONTHS[d.month - 1]} {d.year if d.year >= 2400 else d.year + 543}"
    except Exception:
        return "-"


def _name_key(n):
    """ชื่อหมุดเพื่อเทียบ "ชื่อเดียวกัน" — ชร ทุกแบบ (ช.ร. · ชร- …) นับเป็นชื่อเดียวกัน · ว่าง = ''"""
    n = _txt(n)
    return "ชร" if n and _is_chor(n) else n


def _newest_name(cands):
    """cands = [dict(nm, d)] (d = วันที่ของหมุด หรือ None) ⇒ ชื่อของหมุดที่วันที่ใหม่สุด
    ตัดสินไม่ได้ ⇒ None: ไม่มีวันที่เลยสักดวง · หรือวันที่ใหม่สุดเท่ากันแต่ชื่อต่างกัน (ชื่อว่างไม่นับ)"""
    มี = [c for c in cands if _txt(c.get("nm")) and c.get("d") is not None]
    if not มี:
        return None
    ใหม่สุด = max(c["d"] for c in มี)
    ชนะ = {_name_key(c["nm"]) for c in มี if c["d"] == ใหม่สุด}
    if len(ชนะ) != 1:
        return None
    return next(_txt(c["nm"]) for c in มี if c["d"] == ใหม่สุด)


_PW_RE = re.compile(r"(password\s*=\s*)('(?:[^'\\]|\\.)*'|\S+)", re.I)


def _scrub(text):
    """★ 2.3.7 (review SE-03) — ปิดรหัสผ่านใน connection string ของ PostgreSQL ก่อนเขียน Log/แสดงผล"""
    try:
        return _PW_RE.sub(r"\1***", str(text))
    except Exception:
        return "(ปิดข้อความไว้)"


# ★ 2.4.0 (review DI-13) — commitErrors ที่บอกว่า "สิทธิ์ไม่พอ" (SQLSTATE 42501 insufficient_privilege ของ PostgreSQL)
#   ใช้แยกข้อความหลังบันทึกไม่สำเร็จ: สิทธิ์ไม่พอ = กดบันทึกซ้ำไม่มีวันผ่าน · อย่างอื่น (เน็ตหลุด/ฐานไม่ตอบ) = ลองใหม่ได้
#   ★ 2.4.0 (review DI-13) — รหัส 42501 นับเฉพาะในตำแหน่งรหัส SQLSTATE ("ERROR:  42501: …" / "SQLSTATE[42501]")
#     เดิม \b42501\b จับเลขโดด ๆ ⇒ DETAIL "Key (fid)=(42501) already exists." (คีย์ซ้ำ) ถูกนับเป็นสิทธิ์ไม่พอ
_PERM_DENIED_RE = re.compile(r"permission denied|insufficient[_ ]privilege|SQLSTATE\W{0,3}42501\b|ERROR:\s+42501\b"
                             r"|must be owner of", re.I)
_PERM_OBJ_RE = re.compile(r"permission denied for (?:table|relation|sequence|schema|view|column) \"?([^\s\"]+)\"?", re.I)


_LOG_ONCE = set()          # ★ 2.3.7 (review ER-03) — กุญแจของ _log_exc(once_key=…) ที่เขียนไปแล้วใน session นี้


def _log_exc(ctx, level=None, once_key=None):
    """★ 2.3.7 (review ER-03) — เขียน traceback ของ exception ที่ "กำลังจัดการอยู่" ลง Log Messages แท็บ MLEP
    ใช้ในบล็อก except เท่านั้น · เดิมด่านที่ "ปล่อยผ่านเมื่อตรวจไม่ได้" กลืน exception เงียบ ⇒ ไม่มีใครรู้ว่าด่านไม่ได้ตรวจ
    · ปิดรหัสผ่านด้วย _scrub (ข้อความของการต่อฐานอาจมี connection string) · ไม่เก็บตัว exception ไว้
    · once_key = เขียนครั้งเดียวต่อ session (ด่านที่ถูกเรียกถี่) · ตัวมันเองห้ามโยน exception (ถูกเรียกจากใน except)"""
    try:
        if once_key is not None:
            if once_key in _LOG_ONCE:
                return
            _LOG_ONCE.add(once_key)
        import traceback
        QgsMessageLog.logMessage(_scrub(f"{ctx}\n{traceback.format_exc()}"), "MLEP",
                                 Qgis.Warning if level is None else level)
    except Exception:
        pass


def _log_msg_once(key, msg, level=None):
    """★ 2.4.0 (review ER-09) — เขียนข้อความ (ไม่ใช่ traceback) ลง Log แท็บ MLEP ครั้งเดียวต่อ session ต่อ key
    ใช้กับเงื่อนไขผิดปกติที่ไม่ได้มาจาก exception และเกิดซ้ำได้ทุกครั้งที่บันทึก · ห้ามโยน exception"""
    try:
        if key in _LOG_ONCE:
            return
        _LOG_ONCE.add(key)
        QgsMessageLog.logMessage(_scrub(msg), "MLEP", Qgis.Warning if level is None else level)
    except Exception:
        pass


def _log_err(ctx, e, level=None):
    """★ 2.3.7 (review ER-03/ER-06) — แบบ _log_exc แต่รับ "ตัว exception" ที่ส่งต่อมา (ผลล้มของ worker thread ที่มาถึง slot
    บน main thread — ตอนนั้นไม่ได้อยู่ใน except แล้ว) · เขียน traceback ของมันเอง (__traceback__) · ห้ามโยน exception"""
    try:
        import traceback
        if isinstance(e, BaseException):
            tb = "".join(traceback.format_exception(type(e), e, e.__traceback__))
        else:
            tb = str(e)
        QgsMessageLog.logMessage(_scrub(f"{ctx}\n{tb}"), "MLEP", Qgis.Warning if level is None else level)
    except Exception:
        pass


_TH_RE = re.compile(r"[\u0E00-\u0E7F]")


def _reason_text(e):
    """★ 2.3.7 (review ER-06) — เหตุที่แสดงให้พนักงานได้: ข้อความภาษาไทยที่ปลั๊กอินเขียนเอง (DOLError / RuntimeError ของเรา)
    ใช้ตามเดิม · ข้อความดิบภาษาอังกฤษของ Python/QGIS/requests ⇒ 'เกิดข้อผิดพลาดที่ไม่คาดคิด' (ตัวจริงอยู่ใน Log)"""
    try:
        s = str(e).strip()
    except Exception:
        s = ""
    return s if s and _TH_RE.search(s) else "เกิดข้อผิดพลาดที่ไม่คาดคิด"


def _net_err_text(e):
    """★ 2.3.7 (review ER-06) — exception ของงานเครือข่าย ⇒ เหตุภาษาไทยสั้น ๆ (หมดเวลา · ใบรับรอง · ต่อไม่ได้ · HTTP)
    เดิมกล่องแสดงข้อความดิบของ requests (HTTPSConnectionPool(host=…): Max retries exceeded …) · อื่น ๆ = _reason_text"""
    try:
        from .. import dol_api
        r = dol_api.net_reason(e)
        if r:
            return r
    except Exception:
        pass
    if isinstance(e, TimeoutError):
        return "ระบบปลายทางตอบช้าเกินเวลา (หมดเวลารอ) — ลองใหม่ภายหลัง"
    if isinstance(e, ConnectionError):
        return "เชื่อมต่อเครือข่ายไม่ได้ — ตรวจอินเทอร์เน็ต/เครือข่ายของสำนักงาน"
    return _reason_text(e)


class _LockScanError(Exception):
    """★ 2.3.7 (review PF-01) — สแกนแปลง L1 ไม่สำเร็จ (ผู้เรียกต้องหยุด ไม่ถือว่า 'ไม่มีแปลงล็อก')"""


def _rngw(m2):
    """ตร.ม. -> 'ไร่-งาน-วา' แบบที่ระบบกรมแสดง (วา ทศนิยม 1 ตำแหน่ง) · None/ค่าลบ -> ''  (★ 2.3.7)
    1 ไร่ = 4 งาน = 400 ตร.ว. · 1 ตร.ว. = 4 ตร.ม."""
    try:
        m2 = float(m2)
    except (TypeError, ValueError):
        return ""
    if m2 < 0:
        return ""
    wa_all = round(m2 / 4.0, 1)                 # ปัดก่อนแตกหน่วย กัน 99.96 วา -> '0-0-100.0'
    rai = int(wa_all // 400)
    ngan = int((wa_all - rai * 400) // 100)
    wa = wa_all - rai * 400 - ngan * 100
    return "%d-%d-%.1f" % (rai, ngan, wa)


def _dol_area_m2(s):
    """เนื้อที่จากระบบกรม '0-1-0.0  ไร่' (ไร่-งาน-วา) -> ตร.ม. · รูปแบบอื่น/ค่าผิดหน่วย -> None (ไม่เดา)  (★ 2.3.7)"""
    m = re.search(r"(\d+)\s*-\s*(\d+)\s*-\s*(\d+(?:\.\d+)?)", _txt(s))
    if not m:
        return None
    rai, ngan, wa = int(m.group(1)), int(m.group(2)), float(m.group(3))
    if ngan > 3 or wa >= 100:
        return None
    return (rai * 400 + ngan * 100 + wa) * 4.0


def _area_num(v):
    """★ 2.4.2 E9 — ค่า AREA ของแปลง (ตัวเลข/ข้อความ) -> ตร.ม. · NULL/ว่าง/อ่านไม่ได้ -> None"""
    s = _txt(v).replace(",", "")
    try:
        x = float(s)
    except ValueError:
        return None
    return x if x == x else None


_EP_SCALES = ("500", "1000", "2000", "4000")
# ★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 17:16 "นส3ก ใช้ utmmap1 2 4 มาตรส่วนระวาง เลขที่ดิน" · 18:1x มาตราส่วน 5000 ตั้งต้น + เลือก 1250/2500/50000 ได้)
#   มาตราส่วนระวางรูปถ่ายทางอากาศของ น.ส.3 ก — ตัวเลือกเดียวกับช่อง ddlAirPhotoScale ของหน้าค้น QNS3K (ตัวแรก = ค่าตั้งต้น)
_AIR_SCALES = ("5000", "1250", "2500", "50000")
_ROMAN_OF = {"1": "I", "2": "II", "3": "III", "4": "IV"}
_EP_MAP4_MAX = {"4000": 0, "2000": 4, "1000": 16, "500": 64}     # memory utmmap-structure: แบ่งระวางตามมาตราส่วน
_ROMAN = {"I": "1", "II": "2", "III": "3", "IV": "4"}


def _ep_normalize(m1, m2, m3, m4, sc, ln, public_neg=False, airphoto=False):
    """ตรวจ + จัดรูปช่องคีย์แปลงตามมาตรฐาน (memory utmmap-structure) -> (dict ค่า, [ข้อผิด])  (★ 2.3.7)
    UTMMAP1 4 หลัก · UTMMAP2 1 หลัก 1-4 (รับเลขโรมัน I-IV) · UTMMAP3 ≤4 หลัก เติมศูนย์หน้า · UTMMAP4 ≤2 หลัก เติมศูนย์หน้า
    (1:4000 = 00 · 1:2000 = 01-04 · 1:1000 = 01-16 · 1:500 = 01-64) · UTMSCALE 500/1000/2000/4000 · LANDNO เลขจำนวนเต็ม
    public_neg = รับเลขที่ดินติดลบ (ที่สาธารณะที่มีอยู่แล้ว · ★ 2.4.3 rc2 เฉพาะ 📝 — ➕ คิดเลขติดลบให้เองจาก 0 เท่านั้น)
    🔑 ห้ามแปลงช่อง UTMMAP เป็น int แล้วกลับ (ศูนย์นำหน้าหาย) — เติมศูนย์ด้วย zfill เท่านั้น
    ★ 2.4.8 airphoto=True = คีย์ระวางรูปถ่ายทางอากาศของ น.ส.3 ก (แบบชั้น NS3K ของกรม · คีย์ทะเบียนที่ค้น QNS3K ได้):
      UTMMAP3 ต้องว่าง · UTMMAP4 = แผ่นที่ ≤ 3 หลัก เติมศูนย์เป็น 3 หลัก · มาตราส่วนใน _AIR_SCALES · เลขที่ดิน > 0"""
    v = {k: "".join(_txt(x).split()) for k, x in
         (("UTMMAP1", m1), ("UTMMAP2", m2), ("UTMMAP3", m3), ("UTMMAP4", m4), ("UTMSCALE", sc), ("LANDNO", ln))}
    err = []
    # ★ 2.3.7 b19 (doc-verify E2) — ตัวเลขอารบิก 0-9 เท่านั้น: \d ของ Python รับเลขไทย ๐-๙ (และเลขยูนิโคดอื่น)
    #   ⇒ เดิมช่องไม่ขึ้นแดง แล้วเลขไทยถูกเขียนลงคีย์แปลง/หมุด (UTMMAP1 '๕๑๓๗' ไม่ตรงกับแปลง/หมุดใดในฐาน)
    if not re.fullmatch(r"[0-9]{4}", v["UTMMAP1"]):
        err.append("UTMMAP1 ต้องเป็นตัวเลข 4 หลัก")
    v["UTMMAP2"] = _ROMAN.get(v["UTMMAP2"].upper(), v["UTMMAP2"])
    if not re.fullmatch(r"[1-4]", v["UTMMAP2"]):
        err.append("UTMMAP2 ต้องเป็น 1-4 (หรือ I-IV)")
    if airphoto:
        if v["UTMMAP3"]:
            err.append("น.ส.3 ก ใช้ระวางรูปถ่ายทางอากาศ — ไม่มี UTMMAP3 (เว้นว่าง)")
        if re.fullmatch(r"[0-9]{1,3}", v["UTMMAP4"]):
            v["UTMMAP4"] = v["UTMMAP4"].zfill(3)
            if v["UTMMAP4"] == "000":           # ★ 2.4.8 rc3 (ผลตรวจ Windows 2.4.8 rc2 ⚪1) แผ่นที่เริ่ม 001 (ฐานจริงไม่มีแปลง น.ส.3 ก)
                err.append("แผ่นที่ของระวางรูปถ่าย (UTMMAP4) ต้องเป็น 001 ขึ้นไป")
        else:
            err.append("แผ่นที่ของระวางรูปถ่าย (UTMMAP4) ต้องเป็นตัวเลขไม่เกิน 3 หลัก เช่น 001")
        if v["UTMSCALE"] not in _AIR_SCALES:
            err.append("มาตราส่วนระวางรูปถ่ายต้องเป็น " + " · ".join(_AIR_SCALES))
        if re.fullmatch(r"[0-9]{1,7}", v["LANDNO"]) and int(v["LANDNO"]) > 0:
            v["LANDNO"] = str(int(v["LANDNO"]))
        else:
            err.append("น.ส.3 ก ต้องใส่เลขที่ดินของระวางรูปถ่ายตามเอกสาร (มากกว่า 0)")
    else:
        if re.fullmatch(r"[0-9]{1,4}", v["UTMMAP3"]):
            v["UTMMAP3"] = v["UTMMAP3"].zfill(4)
        else:
            err.append("UTMMAP3 ต้องเป็นตัวเลขไม่เกิน 4 หลัก")
        if v["UTMSCALE"] not in _EP_SCALES:
            err.append("มาตราส่วนต้องเป็น 500 · 1000 · 2000 · 4000")
        if re.fullmatch(r"[0-9]{1,2}", v["UTMMAP4"] or "0"):
            v["UTMMAP4"] = (v["UTMMAP4"] or "0").zfill(2)
            mx = _EP_MAP4_MAX.get(v["UTMSCALE"])
            if mx is not None:
                n4 = int(v["UTMMAP4"])
                if mx == 0 and n4 != 0:
                    err.append("มาตราส่วน 1:4000 ต้องมี UTMMAP4 = 00")
                elif mx and not 1 <= n4 <= mx:
                    err.append(f"มาตราส่วน 1:{v['UTMSCALE']} ต้องมี UTMMAP4 01-{mx:02d}")
        else:
            err.append("UTMMAP4 ต้องเป็นตัวเลขไม่เกิน 2 หลัก")
        if re.fullmatch(r"[0-9]{1,7}", v["LANDNO"]) or (public_neg and re.fullmatch(r"-[0-9]{1,6}", v["LANDNO"])):
            v["LANDNO"] = str(int(v["LANDNO"]))          # เลขที่ดินในฐานไม่มีศูนย์นำหน้า (0 ยังเป็น '0' · '-03' → '-3' · '-0' → '0')
        else:
            err.append("เลขที่ดินต้องเป็นตัวเลข")
    if any("๐" <= ch <= "๙" for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "LANDNO") for ch in v[k]):
        err.append("ใช้เลขอารบิก 0-9 (ไม่ใช่เลขไทย ๐-๙)")     # ★ b19 E2 — บอกเหตุที่ช่องแดงทั้งที่ "พิมพ์ตัวเลขแล้ว"
    v["UTM"] = "".join(v[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO"))
    return v, err


def _public_landno(ln):
    """★ 2.4.3 rc2 — เลขที่ดิน ≤ 0 = ที่สาธารณะ (เลขที่จัดรูปแล้ว: '0' · '-1' · '-2' …)"""
    return bool(re.fullmatch(r"0|-[0-9]+", _txt(ln)))


# ค่าที่ไม่มีวันเท่ากับของใคร **รวมทั้งตัวมันเอง** (ใช้กับ UTM ว่าง/NULL)
# 🔴 ห้ามใช้ `id(v)` — `None` / `''` / สตริงลิเทอรัลเป็น singleton ทำให้ id เท่ากันทุกครั้ง
#    (เทส sim56 จับได้ตอนแรกที่เขียนผิดแบบนั้น) ⇒ ใช้ตัวนับที่เพิ่มขึ้นทุกครั้งที่เรียก
_UTM_ตัวนับ = _it.count()


def _norm_utm(v):
    """normalize ค่า UTM เป็น string สำหรับเทียบข้ามเลเยอร์
    (กันเคส provider คนละชนิดคืน 123 กับ 123.0 แล้วเทียบไม่ตรงกัน)

    ★★ 2.3.5 — **UTM ว่าง/NULL ต้องไม่เท่ากับ UTM ว่าง/NULL ของใคร**
      เดิม `_norm_utm(None)` คืนสตริง `'None'` ⇒ NULL == NULL ⇒ หมุดที่ไม่มี UTM
      ถูกจับคู่เข้ากับแปลงที่ไม่มี UTM ได้ (ผู้ตรวจ Windows ยืนยัน 24 ก.ย. 69)
      คืนค่าที่ **ไม่มีวันตรงกับใคร** แทน + ต่อเลขลำดับ (ตัวนับ) กันชนกันเอง
    ⚠️ ค่าตัวแทนนี้ขึ้นต้นด้วย \x00 — ห้ามเอาไปใส่ในนิพจน์ (IN (...) จะพัง) · ผู้เรียกที่สร้างนิพจน์ต้องกรองด้วย _txt ก่อน"""
    s = _txt(v)
    if not s:
        return "\x00ไม่มีค่า%d" % next(_UTM_ตัวนับ)
    if s.endswith(".0"):
        s = s[:-2]
    return s


def _log_sql_val(v, utm=False):
    """★ 2.4.0 (review DI-08-leftover) — ค่าหนึ่งช่องของ INSERT ลง Move_Log เป็นลิเทอรัล SQL
    NULL/None/ว่าง/คำว่า 'NULL' (_txt) และค่าแทน "\\x00ไม่มีค่า…" ของ _norm_utm ⇒ SQL NULL (เดิมได้ '' / 'None' / ไบต์ NUL ที่ libpq ตัดคำสั่ง)
    utm=True ⇒ คีย์ผ่าน _norm_utm (ตัด .0 ท้าย) ให้ตรงกับที่โค้ดส่วนอื่นเทียบ · ตัด '\\x00' ที่หลงมาทิ้งเป็นตาข่ายสุดท้าย"""
    s = _txt(v)
    if utm and s and not s.startswith("\x00"):
        s = _norm_utm(s)
    if s.startswith("\x00"):
        s = ""
    s = s.replace("\x00", "")
    return QgsExpression.quotedValue(s) if s else "NULL"


class _กริดจุด:
    """★ 2.3.6 audit รอบ 4 — ตารางแฮชช่องละ `cell` ม. สำหรับหา "จุดที่ห่างไม่เกิน r" (r ≤ cell) แบบไม่ต้องไล่ทุกคู่
    (แบบเดียวกับ `_bare_nodes`) · เดิม `_donut_orphans`/`_donut_marker_plan` เทียบทุกหมุด × ทุกมุม
    ⇒ แปลง 2,000 มุม = 4 ล้านคู่ ค้าง ~3 วินาทีทุกครั้งที่หัก (ผู้ตรวจรอบ 4 วัดได้)
    🔑 ผลต้องเท่ากับไล่ทุกคู่เป๊ะ: ใกล้สุดเสมอกัน ⇒ ตัวที่มาก่อนในลิสต์ชนะ (เหมือน min() เดิม)"""

    def __init__(self, pts, cell):
        self.pts = list(pts)
        self.cell = float(cell)
        self.g = {}
        for i, p in enumerate(self.pts):
            self.g.setdefault((math.floor(p.x() / self.cell), math.floor(p.y() / self.cell)), []).append(i)

    def _รอบ(self, q):
        cx, cy = math.floor(q.x() / self.cell), math.floor(q.y() / self.cell)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for i in self.g.get((cx + dx, cy + dy), ()):
                    yield i

    def ใกล้สุด(self, q, r):
        """(ลำดับในลิสต์, จุด) ของจุดที่ใกล้ q ที่สุดในระยะ r · ไม่มี = None"""
        best = None
        for i in self._รอบ(q):
            d = self.pts[i].distance(q)
            if d <= r and (best is None or (d, i) < best[0]):
                best = ((d, i), i)
        return None if best is None else (best[1], self.pts[best[1]])

    def มี(self, q, r):
        return any(self.pts[i].distance(q) <= r for i in self._รอบ(q))

    def นับ(self, q, r):
        """★ 2.4.0 (review DU-02) จำนวนจุดที่ห่าง q ไม่เกิน r (= len(ทั้งหมด(q, r)) · ไม่เรียง ไม่ผ่าน generator)
        ด่านก่อนบันทึกเรียกทุกมุม/ทุกหมุดของทุกแปลงที่แก้ ⇒ ดูเฉพาะช่องที่กรอบ q ± r แตะ (ช่องละ 2r = ไม่เกิน 2×2 ช่อง)
        แทน 3×3 ช่องเสมอ · ใช้ได้กับ r ทุกขนาด (ไม่ต้อง r ≤ cell) · เพรดิเคตระยะเดียวกับ มี/ทั้งหมด"""
        c, g, pts = self.cell, self.g, self.pts
        x, y = q.x(), q.y()
        ys = range(math.floor((y - r) / c), math.floor((y + r) / c) + 1)
        n = 0
        for gx in range(math.floor((x - r) / c), math.floor((x + r) / c) + 1):
            for gy in ys:
                b = g.get((gx, gy))
                if b:
                    for i in b:
                        if pts[i].distance(q) <= r:
                            n += 1
        return n

    def ทั้งหมด(self, q, r):
        """ลำดับในลิสต์ของทุกจุดที่ห่าง q ไม่เกิน r (เรียงตามลำดับเดิม)"""
        return sorted(i for i in self._รอบ(q) if self.pts[i].distance(q) <= r)

    def เพิ่ม(self, p):
        self.pts.append(p)
        self.g.setdefault((math.floor(p.x() / self.cell), math.floor(p.y() / self.cell)), []).append(len(self.pts) - 1)


# ★★ 2 ก.ย. 69 — เคยมีคลาส _AppCloseFilter ตรงนี้ ดักตอน QGIS กำลังปิดแล้ว "รื้อของทิ้ง"
#   ก่อนกล่องถามบันทึกจะขึ้น  **ถอดออกแล้ว** ด้วยเหตุผลที่วัดมาได้จริง:
#
#   ① มันพังเมื่อพนักงานกด "ยกเลิก" — QgisApp::closeEvent ทำ ev->ignore() **เสมอ**
#      แล้วกระโดดเข้า fileExit() (อ่านจากไบนารี: andb $0xfb,0x12(%rsi) ; jmp fileExit)
#      ⇒ ไม่มีทางแยกได้เลยว่า "ปิดจริง" หรือ "ยกเลิก" จากตัวหน้าต่าง
#      ⇒ กด X แล้วกดยกเลิก = MLEP รื้อตัวเองทิ้งไปแล้ว ทั้งที่ QGIS ยังเปิดอยู่
#         (เส้นที่วัดไว้หายจากจอ · แผงหลักปิด · cache ถูกล้าง)
#   ② มันครอบไม่ครบอยู่ดี — เมนู File > Exit ไม่ผ่าน QCloseEvent เลย
#      (fileExit ถูก connect ตรง ๆ) ⇒ ทางนั้นตัวกรองไม่เคยทำงาน
#   ③ และตอนนี้ "ไม่มีอะไรต้องรีบทำก่อนกล่องถามบันทึก" อีกแล้ว เพราะแก้ที่ต้นทางครบ 3 ทาง:
#        · ชั้นเส้นไม่ถูกเขียนลงไฟล์  -> _on_project_write ถอดออกก่อน QGIS เขียน
#        · ไม่ทำให้โปรเจกต์ "มีการแก้ไข" -> คืนค่า isDirty ทุกครั้งที่เพิ่ม/ลบชั้นและฟีเจอร์
#        · ไม่เด้งกล่องเตือน scratch layer -> customProperty skipMemoryLayersCheck
#      ส่วนการเก็บของตอนปิดจริง unload() ทำอยู่แล้ว (เรียก _line_cleanup)
#   🔴 อย่าเอากลับมาโดยไม่อ่านข้อ ① ก่อน — ทางแก้ที่ถูกถ้าจำเป็นจริงคือ
#      iface.registerApplicationExitBlocker() ซึ่งถูกเรียก "หลัง" กล่องถามบันทึกผ่านไปแล้ว



def _fld_idx(fields, name):
    """ตำแหน่งคอลัมน์จากชื่อ — ตรงตัวก่อน แล้วค่อยไม่สนตัวพิมพ์ · ไม่มีคอลัมน์คืน -1

    ★ 8 ก.ย. 69 — ทำไมไม่ใช้ `QgsFields.lookupField()` ทั้งที่มันไม่สนตัวพิมพ์อยู่แล้ว
      เพราะ `lookupField` **จับ "ชื่อแทน (alias)" ด้วย** (ลำดับ: ชื่อจริงตรงตัว -> ไม่สนตัวพิมพ์ -> alias)
      ทดสอบแล้ว: ตั้ง alias ชื่อ `EDIT_SRC` ให้คอลัมน์ `AAA` -> `lookupField("EDIT_SRC")` คืน 0 (คือ AAA)
      ⇒ ถ้าพนักงานเผลอตั้ง alias ชนกับชื่อคอลัมน์จริง เราจะ **เขียนลงคอลัมน์ผิด**
      (ตรวจแล้วว่าไฟล์โปรเจกต์ทั้ง 5 อำเภอยังไม่มี alias เลย — แต่ตั้งเองได้ทุกเมื่อจากหน้า Properties)
      ตัวนี้จึงเทียบกับ **ชื่อคอลัมน์จริงเท่านั้น** ได้ความไม่สนตัวพิมพ์โดยไม่รับความเสี่ยงจาก alias
    """
    i = fields.indexOf(name)
    if i >= 0:
        return i
    low = str(name).lower()
    for k in range(fields.count()):
        if fields.at(k).name().lower() == low:
            return k
    return -1


def _sheet_str(feat, name):
    """อ่านช่องระวาง (UTMMAP1-4 / UTMSCALE / LANDNO / UTM) จากฟีเจอร์ เป็นสตริงที่ trim แล้ว

    ★ 2.3.0 — รวมมาจาก closure `gv()` ที่เคยเขียนซ้ำ **สามที่**
      (`_on_polygon_picked` · กล่องยืนยันลบแปลง · `map_tools._choose_parcel`)
      🔴 ข้อนี้ทำให้พลาดมาแล้วสองครั้งในรอบ 2.2.8-2.2.9 — แก้ตัวหนึ่ง ลืมตัวอื่น
      (ผู้ตรวจฝั่ง Windows ชี้ให้รวม)

    🔧 ต้องใช้ `_fld_idx` ไม่ใช่ `indexOf` — ชื่อคงที่ (UTMMAP1..) บนชั้นตัวพิมพ์เล็ก
       จะได้ค่าว่างทุกช่องแบบเงียบ ๆ
    """
    try:
        i = _fld_idx(feat.fields(), name)
        if i < 0:
            return ""
        # ★ 2.3.7 (review UX-45 / DI-01) — NULL จาก provider เป็น QVariant ⇒ str() ได้ 'NULL'
        #   เดิมค้นหา DOL ส่ง UTMMAP4='NULL' / มาตราส่วน 'NULL' และข้ามด่าน "ข้อมูลแปลงไม่ครบ"
        return _txt(feat[i])
    except Exception:
        return ""


# ★ 2.3.7 (review UX-06) — ชนิดแปลงที่ "ล็อก" (ชั้นอ้างอิง) ของเครื่องมือ attribute ที่เดียว
# ★ 2.4.0 (review DU-01) — ย้ายไปอยู่ lock_rules.py (ที่เดียวของกติกาล็อก L1 · map_tools ใช้ร่วม) · ชื่อเดิมยัง import จาก main ได้


def _is_l1(v):
    """★ 2.3.7 (review UX-06 / DI-01) — ค่า Type เป็นแปลง L1 ไหม · NULL/ว่าง/สตริง 'NULL' = ไม่ใช่
    ★ 2.4.0 (review DU-01) — ส่งต่อให้ lock_rules.is_l1_type (กติกาเดียวกัน)"""
    return is_l1_type(v)


# ★ rc2 2.4.0 (audit A2-03 · A3-03 · กติกาเจ้าของงาน 13 ต.ค. 69) — CT-RTK อยู่ในชั้น CT_<สาขา> เท่านั้น ห้ามอยู่ในชั้นหมุด
#   ไม่ใช่กติกาล็อก (lock_rules ไม่เกี่ยว) — เป็นกติกาว่า "Type ไหนเขียนลงหมุดได้"
_TYPE_NOT_ON_MARKER = ("CT-RTK",)


# ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪5) ข้อความชนิดแปลงจากระบบกรม (UDM/LIS) -> รหัส DOC_TYPE ของเรา (None = ไม่รู้)
#   เช่น "หนังสือสำคัญสำหรับที่หลวง (น.ส.ล.)" → น.ส.ล. · "ทางสาธารณประโยชน์(ทางบก)" → ทางสาธารณประโยชน์ (ทางบก)
#   "อื่นๆ (ไม่ปรากฎเลขที่ดินในระวางแผนที่)" ไม่ได้บอกชนิด ⇒ None (ด่านโฉนดใช้ด่านเดิม)
_DOL_DOC_RULES = (
    (r"โฉนดตราจอง", "โฉนดตราจอง"),
    (r"ตราจอง", "ตราจองที่ทำประโยชน์แล้ว"),
    (r"โฉนด", "โฉนดที่ดิน"),
    (r"น\.?ส\.?3\.?ก", "น.ส.3 ก"),
    (r"น\.?ส\.?3", "น.ส.3"),
    (r"น\.?ส\.?ล|ที่หลวง", "น.ส.ล."),
    (r"ใบจอง", "ใบจอง"),
    (r"ส\.?ค\.?1", "ส.ค.1"),
    (r"ท\.?ค\.|ครอบครอง", "ที่มีการครอบครอง (ท.ค.)"),
    (r"ทางสาธารณ.*น้ำ", "ทางสาธารณประโยชน์ (ทางน้ำ)"),
    (r"ทางสาธารณ", "ทางสาธารณประโยชน์ (ทางบก)"),
    (r"สาธารณ", "ที่สาธารณประโยชน์"),
)


# ★ 2.4.8 คอลัมน์ทะเบียน 7 ตัวของ <สาขา>_POLYGON (ลงฐานครบ 5 สาขา 26 ต.ค. 69 · แผน เอกสาร/แผน_2.4.7_คอลัมน์ทะเบียน_ตำแหน่ง_20261026.md)
#   REG_SEQ = ลำดับที่เอกสารสิทธิในทะเบียน (parcelSeq/parcelLandSeq) · PARCEL_NO = เลขที่เอกสาร (เลขโฉนด/เลข น.ส.3 …) · SURVEY_NO = หน้าสำรวจ
_REG_COLS = ("REG_SEQ", "PARCEL_NO", "SURVEY_NO", "MOO", "TAMBOL", "AMPHUR", "PROVINCE")
_REG_IDS = ("REG_SEQ", "PARCEL_NO", "SURVEY_NO", "MOO")        # เลขอ้างอิงของเอกสารฉบับนั้น (ตำบล/อำเภอ/จังหวัด = ตำแหน่ง)


def _reg_loc(city):
    """'จ.นครนายก อ.องครักษ์ ต.ชุมพล' -> {'จ': 'นครนายก', 'อ': 'องครักษ์', 'ต': 'ชุมพล'} · ค่าของช่อง = ข้อความหลังคำนำหน้าจนถึงคำนำหน้าถัดไป
    (ขึ้นต้นข้อความหรือหลังช่องว่าง) · ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 🔴) ชื่อที่มีช่องว่าง เช่น 'ต.คลอง 12 ฝั่งตะวันตก' (ธัญบุรี) ·
    'ต.คลอง 11' (ลำลูกกา) ได้ครบ — เดิมแยกทีละคำ ⇒ บันทึก TAMBOL เหลือ 'คลอง' · ช่องว่าง ('จ. อ.องครักษ์' ของทาง LIS ที่ไม่มีจังหวัด)
    ไม่ไปจับชื่อช่องถัดไป · คำนำหน้าซ้ำ ('จ.จ.นครนายก') ตัดออก · ช่องว่างซ้อนในชื่อยุบเหลือช่องเดียว"""
    out = {}
    for m in re.finditer(r"(?:^|(?<=\s))([จอต])\.(.*?)(?=\s+[จอต]\.|\s*$)", _txt(city)):
        val = re.sub(r"\s+", " ", re.sub("^" + m.group(1) + r"\.", "", m.group(2).strip())).strip()
        if val and m.group(1) not in out:
            out[m.group(1)] = val
    return out


def _reg_vals(res):
    """★ 2.4.8 ผลค้นทะเบียน (dict ของ dol_api) ที่ยืนยันแปลงได้ -> {คอลัมน์ทะเบียน: ค่า} ไว้เขียน _REG_COLS (แผน 2.4.7 ข้อ 5)
    REG_SEQ/PARCEL_NO/SURVEY_NO มีเสมอ (ไม่มีค่า = None) · MOO มีเมื่อแหล่งส่งหมู่มา (ผลโฉนดของ UDM/LIS ไม่มีหมู่ ⇒ ไม่มีคีย์นี้) ·
    TAMBOL/AMPHUR/PROVINCE จาก city ('จ.นครนายก อ.องครักษ์ ต.ชุมพล' ของ UDM · ทาง LIS ประกอบเป็นรูปเดียวกัน) เฉพาะที่มีค่า ·
    ยืนยันไม่ได้/ไม่มีทะเบียน/คร่อมสาขา/แผนที่มีเลขนี้หลายแปลงโดยชั้นไม่ล็อกสาขา (เกณฑ์เดียวกับการเติมชนิดเอกสารของ ➕/📝)/ไม่ใช่ dict ⇒ {} ·
    ไม่อ่านช่องชื่อบุคคล (owner)"""
    if not isinstance(res, dict) or not res.get("verified") or res.get("not_registered") or res.get("not_found") \
            or res.get("cross_office") or ((res.get("match_count") or 1) > 1 and not res.get("branch_office")):
        return {}
    out = {"REG_SEQ": _txt(res.get("parcel_seq")) or None, "PARCEL_NO": _txt(res.get("parcel_no")) or None,
           "SURVEY_NO": _txt(res.get("survey_no")) or None}
    if not (out["REG_SEQ"] or out["PARCEL_NO"]):
        return {}
    if "moo" in res:
        out["MOO"] = _txt(res.get("moo")) or None
    loc = _reg_loc(res.get("city"))
    for k, tag in (("TAMBOL", "ต"), ("AMPHUR", "อ"), ("PROVINCE", "จ")):
        if loc.get(tag):
            out[k] = loc[tag]
    return out


def _nm_for_login(login, names):
    """★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 22:2x "ปุ่มสร้าง ถ้าเป็นสิทธิ์ staff หรือ mod อยากให้เด้งชื่อคนทำเป็นชื่อเริ่มต้น ในช่องมอบหมาย")
    ชื่อผู้รับผิดชอบ (NAME) ของบัญชีฐานข้อมูล login จากรายชื่อในชั้น — ชื่อบัญชีขึ้นต้นด้วยชื่อนั้น (ไม่สนตัวพิมพ์) และตัวถัดไปไม่ใช่ตัวอักษร
    (_ . - ตัวเลข หรือจบ) · ตรงหลายชื่อ = ชื่อยาวสุด (ต้องเหลือชื่อเดียว ไม่นับตัวพิมพ์) · ไม่ตรง/กำกวม = '' — ห้ามเดา
    (ชื่อที่คนเรียก ≠ ชื่อบัญชี · การจับคู่ด้วยการขึ้นต้นเคยได้ 17/18 คน — คนที่เหลือเลือกเองในช่อง)"""
    lg = _txt(login).lower()
    if not lg:
        return ""
    hits = []
    for n in names or ():
        k = _txt(n).lower()
        # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 ⚪B7) สระ/วรรณยุกต์ไทย (หมวด M) นับเป็นตัวของคำ — เดิม isalpha() ⇒ "สมศรี_k" จับชื่อ "สมศร"
        if k and lg.startswith(k) and (len(lg) == len(k) or not (lg[len(k)].isalpha()
                                                                 or unicodedata.category(lg[len(k)]).startswith("M"))):
            hits.append(_txt(n))
    if not hits:
        return ""
    mx = max(len(h) for h in hits)
    top = [h for h in hits if len(h) == mx]
    return top[0] if len({h.lower() for h in top}) == 1 else ""


def _reg_txt(reg):
    """★ 2.4.8 ข้อความสั้นของค่าทะเบียนที่จะเขียน (กล่องตัวอย่าง/ยืนยันของ ➕/📝) · ว่าง ⇒ ''"""
    if not reg:
        return ""
    parts = [f"{lab} {reg[k]}" for lab, k in (("เลขที่", "PARCEL_NO"), ("หน้าสำรวจ", "SURVEY_NO"), ("หมู่", "MOO")) if reg.get(k)]
    loc = " ".join(f"{t}.{reg[k]}" for t, k in (("ต", "TAMBOL"), ("อ", "AMPHUR"), ("จ", "PROVINCE")) if reg.get(k))
    if loc:
        parts.append(loc)
    return ("ข้อมูลทะเบียน: " + " · ".join(parts)) if parts else ""


def _dol_doc_code(ptype):
    t = re.sub(r"\s+", "", _txt(ptype))
    if not t:
        return None
    for pat, code in _DOL_DOC_RULES:
        if re.search(pat, t):
            return code
    return None


def _marker_type_from_parcel(v):
    """★ rc2 (audit A2-03) — Type ที่หมุดใหม่/หมุดที่ปรับควรได้จาก Type ของแปลง (Add Node · 🍩 · ➕ ใช้ที่เดียวกัน)
    ปรับรูปแบบแบบเดียวกับด่านล็อก (norm_type: trim + ตัวพิมพ์ใหญ่ · NULL/'NULL'/ว่าง = None)
    CT-RTK ⇒ None (ไม่ตั้ง Type ให้หมุด · CT-RTK อยู่ในชั้น CT_ เท่านั้น)
    ★ rc2 S_close (review R3 note) — CT-RTK ที่สะกดต่าง (CT_RTK · CTRTK · CT RTK · ขีดยาว · อักขระล่องหน) ก็ไม่ตั้งให้หมุด
      (เทียบแบบเหลือแค่ A–Z/0–9 · กติกาเจ้าของงาน 13 ต.ค.: ชั้นหมุดต้องไม่มี CT-RTK จากเครื่องมือใด)"""
    t = norm_type(v)
    if not t or t in _TYPE_NOT_ON_MARKER:
        return None
    if re.sub(r"[^0-9A-Z]", "", t) in {re.sub(r"[^0-9A-Z]", "", x) for x in _TYPE_NOT_ON_MARKER}:
        return None
    return t


def _is_sql_null(v):
    """★ 2.3.7 (review DI-12 / DI-52) — NULL "จริง" ของฐานเท่านั้น (None หรือ QVariant ว่างจาก provider)
    ต่างจาก _txt ที่นับสตริง 'NULL' / '' / ช่องว่าง เป็นว่างด้วย — ใช้ตอนต้อง "ซ่อม" แถวที่มีสตริงขยะ
    (เหตุ 15 ก.ย. 69: สตริง 'NULL' ใน SCORE 410 แปลง ⇒ เว็บติดตามงานหยุด 15 ชั่วโมง)"""
    if v is None:
        return True
    try:
        from qgis.PyQt.QtCore import QVariant
        return isinstance(v, QVariant) and v.isNull()
    except Exception:
        return False


def _natkey(s):
    """เรียงแบบคนอ่าน: 'ที่ดิน 3' มาก่อน 'ที่ดิน 12' (ตำแหน่งคู่ = ข้อความ · คี่ = ตัวเลข จึงเทียบกันได้เสมอ)"""
    return [int(x) if i % 2 else x for i, x in enumerate(re.split(r"(\d+)", str(s)))]


def _sheet_label(m1, m2, m3, m4, landno):
    """★ 2.3.7 (review UX-06) — ชื่อแปลงที่พนักงานอ่านรู้เรื่อง 'ระวาง 5136 4 7842-07 ที่ดิน 12' (แทน fid)
    รับค่าดิบจาก provider ได้ (ผ่าน _txt) · ไม่มีเลขระวางเลย = ''"""
    m1, m2, m3, m4, ln = (_txt(x) for x in (m1, m2, m3, m4, landno))
    if not (m1 or m2 or m3 or ln):
        return ""
    return f"ระวาง {m1} {m2} {m3}-{m4 or '00'} ที่ดิน {ln or '-'}"


def _osa(a, b):
    """ระยะแก้คำ (แทน/เพิ่ม/ลบ/สลับตัวติดกัน = 1) — จับชนิดแปลงที่พิมพ์เพี้ยนจาก L1 (★ 2.3.7 review DI-55)"""
    la, lb = len(a), len(b)
    d = [[0] * (lb + 1) for _ in range(la + 1)]
    for i in range(la + 1):
        d[i][0] = i
    for j in range(lb + 1):
        d[0][j] = j
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] != b[j - 1]))
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[la][lb]
