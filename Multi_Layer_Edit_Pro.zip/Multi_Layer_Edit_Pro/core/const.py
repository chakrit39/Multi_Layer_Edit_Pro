# -*- coding: utf-8 -*-
"""ค่าคงที่ของปลั๊กอิน และ path ของ main.py ที่รากปลั๊กอิน

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import os

# ★ 2.4.0 (audit MT-17) — path ของ main.py ที่รากปลั๊กอิน: โค้ดที่ย้ายออกจาก main.py ใช้แทน __file__ เดิม
#   ⇒ os.path.dirname(...) ยังชี้โฟลเดอร์ปลั๊กอินเหมือนเดิม (updater/ไอคอน/metadata ไม่ชี้ผิดโฟลเดอร์ย่อย)
_MLEP_MAIN_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "main.py")


# ============ เงาตัวอย่าง (preview) ของ Move/Rotate/Scale ============
# จำนวนคลิกที่แต่ละโหมดต้องใช้ — ใช้ร่วมกันทั้ง handle_click และเงาตัวอย่าง
# (เดิมตารางนี้อยู่ใน handle_click ที่เดียว — แยกออกมากัน "จำนวนคลิก" ของสองฝั่งหลุดจากกัน)
# ★ rc2 (audit A2-07) — ไม่มี 'modify_node': Move Node ใช้ SyncVertexTool ไม่ผ่าน handle_click/execute_tool
_CLICK_LIMIT = {'move': 2, 'rotate': 3, 'scale': 3, 'transform': 4}

# โหมดที่มีเงาตัวอย่าง — transform ไม่มี:
#   transform: กฎปลดล็อก L1-TS ตัดสินจากจุดที่ 4 ซึ่งก็คือเมาส์ -> เงาจะพลิกไปมาทุกเฟรม
_PREVIEW_MODES = ('move', 'rotate', 'scale')

# เกินจำนวนจุดนี้ -> ย่อเงาแปลงเป็นกรอบรวม (convex hull) กันเฟรมตกตอนเลือกทั้งระวาง
# hull ไม่ทำให้เงาโกหก: move/rotate/scale เป็น similarity ทั้งหมด -> hull(T(g)) == T(hull(g))
_PREVIEW_VERTEX_BUDGET = 20000
