"""
QGIS Map Tools for Multi-Layer Edit Pro
"""
from qgis.core import (
    QgsProject, QgsFeatureRequest, QgsGeometry, QgsRectangle, 
    QgsWkbTypes, QgsCoordinateTransform, QgsPointXY, QgsCoordinateReferenceSystem,
    QgsSpatialIndex
)
from qgis.gui import QgsMapTool, QgsRubberBand, QgsVertexMarker
from qgis.PyQt import QtCore, QtGui
from qgis.utils import iface

class BoxSelectTool(QgsMapTool):
    """ลากกล่องเลือก point features (สะสมหลายรอบ); คลิกขวา=เสร็จ, Ctrl+ลาก=เอาออก, Esc=ยกเลิก"""

    def __init__(self, canvas, on_box, on_finish, on_cancel):
        super().__init__(canvas)
        self._canvas = canvas
        self._on_box = on_box
        self._on_finish = on_finish
        self._on_cancel = on_cancel
        self._start = None
        self._band = None
        self.setCursor(QtCore.Qt.CrossCursor)

    def canvasPressEvent(self, e):
        if e.button() == QtCore.Qt.LeftButton:
            self._start = self.toMapCoordinates(e.pos())
            self._band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
            self._band.setColor(QtGui.QColor(0, 120, 255))
            self._band.setFillColor(QtGui.QColor(0, 120, 255, 40))
            self._band.setWidth(2)

    def canvasMoveEvent(self, e):
        if self._start is None or self._band is None:
            return
        cur = self.toMapCoordinates(e.pos())
        self._band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self._start, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_band(); self._start = None
            self._on_finish()
            return
        if e.button() == QtCore.Qt.LeftButton and self._start is not None:
            cur = self.toMapCoordinates(e.pos())
            rect = QgsRectangle(self._start, cur)
            self._clear_band(); self._start = None
            if rect.width() < 1e-9 and rect.height() < 1e-9:
                tol = self._canvas.mapUnitsPerPixel() * 6
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol, cur.x() + tol, cur.y() + tol)
            remove = bool(e.modifiers() & QtCore.Qt.ControlModifier)
            self._on_box(rect, remove)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._clear_band()
            self._on_cancel()

    def _clear_band(self):
        if self._band:
            try:
                self._canvas.scene().removeItem(self._band)
            except Exception:
                pass
            self._band = None

    def deactivate(self):
        self._clear_band()
        super().deactivate()


class PolygonPickTool(QgsMapTool):
    """cursor กากบาท + ไฮไลต์แปลงใต้เมาส์ (ก่อนคลิก) เป็นตัวช่วยตัดสินใจ
    คลิก = ส่ง feature กลับผ่าน click_cb ; เลื่อนเมาส์ = hover_cb"""

    def __init__(self, canvas, layer, click_cb, hover_cb):
        super().__init__(canvas)
        self._canvas = canvas
        self._layer = layer
        self._click_cb = click_cb
        self._hover_cb = hover_cb
        self._last_fid = None
        self._picked = False
        self.setCursor(QtCore.Qt.CrossCursor)
        # cache transform ครั้งเดียว (เดิมสร้างใหม่ทุก mouse-move ตอน hover)
        proj = QgsProject.instance()
        self._xform = None
        if layer.crs() != proj.crs():
            try:
                self._xform = QgsCoordinateTransform(proj.crs(), layer.crs(), proj)
            except Exception:
                self._xform = None
                
        # สร้าง Spatial Index ล่วงหน้าเพื่อความเร็วในการค้นหาแปลงใต้เมาส์
        self._idx = QgsSpatialIndex(layer.getFeatures(QgsFeatureRequest().setNoAttributes()))

    def _feature_at(self, event):
        """หา feature ในเลเยอร์ที่เลือก ใต้ตำแหน่งเมาส์ (None ถ้าไม่มี)"""
        map_pt = self.toMapCoordinates(event.pos())   # CRS ของโปรเจกต์
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
            except Exception:
                pt = map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))

        tol = self._canvas.mapUnitsPerPixel() * 4
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                pass

        found = fallback = None
        fids = self._idx.intersects(rect)
        if not fids:
            return None
            
        for f in self._layer.getFeatures(QgsFeatureRequest().setFilterFids(fids)):
            g = f.geometry()
            if fallback is None:
                fallback = f
            if g and g.contains(gp):
                found = f
                break
        return found or fallback

    def canvasMoveEvent(self, event):
        # ไฮไลต์แปลงใต้เมาส์ (อัปเดตเฉพาะเมื่อเปลี่ยนแปลง)
        feat = self._feature_at(event)
        fid = feat.id() if feat is not None else None
        if fid == self._last_fid:
            return
        self._last_fid = fid
        self._hover_cb(feat, self._layer)

    def canvasReleaseEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        feat = self._feature_at(event)
        if feat is None:
            iface.messageBar().pushMessage(
                "DOL", "ไม่พบแปลงในเลเยอร์ที่เลือกตรงตำแหน่งที่คลิก ลองใหม่อีกครั้ง", level=1, duration=6)
            return
        self._picked = True
        self._click_cb(feat, self._layer)

    def deactivate(self):
        # ถ้าเลิกใช้เครื่องมือโดยไม่ได้คลิก -> ลบไฮไลต์ hover + ข้อความแนะนำที่ค้างอยู่
        if not self._picked:
            try:
                self._hover_cb(None, self._layer)
            except Exception:
                pass
            try:
                iface.messageBar().clearWidgets()
            except Exception:
                pass
        super().deactivate()


class AddNodeTool(QgsMapTool):
    """เพิ่ม node ให้แปลง + เพิ่มหมุด (ไม่ต้องคลิกขวา)
    - คลิกในแปลง = เลือก/เอาออก (ไฮไลต์เขียว, หลายแปลงได้)
    - เลื่อนเมาส์ใกล้หมุด = snap (วงกลมแดง) -> คลิกตอนนั้น = แทรก node เข้าทุกแปลงที่เลือก + เพิ่มหมุด
    - คลิกขวา / Esc = ยกเลิก"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.picked = []          # [(fid, rubberband)]
        self.setCursor(QtCore.Qt.CrossCursor)
        proj = QgsProject.instance()
        self._to_poly = (QgsCoordinateTransform(proj.crs(), poly_lyr.crs(), proj)
                         if poly_lyr.crs() != proj.crs() else None)
        self._to_pt = (QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj)
                       if point_lyr.crs() != proj.crs() else None)
        self._from_pt = (QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
                         if point_lyr.crs() != proj.crs() else None)
        # ตัวบอก snap = วงกลมแดงที่เด้งไปเกาะหมุดใกล้สุด
        self._snap_mk = QgsVertexMarker(canvas)
        self._snap_mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self._snap_mk.setColor(QtGui.QColor(255, 0, 0))
        self._snap_mk.setPenWidth(3)
        self._snap_mk.setIconSize(14)
        self._snap_mk.hide()
        # hover highlight แปลงใต้เมาส์ก่อนคลิก (เหลือง) เป็นตัวช่วยตัดสินใจ
        self._hover_rb = None
        self._hover_fid = None
        
        # Spatial Index สำหรับความรวดเร็วตอนเลื่อนเมาส์
        self._poly_idx = QgsSpatialIndex(poly_lyr.getFeatures(QgsFeatureRequest().setNoAttributes()))
        self._point_idx = QgsSpatialIndex(point_lyr.getFeatures(QgsFeatureRequest().setNoAttributes()))

    def _poly_at(self, map_pt):
        pt = self._to_poly.transform(map_pt) if self._to_poly else map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        tol = self._canvas.mapUnitsPerPixel() * 4
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._to_poly is not None:
            try:
                rect = self._to_poly.transformBoundingBox(rect)
            except Exception:
                pass
        found = fallback = None
        fids = self._poly_idx.intersects(rect)
        if not fids:
            return None
            
        for f in self.poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(fids)):
            g = f.geometry()
            if fallback is None:
                fallback = f
            if g and g.contains(gp):
                found = f
                break
        return found or fallback

    def _nearest_marker(self, map_pt):
        """หาหมุดใกล้สุดในรัศมี snap -> (xy ใน CRS หมุด, xy ใน CRS แผนที่) หรือ (None, None)"""
        click = self._to_pt.transform(map_pt) if self._to_pt else QgsPointXY(map_pt)
        tol = max(self._canvas.mapUnitsPerPixel() * 12, 0.5)
        rect = QgsRectangle(click.x() - tol, click.y() - tol, click.x() + tol, click.y() + tol)
        best = None
        bestd = tol * tol
        fids = self._point_idx.intersects(rect)
        if not fids:
            return None, None
            
        for f in self.point_lyr.getFeatures(
                QgsFeatureRequest().setFilterFids(fids).setNoAttributes()):
            xy = f.geometry().asPoint()
            d = (xy.x() - click.x()) ** 2 + (xy.y() - click.y()) ** 2
            if d <= bestd:
                bestd = d
                best = xy
        if best is None:
            return None, None
        map_xy = self._from_pt.transform(best) if self._from_pt else QgsPointXY(best)
        return best, map_xy

    def _add_highlight(self, feat):
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(0, 170, 0))
        rb.setFillColor(QtGui.QColor(0, 170, 0, 60))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        return rb

    def _toggle(self, feat):
        # กันชน: ห้ามเลือกแปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
        tp = self.plugin._poly_type_str(self.poly_lyr, feat)
        if tp in ("L1-RTK", "L1-TS"):
            iface.messageBar().pushMessage(
                "Add Node", f"แปลง {feat.id()} เป็น {tp} (พิกัดอ้างอิง) — ห้ามเพิ่ม node",
                level=2, duration=6)
            return
        # เลือกได้ทีละ 1 แปลง: คลิกแปลงใหม่ = แทนที่ • คลิกแปลงเดิมซ้ำ = ยกเลิก
        fid = feat.id()
        already = bool(self.picked) and self.picked[0][0] == fid
        self._clear_highlights()
        if already:
            iface.messageBar().pushInfo("Add Node", "ยกเลิกเลือกแปลง — คลิกเลือกแปลงใหม่ได้")
            return
        self.picked = [(fid, self._add_highlight(feat))]
        iface.messageBar().pushInfo(
            "Add Node", "เลือกแปลงแล้ว • เลื่อนไปที่หมุด (snap) แล้วคลิกเพื่อเพิ่ม node")

    def _set_hover(self, feat):
        """ไฮไลต์แปลงใต้เมาส์ (เหลือง) — ข้ามถ้าเป็นแปลงที่เลือกอยู่แล้ว (เขียว)"""
        fid = feat.id() if feat is not None else None
        if feat is not None and self.picked and self.picked[0][0] == fid:
            feat, fid = None, None
        if fid == self._hover_fid:
            return
        self._hover_fid = fid
        if self._hover_rb is not None:
            try:
                self._canvas.scene().removeItem(self._hover_rb)
            except Exception:
                pass
            self._hover_rb = None
        if feat is None:
            return
        # แปลงอ้างอิง L1-RTK/L1-TS = แดง (ห้ามเลือก) • ปกติ = เหลือง
        locked = self.plugin._poly_type_str(self.poly_lyr, feat) in ("L1-RTK", "L1-TS")
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        if locked:
            rb.setColor(QtGui.QColor(220, 0, 0))
            rb.setFillColor(QtGui.QColor(220, 0, 0, 45))
        else:
            rb.setColor(QtGui.QColor(255, 190, 0))
            rb.setFillColor(QtGui.QColor(255, 190, 0, 45))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        self._hover_rb = rb

    def canvasMoveEvent(self, event):
        if getattr(self, "_snap_mk", None) is None:
            return
        map_pt = self.toMapCoordinates(event.pos())
        _pt, map_xy = self._nearest_marker(map_pt)
        if map_xy is not None:
            self._snap_mk.setCenter(QgsPointXY(map_xy))
            self._snap_mk.show()
            self._set_hover(None)        # อยู่บนหมุด -> ไม่ต้อง hover แปลง
        else:
            self._snap_mk.hide()
            self._set_hover(self._poly_at(map_pt))

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._cancel()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        map_pt = self.toMapCoordinates(event.pos())
        pt_xy, _map_xy = self._nearest_marker(map_pt)
        if pt_xy is not None:
            # snap ติดหมุด -> วาง node (ต้องเลือกแปลงไว้ก่อน)
            if not self.picked:
                iface.messageBar().pushMessage(
                    "Add Node", "เลือกแปลงก่อน แล้วค่อยคลิกที่หมุด", level=1, duration=5)
                return
            fids = [f for f, _ in self.picked]
            if self.plugin._addnode_execute(self.poly_lyr, fids, pt_xy):
                self._finish()
        else:
            # ไม่ติดหมุด -> เลือก/เอาแปลงออก
            feat = self._poly_at(map_pt)
            if feat is None:
                iface.messageBar().pushMessage(
                    "Add Node", "ไม่พบแปลง/หมุดตรงนี้ — คลิกในแปลง หรือเลื่อนให้ snap ติดหมุด",
                    level=1, duration=4)
                return
            self._toggle(feat)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._cancel()

    def _clear_highlights(self):
        for _fid, rb in self.picked:
            try:
                self._canvas.scene().removeItem(rb)
            except Exception:
                pass
        self.picked = []

    def _remove_snap(self):
        if getattr(self, "_snap_mk", None) is not None:
            try:
                self._canvas.scene().removeItem(self._snap_mk)
            except Exception:
                pass
            self._snap_mk = None

    def _finish(self):
        self._canvas.refresh()
        iface.actionSelect().trigger()   # -> deactivate() ล้าง highlight/snap

    def _cancel(self):
        try:
            iface.messageBar().clearWidgets()
        except Exception:
            pass
        iface.actionSelect().trigger()

    def deactivate(self):
        self._clear_highlights()
        self._set_hover(None)
        self._remove_snap()
        super().deactivate()


