"""
QGIS Map Tools for Multi-Layer Edit Pro
"""
from qgis.core import (
    QgsProject, QgsFeatureRequest, QgsGeometry, QgsRectangle,
    QgsWkbTypes, QgsCoordinateTransform, QgsPointXY
)
from qgis.gui import QgsMapTool, QgsRubberBand, QgsVertexMarker
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.utils import iface

class BoxSelectTool(QgsMapTool):
    """ลากกล่องเลือก point features (สะสมหลายรอบ); คลิกขวา=เสร็จ, Ctrl+ลาก=เอาออก, Esc=ยกเลิก"""

    def __init__(self, canvas, on_box, on_finish, on_cancel):
        super().__init__(canvas)
        self._canvas = canvas
        self._on_box = on_box
        self._on_finish = on_finish
        self._on_cancel = on_cancel
        self._start = None
        self._band = None
        self.setCursor(QtCore.Qt.CrossCursor)

    def canvasPressEvent(self, e):
        if e.button() != QtCore.Qt.LeftButton:
            return
        self._start = self.toMapCoordinates(e.pos())
        self._band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        self._band.setColor(QtGui.QColor(255, 0, 0, 60))
        self._band.setWidth(1)

    def canvasMoveEvent(self, e):
        if self._start is None or self._band is None:
            return
        cur = self.toMapCoordinates(e.pos())
        self._band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self._start, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_band(); self._start = None
            self._on_finish()
            return
        if e.button() == QtCore.Qt.LeftButton and self._start is not None:
            cur = self.toMapCoordinates(e.pos())
            rect = QgsRectangle(self._start, cur)
            self._clear_band(); self._start = None
            if rect.width() < 1e-9 and rect.height() < 1e-9:
                tol = self._canvas.mapUnitsPerPixel() * 6
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol, cur.x() + tol, cur.y() + tol)
            remove = bool(e.modifiers() & QtCore.Qt.ControlModifier)
            self._on_box(rect, remove)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._clear_band()
            self._on_cancel()

    def _clear_band(self):
        if self._band:
            try:
                self._canvas.scene().removeItem(self._band)
            except Exception:
                pass
            self._band = None

    def deactivate(self):
        self._clear_band()
        super().deactivate()


class PolygonPickTool(QgsMapTool):
    """cursor กากบาท + ไฮไลต์แปลงใต้เมาส์ (ก่อนคลิก) เป็นตัวช่วยตัดสินใจ
    คลิก = ส่ง feature กลับผ่าน click_cb ; เลื่อนเมาส์ = hover_cb"""

    # hover ยิง getFeatures ทุก mouse-move = 1 query/เฟรมบน PostgreSQL -> รวบยอดทุก ~80ms
    HOVER_MS = 80

    def __init__(self, canvas, layer, click_cb, hover_cb):
        super().__init__(canvas)
        self._canvas = canvas
        self._layer = layer
        self._click_cb = click_cb
        self._hover_cb = hover_cb
        self._last_fid = None
        self._picked = False
        self.setCursor(QtCore.Qt.CrossCursor)
        # cache transform ครั้งเดียว (เดิมสร้างใหม่ทุก mouse-move ตอน hover)
        proj = QgsProject.instance()
        self._xform = None
        if layer.crs() != proj.crs():
            try:
                self._xform = QgsCoordinateTransform(proj.crs(), layer.crs(), proj)
            except Exception:
                self._xform = None
        # throttle hover: เก็บตำแหน่งล่าสุดไว้ ประมวลผลตาม timer แทนทุกเฟรม
        self._pending_pos = None
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(self.HOVER_MS)
        self._hover_timer.timeout.connect(self._hover_tick)

    def _feature_at_pos(self, pos):
        """หา feature ในเลเยอร์ที่เลือก ใต้ตำแหน่ง pixel pos (None ถ้าไม่มี)"""
        map_pt = self.toMapCoordinates(pos)   # CRS ของโปรเจกต์
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
            except Exception:
                pt = map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))

        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                pass

        req = QgsFeatureRequest().setFilterRect(rect).setNoAttributes()
        for f in self._layer.getFeatures(req):
            if f.geometry().intersects(gp):
                return f
        return None

    def canvasMoveEvent(self, event):
        # เก็บตำแหน่งไว้ก่อน — query จริงเกิดใน _hover_tick ตามรอบ timer
        self._pending_pos = event.pos()
        if not self._hover_timer.isActive():
            self._hover_timer.start()

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None:
            return
        # ไฮไลต์แปลงใต้เมาส์ (อัปเดตเฉพาะเมื่อเปลี่ยนแปลง)
        feat = self._feature_at_pos(pos)
        fid = feat.id() if feat is not None else None
        if fid == self._last_fid:
            return
        self._last_fid = fid
        self._hover_cb(feat, self._layer)

    def _features_at_pos(self, pos):
        """คืน "ทุกแปลง" ในเลเยอร์ที่ครอบจุดที่คลิก (แปลงซ้อนกัน) พร้อม attribute
        intersects กับ "จุดคลิกจริง" (ไม่ใช่กล่อง) = เฉพาะแปลงที่ครอบจุดนั้นจริง ; เรียงพื้นที่เล็ก->ใหญ่"""
        map_pt = self.toMapCoordinates(pos)
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
            except Exception:
                pt = map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                pass
        out = []
        for f in self._layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            g = f.geometry()
            if g is not None and not g.isNull() and g.intersects(gp):
                out.append(f)
        try:
            out.sort(key=lambda ff: ff.geometry().area())   # แปลงเล็ก (มักเป็นแปลงในซ้อน) อยู่บนสุด
        except Exception:
            pass
        return out

    def _choose_parcel(self, feats):
        """แปลงซ้อนกัน >1 -> popup ให้เลือกตามระวาง UTMMAP1-4 / UTMSCALE / LANDNO ; คืน None ถ้ายกเลิก"""
        def gv(f, name):
            try:
                if f.fields().indexOf(name) < 0:
                    return ""
                v = f[name]
                return "" if v is None else str(v).strip()
            except Exception:
                return ""
        labels = []
        for f in feats:
            m4 = gv(f, "UTMMAP4") or "00"
            labels.append(
                f"ระวาง {gv(f,'UTMMAP1')} {gv(f,'UTMMAP2')} {gv(f,'UTMMAP3')}-{m4}"
                f"  |  มาตราส่วน {gv(f,'UTMSCALE')}  |  เลขที่ดิน {gv(f,'LANDNO')}")
        item, ok = QtWidgets.QInputDialog.getItem(
            iface.mainWindow(), "เลือกแปลง (มีแปลงซ้อนกัน)",
            f"จุดที่คลิกมี {len(feats)} แปลงซ้อนกัน — เลือกแปลงที่ต้องการค้นหา:",
            labels, 0, False)
        if not ok:
            return None
        return feats[labels.index(item)]

    def canvasReleaseEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        # เก็บ "ทุกแปลง" ที่ครอบจุดคลิก — ถ้าซ้อนกัน >1 ให้ผู้ใช้เลือกตามระวาง (image + survey ใช้ tool นี้ทั้งคู่)
        feats = self._features_at_pos(event.pos())
        if not feats:
            iface.messageBar().pushMessage(
                "DOL", "ไม่พบแปลงในเลเยอร์ที่เลือกตรงตำแหน่งที่คลิก ลองใหม่อีกครั้ง", level=1, duration=6)
            return
        if len(feats) == 1:
            chosen = feats[0]
        else:
            chosen = self._choose_parcel(feats)
            if chosen is None:
                return   # ผู้ใช้ยกเลิก popup
        # ดึง feature เต็มตาม id ให้ชัวร์ทุก provider (บาง provider คืน NULL ถ้าไม่มี attribute)
        full = self._layer.getFeature(chosen.id())
        if full is None or not full.isValid():
            full = chosen
        self._picked = True
        self._click_cb(full, self._layer)

    def deactivate(self):
        self._hover_timer.stop()
        self._pending_pos = None
        # ถ้าเลิกใช้เครื่องมือโดยไม่ได้คลิก -> ลบไฮไลต์ hover + ข้อความแนะนำที่ค้างอยู่
        if not self._picked:
            try:
                self._hover_cb(None, self._layer)
            except Exception:
                pass
            try:
                iface.messageBar().clearWidgets()
            except Exception:
                pass
        super().deactivate()


class AddNodeTool(QgsMapTool):
    """เพิ่ม node ให้แปลง + เพิ่มหมุด (ไม่ต้องคลิกขวา)
    - คลิกในแปลง = เลือก/เอาออก (ไฮไลต์เขียว, หลายแปลงได้)
    - เลื่อนเมาส์ใกล้หมุด = snap (วงกลมแดง) -> คลิกตอนนั้น = แทรก node เข้าทุกแปลงที่เลือก + เพิ่มหมุด
    - คลิกขวา / Esc = ยกเลิก"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.picked = []          # [(fid, rubberband)]
        self.setCursor(QtCore.Qt.CrossCursor)
        proj = QgsProject.instance()
        self._to_poly = (QgsCoordinateTransform(proj.crs(), poly_lyr.crs(), proj)
                         if poly_lyr.crs() != proj.crs() else None)
        self._to_pt = (QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj)
                       if point_lyr.crs() != proj.crs() else None)
        self._from_pt = (QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
                         if point_lyr.crs() != proj.crs() else None)
        # ตัวบอก snap = วงกลมแดงที่เด้งไปเกาะหมุดใกล้สุด
        self._snap_mk = QgsVertexMarker(canvas)
        self._snap_mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self._snap_mk.setColor(QtGui.QColor(255, 0, 0))
        self._snap_mk.setPenWidth(3)
        self._snap_mk.setIconSize(14)
        self._snap_mk.hide()
        # hover highlight แปลงใต้เมาส์ก่อนคลิก (เหลือง) เป็นตัวช่วยตัดสินใจ
        self._hover_rb = None
        self._hover_fid = None
        # throttle hover: เดิมยิงสูงสุด 2 query ต่อ mouse-move (_nearest_marker + _poly_at)
        # -> บน PostgreSQL คือ 2 round-trips ต่อเฟรม; รวบยอดประมวลผลทุก ~80ms แทน
        self._pending_pos = None
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(80)
        self._hover_timer.timeout.connect(self._hover_tick)

    def _poly_at(self, map_pt):
        pt = self._to_poly.transform(map_pt) if self._to_poly else map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol, map_pt.x() + tol, map_pt.y() + tol)
        if self._to_poly is not None:
            try:
                rect = self._to_poly.transformBoundingBox(rect)
            except Exception:
                pass
        
        # ★ ต้องดึงฟิลด์ Type มาด้วย — ห้ามใช้ setNoAttributes() ตรงนี้
        #   feature ที่ได้จากนี่ถูกส่งต่อให้ _poly_type_str() (บรรทัด ~332 _toggle และ ~366 _set_hover)
        #   เพื่อเช็คว่าเป็นแปลงล็อก L1-RTK/L1-TS หรือไม่
        #   บน provider PostGIS setNoAttributes() ทำให้ attribute เป็น None ทั้งหมด (พิสูจน์แล้วกับชั้นจริง)
        #   -> Type=None -> ไม่เข้าเงื่อนไข ("L1-RTK","L1-TS") -> กันชนไม่ทำงานเลยใน Add Node
        #   (memory layer ไม่ strip จึงไม่เคยเห็นบั๊กนี้ตอนทดสอบ)
        #   ดึงเฉพาะฟิลด์ Type ฟิลด์เดียว ไม่ใช่ทั้งแถว -> ยังเบาอยู่บน hover path
        req = QgsFeatureRequest().setFilterRect(rect)
        ti = self.poly_lyr.fields().indexOf(self.plugin._resolve_field(self.poly_lyr, {'type'}) or "")
        if ti >= 0:
            req.setSubsetOfAttributes([ti])
        else:
            req.setNoAttributes()
        for f in self.poly_lyr.getFeatures(req):
            if f.geometry().intersects(gp):
                return f
        return None

    def _nearest_marker(self, map_pt):
        """หาหมุดใกล้สุดในรัศมี snap -> (xy ใน CRS หมุด, xy ใน CRS แผนที่) หรือ (None, None)"""
        # 12px เพดาน 25 ม. (เดิมไม่มีเพดาน ตอน zoom-out ระดับอำเภอ กรอบ ~1.2 กม.
        # ดึงหมุดหลักพันจาก PostGIS ทุกครั้งที่ขยับเมาส์) — แต่การันตี >=4px เสมอ:
        # เพดานล้วน ๆ ทำให้จุดคลิกเล็กกว่าไอคอนหมุดตอน zoom-out ลึก (คลิกบนหมุด
        # ที่เห็น ๆ แล้วพลาด -> ตกไปเลือกแปลงแทน = ได้แปลงผิดตัว)
        _mupp = self._canvas.mapUnitsPerPixel()
        map_tol = max(min(max(_mupp * 12, 0.5), 25.0), _mupp * 4)
        rect = QgsRectangle(map_pt.x() - map_tol, map_pt.y() - map_tol, map_pt.x() + map_tol, map_pt.y() + map_tol)
        if self._to_pt is not None:
            try:
                rect = self._to_pt.transformBoundingBox(rect)
            except Exception:
                pass
                
        best = None
        best_map = None
        bestd = map_tol * map_tol
            
        for f in self.point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes()):
            xy = f.geometry().asPoint()
            map_xy = self._from_pt.transform(xy) if self._from_pt else QgsPointXY(xy)
            d = (map_xy.x() - map_pt.x()) ** 2 + (map_xy.y() - map_pt.y()) ** 2
            if d <= bestd:
                bestd = d
                best = xy
                best_map = map_xy
        if best is None:
            return None, None
        return best, best_map

    def _add_highlight(self, feat):
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(0, 170, 0))
        rb.setFillColor(QtGui.QColor(0, 170, 0, 60))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        return rb

    def _toggle(self, feat):
        # กันชน: ห้ามเลือกแปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
        tp = self.plugin._poly_type_str(self.poly_lyr, feat)
        if tp in ("L1-RTK", "L1-TS") and not self.plugin._admin_unlock_l1:
            iface.messageBar().pushMessage(
                "Add Node", f"แปลง {feat.id()} เป็น {tp} (พิกัดอ้างอิง) — ห้ามเพิ่ม node",
                level=2, duration=6)
            return
        # เลือกได้ทีละ 1 แปลง: คลิกแปลงใหม่ = แทนที่ • คลิกแปลงเดิมซ้ำ = ยกเลิก
        fid = feat.id()
        already = bool(self.picked) and self.picked[0][0] == fid
        self._clear_highlights()
        if already:
            iface.messageBar().pushInfo("Add Node", "ยกเลิกเลือกแปลง — คลิกเลือกแปลงใหม่ได้")
            return
        self.picked = [(fid, self._add_highlight(feat))]
        iface.messageBar().pushInfo(
            "Add Node", "เลือกแปลงแล้ว • เลื่อนไปที่หมุด (snap) แล้วคลิกเพื่อเพิ่ม node")

    def _set_hover(self, feat):
        """ไฮไลต์แปลงใต้เมาส์ (เหลือง) — ข้ามถ้าเป็นแปลงที่เลือกอยู่แล้ว (เขียว)"""
        fid = feat.id() if feat is not None else None
        if feat is not None and self.picked and self.picked[0][0] == fid:
            feat, fid = None, None
        if fid == self._hover_fid:
            return
        self._hover_fid = fid
        if self._hover_rb is not None:
            try:
                self._canvas.scene().removeItem(self._hover_rb)
            except Exception:
                pass
            self._hover_rb = None
        if feat is None:
            return
        # แปลงอ้างอิง L1-RTK/L1-TS = แดง (ห้ามเลือก) • ปกติ = เหลือง
        locked = self.plugin._poly_type_str(self.poly_lyr, feat) in ("L1-RTK", "L1-TS")
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        if locked:
            rb.setColor(QtGui.QColor(220, 0, 0))
            rb.setFillColor(QtGui.QColor(220, 0, 0, 45))
        else:
            rb.setColor(QtGui.QColor(255, 190, 0))
            rb.setFillColor(QtGui.QColor(255, 190, 0, 45))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        self._hover_rb = rb

    def canvasMoveEvent(self, event):
        if getattr(self, "_snap_mk", None) is None:
            return
        # เก็บตำแหน่งไว้ก่อน — query จริงเกิดใน _hover_tick ตามรอบ timer
        self._pending_pos = event.pos()
        if not self._hover_timer.isActive():
            self._hover_timer.start()

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None or getattr(self, "_snap_mk", None) is None:
            return
        map_pt = self.toMapCoordinates(pos)
        _pt, map_xy = self._nearest_marker(map_pt)
        if map_xy is not None:
            self._snap_mk.setCenter(QgsPointXY(map_xy))
            self._snap_mk.show()
            self._set_hover(None)        # อยู่บนหมุด -> ไม่ต้อง hover แปลง
        else:
            self._snap_mk.hide()
            self._set_hover(self._poly_at(map_pt))

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._cancel()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        map_pt = self.toMapCoordinates(event.pos())
        pt_xy, _map_xy = self._nearest_marker(map_pt)
        if pt_xy is not None:
            # snap ติดหมุด -> วาง node (ต้องเลือกแปลงไว้ก่อน)
            if not self.picked:
                iface.messageBar().pushMessage(
                    "Add Node", "เลือกแปลงก่อน แล้วค่อยคลิกที่หมุด", level=1, duration=5)
                return
            fids = [f for f, _ in self.picked]
            if self.plugin._addnode_execute(self.poly_lyr, fids, pt_xy):
                # อัปเดตไฮไลต์แปลงเพื่อโชว์ node ใหม่ที่เพิ่งเพิ่มเข้าไป
                for fid, rb in self.picked:
                    feat = self.poly_lyr.getFeature(fid)
                    if feat.isValid():
                        rb.setToGeometry(feat.geometry(), self.poly_lyr)
                self._canvas.refresh()
                iface.messageBar().pushInfo("Add Node", "เพิ่มหมุดสำเร็จ — สามารถคลิกเพิ่มหมุดอื่นต่อได้เลย หรือคลิกขวาเพื่อเสร็จสิ้น")
        else:
            # ไม่ติดหมุด -> เลือก/เอาแปลงออก
            feat = self._poly_at(map_pt)
            if feat is None:
                iface.messageBar().pushMessage(
                    "Add Node", "ไม่พบแปลง/หมุดตรงนี้ — คลิกในแปลง หรือเลื่อนให้ snap ติดหมุด",
                    level=1, duration=4)
                return
            self._toggle(feat)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._cancel()

    def _clear_highlights(self):
        for _fid, rb in self.picked:
            try:
                self._canvas.scene().removeItem(rb)
            except Exception:
                pass
        self.picked = []

    def _remove_snap(self):
        if getattr(self, "_snap_mk", None) is not None:
            try:
                self._canvas.scene().removeItem(self._snap_mk)
            except Exception:
                pass
            self._snap_mk = None

    def _finish(self):
        self._canvas.refresh()
        iface.actionSelect().trigger()   # -> deactivate() ล้าง highlight/snap

    def _cancel(self):
        try:
            iface.messageBar().clearWidgets()
        except Exception:
            pass
        iface.actionSelect().trigger()

    def deactivate(self):
        self._hover_timer.stop()
        self._pending_pos = None
        self._clear_highlights()
        self._set_hover(None)
        self._remove_snap()
        super().deactivate()



class SyncVertexTool(QgsMapTool):
    """เลือกและเลื่อนหมุดหลายเลเยอร์พร้อมกัน
    - คลิกเดี่ยว: คลิกหมุด -> เลือก 1 หมุด แล้ว "คลิกตำแหน่งใหม่" เพื่อย้าย (click-to-move)
    - หลายหมุด: ลากกล่องครอบหลายหมุด แล้วลากหมุดที่เลือกเพื่อย้าย (Shift+ลาก = เลือกเพิ่ม)
    - คลิกขวาเพื่อยกเลิก/เสร็จสิ้น"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.setCursor(QtCore.Qt.CrossCursor)
        
        self.selected_vertices = [] # [{'layer': lyr, 'fid': id, 'vidx': idx, 'pt': QgsPointXY, 'marker': QgsVertexMarker}]
        self.selected_keys = set() # O(1) lookup for (layer_id, fid, vidx)
        self.picked = [] # list of (fid, rubberband)
        self.drag_start_pt = None
        self.box_band = None
        self.drag_band = None
        self.is_moving = False
        self.armed = False          # โหมดคลิกเดี่ยว: เลือกหมุดแล้วรอ "คลิกครั้งถัดไป" เพื่อย้าย
        self.move_anchor = None     # ตำแหน่งอ้างอิงที่ย้ายจาก (โหมด armed)
        self._placing = False       # press ปัจจุบันคือ "คลิกปลายทาง" (สั่งย้ายตอน release)
        self.move_guide = None      # เส้นนำตอน armed (จากจุดอ้างอิงไปเมาส์)

        self.snap_marker = QgsVertexMarker(self._canvas)
        self.snap_marker.setIconType(QgsVertexMarker.ICON_CROSS)
        self.snap_marker.setColor(QtGui.QColor(255, 0, 255))
        self.snap_marker.setPenWidth(2)
        self.snap_marker.hide()

    def _clear_selection(self):
        for v in self.selected_vertices:
            if v.get('marker'):
                try:
                    self._canvas.scene().removeItem(v['marker'])
                except Exception:
                    pass
        self.selected_vertices = []
        self.selected_keys.clear()
        for attr in ('box_band', 'drag_band', 'move_guide'):
            b = getattr(self, attr, None)
            if b:
                try:
                    self._canvas.scene().removeItem(b)
                except Exception:
                    pass
                setattr(self, attr, None)
        # รีเซ็ตโหมดคลิกเดี่ยว
        self.armed = False
        self.move_anchor = None
        self._placing = False

    def _remove_guide(self):
        if self.move_guide:
            try:
                self._canvas.scene().removeItem(self.move_guide)
            except Exception:
                pass
            self.move_guide = None

    def _add_marker(self, pt):
        mk = QgsVertexMarker(self._canvas)
        mk.setIconType(QgsVertexMarker.ICON_BOX)
        mk.setColor(QtGui.QColor(255, 60, 0))
        mk.setFillColor(QtGui.QColor(255, 60, 0, 80))
        mk.setPenWidth(2)
        mk.setIconSize(10)
        mk.setCenter(pt)
        mk.show()
        return mk

    def _select_vertices_in_rect(self, rect, add_mode=False):
        if not add_mode:
            self._clear_selection()

        has_blocked = False
        has_cap = False      # เลือกทะลุเพดาน 800 จุด -> ตัด (กัน QgsVertexMarker ท่วมจอ/ลากกระตุก)
        proj = QgsProject.instance()
        locked_map = None   # ตาราง UTM ล็อก L1-RTK/L1-TS — โหลดครั้งแรกที่เจอหมุด (คิวรีเดียวต่อรอบ)

        selected_poly_ids = []
        selected_poly_utms = set()
        if self.poly_lyr:
            selected_poly_ids = self.poly_lyr.selectedFeatureIds()
            if selected_poly_ids:
                poly_utm_field = self.plugin._resolve_field(self.poly_lyr, {'utm', 'utm_code', 'utm_id'})
                if poly_utm_field:
                    u_idx = self.poly_lyr.fields().indexFromName(poly_utm_field)
                    # ดึงเฉพาะฟิลด์ UTM ไม่เอา geometry (เดิมดึงทั้ง feature)
                    req_u = (QgsFeatureRequest().setFilterFids(selected_poly_ids)
                             .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([u_idx]))
                    for f_p in self.poly_lyr.getFeatures(req_u):
                        val = f_p[poly_utm_field]
                        if val is not None:
                            selected_poly_utms.add(str(val).strip())
                            
        selected_point_ids = []
        if self.point_lyr:
            selected_point_ids = self.point_lyr.selectedFeatureIds()

        # ค้นหาใน point_lyr
        if self.point_lyr:
            to_pt = QgsCoordinateTransform(proj.crs(), self.point_lyr.crs(), proj) if self.point_lyr.crs() != proj.crs() else None
            from_pt = QgsCoordinateTransform(self.point_lyr.crs(), proj.crs(), proj) if self.point_lyr.crs() != proj.crs() else None
            try:
                pt_rect = to_pt.transformBoundingBox(rect) if to_pt else rect
            except:
                pt_rect = rect
            
            req = QgsFeatureRequest().setFilterRect(pt_rect)
            point_utm_field = self.plugin._resolve_field(self.point_lyr, {'utm', 'utm_code', 'utm_id'})

            for f in self.point_lyr.getFeatures(req):
                # ถ้ามีการ select หมุดเอาไว้ ให้ดึงเฉพาะหมุดที่ select
                if selected_point_ids and f.id() not in selected_point_ids:
                    continue
                
                # ถ้าไม่ได้ select หมุด แต่มีแปลงที่ถูก select ไว้ ให้กรองหมุดด้วย UTM
                if not selected_point_ids and selected_poly_utms and point_utm_field:
                    pt_val = f[point_utm_field]
                    if pt_val is None or str(pt_val).strip() not in selected_poly_utms:
                        continue

                g = f.geometry()
                if g.intersects(pt_rect):
                    map_pt = from_pt.transform(g.asPoint()) if from_pt else g.asPoint()
                    if self.poly_lyr:
                        if locked_map is None:
                            locked_map = self.plugin._locked_utm_map(self.poly_lyr)
                        is_locked, type_str = self.plugin._is_point_feature_locked(f, locked_map)
                        if is_locked:
                            has_blocked = True
                            continue
                    if len(self.selected_vertices) >= 800:
                        has_cap = True
                        break
                    key = (self.point_lyr.id(), f.id(), -1)
                    if key not in self.selected_keys:
                        self.selected_keys.add(key)
                        self.selected_vertices.append({
                            'layer': self.point_lyr, 'fid': f.id(), 'vidx': -1, 'pt': map_pt,
                            'marker': self._add_marker(map_pt)
                        })
                        
        # ค้นหาใน poly_lyr (ข้ามถ้าชนเพดานแล้ว — ผลจะถูกยกเลิกทั้งหมดอยู่ดี)
        if self.poly_lyr and not has_cap:
            to_poly = QgsCoordinateTransform(proj.crs(), self.poly_lyr.crs(), proj) if self.poly_lyr.crs() != proj.crs() else None
            from_poly = QgsCoordinateTransform(self.poly_lyr.crs(), proj.crs(), proj) if self.poly_lyr.crs() != proj.crs() else None
            try:
                poly_rect = to_poly.transformBoundingBox(rect) if to_poly else rect
            except:
                poly_rect = rect
                
            req = QgsFeatureRequest().setFilterRect(poly_rect)
            selected_poly_ids = self.poly_lyr.selectedFeatureIds()
            # ★ กันฉีกกติกาเหล็ก: ถ้าผู้ใช้ select "เฉพาะหมุด" ไว้ (ไม่ได้ select แปลง)
            #   เดิมฝั่งหมุดถูกจำกัดตาม selection แต่ฝั่งมุมแปลงกวาดทุกมุมในกรอบ
            #   -> ลากแล้วมุมแปลงขยับ แต่หมุดของมัน (ที่ไม่ได้เลือก) อยู่กับที่
            #   จำกัดมุมแปลงให้เหลือเฉพาะที่ทับหมุดที่ถูกเลือก (±5 ซม. = tolerance มุมร่วมของปลั๊กอิน)
            sel_pt_idx = None
            if selected_point_ids and not selected_poly_ids:
                # grid bucket ช่อง 1 ซม. -> เช็คต่อ vertex เป็น O(1) แทนสแกนทั้ง list
                # 1 ซม. = tolerance เดียวกับ _marker_exists_here (มุมกับหมุด weld กันระดับ mm;
                # 5 ซม. กว้างจนคว้ามุมของแปลงข้างเคียงที่ไม่ใช่คู่ของหมุดมาได้)
                sel_pt_idx = {}
                for v in self.selected_vertices:
                    if v['layer'] is self.point_lyr:
                        q = v['pt']
                        sel_pt_idx.setdefault(
                            (round(q.x() / 0.01), round(q.y() / 0.01)), []).append(q)
            for f in self.poly_lyr.getFeatures(req):
                # ถ้ามีแปลงที่ถูก select อยู่ ให้ย้ายได้แค่แปลงที่ถูก select เท่านั้น
                if selected_poly_ids and f.id() not in selected_poly_ids:
                    continue
                # กันชน: ห้ามเลือก L1-RTK / L1-TS
                tp = self.plugin._poly_type_str(self.poly_lyr, f)
                if tp in ("L1-RTK", "L1-TS") and not self.plugin._admin_unlock_l1:
                    has_blocked = True
                    continue
                g = f.geometry()
                # ต้องหาทุก vertex ที่อยู่ใน poly_rect
                for vidx, vpt in enumerate(g.vertices()):
                    vpt_xy = QgsPointXY(vpt.x(), vpt.y())
                    if poly_rect.contains(vpt_xy):
                        map_pt = from_poly.transform(vpt_xy) if from_poly else vpt_xy
                        if sel_pt_idx is not None:
                            _cx = round(map_pt.x() / 0.01); _cy = round(map_pt.y() / 0.01)
                            _hit = any(abs(map_pt.x() - q.x()) <= 0.01 and
                                       abs(map_pt.y() - q.y()) <= 0.01
                                       for gx in (_cx - 1, _cx, _cx + 1)
                                       for gy in (_cy - 1, _cy, _cy + 1)
                                       for q in sel_pt_idx.get((gx, gy), ()))
                            if not _hit:
                                continue
                        if len(self.selected_vertices) >= 800:
                            has_cap = True
                            break
                        key = (self.poly_lyr.id(), f.id(), vidx)
                        if key not in self.selected_keys:
                            self.selected_keys.add(key)
                            self.selected_vertices.append({
                                'layer': self.poly_lyr, 'fid': f.id(), 'vidx': vidx, 'pt': map_pt,
                                'marker': self._add_marker(map_pt)
                            })
                if has_cap:
                    break     # เลิกไล่ feature ที่เหลือ — ผลถูกยกเลิกทั้งหมดข้างล่างอยู่แล้ว
                            
        if has_cap:
            # ★ ห้ามตัดครึ่ง ๆ กลาง ๆ: ถ้าตัดกลางคัน หมุดบางตัวถูกเลือกโดยมุมแปลงคู่ของมัน
            #   โดนตัดทิ้ง -> ลากแล้วขยับไม่ครบคู่ (ฉีกกติกาเหล็กเสียเอง) -> ยกเลิกทั้งหมด
            self._clear_selection()
            self.plugin.iface.messageBar().pushMessage(
                "Move Node", "เลือกเกิน 800 จุด — ยกเลิกการเลือกทั้งหมด (กันแปลง/หมุดขยับไม่ครบคู่) "
                             "กรุณาลากกล่องให้เล็กลง", level=2, duration=8)
            return
        if has_blocked:
            self.plugin.iface.messageBar().pushMessage(
                "MLEP Guard", "หมุดหรือแปลงอ้างอิง L1-RTK / L1-TS ถูกข้ามเพื่อป้องกันการแก้ไข!",
                level=1, duration=5
            )
        elif self.selected_vertices:
            iface.messageBar().pushInfo("Move Node", f"เลือก {len(self.selected_vertices)} หมุดแล้ว")
        else:
            iface.messageBar().pushInfo("Move Node", "ไม่พบหมุดในบริเวณที่คลิก กรุณาลองใหม่")

    def canvasPressEvent(self, e):
        if e.button() != QtCore.Qt.LeftButton:
            return

        if self.is_moving:
            return

        shift = bool(e.modifiers() & QtCore.Qt.ShiftModifier)
        match = self._canvas.snappingUtils().snapToMap(e.pos())
        self.drag_start_pt = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        # โหมด armed (คลิกเดี่ยวเลือกหมุดไว้แล้ว) + คลิกปกติ -> คลิกนี้คือ "ปลายทาง" ย้าย (สั่งตอน release)
        if self.armed and not shift:
            self._placing = True
            return
        self._placing = False

        # เช็คว่าคลิกโดนหมุดที่เลือกไว้แล้วหรือไม่ (ใช้ตัดสินว่าจะลากย้าย)
        clicked_on_selected = False
        if self.selected_vertices and match.isValid():
            tol_sq = (self._canvas.mapUnitsPerPixel() * 5) ** 2
            for v in self.selected_vertices:
                if v['pt'].sqrDist(self.drag_start_pt) < tol_sq:
                    clicked_on_selected = True
                    break

        if self.selected_vertices and clicked_on_selected and not self.armed:
            # โหมดหลายหมุด: คลิกโดนหมุดที่เลือกไว้ -> ลากย้าย (กด/ไม่กด Shift ก็ได้)
            self._remove_guide()
            self.is_moving = True
            self.drag_band = QgsRubberBand(self._canvas, QgsWkbTypes.LineGeometry)
            self.drag_band.setColor(QtGui.QColor(0, 0, 255))
            self.drag_band.setWidth(2)
        else:
            # เริ่มกล่องเลือก (คลิก = จุดเดียว+arm, Shift+ลาก = ครอบหลายจุด)
            # ถ้ากำลัง armed อยู่แล้วมากดเริ่ม gesture ใหม่ (เช่น Shift+ลาก) -> ปลด armed + เส้นนำ
            if self.armed:
                self.armed = False
                self._remove_guide()
            self.is_moving = False
            self.box_band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
            self.box_band.setColor(QtGui.QColor(0, 120, 255))
            self.box_band.setFillColor(QtGui.QColor(0, 120, 255, 40))
            self.box_band.setWidth(1)

    def canvasMoveEvent(self, e):
        match = self._canvas.snappingUtils().snapToMap(e.pos())
        cur = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        if match.isValid():
            self.snap_marker.setCenter(cur)
            self.snap_marker.show()
        else:
            self.snap_marker.hide()

        # โหมด armed (คลิกเดี่ยว): ลากเส้นนำจากจุดอ้างอิงไปเมาส์ (มาร์กเกอร์อยู่กับที่ บอกว่าเลือกอะไร)
        if self.armed and self.move_anchor is not None:
            if self.move_guide is None:
                self.move_guide = QgsRubberBand(self._canvas, QgsWkbTypes.LineGeometry)
                self.move_guide.setColor(QtGui.QColor(0, 0, 255))
                self.move_guide.setWidth(2)
            self.move_guide.setToGeometry(
                QgsGeometry.fromPolylineXY([self.move_anchor, cur]), None)
            return

        if self.drag_start_pt is None:
            return

        if self.is_moving and self.drag_band:
            self.drag_band.setToGeometry(QgsGeometry.fromPolylineXY([self.drag_start_pt, cur]), None)
            # ขยับ Marker ตามเมาส์ให้เห็นภาพ
            dx = cur.x() - self.drag_start_pt.x()
            dy = cur.y() - self.drag_start_pt.y()
            for v in self.selected_vertices:
                if v['marker']:
                    v['marker'].setCenter(QgsPointXY(v['pt'].x() + dx, v['pt'].y() + dy))
        elif not self.is_moving and self.box_band:
            self.box_band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self.drag_start_pt, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_selection()
            iface.actionSelect().trigger()
            return

        if e.button() != QtCore.Qt.LeftButton:
            return

        match = self._canvas.snappingUtils().snapToMap(e.pos())
        cur = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        # ===== โหมดคลิกเดี่ยว: คลิกปลายทาง = ย้ายหมุดที่เลือกไว้ =====
        if self._placing:
            self._placing = False
            if self.armed and self.move_anchor is not None and self.selected_vertices:
                dx = cur.x() - self.move_anchor.x()
                dy = cur.y() - self.move_anchor.y()
                if abs(dx) > 1e-6 or abs(dy) > 1e-6:
                    if self.plugin._movenodes_execute(self.selected_vertices, dx, dy):
                        self._clear_selection()
                        iface.messageBar().pushInfo(
                            "Move Node", "ย้ายหมุดสำเร็จ — คลิกหมุดถัดไปเพื่อย้ายต่อ หรือคลิกขวาเพื่อเสร็จสิ้น")
                    # ถ้า execute ล้มเหลว -> คงสถานะ armed ไว้ ให้คลิกย้ายใหม่ได้
                else:
                    # คลิกที่เดิม -> ยกเลิกการเลือก
                    self._clear_selection()
            self.drag_start_pt = None
            return

        if self.drag_start_pt is None:
            return

        if self.is_moving:
            # ===== โหมด Shift: ปล่อยเมาส์หลังลากย้าย -> Execute =====
            dx = cur.x() - self.drag_start_pt.x()
            dy = cur.y() - self.drag_start_pt.y()

            if abs(dx) > 1e-6 or abs(dy) > 1e-6:
                if self.plugin._movenodes_execute(self.selected_vertices, dx, dy):
                    self._clear_selection()
                    iface.messageBar().pushInfo("Move Node", "ย้ายหมุดสำเร็จ — Shift+ลากเลือกหมุดอื่นต่อได้ หรือคลิกขวาเพื่อเสร็จสิ้น")
            else:
                # ไม่ได้ลาก แค่คลิกเฉยๆ -> ถ้าคลิกพื้นที่ว่าง ให้ล้าง selection
                if not match.isValid():
                    self._clear_selection()

            self.drag_start_pt = None
            if self.drag_band:
                try:
                    self._canvas.scene().removeItem(self.drag_band)
                except:
                    pass
                self.drag_band = None

            self.is_moving = False

        else:
            # ===== เลือกหมุด: คลิกจุดเดียว = arm คลิกย้าย / ลากกล่อง = หลายหมุด (ลากย้าย) =====
            shift = bool(e.modifiers() & QtCore.Qt.ShiftModifier)
            raw = QgsRectangle(self.drag_start_pt, cur)
            self.drag_start_pt = None
            if self.box_band:
                try:
                    self._canvas.scene().removeItem(self.box_band)
                except:
                    pass
                self.box_band = None

            # คลิกเฉยๆ (กล่องเล็กมาก) = เลือกจุดเดียว ; ลากจริง = กล่องครอบหลายจุด
            tol = self._canvas.mapUnitsPerPixel() * 5
            is_click = raw.width() < tol * 2 and raw.height() < tol * 2
            rect = (QgsRectangle(cur.x() - tol, cur.y() - tol, cur.x() + tol, cur.y() + tol)
                    if is_click else raw)

            # Shift = สะสมเพิ่มจากการเลือกเดิม ; ไม่กด = เลือกใหม่ (แทนที่)
            self._select_vertices_in_rect(rect, add_mode=shift)

            if (not shift) and is_click and self.selected_vertices:
                # คลิกจุดเดียว -> โหมดคลิกย้าย (armed)
                self.armed = True
                self.move_anchor = QgsPointXY(self.selected_vertices[0]['pt'])
                iface.messageBar().pushInfo(
                    "Move Node", "เลือกหมุดแล้ว — คลิกตำแหน่งใหม่เพื่อย้าย (คลิกขวา = ยกเลิก)")
            else:
                # ลากกล่อง / หลายหมุด -> ลากหมุดที่เลือกเพื่อย้าย (ไม่มีเส้นนำคลิกเดี่ยว)
                self.armed = False
                self._remove_guide()
                if self.selected_vertices:
                    iface.messageBar().pushInfo(
                        "Move Node", f"เลือก {len(self.selected_vertices)} หมุด — ลากหมุดที่เลือกเพื่อย้าย (Shift+ลาก = เลือกเพิ่ม)")

    def deactivate(self):
        self._clear_selection()
        if self.snap_marker:
            try:
                self._canvas.scene().removeItem(self.snap_marker)
            except:
                pass
        super().deactivate()


class _AdminNodeTool(AddNodeTool):
    """ฐานของเครื่องมือผู้ดูแล: ใช้ flow เดียวกับ Add Node (คลิกแปลง -> คลิก node)
    ต่างที่ (ก) ไม่บล็อกแปลง L1 (แอดมินแตะได้ทุกประเภทตามที่ตกลง)
            (ข) ตอนคลิกที่หมุด เรียก action ของตัวเองแทนการเพิ่ม node"""
    TITLE = "Admin"
    HINT  = "เลือกแปลงแล้ว • คลิกที่หมุดของแปลงนี้"

    def _toggle(self, feat):
        # แอดมิน: เลือกได้ทุกประเภทรวม L1-RTK/L1-TS (ไม่มีด่านกันแบบ Add Node)
        fid = feat.id()
        already = bool(self.picked) and self.picked[0][0] == fid
        self._clear_highlights()
        if already:
            iface.messageBar().pushInfo(self.TITLE, "ยกเลิกเลือกแปลง — คลิกเลือกแปลงใหม่ได้")
            return
        self.picked = [(fid, self._add_highlight(feat))]
        iface.messageBar().pushInfo(self.TITLE, self.HINT)

    def _do_action(self, fid, pt_xy):
        raise NotImplementedError

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._cancel()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        map_pt = self.toMapCoordinates(event.pos())
        pt_xy, _map_xy = self._nearest_marker(map_pt)
        if pt_xy is not None:
            if not self.picked:
                iface.messageBar().pushMessage(
                    self.TITLE, "เลือกแปลงก่อน แล้วค่อยคลิกที่หมุด", level=1, duration=5)
                return
            if self._do_action(self.picked[0][0], pt_xy):
                # รูปแปลงอาจเปลี่ยน (กรณีลบ node) -> อัปเดตไฮไลต์
                for fid, rb in self.picked:
                    feat = self.poly_lyr.getFeature(fid)
                    if feat.isValid():
                        rb.setToGeometry(feat.geometry(), self.poly_lyr)
                self._canvas.refresh()
        else:
            feat = self._poly_at(map_pt)
            if feat is None:
                iface.messageBar().pushMessage(
                    self.TITLE, "ไม่พบแปลง/หมุดตรงนี้ — คลิกในแปลง หรือเลื่อนให้ snap ติดหมุด",
                    level=1, duration=4)
                return
            self._toggle(feat)


class RenameNodeTool(_AdminNodeTool):
    """แอดมิน: คลิกแปลง -> คลิกหมุดของแปลงนั้น -> แก้ชื่อ (BND_NAME)"""
    TITLE = "แก้ชื่อหมุด"
    HINT  = "เลือกแปลงแล้ว • คลิกที่หมุดของแปลงนี้เพื่อแก้ชื่อ"

    def _do_action(self, fid, pt_xy):
        return self.plugin._rename_node_execute(self.poly_lyr, fid, pt_xy)


class DeleteNodeTool(_AdminNodeTool):
    """แอดมิน: คลิกแปลง -> คลิก node ของแปลงนั้น -> ลบมุมแปลง + หมุดของแปลงนั้นพร้อมกัน
    (ตรงข้ามกับ Add Node — กติกาเหล็กจึงคงอยู่เอง ไม่เกิดมุมเปลือย)"""
    TITLE = "ลบ node"
    HINT  = "เลือกแปลงแล้ว • คลิกที่ node/หมุดของแปลงนี้เพื่อลบ"

    def _do_action(self, fid, pt_xy):
        return self.plugin._delete_node_execute(self.poly_lyr, fid, pt_xy)
