"""
QGIS Map Tools for Multi-Layer Edit Pro
"""
from qgis.core import (
    QgsProject, QgsFeatureRequest, QgsGeometry, QgsRectangle, 
    QgsWkbTypes, QgsCoordinateTransform, QgsPointXY, QgsCoordinateReferenceSystem,
    QgsSpatialIndex
)
from qgis.gui import QgsMapTool, QgsRubberBand, QgsVertexMarker
from qgis.PyQt import QtCore, QtGui
from qgis.utils import iface

class BoxSelectTool(QgsMapTool):
    """ลากกล่องเลือก point features (สะสมหลายรอบ); คลิกขวา=เสร็จ, Ctrl+ลาก=เอาออก, Esc=ยกเลิก"""

    def __init__(self, canvas, on_box, on_finish, on_cancel):
        super().__init__(canvas)
        self._canvas = canvas
        self._on_box = on_box
        self._on_finish = on_finish
        self._on_cancel = on_cancel
        self._start = None
        self._band = None
        self.setCursor(QtCore.Qt.CrossCursor)

    def canvasPressEvent(self, e):
        if e.button() != QtCore.Qt.LeftButton:
            return
        self._start = self.toMapCoordinates(e.pos())
        self._band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        self._band.setColor(QtGui.QColor(255, 0, 0, 60))
        self._band.setWidth(1)

    def canvasMoveEvent(self, e):
        if self._start is None or self._band is None:
            return
        cur = self.toMapCoordinates(e.pos())
        self._band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self._start, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_band(); self._start = None
            self._on_finish()
            return
        if e.button() == QtCore.Qt.LeftButton and self._start is not None:
            cur = self.toMapCoordinates(e.pos())
            rect = QgsRectangle(self._start, cur)
            self._clear_band(); self._start = None
            if rect.width() < 1e-9 and rect.height() < 1e-9:
                tol = self._canvas.mapUnitsPerPixel() * 6
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol, cur.x() + tol, cur.y() + tol)
            remove = bool(e.modifiers() & QtCore.Qt.ControlModifier)
            self._on_box(rect, remove)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._clear_band()
            self._on_cancel()

    def _clear_band(self):
        if self._band:
            try:
                self._canvas.scene().removeItem(self._band)
            except Exception:
                pass
            self._band = None

    def deactivate(self):
        self._clear_band()
        super().deactivate()


class PolygonPickTool(QgsMapTool):
    """cursor กากบาท + ไฮไลต์แปลงใต้เมาส์ (ก่อนคลิก) เป็นตัวช่วยตัดสินใจ
    คลิก = ส่ง feature กลับผ่าน click_cb ; เลื่อนเมาส์ = hover_cb"""

    def __init__(self, canvas, layer, click_cb, hover_cb):
        super().__init__(canvas)
        self._canvas = canvas
        self._layer = layer
        self._click_cb = click_cb
        self._hover_cb = hover_cb
        self._last_fid = None
        self._picked = False
        self.setCursor(QtCore.Qt.CrossCursor)
        # cache transform ครั้งเดียว (เดิมสร้างใหม่ทุก mouse-move ตอน hover)
        proj = QgsProject.instance()
        self._xform = None
        if layer.crs() != proj.crs():
            try:
                self._xform = QgsCoordinateTransform(proj.crs(), layer.crs(), proj)
            except Exception:
                self._xform = None

    def _feature_at(self, event):
        """หา feature ในเลเยอร์ที่เลือก ใต้ตำแหน่งเมาส์ (None ถ้าไม่มี)"""
        map_pt = self.toMapCoordinates(event.pos())   # CRS ของโปรเจกต์
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
            except Exception:
                pt = map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))

        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                pass
        
        req = QgsFeatureRequest().setFilterRect(rect)
        for f in self._layer.getFeatures(req):
            if f.geometry().intersects(gp):
                return f
        return None

    def canvasMoveEvent(self, event):
        # ไฮไลต์แปลงใต้เมาส์ (อัปเดตเฉพาะเมื่อเปลี่ยนแปลง)
        feat = self._feature_at(event)
        fid = feat.id() if feat is not None else None
        if fid == self._last_fid:
            return
        self._last_fid = fid
        self._hover_cb(feat, self._layer)

    def canvasReleaseEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        feat = self._feature_at(event)
        if feat is None:
            iface.messageBar().pushMessage(
                "DOL", "ไม่พบแปลงในเลเยอร์ที่เลือกตรงตำแหน่งที่คลิก ลองใหม่อีกครั้ง", level=1, duration=6)
            return
        self._picked = True
        self._click_cb(feat, self._layer)

    def deactivate(self):
        # ถ้าเลิกใช้เครื่องมือโดยไม่ได้คลิก -> ลบไฮไลต์ hover + ข้อความแนะนำที่ค้างอยู่
        if not self._picked:
            try:
                self._hover_cb(None, self._layer)
            except Exception:
                pass
            try:
                iface.messageBar().clearWidgets()
            except Exception:
                pass
        super().deactivate()


class AddNodeTool(QgsMapTool):
    """เพิ่ม node ให้แปลง + เพิ่มหมุด (ไม่ต้องคลิกขวา)
    - คลิกในแปลง = เลือก/เอาออก (ไฮไลต์เขียว, หลายแปลงได้)
    - เลื่อนเมาส์ใกล้หมุด = snap (วงกลมแดง) -> คลิกตอนนั้น = แทรก node เข้าทุกแปลงที่เลือก + เพิ่มหมุด
    - คลิกขวา / Esc = ยกเลิก"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.picked = []          # [(fid, rubberband)]
        self.setCursor(QtCore.Qt.CrossCursor)
        proj = QgsProject.instance()
        self._to_poly = (QgsCoordinateTransform(proj.crs(), poly_lyr.crs(), proj)
                         if poly_lyr.crs() != proj.crs() else None)
        self._to_pt = (QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj)
                       if point_lyr.crs() != proj.crs() else None)
        self._from_pt = (QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
                         if point_lyr.crs() != proj.crs() else None)
        # ตัวบอก snap = วงกลมแดงที่เด้งไปเกาะหมุดใกล้สุด
        self._snap_mk = QgsVertexMarker(canvas)
        self._snap_mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self._snap_mk.setColor(QtGui.QColor(255, 0, 0))
        self._snap_mk.setPenWidth(3)
        self._snap_mk.setIconSize(14)
        self._snap_mk.hide()
        # hover highlight แปลงใต้เมาส์ก่อนคลิก (เหลือง) เป็นตัวช่วยตัดสินใจ
        self._hover_rb = None
        self._hover_fid = None

    def _poly_at(self, map_pt):
        pt = self._to_poly.transform(map_pt) if self._to_poly else map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol, map_pt.x() + tol, map_pt.y() + tol)
        if self._to_poly is not None:
            try:
                rect = self._to_poly.transformBoundingBox(rect)
            except Exception:
                pass
        
        req = QgsFeatureRequest().setFilterRect(rect)
        for f in self.poly_lyr.getFeatures(req):
            if f.geometry().intersects(gp):
                return f
        return None

    def _nearest_marker(self, map_pt):
        """หาหมุดใกล้สุดในรัศมี snap -> (xy ใน CRS หมุด, xy ใน CRS แผนที่) หรือ (None, None)"""
        map_tol = max(self._canvas.mapUnitsPerPixel() * 12, 0.5)
        rect = QgsRectangle(map_pt.x() - map_tol, map_pt.y() - map_tol, map_pt.x() + map_tol, map_pt.y() + map_tol)
        if self._to_pt is not None:
            try:
                rect = self._to_pt.transformBoundingBox(rect)
            except Exception:
                pass
                
        best = None
        best_map = None
        bestd = map_tol * map_tol
            
        for f in self.point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes()):
            xy = f.geometry().asPoint()
            map_xy = self._from_pt.transform(xy) if self._from_pt else QgsPointXY(xy)
            d = (map_xy.x() - map_pt.x()) ** 2 + (map_xy.y() - map_pt.y()) ** 2
            if d <= bestd:
                bestd = d
                best = xy
                best_map = map_xy
        if best is None:
            return None, None
        return best, best_map

    def _add_highlight(self, feat):
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(0, 170, 0))
        rb.setFillColor(QtGui.QColor(0, 170, 0, 60))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        return rb

    def _toggle(self, feat):
        # กันชน: ห้ามเลือกแปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
        tp = self.plugin._poly_type_str(self.poly_lyr, feat)
        if tp in ("L1-RTK", "L1-TS"):
            iface.messageBar().pushMessage(
                "Add Node", f"แปลง {feat.id()} เป็น {tp} (พิกัดอ้างอิง) — ห้ามเพิ่ม node",
                level=2, duration=6)
            return
        # เลือกได้ทีละ 1 แปลง: คลิกแปลงใหม่ = แทนที่ • คลิกแปลงเดิมซ้ำ = ยกเลิก
        fid = feat.id()
        already = bool(self.picked) and self.picked[0][0] == fid
        self._clear_highlights()
        if already:
            iface.messageBar().pushInfo("Add Node", "ยกเลิกเลือกแปลง — คลิกเลือกแปลงใหม่ได้")
            return
        self.picked = [(fid, self._add_highlight(feat))]
        iface.messageBar().pushInfo(
            "Add Node", "เลือกแปลงแล้ว • เลื่อนไปที่หมุด (snap) แล้วคลิกเพื่อเพิ่ม node")

    def _set_hover(self, feat):
        """ไฮไลต์แปลงใต้เมาส์ (เหลือง) — ข้ามถ้าเป็นแปลงที่เลือกอยู่แล้ว (เขียว)"""
        fid = feat.id() if feat is not None else None
        if feat is not None and self.picked and self.picked[0][0] == fid:
            feat, fid = None, None
        if fid == self._hover_fid:
            return
        self._hover_fid = fid
        if self._hover_rb is not None:
            try:
                self._canvas.scene().removeItem(self._hover_rb)
            except Exception:
                pass
            self._hover_rb = None
        if feat is None:
            return
        # แปลงอ้างอิง L1-RTK/L1-TS = แดง (ห้ามเลือก) • ปกติ = เหลือง
        locked = self.plugin._poly_type_str(self.poly_lyr, feat) in ("L1-RTK", "L1-TS")
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        if locked:
            rb.setColor(QtGui.QColor(220, 0, 0))
            rb.setFillColor(QtGui.QColor(220, 0, 0, 45))
        else:
            rb.setColor(QtGui.QColor(255, 190, 0))
            rb.setFillColor(QtGui.QColor(255, 190, 0, 45))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        self._hover_rb = rb

    def canvasMoveEvent(self, event):
        if getattr(self, "_snap_mk", None) is None:
            return
        map_pt = self.toMapCoordinates(event.pos())
        _pt, map_xy = self._nearest_marker(map_pt)
        if map_xy is not None:
            self._snap_mk.setCenter(QgsPointXY(map_xy))
            self._snap_mk.show()
            self._set_hover(None)        # อยู่บนหมุด -> ไม่ต้อง hover แปลง
        else:
            self._snap_mk.hide()
            self._set_hover(self._poly_at(map_pt))

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._cancel()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        map_pt = self.toMapCoordinates(event.pos())
        pt_xy, _map_xy = self._nearest_marker(map_pt)
        if pt_xy is not None:
            # snap ติดหมุด -> วาง node (ต้องเลือกแปลงไว้ก่อน)
            if not self.picked:
                iface.messageBar().pushMessage(
                    "Add Node", "เลือกแปลงก่อน แล้วค่อยคลิกที่หมุด", level=1, duration=5)
                return
            fids = [f for f, _ in self.picked]
            if self.plugin._addnode_execute(self.poly_lyr, fids, pt_xy):
                # อัปเดตไฮไลต์แปลงเพื่อโชว์ node ใหม่ที่เพิ่งเพิ่มเข้าไป
                for fid, rb in self.picked:
                    feat = self.poly_lyr.getFeature(fid)
                    if feat.isValid():
                        rb.setToGeometry(feat.geometry(), self.poly_lyr)
                self._canvas.refresh()
                iface.messageBar().pushInfo("Add Node", "เพิ่มหมุดสำเร็จ — สามารถคลิกเพิ่มหมุดอื่นต่อได้เลย หรือคลิกขวาเพื่อเสร็จสิ้น")
        else:
            # ไม่ติดหมุด -> เลือก/เอาแปลงออก
            feat = self._poly_at(map_pt)
            if feat is None:
                iface.messageBar().pushMessage(
                    "Add Node", "ไม่พบแปลง/หมุดตรงนี้ — คลิกในแปลง หรือเลื่อนให้ snap ติดหมุด",
                    level=1, duration=4)
                return
            self._toggle(feat)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._cancel()

    def _clear_highlights(self):
        for _fid, rb in self.picked:
            try:
                self._canvas.scene().removeItem(rb)
            except Exception:
                pass
        self.picked = []

    def _remove_snap(self):
        if getattr(self, "_snap_mk", None) is not None:
            try:
                self._canvas.scene().removeItem(self._snap_mk)
            except Exception:
                pass
            self._snap_mk = None

    def _finish(self):
        self._canvas.refresh()
        iface.actionSelect().trigger()   # -> deactivate() ล้าง highlight/snap

    def _cancel(self):
        try:
            iface.messageBar().clearWidgets()
        except Exception:
            pass
        iface.actionSelect().trigger()

    def deactivate(self):
        self._clear_highlights()
        self._set_hover(None)
        self._remove_snap()
        super().deactivate()



class SyncVertexTool(QgsMapTool):
    """เลือกและเลื่อนหมุดหลายเลเยอร์พร้อมกัน
    - คลิกเพื่อเลือกหมุดเดียว, ลากกล่องเพื่อเลือกหลายหมุด
    - คลิกค้างที่พื้นที่ว่างหรือหมุดที่เลือก แล้วลากเพื่อย้าย
    - คลิกขวาหรือกด Esc เพื่อยกเลิก"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.setCursor(QtCore.Qt.CrossCursor)
        
        self.selected_vertices = [] # [{'layer': lyr, 'fid': id, 'vidx': idx, 'pt': QgsPointXY, 'marker': QgsVertexMarker}]
        self.picked = [] # list of (fid, rubberband)
        self.drag_start_pt = None
        self.box_band = None
        self.drag_band = None
        self.is_moving = False
        
        self.snap_marker = QgsVertexMarker(self._canvas)
        self.snap_marker.setIconType(QgsVertexMarker.ICON_CROSS)
        self.snap_marker.setColor(QtGui.QColor(255, 0, 255))
        self.snap_marker.setPenWidth(2)
        self.snap_marker.hide()

    def _clear_selection(self):
        for v in self.selected_vertices:
            if v.get('marker'):
                try:
                    self._canvas.scene().removeItem(v['marker'])
                except Exception:
                    pass
        self.selected_vertices = []
        if self.box_band:
            try:
                self._canvas.scene().removeItem(self.box_band)
            except Exception:
                pass
            self.box_band = None
        if self.drag_band:
            try:
                self._canvas.scene().removeItem(self.drag_band)
            except Exception:
                pass
            self.drag_band = None
            
    def _add_marker(self, pt):
        mk = QgsVertexMarker(self._canvas)
        mk.setIconType(QgsVertexMarker.ICON_BOX)
        mk.setColor(QtGui.QColor(255, 60, 0))
        mk.setFillColor(QtGui.QColor(255, 60, 0, 80))
        mk.setPenWidth(2)
        mk.setIconSize(10)
        mk.setCenter(pt)
        mk.show()
        return mk

    def _select_vertices_in_rect(self, rect, add_mode=False):
        if not add_mode:
            self._clear_selection()
        
        has_blocked = False
            
        # ฟังก์ชันเช็คหมุดซ้ำ
        def is_duplicate(lyr, fid, vidx):
            for v in self.selected_vertices:
                if v['layer'].id() == lyr.id() and v['fid'] == fid and v['vidx'] == vidx:
                    return True
            return False
            
        proj = QgsProject.instance()
        
        # ค้นหาใน point_lyr
        if self.point_lyr:
            to_pt = QgsCoordinateTransform(proj.crs(), self.point_lyr.crs(), proj) if self.point_lyr.crs() != proj.crs() else None
            from_pt = QgsCoordinateTransform(self.point_lyr.crs(), proj.crs(), proj) if self.point_lyr.crs() != proj.crs() else None
            try:
                pt_rect = to_pt.transformBoundingBox(rect) if to_pt else rect
            except:
                pt_rect = rect
            
            req = QgsFeatureRequest().setFilterRect(pt_rect)
            for f in self.point_lyr.getFeatures(req):
                g = f.geometry()
                if g.intersects(pt_rect):
                    map_pt = from_pt.transform(g.asPoint()) if from_pt else g.asPoint()
                    if self.poly_lyr:
                        is_locked, type_str = self.plugin._is_point_feature_locked(self.poly_lyr, f)
                        if is_locked:
                            has_blocked = True
                            continue
                    if not is_duplicate(self.point_lyr, f.id(), -1):
                        self.selected_vertices.append({
                            'layer': self.point_lyr, 'fid': f.id(), 'vidx': -1, 'pt': map_pt,
                            'marker': self._add_marker(map_pt)
                        })
                        
        # ค้นหาใน poly_lyr
        if self.poly_lyr:
            to_poly = QgsCoordinateTransform(proj.crs(), self.poly_lyr.crs(), proj) if self.poly_lyr.crs() != proj.crs() else None
            from_poly = QgsCoordinateTransform(self.poly_lyr.crs(), proj.crs(), proj) if self.poly_lyr.crs() != proj.crs() else None
            try:
                poly_rect = to_poly.transformBoundingBox(rect) if to_poly else rect
            except:
                poly_rect = rect
                
            req = QgsFeatureRequest().setFilterRect(poly_rect)
            selected_poly_ids = self.poly_lyr.selectedFeatureIds()
            for f in self.poly_lyr.getFeatures(req):
                # ถ้ามีแปลงที่ถูก select อยู่ ให้ย้ายได้แค่แปลงที่ถูก select เท่านั้น
                if selected_poly_ids and f.id() not in selected_poly_ids:
                    continue
                # กันชน: ห้ามเลือก L1-RTK / L1-TS
                tp = self.plugin._poly_type_str(self.poly_lyr, f)
                if tp in ("L1-RTK", "L1-TS"):
                    has_blocked = True
                    continue
                g = f.geometry()
                # ต้องหาทุก vertex ที่อยู่ใน poly_rect
                for vidx, vpt in enumerate(g.vertices()):
                    vpt_xy = QgsPointXY(vpt.x(), vpt.y())
                    if poly_rect.contains(vpt_xy):
                        map_pt = from_poly.transform(vpt_xy) if from_poly else vpt_xy
                        if not is_duplicate(self.poly_lyr, f.id(), vidx):
                            self.selected_vertices.append({
                                'layer': self.poly_lyr, 'fid': f.id(), 'vidx': vidx, 'pt': map_pt,
                                'marker': self._add_marker(map_pt)
                            })
                            
        if has_blocked:
            self.plugin.iface.messageBar().pushMessage(
                "MLEP Guard", "หมุดหรือแปลงอ้างอิง L1-RTK / L1-TS ถูกข้ามเพื่อป้องกันการแก้ไข!",
                level=1, duration=5
            )
        elif self.selected_vertices:
            iface.messageBar().pushInfo("Move Node", f"เลือก {len(self.selected_vertices)} หมุดแล้ว ลากเมาส์เพื่อย้ายพิกัด")
        else:
            iface.messageBar().pushInfo("Move Node", "ไม่พบหมุดในบริเวณที่คลิก กรุณาลองใหม่")

    def canvasPressEvent(self, e):
        if e.button() != QtCore.Qt.LeftButton:
            return

        if self.is_moving:
            return

        match = self._canvas.snappingUtils().snapToMap(e.pos())
        self.drag_start_pt = match.point() if match.isValid() else self.toMapCoordinates(e.pos())
        
        # เช็คว่าคลิกโดนหมุดที่เลือกไว้แล้วหรือไม่ (เพื่อลากย้าย)
        clicked_on_selected = False
        if self.selected_vertices and match.isValid():
            tol_sq = (self._canvas.mapUnitsPerPixel() * 5) ** 2
            for v in self.selected_vertices:
                if v['pt'].sqrDist(self.drag_start_pt) < tol_sq:
                    clicked_on_selected = True
                    break

        if self.selected_vertices and clicked_on_selected:
            # มีหมุดถูกเลือกอยู่แล้ว และคลิกโดนหมุดที่เลือก -> พร้อมย้าย
            self.is_moving = True
            self.drag_band = QgsRubberBand(self._canvas, QgsWkbTypes.LineGeometry)
            self.drag_band.setColor(QtGui.QColor(0, 0, 255))
            self.drag_band.setWidth(2)
        else:
            # ไม่โดนหมุด หรือโดนหมุดอื่นที่ไม่ได้เลือก -> เริ่มวาดกล่องใหม่ (สะสม)
            self.is_moving = False
            self.box_band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
            self.box_band.setColor(QtGui.QColor(0, 120, 255))
            self.box_band.setFillColor(QtGui.QColor(0, 120, 255, 40))
            self.box_band.setWidth(1)

    def canvasMoveEvent(self, e):
        match = self._canvas.snappingUtils().snapToMap(e.pos())
        cur = match.point() if match.isValid() else self.toMapCoordinates(e.pos())
        
        if match.isValid():
            self.snap_marker.setCenter(cur)
            self.snap_marker.show()
        else:
            self.snap_marker.hide()
            
        if self.drag_start_pt is None:
            return
            
        if self.is_moving and self.drag_band:
            self.drag_band.setToGeometry(QgsGeometry.fromPolylineXY([self.drag_start_pt, cur]), None)
            # ขยับ Marker ตามเมาส์ให้เห็นภาพ
            dx = cur.x() - self.drag_start_pt.x()
            dy = cur.y() - self.drag_start_pt.y()
            for v in self.selected_vertices:
                if v['marker']:
                    v['marker'].setCenter(QgsPointXY(v['pt'].x() + dx, v['pt'].y() + dy))
        elif not self.is_moving and self.box_band:
            self.box_band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self.drag_start_pt, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_selection()
            iface.actionSelect().trigger()
            return

        if e.button() != QtCore.Qt.LeftButton or self.drag_start_pt is None:
            return

        match = self._canvas.snappingUtils().snapToMap(e.pos())
        cur = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        if self.is_moving:
            # ผู้ใช้ปล่อยเมาส์หลังลากย้าย -> สั่ง Execute!
            dx = cur.x() - self.drag_start_pt.x()
            dy = cur.y() - self.drag_start_pt.y()

            if abs(dx) > 1e-6 or abs(dy) > 1e-6:
                if self.plugin._movenodes_execute(self.selected_vertices, dx, dy):
                    self._clear_selection()
                    iface.messageBar().pushInfo("Move Node", "ย้ายหมุดสำเร็จ — สามารถเลือกหมุดอื่นต่อได้ หรือคลิกขวาเพื่อเสร็จสิ้น")
            else:
                # ไม่ได้ลาก แค่คลิกเฉยๆ
                # ถ้ายกเลิกโดยคลิกพื้นที่ว่าง ให้ล้าง selection
                if not match.isValid():
                    self._clear_selection()

            self.drag_start_pt = None
            if self.drag_band:
                try:
                    self._canvas.scene().removeItem(self.drag_band)
                except:
                    pass
                self.drag_band = None

            self.is_moving = False

        else:
            # ผู้ใช้ปล่อยเมาส์หลังลากกล่อง -> ค้นหาหมุด
            rect = QgsRectangle(self.drag_start_pt, cur)
            self.drag_start_pt = None
            if self.box_band:
                try:
                    self._canvas.scene().removeItem(self.box_band)
                except:
                    pass
                self.box_band = None

            # แก้ปัญหามือสั่น (คลิกเฉยๆ แต่เมาส์เลื่อนนิดเดียว)
            tol = self._canvas.mapUnitsPerPixel() * 5
            if rect.width() < tol * 2 and rect.height() < tol * 2:
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol, cur.x() + tol, cur.y() + tol)
                
            # วาดกล่อง/คลิกเพิ่ม จะบังคับเป็นโหมดสะสม (add_mode=True) เสมอ เพื่อหลีกเลี่ยงบั๊กปุ่มค้าง
            self._select_vertices_in_rect(rect, add_mode=True)

    def deactivate(self):
        self._clear_selection()
        if self.snap_marker:
            try:
                self._canvas.scene().removeItem(self.snap_marker)
            except:
                pass
        super().deactivate()
