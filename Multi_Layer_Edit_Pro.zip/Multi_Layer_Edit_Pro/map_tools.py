"""
QGIS Map Tools for Multi-Layer Edit Pro
"""
import math
import time

from qgis.core import (
    QgsProject, QgsFeatureRequest, QgsGeometry, QgsRectangle,
    QgsWkbTypes, QgsCoordinateTransform, QgsPointXY, QgsUnitTypes,
    QgsDistanceArea
)
from qgis.gui import (QgsMapTool, QgsRubberBand, QgsVertexMarker,
                      QgsMapCanvasItem, QgsSnapIndicator)
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.utils import iface

from .lock_rules import L1_TYPES     # ★ 2.4.0 (review DU-01) — กติกาล็อก L1 ที่เดียว (ไม่ import main ⇒ ไม่วน)

class NodeSelectionDialog(QtWidgets.QDialog):
    def __init__(self, candidates, parent=None, multi_select=False):
        super().__init__(parent)
        self.setWindowTitle("พบวัตถุซ้อนทับกัน โปรดเลือก")
        self.setWindowModality(QtCore.Qt.WindowModal)
        self.resize(400, 250)
        self.multi_select = multi_select
        # ★ rc2 (audit A1-09) — ชื่อ _lay (เดิม self.layout บังเมธอด QWidget.layout() ของตัวเอง ⇒ dlg.layout() พัง)
        self._lay = QtWidgets.QVBoxLayout(self)
        self._lay.addWidget(QtWidgets.QLabel("พบวัตถุหลายชิ้นซ้อนทับกัน กรุณาเลือก:"))
        self.list_widget = QtWidgets.QListWidget()
        if not multi_select:
            self.list_widget.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        for c in candidates:
            text = f"[{'หมุด' if c.get('layer_type') == 'point' else 'แปลง'}] "
            text += f"{c.get('name', 'ไม่มีชื่อ')} (UTM: {c.get('utm', '?')}) [ID: {c.get('id', '?')}]"
            if c.get('dates'):          # ★ 2.3.7 (audit F4) วันที่ของหมุด — ผู้เรียกใส่มาเมื่อชั้นมีคอลัมน์วันที่
                text += f"  ·  {c['dates']}"
            item = QtWidgets.QListWidgetItem(text)
            if multi_select:
                item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
                item.setCheckState(QtCore.Qt.Checked)
            item.setData(QtCore.Qt.UserRole, c)
            self.list_widget.addItem(item)
        if not multi_select and self.list_widget.count() > 0:
            self.list_widget.setCurrentRow(0)
        self._lay.addWidget(self.list_widget)
        self.btn_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        self.btn_box.accepted.connect(self.accept)
        self.btn_box.rejected.connect(self.reject)
        self._lay.addWidget(self.btn_box)

    def get_selected(self):
        selected = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if self.multi_select:
                if item.checkState() == QtCore.Qt.Checked:
                    selected.append(item.data(QtCore.Qt.UserRole))
            else:
                if item.isSelected():
                    selected.append(item.data(QtCore.Qt.UserRole))
        return selected

def _canvas_is_metres(canvas):
    """แคนวาสคิดระยะเป็นเมตรหรือไม่

    ★ 31 ส.ค. 69 — ค่าคงที่ที่เขียนเป็น "เมตร" (เพดาน/พื้นของรัศมีค้นหา) ใช้ได้
    เฉพาะเมื่อ CRS ของ *โปรเจกต์* มีหน่วยเป็นเมตร. Khlongluang_V2 ตั้ง projectCrs
    เป็น EPSG:4326 ทั้งที่ทุกเลเยอร์เป็น EPSG:24047 -> mapUnitsPerPixel() คืนค่า
    เป็นองศา ค่าคงที่เมตรจึงกลายเป็นองศาแล้วบานเป็นกิโลเมตร
    """
    try:
        return (canvas.mapSettings().destinationCrs().mapUnits()
                == QgsUnitTypes.DistanceMeters)
    except Exception:
        return False


def _utm_key(v):
    """★ 2.4.0 (review DI-08-leftover) — คีย์ UTM สำหรับเทียบหมุดกับแปลงในเครื่องมือบนแผนที่ (ตัวเดียวกับ main.py)
    _txt (NULL/None/คำว่า 'NULL' = ว่าง · ตัดช่องว่าง) แล้ว _norm_utm (ตัด .0 ท้ายของคีย์ที่อ่านเป็นทศนิยม เช่น '1234.0' → '1234')
    ★ rc1 (F8 · §5.1 DI-08) ตัวอย่างเดิม (คีย์ 18 หลัก + .0) ไม่จริง: double เก็บเลขเต็มได้แม่นแค่ ~15–16 หลัก ⇒ คีย์ ≥ 1e16 ในคอลัมน์
    ทศนิยมเพี้ยนตั้งแต่อ่านจาก provider (ข้อจำกัดเดิม P3 — คอลัมน์ UTM ของกรมเป็นข้อความ) ตัด .0 ช่วยได้เฉพาะคีย์ที่ยังแม่นอยู่
    · ว่าง = "" (ไม่ตรงคีย์ใด — ผู้เรียกตัด "" ออกจากชุดของแปลงเอง) · เดิมเทียบ str()/_txt ตรง ๆ ⇒ '1234.0' ≠ '1234' ทั้งที่ main.py ถือว่าตรง
    import ในฟังก์ชัน เพราะ main.py เป็นฝั่งที่ import โมดูลนี้ (กัน circular import)"""
    from .main import _txt, _norm_utm
    s = _txt(v)
    return _norm_utm(s) if s else ""


def azimuth(a, b):
    """อาซิมุทจาก a ไป b — องศา นับจากทิศเหนือ วนตามเข็ม (0-360)

    ใช้ระบบเดียวกับงานรังวัด (เหนือ=0 ตะวันออก=90) ไม่ใช่ atan2 แบบคณิตศาสตร์
    """
    import math as _m
    dx = b.x() - a.x()
    dy = b.y() - a.y()
    return _m.degrees(_m.atan2(dx, dy)) % 360.0


# ★ 2.3.7 (audit F1 · P1) — Backspace/Delete ระหว่างใช้เครื่องมือของ MLEP
_DEL_KEYS = (QtCore.Qt.Key_Backspace, QtCore.Qt.Key_Delete)
DEL_KEY_INFO = ("ปุ่ม Delete/Backspace ใช้ไม่ได้ระหว่างใช้เครื่องมือของ MLEP "
                "(กันลบแปลง/หมุดที่เลือกค้างไว้โดยไม่ตั้งใจ)")


def _eat_del_key(tool, e, back=None):
    """★ 2.3.7 (audit F1 · P1) — "กิน" Backspace/Delete ของเครื่องมือ · คืน True = เป็นคีย์นี้ (ผู้เรียกจบได้เลย)
    เดิม Move Node · Add Node/แก้ชื่อหมุด/ลบ Node/สลับหมุด · ℹ️/DOL/🍩/📝 · กรอบเลือกหมุดของ Align ไม่ ignore() คีย์นี้
    ⇒ QgsMapCanvas ยิง keyPressed ต่อ ⇒ QgisApp::mapCanvas_keyPressed สั่ง deleteSelected() กับชั้นที่ active
    = ลบแปลง/หมุดที่เลือกค้างไว้ทั้งดวง (3.40.6 ถามก่อน แต่ Enter/Yes = ลบ · ↺ ของปลั๊กอินคืนไม่ได้ · ผู้ตรวจ p08 หมุด 8→4)
    ignore() = "เครื่องมือกินคีย์แล้ว" (กติกากลับด้านของ QGIS — ดู DrawLineTool._กินคีย์)
    back() คืน True = ใช้คีย์เป็น "ถอย" ของเครื่องมือแล้ว · ไม่มี/คืน False ⇒ บอกสั้น ๆ (ระดับ 1 = เหลือง) ไม่เกิน 1 ครั้งต่อ 4 วินาที"""
    try:
        if e.key() not in _DEL_KEYS:
            return False
    except Exception:
        return False
    try:
        e.ignore()
    except Exception:
        pass
    done = False
    if back is not None:
        try:
            done = bool(back())
        except Exception:
            done = False
    if not done:
        import time
        now = time.monotonic()
        last = getattr(tool, "_del_info_t", None)
        if last is None or now - last >= 4.0:
            tool._del_info_t = now
            # ★ 2.3.7 b17 (audit R2-D3) — เป็นการปฏิเสธ ⇒ เหลือง ตามกติกาสีของเจ้าของงาน (ฟ้า = ทำแล้วยังไม่บันทึก · เดิมระดับ 0)
            _bar_push_own(tool, "MLEP", DEL_KEY_INFO, 1, 4)
    return True


class _MlepKeys:
    """★ 2.3.7 (audit F1) — mixin ของเครื่องมือบนแผนที่ทุกตัวของ MLEP: Backspace/Delete ไม่ถึงมือ QGIS เลยระหว่างใช้เครื่องมือ
    QgsMapCanvas ส่งคีย์ให้ keyPressEvent ของเครื่องมือเฉพาะตอนไม่มีปุ่มเมาส์ค้าง — ระหว่างลาก (กล่องเลือก · ลากหมุดของ Move Node
    · กดปุ่มกลาง/Space เลื่อนแผนที่) แคนวาสยิง keyPressed ตรง ⇒ QGIS ลบฟีเจอร์ที่เลือกไว้ แม้เครื่องมือ ignore() ก็ตาม
    (ทดลองกับ QgsMapCanvas จริง: ปุ่มเมาส์ค้าง ⇒ เครื่องมือไม่เห็นคีย์ · keyPressed ยิงพร้อม isAccepted = True)
    ⇒ ตอนเครื่องมือทำงานอยู่ ติดตัวกรองเหตุการณ์บนแคนวาส: Backspace/Delete ส่งเข้า keyPressEvent ของเครื่องมือเอง (ถอย/บอก)
      แล้ว "กิน" ไว้ (แคนวาสไม่เห็นคีย์นี้ ⇒ ไม่มี keyPressed) · คีย์อื่นผ่านตามเดิม · เลิกใช้เครื่องมือ = ถอดตัวกรอง
    ใส่ไว้หน้าคลาสของ QGIS ในรายการฐาน (class X(_MlepKeys, QgsMapTool)) · activate/deactivate ของคลาสลูกต้องเรียก super()"""

    def activate(self):
        super().activate()
        try:
            self.canvas().installEventFilter(self)
        except Exception:
            pass
        self._xf_watch(True)

    def deactivate(self):
        self._xf_watch(False)
        try:
            self.canvas().removeEventFilter(self)
        except Exception:
            pass
        super().deactivate()

    # ★ rc1 2.4.0 (F8 · §5.1 DI-03) — ตัวแปลงพิกัดที่เครื่องมือสร้างไว้ตอนสร้างเครื่องมือ (AddNodeTool · PolygonPickTool ·
    #   DonutFrameTool · CreateParcelTool) ค้างค่าเดิมเมื่อเปลี่ยน CRS/วิธีแปลง datum ของโปรเจกต์ระหว่างเครื่องมือเปิดอยู่
    #   ⇒ เครื่องมือที่ทำงานอยู่ฟัง crsChanged / transformContextChanged ของโปรเจกต์ แล้วสร้างตัวแปลงใหม่ (_build_xforms)
    def _build_xforms(self):
        """สร้างตัวแปลงพิกัดของเครื่องมือ (คลาสลูกที่มีตัวแปลงเขียนทับ) · ฐาน = ไม่มีอะไร"""
        return None

    def _crs_redraw(self):
        """★ rc2 (audit A1-04) — ของบนจอที่เก็บพิกัดแผนที่ของ CRS เดิม (ไฮไลต์ · กากบาท · กรอบ) / แคชที่คีย์ไม่มี CRS
        ⇒ วาด/ล้างใหม่หลังเปลี่ยน CRS · ฐาน = ไม่มีอะไร (คลาสลูกเขียนทับ)"""
        return None

    def _xf_watch(self, on):
        try:
            prj = QgsProject.instance()
            if bool(on) == bool(getattr(self, "_xf_on", False)):
                return
            _sigs = [prj.crsChanged, prj.transformContextChanged]
            # ★ rc2 (audit A1-04) — CRS ของแคนวาสอาจเปลี่ยนหลัง crsChanged ของโปรเจกต์ ⇒ วาดใหม่อีกรอบตอนแคนวาสเปลี่ยน
            try:
                _sigs.append(self.canvas().destinationCrsChanged)
            except Exception:
                pass
            for sig in _sigs:
                try:
                    (sig.connect if on else sig.disconnect)(self._xf_rebuild)
                except Exception:
                    pass
            self._xf_on = bool(on)
            if on:
                self._xf_rebuild()          # เปลี่ยนไประหว่างเครื่องมือไม่ได้ทำงาน (deactivate → activate)
        except Exception:
            pass

    def _xf_rebuild(self, *_a):
        try:
            self._build_xforms()
        except Exception:
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage("เครื่องมือบนแผนที่: สร้างตัวแปลงพิกัดใหม่หลังเปลี่ยน CRS ไม่สำเร็จ", "MLEP", Qgis.Warning)
            except Exception:
                pass
        try:
            self._crs_redraw()              # ★ rc2 (audit A1-04)
        except Exception:
            pass

    def eventFilter(self, obj, ev):
        try:
            if ev.type() == QtCore.QEvent.KeyPress and ev.key() in _DEL_KEYS:
                # ★ 2.3.7 b17 (audit รอบ 2 · hardening) — ตัวกรองค้าง (deactivate ล้มก่อนถึง super() = ไม่ได้ถอด) ห้ามกินคีย์ของ
                #   เครื่องมืออื่น: เครื่องมือของ MLEP อยู่บนแคนวาสทั้ง session ⇒ Delete ของเครื่องมือ QGIS ถูกกินทั้ง session
                #   ⇒ ไม่ใช่เครื่องมือปัจจุบันของแคนวาสแล้ว = หลีกทาง (ปล่อยคีย์ผ่าน) + ถอดตัวเอง
                if not self._mlep_keys_own():
                    try:
                        obj.removeEventFilter(self)
                    except Exception:
                        pass
                    return False
                try:
                    self.keyPressEvent(ev)
                except Exception:
                    pass
                return True
        except Exception:
            pass
        return False

    def _mlep_keys_own(self):
        """★ 2.3.7 b17 — เครื่องมือนี้ยังเป็นเครื่องมือปัจจุบันของแคนวาสไหม (เทียบตัววัตถุ C++) · อ่านไม่ได้ ⇒ True (กินคีย์แบบเดิม)"""
        try:
            from qgis.PyQt import sip
            cur = self.canvas().mapTool()
            return cur is not None and sip.unwrapinstance(cur) == sip.unwrapinstance(self)
        except Exception:
            return True


class BoxSelectTool(_MlepKeys, QgsMapTool):
    """ลากกล่องเลือก point features (สะสมหลายรอบ); คลิกขวา=เสร็จ, Ctrl+ลาก=เอาออก, Esc=ยกเลิก"""

    def __init__(self, canvas, on_box, on_finish, on_cancel):
        super().__init__(canvas)
        self._canvas = canvas
        self._on_box = on_box
        self._on_finish = on_finish
        self._on_cancel = on_cancel
        self._start = None
        self._band = None
        self.setCursor(QtCore.Qt.CrossCursor)

    def canvasPressEvent(self, e):
        if e.button() != QtCore.Qt.LeftButton:
            return
        self._start = self.toMapCoordinates(e.pos())
        self._band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        self._band.setColor(QtGui.QColor(255, 0, 0, 60))
        self._band.setWidth(1)

    def canvasMoveEvent(self, e):
        if self._start is None or self._band is None:
            return
        cur = self.toMapCoordinates(e.pos())
        self._band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self._start, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_band(); self._start = None
            self._on_finish()
            return
        if e.button() == QtCore.Qt.LeftButton and self._start is not None:
            cur = self.toMapCoordinates(e.pos())
            rect = QgsRectangle(self._start, cur)
            self._clear_band(); self._start = None
            if rect.width() < 1e-9 and rect.height() < 1e-9:
                tol = self._canvas.mapUnitsPerPixel() * 6
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol, cur.x() + tol, cur.y() + tol)
            remove = bool(e.modifiers() & QtCore.Qt.ControlModifier)
            self._on_box(rect, remove)

    def keyPressEvent(self, e):
        if _eat_del_key(self, e):          # ★ 2.3.7 (audit F1) กรอบเลือกหมุดของ Align ไม่มีขั้นให้ถอย ⇒ บอกเฉย ๆ
            return
        if e.key() == QtCore.Qt.Key_Escape:
            self._clear_band()
            self._on_cancel()

    def _clear_band(self):
        if self._band:
            try:
                self._canvas.scene().removeItem(self._band)
            except Exception:
                pass
            self._band = None

    def deactivate(self):
        self._clear_band()
        super().deactivate()


_LOCK_UNKNOWN = object()        # ★ 2.3.7 (PF-01) — สแกนล็อก L1 ไม่สำเร็จในรอบนี้


def _bar_push_own(owner, title, text, level=0, duration=None):
    """★ 2.3.7 (review UX-01) — ดันข้อความแล้ว **จำไว้กับ owner** ⇒ ตอนเลิกใช้ลบเฉพาะของตัวเองได้ (_bar_pop_own)
    เดิมเครื่องมือเรียก messageBar().clearWidgets() = ล้างทั้งแถบ ⇒ คำเตือนที่ตั้งใจให้ค้าง (duration=0 เช่น
    '⚠️ มุมแปลงไม่มีหมุด' หลังบันทึก · ผลของ ลบ Node · ข้อความของปลั๊กอินอื่น) หายไปด้วยทุกครั้งที่คลิกขวา/Esc
    แบบเดียวกับ DonutFrameTool._push (2.3.6) แต่จำได้หลายข้อความ · duration=None = ค่าปริยายของ QGIS ตามระดับ
    (เท่ากับ pushInfo/pushMessage เดิม)"""
    bar = iface.messageBar()
    if duration is None:
        try:
            from qgis.gui import QgsMessageBar
            duration = QgsMessageBar.defaultMessageTimeout(level)
        except Exception:
            duration = 5 if level == 0 else 0
    try:
        from qgis.gui import QgsMessageBar
        item = QgsMessageBar.createMessage(title, text)
        bar.pushWidget(item, level, duration)
    except Exception:
        try:
            bar.pushMessage(title, text, level=level, duration=duration)
        except Exception:
            pass
        return None
    keep = list(getattr(owner, "_own_items", None) or [])
    try:
        from qgis.PyQt import sip
        keep = [i for i in keep if not sip.isdeleted(i)]       # ตัวที่หมดเวลาไปแล้ว ไม่ต้องจำ
    except Exception:
        pass
    keep.append(item)
    owner._own_items = keep
    return item


def _bar_pop_own(owner):
    """★ 2.3.7 (review UX-01) — เอาออกเฉพาะข้อความที่ owner ดันเอง (ตัวที่หมดเวลา/ถูกลบไปแล้ว ข้ามเงียบ ๆ)"""
    items = list(getattr(owner, "_own_items", None) or [])
    owner._own_items = []
    for it in items:
        try:
            iface.messageBar().popWidget(it)
        except Exception:
            pass


class _HoverPolyCache:
    """★ 2.4.0 (review PF-15) — แคชแปลงรอบเคอร์เซอร์ของทาง hover (PolygonPickTool · Add Node และเครื่องมือลูก)

    เดิม hover ถามชั้นแปลงทุก 80 มิลลิวินาที แม้เคอร์เซอร์ยังอยู่ในแปลงเดิม (PostGIS = server cursor บน UI thread ทุกครั้ง)
    ตอนนี้: คิวรีครั้งเดียวด้วยกรอบที่ขยายรอบเคอร์เซอร์ ≤ PAD_PX พิกเซล (request เดิมทุกอย่าง — ฟิลด์ · เพดาน — ต่างแค่กรอบ)
    เก็บ feature + กรอบของรูปไว้ แล้วตอบ tick ถัดไปในเครื่อง (ทดสอบ intersects กับรูปที่เก็บไว้ = เทียบรูปจริงแบบเดียวกับเดิม)
    จนกว่าจุดเคอร์เซอร์จะออกนอกกรอบที่ดึงไว้ · ยังคง throttle 80 มิลลิวินาทีเหมือนเดิม
    ★ 2.4.0 (review PF-07+PF-10+PF-15) — ใช้แคชเฉพาะตอนเคอร์เซอร์ช้า และขยายกรอบเท่าที่คาดว่าคุ้ม (_pad_px)
       เคอร์เซอร์เลื่อนเร็ว/ซูมออกจนแน่น = คิวรีกรอบเล็กแบบเดิมทุก tick (ไม่ดึงมากกว่าเดิม)

    🔑 ไม่ใช้ทางลัด "ยังอยู่ในแปลงที่ hover ล่าสุด" เพราะทำนายแปลงซ้อน/แปลงในแปลงผิด (เข้าแปลงในแล้วยังไฮไลต์แปลงนอก
       ⇒ ขัด DI-38 ที่ hover ต้องตรงกับที่คลิกจะได้) · แคชเก็บ "ทุกแปลง" ในกรอบ ⇒ กติกาเลือก (ตัวแรก/เนื้อที่เล็กสุด) ของผู้เรียกเหมือนเดิม
    🔑 ผลเท่ากับคิวรีสด: แปลงที่ครอบจุดเคอร์เซอร์มีกรอบของรูปครอบจุดนั้น ⇒ อยู่ในกรอบที่ดึงไว้แน่นอน
       · กรอบใหญ่ชนเพดาน (setLimit) = แคชไม่ครบ ⇒ ไม่ใช้แคช คิวรีสดแบบเดิม และเลิกขยายที่ระดับซูมนั้น
    🔑 ทิ้งแคชเมื่อชั้นเปลี่ยน (สัญญาณแก้ไข/undo/บันทึก/rollback ของชั้น · โหมดแก้ไข · ตัวกรองชั้น · ฟิลด์ที่ขอ) และอายุเกิน TTL_S วินาที
       (ของที่คนอื่นแก้ในฐานเห็นช้าสุด TTL_S วินาที) · คลิกยังคิวรีสดเสมอ (ไม่ผ่านแคชนี้)"""
    PAD_PX = 30
    TTL_S = 2.0
    # ★ 2.4.0 (review PF-07+PF-10+PF-15) — เดิมขยายกรอบ 30 px ทุกครั้งที่ออกนอกบริเวณ ⇒ เลื่อนเมาส์ปกติ/ซูมออก
    #   ดึงกรอบใหญ่ ~120 เท่าของพื้นที่เดิมทุกไม่กี่ tick (ชนเพดาน 200 = ทิ้งแล้วคิวรีเล็กซ้ำอีกรอบ) แพงกว่าเดิมมาก
    #   ⇒ ขยายเฉพาะตอนเคอร์เซอร์ "ช้า" (≤ SLOW_PX ต่อ tick) และขยายเท่าที่คาดว่าคุ้ม (ดู _pad_px)
    #   · เร็วกว่านั้น/เพิ่งเริ่ม/เพิ่งซูม = คิวรีกรอบเล็กแบบเดิมทุก tick (เหมือน 2.3.10 ทุกอย่าง)
    SLOW_PX = 6.0               # ขยับไม่เกินนี้ (พิกเซล) ต่อ tick = เล็ง/เดินอยู่ในแปลง
    BUDGET = 32                 # จำนวนแปลงที่ "คาดว่า" กรอบขยายจะดึงมา ไม่เกินนี้
    DENSE_S = 10.0              # ดึงเก็บแล้วชนเพดาน ⇒ ที่ซูมนั้นคิวรีสดแบบเดิมไปนานเท่านี้ (เลื่อนไปที่โล่งแล้วกลับมาใช้แคชได้)
    _SIGS = ("layerModified", "afterCommitChanges", "afterRollBack", "editingStarted", "editingStopped",
             "dataChanged", "subsetStringChanged")

    def __init__(self):
        self._lyr = None           # ★ 2.4.0 (review PF-07+PF-10+PF-15) — ชั้นที่ต่อสัญญาณ "ถูกแก้" ไว้
        self._gen = 0
        self.clear()

    def clear(self):
        self._key = None
        self._t = 0.0
        self._rect = None          # กรอบที่ดึงไว้ (พิกัดชั้น)
        self._feats = None         # [(feature, กรอบของรูป)] ตามลำดับที่ provider ส่ง
        self._prev = None          # ★ 2.4.0 (review PF-07+PF-10+PF-15) — (จุดเคอร์เซอร์บนแผนที่, mupp) ของ tick ก่อน
        self._slow = 0             # ★ จำนวน tick ติดกันที่เคอร์เซอร์ขยับ ≤ SLOW_PX (ต้อง ≥ 2 จึงดึงเก็บ — ไม่ใช่แค่ชะลอทีเดียว)
        self._stat = None          # ★ (ชั้น/ฟิลด์/mupp, ครึ่งกรอบ px, จำนวนแปลง, ขนาดแปลงกลาง px) ของการดึงครั้งล่าสุด
        self._dense = None         # ★ (ชั้น/ฟิลด์/mupp, เวลา) ที่การดึงเก็บเคยชนเพดาน ⇒ เลิกดึงเก็บที่ซูมนั้น DENSE_S วินาที

    def _bump(self, *a):
        """★ 2.4.0 (review PF-07+PF-10+PF-15) — ชั้นถูกแก้ (รวม undo/redo · บันทึก · rollback) ⇒ แคชเดิมใช้ไม่ได้
        เดิมใช้แค่ (undo index, undo count) เป็นคีย์ ⇒ undo แล้วแก้ใหม่ / บันทึกแล้วเปิดแก้ใหม่ ได้คู่เลขเดิมทั้งที่ข้อมูลต่าง"""
        self._gen += 1

    def _watch(self, layer):
        if self._lyr is layer:
            return
        self.release()
        for s in self._SIGS:
            try:
                getattr(layer, s).connect(self._bump)
            except Exception:
                pass
        self._lyr = layer

    def release(self):
        """★ 2.4.0 (review PF-07+PF-10+PF-15) — ถอดสัญญาณจากชั้น + ล้างแคช (เรียกตอนเลิกใช้เครื่องมือ)"""
        lyr, self._lyr = self._lyr, None
        if lyr is not None:
            for s in self._SIGS:
                try:
                    getattr(lyr, s).disconnect(self._bump)
                except Exception:
                    pass
        self._bump()
        self.clear()

    def _pad_px(self, d_px):
        """★ 2.4.0 (review PF-07+PF-10+PF-15) — ขยายกรอบกี่พิกเซล ให้ "แปลงที่ดึงต่อ tick" ไม่เกินคิวรีกรอบเล็กแบบเดิม
        ประมาณจากการดึงครั้งล่าสุดที่ซูมเดียวกัน: n0 แปลงในกรอบครึ่งกว้าง h0 px · ขนาดแปลงกลาง s px
        ⇒ กรอบครึ่งกว้าง h ได้ราว n0·((2h+s)/(2h0+s))² แปลง และเคอร์เซอร์ที่ขยับ d px/tick อยู่ในกรอบราว h/d tick
        เลือก pad มากสุด (≤ PAD_PX) ที่ แปลงต่อ tick ≤ ครึ่งหนึ่งของกรอบเล็ก (h = 3) และไม่เกิน BUDGET · ไม่มีที่คุ้ม = 0
        (ครึ่งหนึ่ง = เผื่อค่าประมาณคลาด + คิวรีเดิมของ PolygonPickTool หยุดอ่านที่แปลงแรกที่ครอบจุด)"""
        _k, h0, n0, s = self._stat
        n0 = max(n0, 1)

        def _n(h):
            return n0 * ((2.0 * h + s) / (2.0 * h0 + s)) ** 2
        n_old, v = _n(3), max(d_px, 1.0)
        for p in range(self.PAD_PX, 0, -1):
            n = _n(3 + p)
            if n <= self.BUDGET and 2.0 * n * v <= n_old * (3 + p):
                return p
        return 0

    def features(self, layer, req, rect, pt, map_pt, mupp, big_fn, extra=None):
        """ฟีเจอร์สำหรับ hover แทน layer.getFeatures(req) — req = คำขอเดิมของผู้เรียก (กรองด้วยกรอบเล็ก rect + setLimit)
        pt = จุดเคอร์เซอร์ (พิกัดชั้น) · map_pt/mupp = จุดบนแผนที่/หน่วยต่อพิกเซล (วัดความเร็วเคอร์เซอร์)
        big_fn(pad_px) -> กรอบเล็กขยายอีก pad_px พิกเซล ในพิกัดชั้น (None = แปลงไม่ได้)
        คืน list หรือ None = ผู้เรียกคิวรีสดแบบเดิม

        ★ 2.4.0 (review PF-07+PF-10+PF-15) — ตอบจากแคชเมื่อ "จุด" เคอร์เซอร์ยังอยู่ในกรอบที่ดึงไว้ (เดิมต้องทั้งกรอบเล็ก)
          ผลเท่าเดิม: ผู้เรียกใช้เฉพาะแปลงที่รูปครอบจุดนั้น ⇒ กรอบของรูปครอบจุด ⇒ อยู่ในชุดที่ดึงด้วยกรอบที่ครอบจุดแน่นอน"""
        try:
            self._watch(layer)
            st = layer.undoStack()
            key = (layer.id(), layer.isEditable(), st.index(), st.count(), layer.subsetString(), extra, self._gen)
            skey = (layer.id(), extra, round(float(mupp), 9))
        except Exception:
            return None
        d_px = None
        if self._prev is not None and mupp > 0 and self._prev[1] == mupp:
            d_px = max(abs(map_pt.x() - self._prev[0].x()), abs(map_pt.y() - self._prev[0].y())) / mupp
        self._prev = (QgsPointXY(map_pt), mupp)
        self._slow = self._slow + 1 if (d_px is not None and d_px <= self.SLOW_PX) else 0
        now = time.monotonic()
        if not (key == self._key and now - self._t <= self.TTL_S
                and self._rect is not None and self._rect.contains(pt)):
            self._key, self._rect, self._feats = None, None, None
            # เร็ว/เพิ่งเริ่ม/เพิ่งซูม/บริเวณแน่นเกิน = คิวรีสดแบบเดิม (ไม่ดึงเกิน · หยุดที่แปลงแรกได้เหมือนเดิม)
            if self._slow < 2 or (self._dense is not None and self._dense[0] == skey
                                  and now - self._dense[1] <= self.DENSE_S):
                return None
            known = self._stat is not None and self._stat[0] == skey
            pad = self._pad_px(d_px) if known else 0
            if pad == 0 and known and d_px > 3:
                return None            # ขยายไม่คุ้ม และจุดก็หลุดกรอบเล็กใน tick ถัดไปอยู่ดี = แบบเดิม
            big = None
            if pad > 0:
                try:
                    big = big_fn(pad)
                except Exception:
                    big = None
                if big is None or big.isEmpty() or not big.contains(rect):
                    big, pad = None, 0
            lim = req.limit()
            _it = layer.getFeatures(req if big is None else QgsFeatureRequest(req).setFilterRect(big))
            try:
                got = []
                for f in _it:
                    g = f.geometry()
                    got.append((f, g.boundingBox() if g is not None and not g.isNull() else None))
            finally:
                _it.close()
            if not (lim is None or lim < 0 or len(got) < lim):
                self._dense = (skey, now)            # แน่นเกินเพดาน ⇒ ที่ซูมนี้เลิกดึงเก็บ (tick ต่อไป = คิวรีสดแบบเดิม)
                if big is None:
                    return [f for f, bb in got]      # = คิวรีสดแบบเดิมเป๊ะ (ชนเพดานเหมือนกัน) · ไม่เก็บ
                return None                          # กรอบขยายไม่ครบ ⇒ tick นี้คิวรีสด
            lupp = rect.width() / 6.0                # หน่วยชั้นต่อพิกเซล (กรอบเล็ก = 6 px)
            sz = sorted(max(bb.width(), bb.height()) for f, bb in got if bb is not None)
            s_px = (sz[len(sz) // 2] / lupp) if (sz and lupp > 0) else 0.0
            self._stat = (skey, 3 + pad, len(got), s_px)
            self._key, self._t = key, now
            self._rect, self._feats = QgsRectangle(rect if big is None else big), got
        return [f for f, bb in self._feats if bb is not None and bb.intersects(rect)]


class PolygonPickTool(_MlepKeys, QgsMapTool):
    """cursor กากบาท + ไฮไลต์แปลงใต้เมาส์ (ก่อนคลิก) เป็นตัวช่วยตัดสินใจ
    คลิก = ส่ง feature กลับผ่าน click_cb ; เลื่อนเมาส์ = hover_cb"""

    # hover ยิง getFeatures ทุก mouse-move = 1 query/เฟรมบน PostgreSQL -> รวบยอดทุก ~80ms
    HOVER_MS = 80

    def __init__(self, canvas, layer, click_cb, hover_cb, done_cb=None, skip_fids=None,
                 keep_active=False, msg_title="DOL", choose_prompt=None):
        """done_cb (2.3.1) — รับสัญญาณ "เลือกครบแล้ว" จาก **คลิกขวา / Enter**

        ★ เป็นทางเลือก (ปริยาย None) ⇒ ผู้ใช้เดิมทุกตัว (ค้นหาภาพลักษณ์ · ลบแปลง ·
          เปลี่ยน Type) พฤติกรรมไม่เปลี่ยนเลย — คลิกขวายังไม่ทำอะไรเหมือนเดิม
        ใช้กับ 🍩 แบ่งหัก/แยก ที่ต้องคลิกแปลงในได้ **หลายใบ** ก่อนไปเลือกแปลงนอก
        """
        super().__init__(canvas)
        self._canvas = canvas
        self._layer = layer
        self._click_cb = click_cb
        self._hover_cb = hover_cb
        self._done_cb = done_cb
        # ★ 2.3.1 — แปลงที่ให้ "มองข้าม" (ทั้งไฮไลต์ตอนเลื่อนเมาส์ และตอนคลิก)
        #   🔴 เคสจริง: 🍩 แบ่งหัก/แยก ตอนเลือกแปลงใน — แปลงในซ้อนอยู่ในแปลงเต็ม
        #      คลิกทีเดียวโดนทั้งคู่ ⇒ เด้ง popup ให้เลือกทุกครั้ง ทั้งที่รู้อยู่แล้วว่าใบไหนคือแปลงเต็ม
        #      และไฮไลต์ตอนเลื่อนเมาส์ก็ขึ้นแปลงเต็ม ทำให้สับสนว่ากำลังจะคลิกใบไหน
        self._skip_fids = set(skip_fids or ())
        # ★ 2.3.7 — keep_active: เครื่องมือค้างไว้หลังคลิก (ℹ️ สอบถามข้อมูลแปลง แบบ Identify ของ QGIS)
        #   ⇒ คืน _picked = False หลัง callback ทุกครั้ง ไม่งั้น deactivate() จะไม่ล้มไฮไลต์ hover ตอนเลิกใช้ (review LC-13)
        #   msg_title / choose_prompt: ข้อความของเครื่องมือที่ไม่ใช่ DOL (เดิมขึ้น "DOL" · "ต้องการค้นหา" ทุกตัว — review UX-45)
        self._keep_active = bool(keep_active)
        self._msg_title = msg_title or "DOL"
        self._choose_prompt = choose_prompt
        self._last_fid = None
        self._picked = False
        self.setCursor(QtCore.Qt.CrossCursor)
        # cache transform ครั้งเดียว (เดิมสร้างใหม่ทุก mouse-move ตอน hover) · ★ rc1 (DI-03) สร้างใหม่เมื่อ CRS/datum ของโปรเจกต์เปลี่ยน
        self._pick_layer = layer
        self._build_xforms()
        # throttle hover: เก็บตำแหน่งล่าสุดไว้ ประมวลผลตาม timer แทนทุกเฟรม
        self._pending_pos = None
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(self.HOVER_MS)
        self._hover_timer.timeout.connect(self._hover_tick)
        self._hover_cache = _HoverPolyCache()       # ★ 2.4.0 (review PF-15)

    def _crs_redraw(self):
        """★ rc2 (audit A1-04) — ทิ้งแคช hover หลังเปลี่ยน CRS (ตอบใหม่จากคิวรีสดครั้งถัดไป)"""
        try:
            self._hover_cache.clear()
        except Exception:
            pass

    def _build_xforms(self):
        """★ rc1 (DI-03) ตัวแปลง CRS โปรเจกต์ → CRS ชั้นที่เลือก (ชั้นเดียวกัน = None)"""
        proj = QgsProject.instance()
        layer = self._pick_layer
        self._xform = None
        if layer.crs() != proj.crs():
            try:
                self._xform = QgsCoordinateTransform(proj.crs(), layer.crs(), proj)
            except Exception:
                self._xform = None

    def _feature_at_pos(self, pos):
        """หา feature ในเลเยอร์ที่เลือก ใต้ตำแหน่ง pixel pos (None ถ้าไม่มี)"""
        map_pt = self.toMapCoordinates(pos)   # CRS ของโปรเจกต์
        pt = map_pt
        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        # ★ 2.4.0 (review DI-44) — แปลงพิกัดไม่ได้ = ถือว่า "ไม่มีแปลงใต้เมาส์" (ไม่ไฮไลต์)
        #   เดิมถอยไปใช้จุด/กรอบที่ยังไม่แปลง (คนละระบบพิกัด คลาดได้หลายร้อยเมตร) ⇒ ไฮไลต์แปลงอื่นที่ไม่ได้อยู่ใต้เมาส์
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                return None
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))

        # 🔴🔴 3 ก.ย. 69 (2.2.4) — 2.2.2 ใส่ setLimit(1) เพื่อกันค้าง แต่ทำให้ "ผิด" ได้:
        #   setFilterRect กรองด้วย "กรอบสี่เหลี่ยม" ของรูป แล้วบรรทัดล่างค่อยเช็ค intersects จริง
        #   ⇒ limit=1 แล้วบังเอิญได้แปลงข้างเคียงที่กรอบคลุมเมาส์แต่รูปไม่คลุม = คืน None
        #     ทั้งที่มีแปลงอยู่ใต้เมาส์จริง ⇒ ไฮไลต์หายเป็นช่วง ๆ เฉพาะบริเวณแปลงเบียดกัน
        #     ซึ่งคือบริเวณที่พนักงานต้องใช้มากที่สุด
        #   ⇒ ยังจำกัดจำนวนเพื่อกันค้าง (เจตนาเดิมของ 2.2.2 ถูก) แต่ต้องมากพอให้ยังถูกต้อง
        #   ★ 4 ก.ย. 69 วัดกับอำเภอจริง (a18.shp 183,057 แปลง สุ่ม 400 จุด): จำนวนแปลงที่ "กรอบ"
        #     คลุมจุดคลิก p95 = 4-12 ที่ 1:600-1:12,000 (ช่วงที่ทำงานจริง) แต่พุ่งเป็น 85 ที่ 1:60,000
        #     ⇒ 50 พอสำหรับงานปกติ แต่ 200 ครอบถึง ~1:60,000 โดยไม่แพงขึ้นจริง
        #   ★ ห้ามใส่ .setNoGeometry() (รายงาน 2.2.2 แนะนำไว้) เพราะบรรทัดล่างเรียก f.geometry()
        req = QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(200)
        # ★ 2.4.0 (review PF-15) — ตอบจากแปลงรอบเคอร์เซอร์ที่ดึงไว้ (ไม่ถามฐานทุก tick) · แคชใช้ไม่ได้ = คิวรีสดแบบเดิม
        _cached = self._hover_cache.features(self._layer, req, rect, pt, map_pt, self._canvas.mapUnitsPerPixel(),
                                             lambda pad: self._hover_big_rect(map_pt, pad))
        _fit204 = self._layer.getFeatures(req) if _cached is None else None
        try:
            for f in (_cached if _cached is not None else _fit204):
                if f.id() in self._skip_fids:      # ★ 2.3.1 มองข้ามแปลงที่สั่งไม่ให้เห็น
                    continue
                if f.geometry().intersects(gp):
                    return f
        finally:
            if _fit204 is not None:
                _fit204.close()
        return None

    def _hover_big_rect(self, map_pt, pad):
        """★ 2.4.0 (review PF-15) — กรอบที่ดึงแปลงมาเก็บไว้ (พิกัดชั้น) = กรอบ 3 พิกเซลของ hover ขยายอีก pad พิกเซล"""
        d = self._canvas.mapUnitsPerPixel() * (3 + pad)
        big = QgsRectangle(map_pt.x() - d, map_pt.y() - d, map_pt.x() + d, map_pt.y() + d)
        return self._xform.transformBoundingBox(big) if self._xform is not None else big

    def canvasMoveEvent(self, event):
        # เก็บตำแหน่งไว้ก่อน — query จริงเกิดใน _hover_tick ตามรอบ timer
        self._pending_pos = event.pos()
        if not self._hover_timer.isActive():
            self._hover_timer.start()

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None:
            return
        # ไฮไลต์แปลงใต้เมาส์ (อัปเดตเฉพาะเมื่อเปลี่ยนแปลง)
        feat = self._feature_at_pos(pos)
        fid = feat.id() if feat is not None else None
        if fid == self._last_fid:
            return
        self._last_fid = fid
        self._hover_cb(feat, self._layer)

    def _features_at_pos(self, pos):
        """คืน "ทุกแปลง" ในเลเยอร์ที่ครอบจุดที่คลิก (แปลงซ้อนกัน) พร้อม attribute
        intersects กับ "จุดคลิกจริง" (ไม่ใช่กล่อง) = เฉพาะแปลงที่ครอบจุดนั้นจริง ; เรียงพื้นที่เล็ก->ใหญ่
        ★ 2.4.0 (review DI-44) — คืน None (ไม่ใช่ list ว่าง) เมื่อแปลงพิกัดจุดคลิกเป็นระบบของชั้นไม่ได้"""
        map_pt = self.toMapCoordinates(pos)
        pt = map_pt
        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        # ★ 2.4.0 (review DI-44) — เดิมแปลงจุด/กรอบไม่ได้ = ใช้ค่าที่ยังไม่แปลงต่อ (คนละระบบพิกัด คลาดได้หลายร้อยเมตร)
        #   ⇒ ได้แปลงอื่นที่ไม่ได้คลิก ส่งต่อให้ ค้นหา DOL/ลบแปลง/เปลี่ยน Type/🍩 ⇒ ยกเลิกการคลิกนี้ (ผู้เรียกแจ้งเหตุ)
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                return None
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        out = []
        for f in self._layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            if f.id() in self._skip_fids:          # ★ 2.3.1 มองข้ามแปลงที่ผู้เรียกสั่งไม่ให้เห็น
                continue
            g = f.geometry()
            if g is not None and not g.isNull() and g.intersects(gp):
                out.append(f)
        try:
            out.sort(key=lambda ff: ff.geometry().area())   # แปลงเล็ก (มักเป็นแปลงในซ้อน) อยู่บนสุด
        except Exception:
            pass
        return out

    def _choose_parcel(self, feats):
        """แปลงซ้อนกัน >1 -> popup ให้เลือกตามระวาง UTMMAP1-4 / UTMSCALE / LANDNO ; คืน None ถ้ายกเลิก"""
        # 🔧 9 ก.ย. 69 — ชื่อคงที่ (UTMMAP1..) ⇒ ต้องใช้ _fld_idx ไม่ใช่ indexOf
        #   import ในฟังก์ชัน เพราะ main.py เป็นฝั่งที่ import โมดูลนี้ (กัน circular import)
        #   ตอนฟังก์ชันนี้ทำงาน main ถูกโหลดไปแล้วแน่นอน (เป็นตัวเริ่มปลั๊กอิน)
        from .main import _sheet_str as gv          # ★ 2.3.0 ตัวเดียวกับที่ main.py ใช้
        labels = []
        for f in feats:
            m4 = gv(f, "UTMMAP4") or "00"
            labels.append(
                f"ระวาง {gv(f,'UTMMAP1')} {gv(f,'UTMMAP2')} {gv(f,'UTMMAP3')}-{m4}"
                f"  |  มาตราส่วน {gv(f,'UTMSCALE')}  |  เลขที่ดิน {gv(f,'LANDNO')}")
        # 🔴 9 ก.ย. 69 — ป้ายสร้างจากระวาง+มาตราส่วน+เลขที่ดินเท่านั้น **ไม่มีตัวระบุแปลง**
        #   ถ้าป้ายซ้ำกัน `labels.index(item)` คืน 0 เสมอ ⇒ ผู้ใช้เลือกแปลงที่สอง
        #   **แต่ได้แปลงแรกเงียบ ๆ** (ผู้ตรวจ Windows ชี้จุดนี้)
        #   วัดกับฐานจริงแล้ว ~598,000 แปลง 4 อำเภอ **ไม่มีป้ายซ้ำเลยสักกลุ่ม**
        #   แต่กันไว้เพราะเป็นความพังแบบ "เงียบ" และกันได้ด้วยการเติมลำดับให้ป้ายไม่ซ้ำ
        _base = list(labels)          # นับจากรายการเดิม ไม่งั้นจะเติมเลขให้แค่ตัวแรกของกลุ่ม
        labels = ["%s  (#%d)" % (_l, _i + 1) if _base.count(_l) > 1 else _l
                  for _i, _l in enumerate(_base)]
        item, ok = QtWidgets.QInputDialog.getItem(
            iface.mainWindow(), "เลือกแปลง (มีแปลงซ้อนกัน)",
            f"จุดที่คลิกมี {len(feats)} แปลงซ้อนกัน — {self._choose_prompt or 'เลือกแปลงที่ต้องการค้นหา:'}",
            labels, 0, False)
        if not ok:
            return None
        return feats[labels.index(item)]

    def keyPressEvent(self, e):
        # ★ ข้อความแนะนำของทุกผู้ใช้ tool นี้ (ค้นหาภาพลักษณ์/ลบทั้งแปลง) สัญญาว่า "Esc = ยกเลิก"
        #   แต่เดิมไม่มี handler -> Esc ไม่ทำอะไร เครื่องมือ (รวมตัวลบ) ค้าง arm อยู่ (2026-08-05)
        if _eat_del_key(self, e):          # ★ 2.3.7 (audit F1) ℹ️/DOL/🍩/📝 — แปลงที่เลือกค้างต้องไม่ถูกลบด้วยคีย์นี้
            return
        # ★ 2.3.1 — Enter/Return = "เลือกครบแล้ว" (คู่กับคลิกขวา) เฉพาะตัวที่ส่ง done_cb มา
        if e.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter) and self._done_cb:
            self._picked = True          # กัน deactivate() ล้างข้อความแนะนำของขั้นถัดไป
            self._done_cb()
            self._picked_done()          # ★ 2.3.7 (LC-13)
            return
        if e.key() == QtCore.Qt.Key_Escape:
            # ★ ต้องสลับไปเครื่องมือเลือกปกติ (2026-08-06 release gate)
            #   unsetMapTool เฉย ๆ ทำให้ canvas ไม่มี map tool เลย (คลิกแล้วไม่มีอะไรตอบสนอง
            #   + cursor กลับเป็นลูกศรจนผู้ใช้เข้าใจว่าโปรแกรมค้าง) · actionSelect ทำให้ deactivate()
            #   ทำงานตามปกติ (ล้าง hover + ข้อความ) แล้วได้เครื่องมือเลือกมาตรฐานกลับมา
            iface.actionSelect().trigger()

    def canvasReleaseEvent(self, event):
        # ★ 2.3.1 — คลิกขวา = "เลือกครบแล้ว" เฉพาะตัวที่ส่ง done_cb มา (ตัวอื่นเมินเหมือนเดิม)
        if event.button() == QtCore.Qt.RightButton and self._done_cb:
            self._picked = True
            self._done_cb()
            self._picked_done()          # ★ 2.3.7 (LC-13)
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        # เก็บ "ทุกแปลง" ที่ครอบจุดคลิก — ถ้าซ้อนกัน >1 ให้ผู้ใช้เลือกตามระวาง (image + survey ใช้ tool นี้ทั้งคู่)
        feats = self._features_at_pos(event.pos())
        if feats is None:                # ★ 2.4.0 (review DI-44) แปลงพิกัดไม่ได้ ⇒ ไม่เลือกแปลงใด
            iface.messageBar().pushMessage(
                self._msg_title, "แปลงพิกัดจุดที่คลิกเป็นระบบพิกัดของชั้นข้อมูลไม่ได้ — ยกเลิก ยังไม่ได้เลือกแปลง "
                                 "(ตรวจระบบพิกัดของโปรเจกต์/ชั้น)", level=2, duration=10)
            return
        if not feats:
            iface.messageBar().pushMessage(
                self._msg_title, "ไม่พบแปลงในเลเยอร์ที่เลือกตรงตำแหน่งที่คลิก ลองใหม่อีกครั้ง", level=1, duration=6)
            return
        if len(feats) == 1:
            chosen = feats[0]
        else:
            chosen = self._choose_parcel(feats)
            if chosen is None:
                return   # ผู้ใช้ยกเลิก popup
        # ดึง feature เต็มตาม id ให้ชัวร์ทุก provider (บาง provider คืน NULL ถ้าไม่มี attribute)
        full = self._layer.getFeature(chosen.id())
        if full is None or not full.isValid():
            full = chosen
        self._picked = True
        self._click_cb(full, self._layer)
        self._picked_done()              # ★ 2.3.7 (LC-13) — ครอบกรณี keep_active (ℹ️ สอบถาม) ด้วย

    def _picked_done(self):
        """★ 2.3.7 (review LC-13) — หลัง callback: ถือว่า "เลือกแล้ว" ต่อเฉพาะเมื่อ callback ส่งต่อไปเครื่องมืออื่นแล้ว
        เดิม _picked = True ค้างตลอด ⇒ callback ที่ return โดยไม่เปลี่ยนเครื่องมือ (เช่น 🍩 ตอนด่านสิทธิ์ไม่ผ่าน)
        ทิ้งเครื่องมือไว้ แล้วกด Esc ⇒ deactivate() ข้ามการล้างไฮไลต์ hover ⇒ ไฮไลต์ค้างจอ
        (เครื่องมือแบบ keep_active ยังเป็นเครื่องมือที่ใช้อยู่ ⇒ False เหมือนที่ 2.3.7 ตั้งไว้เดิม)"""
        try:
            self._picked = self._canvas.mapTool() is not self
        except Exception:
            self._picked = False

    def push_hint(self, title, text, level=0, duration=None):
        """★ 2.3.7 (review UX-01) — ข้อความแนะนำของเครื่องมือนี้ (ผู้เรียกดันผ่านนี่หลัง setMapTool)
        ⇒ เลิกใช้เครื่องมือแล้วลบเฉพาะอันนี้ ไม่ล้างทั้งแถบ"""
        return _bar_push_own(self, title, text, level, duration)

    def deactivate(self):
        self._hover_timer.stop()
        self._pending_pos = None
        self._hover_cache.release()     # ★ 2.4.0 (review PF-07+PF-10+PF-15) — ถอดสัญญาณชั้น + ทิ้งแคช hover
        # ถ้าเลิกใช้เครื่องมือโดยไม่ได้คลิก -> ลบไฮไลต์ hover
        if not self._picked:
            try:
                self._hover_cb(None, self._layer)
            except Exception:
                pass
        # ★ 2.3.7 (review UX-01) — เดิม clearWidgets() (ตอนออกโดยไม่ได้คลิก) ล้างทั้งแถบ รวมคำเตือนที่ตั้งใจให้ค้าง
        #   ⇒ ลบเฉพาะคำแนะนำของเครื่องมือนี้ (push_hint) · คลิกแล้วก็ลบ (คำแนะนำหมดหน้าที่ ไม่แตะข้อความของขั้นถัดไป)
        _bar_pop_own(self)
        super().deactivate()


class AddNodeTool(_MlepKeys, QgsMapTool):
    """เพิ่ม node ให้แปลง + เพิ่มหมุด (ไม่ต้องคลิกขวา)
    - คลิกในแปลง = เลือก/เอาออก (ไฮไลต์เขียว, หลายแปลงได้)
    - เลื่อนเมาส์ใกล้หมุด = snap (วงกลมแดง) -> คลิกตอนนั้น = แทรก node เข้าทุกแปลงที่เลือก + เพิ่มหมุด
    - คลิกขวา / Esc = ยกเลิก"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.picked = []          # [(fid, rubberband)]
        self.setCursor(QtCore.Qt.CrossCursor)
        self._build_xforms()        # ★ rc1 (DI-03) สร้างใหม่เมื่อ CRS/datum ของโปรเจกต์เปลี่ยน (_MlepKeys._xf_watch)
        # ตัวบอก snap = วงกลมแดงที่เด้งไปเกาะหมุดใกล้สุด
        self._dup_marks = []        # ★ 2.2.9 — เครื่องหมาย "ของซ้อน" ที่วางไว้บนแคนวาส
        self._snap_mk = None
        self._make_snap_mk()        # ★ 2.3.7 (LC-09) — แยกออกมาให้ activate() สร้างคืนได้
        # hover highlight แปลงใต้เมาส์ก่อนคลิก (เหลือง) เป็นตัวช่วยตัดสินใจ
        self._hover_rb = None
        self._hover_fid = None
        # throttle hover: เดิมยิงสูงสุด 2 query ต่อ mouse-move (_nearest_marker + _poly_at)
        # -> บน PostgreSQL คือ 2 round-trips ต่อเฟรม; รวบยอดประมวลผลทุก ~80ms แทน
        self._pending_pos = None
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(80)
        self._hover_timer.timeout.connect(self._hover_tick)
        self._hover_cache = _HoverPolyCache()       # ★ 2.4.0 (review PF-15) แปลงรอบเคอร์เซอร์ของ _poly_at(hover=True)

    def _make_snap_mk(self):
        """★ 2.3.7 (review LC-09) — สร้างวงกลมแดงตัวบอก snap (ตอนสร้างเครื่องมือ + ตอนถูกเปิดกลับมา)"""
        if getattr(self, "_snap_mk", None) is not None:
            return
        mk = QgsVertexMarker(self._canvas)
        mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
        mk.setColor(QtGui.QColor(255, 0, 0))
        mk.setPenWidth(3)
        mk.setIconSize(14)
        mk.hide()
        self._snap_mk = mk

    def _build_xforms(self):
        """★ rc1 (DI-03) ตัวแปลง CRS โปรเจกต์ ↔ ชั้นแปลง/ชั้นหมุด (ชั้นเดียวกัน = None)"""
        proj = QgsProject.instance()
        poly_lyr, point_lyr = self.poly_lyr, self.point_lyr
        self._to_poly = (QgsCoordinateTransform(proj.crs(), poly_lyr.crs(), proj)
                         if poly_lyr.crs() != proj.crs() else None)
        self._to_pt = (QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj)
                       if point_lyr.crs() != proj.crs() else None)
        self._from_pt = (QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
                         if point_lyr.crs() != proj.crs() else None)
        self._from_poly = (QgsCoordinateTransform(poly_lyr.crs(), proj.crs(), proj)
                           if poly_lyr.crs() != proj.crs() else None)

    def activate(self):
        # ★ 2.3.7 (review LC-09) — deactivate() เอาวงกลม snap ออกจากแคนวาสแล้วตั้งเป็น None (= ด่านใน hover)
        #   เครื่องมือตัวเดิมที่ถูกเปิดกลับมา (เช่น เริ่มวาดเส้นจากหน้าต่างวาดเส้นแล้วหยุด — _line_restore_tool)
        #   จึงไม่มีวงกลมแดง/ไฮไลต์ hover อีกเลย ทั้งที่คลิกยังทำงาน ⇒ สร้างคืนทุกครั้งที่ถูกเปิดใช้
        super().activate()
        self._make_snap_mk()
        self._hover_fid = None
        self._pending_pos = None

    def _poly_at(self, map_pt, hover=False):
        # ★ 2.4.0 (review PF-15) — hover=True (จาก _hover_tick เท่านั้น) ตอบจากแปลงรอบเคอร์เซอร์ที่ดึงไว้ · คลิกคิวรีสดเสมอ
        # ★ 2.3.7 (review DU-12-D) — เดิมแปลงพิกัดนอก try: โปรเจกต์ CRS ผสม (เช่นโปรเจกต์ 4326 · ชั้น 24047)
        #   เมาส์ออกนอกขอบเขตของ projection ⇒ QgsCsException หลุดใน slot ของ hover timer = กล่อง error ของ Python
        #   ⇒ ถือว่า "ไม่มีแปลงใต้เมาส์" (ผู้เรียกทุกตัวรับ None อยู่แล้ว)
        try:
            pt = self._to_poly.transform(map_pt) if self._to_poly else map_pt
        except Exception:
            return None
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol, map_pt.x() + tol, map_pt.y() + tol)
        if self._to_poly is not None:
            try:
                rect = self._to_poly.transformBoundingBox(rect)
            except Exception:
                pass
        
        # ★ ต้องดึงฟิลด์ Type มาด้วย — ห้ามใช้ setNoAttributes() ตรงนี้
        #   feature ที่ได้จากนี่ถูกส่งต่อให้ _poly_type_str() (บรรทัด ~332 _toggle และ ~366 _set_hover)
        #   เพื่อเช็คว่าเป็นแปลงล็อก L1-RTK/L1-TS หรือไม่
        #   บน provider PostGIS setNoAttributes() ทำให้ attribute เป็น None ทั้งหมด (พิสูจน์แล้วกับชั้นจริง)
        #   -> Type=None -> ไม่เข้าเงื่อนไข ("L1-RTK","L1-TS") -> กันชนไม่ทำงานเลยใน Add Node
        #   (memory layer ไม่ strip จึงไม่เคยเห็นบั๊กนี้ตอนทดสอบ)
        #   ดึงเฉพาะฟิลด์ Type ฟิลด์เดียว ไม่ใช่ทั้งแถว -> ยังเบาอยู่บน hover path
        # ★ 4 ก.ย. 69 (2.2.4) — จำกัดจำนวนเหมือน _feature_at_pos ของ PolygonPickTool
        #   ทางนี้อยู่บน hover ที่ยิงทุก 80 มิลลิวินาที และเดิมไม่มีเพดานเลย
        #   ★ 2.3.7 (DI-38) — ตอนนี้คืน "แปลงเนื้อที่เล็กสุดที่ intersects" (ดูข้างล่าง) · 200 ยังครอบทุกแปลงที่กรอบคลุมจุด
        #   200 มาจากการวัดกับอำเภอจริง (a18.shp): p95 ของแปลงที่กรอบคลุมจุด = 85 ที่ 1:60,000
        req = QgsFeatureRequest().setFilterRect(rect).setLimit(200)
        ti = self.poly_lyr.fields().indexOf(self.plugin._resolve_field(self.poly_lyr, {'type'}) or "")
        if ti >= 0:
            req.setSubsetOfAttributes([ti])
        else:
            req.setNoAttributes()
        _cached = (self._hover_cache.features(self.poly_lyr, req, rect, pt, map_pt, self._canvas.mapUnitsPerPixel(),
                                              lambda pad: self._hover_big_rect(map_pt, pad), extra=ti)
                   if hover else None)
        _fit398 = self.poly_lyr.getFeatures(req) if _cached is None else None
        # ★ 2.3.7 (review DI-38) — แปลงซ้อน/แปลงในแปลง: คืนแปลงที่ **เนื้อที่เล็กสุด** ที่ครอบจุดนั้น
        #   (กติกาเดียวกับ PolygonPickTool._features_at_pos ⇒ ไฮไลต์เหลืองตรงกับที่คลิกจะได้ ทุกเครื่องมือ)
        #   เดิมคืน "ตัวแรก" ตามลำดับของ provider ⇒ ถ้าแปลงเต็มมาก่อน แปลงในเลือกไม่ได้เลย
        #   (Add Node / แก้ชื่อหมุด / ลบ Node / สลับหมุด) และถ้าแปลงเต็มเป็น L1 ก็ถูกปฏิเสธทั้งที่คลิกแปลงใน
        best, best_a = None, None
        try:
            for f in (_cached if _cached is not None else _fit398):
                g = f.geometry()
                if g is None or g.isEmpty() or not g.intersects(gp):
                    continue
                a = g.area()
                if best is None or a < best_a:
                    best, best_a = f, a
        finally:
            if _fit398 is not None:
                _fit398.close()
        return best

    def _hover_big_rect(self, map_pt, pad):
        """★ 2.4.0 (review PF-15) — กรอบที่ดึงแปลงมาเก็บไว้ (พิกัดชั้นแปลง) = กรอบ 3 พิกเซลของ _poly_at ขยายอีก pad พิกเซล"""
        d = self._canvas.mapUnitsPerPixel() * (3 + pad)
        big = QgsRectangle(map_pt.x() - d, map_pt.y() - d, map_pt.x() + d, map_pt.y() + d)
        return self._to_poly.transformBoundingBox(big) if self._to_poly is not None else big

    def _snap_map_tol(self):
        """รัศมี snap ในหน่วยของ CRS *แผนที่* — แยกออกมาเพื่อให้ตัวหา 'มุมเปลือย' ใช้ค่าเดียวกัน
        (ห้ามคำนวณซ้ำที่อื่น — สูตรนี้มีกับดักเรื่องหน่วย CRS ที่เคยทำให้ snap ผิดตัวหลายสิบกิโลเมตร)"""
        # 12px เพดาน 25 ม. (เดิมไม่มีเพดาน ตอน zoom-out ระดับอำเภอ กรอบ ~1.2 กม.
        # ดึงหมุดหลักพันจาก PostGIS ทุกครั้งที่ขยับเมาส์) — แต่การันตี >=4px เสมอ:
        # เพดานล้วน ๆ ทำให้จุดคลิกเล็กกว่าไอคอนหมุดตอน zoom-out ลึก (คลิกบนหมุด
        # ที่เห็น ๆ แล้วพลาด -> ตกไปเลือกแปลงแทน = ได้แปลงผิดตัว)
        _mupp = self._canvas.mapUnitsPerPixel()
        if _canvas_is_metres(self._canvas):
            map_tol = max(min(max(_mupp * 12, 0.5), 25.0), _mupp * 4)
        else:
            # แคนวาสไม่ใช่เมตร (เช่น projectCrs 4326): พื้น 0.5 จะกลายเป็น 0.5 องศา
            # ~55 กม. -> ดึงหมุดทั้งอำเภอจาก PostGIS ทุก 80 มิลลิวินาทีที่เลื่อนเมาส์
            # 🔴 4 ก.ย. 69 (2.2.4) — คอมเมนต์ข้างบนอธิบายปัญหาไว้ตั้งแต่แรก แต่โค้ดไม่เคยใส่
            #   เพดานให้ทางนี้ (ใส่แค่ทางเมตร) และมีไฟล์อำเภอจริงที่ตั้งเป็น EPSG:4326 อยู่
            #   ⇒ บนไฟล์นั้น hover ดึงหมุดหลักหมื่นทุก 80 มิลลิวินาที และมีสิทธิ์ snap หมุด
            #     ที่อยู่ห่างหลายสิบกิโลเมตร = เขียนพิกัดผิดลงฐานโดยไม่มีคำเตือน
            #   ★ ห้ามใส่ setLimit แทน เพราะฟังก์ชันนี้ต้องได้ "ตัวใกล้สุดจริง"
            #     ถ้าจำกัดจำนวนจะได้หมุดชุดสุ่มมาเทียบ -> snap ผิดตัว (ร้ายกว่าอาการค้าง)
            #     การคุมด้วย "รัศมี" จึงถูกกว่า: ลดงานโดยไม่เปลี่ยนคำตอบในระยะที่ใช้จริง
            #   25 ม. ที่ละติจูดของงานนี้ ~ 0.000226 องศา (ใช้ค่าคงที่ ไม่ต้องแปลง CRS
            #   ตอน hover ซึ่งต้องเบาที่สุด) และการันตี >=4px เหมือนทางเมตร
            _DEG_25M = 0.000226
            map_tol = max(min(_mupp * 12, _DEG_25M), _mupp * 4)
        return map_tol

    def _nearest_marker(self, map_pt):
        """หาหมุดใกล้สุดในรัศมี snap -> (xy ใน CRS หมุด, xy ใน CRS แผนที่) หรือ (None, None)"""
        map_tol = self._snap_map_tol()
        rect = QgsRectangle(map_pt.x() - map_tol, map_pt.y() - map_tol, map_pt.x() + map_tol, map_pt.y() + map_tol)
        if self._to_pt is not None:
            try:
                rect = self._to_pt.transformBoundingBox(rect)
            except Exception:
                pass
                
        best = None
        best_map = None
        bestd = map_tol * map_tol
            
        for f in self.point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes()):
            xy = f.geometry().asPoint()
            map_xy = self._from_pt.transform(xy) if self._from_pt else QgsPointXY(xy)
            d = (map_xy.x() - map_pt.x()) ** 2 + (map_xy.y() - map_pt.y()) ** 2
            if d <= bestd:
                bestd = d
                best = xy
                best_map = map_xy
        if best is None:
            return None, None
        return best, best_map

    def _add_highlight(self, feat):
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(0, 170, 0))
        rb.setFillColor(QtGui.QColor(0, 170, 0, 60))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        return rb

    # ★ 31 ส.ค. 69 — ย้ายข้อความ/กติกาขึ้นมาเป็นตัวแปรของคลาส เพื่อให้เครื่องมือลูก
    #   (แอดมิน + สลับหมุด) ใช้ _toggle ตัวเดียวกันได้ ไม่ต้องก๊อปโค้ดไปแก้ทีละที่
    #   ALLOW_LOCKED = True เฉพาะเครื่องมือแอดมินที่ตกลงกันว่าแตะแปลงอ้างอิง L1 ได้
    TITLE = "Add Node"
    HINT  = "เลือกแปลงแล้ว • เลื่อนไปที่หมุด (snap) แล้วคลิกเพื่อเพิ่ม node"
    ALLOW_LOCKED = False
    # ★ 2.2.9 — เจ้าของงานสั่ง: "สร้างหมุด เอาไปรวมกับ Add Node · คลิกแล้ว snap กับแปลงตัวเองได้
    #   ถ้ากดตรง node ที่ไม่มีหมุดในแปลงตัวเองให้สร้างหมุดให้"
    #   ⇒ เปิดให้ถอยไปหา "มุมเปลือย" ของแปลงที่เลือกไว้ เมื่อไม่มีหมุดให้ snap
    ALLOW_BARE_NODE = True
    # ★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค.: "ปุ่ม add node ของ admin สามารถเพิ่มหมุดตรงที่ไม่มีหมุดได้")
    #   ผู้ดูแล (โหมดผู้ดูแลเต็ม) คลิกบน "ขอบ" ของแปลงที่เลือกตรงที่ไม่มีหมุด/มุมให้ snap ⇒ ฉายลงขอบ แทรก node + หมุดจุดเดียวกัน
    #   (กติกาเหล็กยังครบ: node ใหม่มีหมุดของตัวเองบนจุดเดียวกัน) · เครื่องมือลูก (แก้ชื่อ/ลบ/สลับ) ปิดไว้
    ALLOW_FREE_EDGE = True
    EDGE_PX = 5                    # ★ rc2 (audit A1-01) รัศมีคลิกขอบ (พิกเซล) — ดู _nearest_edge_point
    EDGE_INSIDE_PX = 2             # ★ rc2 (audit A1-01) ในแปลงอื่นแต่ชิดขอบไม่เกินนี้ = ยังเป็นการแทรก node บนขอบ
    SHOW_DUPS = False         # ★ 2.2.9 — เครื่องมือลูกเปิดเองถ้าอยากเห็น "ของซ้อน"
    SHOW_BARE = True          # ★ 2.2.9 — Add Node: ไฮไลต์ "มุมที่ยังไม่มีหมุด" (เจ้าของงานสั่ง)
    DENY_MSG = "ห้ามเพิ่ม node"

    def _clear_dups(self):
        """ลบเครื่องหมาย 'ของซ้อน' ทั้งหมดออกจากแคนวาส"""
        for m in getattr(self, "_dup_marks", []) or []:
            try:
                self._canvas.scene().removeItem(m)
            except Exception:
                pass
        self._dup_marks = []

    def _crs_redraw(self):
        """★ rc2 (audit A1-04) — หลังเปลี่ยน CRS: ล้างแคชมุม/รูปของแปลงที่เลือก (_pv/_pg คีย์ไม่มี CRS ⇒ hover ไม่ขึ้นที่มุม)
        และแคช hover · วาดไฮไลต์เขียวของแปลงที่เลือกใหม่ (เดิมคลาดหลายร้อยเมตร) · วาดกากบาทมุมเปลือย/ของซ้อนใหม่"""
        self._pv_key = None
        self._pg_key = None
        try:
            self._hover_cache.clear()
        except Exception:
            pass
        try:
            self._snap_mk.hide()
        except Exception:
            pass
        for fid, rb in list(getattr(self, "picked", None) or []):
            try:
                f = self.poly_lyr.getFeature(fid)
                if f.isValid():
                    rb.setToGeometry(f.geometry(), self.poly_lyr)
            except Exception:
                pass
        try:
            if getattr(self, "picked", None):
                self._refresh_dups()
        except Exception:
            pass

    def _refresh_dups(self):
        """วาดเครื่องหมายช่วยมองใหม่จาก 'แปลงที่เลือกอยู่' — เรียกหลังลงมือสำเร็จทุกครั้ง

        ★ 2.2.9 — ถ้าไม่เรียก เครื่องหมายจะค้างชี้จุดที่จัดการไปแล้ว
        """
        if not self.picked:
            self._clear_dups()
            return
        try:
            feat = self.poly_lyr.getFeature(self.picked[0][0])
        except Exception:
            return
        if feat is not None and feat.isValid():
            self._show_dups(feat, quiet=True, full=True)   # ★ 2.4.0 (review PF-07) แถวเต็มแล้ว ไม่ต้องอ่านซ้ำ

    def _show_dups(self, feat, quiet=False, full=False):
        """★ 2.2.9 — เจ้าของงานสั่ง: "ปุ่มลบ node ให้แสดงไฮไลท์ด้วย เวลาคลิกแปลงแล้วเจอ
        node หรือหมุดที่ซ้อนกัน"  ⇒ เลือกแปลงเสร็จก็สแกนแล้ววางเครื่องหมายให้เห็นเลย
        ว่าต้องไปคลิกตรงไหน (ไม่ต้องไล่หาเอง)

        🔑 อ่านอย่างเดียว ไม่แตะข้อมูล · สแกนไม่ได้ให้เงียบ เพราะเป็นแค่ตัวช่วยมอง
        """
        self._clear_dups()
        # 🔴🔴 2.2.9 — feature ที่มาจาก `_poly_at()` ถูกดึงมาแค่ฟิลด์ `Type` ฟิลด์เดียว
        #   (`setSubsetOfAttributes`) เพราะทางนั้นอยู่บน hover ที่ยิงทุก 80 มิลลิวินาที
        #   บน provider PostGIS ฟิลด์ที่เหลือจึงเป็น **None ทั้งหมด**
        #   ⇒ คีย์ระวางของแปลงกลายเป็นค่าว่าง ⇒ `_marker_exists_here` เทียบไม่ตรงสักดวง
        #   ⇒ **ขึ้นกากบาทเขียวทุกมุม** ทั้งที่หมุดครบ (เจ้าของงานเจอจริง 18 ก.ย. · gid 59050)
        #   🔑 memory layer ไม่ strip attribute ⇒ ชุดทดสอบจับไม่ได้เลย
        #      (คอมเมนต์ที่ `_poly_at` เตือนกับดักนี้ไว้อยู่แล้ว — พลาดซ้ำรอบที่สอง)
        #   ⇒ อ่านแถวเต็มจากเลเยอร์ด้วย getFeature(id) ก่อนใช้เสมอ
        # ★ 2.4.0 (review PF-07) — ยกเว้น full=True: ผู้เรียก (_refresh_dups) เพิ่งอ่านแถวเต็มด้วย getFeature(id) มาเอง
        #   (เดิมอ่านแปลงเดิมซ้ำอีกรอบ ⇒ Add Node/ลบ Node 1 ครั้ง = อ่านแปลงเดียวกัน 3 ครั้ง)
        if not full:
            try:
                _full = self.poly_lyr.getFeature(feat.id())
                if _full is not None and _full.isValid():
                    feat = _full
            except Exception:
                pass
        pts = []
        if self.SHOW_DUPS:
            try:
                pts += self.plugin._stacked_points(self.poly_lyr, self.point_lyr, feat)
            except Exception:
                pass
        if self.SHOW_BARE:
            try:
                # ★ 2.4.0 (review DU-02) — เพรดิเคตเดียวกับด่านก่อนบันทึก: มุมที่หมุดของแปลงเยื้อง 1 มม.–1 ซม.
                #   (ด่านเตือนว่ามุมไม่มีหมุด แต่เดิมไม่มีไฮไลต์ชี้) ⇒ วงแดง แยกจากกากบาทเขียว (Add Node ไม่สร้างหมุดซ้ำตรงนั้น)
                _off = []
                pts += [(q, 'bare') for q in
                        self.plugin._bare_nodes(self.poly_lyr, self.point_lyr, feat, offset_out=_off)]
                pts += [(q, 'offset') for q in _off]
            except Exception:
                pass
        if not pts:
            return
        n_mk = sum(1 for _p, k in pts if k == 'marker')
        n_nd = sum(1 for _p, k in pts if k == 'node')
        n_br = sum(1 for _p, k in pts if k == 'bare')
        n_of = sum(1 for _p, k in pts if k == 'offset')
        for p, kind in pts:
            q = p
            if self._from_poly is not None:          # CRS ชั้นแปลง -> CRS แผนที่
                try:
                    q = self._from_poly.transform(p)
                except Exception:
                    continue
            m = QgsVertexMarker(self._canvas)
            # มุมเปลือยใช้กากบาท (คนละรูปกับของซ้อน) — แยกออกแม้จอขาวดำ
            m.setIconType(QgsVertexMarker.ICON_X if kind == 'bare'
                          else QgsVertexMarker.ICON_CIRCLE if kind == 'offset'
                          else QgsVertexMarker.ICON_BOX)
            # หมุดซ้อน = ส้ม · node ซ้อน = ม่วง · มุมไม่มีหมุด = เขียว · หมุดเยื้องมุม = วงแดง (★ 2.4.0 DU-02)
            m.setColor({'marker': QtGui.QColor(255, 140, 0),
                        'node':   QtGui.QColor(156, 39, 176),
                        'bare':   QtGui.QColor(0, 150, 60),
                        'offset': QtGui.QColor(220, 30, 30)}.get(kind, QtGui.QColor(255, 140, 0)))
            m.setPenWidth(3)
            m.setIconSize(18)
            m.setCenter(QgsPointXY(q))
            m.show()
            self._dup_marks.append(m)
        msg = []
        if n_mk:
            msg.append("หมุดซ้อน %d จุด (กรอบส้ม)" % n_mk)
        if n_nd:
            msg.append("node ซ้อน %d จุด (กรอบม่วง)" % n_nd)
        if n_br:
            msg.append("มุมที่ยังไม่มีหมุด %d จุด (กากบาทเขียว)" % n_br)
        if n_of:
            msg.append("หมุดเยื้องมุม %d จุด (วงแดง — ใช้ Move Node ลากหมุดไปวางที่มุม)" % n_of)
        if not msg or quiet:
            return
        # ★ 2.4.0 (review DU-02) — คลิกวงแดงไม่ได้แก้อะไร (Add Node ไม่สร้างหมุดซ้ำ) ⇒ "คลิกเพื่อจัดการ" เฉพาะกากบาท/กรอบ
        _tail = (" — คลิกที่จุดนั้นเพื่อจัดการ" if not n_of
                 else " — คลิกกากบาท/กรอบเพื่อจัดการ" if (n_mk or n_nd or n_br) else "")
        self._push("แปลงนี้มี " + " · ".join(msg) + _tail, 0, 8)   # ★ 2.3.7 UX-01

    def _toggle(self, feat):
        # กันชน: ห้ามเลือกแปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
        if not self.ALLOW_LOCKED:
            tp = self.plugin._poly_type_str(self.poly_lyr, feat)
            if tp in L1_TYPES and not self.plugin._l1_unlocked():      # ★ 2.4.0 (DU-01) lock_rules
                try:                       # ★ 2.3.7 (review ER-06) — บอกแปลงด้วยระวาง/เลขที่ดิน แทน fid
                    _lab = self.plugin._feat_label(self.poly_lyr, feat)
                except Exception:
                    _lab = f"แปลง {feat.id()}"
                iface.messageBar().pushMessage(
                    self.TITLE, f"{_lab} เป็น {tp} (พิกัดอ้างอิง) — {self.DENY_MSG}",
                    level=1, duration=6)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธล็อก L1 ⇒ เหลือง (เดิมแดง)
                return
        # เลือกได้ทีละ 1 แปลง: คลิกแปลงใหม่ = แทนที่ • คลิกแปลงเดิมซ้ำ = ยกเลิก
        fid = feat.id()
        already = bool(self.picked) and self.picked[0][0] == fid
        self._clear_highlights()
        if already:
            self._push("ยกเลิกเลือกแปลง — คลิกเลือกแปลงใหม่ได้")        # ★ 2.3.7 UX-01
            return
        self.picked = [(fid, self._add_highlight(feat))]
        self._push(self.HINT)                                          # ★ 2.3.7 UX-01
        self._show_dups(feat)        # ★ 2.2.9 — ชี้ให้เห็นว่ามีของซ้อนตรงไหนบ้าง

    def _set_hover(self, feat):
        """ไฮไลต์แปลงใต้เมาส์ (เหลือง) — ข้ามถ้าเป็นแปลงที่เลือกอยู่แล้ว (เขียว)"""
        fid = feat.id() if feat is not None else None
        if feat is not None and self.picked and self.picked[0][0] == fid:
            feat, fid = None, None
        if fid == self._hover_fid:
            return
        self._hover_fid = fid
        if self._hover_rb is not None:
            try:
                self._canvas.scene().removeItem(self._hover_rb)
            except Exception:
                pass
            self._hover_rb = None
        if feat is None:
            return
        # แปลงอ้างอิง L1-RTK/L1-TS = แดง (ห้ามเลือก) • ปกติ = เหลือง · ★ admin ปลดล็อก -> ไม่แดง (แก้ได้)
        locked = (self.plugin._poly_type_str(self.poly_lyr, feat) in L1_TYPES      # ★ 2.4.0 (DU-01) lock_rules
                  and not self.plugin._l1_unlocked())
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        if locked:
            rb.setColor(QtGui.QColor(220, 0, 0))
            rb.setFillColor(QtGui.QColor(220, 0, 0, 45))
        else:
            rb.setColor(QtGui.QColor(255, 190, 0))
            rb.setFillColor(QtGui.QColor(255, 190, 0, 45))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        self._hover_rb = rb

    def canvasMoveEvent(self, event):
        if getattr(self, "_snap_mk", None) is None:
            return
        # เก็บตำแหน่งไว้ก่อน — query จริงเกิดใน _hover_tick ตามรอบ timer
        self._pending_pos = event.pos()
        if not self._hover_timer.isActive():
            self._hover_timer.start()

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None or getattr(self, "_snap_mk", None) is None:
            return
        map_pt = self.toMapCoordinates(pos)
        # ★ 2.3.7 (review DI-07) — ตัวบอกชี้เป้าเดียวกับที่คลิกจะได้: หมุด = วงกลม · มุมของแปลงที่เลือก = สี่เหลี่ยม
        #   (ใช้มุมที่จำไว้ ไม่ getFeature ทุกจังหวะเมาส์) · ล้ม = ถือว่าไม่มีเป้า (ไม่พ่น error จาก slot ของ timer)
        try:
            _pt, map_xy, _kind = self._pick_target(map_pt, fresh=False)
        except Exception:
            map_xy, _kind = None, None
        if map_xy is not None:
            # ★ 2.3.9 — ขอบตรงที่ไม่มีหมุด (ผู้ดูแล) = กากบาทบวก (จุด node ใหม่)
            self._snap_mk.setIconType(QgsVertexMarker.ICON_BOX if _kind == "vertex"
                                      else (QgsVertexMarker.ICON_CROSS if _kind == "edge"
                                            else QgsVertexMarker.ICON_CIRCLE))
            self._snap_mk.setCenter(QgsPointXY(map_xy))
            self._snap_mk.show()
            self._set_hover(None)        # อยู่บนหมุด/มุม -> ไม่ต้อง hover แปลง
        else:
            self._snap_mk.hide()
            self._set_hover(self._poly_at(map_pt, hover=True))      # ★ 2.4.0 (review PF-15) ใช้แคชของ hover

    # ★ 2.3.7 (DI-07) — หมุดห่างมุมไม่เกินนี้ (หน่วยชั้นหมุด = เมตร) = "มุมเดียวกัน" (เท่า TOL ของ _bare_nodes/_marker_exists_here)
    SAME_CORNER_TOL = 0.01

    def _picked_vertices(self, fresh=False):
        """★ 2.3.7 (review DI-07) — ทุกมุมของแปลงที่เลือก -> [QgsPointXY ใน CRS แผนที่]
        hover ใช้ของที่จำไว้ (อ่านใหม่เมื่อเปลี่ยนแปลงที่เลือก หรือ undo stack ของชั้นแปลงเปลี่ยน — ไม่ getFeature
        ทุก 80 มิลลิวินาที) · คลิกอ่านสดเสมอ (fresh=True)"""
        if not self.picked:
            return []
        try:
            _st = self.poly_lyr.undoStack()
            key = (tuple(f for f, _rb in self.picked), _st.index(), _st.count())
        except Exception:
            key = None
        if not fresh and key is not None and key == getattr(self, "_pv_key", None):
            return self._pv
        out = []
        for fid, _rb in self.picked:
            feat = self.poly_lyr.getFeature(fid)
            if not feat.isValid():
                continue
            g = feat.geometry()
            if g is None or g.isEmpty():
                continue
            for v in g.vertices():                       # CRS ของชั้นแปลง
                q = QgsPointXY(v.x(), v.y())
                if self._from_poly is not None:          # -> CRS แผนที่
                    try:
                        q = self._from_poly.transform(q)
                    except Exception:
                        continue
                out.append(q)
        self._pv, self._pv_key = out, key
        return out

    def _nearest_vertex(self, map_pt, fresh=True):
        """มุมของแปลงที่เลือกที่ใกล้ map_pt ที่สุดในรัศมี snap -> (xy CRS หมุด, xy CRS แผนที่) หรือ (None, None)
        ใช้รัศมีเดียวกับการ snap หมุด (`_snap_map_tol`)"""
        if not self.picked:
            return None, None
        try:
            tol = self._snap_map_tol()
            best, bestd = None, tol * tol
            for q in self._picked_vertices(fresh):
                d = (q.x() - map_pt.x()) ** 2 + (q.y() - map_pt.y()) ** 2
                if d < bestd:
                    bestd, best = d, q
            if best is None:
                return None, None
            return (self._to_pt.transform(best) if self._to_pt is not None else QgsPointXY(best)), QgsPointXY(best)
        except Exception:
            return None, None

    def _nearest_bare_vertex(self, map_pt):
        """มุมของ 'แปลงที่เลือกไว้' ที่ใกล้จุดคลิกที่สุด -> xy ใน CRS หมุด (หรือ None)

        ใช้รัศมีเดียวกับการ snap หมุด (`_snap_map_tol`) · อ่านรูปสด
        🔑 คืนค่าเป็น CRS ของ *ชั้นหมุด* เพราะ `_do_action` รับ snap_xy เป็น CRS นั้น
        """
        return self._nearest_vertex(map_pt, fresh=True)[0]

    def _free_edge_ok(self):
        """★ 2.3.9 — คลิกขอบตรงที่ไม่มีหมุดได้ไหม: เฉพาะ Add Node + ผู้ดูแล (โหมดผู้ดูแลเต็ม ไม่ใช่ผู้ช่วย)"""
        if not (self.ALLOW_FREE_EDGE and self.picked):
            return False
        try:
            return bool(self.plugin._is_admin())
        except Exception:
            return False

    def _picked_geoms(self, fresh=False):
        """★ 2.3.9 — รูปของแปลงที่เลือก (CRS ชั้นแปลง) · จำไว้แบบเดียวกับ `_picked_vertices` (hover ไม่ getFeature ทุกจังหวะ)"""
        if not self.picked:
            return []
        try:
            _st = self.poly_lyr.undoStack()
            key = (tuple(f for f, _rb in self.picked), _st.index(), _st.count())
        except Exception:
            key = None
        if not fresh and key is not None and key == getattr(self, "_pg_key", None):
            return self._pg
        out = []
        for fid, _rb in self.picked:
            f = self.poly_lyr.getFeature(fid)
            if f.isValid() and f.geometry() is not None and not f.geometry().isEmpty():
                out.append(QgsGeometry(f.geometry()))
        self._pg, self._pg_key = out, key
        return out

    def _nearest_edge_point(self, map_pt, fresh=True):
        """★ 2.3.9 — จุดบนขอบ (ทุกวง ทุกก้อน) ของแปลงที่เลือกที่ใกล้ map_pt สุด ภายในรัศมี snap
        -> (xy CRS หมุด, xy CRS แผนที่) หรือ (None, None) · จุดนี้อยู่บนขอบเป๊ะ ⇒ แทรก node แล้วหมุดอยู่บน node พอดี"""
        try:
            p = self._to_poly.transform(map_pt) if self._to_poly is not None else QgsPointXY(map_pt)
            best, bestd = None, None
            for g in self._picked_geoms(fresh):
                r = g.closestSegmentWithContext(QgsPointXY(p))
                d2, q = r[0], r[1]
                if d2 is None or d2 < 0:
                    continue
                if bestd is None or d2 < bestd:
                    bestd, best = d2, QgsPointXY(q)
            if best is None:
                return None, None
            bm = self._from_poly.transform(best) if self._from_poly is not None else QgsPointXY(best)
            # ★ rc2 (audit A1-01) — รัศมีของ "ขอบ" เป็นพิกเซลล้วน (EDGE_PX · ไม่มีพื้น 0.5 ม. แบบ snap หมุด/มุม)
            #   เดิมใช้ _snap_map_tol (12 px · พื้น 0.5 ม.) ⇒ ห้องแถวกว้าง 5 ม. ที่ 0.25 ม./px รัศมี 3 ม. ⇒ คลิกกลางแปลงข้างเคียง
            #   = แทรก node ลงขอบแปลงที่เลือก (และคลิกกลางแปลงที่เลือกเองก็ยกเลิกการเลือกไม่ได้) · ไม่เกินรัศมี snap เดิม
            _mupp = self._canvas.mapUnitsPerPixel()
            tol = min(self._snap_map_tol(), _mupp * self.EDGE_PX)
            d2 = bm.sqrDist(map_pt)
            if d2 > tol * tol:
                return None, None
            # ★ rc2 (audit A1-01) — จุดคลิกอยู่ "ในแปลงอื่นที่ไม่ได้เลือก" และห่างขอบเกิน EDGE_INSIDE_PX ⇒ ตั้งใจเลือกแปลงนั้น
            #   (ไม่ใช่แทรก node) · ชิดขอบร่วมมาก (≤ EDGE_INSIDE_PX) ยังแทรกได้จากทั้งสองฝั่ง
            if d2 > (_mupp * self.EDGE_INSIDE_PX) ** 2:
                _f = self._poly_at(map_pt, hover=not fresh)
                if _f is not None and _f.id() not in {fid for fid, _rb in self.picked}:
                    return None, None
            bx = self._to_pt.transform(bm) if self._to_pt is not None else QgsPointXY(bm)
            return bx, bm
        except Exception:
            return None, None

    def _edge_neighbour_hint(self, pt_xy, fids):
        """★ rc2 (audit A1 · ผู้ตรวจทานพบเพิ่ม) — แทรก node บนขอบให้แปลงที่เลือกแล้ว แต่จุดนั้นอยู่บนขอบของแปลงข้างเคียงที่ไม่ได้เลือกด้วย
        ⇒ แปลงข้างเคียงไม่ได้มุมตรงนั้น (มีหมุดของแปลงที่เลือกนั่งบนขอบของมัน) และด่านก่อนบันทึกไม่จับ ⇒ บอกบนแถบ (อ่านอย่างเดียว)
        เลือกแปลงข้างเคียงด้วยก่อนคลิก ⇒ _addnode_execute แทรก node ให้ทุกแปลงที่เลือก"""
        try:
            q = QgsPointXY(pt_xy)
            if self.point_lyr.crs() != self.poly_lyr.crs():
                try:
                    q = QgsCoordinateTransform(self.point_lyr.crs(), self.poly_lyr.crs(),
                                               QgsProject.instance()).transform(q)
                except Exception:
                    return
            tol = 0.001 if self.poly_lyr.crs().mapUnits() == QgsUnitTypes.DistanceMeters else 1e-8
            rect = QgsRectangle(q.x() - tol, q.y() - tol, q.x() + tol, q.y() + tol)
            gq = QgsGeometry.fromPointXY(q)
            sel = set(fids)
            n = 0
            for f in self.poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(50)):
                if f.id() in sel or not f.hasGeometry():
                    continue
                g = f.geometry()
                try:
                    _b = QgsGeometry(g.constGet().boundary()) if g.constGet() is not None else None
                except Exception:
                    _b = None
                if _b is not None and not _b.isEmpty() and _b.distance(gq) <= tol:
                    n += 1
            if n:
                self._push(f"จุดนี้อยู่บนขอบของแปลงข้างเคียง {n} แปลงที่ไม่ได้เลือกด้วย — แปลงนั้นไม่ได้มุมตรงนี้ "
                           "(ถ้าต้องการ: Undo แล้วเลือกแปลงนั้นด้วยก่อนคลิก)", 1, 10, title="Add Node")
        except Exception:
            pass

    def _pick_target(self, map_pt, fresh=True):
        """★ 2.3.7 (review DI-07) — เป้าของคลิก (และตัวบอกตอน hover)
        -> (xy CRS หมุด, xy CRS แผนที่, 'marker' | 'vertex') หรือ (None, None, None)

        เดิม: หมุดใดก็ได้ในรัศมี snap (ไม่ต่ำกว่า 0.5 ม.) ชนะเสมอ แล้วค่อยถอยไปหามุมเมื่อไม่มีหมุดเลย
          ⇒ คลิกตรงกากบาทมุมเปลือย V แต่หมุดที่เยื้องไป 20 ซม. ถูกเลือกแทน ⇒ แทรกมุมใหม่ข้าง V (หนามแหลม)
             และ V ยังไม่มีหมุด · ลบ Node คลิกมุมเกินข้างมุมที่มีหมุด แต่ได้มุมที่มีหมุดแทน
        ตอนนี้ (เครื่องมือที่คลิกมุมได้ = ALLOW_BARE_NODE และเลือกแปลงไว้แล้ว):
          หมุดห่างมุมนั้น ≤ 1 ซม. = มุมเดียวกัน ⇒ หมุดชนะ (มุมที่ตรงกันอยู่แล้วทำงานเหมือนเดิม)
          ไม่งั้น ตัวที่ใกล้จุดคลิกกว่าชนะ
        แก้ชื่อหมุด / สลับหมุด (ไม่รับมุม) = หมุดเท่านั้นเหมือนเดิม"""
        m_xy, m_map = self._nearest_marker(map_pt)
        v_xy = v_map = None
        if self.ALLOW_BARE_NODE and self.picked:
            v_xy, v_map = self._nearest_vertex(map_pt, fresh)
        if v_xy is None and m_xy is None and self._free_edge_ok():
            # ★ 2.3.9 — ผู้ดูแล: ไม่มีหมุด/มุมให้ snap ⇒ จุดบนขอบของแปลงที่เลือก (ถ้าคลิกใกล้ขอบในรัศมี snap)
            e_xy, e_map = self._nearest_edge_point(map_pt, fresh)
            if e_xy is not None:
                return e_xy, e_map, "edge"
        if v_xy is None:
            return (m_xy, m_map, "marker") if m_xy is not None else (None, None, None)
        if m_xy is None:
            return v_xy, v_map, "vertex"
        try:
            same = QgsPointXY(m_xy).distance(QgsPointXY(v_xy)) <= self.SAME_CORNER_TOL
        except Exception:
            same = False
        if same or QgsPointXY(m_map).sqrDist(map_pt) <= QgsPointXY(v_map).sqrDist(map_pt):
            return m_xy, m_map, "marker"
        return v_xy, v_map, "vertex"

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._cancel()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        map_pt = self.toMapCoordinates(event.pos())
        # ★ 2.3.7 (review DI-07) — เป้าเดียวกับตัวบอกตอน hover: หมุด หรือ "มุมของแปลงที่เลือก" (ดู _pick_target)
        #   เดิม: หมุดใดก็ได้ในรัศมี snap ชนะเสมอ แล้วค่อยถอยไปหามุมเปลือย (2.2.9) เมื่อไม่มีหมุดเลย
        #   `_addnode_execute` รองรับทั้งสองแบบ: มีมุมตรงนั้นแล้ว = ไม่แทรกซ้ำ แต่วางหมุดบนมุมนั้นให้
        #   และ `_marker_exists_here` กันไม่ให้ไปซ้อนหมุดเดิมของแปลงเดียวกัน
        pt_xy, _map_xy, _kind = self._pick_target(map_pt)
        if pt_xy is not None:
            # snap ติดหมุด/มุม -> วาง node (ต้องเลือกแปลงไว้ก่อน)
            if not self.picked:
                self._push("เลือกแปลงก่อน แล้วค่อยคลิกที่หมุด", 1, 5, title="Add Node")   # ★ 2.3.7 UX-01
                return
            fids = [f for f, _ in self.picked]
            if self.plugin._addnode_execute(self.poly_lyr, fids, pt_xy):
                if _kind == "edge":
                    self._edge_neighbour_hint(pt_xy, fids)        # ★ rc2 (audit A1 · ผู้ตรวจทานพบเพิ่ม)
                # อัปเดตไฮไลต์แปลงเพื่อโชว์ node ใหม่ที่เพิ่งเพิ่มเข้าไป
                for fid, rb in self.picked:
                    feat = self.poly_lyr.getFeature(fid)
                    if feat.isValid():
                        rb.setToGeometry(feat.geometry(), self.poly_lyr)
                # ★ 2.2.9 — วาดเครื่องหมาย "มุมที่ยังไม่มีหมุด" ใหม่ด้วย
                #   🔴 ไม่งั้นกากบาทเขียวของมุมที่เพิ่งเติมหมุดไปแล้วจะค้างบนจอ
                #      = ชี้จุดที่แก้เสร็จแล้ว พนักงานกดซ้ำแล้วไม่เกิดอะไร (หลอกตา)
                self._refresh_dups()
                self._canvas.refresh()
                # ★ 2.3.7 (review UX-01) — เลิกดัน "เพิ่มหมุดสำเร็จ" ทับสรุปของ _addnode_execute
                #   (เดิมขึ้นทุกครั้งที่คืน True รวมกรณีข้ามหมุด/ย้อนมุมไม่สำเร็จ · คำแนะนำ "คลิกต่อ/คลิกขวา" อยู่ท้ายสรุปแล้ว)
        else:
            # ไม่ติดหมุด -> เลือก/เอาแปลงออก
            feat = self._poly_at(map_pt)
            if feat is None:
                self._push("ไม่พบแปลง/หมุดตรงนี้ — คลิกในแปลง หรือเลื่อนให้ snap ติดหมุด", 1, 4,
                           title="Add Node")                         # ★ 2.3.7 UX-01
                return
            self._toggle(feat)

    def keyPressEvent(self, e):
        if _eat_del_key(self, e, self._del_key_back):      # ★ 2.3.7 (audit F1) ตระกูล Add Node/แก้ชื่อ/ลบ Node/สลับหมุด
            return
        if e.key() == QtCore.Qt.Key_Escape:
            self._cancel()

    def _del_key_back(self):
        """★ 2.3.7 (audit F1) — Backspace/Delete = "ถอย" ของเครื่องมือ (คืน True) · Add Node/แก้ชื่อ/ลบ Node ไม่มีขั้นให้ถอย ⇒ False
        (ไม่ตีความเป็น "ลบ node ตรงเมาส์" — ลบ Node ต้องคลิกเสมอ)"""
        return False

    def _clear_highlights(self):
        for _fid, rb in self.picked:
            try:
                self._canvas.scene().removeItem(rb)
            except Exception:
                pass
        self.picked = []
        self._clear_dups()        # ★ 2.2.9 — เครื่องหมายของซ้อนต้องหายพร้อมไฮไลต์แปลง

    def _remove_snap(self):
        if getattr(self, "_snap_mk", None) is not None:
            try:
                self._canvas.scene().removeItem(self._snap_mk)
            except Exception:
                pass
            self._snap_mk = None

    def _finish(self):
        self._canvas.refresh()
        iface.actionSelect().trigger()   # -> deactivate() ล้าง highlight/snap

    def _push(self, text, level=0, duration=None, title=None):
        """★ 2.3.7 (review UX-01) — ข้อความของเครื่องมือนี้ (จำไว้ ⇒ เลิกใช้แล้วลบเฉพาะของตัวเอง)"""
        return _bar_push_own(self, title or self.TITLE, text, level, duration)

    def _cancel(self):
        # ★ 2.3.7 (review UX-01) — เดิม clearWidgets() ล้าง "ทั้งแถบ" ทุกครั้งที่คลิกขวา/Esc (ซึ่งเป็นวิธีจบงานปกติ
        #   ของเครื่องมือตระกูลนี้) ⇒ คำเตือนที่ตั้งใจให้ค้าง เช่น '⚠️ มุมแปลงไม่มีหมุด' หลังบันทึก หรือผลของ ลบ Node
        #   ('⚠️ ชื่อหาย …') หายไปด้วย ⇒ ลบเฉพาะข้อความที่เครื่องมือนี้ดันเอง
        _bar_pop_own(self)
        iface.actionSelect().trigger()

    def deactivate(self):
        self._hover_timer.stop()
        self._pending_pos = None
        self._hover_cache.release()     # ★ 2.4.0 (review PF-07+PF-10+PF-15) — ถอดสัญญาณชั้น + ทิ้งแคช hover
        self._clear_highlights()
        self._set_hover(None)
        self._remove_snap()
        _bar_pop_own(self)            # ★ 2.3.7 (UX-01) — คำแนะนำของเครื่องมือนี้หมดหน้าที่แล้ว
        super().deactivate()



class DonutFrameTool(_MlepKeys, QgsMapTool):
    """★ 2.3.6 — 🍩 แบ่งหัก/แยก แบบ **คลิกหมุดสร้างกรอบ** (เจ้าของงานสั่ง 25 ก.ย. 69)
    *"เปลี่ยนการแบ่งหักเป็นการคลิกสร้างกรอบตามหมุดภายในแปลงแทน · และวนมาหมุดเดิม"*

    แปลงที่จะหักเลือกไว้แล้ว (ขั้นแรกของปุ่ม) · เครื่องมือนี้รับ "หมุดที่อยู่ในแปลง/บนขอบแปลง" ทีละดวง
    - เลื่อนเมาส์ใกล้หมุด = snap (วงกลมแดง) · **หมุดนอกแปลงไม่ snap** (กันกรอบหลุดไปแปลงอื่น)
    - คลิกหมุดทีละดวงตามแนวกรอบ (เส้นส้ม · หมุดดวงแรกวงเขียว)
    - **คลิกหมุดดวงแรกซ้ำ (หรือคลิกขวา / Enter) = ปิดกรอบแล้วหัก** (ต้องมีอย่างน้อย 3 ดวง)
    - Backspace / Delete = ถอยหมุดล่าสุด · Esc = ยกเลิก
    ★ audit 25 ก.ย. 69 — กรอบค้างให้เห็นตอนกล่องยืนยัน · ไม่ได้หัก (กรอบผิด/ตอบไม่) = หมุดที่คลิกยังอยู่ แก้ต่อได้ ·
      คลิกขวา = ปิดกรอบ (เหมือน 2.3.5 ที่คลิกขวา = ลงมือ) ไม่ใช่ทิ้งทุกอย่าง
    ใช้สูตร snap ชุดเดียวกับ Add Node (`_snap_map_tol` — มีกับดักหน่วยของแคนวาส ห้ามเขียนใหม่)
    """
    _snap_map_tol = AddNodeTool._snap_map_tol
    # หมุด "อยู่ในแปลง" = อยู่ในแปลง หรือห่างขอบแปลงไม่เกิน 0.5 ม. (รวมหมุดบนขอบ/มุมเดิม)
    # 🔑 ไม่ใช้ 1 ซม. — เคสจริงของเจ้าของงาน (องครักษ์ gid 20265 + แปลงที่แบ่งแยกไปแล้ว gid 20187)
    #    มุมของแปลงย่อย 2 ใน 5 มุมอยู่นอกแปลงเต็ม 5.4 ซม. และ 6.7 ซม. (รูปวาดไม่ตรงหมุดเป๊ะ)
    #    ⇒ 1 ซม. = คลิกหมุดจริงของงานนี้ไม่ได้ · 0.5 ม. ยังกันหมุดกลางแปลงข้างเคียงได้
    TOL_IN = 0.5
    TOL_SAME = 0.001    # ตำแหน่งเดียวกัน ≤ 1 มม.
    # ★ audit 25 ก.ย. — ปิดกรอบเมื่อคลิกหมุดที่ห่างดวงแรกไม่เกิน 5 ซม. (เดิม 1 มม.)
    #   มีหมุดอีกดวงห่างดวงแรก 3 ซม. แล้วคลิกปิดกรอบพลาดไปโดนดวงนั้น 2 ใน 5 ครั้ง
    #   ⇒ ได้ขอบกรอบยาว 3 ซม. หรือกรอบผีเสื้อที่ถูกปฏิเสธทั้งกรอบ
    TOL_CLOSE = 0.05
    TITLE = "แบ่งหัก/แยก"

    def __init__(self, canvas, plugin, poly_lyr, point_lyr, outer_geom, done_cb, outer_fid=None):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.outer_geom = QgsGeometry(outer_geom)          # CRS ชั้นแปลง
        self.outer_fid = outer_fid                          # อ่านรูปสดทุกคลิก (หลัง Undo รูปเปลี่ยน)
        try:
            self._undo_ix = poly_lyr.undoStack().index()
        except Exception:
            self._undo_ix = None
        self._own_item = None                               # ข้อความแนะนำของเครื่องมือนี้ (มีได้ทีละอัน)
        self.done_cb = done_cb
        self.pts = []                                       # [QgsPointXY] CRS ชั้นหมุด
        self.setCursor(QtCore.Qt.CrossCursor)
        self._build_xforms()        # ★ rc1 (DI-03) สร้างใหม่เมื่อ CRS/datum ของโปรเจกต์เปลี่ยน (_MlepKeys._xf_watch)
        self._snap_mk = self._first_mk = self._rb = None
        self._make_marks()                                  # ★ 2.3.7 (LC-09) — แยกออกมาให้ activate() สร้างคืนได้
        self._pending_pos = None
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(80)
        self._hover_timer.timeout.connect(self._hover_tick)

    def _make_marks(self):
        """★ 2.3.7 (review LC-09) — สร้างตัวบอกบนแคนวาสที่ยังไม่มี (ตอนสร้างเครื่องมือ + ตอนถูกเปิดกลับมา)"""
        canvas = self._canvas
        if getattr(self, "_snap_mk", None) is None:
            self._snap_mk = QgsVertexMarker(canvas)
            self._snap_mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
            self._snap_mk.setColor(QtGui.QColor(255, 0, 0))
            self._snap_mk.setPenWidth(3)
            self._snap_mk.setIconSize(14)
            self._snap_mk.hide()
        if getattr(self, "_first_mk", None) is None:
            self._first_mk = QgsVertexMarker(canvas)        # หมุดดวงแรก = จุดที่ต้องคลิกซ้ำเพื่อปิดกรอบ
            self._first_mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
            self._first_mk.setColor(QtGui.QColor(0, 170, 0))
            self._first_mk.setPenWidth(3)
            self._first_mk.setIconSize(20)
            self._first_mk.hide()
        if getattr(self, "_rb", None) is None:
            self._rb = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
            self._rb.setColor(QtGui.QColor(255, 120, 0))
            self._rb.setWidth(3)

    def _build_xforms(self):
        """★ rc1 (DI-03) ตัวแปลง CRS โปรเจกต์ ↔ ชั้นหมุด · ชั้นหมุด → ชั้นแปลง (ชั้นเดียวกัน = None)"""
        proj = QgsProject.instance()
        poly_lyr, point_lyr = self.poly_lyr, self.point_lyr
        self._to_pt = (QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj)
                       if point_lyr.crs() != proj.crs() else None)
        self._from_pt = (QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
                         if point_lyr.crs() != proj.crs() else None)
        self._pt_to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj)
                            if point_lyr.crs() != poly_lyr.crs() else None)

    def activate(self):
        # ★ 2.3.7 (review LC-09) — deactivate() เอาวงกลม snap · หมุดดวงแรก · เส้นกรอบ ออกจากแคนวาส (ตั้งเป็น None)
        #   เครื่องมือตัวเดิมที่ถูกเปิดกลับมา (หลังวาดเส้นจากหน้าต่างวาดเส้น) จึงไม่มีตัวบอกเลย
        #   ⇒ สร้างคืน แล้ววาดกรอบที่คลิกไว้แล้ว (self.pts ยังอยู่) ให้เห็นอีกครั้ง
        super().activate()
        self._make_marks()
        self._redraw()

    # ── หมุดที่คลิกได้ = อยู่ในแปลง/บนขอบแปลง ──
    def _in_outer(self, pt_xy):
        try:
            # ★ 2.3.7 (review DU-12-D) — แปลงพิกัดเข้ามาอยู่ใน try (ล้ม = ถือว่าอยู่นอกแปลง)
            q = self._pt_to_poly.transform(pt_xy) if self._pt_to_poly else QgsPointXY(pt_xy)
            return self.outer_geom.distance(QgsGeometry.fromPointXY(QgsPointXY(q))) <= self.TOL_IN
        except Exception:
            return False

    def _refresh_outer(self):
        """อ่านรูปแปลงสดจากชั้น (รวมบัฟเฟอร์) — ★ audit 25 ก.ย.: กด ↺ Undo ระหว่างเครื่องมือนี้ทำงาน
        รูปแปลงกลับเป็นเดิม แต่เครื่องมือยังใช้รูปตอนติดตั้ง ⇒ หมุดในแปลงที่คืนมาถูกปฏิเสธ
        อ่านเฉพาะตอนคลิก (ไม่ใช่ทุกครั้งที่เลื่อนเมาส์ — ชั้น PostGIS = ถามฐาน 1 ครั้ง)"""
        if self.outer_fid is None:
            return
        try:
            f = self.poly_lyr.getFeature(self.outer_fid)
            if f is not None and f.isValid() and f.geometry() is not None and not f.geometry().isEmpty():
                self.outer_geom = QgsGeometry(f.geometry())
        except Exception:
            pass

    def _nearest_marker(self, map_pt):
        """หมุดใกล้สุดในรัศมี snap -> (xy ใน CRS หมุด, xy ใน CRS แผนที่) · ดวงใกล้สุดอยู่นอกแปลง = (None, None)
        ★ audit 25 ก.ย. — เดิมกรองหมุดนอกแปลงทิ้ง "ก่อน" หาดวงใกล้สุด ⇒ เล็งหมุดที่อยู่นอกแปลง 0.6 ม.
          แล้ว snap ไปหมุดอีกดวงที่ห่าง 2 ม. เงียบ ๆ · ตอนนี้หาดวงใกล้สุดก่อน แล้วค่อยตรวจว่าอยู่ในแปลง"""
        map_tol = self._snap_map_tol()
        rect = QgsRectangle(map_pt.x() - map_tol, map_pt.y() - map_tol, map_pt.x() + map_tol, map_pt.y() + map_tol)
        if self._to_pt is not None:
            try:
                rect = self._to_pt.transformBoundingBox(rect)
            except Exception:
                pass
        best = best_map = None
        bestd = map_tol * map_tol
        _it = self.point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes())
        try:
            for f in _it:
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                xy = g.asPoint()
                map_xy = self._from_pt.transform(xy) if self._from_pt else QgsPointXY(xy)
                d = (map_xy.x() - map_pt.x()) ** 2 + (map_xy.y() - map_pt.y()) ** 2
                if d <= bestd:
                    bestd, best, best_map = d, xy, map_xy
        finally:
            _it.close()
        if best is None or not self._in_outer(best):
            return (None, None)
        return (best, best_map)

    # ── หัวใจ: รับหมุด 1 ดวง (แยกจากเหตุการณ์เมาส์ เพื่อให้เทสเรียกตรงได้) ──
    def add_point(self, pt_xy):
        """คืน 'ปิด' (ปิดกรอบแล้วส่งให้หัก) · 'เพิ่ม' · หรือเหตุที่ไม่รับ"""
        pt_xy = QgsPointXY(pt_xy)
        if not self._in_outer(pt_xy):
            return "นอกแปลง"
        if self.pts and pt_xy.distance(self.pts[0]) <= self.TOL_CLOSE:
            return self.close_frame()
        if self.pts and pt_xy.distance(self.pts[-1]) <= self.TOL_SAME:
            return "ซ้ำดวงล่าสุด"
        if any(pt_xy.distance(q) <= self.TOL_SAME for q in self.pts):
            return "ซ้ำในกรอบ"
        self.pts.append(pt_xy)
        self._redraw()
        return "เพิ่ม"

    def close_frame(self):
        """ปิดกรอบ (คลิกหมุดดวงแรกซ้ำ / คลิกขวา / Enter) แล้วส่งให้หัก
        ★ audit 25 ก.ย. — วาดกรอบปิดค้างไว้ให้เห็นตอนกล่องยืนยัน (เดิมล้างก่อนถาม = ยืนยันทั้งที่มองไม่เห็นกรอบ)
          หักสำเร็จ = ผู้เรียกติดตั้งเครื่องมือกรอบตัวใหม่ทับตัวนี้ (ตัวนี้ถูก deactivate แล้ว)
          ไม่ได้หัก (กรอบผิด/ตอบไม่/ถูกปฏิเสธ) = หมุดที่คลิกไว้ยังอยู่ ถอย/แก้ต่อได้"""
        if len(self.pts) < 3:
            return "ยังไม่ครบ 3"
        pts = list(self.pts)
        self._redraw(closed=True)
        self.done_cb(pts)                   # 🔑 เรียกท้ายสุด — ผู้เรียกอาจติดตั้งเครื่องมือใหม่ทับตัวนี้
        if getattr(self, "_first_mk", None) is not None:
            self._redraw()                  # ยังเป็นเครื่องมือที่ใช้อยู่ = ไม่ได้หัก ⇒ เปิดกรอบให้แก้ต่อ
        return "ปิด"

    def undo_point(self):
        if self.pts:
            self.pts.pop()
            self._redraw()

    def _map_xy(self, pt_xy):
        return self._from_pt.transform(pt_xy) if self._from_pt else QgsPointXY(pt_xy)

    def _crs_redraw(self):
        """★ rc2 (audit A1-04) — กรอบ 🍩 / ➕ ที่คลิกไว้วาดใหม่ด้วย CRS ปัจจุบัน (เดิมวาดใหม่เฉพาะตอนคลิก ⇒ ค้างพิกัดเดิม)"""
        try:
            self._redraw()
        except Exception:
            pass

    def _redraw(self, closed=False):
        if getattr(self, "_rb", None) is None:
            return
        try:
            self._rb.reset(QgsWkbTypes.LineGeometry)
            for q in self.pts:
                self._rb.addPoint(self._map_xy(q), True)
            if closed and self.pts:
                self._rb.addPoint(self._map_xy(self.pts[0]), True)
            if getattr(self, "_first_mk", None) is None:
                return
            if self.pts:
                self._first_mk.setCenter(self._map_xy(self.pts[0]))
                self._first_mk.show()
            else:
                self._first_mk.hide()
        except Exception:
            pass

    def _reset_frame(self):
        self.pts = []
        self._redraw()

    def _push(self, text, level=0, duration=12):
        """ข้อความของเครื่องมือนี้ **มีได้ทีละอัน** (★ audit 25 ก.ย.)
        เดิมดันข้อความใหม่ทุกคลิก ⇒ พอข้อความบนสุดหมดเวลา ของเก่า ("คลิกแล้ว 1 ดวง") โผล่กลับมา
        และถ้ากด Esc ก็ล้างข้อความทั้งแถบรวมทั้งผลลัพธ์/คำเตือนสำคัญของขั้นก่อน"""
        self._pop_own()
        bar = iface.messageBar()
        try:
            from qgis.gui import QgsMessageBar
            item = QgsMessageBar.createMessage(self.TITLE, text)
            bar.pushWidget(item, level, duration)
            self._own_item = item
        except Exception:
            try:
                bar.pushMessage(self.TITLE, text, level=level, duration=duration)
            except Exception:
                pass

    def _pop_own(self):
        it, self._own_item = getattr(self, "_own_item", None), None
        if it is not None:
            try:
                iface.messageBar().popWidget(it)
            except Exception:
                pass                        # หมดเวลาไปเองแล้ว (C++ ถูกลบ) — ไม่เป็นไร

    def _hint(self):
        n = len(self.pts)
        # ★ 2.3.7 (review UX-29) — แถบข้อความแสดง HTML ⇒ <b> แทน ** (เดิม ** โผล่ตรง ๆ)
        self._push((f"② คลิก <b>หมุดในแปลง</b> ทีละดวงตามแนวกรอบ (คลิกแล้ว {n} ดวง) • "
                    + ("<b>คลิกหมุดดวงแรก (วงเขียว) ซ้ำ หรือคลิกขวา = ปิดกรอบแล้วหัก</b>" if n >= 3
                       else "ต้องมีอย่างน้อย 3 ดวง")
                    + " • Backspace = ถอย • Esc = ยกเลิก"), 0, 12)

    # ── เหตุการณ์เมาส์/คีย์บอร์ด ──
    def canvasMoveEvent(self, event):
        if getattr(self, "_snap_mk", None) is None:
            return
        self._pending_pos = event.pos()
        if not self._hover_timer.isActive():
            self._hover_timer.start()

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None or getattr(self, "_snap_mk", None) is None:
            return
        # ★ audit รอบ 2 — กด ↺ Undo แล้ววงกลมแดงไม่ขึ้นบนหมุดในส่วนที่คืนมา (อ่านรูปใหม่แค่ตอนคลิก)
        #   ⇒ อ่านรูปใหม่เมื่อเลขลำดับ Undo ของชั้นแปลงเปลี่ยน (ไม่ถามฐานทุกครั้งที่เลื่อนเมาส์)
        try:
            _ix = self.poly_lyr.undoStack().index()
            if _ix != getattr(self, "_undo_ix", None):
                self._undo_ix = _ix
                self._refresh_outer()
        except Exception:
            pass
        try:
            _pt, map_xy = self._nearest_marker(self.toMapCoordinates(pos))
        except Exception:
            map_xy = None                   # ชั้นหมุดถูกเอาออกกลางคัน — ไม่พ่น error ทุกจังหวะเมาส์
        if map_xy is not None:
            self._snap_mk.setCenter(QgsPointXY(map_xy))
            self._snap_mk.show()
        else:
            self._snap_mk.hide()

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._close_or_warn()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        self._refresh_outer()
        try:
            pt_xy, _m = self._nearest_marker(self.toMapCoordinates(event.pos()))
        except RuntimeError:
            # audit รอบ 3 — ชั้นหมุดถูกเอาออกจากโปรเจกต์กลางคัน (C++ ถูกลบ) ⇒ เดิมเด้งกล่อง error ของ Python ทุกคลิก
            # ★ 2.3.7 (b12 · กติกาสีของเจ้าของงาน) — เลิกงานโดยยังไม่ได้แตะอะไร = ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            self._push("ชั้นหมุดถูกปิด/เอาออกจากโปรเจกต์แล้ว — เลิกแบ่งหัก (กด 🍩 ใหม่)", 1, 8)
            iface.actionSelect().trigger()
            return
        if pt_xy is None:
            self._push("คลิกที่ <b>หมุดที่อยู่ในแปลง</b> (เลื่อนเมาส์ให้ขึ้นวงกลมแดงก่อน)", 1, 5)     # ★ 2.3.7 UX-29
            return
        r = self.add_point(pt_xy)
        if r == "ปิด":
            return
        if r == "ยังไม่ครบ 3":
            self._push("กรอบต้องมีหมุดอย่างน้อย 3 ดวงก่อนปิด", 1, 5)
        elif r == "ซ้ำในกรอบ":
            self._push("หมุดนี้อยู่ในกรอบแล้ว — กรอบจะตัดกันเอง (ปิดกรอบให้คลิกหมุดดวงแรก วงเขียว)", 1, 6)
        elif r == "ซ้ำดวงล่าสุด":
            self._push("หมุดดวงนี้เพิ่งคลิกไป — ปิดกรอบให้คลิกหมุดดวงแรก (วงเขียว) หรือคลิกขวา", 1, 5)
        elif r == "เพิ่ม":
            self._hint()

    def _close_or_warn(self):
        if self.close_frame() == "ยังไม่ครบ 3":
            self._push("กรอบต้องมีหมุดอย่างน้อย 3 ดวงก่อนปิด (Esc = เลิก)", 1, 5)

    def keyPressEvent(self, e):
        # 🔴 audit รอบ 2 — ใน QGIS เครื่องมือต้อง **ignore()** คีย์ที่ใช้เอง (ความหมายกลับด้านที่ QGIS คงไว้เพื่อ API เดิม)
        #   ไม่งั้นแคนวาสยิง keyPressed ต่อ แล้ว QgisApp::mapCanvas_keyPressed เจอ Backspace/Delete
        #   ⇒ สั่ง "ลบฟีเจอร์ที่เลือกไว้" ของชั้นที่ใช้อยู่ **โดยไม่ถาม** (ถ้าฟีเจอร์ที่เลือกอยู่ในจอ)
        k = e.key()
        if k == QtCore.Qt.Key_Escape:
            self._cancel()
        elif k in (QtCore.Qt.Key_Backspace, QtCore.Qt.Key_Delete):
            self.undo_point()
            self._hint()
        elif k in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
            self._close_or_warn()
        else:
            return
        try:
            e.ignore()
        except Exception:
            pass

    def _cancel(self):
        self._pop_own()                     # ★ ลบเฉพาะข้อความของเครื่องมือนี้ (ไม่ล้างผลลัพธ์/คำเตือนของขั้นก่อน)
        iface.actionSelect().trigger()

    def deactivate(self):
        self._hover_timer.stop()
        self._pending_pos = None
        for _n in ("_snap_mk", "_first_mk"):
            _m = getattr(self, _n, None)
            if _m is not None:
                try:
                    self._canvas.scene().removeItem(_m)
                except Exception:
                    pass
                setattr(self, _n, None)
        # ★ audit 25 ก.ย. — เดิมแค่ reset เส้นส้ม ไม่เอาออกจากฉาก ⇒ ค้างในแผนที่ 1 เส้นต่อ 1 กรอบ
        #   (24 กรอบ = 24 เส้นค้าง อยู่รอดแม้ unload)
        _rb = getattr(self, "_rb", None)
        if _rb is not None:
            try:
                _rb.reset(QgsWkbTypes.LineGeometry)
                self._canvas.scene().removeItem(_rb)
            except Exception:
                pass
            self._rb = None
        self._pop_own()
        super().deactivate()



class CreateParcelTool(DonutFrameTool):
    """★ 2.3.9 — ➕ สร้างรูปแปลง (เจ้าของงานสั่ง 11 ต.ค. 69: "สร้างรูปแปลง ตามหมุดหรือคลิกที่ว่างได้")
    คลิกทีละจุดตามแนวแปลง · เป้าของคลิก (ตัวบอกตอนเลื่อนเมาส์):
      จุดแรกของรูป (วงเขียว · ปิดรูป) → หมุดใกล้สุด (วงกลมแดง) → มุมของแปลงใกล้สุด (สี่เหลี่ยมแดง) → ไม่ติดอะไร = จุดที่คลิก
    - คลิกจุดแรกซ้ำ / คลิกขวา / Enter = ปิดรูป (≥ 3 จุด) แล้วไปกล่องกรอกคีย์ (ผู้เรียกจัดการต่อ)
    - Backspace / Delete = ถอยจุดล่าสุด · Esc = เลิก
    ต่อยอดจาก DonutFrameTool (กรอบจากหมุดของ 🍩) แต่ไม่มี "แปลงที่จะหัก" ⇒ รับหมุดได้ทุกที่ + รับที่ว่าง
    done_cb(pts, kinds) — pts = พิกัด CRS ชั้นหมุด · kinds = 'marker' | 'vertex' | 'free' ต่อจุด"""
    TITLE = "สร้างรูปแปลง"

    def __init__(self, canvas, plugin, poly_lyr, point_lyr, done_cb):
        super().__init__(canvas, plugin, poly_lyr, point_lyr, QgsGeometry(), done_cb, outer_fid=None)
        self.kinds = []
        self._build_xforms()        # ★ rc1 (DI-03) (super().__init__ สร้างของ DonutFrameTool แล้ว · สร้างซ้ำครบชุดได้)

    def _build_xforms(self):
        """★ rc1 (DI-03) ตัวแปลงของ DonutFrameTool + CRS โปรเจกต์ ↔ ชั้นแปลง · ชั้นแปลง → ชั้นหมุด"""
        super()._build_xforms()
        proj = QgsProject.instance()
        poly_lyr, point_lyr = self.poly_lyr, self.point_lyr
        self._to_poly = (QgsCoordinateTransform(proj.crs(), poly_lyr.crs(), proj)
                         if poly_lyr.crs() != proj.crs() else None)
        self._from_poly = (QgsCoordinateTransform(poly_lyr.crs(), proj.crs(), proj)
                           if poly_lyr.crs() != proj.crs() else None)
        self._poly_to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), proj)
                            if poly_lyr.crs() != point_lyr.crs() else None)

    def _in_outer(self, pt_xy):
        return True                                         # ไม่มีแปลงกรอบ — รับได้ทุกที่

    def _refresh_outer(self):
        return

    def _nearest_parcel_vertex(self, map_pt, tol):
        """มุมของแปลงใด ๆ ที่ใกล้ map_pt สุดในรัศมี tol (หน่วยแผนที่) -> (xy CRS หมุด, xy แผนที่) หรือ None"""
        try:
            rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol, map_pt.x() + tol, map_pt.y() + tol)
            if self._to_poly is not None:
                rect = self._to_poly.transformBoundingBox(rect)
            best = None
            bestd = tol * tol
            _it = self.poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(200))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    for v in g.vertices():
                        q = QgsPointXY(v.x(), v.y())
                        qm = self._from_poly.transform(q) if self._from_poly is not None else q
                        d = qm.sqrDist(map_pt)
                        if d <= bestd:
                            bestd, best = d, (q, qm)
            finally:
                _it.close()
            if best is None:
                return None
            q, qm = best
            return (self._poly_to_pt.transform(q) if self._poly_to_pt is not None else QgsPointXY(q)), QgsPointXY(qm)
        except Exception:
            return None

    def _snap_target(self, map_pt):
        """เป้าของคลิก -> (xy CRS หมุด, xy แผนที่, ชนิด) · ชนิด = 'first' | 'marker' | 'vertex' | 'free'"""
        tol = self._snap_map_tol()
        if len(self.pts) >= 3:
            f_map = self._map_xy(self.pts[0])
            if f_map.sqrDist(map_pt) <= tol * tol:
                return QgsPointXY(self.pts[0]), f_map, "first"
        m_xy, m_map = DonutFrameTool._nearest_marker(self, map_pt)
        if m_xy is not None:
            return QgsPointXY(m_xy), QgsPointXY(m_map), "marker"
        v = self._nearest_parcel_vertex(map_pt, tol)
        if v is not None:
            return v[0], v[1], "vertex"
        try:
            xy = self._to_pt.transform(map_pt) if self._to_pt is not None else QgsPointXY(map_pt)
        except Exception:
            return None, None, None
        return QgsPointXY(xy), QgsPointXY(map_pt), "free"

    def add_point(self, pt_xy, kind="free"):
        """คืน 'ปิด' · 'เพิ่ม' · หรือเหตุที่ไม่รับ (แบบเดียวกับ DonutFrameTool)"""
        pt_xy = QgsPointXY(pt_xy)
        if self.pts and pt_xy.distance(self.pts[0]) <= self.TOL_CLOSE:
            return self.close_frame()
        if self.pts and pt_xy.distance(self.pts[-1]) <= self.TOL_SAME:
            return "ซ้ำดวงล่าสุด"
        if any(pt_xy.distance(q) <= self.TOL_SAME for q in self.pts):
            return "ซ้ำในกรอบ"
        self.pts.append(pt_xy)
        self.kinds.append(kind if kind in ("marker", "vertex", "free") else "free")
        self._redraw()
        return "เพิ่ม"

    def undo_point(self):
        if self.pts:
            self.pts.pop()
            if self.kinds:
                self.kinds.pop()
            self._redraw()

    def _reset_frame(self):
        self.pts, self.kinds = [], []
        self._redraw()

    def close_frame(self):
        if len(self.pts) < 3:
            return "ยังไม่ครบ 3"
        pts, kinds = list(self.pts), list(self.kinds)
        self._redraw(closed=True)
        self.done_cb(pts, kinds)            # 🔑 เรียกท้ายสุด — ผู้เรียกอาจติดตั้งเครื่องมือใหม่ทับตัวนี้
        if getattr(self, "_first_mk", None) is not None:
            self._redraw()                  # ยังเป็นเครื่องมือที่ใช้อยู่ = ยังไม่ได้สร้าง ⇒ เปิดรูปให้แก้ต่อ
        return "ปิด"

    def _hint(self):
        n = len(self.pts)
        self._push((f"คลิก <b>หมุด</b> (วงกลมแดง) · <b>มุมแปลง</b> (สี่เหลี่ยม) หรือ <b>ที่ว่าง</b> ทีละจุดตามแนวแปลง "
                    f"(คลิกแล้ว {n} จุด) • "
                    + ("<b>คลิกจุดแรก (วงเขียว) ซ้ำ หรือคลิกขวา = ปิดรูป</b>" if n >= 3 else "ต้องมีอย่างน้อย 3 จุด")
                    + " • Backspace = ถอย • Esc = เลิก"), 0, 15)

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None or getattr(self, "_snap_mk", None) is None:
            return
        try:
            _xy, map_xy, kind = self._snap_target(self.toMapCoordinates(pos))
        except Exception:
            map_xy, kind = None, None
        if map_xy is not None and kind in ("marker", "vertex", "first"):
            self._snap_mk.setIconType(QgsVertexMarker.ICON_BOX if kind == "vertex" else QgsVertexMarker.ICON_CIRCLE)
            self._snap_mk.setCenter(QgsPointXY(map_xy))
            self._snap_mk.show()
        else:
            self._snap_mk.hide()

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._close_or_warn()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        try:
            pt_xy, _m, kind = self._snap_target(self.toMapCoordinates(event.pos()))
        except RuntimeError:
            self._push("ชั้นแปลง/ชั้นหมุดถูกปิดหรือเอาออกจากโปรเจกต์แล้ว — เลิกสร้างรูปแปลง (กดปุ่มใหม่)", 1, 8)
            iface.actionSelect().trigger()
            return
        if pt_xy is None:
            self._push("แปลงพิกัดจุดที่คลิกไม่ได้ — คลิกใหม่", 1, 5)
            return
        r = self.add_point(pt_xy, kind)
        if r == "ปิด":
            return
        if r == "ยังไม่ครบ 3":
            # ★ rc2 (audit A1-05) — คลิกจุดแรกซ้ำตอนมีไม่ถึง 3 จุด (เดิมเงียบ · 🍩 บอกเหตุอยู่แล้ว)
            self._push("รูปแปลงต้องมีอย่างน้อย 3 จุดก่อนปิด — คลิกจุดถัดไปตามแนวแปลงต่อ (Esc = เลิก)", 1, 5)
        elif r == "ซ้ำในกรอบ":
            self._push("จุดนี้อยู่ในรูปแล้ว — รูปจะตัดกันเอง (ปิดรูปให้คลิกจุดแรก วงเขียว)", 1, 6)
        elif r == "ซ้ำดวงล่าสุด":
            self._push("จุดนี้เพิ่งคลิกไป — ปิดรูปให้คลิกจุดแรก (วงเขียว) หรือคลิกขวา", 1, 5)
        elif r == "เพิ่ม":
            self._hint()

    def _close_or_warn(self):
        if self.close_frame() == "ยังไม่ครบ 3":
            self._push("รูปแปลงต้องมีอย่างน้อย 3 จุดก่อนปิด (Esc = เลิก)", 1, 5)


class SyncVertexTool(_MlepKeys, QgsMapTool):
    """เลือกและเลื่อนหมุดหลายเลเยอร์พร้อมกัน
    - คลิกเดี่ยว: คลิกหมุด -> เลือก 1 หมุด แล้ว "คลิกตำแหน่งใหม่" เพื่อย้าย (click-to-move)
    - หลายหมุด: ลากกล่องครอบหลายหมุด แล้วลากหมุดที่เลือกเพื่อย้าย (Shift+ลาก = เลือกเพิ่ม)
    - คลิกขวาเพื่อยกเลิก/เสร็จสิ้น"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.setCursor(QtCore.Qt.CrossCursor)
        
        self.selected_vertices = [] # [{'layer': lyr, 'fid': id, 'vidx': idx, 'pt': QgsPointXY, 'marker': QgsVertexMarker}]
        self.selected_keys = set() # O(1) lookup for (layer_id, fid, vidx)
        self.picked = [] # list of (fid, rubberband)
        self.drag_start_pt = None
        self.box_band = None
        self.drag_band = None
        self.is_moving = False
        self.armed = False          # โหมดคลิกเดี่ยว: เลือกหมุดแล้วรอ "คลิกครั้งถัดไป" เพื่อย้าย
        self.move_anchor = None     # ตำแหน่งอ้างอิงที่ย้ายจาก (โหมด armed)
        self._placing = False       # press ปัจจุบันคือ "คลิกปลายทาง" (สั่งย้ายตอน release)
        self.move_guide = None      # เส้นนำตอน armed (จากจุดอ้างอิงไปเมาส์)
        self._press_pos = None      # ★ 2.3.7 (UX-11) ตำแหน่งบนจอตอนกด — ใช้แยก "คลิกเฉย ๆ" กับ "ลากจริง" ตอนปล่อย
        self._stack_scope = None    # ★ 2.3.7 (UX-12) ชิ้นที่ _stacked_marker_count นับ (None = ทั้งการเลือก)

        self.snap_marker = QgsVertexMarker(self._canvas)
        self.snap_marker.setIconType(QgsVertexMarker.ICON_CROSS)
        self.snap_marker.setColor(QtGui.QColor(255, 0, 255))
        self.snap_marker.setPenWidth(2)
        self.snap_marker.hide()

    def activate(self):
        # ★ 2.3.7 (review LC-09) — deactivate() เอากากบาท snap (ม่วง) ออกจากแคนวาสแต่ยังถือตัวไว้
        #   ⇒ เครื่องมือตัวเดิมที่ถูกเปิดกลับมา (หลังวาดเส้น) ไม่มีกากบาทอีกเลย ⇒ ใส่คืนเข้าแคนวาส
        super().activate()
        _m = getattr(self, "snap_marker", None)
        if _m is not None:
            try:
                if _m.scene() is None:
                    self._canvas.scene().addItem(_m)
            except Exception:
                pass

    # ★ 28 ส.ค. 69 (audit 2.10) — รัศมี "คลิกเลือกจุดเดียว" ต้องมีเพดานเป็นเมตร
    #   เดิมเป็นพิกเซลล้วน (mapUnitsPerPixel * 5 ไม่มีเพดาน):
    #      1:500 -> 0.66 ม. (ปกติดี) · 1:1000 -> 1.3 ม. · zoom ทั้งระวาง (1 px ~ 1 ม.) -> 5 ม.
    #      = คลิกเดียวคว้ามุม+หมุดหลายแปลงมาย้ายทั้งก้อน
    #   วัดจากข้อมูลจริง 8,760 ตัวอย่าง 3 อำเภอ (ระยะถึงหมุดตัวถัดไปที่ "คนละตำแหน่ง"):
    #      เพดาน   เสี่ยงคว้าของข้างเคียง   = กี่ px ที่ 1:500
    #       0.50            2.49%                3.8
    #       0.60            3.21%                4.5   <-- เลือกตัวนี้
    #       0.66            3.89%                5.0   (เท่าของเดิมเป๊ะ)
    #       1.00            6.18%                7.6
    #      ไม่มีเพดาน       36% ที่ zoom ทั้งระวาง
    #   => 0.60 ม.: ที่ 1:500 ยังได้ 4.5 px จากเดิม 5.0 px เป้าคลิกแทบไม่ต่างจากเดิม
    #      (เกณฑ์ "คลิกหรือลาก" ของโค้ดนี้คือ 10 px ที่ click_slop ไม่ใช่ค่านี้)
    #      แต่ตัดเคส "zoom ออกแล้วคลิกเดียวคว้าทั้งก้อน" ทิ้งได้
    #   ไม่มีพื้น (floor) — ดูเหตุผลใน _click_tol · เพดานเป็นเมตร จึงต้องผ่าน
    #      _canvas_is_metres() ก่อนเสมอ
    CLICK_TOL_MAX_M = 0.60

    def _click_tol(self):
        """รัศมีค้นหารอบจุดที่คลิก (หน่วยเดียวกับแคนวาส)

        ★ 31 ส.ค. 69 — CLICK_TOL_MAX_M/MIN_M เป็น "เมตร" จึงใช้ได้เฉพาะเมื่อ
        CRS ของโปรเจกต์มีหน่วยเป็นเมตรเท่านั้น. Khlongluang_V2 ตั้ง projectCrs
        เป็น EPSG:4326 (องศา) ทั้งที่เลเยอร์เป็น EPSG:24047 -> ถ้าเอา 0.05 ไป
        เป็นพื้น จะกลายเป็น 0.05 องศา ~ 5.5 กม. คลิกทีเดียวเลือกทั้งตำบล.
        แคนวาสที่ไม่ใช่เมตร -> คืนค่าพิกเซลล้วนแบบเดิม (พฤติกรรมก่อนใส่เพดาน)
        """
        px = self._canvas.mapUnitsPerPixel() * 5
        if not _canvas_is_metres(self._canvas):
            return px
        # ★ 31 ส.ค. 69 — เอาพื้นหน่วยเมตรออก (เคยเป็น 0.05 ม.)
        #   เหตุผลเดิมคือ "กันรัศมีเล็กจนคลิกไม่โดน" ซึ่งคิดผิด: px = mupp*5 คือ 5 พิกเซล
        #   บนจอเสมออยู่แล้ว ไม่มีทางเล็กจนคลิกไม่โดน  แต่พื้นหน่วยเมตรกลับไปทำลาย
        #   วิธีทำงานจริงของพนักงาน คือ "ซูมเข้าไปเพื่อแยกหมุดที่ห่างกันไม่กี่ ซม."
        #   ที่ 1:10 เคยได้รัศมี 1.3 ซม. กลายเป็น 5 ซม. = คว้าหมุดข้างเคียงติดมาด้วย
        #   (ถอยหลังจาก 2.0.2) · เหลือเฉพาะเพดานซึ่งเป็นสิ่งที่ตั้งใจใส่จริง
        return min(px, self.CLICK_TOL_MAX_M)

    # ระยะที่ถือว่า "หมุดอยู่จุดเดียวกัน" — 1 ซม. เท่ากับ _marker_exists_here
    # และเท่ากับ bucket ที่ _select_vertices_in_rect ใช้จับคู่มุมกับหมุด
    STACK_TOL_M = 0.01

    def _selutm_hook(self, lyr):
        """★ rc2 S_close (review R3-06) — ตัวนับการเปลี่ยนของ undo stack ของชั้นแปลง (ทุก push/undo/redo) ให้แคช _sel_poly_utms
        คืนค่าตัวนับปัจจุบัน · ผูกไม่ได้ ⇒ None (คีย์แคชเหลือแบบเดิม)"""
        try:
            st = lyr.undoStack()
            if st is None:
                return None
            if getattr(self, "_selutm_st", None) is not st:
                self._selutm_unhook()
                st.indexChanged.connect(self._selutm_bump)
                self._selutm_st = st
                self._selutm_gen = 0
            return getattr(self, "_selutm_gen", 0)
        except Exception:
            return None

    def _selutm_bump(self, *_a):
        self._selutm_gen = getattr(self, "_selutm_gen", 0) + 1

    def _selutm_unhook(self):
        """ถอดตัวนับ (deactivate) · แคชทิ้งด้วย — ระหว่างไม่ได้ผูก การแก้ไม่ถูกนับ"""
        st = getattr(self, "_selutm_st", None)
        self._selutm_st = None
        self._selutm_cache = None
        if st is not None:
            try:
                st.indexChanged.disconnect(self._selutm_bump)
            except Exception:
                pass

    def _sel_poly_utms(self, pu):
        """★ rc2 (audit A1-07) — (ชุดคีย์ UTM ของแปลงที่เลือก (_utm_key · ไม่รวมว่าง), [fid ที่ UTM ว่าง]) · จำไว้ตาม
        (ชั้น, คอลัมน์, ชุด fid ที่เลือก, รุ่นข้อมูลของชั้น: undo index/count + จำนวน commit/rollback ของปลั๊กอิน)
        เดิมอ่านทุกแปลงที่เลือก 2 รอบต่อคลิก (setFilterFids ทั้งชุด · ที่ 10,000 แปลง ~89 ms/คลิกบน memory · PostGIS ส่ง IN-list ยาว 2 ครั้ง)"""
        lyr = self.poly_lyr
        ids = frozenset(lyr.selectedFeatureIds() or ())
        try:
            st = lyr.undoStack()
            ver = (st.index(), st.count()) if st is not None else None
        except Exception:
            ver = None
        try:
            _pl = self.plugin
            ver = (ver, _pl._commit_seq.get(lyr.id(), 0), _pl._rollback_seq.get(lyr.id(), 0))
        except Exception:
            pass
        # ★ rc2 S_close (review R3-06) — index/count ของ undo stack ซ้ำได้ (Undo 1 ขั้นแล้วแก้ใหม่ 1 ขั้น ⇒ Redo ถูกตัด
        #   index/count เท่าเดิม) ⇒ นับ indexChanged ของ stack ด้วย (ผูกตอนใช้ครั้งแรก · ถอดตอน deactivate)
        gen = self._selutm_hook(lyr)
        key = (lyr.id(), pu, ids, ver, gen)
        try:
            c = self._selutm_cache
        except Exception:
            c = None                     # เครื่องมือที่สร้างโดยไม่ผ่าน __init__ (sim) — sip โยน RuntimeError แทน AttributeError
        if c is not None and c[0] == key:
            return c[1], c[2]
        utms, nulls = set(), []
        if ids:
            u_idx = lyr.fields().indexFromName(pu)
            req_u = (QgsFeatureRequest().setFilterFids(list(ids))
                     .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([u_idx]))
            for f_p in lyr.getFeatures(req_u):
                if not f_p.isValid():
                    continue
                val = _utm_key(f_p[pu])          # ★ 2.4.0 (review DI-08-leftover) _txt + ตัด .0 แบบ main.py
                if val:
                    utms.add(val)
                else:
                    nulls.append(f_p.id())
        self._selutm_cache = (key, utms, nulls)
        return utms, nulls

    def _stacked_marker_count(self):
        """จำนวนหมุดที่ซ้อนกันมากที่สุด **ในแปลงเดียวกัน ที่มุมเดียวกัน**

        คืน 0 ถ้าไม่ได้เลือกแปลงไว้ (พนักงานย้ายได้ตามปกติ ไม่ต้องมีกล่องมาขวาง)

        ★ ทำไมต้องแยกราย (แปลง, มุม) ไม่ใช่นับรวม
          มุมร่วมระหว่าง 4 แปลงมีหมุดของใครของมัน 4 ดวง = เรื่องปกติของงานนี้
          ถ้านับรวมทุกแปลงที่เลือก จะเด้งกล่องทุกครั้งที่คลิกมุมร่วม ทั้งที่ไม่มีอะไรซ้อน
          สิ่งที่ต้องถามคือ "แปลงใดแปลงหนึ่ง มีหมุดของตัวเองซ้อนกันที่มุมใดมุมหนึ่งไหม"
        """
        try:
            # ★ 2.3.7 (review UX-12) — นับเฉพาะ "ของตรงจุดที่คลิก" เมื่อผู้เรียกตั้ง self._stack_scope ไว้
            #   (canvasReleaseEvent ตั้งเป็น _near ก่อนเรียก) · เดิมนับจากการเลือกสะสมทั้งกอง ⇒ มีคู่ซ้อนอยู่ที่ไหนสักแห่ง
            #   ทุก Shift+คลิกมุมธรรมดาก็เด้งกล่อง · ไม่ได้ตั้ง (None) = ทั้งการเลือกแบบเดิม (sim24/sim46 เรียกตรง)
            try:
                items = self._stack_scope
            except Exception:
                # ⚠️ ห้ามใช้ getattr(..., None): เครื่องมือที่สร้างโดยไม่ผ่าน __init__ (sim23/sim24) เป็น sip wrapper
                #   ที่โยน RuntimeError (ไม่ใช่ AttributeError) เมื่ออ่านแอตทริบิวต์ที่ไม่มี ⇒ getattr ไม่จับ ⇒ นับได้ 0 เสมอ
                items = None
            if items is None:
                items = self.selected_vertices
            if not items or not self.poly_lyr:
                return 0
            pu = self.plugin._resolve_field(self.poly_lyr, {'utm', 'utm_code', 'utm_id'})
            if not pu:
                return 0
            # ★ 2.3.0 — ดึงทีเดียวด้วย setFilterFids (เดิม getFeature ทีละ fid = N+1)
            #   ผู้ตรวจฝั่ง Windows วัดไว้: เลือกหมุด 400 ดวง -> คิวรีชั้นหมุด 400 ครั้ง
            #   บนฐานจริง ~1.7 มิลลิวินาที/คิวรี ⇒ 900 ดวง ≈ 1.5 วินาที **ต่อคลิก**
            # ★ rc2 (audit A1-07) — ชุด UTM ของแปลงที่เลือก จำไว้ (_sel_poly_utms) ⇒ ไม่อ่านทุกแปลงที่เลือกซ้ำทุกคลิก
            sel_utms = set(self._sel_poly_utms(pu)[0])
            sel_utms.discard("")
            if not sel_utms:
                return 0                      # ไม่ได้เลือกแปลง -> ไม่เด้ง

            # แคนวาสองศา: 1e-7 องศา ~ 1.1 ซม. (ไฟล์อำเภอบางไฟล์ตั้ง projectCrs 4326)
            tol = self.STACK_TOL_M if _canvas_is_metres(self._canvas) else 1e-7

            # ★ 2.3.0 — ดึงหมุด "ทีเดียวต่อชั้น" แทนทีละดวง (ต้นแบบ: `_movenodes_execute`)
            need = {}
            for v in items:
                if v['layer'].geometryType() == 0:            # เฉพาะชั้นหมุด
                    need.setdefault(v['layer'], set()).add(v['fid'])
            utm_of = {}                                        # (id(layer), fid) -> UTM
            fld_of = {}                                        # id(layer) -> ชื่อฟิลด์ UTM
            for lyr, fids in need.items():
                tu = self.plugin._resolve_field(lyr, {'utm', 'utm_code', 'utm_id'})
                fld_of[id(lyr)] = tu
                if not tu:
                    continue
                req = (QgsFeatureRequest().setFilterFids(list(fids))
                       .setSubsetOfAttributes([tu], lyr.fields()))
                for mf in lyr.getFeatures(req):
                    if mf.isValid():
                        utm_of[(id(lyr), mf.id())] = _utm_key(mf[tu])      # ★ 2.4.0 (review DI-08-leftover)

            bkt = {}
            for v in items:
                if v['layer'].geometryType() != 0:            # ไม่ใช่หมุด -> ข้าม
                    continue
                if not fld_of.get(id(v['layer'])):
                    continue
                u = utm_of.get((id(v['layer']), v['fid']))
                if u is None:                                  # ดึงไม่ได้/ฟีเจอร์หาย
                    continue
                if u not in sel_utms:                          # หมุดของแปลงอื่น -> ไม่นับ
                    continue
                q = v.get('pt')
                if q is None:
                    continue
                bkt.setdefault((u, round(q.x() / tol), round(q.y() / tol)), []).append(q)

            best = 0
            for (u, cx, cy), lst in bkt.items():
                # กวาดช่องข้างเคียง 3x3 กันคู่ที่คร่อมขอบช่อง แล้ววัดระยะจริงอีกชั้น
                near = []
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        near += bkt.get((u, cx + dx, cy + dy), [])
                for pnt in lst:
                    n = sum(1 for o in near if pnt.distance(o) <= tol)
                    if n > best:
                        best = n
            return best
        except Exception:
            return 0                                           # นับไม่ได้ -> อย่าไปขวาง

    def _clear_selection(self):
        for v in self.selected_vertices:
            if v.get('marker'):
                try:
                    self._canvas.scene().removeItem(v['marker'])
                except Exception:
                    pass
        self.selected_vertices = []
        self.selected_keys.clear()
        for attr in ('box_band', 'drag_band', 'move_guide'):
            b = getattr(self, attr, None)
            if b:
                try:
                    self._canvas.scene().removeItem(b)
                except Exception:
                    pass
                setattr(self, attr, None)
        # รีเซ็ตโหมดคลิกเดี่ยว
        self.armed = False
        self.move_anchor = None
        self._placing = False

    def _remove_guide(self):
        if self.move_guide:
            try:
                self._canvas.scene().removeItem(self.move_guide)
            except Exception:
                pass
            self.move_guide = None

    def _restore_markers(self):
        """★ 2.3.7 (review UX-48) — คืน marker พรีวิวกลับตำแหน่งจริง (v['pt'])
        ใช้เมื่อลากแล้วไม่ได้ย้าย (ถูกปฏิเสธที่ด่าน · ล้มเหลว · ไม่ได้ลากจริง) — เดิม marker ค้างอยู่ตรงที่ลากไป
        ทั้งที่ข้อมูลไม่ขยับ แล้วกดบน marker ที่ค้างก็เริ่มกล่องใหม่แทนการลาก"""
        for v in self.selected_vertices:
            mk = v.get('marker')
            if mk is not None and v.get('pt') is not None:
                try:
                    mk.setCenter(v['pt'])
                except Exception:
                    pass

    def _edit_stamp(self):
        """★ 2.3.7 (review DI-36) — ลายนิ้วมือสถานะการแก้ไขของชั้นแปลง/หมุด ณ ตอนเลือก (ดู plugin._movenodes_stamp)
        None = จดไม่ได้ ⇒ ตอนลงมือข้ามการเทียบข้อนี้ (ยังมีด่านตรวจตำแหน่งจริงอยู่)"""
        try:
            return self.plugin._movenodes_stamp((self.poly_lyr, self.point_lyr))
        except Exception:
            return None

    @staticmethod
    def _is_closing(g, gc, nr):
        """★ 2.3.7 (review DI-56) — vertex ลำดับ nr เป็น "จุดปิดวง" ไหม (จุดสุดท้ายของวง = จุดเดียวกับมุมแรกของวงนั้น)
        g = QgsGeometry รูปแปลง · gc = g.constGet() · ใช้ได้ทั้งวงนอก รู และหลายก้อน"""
        try:
            ok, vid = g.vertexIdFromVertexNr(nr)
            return bool(ok) and vid.vertex == gc.vertexCount(vid.part, vid.ring) - 1
        except Exception:
            return False

    def _hidden_by_qgis_selection(self, rect):
        """★ 2.3.7 (review UX-46) — ในกรอบนี้มีหมุด/มุมที่ "ยังไม่ได้เลือก" อยู่ไหม (ไม่สนการเลือกของ QGIS)
        เรียกเฉพาะตอนกรอบนี้เลือกเพิ่มได้ 0 ชิ้นทั้งที่มีการเลือกค้างอยู่ใน QGIS ⇒ True = ตัวกรองการเลือกของ QGIS ทิ้งไป
        (ไม่แตะตัวกรอง — เป็นกันชนของกติกาเหล็ก แค่บอกเหตุให้ถูก) · ตรวจไม่ได้ = False (ข้อความเดิม)"""
        proj = QgsProject.instance()
        for lyr in (self.point_lyr, self.poly_lyr):
            if lyr is None:
                continue
            try:
                to_l = (QgsCoordinateTransform(proj.crs(), lyr.crs(), proj)
                        if lyr.crs() != proj.crs() else None)
                r = to_l.transformBoundingBox(rect) if to_l else rect
                is_pt = lyr.geometryType() == QgsWkbTypes.PointGeometry
                _it = lyr.getFeatures(QgsFeatureRequest().setFilterRect(r).setNoAttributes().setLimit(500))
                try:
                    for f in _it:
                        g = f.geometry()
                        if g is None or g.isEmpty():
                            continue
                        gc = g.constGet() if g.type() == QgsWkbTypes.PolygonGeometry else None
                        for i, vp in enumerate(g.vertices()):
                            if not r.contains(QgsPointXY(vp.x(), vp.y())):
                                continue
                            if gc is not None and self._is_closing(g, gc, i):
                                continue
                            if (lyr.id(), f.id(), -1 if is_pt else i) not in self.selected_keys:
                                return True
                finally:
                    _it.close()
            except Exception:
                pass
        return False

    def _add_marker(self, pt):
        mk = QgsVertexMarker(self._canvas)
        mk.setIconType(QgsVertexMarker.ICON_BOX)
        mk.setColor(QtGui.QColor(255, 60, 0))
        mk.setFillColor(QtGui.QColor(255, 60, 0, 80))
        mk.setPenWidth(2)
        mk.setIconSize(10)
        mk.setCenter(pt)
        mk.show()
        return mk

    def _select_vertices_in_rect(self, rect, add_mode=False):
        """คืน False เมื่อยกเลิกทั้งกรอบเพราะแปลงพิกัดไม่ได้ (★ 2.4.0 review DI-44 · การเลือกเดิมไม่ถูกแตะ) · ทางอื่นคืน None"""
        proj = QgsProject.instance()
        # ★ 2.4.0 (review DI-44) — แปลงกรอบ (พิกัดแผนที่) เป็นพิกัดของชั้นหมุด/ชั้นแปลง "ก่อน" แตะการเลือก
        #   เดิมแปลงไม่ได้ = ใช้กรอบที่ยังไม่แปลงต่อ (คนละระบบพิกัด คลาดได้หลายร้อยเมตร) ⇒ เลือกหมุด/มุมผิดที่แล้วลากย้ายได้
        #   ⇒ ยกเลิกทั้งกรอบ แจ้งแถบแดงแบบ Align/Add Node · การเลือกเดิมคงไว้ (ยังไม่ได้ล้าง)
        try:
            pt_rect = (QgsCoordinateTransform(proj.crs(), self.point_lyr.crs(), proj).transformBoundingBox(rect)
                       if self.point_lyr and self.point_lyr.crs() != proj.crs() else rect)
            poly_rect = (QgsCoordinateTransform(proj.crs(), self.poly_lyr.crs(), proj).transformBoundingBox(rect)
                         if self.poly_lyr and self.poly_lyr.crs() != proj.crs() else rect)
        except Exception:
            self.plugin.iface.messageBar().pushMessage(
                "Move Node", "แปลงตำแหน่งที่คลิก/กรอบที่ลากเป็นระบบพิกัดของชั้นข้อมูลไม่ได้ — ยกเลิก ไม่ได้เลือกหมุดจากกรอบนี้ "
                             "(ตรวจระบบพิกัดของโปรเจกต์/ชั้น)", level=2, duration=10)
            return False
        if not add_mode:
            self._clear_selection()
        # ★ 2.3.7 (review UX-47) — จำนวนที่เลือกไว้ก่อนกล่องนี้ (โหมด Shift ชนเพดาน ⇒ ถอดเฉพาะของกล่องนี้)
        n0 = len(self.selected_vertices)
        # ★ 2.3.7 (review DI-36) — ลายนิ้วมือสถานะการแก้ไข ณ ตอนเลือก ติดไปกับทุกชิ้นที่กล่องนี้เพิ่ม
        #   _movenodes_execute เทียบอีกครั้งก่อนลงมือ: เปลี่ยน = มีการแก้/ย้อน/บันทึก/สลับล็อก L1 ระหว่างนั้น ⇒ ให้เลือกใหม่
        _stamp = self._edit_stamp()

        has_blocked = False
        has_cap = False      # เลือกทะลุเพดาน 800 จุด -> ตัด (กัน QgsVertexMarker ท่วมจอ/ลากกระตุก)
        locked_map = None   # ตาราง UTM ล็อก L1-RTK/L1-TS — โหลดครั้งแรกที่เจอหมุด (คิวรีเดียวต่อรอบ)

        selected_poly_ids = []
        selected_poly_utms = set()
        poly_utm_field = None
        null_poly_fids = []     # ★ 2.4.0 (review DI-01) — แปลงที่เลือกซึ่ง UTM ว่าง/NULL (เช่นเพิ่งวาด)
        from .main import _txt as _txt_m       # ★ 2.3.7 (review DI-08) — UTM NULL = ว่าง (เดิม str() ได้ 'NULL' แล้วจับคู่หมุดคีย์ว่างทั้งกรอบ)
        if self.poly_lyr:
            selected_poly_ids = self.poly_lyr.selectedFeatureIds()
            if selected_poly_ids:
                poly_utm_field = self.plugin._resolve_field(self.poly_lyr, {'utm', 'utm_code', 'utm_id'})
                if poly_utm_field:
                    # ★ rc2 (audit A1-07) — อ่านผ่าน _sel_poly_utms (จำตามชุดที่เลือก + รุ่นข้อมูล) · เดิมอ่าน UTM ของ "ทุกแปลง
                    #   ที่เลือก" ทุกคลิก 2 รอบ (ตรงนี้ + _stacked_marker_count) โดยไม่จำกัดกรอบ
                    _us, _nf = self._sel_poly_utms(poly_utm_field)
                    selected_poly_utms |= _us
                    null_poly_fids.extend(_nf)
        # ★ 2.4.0 (review DI-01) — มีแปลงถูกเลือก = ตัวกรอง UTM ฝั่งหมุด "เปิดเสมอ" (ชุดคีย์ว่าง = ไม่ตรงหมุดใด)
        #   เดิมเปิดเมื่อ selected_poly_utms ไม่ว่าง ⇒ เลือกเฉพาะแปลงที่ UTM ว่าง แล้วลากกรอบ = ตัวกรองปิด
        #   หมุดที่ไม่ใช่ L1 ทุกดวงในกรอบ (รวมของแปลงข้างเคียง) ถูกเลือกไปด้วย
        #   แปลงที่เลือกซึ่ง UTM ว่าง: ให้หมุดที่ UTM ว่างได้ "เฉพาะดวงที่นั่งบนมุมของแปลงนั้น" (±1 ซม. แบบ sel_pt_idx)
        #   ⇒ หมุด UTM ว่างของแปลงอื่นในกรอบไม่ติดมา · ดึง geometry เฉพาะแปลงกลุ่มนี้ คิวรีเดียว
        #   ⚠️ ข้อจำกัด (review DI-01 · ยังไม่แก้): มุมร่วมกับแปลง UTM ว่างที่ "ไม่ได้เลือก" — หมุด UTM ว่างแยกเจ้าของไม่ได้
        #   หมุดของแปลงข้างเคียงที่นั่งบนมุมร่วม (≤ 1 ซม.) จึงติดมาด้วย (2.3.5/2.3.10 ก็เป็น) · เหลือด่านตรวจก่อนบันทึกจับมุมเปล่า
        use_utm = bool(selected_poly_ids and poly_utm_field)
        # ★ 2.4.0 (review DU-02) — "หมุดนั่งบนมุม" ของเครื่องมือนี้ = ค่าคงที่ชุดเดียวกับ Add Node/ไฮไลต์ (_MK_WELD_TOL = 1 ซม.)
        #   (เดิมพิมพ์ 0.01 ตรง ๆ หลายที่ · ค่าเท่าเดิม)
        # ★ 2.4.0 (review DI-01) — ทุกการเทียบ "นั่งบนมุม" ในฟังก์ชันนี้ทำในพิกัดแผนที่ ⇒ ค่าเมตรใช้ได้เฉพาะแผนที่หน่วยเมตร
        #   แผนที่องศา (เช่น Khlongluang_V2 projectCrs 4326) 0.01 = 0.01° ≈ 1.1 กม. ⇒ หมุด UTM ว่างของแปลงอื่น/หมุดลอย
        #   และมุมทุกมุมรอบหมุดที่เลือกติดมาหมด · ใช้ 1e-7° (~1.1 ซม.) แบบ _stacked_marker_count/_movenodes_pair_ok
        _W = self.plugin._MK_WELD_TOL if _canvas_is_metres(self._canvas) else 1e-7
        null_corner_idx = {}
        if use_utm and null_poly_fids:
            try:
                _to_map = (QgsCoordinateTransform(self.poly_lyr.crs(), proj.crs(), proj)
                           if self.poly_lyr.crs() != proj.crs() else None)
                _req_n = QgsFeatureRequest().setFilterFids(null_poly_fids).setNoAttributes()
                # ★ 2.4.0 (review DI-01) — ดึงเฉพาะแปลงที่อยู่ใกล้กรอบ (หมุดต้องอยู่ในกรอบ ⇒ มุมที่ตรงได้อยู่ในกรอบ ± _W)
                #   เดิมดึง geometry ทุกแปลงที่เลือกทุกครั้ง รวมคลิกเดี่ยว (เลือกไว้หลายหมื่นแปลง = ช้าลงหลายเท่าต่อคลิก)
                try:
                    _nr = rect.buffered(_W)
                    if _to_map:
                        _nr = QgsCoordinateTransform(proj.crs(), self.poly_lyr.crs(), proj).transformBoundingBox(_nr)
                    _req_n.setFilterRect(_nr)
                except Exception:
                    pass     # แปลงกรอบไม่ได้ = ดึงทั้งชุดแบบเดิม (ผลเท่าเดิม แค่ช้ากว่า)
                _it_n = self.poly_lyr.getFeatures(_req_n)
                try:
                    for f_n in _it_n:
                        g_n = f_n.geometry()
                        if g_n is None or g_n.isEmpty():
                            continue
                        for vp in g_n.vertices():
                            q = QgsPointXY(vp.x(), vp.y())
                            if _to_map:
                                q = _to_map.transform(q)
                            null_corner_idx.setdefault(
                                (round(q.x() / _W), round(q.y() / _W)), []).append(q)
                finally:
                    _it_n.close()
            except Exception:
                null_corner_idx = {}     # อ่านมุมไม่ได้ = ไม่ให้หมุด UTM ว่างผ่าน (ปลอดภัยกว่า)

        def _on_null_corner(mp):
            _cx = round(mp.x() / _W); _cy = round(mp.y() / _W)
            return any(abs(mp.x() - q.x()) <= _W and abs(mp.y() - q.y()) <= _W
                       for gx in (_cx - 1, _cx, _cx + 1)
                       for gy in (_cy - 1, _cy, _cy + 1)
                       for q in null_corner_idx.get((gx, gy), ()))

        selected_point_ids = []
        if self.point_lyr:
            # ★ 2.4.0 (review PF-07) — set: เช็ค "อยู่ในที่เลือก" ทีละหมุดเป็น O(1) (selectedFeatureIds() คืน list)
            selected_point_ids = set(self.point_lyr.selectedFeatureIds())

        # ★ 2.4.0 (review DU-01) — หมุดที่ถูกข้ามเพราะล็อก: จำตำแหน่ง + UTM ไว้ ⇒ มุมแปลง UTM เดียวกันที่หมุดนั่งอยู่ (≤ _W) ไม่ถูกเลือกด้วย
        #   (แบบ _align_drop_locked_corners) เดิมหมุดถูกข้ามแต่มุมใต้หมุดถูกเลือก ⇒ กล่อง "เลือกไม่ครบคู่" บอกให้ลากกรอบใหม่
        #   ให้ครอบหมุด (ทำไม่ได้ — หมุดล็อก) · กด Yes = มุมหลุดจากหมุดล็อก · ช่องตาราง _W · คีย์ UTM ว่าง = ไม่จับคู่ (แบบ Align)
        from .main import _norm_utm as _norm_utm_m
        blk_idx = {}

        def _blk_add(mp, f_b, uf_b):
            try:
                raw = f_b[uf_b] if uf_b else None
            except Exception:
                raw = None
            if not _txt_m(raw):
                return
            blk_idx.setdefault((round(mp.x() / _W), round(mp.y() / _W)), []).append((mp, _norm_utm_m(raw)))

        def _on_blocked(mp, u):
            _cx = round(mp.x() / _W); _cy = round(mp.y() / _W)
            return any(bu == u and abs(mp.x() - q.x()) <= _W and abs(mp.y() - q.y()) <= _W
                       for gx in (_cx - 1, _cx, _cx + 1)
                       for gy in (_cy - 1, _cy, _cy + 1)
                       for q, bu in blk_idx.get((gx, gy), ()))

        # ค้นหาใน point_lyr
        if self.point_lyr:
            from_pt = QgsCoordinateTransform(self.point_lyr.crs(), proj.crs(), proj) if self.point_lyr.crs() != proj.crs() else None
            # (pt_rect แปลงไว้แล้วตอนต้นฟังก์ชัน — ★ 2.4.0 review DI-44)
            
            req = QgsFeatureRequest().setFilterRect(pt_rect)
            point_utm_field = self.plugin._resolve_field(self.point_lyr, {'utm', 'utm_code', 'utm_id'})
            pt_type_idx = self.plugin._field_index(self.point_lyr.fields(), 'type')   # ★ 2.4.0 (DU-01) Type ของหมุด

            _fit834 = self.point_lyr.getFeatures(req)
            try:
                for f in _fit834:
                    # ถ้ามีการ select หมุดเอาไว้ ให้ดึงเฉพาะหมุดที่ select
                    if selected_point_ids and f.id() not in selected_point_ids:
                        continue
                
                    # ถ้าไม่ได้ select หมุด แต่มีแปลงที่ถูก select ไว้ ให้กรองหมุดด้วย UTM
                    _null_key = False
                    if not selected_point_ids and use_utm and point_utm_field:     # ★ 2.4.0 (review DI-01) use_utm
                        pt_key = _utm_key(f[point_utm_field])          # ★ 2.4.0 (review DI-08-leftover) '1234.0' = '1234'
                        if pt_key not in selected_poly_utms:          # ★ 2.3.7 DI-08 ('' ไม่อยู่ในชุดอยู่แล้ว)
                            # ★ 2.4.0 (review DI-01) — หมุด UTM ว่าง: ผ่านได้เมื่อนั่งบนมุมของแปลงที่เลือกซึ่ง UTM ว่าง (เช็คข้างล่าง)
                            if pt_key or not null_corner_idx:
                                continue
                            _null_key = True

                    g = f.geometry()
                    if g.intersects(pt_rect):
                        map_pt = from_pt.transform(g.asPoint()) if from_pt else g.asPoint()
                        if _null_key and not _on_null_corner(map_pt):      # ★ 2.4.0 (review DI-01)
                            continue
                        if self.poly_lyr:
                            if locked_map is None:
                                # ★ 2.3.7 (review PF-01) — สแกนล็อกไม่สำเร็จ = ถือว่าทุกหมุดล็อก (fail-closed · แจ้งแล้วใน plugin)
                                locked_map = self.plugin._locked_map_or_block(self.poly_lyr, "Move Node")
                                if locked_map is None:
                                    locked_map = _LOCK_UNKNOWN
                            if locked_map is _LOCK_UNKNOWN:
                                has_blocked = True
                                _blk_add(map_pt, f, point_utm_field)     # ★ 2.4.0 (review DU-01)
                                continue
                            # ★ 2.4.0 (review DU-01) — กติกาเดียว (_marker_locked): Type ของหมุดเอง หรือ UTM ตรงแปลง L1
                            #   (เดิมดูแค่ UTM ⇒ หมุด Type L1 ที่ UTM ว่าง/ไม่ตรงแปลง L1 ใด ถูกเลือกและย้ายได้)
                            is_locked, type_str = self.plugin._marker_locked(f, locked_map, point_utm_field, pt_type_idx)
                            if is_locked:   # ★ admin: เลือก/ย้าย node หมุด L1 ได้ (ปลดล็อกแล้ว _marker_locked คืนไม่ล็อก)
                                has_blocked = True
                                _blk_add(map_pt, f, point_utm_field)     # ★ 2.4.0 (review DU-01) มุมใต้หมุดนี้ไม่ถูกเลือกด้วย
                                continue
                        key = (self.point_lyr.id(), f.id(), -1)
                        if key not in self.selected_keys:
                            # ★ 2.3.7 (review UX-47) — เช็คเพดาน "หลัง" รู้ว่าเป็นของใหม่ (เดิมเช็คก่อน ⇒ Shift+ลากทับ
                            #   ของที่เลือกไว้แล้วตอนครบ 800 พอดี = ชนเพดานทั้งที่ไม่ได้เพิ่มอะไร)
                            if len(self.selected_vertices) >= 800:
                                has_cap = True
                                break
                            self.selected_keys.add(key)
                            self.selected_vertices.append({
                                'layer': self.point_lyr, 'fid': f.id(), 'vidx': -1, 'pt': map_pt,
                                'marker': self._add_marker(map_pt), 'stamp': _stamp,
                                'lpt': QgsPointXY(g.asPoint())    # ★ 2.3.7 (DI-36) พิกัดในชั้นเอง ไว้ตรวจตอนลงมือ
                            })
            finally:
                _fit834.close()
                        
        # ค้นหาใน poly_lyr (ข้ามถ้าชนเพดานแล้ว — ผลจะถูกยกเลิกทั้งหมดอยู่ดี)
        if self.poly_lyr and not has_cap:
            from_poly = QgsCoordinateTransform(self.poly_lyr.crs(), proj.crs(), proj) if self.poly_lyr.crs() != proj.crs() else None
            # (poly_rect แปลงไว้แล้วตอนต้นฟังก์ชัน — ★ 2.4.0 review DI-44)
                
            req = QgsFeatureRequest().setFilterRect(poly_rect)
            selected_poly_ids = set(self.poly_lyr.selectedFeatureIds())     # ★ 2.4.0 (review PF-07) set แทน list
            # ★ กันฉีกกติกาเหล็ก: ถ้าผู้ใช้ select "เฉพาะหมุด" ไว้ (ไม่ได้ select แปลง)
            #   เดิมฝั่งหมุดถูกจำกัดตาม selection แต่ฝั่งมุมแปลงกวาดทุกมุมในกรอบ
            #   -> ลากแล้วมุมแปลงขยับ แต่หมุดของมัน (ที่ไม่ได้เลือก) อยู่กับที่
            #   จำกัดมุมแปลงให้เหลือเฉพาะที่ทับหมุดที่ถูกเลือก (±5 ซม. = tolerance มุมร่วมของปลั๊กอิน)
            sel_pt_idx = None
            if selected_point_ids and not selected_poly_ids:
                # grid bucket ช่อง 1 ซม. -> เช็คต่อ vertex เป็น O(1) แทนสแกนทั้ง list
                # 1 ซม. = tolerance เดียวกับ _marker_exists_here (มุมกับหมุด weld กันระดับ mm;
                # 5 ซม. กว้างจนคว้ามุมของแปลงข้างเคียงที่ไม่ใช่คู่ของหมุดมาได้)
                sel_pt_idx = {}
                for v in self.selected_vertices:
                    if v['layer'] is self.point_lyr:
                        q = v['pt']
                        sel_pt_idx.setdefault(
                            (round(q.x() / _W), round(q.y() / _W)), []).append(q)
            _fit892 = self.poly_lyr.getFeatures(req)
            try:
                for f in _fit892:
                    # ถ้ามีแปลงที่ถูก select อยู่ ให้ย้ายได้แค่แปลงที่ถูก select เท่านั้น
                    if selected_poly_ids and f.id() not in selected_poly_ids:
                        continue
                    # กันชน: ห้ามเลือก L1-RTK / L1-TS
                    tp = self.plugin._poly_type_str(self.poly_lyr, f)
                    if tp in L1_TYPES and not self.plugin._l1_unlocked():      # ★ 2.4.0 (DU-01) lock_rules
                        has_blocked = True
                        continue
                    # ★ 2.4.0 (review DU-01) — UTM ของแปลงนี้ (ใช้เทียบกับหมุดล็อกที่ถูกข้าม) · คีย์ว่าง = ไม่จับคู่
                    _pu_blk = None
                    if blk_idx:
                        if poly_utm_field is None:
                            poly_utm_field = self.plugin._resolve_field(self.poly_lyr, {'utm', 'utm_code', 'utm_id'}) or ""
                        try:
                            _raw_p = f[poly_utm_field] if poly_utm_field else None
                        except Exception:
                            _raw_p = None
                        _pu_blk = _norm_utm_m(_raw_p) if _txt_m(_raw_p) else None
                    g = f.geometry()
                    # ★ 2.3.7 (review DI-56) — ข้าม "จุดปิดวง" (vertex สุดท้ายของแต่ละวง = จุดเดียวกับมุมแรก)
                    #   เดิมคลิกมุมแรกได้ทั้ง vidx 0 และจุดปิดวง ⇒ นับเป็น 2 มุม (กินเพดาน 800 · กล่องหมุดซ้อนมีแถว
                    #   'มุมที่ 0' กับ 'มุมที่ 4' ติ๊กออกแถวเดียวมุมก็ยังขยับ · ด่านครบคู่นับซ้ำ)
                    #   ปลอดภัย: moveVertex(0) ย้ายจุดปิดวงให้เองอยู่แล้ว (ทดสอบแล้ว ทั้งวงนอก รู และหลายก้อน)
                    _gc = g.constGet() if g.type() == QgsWkbTypes.PolygonGeometry else None
                    # ต้องหาทุก vertex ที่อยู่ใน poly_rect
                    for vidx, vpt in enumerate(g.vertices()):
                        vpt_xy = QgsPointXY(vpt.x(), vpt.y())
                        if poly_rect.contains(vpt_xy):
                            if _gc is not None and self._is_closing(g, _gc, vidx):
                                continue
                            map_pt = from_poly.transform(vpt_xy) if from_poly else vpt_xy
                            if _pu_blk is not None and _on_blocked(map_pt, _pu_blk):   # ★ 2.4.0 (review DU-01)
                                has_blocked = True
                                continue
                            if sel_pt_idx is not None:
                                _cx = round(map_pt.x() / _W); _cy = round(map_pt.y() / _W)
                                _hit = any(abs(map_pt.x() - q.x()) <= _W and
                                           abs(map_pt.y() - q.y()) <= _W
                                           for gx in (_cx - 1, _cx, _cx + 1)
                                           for gy in (_cy - 1, _cy, _cy + 1)
                                           for q in sel_pt_idx.get((gx, gy), ()))
                                if not _hit:
                                    continue
                            key = (self.poly_lyr.id(), f.id(), vidx)
                            if key not in self.selected_keys:
                                if len(self.selected_vertices) >= 800:      # ★ 2.3.7 UX-47 (หลังรู้ว่าเป็นของใหม่)
                                    has_cap = True
                                    break
                                self.selected_keys.add(key)
                                self.selected_vertices.append({
                                    'layer': self.poly_lyr, 'fid': f.id(), 'vidx': vidx, 'pt': map_pt,
                                    'marker': self._add_marker(map_pt), 'stamp': _stamp,
                                    'lpt': QgsPointXY(vpt_xy)         # ★ 2.3.7 (DI-36)
                                })
                    if has_cap:
                        break     # เลิกไล่ feature ที่เหลือ — ผลถูกยกเลิกทั้งหมดข้างล่างอยู่แล้ว
            finally:
                _fit892.close()
                            
        if has_cap:
            # ★ ห้ามตัดครึ่ง ๆ กลาง ๆ: ถ้าตัดกลางคัน หมุดบางตัวถูกเลือกโดยมุมแปลงคู่ของมัน
            #   โดนตัดทิ้ง -> ลากแล้วขยับไม่ครบคู่ (ฉีกกติกาเหล็กเสียเอง) -> ยกเลิก "ทั้งกล่องนี้"
            # ★ 2.3.7 (review UX-47) — โหมด Shift: ถอดเฉพาะของที่กล่องนี้เพิ่ม (selected_vertices[n0:])
            #   ของที่สะสมจากกล่องก่อน ๆ ยังอยู่ครบ (เดิมล้างทิ้งทั้งหมด) · ไม่กด Shift = ล้างทั้งหมดเหมือนเดิม
            # ★ 2.3.7 (review UX-35) — เป็นคำแนะนำ/ปฏิเสธ ไม่ใช่ความล้มเหลว ⇒ แถบเหลือง (เดิมแดง)
            if n0 > 0:
                for v in self.selected_vertices[n0:]:
                    if v.get('marker'):
                        try:
                            self._canvas.scene().removeItem(v['marker'])
                        except Exception:
                            pass
                    self.selected_keys.discard((v['layer'].id(), v['fid'], v.get('vidx')))
                del self.selected_vertices[n0:]
                self.plugin.iface.messageBar().pushMessage(
                    "Move Node", f"กล่องนี้ทำให้เกิน 800 จุด — ยกเลิกเฉพาะกล่องนี้ (ที่เลือกไว้เดิม {n0} จุดยังอยู่) "
                                 "กรุณาลากกล่องให้เล็กลง", level=1, duration=8)
                return
            self._clear_selection()
            self.plugin.iface.messageBar().pushMessage(
                "Move Node", "เลือกเกิน 800 จุด — ยกเลิกการเลือกทั้งหมด (กันแปลง/หมุดขยับไม่ครบคู่) "
                             "กรุณาลากกล่องให้เล็กลง", level=1, duration=8)
            return
        if has_blocked:
            self.plugin.iface.messageBar().pushMessage(
                "MLEP Guard", "หมุดหรือแปลงอ้างอิง L1-RTK / L1-TS ถูกข้ามเพื่อป้องกันการแก้ไข!",
                level=1, duration=5
            )
        elif (len(self.selected_vertices) == n0 and (selected_poly_ids or selected_point_ids)
              and self._hidden_by_qgis_selection(rect)):
            # ★ 2.3.7 (review UX-46) — กรอบนี้มีหมุด/มุมอยู่ แต่การเลือกของ QGIS ที่ค้างอยู่กรองทิ้งหมด
            #   เดิมขึ้น "ไม่พบหมุด" (หรือ "เลือก N หมุดแล้ว" เท่าเดิม) โดยไม่บอกว่าตัวกรองคืออะไร
            if selected_poly_ids:
                _why = (f"เลือกได้เฉพาะมุม/หมุดของแปลงที่เลือกไว้ใน QGIS ({len(selected_poly_ids)} แปลง) — "
                        "ล้างการเลือกของ QGIS (Deselect) เพื่อเลือกแปลงอื่น")
            else:
                _why = (f"เลือกได้เฉพาะหมุดที่เลือกไว้ใน QGIS ({len(selected_point_ids)} หมุด) — "
                        "ล้างการเลือกของ QGIS (Deselect) เพื่อเลือกหมุดอื่น")
            self.plugin.iface.messageBar().pushMessage("Move Node", _why, level=1, duration=10)
        elif self.selected_vertices:
            iface.messageBar().pushInfo("Move Node", f"{self._sel_count_text()}แล้ว")      # ★ rc2 (audit A1-06)
        else:
            iface.messageBar().pushInfo("Move Node", "ไม่พบหมุดในบริเวณที่คลิก กรุณาลองใหม่")

    def keyPressEvent(self, e):
        # ★ 2.3.7 (audit F1 · P1) — เดิม Move Node ไม่มี keyPressEvent เลย ⇒ Backspace/Delete ถึงมือ QGIS ⇒ ลบแปลง + หมุด
        #   ที่เลือกค้างไว้ (หลังกดปุ่ม Move Node แปลงที่ทำงาน + หมุดของมันถูกเลือกอยู่เสมอ · ผู้ตรวจ p08 หมุด 8→4 มุมเปลือย 4)
        #   ⇒ กินคีย์ + บอกสั้น ๆ · คีย์อื่น (รวม Esc) ไม่แตะ — เหมือนเดิม
        _eat_del_key(self, e)

    def _sel_count_text(self):
        """★ rc2 (audit A1-06) — "เลือก N หมุด + มุมแปลง M มุม" (เดิมนับมุมแปลงรวมเป็นหมุด: หมุด 4 + มุม 4 = 'เลือก 8 หมุด'
        พนักงานเข้าใจว่ามีหมุดซ้อน) · มุมนับตามตำแหน่งไม่ซ้ำ (จุดปิดวง/มุมร่วมของแปลงที่เลือกพร้อมกันนับครั้งเดียว)"""
        n_mk = sum(1 for v in self.selected_vertices if v.get('vidx', -1) < 0)
        _vx = {(round(v['pt'].x(), 3), round(v['pt'].y(), 3)) for v in self.selected_vertices
               if v.get('vidx', -1) >= 0 and v.get('pt') is not None}
        return f"เลือก {n_mk} หมุด" + (f" + มุมแปลง {len(_vx)} มุม" if _vx else "")

    ARMED_GRAB_PX = 5               # ★ rc2 (audit A1-03) กดห่างหมุดที่ arm ไว้เกินนี้ (พิกเซล) + ลากจริง = กล่องเลือก

    def _armed_far(self, pos):
        """★ rc2 (audit A1-03) — จุดกด (พิกเซล) ห่างหมุด/มุมที่ arm ไว้ทุกชิ้นเกิน ARMED_GRAB_PX ไหม · ตัดสินไม่ได้ = False (ย้ายตามเดิม)"""
        try:
            pts = ([self.move_anchor] if self.move_anchor is not None else []) + \
                  [v['pt'] for v in self.selected_vertices if v.get('pt') is not None]
            if not pts:
                return False
            ct = self._canvas.getCoordinateTransform()
            lim = self.ARMED_GRAB_PX
            for q in pts:
                c = ct.transform(QgsPointXY(q))
                if abs(c.x() - pos.x()) <= lim and abs(c.y() - pos.y()) <= lim:
                    return False
            return True
        except Exception:
            return False

    def _press_dragged(self, pos):
        """★ rc2 (audit A1-03) — เมาส์ขยับจากจุดกดเกิน startDragDistance (เกณฑ์เดียวกับ UX-11) ไหม"""
        try:
            pp = getattr(self, "_press_pos", None)
            return pp is not None and (pos - pp).manhattanLength() >= QtWidgets.QApplication.startDragDistance()
        except Exception:
            return False

    def canvasPressEvent(self, e):
        if e.button() != QtCore.Qt.LeftButton:
            return

        if self.is_moving:
            return

        shift = bool(e.modifiers() & QtCore.Qt.ShiftModifier)
        match = self._canvas.snappingUtils().snapToMap(e.pos())
        self.drag_start_pt = match.point() if match.isValid() else self.toMapCoordinates(e.pos())
        self._press_pos = QtCore.QPoint(e.pos())     # ★ 2.3.7 (UX-11) ใช้แยก "คลิกเฉย ๆ" กับ "ลากจริง" ตอนปล่อย

        # โหมด armed (คลิกเดี่ยวเลือกหมุดไว้แล้ว) + คลิกปกติ -> คลิกนี้คือ "ปลายทาง" ย้าย (สั่งตอน release)
        if self.armed and not shift:
            self._placing = True
            # ★ rc2 (audit A1-03) — จำว่ากด "ห่างหมุดที่ arm ไว้" ไหม (> ARMED_GRAB_PX) ⇒ ถ้าลากต่อเกิน startDragDistance
            #   = ลากกล่องเลือกใหม่ (ไม่ใช่ย้าย) · กดบนหมุดที่ arm แล้วลากไปวาง = ย้ายตามเดิม (ท่าที่ใช้ได้อยู่)
            self._placing_away = self._armed_far(e.pos())
            return
        self._placing = False
        self._placing_away = False

        # เช็คว่าคลิกโดนหมุดที่เลือกไว้แล้วหรือไม่ (ใช้ตัดสินว่าจะลากย้าย)
        clicked_on_selected = False
        # ★ 2.3.7 (review UX-11) — เดิมเช็คเฉพาะเมื่อ snapping เจออะไรสักอย่าง (match.isValid())
        #   ⇒ ปิด snap อยู่ = กดบนหมุดที่เลือกไว้แล้วกลายเป็นเริ่มกล่องใหม่ (ปล่อยแล้วแทนที่การเลือกทั้งชุด)
        #   และวัดระยะจาก "จุด snap" ⇒ snap ติดเป้าข้าง ๆ (หมุด CT / เส้นที่วาด) ห่าง 2-4 px = ทั้งชุดลงเพี้ยนเท่านั้น
        #   ⇒ เทียบกับทั้งจุดที่กดจริงและจุด snap โดยไม่พึ่ง snap · ได้ "ชิ้นที่ใกล้ที่สุด" แล้ววัดระยะจากชิ้นนั้น
        #     (ตอนปล่อยยังใช้จุด snap เป็นปลายทาง ⇒ ชิ้นที่กดโดนลงบนเป้า snap พอดี)
        if self.selected_vertices and not self.armed:
            # ★ 28 ส.ค. 69 — ตรงนี้ **ห้ามใส่เพดานเมตร** (เคยใส่แล้วถอนออก):
            #   ตัวนี้ตัดสินแค่ "ลากของที่เลือกไว้แล้ว" หรือ "เริ่มกล่องใหม่" — ไม่ได้เลือกของใหม่เลย
            #   ของที่จะถูกย้ายคือชุดที่ผู้ใช้ตรวจแล้วเลือกไว้เอง เพดานจึงไม่เพิ่มความปลอดภัยอะไร
            #   มีแต่ทำให้ที่ zoom กว้าง กดบนหมุดที่เห็นว่าเลือกอยู่แล้วพลาด -> เสีย selection ทิ้ง
            tol_sq = (self._canvas.mapUnitsPerPixel() * 5) ** 2
            _probe = [self.toMapCoordinates(e.pos())]
            if match.isValid():
                _probe.append(match.point())
            _best = None
            for v in self.selected_vertices:
                _q = v.get('pt')
                if _q is None:
                    continue
                _d = min(_q.sqrDist(c) for c in _probe)
                if _d < tol_sq and (_best is None or _d < _best[0]):
                    _best = (_d, _q)
            if _best is not None:
                clicked_on_selected = True
                self.drag_start_pt = QgsPointXY(_best[1])     # วัดระยะจากชิ้นที่กดโดน ไม่ใช่จุด snap

        if self.selected_vertices and clicked_on_selected and not self.armed:
            # โหมดหลายหมุด: คลิกโดนหมุดที่เลือกไว้ -> ลากย้าย (กด/ไม่กด Shift ก็ได้)
            self._remove_guide()
            self.is_moving = True
            self.drag_band = QgsRubberBand(self._canvas, QgsWkbTypes.LineGeometry)
            self.drag_band.setColor(QtGui.QColor(0, 0, 255))
            self.drag_band.setWidth(2)
        else:
            # เริ่มกล่องเลือก (คลิก = จุดเดียว+arm, Shift+ลาก = ครอบหลายจุด)
            # ถ้ากำลัง armed อยู่แล้วมากดเริ่ม gesture ใหม่ (เช่น Shift+ลาก) -> ปลด armed + เส้นนำ
            if self.armed:
                self.armed = False
                self._remove_guide()
            self.is_moving = False
            self.box_band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
            self.box_band.setColor(QtGui.QColor(0, 120, 255))
            self.box_band.setFillColor(QtGui.QColor(0, 120, 255, 40))
            self.box_band.setWidth(1)

    def canvasMoveEvent(self, e):
        match = self._canvas.snappingUtils().snapToMap(e.pos())
        cur = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        if match.isValid():
            self.snap_marker.setCenter(cur)
            self.snap_marker.show()
        else:
            self.snap_marker.hide()

        # ★ rc2 (audit A1-03) — armed แต่กดห่างหมุดที่ arm แล้วลากจริง ⇒ แสดงกล่องเลือก (ปล่อยแล้วเลือกใหม่ ไม่ย้าย)
        if self.armed and self._placing and getattr(self, "_placing_away", False) and self._press_dragged(e.pos()) \
                and self.drag_start_pt is not None:
            self._remove_guide()
            if self.box_band is None:
                self.box_band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
                self.box_band.setColor(QtGui.QColor(0, 120, 255))
                self.box_band.setFillColor(QtGui.QColor(0, 120, 255, 40))
                self.box_band.setWidth(1)
            self.box_band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self.drag_start_pt, cur)), None)
            return
        # โหมด armed (คลิกเดี่ยว): ลากเส้นนำจากจุดอ้างอิงไปเมาส์ (มาร์กเกอร์อยู่กับที่ บอกว่าเลือกอะไร)
        if self.armed and self.move_anchor is not None:
            if self.move_guide is None:
                self.move_guide = QgsRubberBand(self._canvas, QgsWkbTypes.LineGeometry)
                self.move_guide.setColor(QtGui.QColor(0, 0, 255))
                self.move_guide.setWidth(2)
            self.move_guide.setToGeometry(
                QgsGeometry.fromPolylineXY([self.move_anchor, cur]), None)
            return

        if self.drag_start_pt is None:
            return

        if self.is_moving and self.drag_band:
            self.drag_band.setToGeometry(QgsGeometry.fromPolylineXY([self.drag_start_pt, cur]), None)
            # ขยับ Marker ตามเมาส์ให้เห็นภาพ
            dx = cur.x() - self.drag_start_pt.x()
            dy = cur.y() - self.drag_start_pt.y()
            for v in self.selected_vertices:
                if v['marker']:
                    v['marker'].setCenter(QgsPointXY(v['pt'].x() + dx, v['pt'].y() + dy))
        elif not self.is_moving and self.box_band:
            self.box_band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self.drag_start_pt, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_selection()
            iface.actionSelect().trigger()
            return

        if e.button() != QtCore.Qt.LeftButton:
            return

        match = self._canvas.snappingUtils().snapToMap(e.pos())
        cur = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        # ===== โหมดคลิกเดี่ยว: คลิกปลายทาง = ย้ายหมุดที่เลือกไว้ =====
        # ★ rc2 (audit A1-03) — กดห่างหมุดที่ arm ไว้แล้วลากจริง = กล่องเลือกใหม่ (เดิมย้ายหมุด+มุมไปปลายกล่องโดยไม่ถาม)
        if self._placing and getattr(self, "_placing_away", False) and self._press_dragged(e.pos()):
            self._placing = False
            self._placing_away = False
            self.armed = False
            self.move_anchor = None
            self._remove_guide()
            if self.drag_start_pt is None:
                return
            # ตกไปทางเลือกด้วยกล่องข้างล่าง (is_moving = False · ไม่กด Shift = เลือกใหม่แทนที่)
        elif self._placing:
            self._placing = False
            self._placing_away = False
            if self.armed and self.move_anchor is not None and self.selected_vertices:
                dx = cur.x() - self.move_anchor.x()
                dy = cur.y() - self.move_anchor.y()
                if abs(dx) > 1e-6 or abs(dy) > 1e-6:
                    if self.plugin._movenodes_execute(self.selected_vertices, dx, dy):
                        self._clear_selection()
                        iface.messageBar().pushInfo(
                            "Move Node", "ย้ายหมุดสำเร็จ — คลิกหมุดถัดไปเพื่อย้ายต่อ หรือคลิกขวาเพื่อเสร็จสิ้น")
                    else:
                        # ★ 2.3.7 (review UX-48) — ไม่ได้ย้าย ⇒ คืน marker พรีวิว (ทางคลิกย้ายไม่ได้เลื่อน แต่กันไว้ทางเดียวกัน)
                        self._restore_markers()
                        # ★ 2.3.7 (review DI-36) — ปฏิเสธเพราะ "ข้อมูลเปลี่ยนหลังเลือก" ⇒ การเลือกนี้ใช้ไม่ได้แล้ว ล้างให้เลือกใหม่
                        if getattr(self.plugin, "_movenodes_stale", False):
                            self._clear_selection()
                    # ถ้า execute ล้มเหลว (เหตุอื่น) -> คงสถานะ armed ไว้ ให้คลิกย้ายใหม่ได้
                else:
                    # คลิกที่เดิม -> ยกเลิกการเลือก
                    self._clear_selection()
            self.drag_start_pt = None
            return

        if self.drag_start_pt is None:
            return

        if self.is_moving:
            # ===== ปล่อยเมาส์หลังลากย้าย -> Execute =====
            # ★ 2.3.7 (review UX-11) — drag_start_pt = พิกัดของ "ชิ้นที่กดโดน" (ไม่ใช่จุด snap) ⇒ คลิกเฉย ๆ บนชิ้นที่เลือกไว้
            #   ได้ dx,dy ≠ 0 เสมอ (กดห่างชิ้นนั้น 1-2 px หรือ snap ติดเป้าข้าง ๆ) ⇒ ตัดสิน "ลากจริงไหม" จากระยะที่เมาส์
            #   ขยับบนจอ (เกณฑ์มาตรฐานของระบบ startDragDistance) ไม่ใช่จาก dx,dy
            #   ไม่งั้นแค่คลิกบนหมุดที่เลือกไว้ = ย้ายทั้งชุดไปเท่าระยะที่คลิกพลาดโดยไม่ได้ตั้งใจ
            _pp = self._press_pos
            try:
                _dragged = (_pp is None or (e.pos() - _pp).manhattanLength()
                            >= QtWidgets.QApplication.startDragDistance())
            except Exception:
                _dragged = True
            dx = cur.x() - self.drag_start_pt.x()
            dy = cur.y() - self.drag_start_pt.y()
            if self.drag_band:
                try:
                    self._canvas.scene().removeItem(self.drag_band)
                except Exception:
                    pass
                self.drag_band = None
            self.is_moving = False

            if _dragged and (abs(dx) > 1e-6 or abs(dy) > 1e-6):
                self.drag_start_pt = None
                if self.plugin._movenodes_execute(self.selected_vertices, dx, dy):
                    self._clear_selection()
                    iface.messageBar().pushInfo("Move Node", "ย้ายหมุดสำเร็จ — Shift+ลากเลือกหมุดอื่นต่อได้ หรือคลิกขวาเพื่อเสร็จสิ้น")
                else:
                    # ★ 2.3.7 (review UX-48) — ไม่ได้ย้าย (ตอบ No ที่ด่าน/ล้มเหลว) ⇒ คืน marker พรีวิวกลับตำแหน่งจริง
                    #   เดิมค้างตรงที่ลากไป ทั้งที่ข้อมูลไม่ขยับ แล้วกดบน marker ที่ค้างกลายเป็นเริ่มกล่องใหม่
                    self._restore_markers()
                    # ★ 2.3.7 (review DI-36) — ปฏิเสธเพราะ "ข้อมูลเปลี่ยนหลังเลือก" ⇒ ล้างการเลือกให้เลือกใหม่
                    if getattr(self.plugin, "_movenodes_stale", False):
                        self._clear_selection()
                return
            # ไม่ได้ลากจริง (คลิกบนชิ้นที่เลือกไว้) ⇒ คืน marker · คงการเลือกไว้
            #   (เดิม: ถ้าตอนปล่อย snap ไม่ติดอะไร = ล้างการเลือกทั้งชุด)
            self._restore_markers()
            if not (e.modifiers() & QtCore.Qt.ShiftModifier):
                self.drag_start_pt = None
                return
            # Shift+คลิก (ไม่ได้ลาก) ⇒ "เลือกเพิ่มตรงจุดนั้น" ทางเดียวกับ Shift+คลิกที่อื่น
            #   (กล่องหมุดซ้อนจึงเปิดได้เมื่อคลิกซ้ำที่มุมที่มีหมุดซ้อน — เดิมได้เฉพาะตอน snap ไม่ติด)
            self.drag_start_pt = QgsPointXY(cur)

        if not self.is_moving:
            # ===== เลือกหมุด: คลิกจุดเดียว = arm คลิกย้าย / ลากกล่อง = หลายหมุด (ลากย้าย) =====
            shift = bool(e.modifiers() & QtCore.Qt.ShiftModifier)
            raw = QgsRectangle(self.drag_start_pt, cur)
            self.drag_start_pt = None
            if self.box_band:
                try:
                    self._canvas.scene().removeItem(self.box_band)
                except Exception:
                    pass
                self.box_band = None

            # คลิกเฉยๆ (กล่องเล็กมาก) = เลือกจุดเดียว ; ลากจริง = กล่องครอบหลายจุด
            # ★ 28 ส.ค. 69 — แยกสองหน้าที่ที่เดิมใช้ตัวแปรเดียวกัน:
            #   click_slop = "มือขยับไปเท่าไหร่บนจอ" -> ตัดสินว่าคลิกหรือลาก = เรื่องของ UI
            #                ต้องเป็นพิกเซลล้วน **ห้ามใส่เพดานเมตร** ไม่งั้นที่ zoom กว้าง
            #                มือสั่น 5 px (= 5 ม.) จะถูกอ่านเป็น "ลากกล่อง" แทนที่จะเป็นคลิก
            #   tol        = "รัศมีค้นหารอบจุดที่คลิก" -> เรื่องของภูมิศาสตร์ = ต้องมีเพดานเมตร
            click_slop = self._canvas.mapUnitsPerPixel() * 5
            is_click = raw.width() < click_slop * 2 and raw.height() < click_slop * 2
            if is_click:
                # ★ 31 ส.ค. 69 (แก้รอบสอง) — เคยใส่ rect.combineExtentWith(raw) ไว้ตรงนี้
                #   ด้วยเหตุผลว่า "ของที่ลากคลุมไว้หาย" แต่คิดผิด: การขยับต่ำกว่า 10 พิกเซล
                #   คือ "มือสั่น" ไม่ใช่การลากที่ตั้งใจ (เกณฑ์เดียวกับ startDragDistance ของ Qt)
                #   การรวม raw เข้ามาทำให้เพดาน 0.60 ม. ไร้ผลทันทีที่มือขยับแม้แต่พิกเซลเดียว
                #   ที่ 1:5000 มือสั่น 9 px = คว้าไป 12 ม. ซึ่งคือสิ่งที่เพดานตั้งใจกัน
                #   -> คลิก = ใช้กรอบรอบจุดที่คลิกเท่านั้น (มีเพดาน) · ลากจริง = ใช้กล่องที่ลาก
                tol = self._click_tol()
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol,
                                    cur.x() + tol, cur.y() + tol)
            else:
                rect = raw

            # Shift = สะสมเพิ่มจากการเลือกเดิม ; ไม่กด = เลือกใหม่ (แทนที่)
            # ★ 2.3.7 (review UX-12) — จำการเลือกเดิมไว้ (โหมด Shift) เผื่อกด Cancel ที่กล่องหมุดซ้อน ⇒ คืนของเดิม
            _before = (list(self.selected_vertices), set(self.selected_keys)) if shift else None
            if self._select_vertices_in_rect(rect, add_mode=shift) is False:
                return       # ★ 2.4.0 (review DI-44) แปลงพิกัดไม่ได้ — แจ้งแล้ว · ไม่ arm/ไม่เด้งกล่องหมุดซ้อนจากการเลือกเดิม

            # ★ 3 ก.ย. 69 (v2.2.3) - เด้ง popup เลือกกรณีคลิกแล้วเจอของซ้อนทับกันหลายชิ้น
            # 🔴🔴 4 ก.ย. 69 (2.2.4 · ผู้ตรวจวัดจริง) - เงื่อนไขเดิมกว้างเกินไปมาก
            #   `len(self.selected_vertices) > 1` นับรวม "มุมแปลง" ด้วย ซึ่งคลิกเดียวได้ >=2 เสมอ
            #   (หมุด 1 + มุมแปลง 1 + จุดปิดวงอีก 1) ⇒ วัดได้ว่า **เด้งทุกคลิก** ที่มีแปลงถูกเลือก
            #   ไม่ใช่เฉพาะ "ของซ้อนทับกัน" ตามที่รายงาน 2.2.3 ตั้งใจไว้เอง
            #   และร้ายกว่านั้น: ถ้าพนักงานติ๊กมุมแปลงออกบางตัวแล้วย้าย จะได้
            #   **มุมแปลงเลื่อนโดยหมุดไม่ตาม = หมุดลอย + เกิดร่องกับแปลงข้างเคียง** (พิสูจน์แล้ว)
            #   ซึ่งขัดกับเป้าหมายสายผลิตโดยตรง และไม่มีด่านไหนขวางเลย
            # ⇒ กติกาที่เจ้าของงานเคาะ (4 ก.ย. 69):
            #     เด้งเฉพาะเมื่อ **เลือกแปลงไว้ก่อน** และจุดที่คลิกมี **หมุดของ "แปลงที่เลือก" ซ้อนกัน >= 2 ตัว**
            #     ถ้าไม่ได้เลือกแปลง -> ย้ายได้ตามปกติ ไม่มีกล่องเด้ง
            #   ★ ต้องนับ "เฉพาะหมุดที่ UTM ตรงกับแปลงที่เลือก" ไม่ใช่หมุดทุกตัวที่จุดนั้น
            #     เพราะมุมร่วมระหว่าง 4 แปลง มีหมุดของใครของมัน 4 ตัวเป็นเรื่องปกติ
            #     ถ้านับรวมจะกลับไปเด้งทุกคลิกเหมือนเดิม
            # 🔴 4 ก.ย. 69 (2.2.5) — ย้ายการนับออกไปเป็นเมธอด `_stacked_marker_count()`
            #   เหตุผล: 2.2.4 นับ "รวมทุกแปลงที่เลือก" เป็นเลขเดียว ⇒ เลือก 3 แปลงแล้วคลิก
            #   มุมร่วม ได้ 3 (แปลงละ 1 ดวง = เรื่องปกติของงานนี้) > 1 = เด้ง ทั้งที่ไม่มี
            #   แปลงไหนมีหมุดซ้อนเลย · ของใหม่ถามว่า "มีแปลงใด ที่มุมใด มีหมุดของตัวเอง >= 2"
            #   และแยกเป็นเมธอดเพื่อให้ชุดเทสเรียกได้ตรง ๆ (เดิมเทสต้องตัดสตริงจากไฟล์ = เปราะ)
            # ★ 2.3.7 (review UX-12) — หา "ของตรงจุดที่คลิก" (_near) ก่อน แล้วนับหมุดซ้อนจาก _near เท่านั้น
            #   เดิมนับจากการเลือกสะสมทั้งกอง ⇒ มีคู่หมุดซ้อนอยู่ที่ไหนสักแห่งในกอง = ทุก Shift+คลิกมุมธรรมดาก็เด้งกล่อง
            #   (ตรรกะ _near/_far ของ 18 ก.ย. ย้ายขึ้นมาจากในบล็อกกล่อง — เหตุผลอยู่ในคอมเมนต์ 🔴 ข้างล่าง)
            _near, _far = None, []
            if is_click and self.selected_vertices:
                _r = self._click_tol()
                _has_pt = [v for v in self.selected_vertices if v.get('pt') is not None]
                if not _has_pt:
                    _near = list(self.selected_vertices)   # กรองไม่ได้จริง -> พฤติกรรมเดิม
                else:
                    _near = [v for v in _has_pt if v['pt'].distance(cur) <= _r]
                # คลิกไม่โดนอะไรเลย -> **ไม่เด้งกล่อง** และไม่แตะการเลือกที่มีอยู่
                _near_ids = {id(v) for v in _near}
                _far = [v for v in self.selected_vertices if id(v) not in _near_ids]
            self._stack_scope = _near
            _n_marker = self._stacked_marker_count() if is_click else 0
            self._stack_scope = None
            if is_click and self.selected_vertices and self.poly_lyr and _n_marker > 1:
                if self.poly_lyr.selectedFeatureIds() and len(self.selected_vertices) > 1:
                    # 🔴 18 ก.ย. 69 (2.3.0 · ผู้ตรวจ Windows วัดจริง) — เดิมวน `selected_vertices`
                    #   **ทั้งกอง** ไม่ใช่เฉพาะชิ้นที่อยู่ตรงจุดที่คลิก ⇒ กด Shift ลากกรอบสะสม 205 มุม
                    #   แล้ว Shift+คลิกมุมที่มีหมุดซ้อน จะได้กล่อง **205 แถว** ให้ไล่หา + คิวรี 205 ครั้ง
                    #   (โตแบบ 1:1 · ที่ 900 มุม ≈ 1.5 วินาที) ทั้งที่คำถามคือ
                    #   "ตรงจุดที่คลิกมีอะไรซ้อนกันบ้าง" ซึ่งปกติมี 2-3 แถว
                    #   🔑 ของที่อยู่ไกลจากจุดคลิก **ต้องไม่ถูกแตะ** — เดิมถ้าผู้ใช้เลือกในกล่อง
                    #      ของสะสมที่เหลือจะถูกทิ้งหมด ของใหม่เก็บไว้เหมือนเดิม
                    # 🔴 18 ก.ย. รอบ 2 — ทางถอยเดิม (`if not _near`) **กว้างเกินไป**
                    #   ตั้งใจจับกรณี "ไม่มี pt เลย" แต่ดันจับ "คลิกไม่โดนอะไร" ด้วย
                    #   `_click_tol()` มีเพดาน 0.60 ม. ⇒ พอจอหยาบกว่า ~1.2 ม./พิกเซล
                    #   คลิกยังไงก็ไม่เข้ารัศมี → ตกทางถอย → กลับไปเป็นก่อนแก้ทั้งสองเรื่อง
                    #   (ผู้ตรวจ Windows วัดได้: จอครอบคลุม 800 ม. -> กล่อง 205 แถว เหลือ 1)
                    #   ⇒ แยกสองกรณีออกจากกันให้ชัด
                    # (_near / _far คำนวณไว้แล้วก่อนนับหมุดซ้อน — ★ 2.3.7 UX-12)

                    # ★ 2.3.0 — ดึงทีเดียวต่อชั้น แทน getFeature ทีละชิ้นในลูป
                    _need = {}
                    for v in _near:
                        _need.setdefault(v['layer'], set()).add(v['fid'])
                    _fmap = {}
                    for _lyr, _fids in _need.items():
                        try:
                            for _f in _lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(_fids))):
                                _fmap[(id(_lyr), _f.id())] = _f
                        except Exception:
                            pass

                    candidates = []
                    for v in _near:
                        feat = _fmap.get((id(v['layer']), v['fid']))
                        _ok = feat is not None and feat.isValid()
                        utmf = self.plugin._resolve_field(v['layer'], {'utm', 'utm_code', 'utm_id'})
                        # ★ rc2 (audit A1-09) — คีย์ว่าง/NULL จาก provider แสดง '(ไม่มี UTM)' (เดิม str() ได้ 'NULL')
                        _u = str(feat[utmf]).strip() if (utmf and _ok and feat[utmf] is not None) else ""
                        utm = ("(ไม่มี UTM)" if (not _u or _u.upper() == "NULL") else _u) if (utmf and _ok) else "?"

                        if v['layer'].geometryType() == 0:  # PointGeometry
                            nfld = self.plugin._addnode_name_field(v['layer'])
                            name = str(feat[nfld]) if nfld and _ok and feat[nfld] else "ไม่มีชื่อ"
                            candidates.append({'id': v['fid'], 'name': name, 'utm': utm, 'layer_type': 'point', 'v': v})
                        else:
                            candidates.append({'id': v['fid'], 'name': f"มุมที่ {v['vidx']}", 'utm': utm, 'layer_type': 'poly', 'v': v})

                    if len(candidates) > 1 and _near:
                        dlg = NodeSelectionDialog(candidates, self.plugin.iface.mainWindow(), multi_select=True)
                        _acc = dlg.exec_()
                        sel = dlg.get_selected() if _acc else []
                        try:
                            dlg.deleteLater()  # ★ 2.3.7 (review LC-11) — อ่านผลแล้วลบกล่อง (เดิมค้างเป็นลูกของหน้าต่างหลัก)
                        except Exception:
                            pass
                        if _acc:
                            keep_v = [s['v'] for s in sel]
                            _keep_ids = {id(x) for x in keep_v}
                            for v in _near:            # ★ เก็บ marker เฉพาะของที่อยู่ตรงจุดคลิก
                                if id(v) not in _keep_ids and v.get('marker'):
                                    # ★ 2.2.4 — ต้องเช็ค marker ก่อน (แพตเทิร์นเดียวกับ _clear_selection)
                                    try:
                                        self._canvas.scene().removeItem(v['marker'])
                                    except Exception:
                                        pass
                            self.selected_vertices = _far + keep_v
                            self.selected_keys = set((v['layer'].id(), v['fid'], v.get('vidx'))
                                                     for v in self.selected_vertices)
                        elif _before is not None:
                            # ★ 2.3.7 (review UX-12) — Cancel ในโหมด Shift = คืนการเลือกเดิม
                            #   (เดิมล้างทิ้งทั้งกองเงียบ ๆ ขณะที่แถบยังบอก "เลือก N หมุดแล้ว")
                            #   เอา marker ของชิ้นที่คลิกนี้เพิ่งเพิ่มออก · ของเดิมไม่ถูกแตะ
                            _old_ids = {id(v) for v in _before[0]}
                            for v in self.selected_vertices:
                                if id(v) not in _old_ids and v.get('marker'):
                                    try:
                                        self._canvas.scene().removeItem(v['marker'])
                                    except Exception:
                                        pass
                            self.selected_vertices, self.selected_keys = _before
                            iface.messageBar().pushInfo(
                                "Move Node", f"ยกเลิก — คงการเลือกเดิม {len(self.selected_vertices)} หมุด")
                            return
                        else:
                            self._clear_selection()

            if (not shift) and is_click and self.selected_vertices:
                # คลิกจุดเดียว -> โหมดคลิกย้าย (armed)
                self.armed = True
                # ★ 2.3.7 (review DI-39) — จุดอ้างอิงการย้าย = ชิ้นที่เลือกที่ "ใกล้จุดคลิกที่สุด"
                #   เดิม selected_vertices[0] = ชิ้นแรกตามลำดับ provider (หมุดของแปลงข้างเคียงที่ห่าง 0.4 ม. แต่อยู่ใน
                #   รัศมีคลิกมาก่อนได้) ⇒ คลิกย้ายแล้วหมุดที่ตั้งใจลงคลาดจุดปลายทางเท่าระยะนั้นโดยไม่มีอะไรเตือน
                _pts = [v['pt'] for v in self.selected_vertices if v.get('pt') is not None]
                self.move_anchor = QgsPointXY(min(_pts, key=lambda q: q.sqrDist(cur))) if _pts else None
                iface.messageBar().pushInfo(
                    "Move Node", "เลือกหมุดแล้ว — คลิกตำแหน่งใหม่เพื่อย้าย (คลิกขวา = ยกเลิก)")
                # ★ 2.3.7 (review DI-39) — คลิกเดียวได้ของหลายตำแหน่ง (เช่นหมุดของแปลงข้างเคียงในรัศมี 0.60 ม.)
                #   ทุกชิ้นจะย้ายไปพร้อมกันด้วยระยะเท่ากัน ⇒ บอกให้เห็น (เดิมเงียบ)
                if self.move_anchor is not None:
                    _m = _canvas_is_metres(self._canvas)
                    _tol = self.STACK_TOL_M if _m else 1e-7
                    _reps, _dmax = [self.move_anchor], 0.0
                    for _q in _pts:
                        _dmax = max(_dmax, _q.distance(self.move_anchor))
                        if all(_q.distance(_r0) > _tol for _r0 in _reps):
                            _reps.append(_q)
                    if len(_reps) > 1:
                        _w = f"คลิกเดียวได้ของ {len(_reps)} ตำแหน่ง"
                        if _m:
                            _w += f" (ห่างกันสุด {_dmax * 100:.0f} ซม.)"
                        iface.messageBar().pushMessage(
                            "Move Node", _w + " — ทุกชิ้นจะย้ายไปพร้อมกัน ถ้าไม่ตั้งใจ ให้ซูมเข้าแล้วคลิกใหม่",
                            level=1, duration=8)
            else:
                # ลากกล่อง / หลายหมุด -> ลากหมุดที่เลือกเพื่อย้าย (ไม่มีเส้นนำคลิกเดี่ยว)
                self.armed = False
                self._remove_guide()
                if self.selected_vertices:
                    iface.messageBar().pushInfo(
                        "Move Node", f"{self._sel_count_text()} — ลากหมุดที่เลือกเพื่อย้าย (Shift+ลาก = เลือกเพิ่ม)")   # rc2 A1-06

    def deactivate(self):
        try:
            self._selutm_unhook()        # ★ rc2 S_close (review R3-06)
        except Exception:
            pass
        self._clear_selection()
        if self.snap_marker:
            try:
                self._canvas.scene().removeItem(self.snap_marker)
            except Exception:
                pass
        super().deactivate()


class _AdminNodeTool(AddNodeTool):
    """ฐานของเครื่องมือ node (แก้ชื่อหมุด / ลบ Node / สลับหมุด): ใช้ flow เดียวกับ Add Node (คลิกแปลง -> คลิก node)
    ต่างที่ (ก) กันชน L1 ใช้ด่านเดียวกับ Add Node (`_toggle` · แตะ L1 ได้เฉพาะเมื่อกดปลดล็อก L1)
               ★ 2.3.7 (review MT-19-D) — เดิมฐานตั้ง ALLOW_LOCKED = True (ค่าปริยายไม่ปลอดภัย: คลาสลูกใหม่ที่ลืมตั้ง
               จะข้ามกันชน L1 เงียบ ๆ) ⇒ สืบ False จาก AddNodeTool · เครื่องมือที่ตกลงกันว่าแตะ L1 ได้ ต้องตั้ง True เอง
            (ข) ตอนคลิกที่หมุด เรียก action ของตัวเองแทนการเพิ่ม node"""
    TITLE = "Admin"
    HINT  = "เลือกแปลงแล้ว • คลิกที่หมุดของแปลงนี้"
    ALLOW_FREE_EDGE = False        # ★ 2.3.9 — คลิกขอบตรงที่ไม่มีหมุด = เฉพาะ Add Node (แก้ชื่อ/ลบ/สลับ ต้องมีหมุด/มุมจริง)
    # ★ 7 ก.ย. 69 (2.2.6) — เจ้าของงานสั่ง: "ปุ่มลบ node อยากให้กดที่มีแค่ node อย่างเดียวได้ด้วย"
    #   เดิมทุกเครื่องมือตระกูลนี้ต้อง snap ติด "หมุด" ก่อนถึงจะลงมือได้ (_nearest_marker)
    #   ⇒ **มุมเปลือย (node ที่ไม่มีหมุด) คลิกไม่ได้เลย** ทั้งที่ `_delete_node_execute`
    #     รองรับกรณี mk=None อยู่แล้ว ("ไม่มี (ลบเฉพาะมุมแปลง)")
    #   เปิดเฉพาะปุ่มลบ — แก้ชื่อ/สลับหมุด ยังต้องมีหมุดจริงถึงจะทำงานได้
    ALLOW_BARE_NODE = False
    SHOW_BARE = False                 # ★ 2.2.9 — เครื่องมือแก้ชื่อ/สลับ ไม่ต้องชี้มุมเปลือย

    def _do_action(self, fid, pt_xy):
        raise NotImplementedError

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._cancel()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        map_pt = self.toMapCoordinates(event.pos())
        # ★ 2.3.7 (review DI-07) — เป้าเดียวกับ Add Node/hover (ลบ Node: มุมเกินข้างมุมที่มีหมุดคลิกได้แล้ว
        #   · แก้ชื่อ/สลับหมุด ไม่รับมุม = หมุดเท่านั้นเหมือนเดิม)
        pt_xy, _map_xy, _kind = self._pick_target(map_pt)
        self._last_map_xy = _map_xy      # เครื่องมือลูกใช้วางเครื่องหมายบนหมุดที่เพิ่งคลิก
        if pt_xy is not None:
            if not self.picked:
                # ★ 2.2.9 — เจ้าของงานสั่ง "ให้คลิกเลือกแปลงก่อน เหมือน add node"
                #   เดิมถ้าคลิกโดนหมุดทั้งที่ยังไม่ได้เลือกแปลง จะได้แค่ข้อความแล้วเงียบ
                #   ซึ่งกดตรงขอบแปลงยังไงก็ติดหมุดเสมอ (ทุกมุมมีหมุด) = เลือกแปลงไม่ได้สักที
                #   -> ให้คลิกแรกทำหน้าที่ "เลือกแปลง" ไปเลย
                feat = self._poly_at(map_pt)
                if feat is not None:
                    self._toggle(feat)
                    return
                self._push("เลือกแปลงก่อน แล้วค่อยคลิกที่หมุด", 1, 5)          # ★ 2.3.7 UX-01
                return
            if self._do_action(self.picked[0][0], pt_xy):
                # รูปแปลงอาจเปลี่ยน (กรณีลบ node) -> อัปเดตไฮไลต์
                for fid, rb in self.picked:
                    feat = self.poly_lyr.getFeature(fid)
                    if feat.isValid():
                        rb.setToGeometry(feat.geometry(), self.poly_lyr)
                # ★ 2.2.9 — ของซ้อนที่เพิ่งลบไปแล้ว ต้องหายจากจอด้วย (เหตุผลเดียวกับ Add Node)
                self._refresh_dups()
                self._canvas.refresh()
        else:
            feat = self._poly_at(map_pt)
            if feat is None:
                self._push("ไม่พบแปลง/หมุดตรงนี้ — คลิกในแปลง หรือเลื่อนให้ snap ติดหมุด", 1, 4)   # ★ 2.3.7 UX-01
                return
            self._toggle(feat)


def _deny_l1(plugin, ห้าม):
    """★ 2.3.7 (review UX-13) — ข้อความเมื่อคลิกแปลง L1 (พนักงานทั่วไปเห็นได้) ⇒ ห้ามบอกโหมดซ่อน/วิธีเข้า
    อยู่ในโหมดแล้ว (plugin._admin_on) ⇒ คงคำแนะนำที่ทำได้จริง · ถ้อยคำมาจาก `plugin._l1_hint` ที่เดียว"""
    _h = getattr(plugin, "_l1_hint", None)
    if callable(_h):
        try:
            return _h(ห้าม)
        except Exception:
            pass
    return ห้าม + (" — กด 🔓 ปลดล็อก L1 ก่อน" if getattr(plugin, "_admin_on", False) else " (แจ้งผู้ดูแล)")


class RenameNodeTool(_AdminNodeTool):
    """คลิกแปลง -> คลิกหมุดของแปลงนั้น -> แก้ชื่อ (BND_NAME)

    ★ 2.2.9 — ย้ายจากกล่อง ADMIN มาโซน "เลือก / ปรับแต่ง"
      พนักงานทั่วไปแก้ได้เฉพาะหมุดที่ยังไม่มีชื่อ · โหมดผู้ดูแลแก้ได้ทุกหมุด
      (ด่านจริงอยู่ที่ `_rename_node_execute`)"""
    TITLE = "แก้ชื่อหมุด"
    HINT  = "เลือกแปลงแล้ว • คลิกที่หมุดของแปลงนี้เพื่อแก้ชื่อ"

    @property
    def DENY_MSG(self):
        # ★ 2.3.7 (review UX-13) — เดิมบอกพนักงานให้ "เปิดโหมดผู้ดูแล" ซึ่งเป็นโหมดซ่อน
        return _deny_l1(self.plugin, "ห้ามแก้ชื่อหมุด")

    # ★ 2.2.9 — เดิมสืบ ALLOW_LOCKED=True จาก _AdminNodeTool (เป็นเครื่องมือแอดมินล้วน)
    #   ตอนนี้พนักงานทั่วไปกดได้ ⇒ ต้องกันแปลงอ้างอิง L1 เหมือนปุ่มอื่นทุกปุ่ม
    #   🔑 ตั้ง False ไปเลย ไม่ผูกกับ `_admin_on` — เพราะเจ้าของงานสั่งว่าต้อง
    #      **เปิดโหมดผู้ดูแล *และ* กดปลดล็อก** ถึงจะแตะ L1 ได้ ซึ่งด่านใน `_toggle`
    #      ทำให้อยู่แล้วผ่าน `_admin_unlock_l1` (ปิดโหมด = ถูกรีเซ็ตเป็น False)
    ALLOW_LOCKED = False

    def _do_action(self, fid, pt_xy):
        return self.plugin._rename_node_execute(self.poly_lyr, fid, pt_xy)


class DeleteNodeTool(_AdminNodeTool):
    """แอดมิน: คลิกแปลง -> คลิก node ของแปลงนั้น -> ลบมุมแปลง + หมุดของแปลงนั้นพร้อมกัน
    (ตรงข้ามกับ Add Node — กติกาเหล็กจึงคงอยู่เอง ไม่เกิดมุมเปลือย)"""
    TITLE = "ลบ Node"
    HINT  = "เลือกแปลงแล้ว • คลิกที่ node ของแปลงนี้เพื่อลบ (มุมที่ไม่มีหมุดก็คลิกได้)"

    @property
    def DENY_MSG(self):
        # ★ 2.3.7 (review UX-13) — เดิมบอกพนักงานให้ "เปิดโหมดผู้ดูแล" ซึ่งเป็นโหมดซ่อน
        return _deny_l1(self.plugin, "ห้ามลบ Node")

    ALLOW_BARE_NODE = True            # ★ 2.2.6 — คลิกมุมที่ไม่มีหมุดได้ (ดูคอมเมนต์ที่ _AdminNodeTool)
    SHOW_DUPS = True                  # ★ 2.2.9 — ไฮไลต์ "ของซ้อน" ให้เห็นทันทีที่เลือกแปลง
    SHOW_BARE = False                 # มุมเปลือยเป็นงานของ ➕ Add Node ไม่ใช่ปุ่มนี้
    ALLOW_LOCKED = False              # ★ 2.2.9 — เหตุผลเดียวกับ RenameNodeTool

    def _do_action(self, fid, pt_xy):
        return self.plugin._delete_node_execute(self.poly_lyr, fid, pt_xy)


class SwapNodeTool(_AdminNodeTool):
    """สลับ "ตำแหน่ง" ของหมุดสองตัวใน "แปลงเดียวกัน"

    ★ 31 ส.ค. 69 — พนักงานเจอเคสชื่อหมุดสลับลำดับกันบ่อย เดิมต้องพึ่งแอดมิน
      กด ✏️ แก้ชื่อหมุด ทีละตัวสองรอบ ซึ่งมีจังหวะที่ชื่อซ้ำกันชั่วคราว
    ★ สลับ geom ไม่ใช่สลับ BND_NAME — ได้ผลเหมือนกัน (ชื่อไปอยู่จุดที่ถูก) แต่
      พนักงานมี GRANT UPDATE เฉพาะ geom/SCORE ของชั้นหมุด เขียนชื่อไม่ได้
      และการย้าย geom ถูกบันทึกใน <D>_Move_Log เป็น 'moved' พร้อม geom ก่อน/หลัง
    ★ 2.4.0 (review DI-13) — "เขียนชื่อไม่ได้" ข้างบนเป็นสิทธิ์ของ 31 ส.ค. · ตั้งแต่ 18 ก.ย. พนักงานได้ UPDATE(BND_NAME)
      ของชั้นหมุดเพิ่มแล้ว (ดู main.py: _can_update_column_uncached) · เครื่องมือนี้ยังสลับ "ตำแหน่ง" เหมือนเดิม
      ต้องการแค่ UPDATE(geom) (start_swap_node ถามฐาน) และ log_move ตามรอยได้ครบ
    flow: คลิกแปลง -> คลิกหมุดตัวที่ 1 -> คลิกหมุดตัวที่ 2 -> ยืนยัน -> สลับ
    การจับคู่ node-หมุด ไม่เสีย เพราะชุดตำแหน่งทั้งหมดเท่าเดิม แค่สลับกันสองจุด
    ไม่ใช่เครื่องมือแอดมิน: ยังกันแปลงอ้างอิง L1-RTK/L1-TS ไว้เหมือน Add Node
    (สืบทอด _AdminNodeTool เพราะต้องการ canvasReleaseEvent แบบ "คลิกหมุด = ลงมือ"
     แล้วปิดธง ALLOW_LOCKED กลับเป็น False)"""
    TITLE = "สลับหมุด"
    HINT  = "เลือกแปลงแล้ว • คลิกหมุดตัวที่ 1 แล้วคลิกหมุดตัวที่ 2 เพื่อสลับตำแหน่งกัน"
    ALLOW_LOCKED = False
    DENY_MSG = "ห้ามสลับหมุด"

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas, plugin, poly_lyr, point_lyr)
        self.first = None        # (fid ของหมุดตัวแรก, ชื่อเดิม)
        self._first_mk = None    # เครื่องหมายสี่เหลี่ยมน้ำเงินบนหมุดตัวแรก

    def mark_first(self, map_xy):
        """วางเครื่องหมายบนหมุดตัวแรก เพื่อให้เห็นว่ากำลังจะสลับกับตัวไหน"""
        self.clear_first_mark()
        try:
            mk = QgsVertexMarker(self._canvas)
            mk.setIconType(QgsVertexMarker.ICON_BOX)
            mk.setColor(QtGui.QColor(0, 90, 255))
            mk.setPenWidth(3)
            mk.setIconSize(16)
            mk.setCenter(QgsPointXY(map_xy))
            mk.show()
            self._first_mk = mk
        except Exception:
            self._first_mk = None

    def clear_first_mark(self):
        if self._first_mk is not None:
            try:
                self._canvas.scene().removeItem(self._first_mk)
            except Exception:
                pass
            self._first_mk = None

    def clear_first(self):
        """ล้างหมุดตัวแรกที่ค้างอยู่ (ทั้งข้อมูลและเครื่องหมายบนจอ)"""
        self.first = None
        self.clear_first_mark()

    def _toggle(self, feat):
        # เปลี่ยนแปลงที่เลือก = ทิ้งหมุดตัวแรกที่ค้างไว้ (ห้ามสลับข้ามแปลง)
        self.clear_first()
        super()._toggle(feat)

    def _do_action(self, fid, pt_xy):
        return self.plugin._swap_node_execute(self.poly_lyr, fid, pt_xy, self)

    def _del_key_back(self):
        """★ 2.3.7 (audit F1) — Backspace/Delete หลังคลิกหมุดตัวที่ 1 = ถอย (ล้างหมุดตัวที่ 1 · แปลงยังเลือกอยู่) เหมือนคลิกหมุดเดิมซ้ำ"""
        if self.first is None:
            return False
        self.clear_first()
        self._push("ยกเลิกหมุดที่ 1 — เลือกใหม่ได้", 0, 4)
        return True

    def _cancel(self):
        self.clear_first()
        super()._cancel()

    def deactivate(self):
        self.clear_first()
        super().deactivate()


# ======================================================================
#  วาดเส้น / วัดระยะ  (31 ส.ค. 69)
# ======================================================================
class LineMeasureItem(QgsMapCanvasItem):
    """วาดเส้นที่ผู้ใช้ลากไว้ + ป้ายระยะรายช่วง ลงบนแคนวาสโดยตรง

    ★ ตั้งใจ **ไม่สร้างเลเยอร์ในโปรเจกต์** — เส้นเป็นของบนแคนวาสล้วน ๆ
      โปรเจกต์จึงไม่ถูกทำให้ "มีการแก้ไข" และพนักงานจะไม่โดนกล่องถามว่าจะบันทึกโปรเจกต์ไหม
      ตอนปิด QGIS (บทเรียนจากปลั๊กอินวาดเส้นตัวเดิม ที่เขียนทับค่าโปรเจกต์แล้วไม่คืน
      จนไฟล์ 5 อำเภอเพี้ยนกันคนละแบบ)
    """

    C_LINE = QtGui.QColor(21, 101, 192)     # เส้นที่วาดเสร็จแล้ว
    C_TEMP = QtGui.QColor(230, 81, 0)       # เส้นที่กำลังลาก
    C_TEXT = QtGui.QColor(20, 20, 20)
    C_HALO = QtGui.QColor(255, 255, 255, 220)

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas
        self.lines = []          # เส้นที่จบแล้ว: [[QgsPointXY, ...], ...]
        self.temp = []           # จุดของเส้นที่กำลังวาด
        self.cursor = None       # ตำแหน่งเมาส์ขณะวาด (QgsPointXY)
        self.show_labels = True
        self.show_nodes = True
        self.layer_draws_lines = True   # เส้นที่จบแล้ว ให้ชั้นจริงเป็นคนวาด
        # ★ 2.3.7 (review UX-49) — ผู้ถือชั้น (main.py) บอกว่าชั้นเส้น "มีอยู่และติ๊กแสดงอยู่" ไหม (callable → bool)
        #   ไม่มีชั้น/สร้างไม่สำเร็จ/ถูกซ่อน ⇒ ไอเทมวาดเส้นที่จบแล้วเอง (เดิมเหลือแค่จุดหักกับป้ายระยะลอย ๆ)
        self.layer_shown = None
        self.ref_line = None     # แนวอ้างอิงมุม: (จุดต้น, จุดปลาย)
        self._da = None
        self._da_key = None      # (authid ของ CRS, ทรงรี) ที่ _da ตัวปัจจุบันถูกสร้างมาเพื่อ

    # ---------- ระยะ ----------
    # ★ CRS ของงานนี้เป็น UTM (EPSG:24047) หน่วยเมตร -> ใช้ "ระยะบนกริด" ตรง ๆ
    #   จงใจไม่ใช้การวัดแบบ ellipsoid เพราะ
    #     ① งานรังวัดเทียบกับพิกัดในฐานข้อมูล ซึ่งเป็นพิกัดกริด — ระยะต้องตรงกับพิกัด
    #        ไม่ใช่ระยะบนผิวโลก (ต่างกันตามมาตราส่วนฉาย ~0.04% = 4 ซม./100 ม.)
    #     ② ถ้าพิกัดเพี้ยน (เช่นเลเยอร์ตั้ง CRS ผิด) การคำนวณแบบ ellipsoid จะให้ค่ามั่ว
    #        แบบไม่มีสัญญาณเตือน — เคยได้ 1,500 ม. จากเส้นยาว 70 ม. ตอนเทส
    #   เหลือทาง ellipsoid ไว้เฉพาะกรณี CRS โปรเจกต์ไม่ใช่เมตร (เช่นตั้งเป็น 4326)
    def _dist_area(self):
        """ตัววัดระยะ — สร้างใหม่เมื่อ CRS หรือทรงรีของโปรเจกต์เปลี่ยน

        🔴 3 ก.ย. 69 (ผู้ตรวจจับได้ · วัดซ้ำแล้ว) เดิมแคชไว้ตัวเดียวทั้งเซสชัน:
          พนักงานเห็นระยะเพี้ยน แล้วไปแก้ทรงรีที่ Project Properties ให้ถูก
          ค่าที่วัดได้ก็ยัง "เท่าเดิม" จนกว่าจะปิด-เปิด QGIS ใหม่
        🔴 และถ้าทรงรีเป็น NONE (ค่าเริ่มต้นของ QGIS) measureLine จะคืนค่าเป็น "องศา"
          บนโปรเจกต์ที่ใช้ CRS เชิงมุม ⇒ ระยะจริง ~108 ม. ถูกรายงานว่า "0.1 ซม."
          โดยไม่มีคำเตือนใด ๆ (คอมเมนต์ข้างบนระบุว่ามีไฟล์อำเภอจริงตั้ง EPSG:4326)
          ⇒ ถ้าไม่ได้ตั้งทรงรีไว้ ให้ใช้ WGS84 แทน จะได้ค่าเป็นเมตรตามที่ป้ายบอก
          (กรณีปกติของงานนี้คือ UTM หน่วยเมตร ซึ่งไม่ผ่านทางนี้อยู่แล้ว — ดู seg_len)
        """
        prj = QgsProject.instance()
        try:
            crs = self._canvas.mapSettings().destinationCrs()
            ell = prj.ellipsoid()
            key = (crs.authid(), ell)
        except Exception:
            crs, ell, key = None, None, None
        if self._da is None or getattr(self, "_da_key", None) != key:
            da = QgsDistanceArea()
            try:
                if crs is not None:
                    da.setSourceCrs(crs, prj.transformContext())
                if not ell or str(ell).strip().upper() in ("", "NONE"):
                    da.setEllipsoid("WGS84")
                else:
                    da.setEllipsoid(ell)
            except Exception:
                pass
            self._da = da
            self._da_key = key
        return self._da

    def seg_len(self, a, b):
        if _canvas_is_metres(self._canvas):
            return a.distance(b)              # ระยะบนกริด = ตรงกับพิกัดในฐานข้อมูล
        try:
            d = self._dist_area().measureLine(a, b)
            if d and d > 0:
                return d
        except Exception:
            pass
        return a.distance(b)

    def line_len(self, pts):
        return sum(self.seg_len(pts[i], pts[i + 1]) for i in range(len(pts) - 1))

    def total_len(self):
        return sum(self.line_len(p) for p in self.lines if len(p) > 1)

    @staticmethod
    def fmt(d):
        """★ 2.3.6 (1 ต.ค. 69 เจ้าของงานสั่ง "ตัวแสดงระยะในแผนที่จะแสดงเป็นเมตรตลอด")
        เดิม < 1 ม. เป็น ซม. · ≥ 1 กม. เป็น กม. ⇒ เป็นเมตรอย่างเดียว (ต่ำกว่า 1 ม. ทศนิยม 3 = ละเอียด 1 มม. เท่าเดิม)
        ใช้ทั้งป้ายบนแผนที่ · ผลการวัด · ข้อความคัดลอก"""
        if d < 1:
            return "%.3f ม." % d
        return "{:,.2f} ม.".format(d)

    # ---------- QGraphicsItem ----------
    def boundingRect(self):
        """กรอบสำหรับ Qt ใช้ตัดสินว่าต้องวาดหรือไม่

        🔴 1 ก.ย. 69 — ห้ามโยน exception เด็ดขาด
          Qt เรียกเมธอดนี้ระหว่างจัดวางซีน ถ้าโยน exception ไอเทมจะ "เงียบไปทั้งตัว"
          = เส้น preview / จุดหัก / ป้ายระยะ หายพร้อมกันแบบไม่มีสัญญาณเตือน
          เกิดจริงได้: ปลั๊กอินถูก reload (self-update) แล้วไอเทมเก่ายังอยู่ในซีน
          -> self._canvas เป็นวัตถุ C++ ที่ถูกลบไปแล้ว -> RuntimeError
          (จับได้ตอนรันเทสจริง: "wrapped C/C++ object of type QgsMapCanvas has been deleted")
        """
        w = h = 4000
        try:
            vp = self._canvas.viewport()
            r = vp.rect() if vp is not None else self._canvas.rect()
            w, h = r.width(), r.height()
        except Exception:
            pass
        # เผื่อขอบกว้าง ๆ กันป้ายระยะที่ล้นออกนอกจอถูกตัดทิ้ง
        return QtCore.QRectF(-2000, -2000, w + 4000, h + 4000)

    def updatePosition(self):
        try:
            self.prepareGeometryChange()
            self.update()
        except Exception:
            pass

    def _canvas_pts(self, pts):
        out = []
        for p in pts:
            try:
                # ลบ pos() แบบเดียวกับ QgsRubberBand ของ QGIS
                # วันนี้ pos() เป็น (0,0) เสมอ (คลาสนี้ override updatePosition จึงไม่มีใครเรียก setRect)
                # จึงเป็นการลบศูนย์ — ใส่ไว้กันวันที่มีคนเผลอเรียก setRect/setPos แล้วภาพเลื่อนทั้งชุด
                out.append(self.toCanvasCoordinates(p) - self.pos())
            except Exception:
                return []
        return out

    def _text(self, painter, pos, txt):
        """ข้อความมีขอบขาว อ่านออกทั้งบนภาพดาวเทียมและพื้นขาว"""
        painter.setFont(self._font)
        painter.setPen(QtGui.QPen(self.C_HALO, 3))
        path = QtGui.QPainterPath()
        path.addText(pos, self._font, txt)
        painter.drawPath(path)
        painter.setPen(QtGui.QPen(self.C_TEXT))
        painter.fillPath(path, QtGui.QBrush(self.C_TEXT))

    def paint(self, painter, *args):
        try:
            self._paint(painter)
        except Exception:
            # 🔴 exception ใน paint ทำให้ Qt เลิกวาดไอเทมนี้ทั้งตัว
            #   ยอมให้เฟรมนั้นว่างดีกว่าไอเทมตายถาวร
            pass

    def _paint(self, painter):
        if not self.lines and not self.temp and not self.ref_line:
            return
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        self._font = QtGui.QFont()
        self._font.setPointSize(9)
        self._font.setBold(True)

        def draw(pts, colour, dashed=False, stroke=True):
            cv = self._canvas_pts(pts)
            if len(cv) < 1:
                return
            pen = QtGui.QPen(colour, 2)
            if dashed:
                pen.setStyle(QtCore.Qt.DashLine)
            painter.setPen(pen)
            if stroke:
                for i in range(len(cv) - 1):
                    painter.drawLine(cv[i], cv[i + 1])
            if self.show_nodes:
                painter.setBrush(QtGui.QBrush(colour))
                painter.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255), 1))
                for c in cv:
                    painter.drawEllipse(c, 3.5, 3.5)
            if self.show_labels:
                for i in range(len(cv) - 1):
                    mid = QtCore.QPointF((cv[i].x() + cv[i + 1].x()) / 2.0,
                                         (cv[i].y() + cv[i + 1].y()) / 2.0)
                    self._text(painter, mid + QtCore.QPointF(4, -4),
                               self.fmt(self.seg_len(pts[i], pts[i + 1])))

        _by_layer = self.layer_draws_lines
        if _by_layer and self.layer_shown is not None:
            try:
                _by_layer = bool(self.layer_shown())      # ★ 2.3.7 (UX-49)
            except Exception:
                _by_layer = False
        for pts in self.lines:
            # เส้นที่วาดเสร็จแล้ว ให้ QGIS วาดจาก "ชั้นเส้นที่วาด (Line)" แทน
            # (ชั้นจริงทำให้ snap ติดได้ และวาดเสถียรกว่าไอเทมบนแคนวาส)
            # ตรงนี้เหลือหน้าที่แค่จุดหักกับป้ายระยะ — ★ 2.3.7 เว้นแต่ชั้นไม่มี/ถูกซ่อน ⇒ วาดเส้นเองด้วย
            draw(pts, self.C_LINE, stroke=not _by_layer)
            if self.show_labels and len(pts) > 2:
                cv = self._canvas_pts(pts)
                if cv:
                    self._text(painter, cv[-1] + QtCore.QPointF(6, 16),
                               "รวม " + self.fmt(self.line_len(pts)))

        if self.temp:
            live = list(self.temp)
            if self.cursor is not None:
                live.append(self.cursor)
            draw(live, self.C_TEMP, dashed=True)

        # แนวอ้างอิงมุม — เส้นประบาง ๆ สีเขียว ไม่นับเป็นเส้นวัด
        if self.ref_line:
            cv = self._canvas_pts(list(self.ref_line))
            if len(cv) == 2:
                pen = QtGui.QPen(QtGui.QColor(46, 125, 50), 2, QtCore.Qt.DashDotLine)
                painter.setPen(pen)
                painter.drawLine(cv[0], cv[1])
                if self.show_labels:
                    mid = QtCore.QPointF((cv[0].x() + cv[1].x()) / 2.0,
                                         (cv[0].y() + cv[1].y()) / 2.0)
                    self._text(painter, mid + QtCore.QPointF(4, 14),
                               "แนวอ้างอิง %.2f°" % azimuth(*self.ref_line))

    # ---------- จัดการเส้น ----------
    def clear_all(self):
        self.lines = []
        self.temp = []
        self.cursor = None
        self.updatePosition()

    def undo_last(self):
        if self.temp:
            self.temp.pop()
        elif self.lines:
            self.lines.pop()
        self.updatePosition()


class _HeldMouse:
    """★ 2.3.7 (review UX-50) — อีเวนต์เมาส์จำลอง ณ ตำแหน่งล่าสุด (pos/modifiers เท่าที่ DrawLineTool._point ใช้)
    ใช้คำนวณพรีวิวใหม่ตอนกด/ปล่อย Shift โดยไม่ขยับเมาส์"""

    def __init__(self, pos, mods):
        self._p, self._m = pos, mods

    def pos(self):
        return self._p

    def modifiers(self):
        return self._m


class DrawLineTool(_MlepKeys, QgsMapTool):
    """วาดเส้นวัดระยะบนแคนวาส

    คลิกซ้าย = ลงจุด · คลิกขวา หรือ ดับเบิลคลิก = จบเส้น
    Backspace = ถอยจุดล่าสุด · Esc = ทิ้งเส้นที่กำลังวาด
    ★ 2.3.7 (DI-25) Ctrl+Z (คีย์ Undo ของปลั๊กอิน) = ถอยจุด/เส้น — main.py _guarded ส่งไป _line_undo
    เกาะหมุด/มุมแปลงตามค่า snapping ของโปรเจกต์
    ★ 2.3.6 (1 ต.ค. 69 เจ้าของงานสั่ง)
      Shift ค้าง + ไม่ติ๊กล็อกมุม = ล็อกแนวที่กำลังลาก (จับแนวตอนเริ่มกด Shift) แล้วยืด/หดตามแนวนั้นได้
                                   เล็งด้วยหมุด/มุมที่ snap ได้ ไม่งั้นใช้เมาส์จริง (★ รอบ 6) · คลิกต่อทั้งที่กดค้าง = ต่อบนแนวเดิม
      Shift ค้าง + ติ๊กล็อกมุม  = ปัดมุมทีละขั้น นับจากแนวช่วงก่อนหน้า (ช่วงแรกนับจากทิศเหนือ)
      Ctrl+คลิก = ลงจุดตามปกติ (เลิกใช้ "แนวอ้างอิงมุม" แล้ว)
    """

    def __init__(self, canvas, item, on_change, on_ref=None):
        super().__init__(canvas)
        self._canvas = canvas
        self._item = item
        self._on_change = on_change
        self._on_ref = on_ref
        self._snap = QgsSnapIndicator(canvas)
        self.setCursor(QtCore.Qt.CrossCursor)
        # ---- ตัวล็อก (แผงเป็นคนตั้งค่า) ----
        self.lock_dist = None      # ระยะคงที่ (เมตร) หรือ None
        self.lock_angle = None     # ขั้นของมุม (องศา) หรือ None — ทำงานเมื่อกด Shift ค้าง
        # ★ 2.3.6 — None = นับมุมจากแนวช่วงก่อนหน้าของเส้นที่กำลังวาด (ช่วงแรกนับจากทิศเหนือ) ← แผงตั้งแบบนี้
        #   ตัวเลข = อาซิมุทคงที่ที่ใช้เป็นศูนย์องศาแบบเดิม (เหลือไว้ให้โค้ด/เทสเก่า)
        self.angle_basis = None
        self._ref_pts = []         # เลิกใช้แล้ว (2.3.6 ไม่มีแนวอ้างอิง Ctrl+คลิก) · คงไว้ให้โค้ดล้างค่าเดิม
        # ★ 2.3.6 — ล็อกแนว (Shift ค้าง ตอนไม่ติ๊กล็อกมุม)
        self._dir_az = None        # อาซิมุทของแนวที่ล็อกอยู่ · None = ยังไม่ล็อก
        self._dir_anchor = None    # ★ รอบ 6 — จุดตั้งต้นของแนวที่ล็อก (ใช้ตัดสินตอนถอยจุดว่ายังอยู่บนแนวเดิมไหม)
        self._dir_block = False    # ★ รอบ 7 — คลิกทั้งที่กด Shift ตอนยังไม่มีแนว ⇒ ยังไม่ล็อกจนกว่าจะปล่อยแล้วกด Shift ใหม่
        self._snap_vertex = False  # ★ รอบ 6 — จุดดิบล่าสุด snap ติด "หมุด/มุม" (ไม่ใช่แค่ลงเส้นขอบ)
        self._last_pos = None      # ★ 2.3.7 (UX-50) — ตำแหน่งเมาส์ล่าสุด (พิกเซล) ไว้คำนวณพรีวิวใหม่ตอนกด/ปล่อย Shift

    # ---------- ช่วยเหลือ ----------
    @staticmethod
    def _mods(e):
        try:
            return e.modifiers()
        except Exception:
            return QtWidgets.QApplication.keyboardModifiers()

    def _raw(self, e):
        """จุดดิบ: เกาะ snap ถ้าเกาะได้ ไม่งั้นใช้ตำแหน่งเมาส์ตรง ๆ"""
        try:
            m = self._canvas.snappingUtils().snapToMap(e.pos())
        except Exception:
            m = None
        if m is not None and m.isValid():
            self._snap.setMatch(m)
            # ★ รอบ 7 (ผู้ตรวจ B 2.1) — snap ที่เป็น "จุด" ทุกชนิด (หมุด/มุม · ปลายเส้น · กลางด้าน · centroid) = จุดเล็ง
            #   เดิมดูแค่ hasVertex() ⇒ ติ๊ก Line Endpoints เองแล้วเล็งปลายเส้น ได้ทิศเมาส์แทน (คลาด 0.16°)
            #   ที่ไม่ใช่จุด = snap ลงเส้นขอบ (Edge) หรือในพื้นที่ (Area) เท่านั้น
            try:
                self._snap_vertex = not (m.hasEdge() or m.hasArea())
            except Exception:
                self._snap_vertex = False
            return QgsPointXY(m.point())
        self._snap_vertex = False
        try:
            self._snap.setMatch(self._empty_match())
        except Exception:
            pass
        return self.toMapCoordinates(e.pos())

    def constrain(self, prev, raw, shift=False, basis=None):
        """บังคับจุดใหม่ให้เข้าล็อกระยะ/ล็อกมุม/ล็อกแนว เทียบจากจุดก่อนหน้า

        ล็อกมุม (ติ๊ก "กด Shift เพื่อล็อกมุม" + กด Shift ค้าง):
                 ปัดอาซิมุทให้เป็นจำนวนเท่าของ lock_angle โดยนับจาก basis
                 basis = ผู้เรียกส่งมา (_point ส่ง "แนวช่วงก่อนหน้า") · ไม่ส่ง = angle_basis · ไม่มีอีก = ทิศเหนือ
        ล็อกแนว (ไม่ติ๊ก + กด Shift ค้าง · ★ 2.3.6): ฉายเมาส์ลงบนแนว _dir_az ที่จับไว้ตอนเริ่มกด Shift
                 = ยืด/หดตามแนวนั้นได้ (ลากถอยข้ามจุดก่อนหน้า = อีกฝั่งของแนวเดียวกัน)
        ล็อกระยะ: บังคับความยาวช่วงให้เท่ากับ lock_dist เป๊ะ
        ★ ถ้าหน่วยแผนที่ไม่ใช่เมตร จะไม่บังคับระยะ เพราะตัวเลขจะคนละหน่วยกับที่พิมพ์
        """
        if prev is None:
            return raw
        az = azimuth(prev, raw)
        d = math.hypot(raw.x() - prev.x(), raw.y() - prev.y())
        # ★ 2.3.7 (review DI-41) — เมาส์ทับจุดก่อนหน้าพอดี = เวกเตอร์ยาวศูนย์ ไม่มีทิศ ⇒ คืนจุดเดิม
        #   เดิมไหลต่อไปใช้ทิศ 0° (atan2(0, 0)) ⇒ ล็อกระยะ 5 ม. ได้จุด "ทิศเหนือ 5 ม." โดยไม่มีอะไรบอก
        if d < 1e-9:
            return QgsPointXY(prev)
        along = False
        if shift and self.lock_angle:
            step = float(self.lock_angle)
            if step > 0:
                b0 = float(basis if basis is not None else (self.angle_basis or 0.0))
                # ★ รอบ 6 — มุมเลี้ยวในช่วง [-180, 180) ก่อนปัด (เดิม [0, 360) ⇒ ขั้นที่หาร 360 ไม่ลงตัว
                #   เลี้ยวซ้ายกลายเป็นขวา/เพี้ยน เช่น ขั้น 150° เลี้ยวซ้าย 150° ได้ขวา 150° · ขั้น 7° เอียงซ้าย 1° ได้ซ้าย 3°)
                rel = ((az - b0 + 180.0) % 360.0) - 180.0
                rel = round(rel / step) * step
                az = (b0 + rel) % 360.0
        elif shift and self._dir_az is not None:
            a0 = math.radians(self._dir_az)
            t = (raw.x() - prev.x()) * math.sin(a0) + (raw.y() - prev.y()) * math.cos(a0)
            az = self._dir_az if t >= 0 else (self._dir_az + 180.0) % 360.0
            d = abs(t)
            along = True
        if self.lock_dist and _canvas_is_metres(self._canvas):
            d = float(self.lock_dist)
        if d <= 0:
            # ล็อกแนวอยู่ แต่เมาส์ตั้งฉากตรงจุดก่อนหน้าพอดี -> อยู่บนแนว (= จุดก่อนหน้า) ไม่หลุดไปตามเมาส์
            return QgsPointXY(prev) if along else raw
        a = math.radians(az)
        return QgsPointXY(prev.x() + d * math.sin(a), prev.y() + d * math.cos(a))

    def _prev_seg_az(self):
        """อาซิมุทของช่วงก่อนหน้าในเส้นที่กำลังวาด (ข้ามช่วงยาวศูนย์) · ยังไม่มีช่วง = None"""
        tp = self._item.temp
        for j in range(len(tp) - 1, 0, -1):
            a, b = tp[j - 1], tp[j]
            if math.hypot(b.x() - a.x(), b.y() - a.y()) > 1e-9:
                return azimuth(a, b)
        return None

    def _on_dir_line(self, q):
        """จุด q อยู่บนแนวที่ล็อกอยู่ไหม (ห่างแนวไม่เกิน 1e-6 หน่วยแผนที่ = 1 µm เมื่อแผนที่เป็นเมตร
        — จุดที่ลงด้วยการฉายลงแนวคลาดแค่เศษทศนิยม)"""
        if q is None or self._dir_az is None or self._dir_anchor is None:
            return False
        a = math.radians(self._dir_az)
        vx, vy = q.x() - self._dir_anchor.x(), q.y() - self._dir_anchor.y()
        return abs(vx * math.cos(a) - vy * math.sin(a)) <= 1e-6

    def _dir_min(self):
        """เมาส์ต้องห่างจุดก่อนหน้าเกิน 30 พิกเซลก่อนจับแนวล็อก (ทิศจากระยะไม่กี่พิกเซลยังไม่นิ่ง)
        ★ รอบ 7 — เดิม 10 px: พิกัดเมาส์เป็นพิกเซลเต็ม ⇒ ทิศหยาบขั้นละ ~5.7° (30 px ≈ 1.9°)"""
        try:
            return 30.0 * float(self._canvas.mapUnitsPerPixel())
        except Exception:
            return 0.0

    def _point(self, e):
        raw = self._raw(e)
        prev = self._item.temp[-1] if self._item.temp else None
        shift = bool(self._mods(e) & QtCore.Qt.ShiftModifier)
        # ★ 2.3.6 — ล็อกแนว (ไม่ติ๊กล็อกมุม): จับแนว "ตอนเริ่มกด Shift" แล้วค้างไว้จนปล่อย Shift
        # ★ รอบ 6 (ผู้ตรวจ B) — "จุดเล็ง" = หมุด/มุมที่ snap ติด หรือ **ตำแหน่งเมาส์จริง**
        #   เดิมใช้จุดที่ snap แล้วเสมอ ⇒ เมาส์อยู่ในรัศมี snap ของเส้นขอบแปลง (ปลั๊กอินตั้ง 20 px) จุดถูกดูดลงเส้นขอบ
        #   ⇒ แนวที่ล็อกกลายเป็นทิศของขอบแปลง (ลากทิศ 60° จากมุมแปลง ได้ 90°) ไม่ใช่ทิศที่ลาก
        aim = raw if self._snap_vertex else self.toMapCoordinates(e.pos())
        if not shift:
            self._dir_az = None
            self._dir_block = False
        elif self.lock_angle or prev is None:
            self._dir_az = None
        elif self._dir_az is None and not self._dir_block:
            # ★ รอบ 8 (ผู้ตรวจ B N1) — เล็งด้วยจุดที่ snap ติด (พิกัดแม่นอยู่แล้ว) จับได้ทันทีที่ไม่ใช่จุดเดียวกัน
            #   ระยะ 30 px มีไว้เฉพาะตอนเล็งด้วยเมาส์ (พิกเซลเต็ม ⇒ ทิศหยาบ) — เดิมหมุดที่อยู่ชิดจุดก่อนหน้าบนจอ (ซูมออก)
            #   ต้องรอเมาส์ออกเกิน 30 px แล้วได้ทิศเมาส์แทนทิศหมุด
            _ขั้นต่ำ = 1e-9 if self._snap_vertex else self._dir_min()
            if math.hypot(aim.x() - prev.x(), aim.y() - prev.y()) > _ขั้นต่ำ:
                self._dir_az = azimuth(prev, aim)
                self._dir_anchor = QgsPointXY(prev)
        basis = self.angle_basis
        if basis is None:
            basis = self._prev_seg_az()
            if basis is None:
                basis = 0.0                 # ช่วงแรกของเส้น ยังไม่มีช่วงก่อนหน้า -> ทิศเหนือ
        if shift and self._dir_az is not None and not self.lock_angle:
            # ล็อกแนวอยู่: ฉายจุดเล็งลงแนว (เล็งหมุด = ได้เงาของหมุดบนแนว) · snap ลงเส้นขอบไม่ได้ใช้ ⇒ ไม่โชว์ตัวชี้หลอก
            if not self._snap_vertex:
                try:
                    self._snap.setMatch(self._empty_match())
                except Exception:
                    pass
            return self.constrain(prev, aim, shift, basis)
        return self.constrain(prev, raw, shift, basis)

    # ---------- แนวอ้างอิงมุม (Ctrl + คลิกซ้าย 2 จุด) ----------
    def _ref_click(self, e):
        self._ref_pts.append(self._raw(e))
        if len(self._ref_pts) >= 2:
            a, b = self._ref_pts[-2], self._ref_pts[-1]
            self._ref_pts = []
            self._item.ref_line = (a, b)
            self.angle_basis = azimuth(a, b)
            if self._on_ref:
                try:
                    self._on_ref(self.angle_basis)
                except Exception:
                    pass
        self._changed()

    @staticmethod
    def _empty_match():
        from qgis.core import QgsPointLocator
        return QgsPointLocator.Match()

    def _changed(self):
        self._item.updatePosition()
        if self._on_change:
            try:
                self._on_change()
            except Exception:
                pass

    def _finish(self):
        if len(self._item.temp) >= 2:
            self._item.lines.append(list(self._item.temp))
        self._item.temp = []
        self._item.cursor = None
        self._dir_az = None
        self._dir_block = False
        self._changed()

    # ---------- เหตุการณ์ ----------
    def canvasMoveEvent(self, e):
        try:
            self._last_pos = QtCore.QPoint(e.pos())      # ★ 2.3.7 (UX-50)
        except Exception:
            pass
        if self._item.temp:
            self._item.cursor = self._point(e)
            self._item.updatePosition()
        else:
            self._point(e)          # ให้ตัวชี้ snap ขึ้นตั้งแต่ยังไม่เริ่มลาก

    def canvasPressEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._finish()
            return
        if e.button() != QtCore.Qt.LeftButton:
            return
        # ★ 2.3.6 (1 ต.ค. 69 เจ้าของงานสั่งเอา "แนวอ้างอิงมุม" ออก) — Ctrl+คลิก = ลงจุดตามปกติ
        #   (เดิม Ctrl+คลิก 2 จุด = ตั้งแนวอ้างอิง ไม่ลงจุด)
        shift = bool(self._mods(e) & QtCore.Qt.ShiftModifier)
        จุด = self._point(e)
        มีแนว = self._dir_az is not None
        self._item.temp.append(จุด)
        # ★ รอบ 6 — ยังกด Shift ค้าง = ช่วงต่อไปอยู่บนแนวเดิม (จุดที่เพิ่งลงอยู่บนแนวนั้นแล้ว) ⇒ ลงจุดต่อกันบนแนวตรงได้
        #   (เดิมต้องปล่อยแล้วกดใหม่ แล้วแนวใหม่จับจากเมาส์ = ไม่ตรงแนวเดิม) · ปล่อย Shift = หลุด
        # ★ รอบ 7 (ผู้ตรวจ B 2.2) — แต่ถ้าคลิกทั้งที่กด Shift ตอน "ยังไม่มีแนว" (เช่นจุดแรกของเส้น) ⇒ ช่วงต่อไปยังไม่ล็อก
        #   จนกว่าจะปล่อยแล้วกด Shift ใหม่ (ไม่งั้นแนวถูกจับจากการขยับเมาส์ช่วงแรก — คลาด 2.7° โดยไม่มีอะไรเตือน)
        if not shift:
            self._dir_az = None
            self._dir_block = False
        else:
            self._dir_block = not มีแนว
        self._changed()

    def canvasDoubleClickEvent(self, e):
        self._finish()

    def keyPressEvent(self, e):
        # 🔴 2.3.6 (audit รอบ 2 เจอ · มีมาตั้งแต่ 31 ส.ค.) — เดิมเรียก e.accept() ซึ่งใน QGIS แปลว่า "ไม่ได้จัดการ"
        #   ⇒ แคนวาสยิง keyPressed ต่อ ⇒ กด Backspace/Delete เพื่อถอยจุดของเส้น แล้ว QGIS สั่ง
        #   "ลบฟีเจอร์ที่เลือกไว้" ของชั้นที่ใช้อยู่ด้วย (ไม่ถามถ้าฟีเจอร์ที่เลือกอยู่ในจอ)
        #   ⇒ ต้อง ignore() = "เครื่องมือกินคีย์แล้ว" (QgsMapCanvas::keyPressEvent เขียนอธิบายไว้ว่ากลับด้านโดยตั้งใจ)
        k = e.key()
        if k == QtCore.Qt.Key_Escape:
            self._dir_az = None
            self._dir_block = False
            if self._item.temp:
                self._item.temp = []
                self._item.cursor = None
                self._changed()
            self._กินคีย์(e)
        elif k in (QtCore.Qt.Key_Backspace, QtCore.Qt.Key_Delete):
            if self._item.temp:
                self._item.temp.pop()
                self._changed()
            # ★ รอบ 6 — ยังกด Shift ค้างแล้วถอยจุดที่ลงบนแนว = แก้คลิกพลาดโดยไม่หลุดแนว
            #   ถอยเลยจุดตั้งต้นของแนว (จุดก่อนหน้าไม่อยู่บนแนวแล้ว) ⇒ ปล่อยแนว · ปล่อย Shift เมื่อไหร่ก็หลุดตามปกติ
            if not self._on_dir_line(self._item.temp[-1] if self._item.temp else None):
                self._dir_az = None
            self._กินคีย์(e)
        elif k in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
            self._finish()
            self._กินคีย์(e)
        elif k == QtCore.Qt.Key_Shift:
            # ★ 2.3.7 (review UX-50) — กด Shift โดยไม่ขยับเมาส์: พรีวิวต้องเปลี่ยนตามทันที (จับแนว/ปัดมุมตอนกด)
            #   ไม่ ignore() — Shift ยังส่งต่อให้ QGIS ตามเดิม
            self._shift_preview(True, e)

    def _shift_preview(self, shift, e=None):
        """★ 2.3.7 (review UX-50) — คำนวณพรีวิวใหม่ ณ ตำแหน่งเมาส์ล่าสุดเมื่อกด/ปล่อย Shift
        เดิมคำนวณแค่ตอนเมาส์ขยับ ⇒ โหมดล็อกมุม: กด Shift ไม่ขยับ พรีวิวไม่เปลี่ยนแต่คลิกลงจุดที่ปัดมุม
        (คลาดจากพรีวิว 149 ม. ในเรขาคณิตทดสอบ) · ปล่อย Shift ไม่ขยับ พรีวิวค้างที่จุดปัดมุมแต่คลิกลงจุดดิบ
        ไม่สนอีเวนต์ซ้ำจากการกดค้าง (auto-repeat) — แนวที่ล็อกต้องไม่เปลี่ยน"""
        try:
            _rep = getattr(e, "isAutoRepeat", None) if e is not None else None
            if _rep is not None and _rep():
                return
            if not self._item.temp or self._last_pos is None:
                return
            mods = QtCore.Qt.ShiftModifier if shift else QtCore.Qt.NoModifier
            self._item.cursor = self._point(_HeldMouse(self._last_pos, mods))
            self._item.updatePosition()
        except Exception:
            pass

    def keyReleaseEvent(self, e):
        # ★ รอบ 7 — ปล่อย Shift = หลุดแนว + ปลดตัวกัน ทันที (เดิมรู้แค่ตอนเมาส์ขยับโดยไม่กด Shift
        #   ⇒ ปล่อยแล้วกด Shift ใหม่โดยไม่ขยับเมาส์ ตัวกัน/แนวเดิมค้างอยู่) · ไม่แตะการส่งต่อคีย์ของ QGIS
        try:
            # ★ รอบ 8 — ไม่สน release ปลอมจาก auto-repeat (กด Shift ค้างแล้วแนวต้องไม่หลุดเอง)
            _ซ้ำ = getattr(e, "isAutoRepeat", None)
            if e.key() == QtCore.Qt.Key_Shift and not (_ซ้ำ is not None and _ซ้ำ()):
                self._dir_az = None
                self._dir_block = False
                self._shift_preview(False)       # ★ 2.3.7 (UX-50) — พรีวิวกลับเป็นจุดดิบทันที ไม่ต้องรอเมาส์ขยับ
        except Exception:
            pass

    @staticmethod
    def _กินคีย์(e):
        """ignore() = "เครื่องมือกินคีย์แล้ว" ในภาษาของ QGIS (★ 2.3.6 audit รอบ 2) · ห่อ try ไว้ให้ทนอีเวนต์จำลองในเทส"""
        try:
            e.ignore()
        except Exception:
            pass

    def deactivate(self):
        # จบเส้นที่ค้างอยู่ให้เรียบร้อย ไม่ทิ้งเส้นครึ่ง ๆ กลาง ๆ ไว้บนจอ
        try:
            self._finish()
            self._snap.setMatch(self._empty_match())
        except Exception:
            pass
        super().deactivate()
