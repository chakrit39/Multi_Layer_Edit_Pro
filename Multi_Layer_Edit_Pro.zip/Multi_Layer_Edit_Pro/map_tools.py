"""
QGIS Map Tools for Multi-Layer Edit Pro
"""
import math

from qgis.core import (
    QgsProject, QgsFeatureRequest, QgsGeometry, QgsRectangle,
    QgsWkbTypes, QgsCoordinateTransform, QgsPointXY, QgsUnitTypes,
    QgsDistanceArea
)
from qgis.gui import (QgsMapTool, QgsRubberBand, QgsVertexMarker,
                      QgsMapCanvasItem, QgsSnapIndicator)
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.utils import iface

class NodeSelectionDialog(QtWidgets.QDialog):
    def __init__(self, candidates, parent=None, multi_select=False):
        super().__init__(parent)
        self.setWindowTitle("พบวัตถุซ้อนทับกัน โปรดเลือก")
        self.setWindowModality(QtCore.Qt.WindowModal)
        self.resize(400, 250)
        self.multi_select = multi_select
        self.layout = QtWidgets.QVBoxLayout(self)
        self.layout.addWidget(QtWidgets.QLabel("พบวัตถุหลายชิ้นซ้อนทับกัน กรุณาเลือก:"))
        self.list_widget = QtWidgets.QListWidget()
        if not multi_select:
            self.list_widget.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        for c in candidates:
            text = f"[{'หมุด' if c.get('layer_type') == 'point' else 'แปลง'}] "
            text += f"{c.get('name', 'ไม่มีชื่อ')} (UTM: {c.get('utm', '?')}) [ID: {c.get('id', '?')}]"
            item = QtWidgets.QListWidgetItem(text)
            if multi_select:
                item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
                item.setCheckState(QtCore.Qt.Checked)
            item.setData(QtCore.Qt.UserRole, c)
            self.list_widget.addItem(item)
        if not multi_select and self.list_widget.count() > 0:
            self.list_widget.setCurrentRow(0)
        self.layout.addWidget(self.list_widget)
        self.btn_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        self.btn_box.accepted.connect(self.accept)
        self.btn_box.rejected.connect(self.reject)
        self.layout.addWidget(self.btn_box)

    def get_selected(self):
        selected = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if self.multi_select:
                if item.checkState() == QtCore.Qt.Checked:
                    selected.append(item.data(QtCore.Qt.UserRole))
            else:
                if item.isSelected():
                    selected.append(item.data(QtCore.Qt.UserRole))
        return selected

def _canvas_is_metres(canvas):
    """แคนวาสคิดระยะเป็นเมตรหรือไม่

    ★ 31 ส.ค. 69 — ค่าคงที่ที่เขียนเป็น "เมตร" (เพดาน/พื้นของรัศมีค้นหา) ใช้ได้
    เฉพาะเมื่อ CRS ของ *โปรเจกต์* มีหน่วยเป็นเมตร. Khlongluang_V2 ตั้ง projectCrs
    เป็น EPSG:4326 ทั้งที่ทุกเลเยอร์เป็น EPSG:24047 -> mapUnitsPerPixel() คืนค่า
    เป็นองศา ค่าคงที่เมตรจึงกลายเป็นองศาแล้วบานเป็นกิโลเมตร
    """
    try:
        return (canvas.mapSettings().destinationCrs().mapUnits()
                == QgsUnitTypes.DistanceMeters)
    except Exception:
        return False

def azimuth(a, b):
    """อาซิมุทจาก a ไป b — องศา นับจากทิศเหนือ วนตามเข็ม (0-360)

    ใช้ระบบเดียวกับงานรังวัด (เหนือ=0 ตะวันออก=90) ไม่ใช่ atan2 แบบคณิตศาสตร์
    """
    import math as _m
    dx = b.x() - a.x()
    dy = b.y() - a.y()
    return _m.degrees(_m.atan2(dx, dy)) % 360.0


class BoxSelectTool(QgsMapTool):
    """ลากกล่องเลือก point features (สะสมหลายรอบ); คลิกขวา=เสร็จ, Ctrl+ลาก=เอาออก, Esc=ยกเลิก"""

    def __init__(self, canvas, on_box, on_finish, on_cancel):
        super().__init__(canvas)
        self._canvas = canvas
        self._on_box = on_box
        self._on_finish = on_finish
        self._on_cancel = on_cancel
        self._start = None
        self._band = None
        self.setCursor(QtCore.Qt.CrossCursor)

    def canvasPressEvent(self, e):
        if e.button() != QtCore.Qt.LeftButton:
            return
        self._start = self.toMapCoordinates(e.pos())
        self._band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        self._band.setColor(QtGui.QColor(255, 0, 0, 60))
        self._band.setWidth(1)

    def canvasMoveEvent(self, e):
        if self._start is None or self._band is None:
            return
        cur = self.toMapCoordinates(e.pos())
        self._band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self._start, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_band(); self._start = None
            self._on_finish()
            return
        if e.button() == QtCore.Qt.LeftButton and self._start is not None:
            cur = self.toMapCoordinates(e.pos())
            rect = QgsRectangle(self._start, cur)
            self._clear_band(); self._start = None
            if rect.width() < 1e-9 and rect.height() < 1e-9:
                tol = self._canvas.mapUnitsPerPixel() * 6
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol, cur.x() + tol, cur.y() + tol)
            remove = bool(e.modifiers() & QtCore.Qt.ControlModifier)
            self._on_box(rect, remove)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._clear_band()
            self._on_cancel()

    def _clear_band(self):
        if self._band:
            try:
                self._canvas.scene().removeItem(self._band)
            except Exception:
                pass
            self._band = None

    def deactivate(self):
        self._clear_band()
        super().deactivate()


class PolygonPickTool(QgsMapTool):
    """cursor กากบาท + ไฮไลต์แปลงใต้เมาส์ (ก่อนคลิก) เป็นตัวช่วยตัดสินใจ
    คลิก = ส่ง feature กลับผ่าน click_cb ; เลื่อนเมาส์ = hover_cb"""

    # hover ยิง getFeatures ทุก mouse-move = 1 query/เฟรมบน PostgreSQL -> รวบยอดทุก ~80ms
    HOVER_MS = 80

    def __init__(self, canvas, layer, click_cb, hover_cb):
        super().__init__(canvas)
        self._canvas = canvas
        self._layer = layer
        self._click_cb = click_cb
        self._hover_cb = hover_cb
        self._last_fid = None
        self._picked = False
        self.setCursor(QtCore.Qt.CrossCursor)
        # cache transform ครั้งเดียว (เดิมสร้างใหม่ทุก mouse-move ตอน hover)
        proj = QgsProject.instance()
        self._xform = None
        if layer.crs() != proj.crs():
            try:
                self._xform = QgsCoordinateTransform(proj.crs(), layer.crs(), proj)
            except Exception:
                self._xform = None
        # throttle hover: เก็บตำแหน่งล่าสุดไว้ ประมวลผลตาม timer แทนทุกเฟรม
        self._pending_pos = None
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(self.HOVER_MS)
        self._hover_timer.timeout.connect(self._hover_tick)

    def _feature_at_pos(self, pos):
        """หา feature ในเลเยอร์ที่เลือก ใต้ตำแหน่ง pixel pos (None ถ้าไม่มี)"""
        map_pt = self.toMapCoordinates(pos)   # CRS ของโปรเจกต์
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
            except Exception:
                pt = map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))

        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                pass

        # 🔴🔴 3 ก.ย. 69 (2.2.4) — 2.2.2 ใส่ setLimit(1) เพื่อกันค้าง แต่ทำให้ "ผิด" ได้:
        #   setFilterRect กรองด้วย "กรอบสี่เหลี่ยม" ของรูป แล้วบรรทัดล่างค่อยเช็ค intersects จริง
        #   ⇒ limit=1 แล้วบังเอิญได้แปลงข้างเคียงที่กรอบคลุมเมาส์แต่รูปไม่คลุม = คืน None
        #     ทั้งที่มีแปลงอยู่ใต้เมาส์จริง ⇒ ไฮไลต์หายเป็นช่วง ๆ เฉพาะบริเวณแปลงเบียดกัน
        #     ซึ่งคือบริเวณที่พนักงานต้องใช้มากที่สุด
        #   ⇒ ยังจำกัดจำนวนเพื่อกันค้าง (เจตนาเดิมของ 2.2.2 ถูก) แต่ต้องมากพอให้ยังถูกต้อง
        #   ★ 4 ก.ย. 69 วัดกับอำเภอจริง (a18.shp 183,057 แปลง สุ่ม 400 จุด): จำนวนแปลงที่ "กรอบ"
        #     คลุมจุดคลิก p95 = 4-12 ที่ 1:600-1:12,000 (ช่วงที่ทำงานจริง) แต่พุ่งเป็น 85 ที่ 1:60,000
        #     ⇒ 50 พอสำหรับงานปกติ แต่ 200 ครอบถึง ~1:60,000 โดยไม่แพงขึ้นจริง
        #   ★ ห้ามใส่ .setNoGeometry() (รายงาน 2.2.2 แนะนำไว้) เพราะบรรทัดล่างเรียก f.geometry()
        req = QgsFeatureRequest().setFilterRect(rect).setNoAttributes().setLimit(200)
        for f in self._layer.getFeatures(req):
            if f.geometry().intersects(gp):
                return f
        return None

    def canvasMoveEvent(self, event):
        # เก็บตำแหน่งไว้ก่อน — query จริงเกิดใน _hover_tick ตามรอบ timer
        self._pending_pos = event.pos()
        if not self._hover_timer.isActive():
            self._hover_timer.start()

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None:
            return
        # ไฮไลต์แปลงใต้เมาส์ (อัปเดตเฉพาะเมื่อเปลี่ยนแปลง)
        feat = self._feature_at_pos(pos)
        fid = feat.id() if feat is not None else None
        if fid == self._last_fid:
            return
        self._last_fid = fid
        self._hover_cb(feat, self._layer)

    def _features_at_pos(self, pos):
        """คืน "ทุกแปลง" ในเลเยอร์ที่ครอบจุดที่คลิก (แปลงซ้อนกัน) พร้อม attribute
        intersects กับ "จุดคลิกจริง" (ไม่ใช่กล่อง) = เฉพาะแปลงที่ครอบจุดนั้นจริง ; เรียงพื้นที่เล็ก->ใหญ่"""
        map_pt = self.toMapCoordinates(pos)
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
            except Exception:
                pt = map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                pass
        out = []
        for f in self._layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            g = f.geometry()
            if g is not None and not g.isNull() and g.intersects(gp):
                out.append(f)
        try:
            out.sort(key=lambda ff: ff.geometry().area())   # แปลงเล็ก (มักเป็นแปลงในซ้อน) อยู่บนสุด
        except Exception:
            pass
        return out

    def _choose_parcel(self, feats):
        """แปลงซ้อนกัน >1 -> popup ให้เลือกตามระวาง UTMMAP1-4 / UTMSCALE / LANDNO ; คืน None ถ้ายกเลิก"""
        def gv(f, name):
            try:
                if f.fields().indexOf(name) < 0:
                    return ""
                v = f[name]
                return "" if v is None else str(v).strip()
            except Exception:
                return ""
        labels = []
        for f in feats:
            m4 = gv(f, "UTMMAP4") or "00"
            labels.append(
                f"ระวาง {gv(f,'UTMMAP1')} {gv(f,'UTMMAP2')} {gv(f,'UTMMAP3')}-{m4}"
                f"  |  มาตราส่วน {gv(f,'UTMSCALE')}  |  เลขที่ดิน {gv(f,'LANDNO')}")
        item, ok = QtWidgets.QInputDialog.getItem(
            iface.mainWindow(), "เลือกแปลง (มีแปลงซ้อนกัน)",
            f"จุดที่คลิกมี {len(feats)} แปลงซ้อนกัน — เลือกแปลงที่ต้องการค้นหา:",
            labels, 0, False)
        if not ok:
            return None
        return feats[labels.index(item)]

    def keyPressEvent(self, e):
        # ★ ข้อความแนะนำของทุกผู้ใช้ tool นี้ (ค้นหาภาพลักษณ์/ลบทั้งแปลง) สัญญาว่า "Esc = ยกเลิก"
        #   แต่เดิมไม่มี handler -> Esc ไม่ทำอะไร เครื่องมือ (รวมตัวลบ) ค้าง arm อยู่ (2026-08-05)
        if e.key() == QtCore.Qt.Key_Escape:
            # ★ ต้องสลับไปเครื่องมือเลือกปกติ (2026-08-06 release gate)
            #   unsetMapTool เฉย ๆ ทำให้ canvas ไม่มี map tool เลย (คลิกแล้วไม่มีอะไรตอบสนอง
            #   + cursor กลับเป็นลูกศรจนผู้ใช้เข้าใจว่าโปรแกรมค้าง) · actionSelect ทำให้ deactivate()
            #   ทำงานตามปกติ (ล้าง hover + ข้อความ) แล้วได้เครื่องมือเลือกมาตรฐานกลับมา
            iface.actionSelect().trigger()

    def canvasReleaseEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        # เก็บ "ทุกแปลง" ที่ครอบจุดคลิก — ถ้าซ้อนกัน >1 ให้ผู้ใช้เลือกตามระวาง (image + survey ใช้ tool นี้ทั้งคู่)
        feats = self._features_at_pos(event.pos())
        if not feats:
            iface.messageBar().pushMessage(
                "DOL", "ไม่พบแปลงในเลเยอร์ที่เลือกตรงตำแหน่งที่คลิก ลองใหม่อีกครั้ง", level=1, duration=6)
            return
        if len(feats) == 1:
            chosen = feats[0]
        else:
            chosen = self._choose_parcel(feats)
            if chosen is None:
                return   # ผู้ใช้ยกเลิก popup
        # ดึง feature เต็มตาม id ให้ชัวร์ทุก provider (บาง provider คืน NULL ถ้าไม่มี attribute)
        full = self._layer.getFeature(chosen.id())
        if full is None or not full.isValid():
            full = chosen
        self._picked = True
        self._click_cb(full, self._layer)

    def deactivate(self):
        self._hover_timer.stop()
        self._pending_pos = None
        # ถ้าเลิกใช้เครื่องมือโดยไม่ได้คลิก -> ลบไฮไลต์ hover + ข้อความแนะนำที่ค้างอยู่
        if not self._picked:
            try:
                self._hover_cb(None, self._layer)
            except Exception:
                pass
            try:
                iface.messageBar().clearWidgets()
            except Exception:
                pass
        super().deactivate()


class AddNodeTool(QgsMapTool):
    """เพิ่ม node ให้แปลง + เพิ่มหมุด (ไม่ต้องคลิกขวา)
    - คลิกในแปลง = เลือก/เอาออก (ไฮไลต์เขียว, หลายแปลงได้)
    - เลื่อนเมาส์ใกล้หมุด = snap (วงกลมแดง) -> คลิกตอนนั้น = แทรก node เข้าทุกแปลงที่เลือก + เพิ่มหมุด
    - คลิกขวา / Esc = ยกเลิก"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.picked = []          # [(fid, rubberband)]
        self.setCursor(QtCore.Qt.CrossCursor)
        proj = QgsProject.instance()
        self._to_poly = (QgsCoordinateTransform(proj.crs(), poly_lyr.crs(), proj)
                         if poly_lyr.crs() != proj.crs() else None)
        self._to_pt = (QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj)
                       if point_lyr.crs() != proj.crs() else None)
        self._from_pt = (QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
                         if point_lyr.crs() != proj.crs() else None)
        # ตัวบอก snap = วงกลมแดงที่เด้งไปเกาะหมุดใกล้สุด
        self._snap_mk = QgsVertexMarker(canvas)
        self._snap_mk.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self._snap_mk.setColor(QtGui.QColor(255, 0, 0))
        self._snap_mk.setPenWidth(3)
        self._snap_mk.setIconSize(14)
        self._snap_mk.hide()
        # hover highlight แปลงใต้เมาส์ก่อนคลิก (เหลือง) เป็นตัวช่วยตัดสินใจ
        self._hover_rb = None
        self._hover_fid = None
        # throttle hover: เดิมยิงสูงสุด 2 query ต่อ mouse-move (_nearest_marker + _poly_at)
        # -> บน PostgreSQL คือ 2 round-trips ต่อเฟรม; รวบยอดประมวลผลทุก ~80ms แทน
        self._pending_pos = None
        self._hover_timer = QtCore.QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(80)
        self._hover_timer.timeout.connect(self._hover_tick)

    def _poly_at(self, map_pt):
        pt = self._to_poly.transform(map_pt) if self._to_poly else map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))
        tol = self._canvas.mapUnitsPerPixel() * 3
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol, map_pt.x() + tol, map_pt.y() + tol)
        if self._to_poly is not None:
            try:
                rect = self._to_poly.transformBoundingBox(rect)
            except Exception:
                pass
        
        # ★ ต้องดึงฟิลด์ Type มาด้วย — ห้ามใช้ setNoAttributes() ตรงนี้
        #   feature ที่ได้จากนี่ถูกส่งต่อให้ _poly_type_str() (บรรทัด ~332 _toggle และ ~366 _set_hover)
        #   เพื่อเช็คว่าเป็นแปลงล็อก L1-RTK/L1-TS หรือไม่
        #   บน provider PostGIS setNoAttributes() ทำให้ attribute เป็น None ทั้งหมด (พิสูจน์แล้วกับชั้นจริง)
        #   -> Type=None -> ไม่เข้าเงื่อนไข ("L1-RTK","L1-TS") -> กันชนไม่ทำงานเลยใน Add Node
        #   (memory layer ไม่ strip จึงไม่เคยเห็นบั๊กนี้ตอนทดสอบ)
        #   ดึงเฉพาะฟิลด์ Type ฟิลด์เดียว ไม่ใช่ทั้งแถว -> ยังเบาอยู่บน hover path
        # ★ 4 ก.ย. 69 (2.2.4) — จำกัดจำนวนเหมือน _feature_at_pos ของ PolygonPickTool
        #   ทางนี้อยู่บน hover ที่ยิงทุก 80 มิลลิวินาที และเดิมไม่มีเพดานเลย
        #   ปลอดภัยที่จะจำกัด เพราะคืน "ตัวแรกที่ intersects" ไม่มีการเรียงลำดับ
        #   200 มาจากการวัดกับอำเภอจริง (a18.shp): p95 ของแปลงที่กรอบคลุมจุด = 85 ที่ 1:60,000
        req = QgsFeatureRequest().setFilterRect(rect).setLimit(200)
        ti = self.poly_lyr.fields().indexOf(self.plugin._resolve_field(self.poly_lyr, {'type'}) or "")
        if ti >= 0:
            req.setSubsetOfAttributes([ti])
        else:
            req.setNoAttributes()
        for f in self.poly_lyr.getFeatures(req):
            if f.geometry().intersects(gp):
                return f
        return None

    def _nearest_marker(self, map_pt):
        """หาหมุดใกล้สุดในรัศมี snap -> (xy ใน CRS หมุด, xy ใน CRS แผนที่) หรือ (None, None)"""
        # 12px เพดาน 25 ม. (เดิมไม่มีเพดาน ตอน zoom-out ระดับอำเภอ กรอบ ~1.2 กม.
        # ดึงหมุดหลักพันจาก PostGIS ทุกครั้งที่ขยับเมาส์) — แต่การันตี >=4px เสมอ:
        # เพดานล้วน ๆ ทำให้จุดคลิกเล็กกว่าไอคอนหมุดตอน zoom-out ลึก (คลิกบนหมุด
        # ที่เห็น ๆ แล้วพลาด -> ตกไปเลือกแปลงแทน = ได้แปลงผิดตัว)
        _mupp = self._canvas.mapUnitsPerPixel()
        if _canvas_is_metres(self._canvas):
            map_tol = max(min(max(_mupp * 12, 0.5), 25.0), _mupp * 4)
        else:
            # แคนวาสไม่ใช่เมตร (เช่น projectCrs 4326): พื้น 0.5 จะกลายเป็น 0.5 องศา
            # ~55 กม. -> ดึงหมุดทั้งอำเภอจาก PostGIS ทุก 80 มิลลิวินาทีที่เลื่อนเมาส์
            # 🔴 4 ก.ย. 69 (2.2.4) — คอมเมนต์ข้างบนอธิบายปัญหาไว้ตั้งแต่แรก แต่โค้ดไม่เคยใส่
            #   เพดานให้ทางนี้ (ใส่แค่ทางเมตร) และมีไฟล์อำเภอจริงที่ตั้งเป็น EPSG:4326 อยู่
            #   ⇒ บนไฟล์นั้น hover ดึงหมุดหลักหมื่นทุก 80 มิลลิวินาที และมีสิทธิ์ snap หมุด
            #     ที่อยู่ห่างหลายสิบกิโลเมตร = เขียนพิกัดผิดลงฐานโดยไม่มีคำเตือน
            #   ★ ห้ามใส่ setLimit แทน เพราะฟังก์ชันนี้ต้องได้ "ตัวใกล้สุดจริง"
            #     ถ้าจำกัดจำนวนจะได้หมุดชุดสุ่มมาเทียบ -> snap ผิดตัว (ร้ายกว่าอาการค้าง)
            #     การคุมด้วย "รัศมี" จึงถูกกว่า: ลดงานโดยไม่เปลี่ยนคำตอบในระยะที่ใช้จริง
            #   25 ม. ที่ละติจูดของงานนี้ ~ 0.000226 องศา (ใช้ค่าคงที่ ไม่ต้องแปลง CRS
            #   ตอน hover ซึ่งต้องเบาที่สุด) และการันตี >=4px เหมือนทางเมตร
            _DEG_25M = 0.000226
            map_tol = max(min(_mupp * 12, _DEG_25M), _mupp * 4)
        rect = QgsRectangle(map_pt.x() - map_tol, map_pt.y() - map_tol, map_pt.x() + map_tol, map_pt.y() + map_tol)
        if self._to_pt is not None:
            try:
                rect = self._to_pt.transformBoundingBox(rect)
            except Exception:
                pass
                
        best = None
        best_map = None
        bestd = map_tol * map_tol
            
        for f in self.point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes()):
            xy = f.geometry().asPoint()
            map_xy = self._from_pt.transform(xy) if self._from_pt else QgsPointXY(xy)
            d = (map_xy.x() - map_pt.x()) ** 2 + (map_xy.y() - map_pt.y()) ** 2
            if d <= bestd:
                bestd = d
                best = xy
                best_map = map_xy
        if best is None:
            return None, None
        return best, best_map

    def _add_highlight(self, feat):
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(0, 170, 0))
        rb.setFillColor(QtGui.QColor(0, 170, 0, 60))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        return rb

    # ★ 31 ส.ค. 69 — ย้ายข้อความ/กติกาขึ้นมาเป็นตัวแปรของคลาส เพื่อให้เครื่องมือลูก
    #   (แอดมิน + สลับหมุด) ใช้ _toggle ตัวเดียวกันได้ ไม่ต้องก๊อปโค้ดไปแก้ทีละที่
    #   ALLOW_LOCKED = True เฉพาะเครื่องมือแอดมินที่ตกลงกันว่าแตะแปลงอ้างอิง L1 ได้
    TITLE = "Add Node"
    HINT  = "เลือกแปลงแล้ว • เลื่อนไปที่หมุด (snap) แล้วคลิกเพื่อเพิ่ม node"
    ALLOW_LOCKED = False
    DENY_MSG = "ห้ามเพิ่ม node"

    def _toggle(self, feat):
        # กันชน: ห้ามเลือกแปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
        if not self.ALLOW_LOCKED:
            tp = self.plugin._poly_type_str(self.poly_lyr, feat)
            if tp in ("L1-RTK", "L1-TS") and not self.plugin._admin_unlock_l1:
                iface.messageBar().pushMessage(
                    self.TITLE, f"แปลง {feat.id()} เป็น {tp} (พิกัดอ้างอิง) — {self.DENY_MSG}",
                    level=2, duration=6)
                return
        # เลือกได้ทีละ 1 แปลง: คลิกแปลงใหม่ = แทนที่ • คลิกแปลงเดิมซ้ำ = ยกเลิก
        fid = feat.id()
        already = bool(self.picked) and self.picked[0][0] == fid
        self._clear_highlights()
        if already:
            iface.messageBar().pushInfo(self.TITLE, "ยกเลิกเลือกแปลง — คลิกเลือกแปลงใหม่ได้")
            return
        self.picked = [(fid, self._add_highlight(feat))]
        iface.messageBar().pushInfo(self.TITLE, self.HINT)

    def _set_hover(self, feat):
        """ไฮไลต์แปลงใต้เมาส์ (เหลือง) — ข้ามถ้าเป็นแปลงที่เลือกอยู่แล้ว (เขียว)"""
        fid = feat.id() if feat is not None else None
        if feat is not None and self.picked and self.picked[0][0] == fid:
            feat, fid = None, None
        if fid == self._hover_fid:
            return
        self._hover_fid = fid
        if self._hover_rb is not None:
            try:
                self._canvas.scene().removeItem(self._hover_rb)
            except Exception:
                pass
            self._hover_rb = None
        if feat is None:
            return
        # แปลงอ้างอิง L1-RTK/L1-TS = แดง (ห้ามเลือก) • ปกติ = เหลือง · ★ admin ปลดล็อก -> ไม่แดง (แก้ได้)
        locked = (self.plugin._poly_type_str(self.poly_lyr, feat) in ("L1-RTK", "L1-TS")
                  and not self.plugin._admin_unlock_l1)
        rb = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
        if locked:
            rb.setColor(QtGui.QColor(220, 0, 0))
            rb.setFillColor(QtGui.QColor(220, 0, 0, 45))
        else:
            rb.setColor(QtGui.QColor(255, 190, 0))
            rb.setFillColor(QtGui.QColor(255, 190, 0, 45))
        rb.setWidth(2)
        rb.setToGeometry(feat.geometry(), self.poly_lyr)
        rb.show()
        self._hover_rb = rb

    def canvasMoveEvent(self, event):
        if getattr(self, "_snap_mk", None) is None:
            return
        # เก็บตำแหน่งไว้ก่อน — query จริงเกิดใน _hover_tick ตามรอบ timer
        self._pending_pos = event.pos()
        if not self._hover_timer.isActive():
            self._hover_timer.start()

    def _hover_tick(self):
        pos, self._pending_pos = self._pending_pos, None
        if pos is None or getattr(self, "_snap_mk", None) is None:
            return
        map_pt = self.toMapCoordinates(pos)
        _pt, map_xy = self._nearest_marker(map_pt)
        if map_xy is not None:
            self._snap_mk.setCenter(QgsPointXY(map_xy))
            self._snap_mk.show()
            self._set_hover(None)        # อยู่บนหมุด -> ไม่ต้อง hover แปลง
        else:
            self._snap_mk.hide()
            self._set_hover(self._poly_at(map_pt))

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._cancel()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        map_pt = self.toMapCoordinates(event.pos())
        pt_xy, _map_xy = self._nearest_marker(map_pt)
        if pt_xy is not None:
            # snap ติดหมุด -> วาง node (ต้องเลือกแปลงไว้ก่อน)
            if not self.picked:
                iface.messageBar().pushMessage(
                    "Add Node", "เลือกแปลงก่อน แล้วค่อยคลิกที่หมุด", level=1, duration=5)
                return
            fids = [f for f, _ in self.picked]
            if self.plugin._addnode_execute(self.poly_lyr, fids, pt_xy):
                # อัปเดตไฮไลต์แปลงเพื่อโชว์ node ใหม่ที่เพิ่งเพิ่มเข้าไป
                for fid, rb in self.picked:
                    feat = self.poly_lyr.getFeature(fid)
                    if feat.isValid():
                        rb.setToGeometry(feat.geometry(), self.poly_lyr)
                self._canvas.refresh()
                iface.messageBar().pushInfo("Add Node", "เพิ่มหมุดสำเร็จ — สามารถคลิกเพิ่มหมุดอื่นต่อได้เลย หรือคลิกขวาเพื่อเสร็จสิ้น")
        else:
            # ไม่ติดหมุด -> เลือก/เอาแปลงออก
            feat = self._poly_at(map_pt)
            if feat is None:
                iface.messageBar().pushMessage(
                    "Add Node", "ไม่พบแปลง/หมุดตรงนี้ — คลิกในแปลง หรือเลื่อนให้ snap ติดหมุด",
                    level=1, duration=4)
                return
            self._toggle(feat)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._cancel()

    def _clear_highlights(self):
        for _fid, rb in self.picked:
            try:
                self._canvas.scene().removeItem(rb)
            except Exception:
                pass
        self.picked = []

    def _remove_snap(self):
        if getattr(self, "_snap_mk", None) is not None:
            try:
                self._canvas.scene().removeItem(self._snap_mk)
            except Exception:
                pass
            self._snap_mk = None

    def _finish(self):
        self._canvas.refresh()
        iface.actionSelect().trigger()   # -> deactivate() ล้าง highlight/snap

    def _cancel(self):
        try:
            iface.messageBar().clearWidgets()
        except Exception:
            pass
        iface.actionSelect().trigger()

    def deactivate(self):
        self._hover_timer.stop()
        self._pending_pos = None
        self._clear_highlights()
        self._set_hover(None)
        self._remove_snap()
        super().deactivate()



class SyncVertexTool(QgsMapTool):
    """เลือกและเลื่อนหมุดหลายเลเยอร์พร้อมกัน
    - คลิกเดี่ยว: คลิกหมุด -> เลือก 1 หมุด แล้ว "คลิกตำแหน่งใหม่" เพื่อย้าย (click-to-move)
    - หลายหมุด: ลากกล่องครอบหลายหมุด แล้วลากหมุดที่เลือกเพื่อย้าย (Shift+ลาก = เลือกเพิ่ม)
    - คลิกขวาเพื่อยกเลิก/เสร็จสิ้น"""

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas)
        self._canvas = canvas
        self.plugin = plugin
        self.poly_lyr = poly_lyr
        self.point_lyr = point_lyr
        self.setCursor(QtCore.Qt.CrossCursor)
        
        self.selected_vertices = [] # [{'layer': lyr, 'fid': id, 'vidx': idx, 'pt': QgsPointXY, 'marker': QgsVertexMarker}]
        self.selected_keys = set() # O(1) lookup for (layer_id, fid, vidx)
        self.picked = [] # list of (fid, rubberband)
        self.drag_start_pt = None
        self.box_band = None
        self.drag_band = None
        self.is_moving = False
        self.armed = False          # โหมดคลิกเดี่ยว: เลือกหมุดแล้วรอ "คลิกครั้งถัดไป" เพื่อย้าย
        self.move_anchor = None     # ตำแหน่งอ้างอิงที่ย้ายจาก (โหมด armed)
        self._placing = False       # press ปัจจุบันคือ "คลิกปลายทาง" (สั่งย้ายตอน release)
        self.move_guide = None      # เส้นนำตอน armed (จากจุดอ้างอิงไปเมาส์)

        self.snap_marker = QgsVertexMarker(self._canvas)
        self.snap_marker.setIconType(QgsVertexMarker.ICON_CROSS)
        self.snap_marker.setColor(QtGui.QColor(255, 0, 255))
        self.snap_marker.setPenWidth(2)
        self.snap_marker.hide()

    # ★ 28 ส.ค. 69 (audit 2.10) — รัศมี "คลิกเลือกจุดเดียว" ต้องมีเพดานเป็นเมตร
    #   เดิมเป็นพิกเซลล้วน (mapUnitsPerPixel * 5 ไม่มีเพดาน):
    #      1:500 -> 0.66 ม. (ปกติดี) · 1:1000 -> 1.3 ม. · zoom ทั้งระวาง (1 px ~ 1 ม.) -> 5 ม.
    #      = คลิกเดียวคว้ามุม+หมุดหลายแปลงมาย้ายทั้งก้อน
    #   วัดจากข้อมูลจริง 8,760 ตัวอย่าง 3 อำเภอ (ระยะถึงหมุดตัวถัดไปที่ "คนละตำแหน่ง"):
    #      เพดาน   เสี่ยงคว้าของข้างเคียง   = กี่ px ที่ 1:500
    #       0.50            2.49%                3.8
    #       0.60            3.21%                4.5   <-- เลือกตัวนี้
    #       0.66            3.89%                5.0   (เท่าของเดิมเป๊ะ)
    #       1.00            6.18%                7.6
    #      ไม่มีเพดาน       36% ที่ zoom ทั้งระวาง
    #   => 0.60 ม.: ที่ 1:500 ยังได้ 4.5 px จากเดิม 5.0 px เป้าคลิกแทบไม่ต่างจากเดิม
    #      (เกณฑ์ "คลิกหรือลาก" ของโค้ดนี้คือ 10 px ที่ click_slop ไม่ใช่ค่านี้)
    #      แต่ตัดเคส "zoom ออกแล้วคลิกเดียวคว้าทั้งก้อน" ทิ้งได้
    #   ไม่มีพื้น (floor) — ดูเหตุผลใน _click_tol · เพดานเป็นเมตร จึงต้องผ่าน
    #      _canvas_is_metres() ก่อนเสมอ
    CLICK_TOL_MAX_M = 0.60

    def _click_tol(self):
        """รัศมีค้นหารอบจุดที่คลิก (หน่วยเดียวกับแคนวาส)

        ★ 31 ส.ค. 69 — CLICK_TOL_MAX_M/MIN_M เป็น "เมตร" จึงใช้ได้เฉพาะเมื่อ
        CRS ของโปรเจกต์มีหน่วยเป็นเมตรเท่านั้น. Khlongluang_V2 ตั้ง projectCrs
        เป็น EPSG:4326 (องศา) ทั้งที่เลเยอร์เป็น EPSG:24047 -> ถ้าเอา 0.05 ไป
        เป็นพื้น จะกลายเป็น 0.05 องศา ~ 5.5 กม. คลิกทีเดียวเลือกทั้งตำบล.
        แคนวาสที่ไม่ใช่เมตร -> คืนค่าพิกเซลล้วนแบบเดิม (พฤติกรรมก่อนใส่เพดาน)
        """
        px = self._canvas.mapUnitsPerPixel() * 5
        if not _canvas_is_metres(self._canvas):
            return px
        # ★ 31 ส.ค. 69 — เอาพื้นหน่วยเมตรออก (เคยเป็น 0.05 ม.)
        #   เหตุผลเดิมคือ "กันรัศมีเล็กจนคลิกไม่โดน" ซึ่งคิดผิด: px = mupp*5 คือ 5 พิกเซล
        #   บนจอเสมออยู่แล้ว ไม่มีทางเล็กจนคลิกไม่โดน  แต่พื้นหน่วยเมตรกลับไปทำลาย
        #   วิธีทำงานจริงของพนักงาน คือ "ซูมเข้าไปเพื่อแยกหมุดที่ห่างกันไม่กี่ ซม."
        #   ที่ 1:10 เคยได้รัศมี 1.3 ซม. กลายเป็น 5 ซม. = คว้าหมุดข้างเคียงติดมาด้วย
        #   (ถอยหลังจาก 2.0.2) · เหลือเฉพาะเพดานซึ่งเป็นสิ่งที่ตั้งใจใส่จริง
        return min(px, self.CLICK_TOL_MAX_M)

    # ระยะที่ถือว่า "หมุดอยู่จุดเดียวกัน" — 1 ซม. เท่ากับ _marker_exists_here
    # และเท่ากับ bucket ที่ _select_vertices_in_rect ใช้จับคู่มุมกับหมุด
    STACK_TOL_M = 0.01

    def _stacked_marker_count(self):
        """จำนวนหมุดที่ซ้อนกันมากที่สุด **ในแปลงเดียวกัน ที่มุมเดียวกัน**

        คืน 0 ถ้าไม่ได้เลือกแปลงไว้ (พนักงานย้ายได้ตามปกติ ไม่ต้องมีกล่องมาขวาง)

        ★ ทำไมต้องแยกราย (แปลง, มุม) ไม่ใช่นับรวม
          มุมร่วมระหว่าง 4 แปลงมีหมุดของใครของมัน 4 ดวง = เรื่องปกติของงานนี้
          ถ้านับรวมทุกแปลงที่เลือก จะเด้งกล่องทุกครั้งที่คลิกมุมร่วม ทั้งที่ไม่มีอะไรซ้อน
          สิ่งที่ต้องถามคือ "แปลงใดแปลงหนึ่ง มีหมุดของตัวเองซ้อนกันที่มุมใดมุมหนึ่งไหม"
        """
        try:
            if not self.selected_vertices or not self.poly_lyr:
                return 0
            pu = self.plugin._resolve_field(self.poly_lyr, {'utm', 'utm_code', 'utm_id'})
            if not pu:
                return 0
            sel_utms = set()
            for fid in (self.poly_lyr.selectedFeatureIds() or []):
                pf = self.poly_lyr.getFeature(fid)
                if pf.isValid():
                    sel_utms.add(str(pf[pu] or "").strip().upper())
            sel_utms.discard("")
            if not sel_utms:
                return 0                      # ไม่ได้เลือกแปลง -> ไม่เด้ง

            # แคนวาสองศา: 1e-7 องศา ~ 1.1 ซม. (ไฟล์อำเภอบางไฟล์ตั้ง projectCrs 4326)
            tol = self.STACK_TOL_M if _canvas_is_metres(self._canvas) else 1e-7
            bkt = {}
            for v in self.selected_vertices:
                if v['layer'].geometryType() != 0:            # ไม่ใช่หมุด -> ข้าม
                    continue
                tu = self.plugin._resolve_field(v['layer'], {'utm', 'utm_code', 'utm_id'})
                if not tu:
                    continue
                mf = v['layer'].getFeature(v['fid'])
                if not mf.isValid():
                    continue
                u = str(mf[tu] or "").strip().upper()
                if u not in sel_utms:                          # หมุดของแปลงอื่น -> ไม่นับ
                    continue
                q = v.get('pt')
                if q is None:
                    continue
                bkt.setdefault((u, round(q.x() / tol), round(q.y() / tol)), []).append(q)

            best = 0
            for (u, cx, cy), lst in bkt.items():
                # กวาดช่องข้างเคียง 3x3 กันคู่ที่คร่อมขอบช่อง แล้ววัดระยะจริงอีกชั้น
                near = []
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        near += bkt.get((u, cx + dx, cy + dy), [])
                for pnt in lst:
                    n = sum(1 for o in near if pnt.distance(o) <= tol)
                    if n > best:
                        best = n
            return best
        except Exception:
            return 0                                           # นับไม่ได้ -> อย่าไปขวาง

    def _clear_selection(self):
        for v in self.selected_vertices:
            if v.get('marker'):
                try:
                    self._canvas.scene().removeItem(v['marker'])
                except Exception:
                    pass
        self.selected_vertices = []
        self.selected_keys.clear()
        for attr in ('box_band', 'drag_band', 'move_guide'):
            b = getattr(self, attr, None)
            if b:
                try:
                    self._canvas.scene().removeItem(b)
                except Exception:
                    pass
                setattr(self, attr, None)
        # รีเซ็ตโหมดคลิกเดี่ยว
        self.armed = False
        self.move_anchor = None
        self._placing = False

    def _remove_guide(self):
        if self.move_guide:
            try:
                self._canvas.scene().removeItem(self.move_guide)
            except Exception:
                pass
            self.move_guide = None

    def _add_marker(self, pt):
        mk = QgsVertexMarker(self._canvas)
        mk.setIconType(QgsVertexMarker.ICON_BOX)
        mk.setColor(QtGui.QColor(255, 60, 0))
        mk.setFillColor(QtGui.QColor(255, 60, 0, 80))
        mk.setPenWidth(2)
        mk.setIconSize(10)
        mk.setCenter(pt)
        mk.show()
        return mk

    def _select_vertices_in_rect(self, rect, add_mode=False):
        if not add_mode:
            self._clear_selection()

        has_blocked = False
        has_cap = False      # เลือกทะลุเพดาน 800 จุด -> ตัด (กัน QgsVertexMarker ท่วมจอ/ลากกระตุก)
        proj = QgsProject.instance()
        locked_map = None   # ตาราง UTM ล็อก L1-RTK/L1-TS — โหลดครั้งแรกที่เจอหมุด (คิวรีเดียวต่อรอบ)

        selected_poly_ids = []
        selected_poly_utms = set()
        if self.poly_lyr:
            selected_poly_ids = self.poly_lyr.selectedFeatureIds()
            if selected_poly_ids:
                poly_utm_field = self.plugin._resolve_field(self.poly_lyr, {'utm', 'utm_code', 'utm_id'})
                if poly_utm_field:
                    u_idx = self.poly_lyr.fields().indexFromName(poly_utm_field)
                    # ดึงเฉพาะฟิลด์ UTM ไม่เอา geometry (เดิมดึงทั้ง feature)
                    req_u = (QgsFeatureRequest().setFilterFids(selected_poly_ids)
                             .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([u_idx]))
                    for f_p in self.poly_lyr.getFeatures(req_u):
                        val = f_p[poly_utm_field]
                        if val is not None:
                            selected_poly_utms.add(str(val).strip())
                            
        selected_point_ids = []
        if self.point_lyr:
            selected_point_ids = self.point_lyr.selectedFeatureIds()

        # ค้นหาใน point_lyr
        if self.point_lyr:
            to_pt = QgsCoordinateTransform(proj.crs(), self.point_lyr.crs(), proj) if self.point_lyr.crs() != proj.crs() else None
            from_pt = QgsCoordinateTransform(self.point_lyr.crs(), proj.crs(), proj) if self.point_lyr.crs() != proj.crs() else None
            try:
                pt_rect = to_pt.transformBoundingBox(rect) if to_pt else rect
            except:
                pt_rect = rect
            
            req = QgsFeatureRequest().setFilterRect(pt_rect)
            point_utm_field = self.plugin._resolve_field(self.point_lyr, {'utm', 'utm_code', 'utm_id'})

            for f in self.point_lyr.getFeatures(req):
                # ถ้ามีการ select หมุดเอาไว้ ให้ดึงเฉพาะหมุดที่ select
                if selected_point_ids and f.id() not in selected_point_ids:
                    continue
                
                # ถ้าไม่ได้ select หมุด แต่มีแปลงที่ถูก select ไว้ ให้กรองหมุดด้วย UTM
                if not selected_point_ids and selected_poly_utms and point_utm_field:
                    pt_val = f[point_utm_field]
                    if pt_val is None or str(pt_val).strip() not in selected_poly_utms:
                        continue

                g = f.geometry()
                if g.intersects(pt_rect):
                    map_pt = from_pt.transform(g.asPoint()) if from_pt else g.asPoint()
                    if self.poly_lyr:
                        if locked_map is None:
                            locked_map = self.plugin._locked_utm_map(self.poly_lyr)
                        is_locked, type_str = self.plugin._is_point_feature_locked(f, locked_map)
                        if is_locked and not self.plugin._admin_unlock_l1:   # ★ admin: เลือก/ย้าย node หมุด L1 ได้
                            has_blocked = True
                            continue
                    if len(self.selected_vertices) >= 800:
                        has_cap = True
                        break
                    key = (self.point_lyr.id(), f.id(), -1)
                    if key not in self.selected_keys:
                        self.selected_keys.add(key)
                        self.selected_vertices.append({
                            'layer': self.point_lyr, 'fid': f.id(), 'vidx': -1, 'pt': map_pt,
                            'marker': self._add_marker(map_pt)
                        })
                        
        # ค้นหาใน poly_lyr (ข้ามถ้าชนเพดานแล้ว — ผลจะถูกยกเลิกทั้งหมดอยู่ดี)
        if self.poly_lyr and not has_cap:
            to_poly = QgsCoordinateTransform(proj.crs(), self.poly_lyr.crs(), proj) if self.poly_lyr.crs() != proj.crs() else None
            from_poly = QgsCoordinateTransform(self.poly_lyr.crs(), proj.crs(), proj) if self.poly_lyr.crs() != proj.crs() else None
            try:
                poly_rect = to_poly.transformBoundingBox(rect) if to_poly else rect
            except:
                poly_rect = rect
                
            req = QgsFeatureRequest().setFilterRect(poly_rect)
            selected_poly_ids = self.poly_lyr.selectedFeatureIds()
            # ★ กันฉีกกติกาเหล็ก: ถ้าผู้ใช้ select "เฉพาะหมุด" ไว้ (ไม่ได้ select แปลง)
            #   เดิมฝั่งหมุดถูกจำกัดตาม selection แต่ฝั่งมุมแปลงกวาดทุกมุมในกรอบ
            #   -> ลากแล้วมุมแปลงขยับ แต่หมุดของมัน (ที่ไม่ได้เลือก) อยู่กับที่
            #   จำกัดมุมแปลงให้เหลือเฉพาะที่ทับหมุดที่ถูกเลือก (±5 ซม. = tolerance มุมร่วมของปลั๊กอิน)
            sel_pt_idx = None
            if selected_point_ids and not selected_poly_ids:
                # grid bucket ช่อง 1 ซม. -> เช็คต่อ vertex เป็น O(1) แทนสแกนทั้ง list
                # 1 ซม. = tolerance เดียวกับ _marker_exists_here (มุมกับหมุด weld กันระดับ mm;
                # 5 ซม. กว้างจนคว้ามุมของแปลงข้างเคียงที่ไม่ใช่คู่ของหมุดมาได้)
                sel_pt_idx = {}
                for v in self.selected_vertices:
                    if v['layer'] is self.point_lyr:
                        q = v['pt']
                        sel_pt_idx.setdefault(
                            (round(q.x() / 0.01), round(q.y() / 0.01)), []).append(q)
            for f in self.poly_lyr.getFeatures(req):
                # ถ้ามีแปลงที่ถูก select อยู่ ให้ย้ายได้แค่แปลงที่ถูก select เท่านั้น
                if selected_poly_ids and f.id() not in selected_poly_ids:
                    continue
                # กันชน: ห้ามเลือก L1-RTK / L1-TS
                tp = self.plugin._poly_type_str(self.poly_lyr, f)
                if tp in ("L1-RTK", "L1-TS") and not self.plugin._admin_unlock_l1:
                    has_blocked = True
                    continue
                g = f.geometry()
                # ต้องหาทุก vertex ที่อยู่ใน poly_rect
                for vidx, vpt in enumerate(g.vertices()):
                    vpt_xy = QgsPointXY(vpt.x(), vpt.y())
                    if poly_rect.contains(vpt_xy):
                        map_pt = from_poly.transform(vpt_xy) if from_poly else vpt_xy
                        if sel_pt_idx is not None:
                            _cx = round(map_pt.x() / 0.01); _cy = round(map_pt.y() / 0.01)
                            _hit = any(abs(map_pt.x() - q.x()) <= 0.01 and
                                       abs(map_pt.y() - q.y()) <= 0.01
                                       for gx in (_cx - 1, _cx, _cx + 1)
                                       for gy in (_cy - 1, _cy, _cy + 1)
                                       for q in sel_pt_idx.get((gx, gy), ()))
                            if not _hit:
                                continue
                        if len(self.selected_vertices) >= 800:
                            has_cap = True
                            break
                        key = (self.poly_lyr.id(), f.id(), vidx)
                        if key not in self.selected_keys:
                            self.selected_keys.add(key)
                            self.selected_vertices.append({
                                'layer': self.poly_lyr, 'fid': f.id(), 'vidx': vidx, 'pt': map_pt,
                                'marker': self._add_marker(map_pt)
                            })
                if has_cap:
                    break     # เลิกไล่ feature ที่เหลือ — ผลถูกยกเลิกทั้งหมดข้างล่างอยู่แล้ว
                            
        if has_cap:
            # ★ ห้ามตัดครึ่ง ๆ กลาง ๆ: ถ้าตัดกลางคัน หมุดบางตัวถูกเลือกโดยมุมแปลงคู่ของมัน
            #   โดนตัดทิ้ง -> ลากแล้วขยับไม่ครบคู่ (ฉีกกติกาเหล็กเสียเอง) -> ยกเลิกทั้งหมด
            self._clear_selection()
            self.plugin.iface.messageBar().pushMessage(
                "Move Node", "เลือกเกิน 800 จุด — ยกเลิกการเลือกทั้งหมด (กันแปลง/หมุดขยับไม่ครบคู่) "
                             "กรุณาลากกล่องให้เล็กลง", level=2, duration=8)
            return
        if has_blocked:
            self.plugin.iface.messageBar().pushMessage(
                "MLEP Guard", "หมุดหรือแปลงอ้างอิง L1-RTK / L1-TS ถูกข้ามเพื่อป้องกันการแก้ไข!",
                level=1, duration=5
            )
        elif self.selected_vertices:
            iface.messageBar().pushInfo("Move Node", f"เลือก {len(self.selected_vertices)} หมุดแล้ว")
        else:
            iface.messageBar().pushInfo("Move Node", "ไม่พบหมุดในบริเวณที่คลิก กรุณาลองใหม่")

    def canvasPressEvent(self, e):
        if e.button() != QtCore.Qt.LeftButton:
            return

        if self.is_moving:
            return

        shift = bool(e.modifiers() & QtCore.Qt.ShiftModifier)
        match = self._canvas.snappingUtils().snapToMap(e.pos())
        self.drag_start_pt = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        # โหมด armed (คลิกเดี่ยวเลือกหมุดไว้แล้ว) + คลิกปกติ -> คลิกนี้คือ "ปลายทาง" ย้าย (สั่งตอน release)
        if self.armed and not shift:
            self._placing = True
            return
        self._placing = False

        # เช็คว่าคลิกโดนหมุดที่เลือกไว้แล้วหรือไม่ (ใช้ตัดสินว่าจะลากย้าย)
        clicked_on_selected = False
        if self.selected_vertices and match.isValid():
            # ★ 28 ส.ค. 69 — ตรงนี้ **ห้ามใส่เพดานเมตร** (เคยใส่แล้วถอนออก):
            #   ตัวนี้ตัดสินแค่ "ลากของที่เลือกไว้แล้ว" หรือ "เริ่มกล่องใหม่" — ไม่ได้เลือกของใหม่เลย
            #   ของที่จะถูกย้ายคือชุดที่ผู้ใช้ตรวจแล้วเลือกไว้เอง เพดานจึงไม่เพิ่มความปลอดภัยอะไร
            #   มีแต่ทำให้ที่ zoom กว้าง กดบนหมุดที่เห็นว่าเลือกอยู่แล้วพลาด -> เสีย selection ทิ้ง
            tol_sq = (self._canvas.mapUnitsPerPixel() * 5) ** 2
            for v in self.selected_vertices:
                if v['pt'].sqrDist(self.drag_start_pt) < tol_sq:
                    clicked_on_selected = True
                    break

        if self.selected_vertices and clicked_on_selected and not self.armed:
            # โหมดหลายหมุด: คลิกโดนหมุดที่เลือกไว้ -> ลากย้าย (กด/ไม่กด Shift ก็ได้)
            self._remove_guide()
            self.is_moving = True
            self.drag_band = QgsRubberBand(self._canvas, QgsWkbTypes.LineGeometry)
            self.drag_band.setColor(QtGui.QColor(0, 0, 255))
            self.drag_band.setWidth(2)
        else:
            # เริ่มกล่องเลือก (คลิก = จุดเดียว+arm, Shift+ลาก = ครอบหลายจุด)
            # ถ้ากำลัง armed อยู่แล้วมากดเริ่ม gesture ใหม่ (เช่น Shift+ลาก) -> ปลด armed + เส้นนำ
            if self.armed:
                self.armed = False
                self._remove_guide()
            self.is_moving = False
            self.box_band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
            self.box_band.setColor(QtGui.QColor(0, 120, 255))
            self.box_band.setFillColor(QtGui.QColor(0, 120, 255, 40))
            self.box_band.setWidth(1)

    def canvasMoveEvent(self, e):
        match = self._canvas.snappingUtils().snapToMap(e.pos())
        cur = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        if match.isValid():
            self.snap_marker.setCenter(cur)
            self.snap_marker.show()
        else:
            self.snap_marker.hide()

        # โหมด armed (คลิกเดี่ยว): ลากเส้นนำจากจุดอ้างอิงไปเมาส์ (มาร์กเกอร์อยู่กับที่ บอกว่าเลือกอะไร)
        if self.armed and self.move_anchor is not None:
            if self.move_guide is None:
                self.move_guide = QgsRubberBand(self._canvas, QgsWkbTypes.LineGeometry)
                self.move_guide.setColor(QtGui.QColor(0, 0, 255))
                self.move_guide.setWidth(2)
            self.move_guide.setToGeometry(
                QgsGeometry.fromPolylineXY([self.move_anchor, cur]), None)
            return

        if self.drag_start_pt is None:
            return

        if self.is_moving and self.drag_band:
            self.drag_band.setToGeometry(QgsGeometry.fromPolylineXY([self.drag_start_pt, cur]), None)
            # ขยับ Marker ตามเมาส์ให้เห็นภาพ
            dx = cur.x() - self.drag_start_pt.x()
            dy = cur.y() - self.drag_start_pt.y()
            for v in self.selected_vertices:
                if v['marker']:
                    v['marker'].setCenter(QgsPointXY(v['pt'].x() + dx, v['pt'].y() + dy))
        elif not self.is_moving and self.box_band:
            self.box_band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self.drag_start_pt, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_selection()
            iface.actionSelect().trigger()
            return

        if e.button() != QtCore.Qt.LeftButton:
            return

        match = self._canvas.snappingUtils().snapToMap(e.pos())
        cur = match.point() if match.isValid() else self.toMapCoordinates(e.pos())

        # ===== โหมดคลิกเดี่ยว: คลิกปลายทาง = ย้ายหมุดที่เลือกไว้ =====
        if self._placing:
            self._placing = False
            if self.armed and self.move_anchor is not None and self.selected_vertices:
                dx = cur.x() - self.move_anchor.x()
                dy = cur.y() - self.move_anchor.y()
                if abs(dx) > 1e-6 or abs(dy) > 1e-6:
                    if self.plugin._movenodes_execute(self.selected_vertices, dx, dy):
                        self._clear_selection()
                        iface.messageBar().pushInfo(
                            "Move Node", "ย้ายหมุดสำเร็จ — คลิกหมุดถัดไปเพื่อย้ายต่อ หรือคลิกขวาเพื่อเสร็จสิ้น")
                    # ถ้า execute ล้มเหลว -> คงสถานะ armed ไว้ ให้คลิกย้ายใหม่ได้
                else:
                    # คลิกที่เดิม -> ยกเลิกการเลือก
                    self._clear_selection()
            self.drag_start_pt = None
            return

        if self.drag_start_pt is None:
            return

        if self.is_moving:
            # ===== โหมด Shift: ปล่อยเมาส์หลังลากย้าย -> Execute =====
            dx = cur.x() - self.drag_start_pt.x()
            dy = cur.y() - self.drag_start_pt.y()

            if abs(dx) > 1e-6 or abs(dy) > 1e-6:
                if self.plugin._movenodes_execute(self.selected_vertices, dx, dy):
                    self._clear_selection()
                    iface.messageBar().pushInfo("Move Node", "ย้ายหมุดสำเร็จ — Shift+ลากเลือกหมุดอื่นต่อได้ หรือคลิกขวาเพื่อเสร็จสิ้น")
            else:
                # ไม่ได้ลาก แค่คลิกเฉยๆ -> ถ้าคลิกพื้นที่ว่าง ให้ล้าง selection
                if not match.isValid():
                    self._clear_selection()

            self.drag_start_pt = None
            if self.drag_band:
                try:
                    self._canvas.scene().removeItem(self.drag_band)
                except:
                    pass
                self.drag_band = None

            self.is_moving = False

        else:
            # ===== เลือกหมุด: คลิกจุดเดียว = arm คลิกย้าย / ลากกล่อง = หลายหมุด (ลากย้าย) =====
            shift = bool(e.modifiers() & QtCore.Qt.ShiftModifier)
            raw = QgsRectangle(self.drag_start_pt, cur)
            self.drag_start_pt = None
            if self.box_band:
                try:
                    self._canvas.scene().removeItem(self.box_band)
                except:
                    pass
                self.box_band = None

            # คลิกเฉยๆ (กล่องเล็กมาก) = เลือกจุดเดียว ; ลากจริง = กล่องครอบหลายจุด
            # ★ 28 ส.ค. 69 — แยกสองหน้าที่ที่เดิมใช้ตัวแปรเดียวกัน:
            #   click_slop = "มือขยับไปเท่าไหร่บนจอ" -> ตัดสินว่าคลิกหรือลาก = เรื่องของ UI
            #                ต้องเป็นพิกเซลล้วน **ห้ามใส่เพดานเมตร** ไม่งั้นที่ zoom กว้าง
            #                มือสั่น 5 px (= 5 ม.) จะถูกอ่านเป็น "ลากกล่อง" แทนที่จะเป็นคลิก
            #   tol        = "รัศมีค้นหารอบจุดที่คลิก" -> เรื่องของภูมิศาสตร์ = ต้องมีเพดานเมตร
            click_slop = self._canvas.mapUnitsPerPixel() * 5
            is_click = raw.width() < click_slop * 2 and raw.height() < click_slop * 2
            if is_click:
                # ★ 31 ส.ค. 69 (แก้รอบสอง) — เคยใส่ rect.combineExtentWith(raw) ไว้ตรงนี้
                #   ด้วยเหตุผลว่า "ของที่ลากคลุมไว้หาย" แต่คิดผิด: การขยับต่ำกว่า 10 พิกเซล
                #   คือ "มือสั่น" ไม่ใช่การลากที่ตั้งใจ (เกณฑ์เดียวกับ startDragDistance ของ Qt)
                #   การรวม raw เข้ามาทำให้เพดาน 0.60 ม. ไร้ผลทันทีที่มือขยับแม้แต่พิกเซลเดียว
                #   ที่ 1:5000 มือสั่น 9 px = คว้าไป 12 ม. ซึ่งคือสิ่งที่เพดานตั้งใจกัน
                #   -> คลิก = ใช้กรอบรอบจุดที่คลิกเท่านั้น (มีเพดาน) · ลากจริง = ใช้กล่องที่ลาก
                tol = self._click_tol()
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol,
                                    cur.x() + tol, cur.y() + tol)
            else:
                rect = raw

            # Shift = สะสมเพิ่มจากการเลือกเดิม ; ไม่กด = เลือกใหม่ (แทนที่)
            self._select_vertices_in_rect(rect, add_mode=shift)

            # ★ 3 ก.ย. 69 (v2.2.3) - เด้ง popup เลือกกรณีคลิกแล้วเจอของซ้อนทับกันหลายชิ้น
            # 🔴🔴 4 ก.ย. 69 (2.2.4 · ผู้ตรวจวัดจริง) - เงื่อนไขเดิมกว้างเกินไปมาก
            #   `len(self.selected_vertices) > 1` นับรวม "มุมแปลง" ด้วย ซึ่งคลิกเดียวได้ >=2 เสมอ
            #   (หมุด 1 + มุมแปลง 1 + จุดปิดวงอีก 1) ⇒ วัดได้ว่า **เด้งทุกคลิก** ที่มีแปลงถูกเลือก
            #   ไม่ใช่เฉพาะ "ของซ้อนทับกัน" ตามที่รายงาน 2.2.3 ตั้งใจไว้เอง
            #   และร้ายกว่านั้น: ถ้าพนักงานติ๊กมุมแปลงออกบางตัวแล้วย้าย จะได้
            #   **มุมแปลงเลื่อนโดยหมุดไม่ตาม = หมุดลอย + เกิดร่องกับแปลงข้างเคียง** (พิสูจน์แล้ว)
            #   ซึ่งขัดกับเป้าหมายสายผลิตโดยตรง และไม่มีด่านไหนขวางเลย
            # ⇒ กติกาที่เจ้าของงานเคาะ (4 ก.ย. 69):
            #     เด้งเฉพาะเมื่อ **เลือกแปลงไว้ก่อน** และจุดที่คลิกมี **หมุดของ "แปลงที่เลือก" ซ้อนกัน >= 2 ตัว**
            #     ถ้าไม่ได้เลือกแปลง -> ย้ายได้ตามปกติ ไม่มีกล่องเด้ง
            #   ★ ต้องนับ "เฉพาะหมุดที่ UTM ตรงกับแปลงที่เลือก" ไม่ใช่หมุดทุกตัวที่จุดนั้น
            #     เพราะมุมร่วมระหว่าง 4 แปลง มีหมุดของใครของมัน 4 ตัวเป็นเรื่องปกติ
            #     ถ้านับรวมจะกลับไปเด้งทุกคลิกเหมือนเดิม
            # 🔴 4 ก.ย. 69 (2.2.5) — ย้ายการนับออกไปเป็นเมธอด `_stacked_marker_count()`
            #   เหตุผล: 2.2.4 นับ "รวมทุกแปลงที่เลือก" เป็นเลขเดียว ⇒ เลือก 3 แปลงแล้วคลิก
            #   มุมร่วม ได้ 3 (แปลงละ 1 ดวง = เรื่องปกติของงานนี้) > 1 = เด้ง ทั้งที่ไม่มี
            #   แปลงไหนมีหมุดซ้อนเลย · ของใหม่ถามว่า "มีแปลงใด ที่มุมใด มีหมุดของตัวเอง >= 2"
            #   และแยกเป็นเมธอดเพื่อให้ชุดเทสเรียกได้ตรง ๆ (เดิมเทสต้องตัดสตริงจากไฟล์ = เปราะ)
            _n_marker = self._stacked_marker_count() if is_click else 0
            if is_click and self.selected_vertices and self.poly_lyr and _n_marker > 1:
                if self.poly_lyr.selectedFeatureIds() and len(self.selected_vertices) > 1:
                    candidates = []
                    for v in self.selected_vertices:
                        feat = v['layer'].getFeature(v['fid'])
                        utmf = self.plugin._resolve_field(v['layer'], {'utm', 'utm_code', 'utm_id'})
                        utm = str(feat[utmf]) if utmf and feat.isValid() else "?"
                        
                        if v['layer'].geometryType() == 0:  # PointGeometry
                            nfld = self.plugin._addnode_name_field(v['layer'])
                            name = str(feat[nfld]) if nfld and feat.isValid() and feat[nfld] else "ไม่มีชื่อ"
                            candidates.append({'id': v['fid'], 'name': name, 'utm': utm, 'layer_type': 'point', 'v': v})
                        else:
                            candidates.append({'id': v['fid'], 'name': f"มุมที่ {v['vidx']}", 'utm': utm, 'layer_type': 'poly', 'v': v})
                    
                    if len(candidates) > 1:
                        dlg = NodeSelectionDialog(candidates, self.plugin.iface.mainWindow(), multi_select=True)
                        if dlg.exec_():
                            sel = dlg.get_selected()
                            keep_v = [s['v'] for s in sel]
                            for v in list(self.selected_vertices):
                                if v not in keep_v and v.get('marker'):
                                    # ★ 2.2.4 — ต้องเช็ค marker ก่อน (แพตเทิร์นเดียวกับ _clear_selection)
                                    try:
                                        self._canvas.scene().removeItem(v['marker'])
                                    except Exception:
                                        pass
                            self.selected_vertices = keep_v
                            self.selected_keys = set((v['layer'].id(), v['fid'], v.get('vidx')) for v in keep_v)
                        else:
                            self._clear_selection()

            if (not shift) and is_click and self.selected_vertices:
                # คลิกจุดเดียว -> โหมดคลิกย้าย (armed)
                self.armed = True
                self.move_anchor = QgsPointXY(self.selected_vertices[0]['pt'])
                iface.messageBar().pushInfo(
                    "Move Node", "เลือกหมุดแล้ว — คลิกตำแหน่งใหม่เพื่อย้าย (คลิกขวา = ยกเลิก)")
            else:
                # ลากกล่อง / หลายหมุด -> ลากหมุดที่เลือกเพื่อย้าย (ไม่มีเส้นนำคลิกเดี่ยว)
                self.armed = False
                self._remove_guide()
                if self.selected_vertices:
                    iface.messageBar().pushInfo(
                        "Move Node", f"เลือก {len(self.selected_vertices)} หมุด — ลากหมุดที่เลือกเพื่อย้าย (Shift+ลาก = เลือกเพิ่ม)")

    def deactivate(self):
        self._clear_selection()
        if self.snap_marker:
            try:
                self._canvas.scene().removeItem(self.snap_marker)
            except:
                pass
        super().deactivate()


class _AdminNodeTool(AddNodeTool):
    """ฐานของเครื่องมือผู้ดูแล: ใช้ flow เดียวกับ Add Node (คลิกแปลง -> คลิก node)
    ต่างที่ (ก) ไม่บล็อกแปลง L1 (แอดมินแตะได้ทุกประเภทตามที่ตกลง)
            (ข) ตอนคลิกที่หมุด เรียก action ของตัวเองแทนการเพิ่ม node"""
    TITLE = "Admin"
    HINT  = "เลือกแปลงแล้ว • คลิกที่หมุดของแปลงนี้"
    ALLOW_LOCKED = True     # แอดมิน: เลือกได้ทุกประเภทรวม L1-RTK/L1-TS

    def _do_action(self, fid, pt_xy):
        raise NotImplementedError

    def canvasReleaseEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self._cancel()
            return
        if event.button() != QtCore.Qt.LeftButton:
            return
        map_pt = self.toMapCoordinates(event.pos())
        pt_xy, _map_xy = self._nearest_marker(map_pt)
        self._last_map_xy = _map_xy      # เครื่องมือลูกใช้วางเครื่องหมายบนหมุดที่เพิ่งคลิก
        if pt_xy is not None:
            if not self.picked:
                iface.messageBar().pushMessage(
                    self.TITLE, "เลือกแปลงก่อน แล้วค่อยคลิกที่หมุด", level=1, duration=5)
                return
            if self._do_action(self.picked[0][0], pt_xy):
                # รูปแปลงอาจเปลี่ยน (กรณีลบ node) -> อัปเดตไฮไลต์
                for fid, rb in self.picked:
                    feat = self.poly_lyr.getFeature(fid)
                    if feat.isValid():
                        rb.setToGeometry(feat.geometry(), self.poly_lyr)
                self._canvas.refresh()
        else:
            feat = self._poly_at(map_pt)
            if feat is None:
                iface.messageBar().pushMessage(
                    self.TITLE, "ไม่พบแปลง/หมุดตรงนี้ — คลิกในแปลง หรือเลื่อนให้ snap ติดหมุด",
                    level=1, duration=4)
                return
            self._toggle(feat)


class RenameNodeTool(_AdminNodeTool):
    """แอดมิน: คลิกแปลง -> คลิกหมุดของแปลงนั้น -> แก้ชื่อ (BND_NAME)"""
    TITLE = "แก้ชื่อหมุด"
    HINT  = "เลือกแปลงแล้ว • คลิกที่หมุดของแปลงนี้เพื่อแก้ชื่อ"
    DENY_MSG = "ห้ามแก้ชื่อหมุด"      # ไม่ได้ใช้ (ALLOW_LOCKED=True) แต่ตั้งไว้กันตกทอดผิด

    def _do_action(self, fid, pt_xy):
        return self.plugin._rename_node_execute(self.poly_lyr, fid, pt_xy)


class DeleteNodeTool(_AdminNodeTool):
    """แอดมิน: คลิกแปลง -> คลิก node ของแปลงนั้น -> ลบมุมแปลง + หมุดของแปลงนั้นพร้อมกัน
    (ตรงข้ามกับ Add Node — กติกาเหล็กจึงคงอยู่เอง ไม่เกิดมุมเปลือย)"""
    TITLE = "ลบ Node"
    HINT  = "เลือกแปลงแล้ว • คลิกที่ node/หมุดของแปลงนี้เพื่อลบ"
    DENY_MSG = "ห้ามลบ node"          # ไม่ได้ใช้ (ALLOW_LOCKED=True) แต่ตั้งไว้กันตกทอดผิด

    def _do_action(self, fid, pt_xy):
        return self.plugin._delete_node_execute(self.poly_lyr, fid, pt_xy)


class SwapNodeTool(_AdminNodeTool):
    """สลับ "ตำแหน่ง" ของหมุดสองตัวใน "แปลงเดียวกัน"

    ★ 31 ส.ค. 69 — พนักงานเจอเคสชื่อหมุดสลับลำดับกันบ่อย เดิมต้องพึ่งแอดมิน
      กด ✏️ แก้ชื่อหมุด ทีละตัวสองรอบ ซึ่งมีจังหวะที่ชื่อซ้ำกันชั่วคราว
    ★ สลับ geom ไม่ใช่สลับ BND_NAME — ได้ผลเหมือนกัน (ชื่อไปอยู่จุดที่ถูก) แต่
      พนักงานมี GRANT UPDATE เฉพาะ geom/SCORE ของชั้นหมุด เขียนชื่อไม่ได้
      และการย้าย geom ถูกบันทึกใน <D>_Move_Log เป็น 'moved' พร้อม geom ก่อน/หลัง
    flow: คลิกแปลง -> คลิกหมุดตัวที่ 1 -> คลิกหมุดตัวที่ 2 -> ยืนยัน -> สลับ
    การจับคู่ node-หมุด ไม่เสีย เพราะชุดตำแหน่งทั้งหมดเท่าเดิม แค่สลับกันสองจุด
    ไม่ใช่เครื่องมือแอดมิน: ยังกันแปลงอ้างอิง L1-RTK/L1-TS ไว้เหมือน Add Node
    (สืบทอด _AdminNodeTool เพราะต้องการ canvasReleaseEvent แบบ "คลิกหมุด = ลงมือ"
     แล้วปิดธง ALLOW_LOCKED กลับเป็น False)"""
    TITLE = "สลับหมุด"
    HINT  = "เลือกแปลงแล้ว • คลิกหมุดตัวที่ 1 แล้วคลิกหมุดตัวที่ 2 เพื่อสลับตำแหน่งกัน"
    ALLOW_LOCKED = False
    DENY_MSG = "ห้ามสลับหมุด"

    def __init__(self, canvas, plugin, poly_lyr, point_lyr):
        super().__init__(canvas, plugin, poly_lyr, point_lyr)
        self.first = None        # (fid ของหมุดตัวแรก, ชื่อเดิม)
        self._first_mk = None    # เครื่องหมายสี่เหลี่ยมน้ำเงินบนหมุดตัวแรก

    def mark_first(self, map_xy):
        """วางเครื่องหมายบนหมุดตัวแรก เพื่อให้เห็นว่ากำลังจะสลับกับตัวไหน"""
        self.clear_first_mark()
        try:
            mk = QgsVertexMarker(self._canvas)
            mk.setIconType(QgsVertexMarker.ICON_BOX)
            mk.setColor(QtGui.QColor(0, 90, 255))
            mk.setPenWidth(3)
            mk.setIconSize(16)
            mk.setCenter(QgsPointXY(map_xy))
            mk.show()
            self._first_mk = mk
        except Exception:
            self._first_mk = None

    def clear_first_mark(self):
        if self._first_mk is not None:
            try:
                self._canvas.scene().removeItem(self._first_mk)
            except Exception:
                pass
            self._first_mk = None

    def clear_first(self):
        """ล้างหมุดตัวแรกที่ค้างอยู่ (ทั้งข้อมูลและเครื่องหมายบนจอ)"""
        self.first = None
        self.clear_first_mark()

    def _toggle(self, feat):
        # เปลี่ยนแปลงที่เลือก = ทิ้งหมุดตัวแรกที่ค้างไว้ (ห้ามสลับข้ามแปลง)
        self.clear_first()
        super()._toggle(feat)

    def _do_action(self, fid, pt_xy):
        return self.plugin._swap_node_execute(self.poly_lyr, fid, pt_xy, self)

    def _cancel(self):
        self.clear_first()
        super()._cancel()

    def deactivate(self):
        self.clear_first()
        super().deactivate()


# ======================================================================
#  วาดเส้น / วัดระยะ  (31 ส.ค. 69)
# ======================================================================
class LineMeasureItem(QgsMapCanvasItem):
    """วาดเส้นที่ผู้ใช้ลากไว้ + ป้ายระยะรายช่วง ลงบนแคนวาสโดยตรง

    ★ ตั้งใจ **ไม่สร้างเลเยอร์ในโปรเจกต์** — เส้นเป็นของบนแคนวาสล้วน ๆ
      โปรเจกต์จึงไม่ถูกทำให้ "มีการแก้ไข" และพนักงานจะไม่โดนกล่องถามว่าจะบันทึกโปรเจกต์ไหม
      ตอนปิด QGIS (บทเรียนจากปลั๊กอินวาดเส้นตัวเดิม ที่เขียนทับค่าโปรเจกต์แล้วไม่คืน
      จนไฟล์ 5 อำเภอเพี้ยนกันคนละแบบ)
    """

    C_LINE = QtGui.QColor(21, 101, 192)     # เส้นที่วาดเสร็จแล้ว
    C_TEMP = QtGui.QColor(230, 81, 0)       # เส้นที่กำลังลาก
    C_TEXT = QtGui.QColor(20, 20, 20)
    C_HALO = QtGui.QColor(255, 255, 255, 220)

    def __init__(self, canvas):
        super().__init__(canvas)
        self._canvas = canvas
        self.lines = []          # เส้นที่จบแล้ว: [[QgsPointXY, ...], ...]
        self.temp = []           # จุดของเส้นที่กำลังวาด
        self.cursor = None       # ตำแหน่งเมาส์ขณะวาด (QgsPointXY)
        self.show_labels = True
        self.show_nodes = True
        self.layer_draws_lines = True   # เส้นที่จบแล้ว ให้ชั้นจริงเป็นคนวาด
        self.ref_line = None     # แนวอ้างอิงมุม: (จุดต้น, จุดปลาย)
        self._da = None
        self._da_key = None      # (authid ของ CRS, ทรงรี) ที่ _da ตัวปัจจุบันถูกสร้างมาเพื่อ

    # ---------- ระยะ ----------
    # ★ CRS ของงานนี้เป็น UTM (EPSG:24047) หน่วยเมตร -> ใช้ "ระยะบนกริด" ตรง ๆ
    #   จงใจไม่ใช้การวัดแบบ ellipsoid เพราะ
    #     ① งานรังวัดเทียบกับพิกัดในฐานข้อมูล ซึ่งเป็นพิกัดกริด — ระยะต้องตรงกับพิกัด
    #        ไม่ใช่ระยะบนผิวโลก (ต่างกันตามมาตราส่วนฉาย ~0.04% = 4 ซม./100 ม.)
    #     ② ถ้าพิกัดเพี้ยน (เช่นเลเยอร์ตั้ง CRS ผิด) การคำนวณแบบ ellipsoid จะให้ค่ามั่ว
    #        แบบไม่มีสัญญาณเตือน — เคยได้ 1,500 ม. จากเส้นยาว 70 ม. ตอนเทส
    #   เหลือทาง ellipsoid ไว้เฉพาะกรณี CRS โปรเจกต์ไม่ใช่เมตร (เช่นตั้งเป็น 4326)
    def _dist_area(self):
        """ตัววัดระยะ — สร้างใหม่เมื่อ CRS หรือทรงรีของโปรเจกต์เปลี่ยน

        🔴 3 ก.ย. 69 (ผู้ตรวจจับได้ · วัดซ้ำแล้ว) เดิมแคชไว้ตัวเดียวทั้งเซสชัน:
          พนักงานเห็นระยะเพี้ยน แล้วไปแก้ทรงรีที่ Project Properties ให้ถูก
          ค่าที่วัดได้ก็ยัง "เท่าเดิม" จนกว่าจะปิด-เปิด QGIS ใหม่
        🔴 และถ้าทรงรีเป็น NONE (ค่าเริ่มต้นของ QGIS) measureLine จะคืนค่าเป็น "องศา"
          บนโปรเจกต์ที่ใช้ CRS เชิงมุม ⇒ ระยะจริง ~108 ม. ถูกรายงานว่า "0.1 ซม."
          โดยไม่มีคำเตือนใด ๆ (คอมเมนต์ข้างบนระบุว่ามีไฟล์อำเภอจริงตั้ง EPSG:4326)
          ⇒ ถ้าไม่ได้ตั้งทรงรีไว้ ให้ใช้ WGS84 แทน จะได้ค่าเป็นเมตรตามที่ป้ายบอก
          (กรณีปกติของงานนี้คือ UTM หน่วยเมตร ซึ่งไม่ผ่านทางนี้อยู่แล้ว — ดู seg_len)
        """
        prj = QgsProject.instance()
        try:
            crs = self._canvas.mapSettings().destinationCrs()
            ell = prj.ellipsoid()
            key = (crs.authid(), ell)
        except Exception:
            crs, ell, key = None, None, None
        if self._da is None or getattr(self, "_da_key", None) != key:
            da = QgsDistanceArea()
            try:
                if crs is not None:
                    da.setSourceCrs(crs, prj.transformContext())
                if not ell or str(ell).strip().upper() in ("", "NONE"):
                    da.setEllipsoid("WGS84")
                else:
                    da.setEllipsoid(ell)
            except Exception:
                pass
            self._da = da
            self._da_key = key
        return self._da

    def seg_len(self, a, b):
        if _canvas_is_metres(self._canvas):
            return a.distance(b)              # ระยะบนกริด = ตรงกับพิกัดในฐานข้อมูล
        try:
            d = self._dist_area().measureLine(a, b)
            if d and d > 0:
                return d
        except Exception:
            pass
        return a.distance(b)

    def line_len(self, pts):
        return sum(self.seg_len(pts[i], pts[i + 1]) for i in range(len(pts) - 1))

    def total_len(self):
        return sum(self.line_len(p) for p in self.lines if len(p) > 1)

    @staticmethod
    def fmt(d):
        if d >= 1000:
            return "%.3f กม." % (d / 1000.0)
        if d >= 1:
            return "%.2f ม." % d
        return "%.1f ซม." % (d * 100.0)

    # ---------- QGraphicsItem ----------
    def boundingRect(self):
        """กรอบสำหรับ Qt ใช้ตัดสินว่าต้องวาดหรือไม่

        🔴 1 ก.ย. 69 — ห้ามโยน exception เด็ดขาด
          Qt เรียกเมธอดนี้ระหว่างจัดวางซีน ถ้าโยน exception ไอเทมจะ "เงียบไปทั้งตัว"
          = เส้น preview / จุดหัก / ป้ายระยะ หายพร้อมกันแบบไม่มีสัญญาณเตือน
          เกิดจริงได้: ปลั๊กอินถูก reload (self-update) แล้วไอเทมเก่ายังอยู่ในซีน
          -> self._canvas เป็นวัตถุ C++ ที่ถูกลบไปแล้ว -> RuntimeError
          (จับได้ตอนรันเทสจริง: "wrapped C/C++ object of type QgsMapCanvas has been deleted")
        """
        w = h = 4000
        try:
            vp = self._canvas.viewport()
            r = vp.rect() if vp is not None else self._canvas.rect()
            w, h = r.width(), r.height()
        except Exception:
            pass
        # เผื่อขอบกว้าง ๆ กันป้ายระยะที่ล้นออกนอกจอถูกตัดทิ้ง
        return QtCore.QRectF(-2000, -2000, w + 4000, h + 4000)

    def updatePosition(self):
        try:
            self.prepareGeometryChange()
            self.update()
        except Exception:
            pass

    def _canvas_pts(self, pts):
        out = []
        for p in pts:
            try:
                # ลบ pos() แบบเดียวกับ QgsRubberBand ของ QGIS
                # วันนี้ pos() เป็น (0,0) เสมอ (คลาสนี้ override updatePosition จึงไม่มีใครเรียก setRect)
                # จึงเป็นการลบศูนย์ — ใส่ไว้กันวันที่มีคนเผลอเรียก setRect/setPos แล้วภาพเลื่อนทั้งชุด
                out.append(self.toCanvasCoordinates(p) - self.pos())
            except Exception:
                return []
        return out

    def _text(self, painter, pos, txt):
        """ข้อความมีขอบขาว อ่านออกทั้งบนภาพดาวเทียมและพื้นขาว"""
        painter.setFont(self._font)
        painter.setPen(QtGui.QPen(self.C_HALO, 3))
        path = QtGui.QPainterPath()
        path.addText(pos, self._font, txt)
        painter.drawPath(path)
        painter.setPen(QtGui.QPen(self.C_TEXT))
        painter.fillPath(path, QtGui.QBrush(self.C_TEXT))

    def paint(self, painter, *args):
        try:
            self._paint(painter)
        except Exception:
            # 🔴 exception ใน paint ทำให้ Qt เลิกวาดไอเทมนี้ทั้งตัว
            #   ยอมให้เฟรมนั้นว่างดีกว่าไอเทมตายถาวร
            pass

    def _paint(self, painter):
        if not self.lines and not self.temp and not self.ref_line:
            return
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        self._font = QtGui.QFont()
        self._font.setPointSize(9)
        self._font.setBold(True)

        def draw(pts, colour, dashed=False, stroke=True):
            cv = self._canvas_pts(pts)
            if len(cv) < 1:
                return
            pen = QtGui.QPen(colour, 2)
            if dashed:
                pen.setStyle(QtCore.Qt.DashLine)
            painter.setPen(pen)
            if stroke:
                for i in range(len(cv) - 1):
                    painter.drawLine(cv[i], cv[i + 1])
            if self.show_nodes:
                painter.setBrush(QtGui.QBrush(colour))
                painter.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255), 1))
                for c in cv:
                    painter.drawEllipse(c, 3.5, 3.5)
            if self.show_labels:
                for i in range(len(cv) - 1):
                    mid = QtCore.QPointF((cv[i].x() + cv[i + 1].x()) / 2.0,
                                         (cv[i].y() + cv[i + 1].y()) / 2.0)
                    self._text(painter, mid + QtCore.QPointF(4, -4),
                               self.fmt(self.seg_len(pts[i], pts[i + 1])))

        for pts in self.lines:
            # เส้นที่วาดเสร็จแล้ว ให้ QGIS วาดจาก "ชั้นเส้นที่วาด (Line)" แทน
            # (ชั้นจริงทำให้ snap ติดได้ และวาดเสถียรกว่าไอเทมบนแคนวาส)
            # ตรงนี้เหลือหน้าที่แค่จุดหักกับป้ายระยะ
            draw(pts, self.C_LINE, stroke=not self.layer_draws_lines)
            if self.show_labels and len(pts) > 2:
                cv = self._canvas_pts(pts)
                if cv:
                    self._text(painter, cv[-1] + QtCore.QPointF(6, 16),
                               "รวม " + self.fmt(self.line_len(pts)))

        if self.temp:
            live = list(self.temp)
            if self.cursor is not None:
                live.append(self.cursor)
            draw(live, self.C_TEMP, dashed=True)

        # แนวอ้างอิงมุม — เส้นประบาง ๆ สีเขียว ไม่นับเป็นเส้นวัด
        if self.ref_line:
            cv = self._canvas_pts(list(self.ref_line))
            if len(cv) == 2:
                pen = QtGui.QPen(QtGui.QColor(46, 125, 50), 2, QtCore.Qt.DashDotLine)
                painter.setPen(pen)
                painter.drawLine(cv[0], cv[1])
                if self.show_labels:
                    mid = QtCore.QPointF((cv[0].x() + cv[1].x()) / 2.0,
                                         (cv[0].y() + cv[1].y()) / 2.0)
                    self._text(painter, mid + QtCore.QPointF(4, 14),
                               "แนวอ้างอิง %.2f°" % azimuth(*self.ref_line))

    # ---------- จัดการเส้น ----------
    def clear_all(self):
        self.lines = []
        self.temp = []
        self.cursor = None
        self.updatePosition()

    def undo_last(self):
        if self.temp:
            self.temp.pop()
        elif self.lines:
            self.lines.pop()
        self.updatePosition()


class DrawLineTool(QgsMapTool):
    """วาดเส้นวัดระยะบนแคนวาส

    คลิกซ้าย = ลงจุด · คลิกขวา หรือ ดับเบิลคลิก = จบเส้น
    Backspace = ถอยจุดล่าสุด · Esc = ทิ้งเส้นที่กำลังวาด
    เกาะหมุด/มุมแปลงตามค่า snapping ของโปรเจกต์
    """

    def __init__(self, canvas, item, on_change, on_ref=None):
        super().__init__(canvas)
        self._canvas = canvas
        self._item = item
        self._on_change = on_change
        self._on_ref = on_ref
        self._snap = QgsSnapIndicator(canvas)
        self.setCursor(QtCore.Qt.CrossCursor)
        # ---- ตัวล็อก (แผงเป็นคนตั้งค่า) ----
        self.lock_dist = None      # ระยะคงที่ (เมตร) หรือ None
        self.lock_angle = None     # ขั้นของมุม (องศา) หรือ None — ทำงานเมื่อกด Shift ค้าง
        self.angle_basis = 0.0     # อาซิมุทของแนวที่ใช้เป็นศูนย์องศา (0 = ทิศเหนือ)
        self._ref_pts = []         # จุดที่เก็บไว้ตอน Ctrl+คลิก เพื่อตั้งแนวอ้างอิง

    # ---------- ช่วยเหลือ ----------
    @staticmethod
    def _mods(e):
        try:
            return e.modifiers()
        except Exception:
            return QtWidgets.QApplication.keyboardModifiers()

    def _raw(self, e):
        """จุดดิบ: เกาะ snap ถ้าเกาะได้ ไม่งั้นใช้ตำแหน่งเมาส์ตรง ๆ"""
        try:
            m = self._canvas.snappingUtils().snapToMap(e.pos())
        except Exception:
            m = None
        if m is not None and m.isValid():
            self._snap.setMatch(m)
            return QgsPointXY(m.point())
        try:
            self._snap.setMatch(self._empty_match())
        except Exception:
            pass
        return self.toMapCoordinates(e.pos())

    def constrain(self, prev, raw, shift=False):
        """บังคับจุดใหม่ให้เข้าล็อกระยะ/ล็อกมุม เทียบจากจุดก่อนหน้า

        ล็อกมุม: ปัดอาซิมุทให้เป็นจำนวนเท่าของ lock_angle โดยนับจาก angle_basis
                 (ทำงานเฉพาะตอนกด Shift ค้าง เหมือนต้นฉบับ)
        ล็อกระยะ: บังคับความยาวช่วงให้เท่ากับ lock_dist เป๊ะ
        ★ ถ้าหน่วยแผนที่ไม่ใช่เมตร จะไม่บังคับระยะ เพราะตัวเลขจะคนละหน่วยกับที่พิมพ์
        """
        if prev is None:
            return raw
        az = azimuth(prev, raw)
        d = math.hypot(raw.x() - prev.x(), raw.y() - prev.y())
        if shift and self.lock_angle:
            step = float(self.lock_angle)
            if step > 0:
                rel = (az - self.angle_basis) % 360.0
                rel = round(rel / step) * step
                az = (self.angle_basis + rel) % 360.0
        if self.lock_dist and _canvas_is_metres(self._canvas):
            d = float(self.lock_dist)
        if d <= 0:
            return raw
        a = math.radians(az)
        return QgsPointXY(prev.x() + d * math.sin(a), prev.y() + d * math.cos(a))

    def _point(self, e):
        raw = self._raw(e)
        prev = self._item.temp[-1] if self._item.temp else None
        shift = bool(self._mods(e) & QtCore.Qt.ShiftModifier)
        return self.constrain(prev, raw, shift)

    # ---------- แนวอ้างอิงมุม (Ctrl + คลิกซ้าย 2 จุด) ----------
    def _ref_click(self, e):
        self._ref_pts.append(self._raw(e))
        if len(self._ref_pts) >= 2:
            a, b = self._ref_pts[-2], self._ref_pts[-1]
            self._ref_pts = []
            self._item.ref_line = (a, b)
            self.angle_basis = azimuth(a, b)
            if self._on_ref:
                try:
                    self._on_ref(self.angle_basis)
                except Exception:
                    pass
        self._changed()

    @staticmethod
    def _empty_match():
        from qgis.core import QgsPointLocator
        return QgsPointLocator.Match()

    def _changed(self):
        self._item.updatePosition()
        if self._on_change:
            try:
                self._on_change()
            except Exception:
                pass

    def _finish(self):
        if len(self._item.temp) >= 2:
            self._item.lines.append(list(self._item.temp))
        self._item.temp = []
        self._item.cursor = None
        self._changed()

    # ---------- เหตุการณ์ ----------
    def canvasMoveEvent(self, e):
        if self._item.temp:
            self._item.cursor = self._point(e)
            self._item.updatePosition()
        else:
            self._point(e)          # ให้ตัวชี้ snap ขึ้นตั้งแต่ยังไม่เริ่มลาก

    def canvasPressEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._finish()
            return
        if e.button() != QtCore.Qt.LeftButton:
            return
        if self._mods(e) & QtCore.Qt.ControlModifier:
            self._ref_click(e)          # Ctrl+คลิก 2 จุด = ตั้งแนวอ้างอิงมุม
            return
        self._item.temp.append(self._point(e))
        self._changed()

    def canvasDoubleClickEvent(self, e):
        self._finish()

    def keyPressEvent(self, e):
        k = e.key()
        if k == QtCore.Qt.Key_Escape:
            if self._item.temp:
                self._item.temp = []
                self._item.cursor = None
                self._changed()
            e.accept()
        elif k in (QtCore.Qt.Key_Backspace, QtCore.Qt.Key_Delete):
            if self._item.temp:
                self._item.temp.pop()
                self._changed()
            e.accept()
        elif k in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
            self._finish()
            e.accept()

    def deactivate(self):
        # จบเส้นที่ค้างอยู่ให้เรียบร้อย ไม่ทิ้งเส้นครึ่ง ๆ กลาง ๆ ไว้บนจอ
        try:
            self._finish()
            self._snap.setMatch(self._empty_match())
        except Exception:
            pass
        super().deactivate()
