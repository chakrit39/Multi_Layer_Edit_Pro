"""
DOL iLands API (public — ไม่ต้อง login) สำหรับ Multi-Layer Edit Pro
ค้นหา PARCEL_SEQ จาก "เลขระวาง" (attribute) ผ่าน 2 ขั้น:
  ① ArcGIS : attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ
  ② UDM    : GetMapInformation(centroid) -> strRegParcelSeq (=PARCEL_SEQ) + ข้อมูลแปลง
ใช้ attribute (ไม่พึ่งตำแหน่ง polygon ใน QGIS) -> กันแปลงที่ถูกขยับ/แก้ไข
"""

import re
import json
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://ilands.dol.go.th"
ARCGIS_PARCEL_LAYER = {
    47: f"{BASE}/arcgis/rest/services/MapDOL_47/MapServer/6",
    48: f"{BASE}/arcgis/rest/services/MapDOL_48/MapServer/6",
}
UDM_MAPINFO_URL = f"{BASE}/UDM_MAP/frmMain.aspx/GetMapInformation"
LOGIN_URL = f"{BASE}/dolauth/login"
EVD_CADASTRAL_URL = f"{BASE}/evd/servlet/EvdPcadastral001Servlet"

# จังหวัด/มาตราส่วน -> รหัสที่ servlet รังวัดใช้
PROVINCE_CODE = {"ชลบุรี": "11", "นครนายก": "17", "ปทุมธานี": "4"}
SCALE_CODE = {"500": "1", "1000": "2", "2000": "3", "4000": "5"}

# session ใช้ร่วม (keep-alive) -> ArcGIS + UDM host เดียวกัน, call ที่ 2 ไม่ต้อง TLS handshake ใหม่
_PUBLIC_SESSION = requests.Session()
_PUBLIC_SESSION.headers.update({"User-Agent": "QGIS-MultiLayerEditPro"})

# session ที่ login แล้ว (เก็บใน memory เท่านั้น — ปิด QGIS แล้วหาย ไม่บันทึกลงดิสก์)
_AUTH = {"session": None, "credentials": None}


class DOLError(Exception):
    pass


class DOLAuthError(Exception):
    """login ล้มเหลว / token หมดอายุ"""
    pass


def doc_url(seq, plate_type="1"):
    """URL หน้าดูภาพลักษณ์ (evdsimgs001) จาก PARCEL_SEQ"""
    if not seq:
        return ""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=1&readOnly=2&dataId={seq}&plateType={plate_type}&page=1")


def _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                        zone=47, near_xy=None, timeout=20):
    """ArcGIS: attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ (None ถ้าไม่พบ)

    near_xy=(x,y) ใน datum 24047: ใช้ตัดสินเมื่อ "ระวางคร่อมหลายสาขา" ทำให้ LAND_NO
    ซ้ำข้ามสาขา (query ได้หลาย feature) -> เลือกแปลงที่ centroid ใกล้จุดที่คลิกที่สุด
    (กันเปิดภาพลักษณ์ผิดสาขา)
    """
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        raise DOLError(f"ไม่รองรับ zone {zone}")
    where = (f"UTMMAP1='{utmmap1}' AND UTMMAP2={int(utmmap2)} AND UTMMAP3='{utmmap3}' "
             f"AND UTMMAP4='{utmmap4}' AND UTMSCALE={int(scale)} AND LAND_NO='{landno}'")
    params = {
        "where": where,
        "outFields": "MAP_PARCEL_SEQ,ORIGIN_X,ORIGIN_Y,LANDOFFICE_SEQ,LAND_NO",
        "returnGeometry": "false", "f": "json",
    }
    r = _PUBLIC_SESSION.get(f"{layer}/query", params=params, verify=False, timeout=timeout)
    r.raise_for_status()
    feats = r.json().get("features", [])
    if not feats:
        return None
    # ระวางคร่อมสาขา -> มีได้หลายแปลง LAND_NO เดียวกัน: เลือกตัวที่ centroid ใกล้จุดคลิกสุด
    if near_xy and len(feats) > 1:
        nx, ny = near_xy
        feats.sort(key=lambda f: (f["attributes"].get("ORIGIN_X", 0) - nx) ** 2
                                 + (f["attributes"].get("ORIGIN_Y", 0) - ny) ** 2)
    att = dict(feats[0]["attributes"])
    att["_match_count"] = len(feats)   # >1 = ระวางกำกวม (เลือกตัวใกล้สุดแล้ว)
    return att


def get_map_information(x, y, zone=47, parcel_type=1, timeout=20):
    """UDM GetMapInformation: พิกัด (X,Y datum 24047) -> ข้อมูลแปลง (dict)"""
    payload = {"Zone": str(zone), "X": str(x), "Y": str(y),
               "PARCEL_TYPE": str(parcel_type), "pid": "", "pr_Sys": "udm"}
    headers = {"Content-Type": "application/json; charset=utf-8",
               "X-Requested-With": "XMLHttpRequest"}
    r = _PUBLIC_SESSION.post(UDM_MAPINFO_URL, data=json.dumps(payload), headers=headers,
                             verify=False, timeout=timeout)
    r.raise_for_status()
    return json.loads(r.json()["d"])  # {"d":"<json string>"} -> dict


def lookup_parcel_by_rawang(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                            zone=47, parcel_type=1, near_xy=None):
    """
    ระวาง(attribute) -> PARCEL_SEQ + ข้อมูลแปลง  (public, ~90ms)
    near_xy=(x,y) 24047: จุด centroid ของแปลงที่คลิก ใช้แก้ปัญหาระวางคร่อมสาขา
    คืน dict (มี key 'verified' กันแปลงผิด, 'match_count' บอกความกำกวม) หรือ None ถ้าไม่พบ
    """
    arc = _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                              zone, near_xy=near_xy)
    if not arc:
        return None
    d = get_map_information(arc["ORIGIN_X"], arc["ORIGIN_Y"], zone, parcel_type)
    map_seq = str(arc.get("MAP_PARCEL_SEQ"))
    
    idx = -1
    if "strMapParcelSeqs" in d and d["strMapParcelSeqs"]:
        try:
            idx = d["strMapParcelSeqs"].index(map_seq)
        except ValueError:
            pass

    def get_v(singular, plural):
        if idx >= 0 and plural in d and d[plural] and idx < len(d[plural]):
            return d[plural][idx]
        return d.get(singular)

    parcel_seq = get_v("strRegParcelSeq", "strRegParcelSeqs")
    return {
        "match_count": arc.get("_match_count", 1),    # >1 = ระวางคร่อมสาขา (เลือกใกล้สุดแล้ว)
        "parcel_seq": parcel_seq,                     # PARCEL_SEQ ฝั่งโฉนด (ที่ต้องการ)
        "map_parcel_seq": get_v("strMapParcelSeq", "strMapParcelSeqs"),
        "parcel_no": get_v("strParcelNo", "strParcelNos"),
        "land_no": get_v("strLandNo", "strLandNos"),
        "survey_no": get_v("strSurveyNo", "strSurveyNos"),
        "rawang": get_v("strRawang", "strRawangs"),
        "area": get_v("strArea", "strAreas"),
        "owner": get_v("strOwner", "strOwners"),
        "city": get_v("strCity", "strCitys"),
        "office": get_v("strOfficeSname", "strOfficeSnames"),
        "office_seq": get_v("strOfficeSeq", "strOfficeSeqs"),
        "parcel_type": get_v("strParcel_Type", "strParcel_Types"),
        "verified": str(get_v("strMapParcelSeq", "strMapParcelSeqs")) == map_seq,
        "doc_url": doc_url(parcel_seq, "1"),
    }


# ====================================================================
#  หลักฐานการรังวัด (ต้อง login — EvdPcadastral001Servlet)
# ====================================================================
def login(username, password, timeout=20):
    """login CAS -> เก็บ session (มี DOL-TOKEN) ใน memory. raise DOLAuthError ถ้าไม่สำเร็จ"""
    s = requests.Session()
    s.headers.update({"User-Agent": "Mozilla/5.0 QGIS-MultiLayerEditPro"})
    try:
        r = s.get(LOGIN_URL, verify=False, timeout=timeout)
        r.raise_for_status()
        m = re.search(r'name="lt"\s+value="([^"]*)"', r.text)
        lt = m.group(1) if m else ""
        r = s.post(LOGIN_URL, data={"username": username, "password": password,
                                    "lt": lt, "_eventId": "submit", "warn": "true"},
                   verify=False, timeout=timeout, allow_redirects=True)
        r.raise_for_status()
        
    except requests.RequestException as e:
        raise DOLAuthError(f"เชื่อมต่อระบบ login ไม่ได้: {e}")
    if not s.cookies.get("DOL-TOKEN", ""):
        raise DOLAuthError("login ล้มเหลว — ตรวจสอบ username/password หรือมีการ login ซ้อนอยู่")
    _AUTH["session"] = s
    _AUTH["credentials"] = (username, password)
    return s


def is_logged_in():
    s = _AUTH["session"]
    return bool(s and s.cookies.get("DOL-TOKEN", ""))


def logout():
    _AUTH["session"] = None
    _AUTH["credentials"] = None


def province_code_from_city(city):
    """แยกรหัสจังหวัดจากข้อความ strCity เช่น 'จ.นครนายก อ.องครักษ์ ...' -> '17'"""
    for name, code in PROVINCE_CODE.items():
        if name in (city or ""):
            return code
    return None


def survey_doc_url(cadastral_seq, plate_type="1"):
    """URL หน้าหลักฐานการรังวัด (evdsimgs001 id=2) จาก CADASTRAL_SEQ"""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=2&readOnly=2&dataId={cadastral_seq}&plateType={plate_type}&page=1")


def _collect_cadastral(obj, out):
    """ไล่หา record ที่มี CADASTRAL_SEQ ใน response (dict/list ซ้อนกัน)"""
    if isinstance(obj, dict):
        if obj.get("CADASTRAL_SEQ"):
            out.append(obj)
        for v in obj.values():
            _collect_cadastral(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _collect_cadastral(v, out)


def search_cadastral(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                     province_code, office_seq, zone=47, timeout=30):
    """ค้นหลักฐานรังวัด -> list ของ record (มี CADASTRAL_SEQ); ต้อง login ก่อน
    คืน list (อาจมีหลายรายการต่อแปลง -> ให้ผู้เรียกทำ popup เลือก)"""
    s = _AUTH["session"]
    if not s:
        raise DOLAuthError("ยังไม่ได้ login")
    sc = SCALE_CODE.get(str(scale).strip(), str(scale))
    ln = int(landno) if str(landno).strip().lstrip("-").isdigit() else landno
    crit = {
        "boxnoValue": "", "sheetcodeValue": "", "cadastralnoValue": "",
        "numofsurveyqtyValue": "", "provinceValue": int(province_code),
        "landofficeValue": str(office_seq), "amphurValue": "", "tambolValue": "",
        "surveynoValue": "", "sheettypeValue": 1, "zonelandValue": str(zone),
        "scaleValue": int(sc), "utmmap1Value": str(utmmap1), "utmmap2Value": str(utmmap2),
        "utmmap3Value": str(utmmap3), "utmmap4Value": str(utmmap4),
        "origionmap1Value": None, "origionmap2Value": None, "origionmap3Value": None,
        "airphotomapnameValue": "", "airphotomap1Value": None,
        "airphotomap2Value": None, "airphotomap3Value": None, "landnoValue": ln,
        "typeofsurveyValue": "", "titleValue": "", "surveyorfnameValue": "",
        "surveyorlnameValue": "", "surveyfdateValue": None, "surveyedateValue": None,
    }
    
    def _do_search(session):
        return session.post(EVD_CADASTRAL_URL,
                   data={"action": "load", "func": "search", "data": json.dumps([crit])},
                   headers={"X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
                   verify=False, timeout=timeout, allow_redirects=False)

    def _parse_json(text):
        try:
            return json.loads(text)
        except ValueError:
            # ระบบของ DOL ตอบกลับเป็น ExtJS format (ไม่มีเครื่องหมายคำพูดครอบ key)
            # เช่น {success:true,results:1,data:[...]} เราต้องแก้ให้เป็น JSON ที่ถูกต้องก่อน
            fixed = re.sub(r'(^\{|,)(success|results|data|errors):', r'\1"\2":', text)
            return json.loads(fixed)

    def _is_expired(resp):
        if resp.status_code in (301, 302) or "/dolauth/login" in resp.headers.get("Location", ""):
            return True
        try:
            _parse_json(resp.text)
            return False
        except ValueError:
            return True

    try:
        r = _do_search(s)
    except requests.RequestException as e:
        raise DOLError(f"ค้นหารังวัดไม่สำเร็จ: {e}")

    if _is_expired(r):
        # พยายาม auto-relogin ถ้ามี credentials เก็บไว้
        creds = _AUTH.get("credentials")
        if creds:
            try:
                s = login(creds[0], creds[1], timeout=timeout)
                r = _do_search(s)
            except Exception:
                pass
                
        if _is_expired(r):
            _AUTH["session"] = None
            raise DOLAuthError(f"token หมดอายุ (หรือเซิร์ฟเวอร์ตอบกลับผิดปกติ)\nDebug: {r.text[:200]}")
            
    r.raise_for_status()
    try:
        j = _parse_json(r.text)
    except ValueError:
        _AUTH["session"] = None
        raise DOLAuthError(f"ผลลัพธ์ไม่ใช่ JSON (อาจ token หมดอายุ)\nDebug: {r.text[:200]}")
        
    recs = []
    _collect_cadastral(j, recs)
    # ตัดซ้ำตาม CADASTRAL_SEQ
    seen, uniq = set(), []
    for rec in recs:
        cs = str(rec.get("CADASTRAL_SEQ"))
        if cs not in seen:
            seen.add(cs)
            uniq.append(rec)
    return uniq
