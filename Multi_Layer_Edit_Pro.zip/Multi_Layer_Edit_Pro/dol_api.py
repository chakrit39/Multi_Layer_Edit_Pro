"""
DOL iLands API (public — ไม่ต้อง login) สำหรับ Multi-Layer Edit Pro
ค้นหา PARCEL_SEQ จาก "เลขระวาง" (attribute) ผ่าน 2 ขั้น:
  ① ArcGIS : attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ
  ② UDM    : GetMapInformation(centroid) -> strRegParcelSeq (=PARCEL_SEQ) + ข้อมูลแปลง
ใช้ attribute (ไม่พึ่งตำแหน่ง polygon ใน QGIS) -> กันแปลงที่ถูกขยับ/แก้ไข
"""

import re
import html
import json
import requests

import ssl
from requests.adapters import HTTPAdapter

# ★ 2.3.7 (review SE-01 · P0) — ตรวจใบรับรอง TLS ทุกคำขอ
#   เดิม verify=False ทั้ง 6 จุด รวม POST รหัสผ่าน CAS + ปิดคำเตือน InsecureRequestWarning ทั้ง process
#   ⇒ ใครดักเครือข่ายได้ก็ปลอมเป็นระบบกรมแล้วเก็บรหัสผ่าน/คุกกี้ DOL-TOKEN ได้ · ใบรับรองไม่ผ่าน = แจ้งชัด ห้ามถอยไป verify=False
#   เชื่อใบรับรองชุดเดียวกับเบราว์เซอร์: ที่เก็บใบรับรองของ Windows (รวมใบของโปรแกรมป้องกันไวรัสที่ตรวจ HTTPS
#   ซึ่งติดตั้งไว้ในเครื่อง) + ชุดของ certifi — ถ้าใช้ certifi อย่างเดียว เครื่องที่มีโปรแกรมแบบนั้นจะใช้ปุ่ม DOL ไม่ได้เลย
SSL_MSG = ("ตรวจใบรับรองความปลอดภัยของระบบกรมไม่ผ่าน — เครือข่ายหรือโปรแกรมป้องกันไวรัสอาจดักการเชื่อมต่อ "
           "(ยังไม่ได้ส่งข้อมูลใด ๆ) · แจ้งผู้ดูแล")


class _TrustAdapter(HTTPAdapter):
    """ส่ง SSLContext ที่โหลดใบรับรองของระบบ + certifi ให้ urllib3 (ทั้งต่อตรงและผ่าน proxy)"""

    def __init__(self, ctx, **kw):
        self._ctx = ctx
        super().__init__(**kw)

    def init_poolmanager(self, *a, **kw):
        kw["ssl_context"] = self._ctx
        return super().init_poolmanager(*a, **kw)

    def proxy_manager_for(self, proxy, **kw):
        kw["ssl_context"] = self._ctx
        return super().proxy_manager_for(proxy, **kw)


def _trust_context():
    ctx = ssl.create_default_context()          # ตรวจชื่อโฮสต์ + CERT_REQUIRED · Windows = โหลดที่เก็บ ROOT/CA ของระบบ
    try:
        import certifi
        ctx.load_verify_locations(certifi.where())
    except Exception:
        pass
    return ctx


def _new_session(user_agent):
    s = requests.Session()
    s.headers.update({"User-Agent": user_agent})
    try:
        s.mount("https://", _TrustAdapter(_trust_context()))
    except Exception:
        pass        # สร้าง context ไม่ได้ ⇒ ใช้ค่าตั้งต้นของ requests (certifi) — ยังตรวจใบรับรองอยู่ ไม่ถอยไป verify=False
    return s

BASE = "https://ilands.dol.go.th"
ARCGIS_PARCEL_LAYER = {
    47: f"{BASE}/arcgis/rest/services/MapDOL_47/MapServer/6",
    48: f"{BASE}/arcgis/rest/services/MapDOL_48/MapServer/6",
}
# ★ 2.3.9 rc5 (เจ้าของงานสั่ง 11 ต.ค. ค่ำ) — ชั้นอื่นของ ArcGIS สาธารณะ ช่องคีย์ชุดเดียวกับชั้น 6 (วัดจากระบบจริง 11 ต.ค.)
#   แปลงรอจด/ชั่วคราว = แปลงใหม่ที่ยังไม่ขึ้นชั้น 6 · ประวัติ = เลขที่ถูกยกเลิกแล้ว (รวม/แบ่ง/เปลี่ยนเลข) · โซน 47/48 ใช้เลขชั้นเดียวกัน
ARCGIS_TEMP_LAYERS = {z: (f"{BASE}/arcgis/rest/services/MapSVA_{z}/MapServer/5",     # MAP_LAND_TEMP
                          f"{BASE}/arcgis/rest/services/MapTEMP_{z}/MapServer/0",    # MAP_LAND_RTK_TEMP
                          f"{BASE}/arcgis/rest/services/MapTEMP_{z}/MapServer/1",    # MAP_LAND_L1_TEMP
                          f"{BASE}/arcgis/rest/services/MapTEMP_{z}/MapServer/3")    # MAP_LAND_TEMP
                      for z in (47, 48)}
ARCGIS_HISTORY_LAYER = {z: f"{BASE}/arcgis/rest/services/MapSVA_{z}/MapServer/11" for z in (47, 48)}   # MAP_LAND_GIS_HISTORY
UDM_MAPINFO_URL = f"{BASE}/UDM_MAP/frmMain.aspx/GetMapInformation"
LOGIN_URL = f"{BASE}/dolauth/login"
EVD_CADASTRAL_URL = f"{BASE}/evd/servlet/EvdPcadastral001Servlet"
# ★ 2.3.9 rc5 — หน้า "สอบถามข้อมูลแปลง" ของ iLands (ต้อง login) ค้นทะเบียนด้วยระวาง+มาตราส่วน+แผ่น+เลขที่ดิน
#   = ทางเดียวที่เจอแปลงที่มีทะเบียนแต่ไม่มีรูปบนแผนที่กรม · ช้า (ส่งฟอร์ม 5 รอบ) ⇒ ใช้เป็นทางสุดท้าย (เจ้าของงานสั่ง)
LIS_QDOCPARCEL_URL = f"{BASE}/LIS/Application/QDocParcel.aspx"

# จังหวัด/มาตราส่วน -> รหัสที่ servlet รังวัดใช้
PROVINCE_CODE = {"ชลบุรี": "11", "นครนายก": "17", "ปทุมธานี": "4"}
SCALE_CODE = {"500": "1", "1000": "2", "2000": "3", "4000": "5"}

# ★ 2.3.7 (review UX-22) — timeout แบบ (ต่อ, อ่าน) · เดิมตัวเลขเดียว 20-30 วิ ใช้ทั้งตอนต่อและตอนอ่าน
#   ⇒ ต่อระบบกรมไม่ได้ = รอ ~20 วิ ต่อคำขอ (สะสมได้หลายช่วง) · ค่าต่อ 6.05 = เลยพหุคูณ 3 วิของการลองต่อ TCP ซ้ำไปเล็กน้อย
#   ⇒ ต่อไม่ได้รู้ใน ~6 วิ · ค่าอ่านคงเดิม (คำค้นที่ช้ายังมีเวลาเท่าเดิม)
#   ผู้เรียกส่ง timeout=None = ใช้ค่าข้างล่าง ณ ตอนเรียก (ไม่ผูกเป็น default argument — แก้ค่าคงที่ทีหลังแล้วมีผลจริง)
T_PUBLIC = (6.05, 20)
T_SHEET = (6.05, 25)
T_LOGIN = (6.05, 20)
T_SURVEY = (6.05, 30)
T_LIS = (6.05, 30)          # ★ 2.3.9 rc5 — ต่อหนึ่งคำขอของหน้า LIS (หน้าใหญ่ ~600 KB)

# session ใช้ร่วม (keep-alive) -> ArcGIS + UDM host เดียวกัน, call ที่ 2 ไม่ต้อง TLS handshake ใหม่
_PUBLIC_SESSION = _new_session("QGIS-MultiLayerEditPro")

# session ที่ login แล้ว (เก็บใน memory เท่านั้น — ปิด QGIS แล้วหาย ไม่บันทึกลงดิสก์)
_AUTH = {"session": None, "credentials": None}


class DOLError(Exception):
    """ข้อผิดพลาดของระบบกรม/ข้อมูล — ข้อความ (str) แสดงให้พนักงานได้
    ★ 2.3.7 (review ER-04) — detail = เนื้อคำตอบดิบจากระบบกรม ไว้เขียนลง Log ของ MLEP ให้ผู้ดูแล (ไม่ใส่ในกล่องข้อความ)"""

    def __init__(self, msg="", detail=""):
        super().__init__(msg)
        self.detail = detail


class DOLServiceError(DOLError):
    """★ 2.3.7 (review DI-18) — บริการค้นหลักฐานรังวัดตอบ success:false = ทำรายการไม่สำเร็จ (≠ "ไม่พบข้อมูล")"""


class DOLAuthError(Exception):
    """login ล้มเหลว / token หมดอายุ
    ★ 2.3.7 (review UX-31 / ER-04) — ask_again=True = ถามชื่อผู้ใช้/รหัสผ่านใหม่แล้วอาจผ่าน
      (ระบบตอบว่าเข้าสู่ระบบไม่ผ่าน · ยังไม่ได้เข้าสู่ระบบ) · False = ถามใหม่ไม่ช่วย
      (ต่อระบบไม่ได้ · ใบรับรองไม่ผ่าน · เข้าสู่ระบบใหม่แล้วยังถูกปฏิเสธ)"""

    def __init__(self, msg="", ask_again=False):
        super().__init__(msg)
        self.ask_again = ask_again


def net_reason(e):
    """★ 2.3.7 (review ER-06) — exception ของ requests ⇒ เหตุภาษาไทยสั้น ๆ · ไม่ใช่ของ requests ⇒ None
    (ข้อความดิบเช่น HTTPSConnectionPool(...): Max retries exceeded ... ไปอยู่ใน detail/Log ไม่ใช่กล่องของพนักงาน)
    🔑 ลำดับสำคัญ: SSLError และ ConnectTimeout เป็นลูกของ ConnectionError ⇒ ตรวจก่อน"""
    try:
        if isinstance(e, requests.exceptions.SSLError):
            return SSL_MSG
        if isinstance(e, requests.exceptions.Timeout):
            return "ระบบปลายทางตอบช้าเกินเวลา (หมดเวลารอ) — ลองใหม่ภายหลัง"
        if isinstance(e, requests.exceptions.ConnectionError):
            return "เชื่อมต่อเครือข่ายไม่ได้ — ตรวจอินเทอร์เน็ต/เครือข่ายของสำนักงาน"
        if isinstance(e, requests.exceptions.HTTPError):
            code = getattr(getattr(e, "response", None), "status_code", None)
            return f"ระบบปลายทางตอบผิดปกติ (HTTP {code})" if code else "ระบบปลายทางตอบผิดปกติ"
        if isinstance(e, requests.exceptions.RequestException):
            return "การเชื่อมต่อผิดพลาด"
    except Exception:
        pass
    return None


def _as_int(v, what):
    """ค่าตัวเลขจาก attribute/QSettings -> int · รับ '2.0' / 4000.0 (ทศนิยมที่เป็นจำนวนเต็ม)
    ★ 2.3.7 (review ER-07) — เดิม int() ตรง ๆ โยน ValueError เปล่า ⇒ กล่อง 'ค้นหาไม่สำเร็จ: invalid literal for int()…'
      ไม่ใช่ตัวเลข ⇒ DOLError ภาษาไทยที่บอกว่าช่องไหน"""
    s = "" if v is None else str(v).strip()
    try:
        return int(s)
    except ValueError:
        pass
    try:
        f = float(s)
    except ValueError:
        f = None
    if f is not None and f.is_integer():
        return int(f)
    raise DOLError(f"{what} ไม่ใช่ตัวเลข: {v!r}")


def scale_code(scale):
    """มาตราส่วนของระวาง -> รหัสที่ servlet ค้นหลักฐานรังวัดใช้
    ★ 2.3.7 (review ER-07) — เดิมมาตราส่วนที่ไม่รู้จักถูกส่งค่าดิบ ⇒ ได้ผลว่าง ⇒ พนักงานเห็น "ไม่พบหลักฐานการรังวัด"
      ทั้งที่จริงคือยังไม่รองรับมาตราส่วนนั้น ⇒ แจ้งตรง ๆ ก่อนยิงเน็ต"""
    code = SCALE_CODE.get(str(scale).strip())
    if code is None:
        try:
            code = SCALE_CODE.get(str(_as_int(scale, "มาตราส่วน")))
        except DOLError:
            code = None
    if code is None:
        raise DOLError(f"ยังไม่รองรับมาตราส่วน 1:{str(scale).strip()} สำหรับค้นหลักฐานการรังวัด")
    return code


def doc_url(seq, plate_type="1"):
    """URL หน้าดูภาพลักษณ์ (evdsimgs001) จาก PARCEL_SEQ"""
    if not seq:
        return ""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=1&readOnly=2&dataId={seq}&plateType={plate_type}&page=1")


def _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                        zone=47, near_xy=None, timeout=None, layer=None):
    """ArcGIS: attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ (None ถ้าไม่พบ)

    near_xy=(x,y) ใน datum 24047: ใช้ตัดสินเมื่อ "ระวางคร่อมหลายสาขา" ทำให้ LAND_NO
    ซ้ำข้ามสาขา (query ได้หลาย feature) -> เลือกแปลงที่ centroid ใกล้จุดที่คลิกที่สุด
    (กันเปิดภาพลักษณ์ผิดสาขา)
    layer: ★ 2.3.9 rc5 — URL ชั้นอื่นที่มีช่องคีย์ชุดเดียวกัน (ชั้นรอจด/ประวัติ) · ไม่ส่ง = ชั้น 6 แปลงปัจจุบัน
    """
    layer = layer or ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        raise DOLError(f"ไม่รองรับ zone {zone}")
    def _q(v):
        # escape ' กัน where-clause พัง/ถูกฉีดเงื่อนไข เมื่อค่า attribute มี quote ปน (SQL-92)
        return str(v).replace("'", "''")
    # ★ 2.3.7 (review ER-07) — _as_int: รับ '2.0' · ไม่ใช่ตัวเลข = DOLError ภาษาไทย (เดิม ValueError เปล่า)
    where = (f"UTMMAP1='{_q(utmmap1)}' AND UTMMAP2={_as_int(utmmap2, 'UTMMAP2')} AND UTMMAP3='{_q(utmmap3)}' "
             f"AND UTMMAP4='{_q(utmmap4)}' AND UTMSCALE={_as_int(scale, 'มาตราส่วน')} AND LAND_NO='{_q(landno)}'")
    params = {
        "where": where,
        "outFields": "MAP_PARCEL_SEQ,ORIGIN_X,ORIGIN_Y,LANDOFFICE_SEQ,LAND_NO",
        "returnGeometry": "false", "f": "json",
    }
    try:
        r = _PUBLIC_SESSION.get(f"{layer}/query", params=params, timeout=timeout or T_PUBLIC)
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)
    r.raise_for_status()
    j = r.json()
    # ArcGIS ตอบ error เป็น HTTP 200 + {"error": {...}} — เดิมถูกอ่านเป็น "ไม่พบแปลง" เงียบ ๆ
    if isinstance(j, dict) and "error" in j:
        err = j["error"]
        # error อาจเป็น dict (มาตรฐาน ArcGIS), string หรือ list (proxy/WAF) — และ message อาจว่างโดยมี details แทน
        if isinstance(err, dict):
            det = err.get("details")
            if isinstance(det, (list, tuple)):
                det = "; ".join(str(d) for d in det)   # details เป็น string/int ก็ได้ — ห้าม join ตรง ๆ
            msg = err.get("message") or (str(det) if det else "") or str(err)
        else:
            msg = str(err)
        # ★ 2.3.7 b19 (doc-verify E8) — เดิม "ArcGIS ขัดข้อง: <ข้อความดิบ>" (อังกฤษ/รหัส เช่น 'Unable to complete operation.')
        #   ถึงกล่องของพนักงาน และไม่ลง Log ⇒ ข้อความไทยของเรา · ตัวจริงทั้งก้อนไป detail ⇒ ParcelLookupWorker เขียนลง Log ของ MLEP
        raise DOLError("ระบบแผนที่ของกรมตอบข้อผิดพลาด — ค้นแปลงด้วยระวางนี้ไม่ได้ตอนนี้ ลองใหม่ภายหลัง "
                       "(รายละเอียดอยู่ในแผง Log Messages แท็บ MLEP)",
                       detail=f"ArcGIS error: {msg} · {err}"[:2000])
    feats = j.get("features", [])
    if not feats:
        return None
    # ระวางคร่อมสาขา -> มีได้หลายแปลง LAND_NO เดียวกัน: เลือกตัวที่ centroid ใกล้จุดคลิกสุด
    if near_xy and len(feats) > 1:
        nx, ny = near_xy
        # ★ ArcGIS คืน attribute ที่ว่างเป็น JSON null -> .get(...,0) ได้ None (คีย์มีอยู่ ค่าเป็น null)
        #   เดิม None - nx = TypeError ทำให้การค้นหาล้มทั้งครั้ง · ตอนนี้ดันตัวที่พิกัดว่างไปท้ายแถว
        def _dist2(f):
            a = f.get("attributes") or {}
            x, y = a.get("ORIGIN_X"), a.get("ORIGIN_Y")
            if x is None or y is None:
                return float("inf")
            try:
                return (float(x) - nx) ** 2 + (float(y) - ny) ** 2
            except (TypeError, ValueError):
                return float("inf")
        feats.sort(key=_dist2)
    att = dict(feats[0]["attributes"])
    att["_match_count"] = len(feats)   # >1 = ระวางกำกวม (เลือกตัวใกล้สุดแล้ว)
    return att


def get_map_information(x, y, zone=47, parcel_type=1, timeout=None):
    try:
        return _get_map_information(x, y, zone, parcel_type, timeout or T_PUBLIC)
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)


def _get_map_information(x, y, zone=47, parcel_type=1, timeout=20):
    """UDM GetMapInformation: พิกัด (X,Y datum 24047) -> ข้อมูลแปลง (dict)"""
    payload = {"Zone": str(zone), "X": str(x), "Y": str(y),
               "PARCEL_TYPE": str(parcel_type), "pid": "", "pr_Sys": "udm"}
    headers = {"Content-Type": "application/json; charset=utf-8",
               "X-Requested-With": "XMLHttpRequest"}
    r = _PUBLIC_SESSION.post(UDM_MAPINFO_URL, data=json.dumps(payload), headers=headers,
                             timeout=timeout)
    r.raise_for_status()
    return json.loads(r.json()["d"])  # {"d":"<json string>"} -> dict


def sheet_land_numbers(utmmap1, utmmap2, utmmap3, utmmap4, scale, zone=47, timeout=None):
    """คืนชุดเลขที่ดินที่ **ระบบ DOL มีอยู่จริง** ในระวางนั้น (set ของสตริง)

    ★ 2.3.1 (21 ก.ย. 69) — ใช้ตอบให้ตรงว่า "หาไม่เจอเพราะอะไร"
      เดิมพอ ArcGIS ไม่คืนอะไร ปลั๊กอินขึ้นว่า "ตรวจเลขระวาง / zone UTM"
      ซึ่ง **ชี้ผิดทาง** เมื่อระวางถูกต้องอยู่แล้ว แต่ DOL ไม่มีเลขที่ดินนั้น
      (เคสจริง: องครักษ์ gid 20265 ระวาง 5137 2 1058-07 ที่ดิน 89 —
       ระวางนี้ DOL มี 98 เลข แต่ไม่มี 88/89/105)
    คืน None ถ้าถามไม่ได้ (เน็ตล่ม/บริการตอบ error) — ผู้เรียกต้องแยกจาก set ว่าง
    """
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        return None

    def _q(v):
        return str(v).replace("'", "''")
    where = (f"UTMMAP1='{_q(utmmap1)}' AND UTMMAP2={_as_int(utmmap2, 'UTMMAP2')} AND UTMMAP3='{_q(utmmap3)}' "
             f"AND UTMMAP4='{_q(utmmap4)}' AND UTMSCALE={_as_int(scale, 'มาตราส่วน')}")      # ★ 2.3.7 ER-07
    try:
        r = _PUBLIC_SESSION.get(f"{layer}/query", timeout=timeout or T_SHEET, params={
            "where": where, "outFields": "LAND_NO", "returnGeometry": "false",
            "f": "json", "resultRecordCount": 3000})
        r.raise_for_status()
        j = r.json()
        if not isinstance(j, dict) or "error" in j:
            return None
        return {str((f.get("attributes") or {}).get("LAND_NO")).strip()
                for f in (j.get("features") or [])}
    except Exception:
        return None


def lookup_parcel_by_rawang(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                            zone=47, parcel_type=1, near_xy=None, timeout=None, probe_xy=None):
    """
    ระวาง(attribute) -> PARCEL_SEQ + ข้อมูลแปลง  (public · 2-3 คำขอ ต่อคำขอ ≤ ~6 วิถ้าต่อไม่ได้ · timeout=None = T_PUBLIC/T_SHEET)
    near_xy=(x,y) 24047: จุด centroid ของแปลงที่คลิก ใช้แก้ปัญหาระวางคร่อมสาขา
    probe_xy=(x,y) 24047: ★ 2.3.9 จุดที่อยู่ "ใน" แปลงที่คลิก (pointOnSurface) — ใช้ถาม iLands เมื่อ ArcGIS ไม่มีคีย์นี้
                          (ไม่ส่ง = ใช้ near_xy)
    คืน dict (มี key 'verified' กันแปลงผิด, 'match_count' บอกความกำกวม) หรือ None ถ้าไม่พบ
    """
    arc = _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                              zone, near_xy=near_xy, timeout=timeout)
    if not arc:
        # ★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค.: "ถ้าหาจาก arcgis ไม่เจอ ให้ไปหาใน ilands ต่อ")
        #   ⇒ ถาม UDM ของ iLands ที่จุดในแปลงของเรา · รับเฉพาะแปลงที่ "คีย์ตรงทุกท่อน" (ระวาง 4 ท่อน + มาตราส่วน + เลขที่ดิน)
        #   (สูตรเดียวกับเครื่องมือฝั่งฐาน ทะเบียนปัจจุบัน_L1.py ที่วัดแล้ว 23 ก.ย. — ค้นด้วยระวางไม่เจอ แต่เจอด้วยพิกัด 488 ใบ)
        #   คีย์ไม่ตรง = ไม่รับ แต่ส่งแปลงของกรมที่จุดนั้นกลับไปบอกพนักงาน (มักแปลว่าคีย์ของแปลงเราผิด)
        key = (utmmap1, utmmap2, utmmap3, utmmap4, scale, landno)
        # ★ rc5 ② ชั้นแปลงรอจด/ชั่วคราว (คีย์) → จุดกลางของกรม → UDM ยืนยันคีย์ตรงทุกท่อน
        temp = None
        for L in ARCGIS_TEMP_LAYERS.get(int(zone), ()):
            t = _arcgis_try(*key, zone, near_xy, timeout, L)
            if not t or t.get("ORIGIN_X") is None or t.get("ORIGIN_Y") is None:
                continue
            hit, _h = _udm_point_lookup((t["ORIGIN_X"], t["ORIGIN_Y"]), *key, zone, parcel_type, timeout)
            if hit is not None:
                hit["via"] = "arcgis_temp"
                _remember_office(hit.get("office_seq"))
                return hit
            temp = temp or {"layer": L.split("/services/")[-1]}   # มีในชั้นรอจด แต่ทะเบียน (UDM) ยังไม่มี
        # ③ ตำแหน่งแปลงของเรา (ทางสำรอง 2.3.9)
        here = None
        xy = probe_xy or near_xy
        if xy:
            hit, here = _udm_point_lookup(xy, *key, zone, parcel_type, timeout)
            if hit is not None:
                _remember_office(hit.get("office_seq"))
                return hit
        # ★ rc5 ④ ชั้นประวัติ (คีย์) — เลขนี้ถูกยกเลิกแล้ว · ตอนนี้ที่จุดเดิมเป็นแปลงอะไร (ใช้แก้คีย์ในฐาน)
        history = None
        h = _arcgis_try(*key, zone, near_xy, timeout, ARCGIS_HISTORY_LAYER.get(int(zone)))
        if h:
            now = None
            if h.get("ORIGIN_X") is not None and h.get("ORIGIN_Y") is not None:
                hit, now = _udm_point_lookup((h["ORIGIN_X"], h["ORIGIN_Y"]), *key, zone, parcel_type, timeout)
                if hit is not None:               # จุดเดิมยังเป็นเลขนี้ (ชั้นปัจจุบันยังไม่อัปเดต) ⇒ ใช้ได้
                    hit["via"] = "arcgis_history"
                    _remember_office(hit.get("office_seq"))
                    return hit
            history = {"now": now}
        # ★ 2.3.1 — หาไม่เจอ: ถามต่อว่า "ระวางมี แต่ไม่มีเลขนี้" หรือ "ไม่มีระวางนี้เลย"
        #   ทำในเธรดเบื้องหลังตัวเดียวกัน (ไม่หน่วง UI) · ล้มเหลวก็คืนรูปเดิมได้
        เลข = sheet_land_numbers(utmmap1, utmmap2, utmmap3, utmmap4, scale, zone, timeout=timeout)
        out = {"not_found": True,
               "sheet_exists": (None if เลข is None else bool(เลข)),
               "sheet_land_count": (None if เลข is None else len(เลข)),
               "asked_land_no": str(landno).strip()}
        if here:
            out["udm_here"] = here
        if temp:
            out["temp"] = temp
        if history:
            out["history"] = history
        # ★ rc5 ⑤ ทางสุดท้าย: ทะเบียน iLands (หน้า LIS · ต้อง login · ช้า) — แปลงที่มีทะเบียนแต่ไม่มีรูปบนแผนที่กรม
        #   ไม่ถามเมื่อรู้แล้วว่าเลขถูกยกเลิก (ประวัติ) หรือยังรอจด (ชั้นชั่วคราว) — ทะเบียนไม่มีแน่ ไม่เสียเวลา
        if not history and not temp:
            if is_logged_in():
                try:
                    lis = lookup_parcel_lis(*key, zone=zone, near_xy=near_xy, here=here, timeout=timeout)
                except DOLAuthError:
                    out["lis"] = "login"
                except DOLError as e:
                    out["lis"], out["lis_error"] = "error", str(e)
                except Exception as e:            # ทางสุดท้ายล้มแบบไม่คาดคิด ⇒ ห้ามทำผล "ไม่พบ" ของขั้นก่อนหน้าหาย
                    out["lis"], out["lis_error"] = "error", f"หน้าทะเบียน iLands ตอบผิดรูปแบบ ({type(e).__name__})"
                else:
                    if not lis.get("not_found"):
                        return lis
                    out["lis"] = "none"
            else:
                out["lis"] = "login"              # ผู้เรียก (UI) ถามว่าจะเข้าสู่ระบบแล้วค้นในทะเบียนต่อไหม
        return out
    # ★ กันส่ง None ต่อไปให้ UDM (จะกลายเป็นสตริง 'None' แล้วได้ผลลัพธ์มั่ว) — แจ้งสาเหตุตรง ๆ แทน
    if arc.get("ORIGIN_X") is None or arc.get("ORIGIN_Y") is None:
        raise DOLError("ระบบ DOL ไม่มีพิกัดศูนย์กลาง (ORIGIN_X/Y) ของแปลงนี้ — ค้นด้วยระวางนี้ไม่ได้")
    d = get_map_information(arc["ORIGIN_X"], arc["ORIGIN_Y"], zone, parcel_type, timeout=timeout)
    # ★ 2.3.3 (23 ก.ย. 69) — UDM ไม่มีข้อมูลที่พิกัดนั้น ⇒ คืน None
    #   เดิมบรรทัดถัดไปเอา `in` ไปใช้กับ None ทันที ได้
    #   TypeError: argument of type 'NoneType' is not iterable ซึ่งชี้ผิดทางสิ้นเชิง
    #   กันที่นี่ที่เดียวไม่พอ — `get_v()` ข้างล่างก็ใช้ `in d` / `d.get()` ต่อ
    #   เจอจริง: ระวาง 5137 3 7054-00 1:4000 เลขที่ดิน 514
    if not d:
        raise DOLError("ระบบ DOL ไม่มีข้อมูลแปลงที่พิกัดของระวางนี้ — ค้นด้วยระวางนี้ไม่ได้")
    map_seq = str(arc.get("MAP_PARCEL_SEQ")).strip()

    idx = -1
    if "strMapParcelSeqs" in d and d["strMapParcelSeqs"]:
        _seqs = d["strMapParcelSeqs"]
        try:
            # ★ 2.3.7 (review DI-16) — รายการ: เทียบแบบ str+strip ทั้งสองฝั่ง (UDM ส่งเป็นตัวเลข/มีช่องว่าง
            #   ⇒ เดิมหาไม่เจอ ⇒ ได้ค่าเดี่ยวของแปลงอื่น + verified=False) · ไม่ใช่รายการ = แบบเดิม
            if isinstance(_seqs, (list, tuple)):
                idx = [str(_x).strip() for _x in _seqs].index(map_seq)
            else:
                idx = _seqs.index(map_seq)
        except ValueError:
            pass

    res = _udm_result(d, idx, arc.get("_match_count", 1))     # >1 = ระวางคร่อมสาขา (เลือกใกล้สุดแล้ว)
    res["verified"] = str(res.get("map_parcel_seq")).strip() == map_seq
    if res["verified"]:
        _remember_office(res.get("office_seq"))   # ★ rc5 — สำนักงานสำรองของทางสุดท้าย (LIS)
    return res


def _udm_result(d, idx, match_count=1):
    """คำตอบ UDM GetMapInformation -> dict ผลค้นแปลง (ค่าของรายการที่ idx · idx<0 = ค่าเดี่ยว)
    ★ 2.3.9 — แยกออกมาจาก lookup_parcel_by_rawang ให้ทางสำรอง iLands (_udm_point_lookup) ใช้สูตรเดียวกัน"""
    def get_v(singular, plural):
        if idx >= 0 and plural in d and d[plural] and idx < len(d[plural]):
            return d[plural][idx]
        return d.get(singular)

    parcel_seq = get_v("strRegParcelSeq", "strRegParcelSeqs")
    # 🔧 2.2.10 (17 ก.ย. 69) — แปลงที่ "ไม่มีทะเบียน" ในระบบ DOL: UDM ตอบ strDisplayNotRegData='1'
    #   และไม่ส่ง PARCEL_SEQ / ชื่อจังหวัด-ตำบลมา (แต่ยังส่งชื่อสำนักงานมา)
    #   เจอจริง: gid 211734 ปทุม L1-RTK 179 ⇒ ปุ่มหลักฐานรังวัดขึ้น "ยังไม่รองรับจังหวัด ()" ชี้ผิดทาง
    not_reg = (str(get_v("strDisplayNotRegData", "strDisplayNotRegDatas")) == "1") or not parcel_seq
    return {
        "not_registered": not_reg,
        "match_count": match_count,
        "parcel_seq": parcel_seq,                     # PARCEL_SEQ ฝั่งโฉนด (ที่ต้องการ)
        "map_parcel_seq": get_v("strMapParcelSeq", "strMapParcelSeqs"),
        "parcel_no": get_v("strParcelNo", "strParcelNos"),
        "land_no": get_v("strLandNo", "strLandNos"),
        "survey_no": get_v("strSurveyNo", "strSurveyNos"),
        "rawang": get_v("strRawang", "strRawangs"),
        "area": get_v("strArea", "strAreas"),
        "owner": get_v("strOwner", "strOwners"),
        "city": get_v("strCity", "strCitys"),
        "office": get_v("strOfficeSname", "strOfficeSnames"),
        "office_seq": get_v("strOfficeSeq", "strOfficeSeqs"),
        "parcel_type": get_v("strParcel_Type", "strParcel_Types"),
        "verified": False,
        "doc_url": doc_url(parcel_seq, "1"),
    }


# ★ 2.3.9 — ระวางในคำตอบ UDM เช่น "5137 III 7456 - 08(1:1000)" (วัดจากระบบจริง 11 ต.ค. 69)
# ★ rc4 — ระวาง 1:4000 UDM ส่งแค่ "5136 I 0844" (ไม่มี "- 00(1:4000)" ต่อท้าย · วัดจากระบบจริง 11 ต.ค. 69 เย็น)
#   rc1–rc3 บังคับต้องมีท่อนท้าย ⇒ แปลง 1:4000 ทุกใบได้คีย์ว่าง ⇒ ทางสำรอง iLands ไม่เคยจับคู่ได้ (บอกว่าตำแหน่งนี้เป็นแปลงเลขเดียวกันเสียเอง)
#   ⇒ ท่อนท้ายไม่มี = แผ่น 00 มาตราส่วน 1:4000 (กติกาเดียวกับทะเบียน: MAP4 '00' คู่กับ 1:4000 เสมอ)
_UDM_RAWANG_RE = re.compile(r"(\d{4})\s+([IVX]+|\d)\s+(\d{4})(?:\s*-\s*(\d+)\s*\(\s*1\s*:\s*(\d+)\s*\))?")
_ROMAN_NUM = {"I": 1, "II": 2, "III": 3, "IV": 4}


def _key6(m1, m2, m3, m4, scale, landno):
    """คีย์ 6 ท่อนแบบเทียบได้ (ตัดศูนย์นำหน้า · โรมัน → เลข) · อ่านไม่ได้ = None"""
    try:
        s2 = str(m2).strip().upper()
        n2 = _ROMAN_NUM[s2] if s2 in _ROMAN_NUM else int(float(s2))
        return (str(m1).strip(), n2, str(m3).strip(), int(float(str(m4).strip())),
                int(float(str(scale).strip())), int(float(str(landno).strip())))
    except (KeyError, TypeError, ValueError):
        return None


def _udm_entries(d):
    """[(idx, key6, rawang, land_no, parcel_type)] ของทุกแปลงในคำตอบ UDM (idx<0 = คำตอบแบบค่าเดี่ยว)"""
    out = []
    seqs = d.get("strMapParcelSeqs")
    n = len(seqs) if isinstance(seqs, (list, tuple)) else 0
    rng = range(n) if n else [-1]
    for i in rng:
        def _v(s, pl):
            v = d.get(pl)
            if i >= 0 and isinstance(v, (list, tuple)) and i < len(v):
                return v[i]
            return d.get(s)
        rw, ln = _v("strRawang", "strRawangs"), _v("strLandNo", "strLandNos")
        m = _UDM_RAWANG_RE.search(str(rw or ""))
        k = (_key6(m.group(1), m.group(2), m.group(3), m.group(4) if m.group(4) is not None else "00",
                   m.group(5) if m.group(5) is not None else "4000", ln) if m else None)
        out.append((i, k, str(rw or "").strip(), str(ln or "").strip(), str(_v("strParcel_Type", "strParcel_Types") or "").strip()))
    return out


def _udm_point_lookup(xy, utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, zone=47, parcel_type=1, timeout=None):
    """★ 2.3.9 — ทางสำรองเมื่อ ArcGIS ไม่มีคีย์นี้: ถาม UDM (iLands) ที่จุด xy ในแปลงของเรา
    คืน (ผล, None) ถ้ามีแปลงของกรมที่จุดนั้น **คีย์ตรงทุกท่อน** เพียงแปลงเดียว
       (None, ที่นี่) ถ้ามีแปลงแต่คีย์ไม่ตรง — ที่นี่ = {rawang, land_no, parcel_type} ของแปลงแรก (ไม่มีชื่อเจ้าของ)
       (None, None) ถ้าถามไม่ได้ / จุดนั้นไม่มีข้อมูล (ไม่โยนข้อผิดพลาด — ผู้เรียกตอบ "ไม่พบ" แบบเดิมต่อ)"""
    want = _key6(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno)
    try:
        d = get_map_information(xy[0], xy[1], zone, parcel_type, timeout=timeout)
    except Exception:
        return None, None
    if not d or not isinstance(d, dict):
        return None, None
    ent = _udm_entries(d)
    hits = [e for e in ent if want is not None and e[1] == want]
    if len(hits) == 1:
        res = _udm_result(d, hits[0][0], 1)
        res["verified"] = True                     # คีย์ตรงทุกท่อน + อยู่ในแปลงที่คลิก
        res["via"] = "udm_point"                   # ArcGIS ไม่มีคีย์นี้ — พบจาก iLands ที่ตำแหน่งแปลง
        return res, None
    first = next((e for e in ent if e[2] or e[3]), None)
    if first is None:
        return None, None
    # ★ rc5 — สำนักงาน/จังหวัดของจุดนั้นด้วย (ทางสุดท้าย LIS ต้องรู้ว่าแปลงอยู่สำนักงานไหน) · ไม่มีชื่อเจ้าของ
    _r = _udm_result(d, first[0], 1)
    return None, {"rawang": first[2], "land_no": first[3], "parcel_type": first[4],
                  "office_seq": str(_r.get("office_seq") or "").strip(), "city": str(_r.get("city") or "").strip()}


# ====================================================================
#  ★ 2.3.9 rc5 — ค้นด้วยคีย์ให้ครบก่อนใช้ตำแหน่ง (เจ้าของงานสั่ง 11 ต.ค. ค่ำ)
#    ชั้นรอจด/ชั่วคราว + ชั้นประวัติของ ArcGIS (สาธารณะ) · หน้า LIS ของ iLands = ทางสุดท้าย (ต้อง login · ช้า)
#    "มีบางแปลงที่ไม่มีรูปแปลงแต่มีทะเบียน จึงหาใน arcgis ไม่ได้" — "ให้เป็นทางสุดท้ายนะ เพราะใช้เวลานาน"
# ====================================================================
def _arcgis_try(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, zone, near_xy, timeout, layer):
    """_arcgis_find_parcel ของชั้นเสริม — ชั้นเสริมล่ม/ตอบผิดรูป ไม่ทำให้ทั้งการค้นล้ม (คืน None = ไม่พบในชั้นนั้น)"""
    if not layer:
        return None
    try:
        return _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                                   zone, near_xy=near_xy, timeout=timeout, layer=layer)
    except Exception:
        return None


def _sheet_offices(utmmap1, utmmap2, utmmap3, utmmap4, scale, near_xy=None, zone=47, timeout=None):
    """รหัสสำนักงาน (LANDOFFICE_SEQ) ของแปลงในระวางนี้บน ArcGIS ชั้น 6 — เรียงจากใกล้ near_xy ก่อน (ระวางคร่อมสาขา)
    ถามไม่ได้ = [] (ผู้เรียกลองทางอื่นต่อ)"""
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        return []

    def _q(v):
        return str(v).replace("'", "''")
    try:
        where = (f"UTMMAP1='{_q(utmmap1)}' AND UTMMAP2={_as_int(utmmap2, 'UTMMAP2')} AND UTMMAP3='{_q(utmmap3)}' "
                 f"AND UTMMAP4='{_q(utmmap4)}' AND UTMSCALE={_as_int(scale, 'มาตราส่วน')}")
        r = _PUBLIC_SESSION.get(f"{layer}/query", timeout=timeout or T_SHEET, params={
            "where": where, "outFields": "LANDOFFICE_SEQ,ORIGIN_X,ORIGIN_Y", "returnGeometry": "false",
            "f": "json", "resultRecordCount": 2000})
        r.raise_for_status()
        feats = (r.json() or {}).get("features") or []
    except Exception:
        return []
    best = {}
    for f in feats:
        a = f.get("attributes") or {}
        o = str(a.get("LANDOFFICE_SEQ") or "").strip()
        if not o:
            continue
        d = 0.0
        if near_xy:
            try:
                d = (float(a.get("ORIGIN_X")) - near_xy[0]) ** 2 + (float(a.get("ORIGIN_Y")) - near_xy[1]) ** 2
            except (TypeError, ValueError):
                d = float("inf")
        best[o] = min(best.get(o, float("inf")), d)
    return sorted(best, key=lambda o: best[o])


def _last_office():
    """รหัสสำนักงานที่ค้นสำเร็จครั้งล่าสุด (QSettings MultiLayerEditPro/DOL/LastOfficeSeq) · ไม่มี = ''"""
    try:
        from qgis.PyQt import QtCore
        return str(QtCore.QSettings().value("MultiLayerEditPro/DOL/LastOfficeSeq", "", str) or "").strip()
    except Exception:
        return ""


def _remember_office(seq):
    seq = str(seq or "").strip()
    if not seq.isdigit():
        return
    try:
        from qgis.PyQt import QtCore
        QtCore.QSettings().setValue("MultiLayerEditPro/DOL/LastOfficeSeq", seq)
    except Exception:
        pass


_LIS_ROMAN = {1: "I", 2: "II", 3: "III", 4: "IV"}
_LIS_RAWANG_RE = re.compile(r"(\d{4})\s+([IVX]+|\d)\s+(\d{4})\s*-\s*(\d+)")
# 🔐 หน้า LIS มีคอลัมน์ผู้ถือกรรมสิทธิ์ — ไม่อ่านคอลัมน์ที่หัวเข้ารูปแบบนี้เลย (ไม่เก็บ ไม่ส่งต่อ ไม่ลง Log)
_LIS_SKIP = re.compile("ชื่อ|ผู้ถือ|เจ้าของ|ผู้รับ|ผู้ขอ")
_LIS_COLS = {"ลำดับที่เอกสารสิทธิ": "parcel_seq", "PIN Code": "pin", "เลขโฉนดที่ดิน": "parcel_no",
             "เลขหน้าสำรวจ": "survey_no", "ระวาง ยู ที เอ็ม": "rawang", "มาตรา ส่วน": "scale",
             "เลขที่ดิน ยู ที เอ็ม": "land_no", "ตำบล": "tambol", "อำเภอ": "amphur", "จังหวัด": "province",
             "สำนักงานที่ดินที่ที่ดินตั้งอยู่": "office", "LANDOFFICE_SEQ": "office_seq"}


def _lis_form(t):
    """ค่าทุกช่องในฟอร์ม ASP.NET (hidden + select ที่เลือกอยู่) เหมือนเบราว์เซอร์ส่ง"""
    d = {}
    for m in re.finditer(r"<input\b([^>]*)>", t, re.I):
        a = m.group(1)
        n = re.search(r'name="([^"]*)"', a)
        if not n:
            continue
        ty = (re.search(r'type="([^"]*)"', a, re.I) or [None, "text"])[1].lower()
        if ty in ("submit", "button", "image", "checkbox", "radio"):
            continue
        v = re.search(r'value="([^"]*)"', a)
        d[n.group(1)] = html.unescape(v.group(1)) if v else ""
    for m in re.finditer(r'<select\b[^>]*name="([^"]*)"[^>]*>(.*?)</select>', t, re.I | re.S):
        sel = (re.search(r'<option[^>]*selected="selected"[^>]*value="([^"]*)"', m.group(2))
               or re.search(r'<option[^>]*value="([^"]*)"', m.group(2)))
        d[m.group(1)] = html.unescape(sel.group(1)) if sel else ""
    return d


def _lis_options(t, name):
    m = re.search(r'<select\b[^>]*name="%s"[^>]*>(.*?)</select>' % re.escape(name), t, re.I | re.S)
    if not m:
        return []
    return [(html.unescape(v), html.unescape(re.sub(r"<[^>]+>", "", x)).strip())
            for v, x in re.findall(r'<option[^>]*value="([^"]*)"[^>]*>(.*?)</option>', m.group(1), re.I | re.S)]


def _lis_check(r):
    """หน้าที่ได้ต้องเป็นหน้า QDocParcel (ไม่ใช่หน้า login) — เซสชันหมด = DOLAuthError ให้ถามรหัสใหม่"""
    if "dolauth/login" in str(getattr(r, "url", "")) or "ddlLandOffice" not in (r.text or ""):
        raise DOLAuthError("เซสชันของระบบกรมหมดอายุหรือบัญชีนี้ใช้หน้าทะเบียนไม่ได้ — เข้าสู่ระบบใหม่", ask_again=True)


def _lis_post(s, t, target, timeout, **vals):
    d = _lis_form(t)
    d.update(vals)
    d["__EVENTTARGET"], d["__EVENTARGUMENT"] = target, ""
    r = s.post(LIS_QDOCPARCEL_URL, data=d, timeout=timeout)
    r.raise_for_status()
    _lis_check(r)
    return r.text


def _lis_province_of_office(t, office_seq):
    """ค่าตัวเลือกจังหวัดของสำนักงานนี้ — ชื่อสำนักงานมีชื่อจังหวัดอยู่ ("สำนักงานที่ดินจังหวัดปทุมธานี  สาขาคลองหลวง")"""
    name = dict(_lis_options(t, "ddlLandOffice")).get(str(office_seq), "")
    best = None
    for v, x in _lis_options(t, "ddlProvince"):
        if v and x and "เลือก" not in x and x in name and (best is None or len(x) > len(best[1])):
            best = (v, x)
    return best[0] if best else None


def _lis_rows(t):
    """ตารางผลของหน้า LIS -> [dict] เฉพาะคอลัมน์ที่ใช้ · 🔐 คอลัมน์ชื่อบุคคลไม่ถูกอ่านเลย · "ไม่พบข้อมูล" = []"""
    m = re.search(r'<table[^>]*id="gvwSearchResultList"[^>]*>(.*?)</table>', t, re.S | re.I)
    if not m:
        return []
    rows = re.findall(r"<tr[^>]*>(.*?)</tr>", m.group(1), re.S | re.I)
    if len(rows) < 2:
        return []

    def _cell(c):
        return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", c))).strip()
    head = [_cell(c) for c in re.findall(r"<t[hd][^>]*>(.*?)</t[hd]>", rows[0], re.S | re.I)]
    idx = {}
    for i, h in enumerate(head):
        if _LIS_SKIP.search(h):
            continue
        k = _LIS_COLS.get(h)
        if k:
            idx[k] = i
    out = []
    for r in rows[1:]:
        cs = re.findall(r"<td[^>]*>(.*?)</td>", r, re.S | re.I)
        if len(cs) < len(head) or "parcel_seq" not in idx:
            continue                                  # แถว "ไม่พบข้อมูล" (ช่องเดียว) / แถบแบ่งหน้า
        d = {k: _cell(cs[i]) for k, i in idx.items()}
        mm = _LIS_RAWANG_RE.search(d.get("rawang", ""))
        d["_key"] = (_key6(mm.group(1), mm.group(2), mm.group(3), mm.group(4), d.get("scale"), d.get("land_no"))
                     if mm else None)
        out.append(d)
    return out


def lis_search_by_key(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, office_seq, timeout=None):
    """ค้นทะเบียนด้วยคีย์ในหน้า iLands LIS QDocParcel ของสำนักงาน office_seq (ต้อง login)
    ทำแบบคนกด: จังหวัด → สำนักงาน → โหมด "ระวาง ยู ที เอ็ม" → มาตราส่วน → แผ่น + เลขที่ดิน → ค้นหา (5 รอบ · ช้า)
    🔑 ช่องระวางของหน้านี้รับโรมันติดกันไม่เว้นวรรค ("5136I0844") — วัดจากระบบจริง 11 ต.ค. 69
    คืน [dict] เฉพาะแถวที่คีย์ตรงทุกท่อน (ไม่มีชื่อบุคคล)"""
    s = _AUTH["session"]
    if not s:
        raise DOLAuthError("ยังไม่ได้เข้าสู่ระบบ DOL", ask_again=True)
    want = _key6(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno)
    if want is None or want[1] not in _LIS_ROMAN:
        raise DOLError("คีย์ของแปลงไม่ครบ/ไม่ถูกรูปแบบ — ค้นในทะเบียน iLands ไม่ได้")
    timeout = timeout or T_LIS
    crit = {"SelectCriteria": "radParcelLandUTMMap"}
    rw = "%s%s%s" % (want[0], _LIS_ROMAN[want[1]], want[2])
    try:
        r = s.get(LIS_QDOCPARCEL_URL, timeout=timeout)
        r.raise_for_status()
        _lis_check(r)
        t = r.text
        prov = _lis_province_of_office(t, office_seq)
        if not prov:
            raise DOLError(f"หน้าทะเบียน iLands ไม่มีสำนักงานรหัส {office_seq}")
        t = _lis_post(s, t, "ddlProvince", timeout, ddlProvince=prov)
        t = _lis_post(s, t, "ddlLandOffice", timeout, ddlLandOffice=str(office_seq))
        t = _lis_post(s, t, "radParcelLandUTMMap", timeout, **crit)
        sc = next((v for v, x in _lis_options(t, "ddlUTMScale") if x == str(want[4])), None)
        if not sc:
            raise DOLError(f"หน้าทะเบียน iLands ไม่มีมาตราส่วน 1:{want[4]}")
        t = _lis_post(s, t, "ddlUTMScale", timeout, txtUTMMap=rw, ddlUTMScale=sc, **crit)
        pg = next((v for v, x in _lis_options(t, "ddlUTMPage") if x == "%02d" % want[3]), None)
        if pg is None:
            raise DOLError(f"หน้าทะเบียน iLands ไม่มีแผ่นที่ {want[3]:02d} ของมาตราส่วน 1:{want[4]}")
        t = _lis_post(s, t, "btnSearch", timeout, txtUTMMap=rw, ddlUTMScale=sc, ddlUTMPage=pg,
                      txtUTMLandNo=str(want[5]), txtUTMLandNoTo="", **crit)
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)
    except requests.RequestException as e:
        raise DOLError(f"ต่อหน้าทะเบียน iLands ไม่ได้: {net_reason(e)}")
    return [x for x in _lis_rows(t) if x.get("_key") == want]


def lookup_parcel_lis(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, zone=47, near_xy=None, here=None,
                      timeout=None):
    """ทางสุดท้ายของการค้นแปลง: ทะเบียน iLands ด้วยคีย์ (ต้อง login) → dict ผลค้นแบบเดียวกับ lookup_parcel_by_rawang
    (via='lis' · verified · ไม่มีเนื้อที่ — หน้านี้ไม่มีเนื้อที่) หรือ {'not_found': True}
    สำนักงานที่จะค้น (ลองไม่เกิน 2): ① ที่ UDM บอกที่ตำแหน่งแปลง ② สำนักงานของแปลงในระวางเดียวกันบน ArcGIS (ใกล้ก่อน)
    ③ สำนักงานที่ค้นสำเร็จครั้งล่าสุด"""
    offices = []
    for o in [(here or {}).get("office_seq")] + _sheet_offices(utmmap1, utmmap2, utmmap3, utmmap4, scale,
                                                                near_xy, zone, timeout) + [_last_office()]:
        o = str(o or "").strip()
        if o.isdigit() and o not in offices:
            offices.append(o)
    if not offices:
        raise DOLError("ไม่รู้ว่าแปลงนี้อยู่สำนักงานที่ดินไหน — ค้นในทะเบียน iLands ไม่ได้")
    for o in offices[:2]:
        rows = lis_search_by_key(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, o, timeout=timeout)
        if rows:
            x = rows[0]
            _remember_office(x.get("office_seq") or o)
            return {"not_registered": False, "match_count": len(rows), "parcel_seq": x.get("parcel_seq"),
                    "map_parcel_seq": None, "parcel_no": x.get("parcel_no"), "land_no": x.get("land_no"),
                    "survey_no": x.get("survey_no"), "rawang": x.get("rawang"), "area": "", "owner": None,
                    "city": "จ.%s อ.%s ต.%s" % (x.get("province", ""), x.get("amphur", ""), x.get("tambol", "")),
                    "office": x.get("office"), "office_seq": x.get("office_seq") or o, "parcel_type": "โฉนดที่ดิน",
                    "pin": x.get("pin"), "verified": True, "via": "lis", "doc_url": doc_url(x.get("parcel_seq"), "1")}
    return {"not_found": True}


# ====================================================================
#  หลักฐานการรังวัด (ต้อง login — EvdPcadastral001Servlet)
# ====================================================================
def login(username, password, timeout=None):
    """login CAS -> เก็บ session (มี DOL-TOKEN) ใน memory. raise DOLAuthError ถ้าไม่สำเร็จ"""
    timeout = timeout or T_LOGIN              # ★ 2.3.7 (review UX-22) — (ต่อ, อ่าน)
    s = _new_session("Mozilla/5.0 QGIS-MultiLayerEditPro")
    try:
        r = s.get(LOGIN_URL, timeout=timeout)
        r.raise_for_status()
        m = re.search(r'name="lt"\s+value="([^"]*)"', r.text)
        lt = m.group(1) if m else ""
        r = s.post(LOGIN_URL, data={"username": username, "password": password,
                                    "lt": lt, "_eventId": "submit", "warn": "true"},
                   timeout=timeout, allow_redirects=True)
        r.raise_for_status()
    except requests.exceptions.SSLError:
        raise DOLAuthError(SSL_MSG)
    except requests.RequestException as e:
        # ★ 2.3.7 (ER-06) เดิมข้อความดิบของ requests · (audit C-08) ไม่ใช้คำว่า "ระบบ login" ในข้อความที่พนักงานเห็น
        raise DOLAuthError(f"เชื่อมต่อระบบเข้าใช้งานของกรมไม่ได้: {net_reason(e)}")
    if not s.cookies.get("DOL-TOKEN", ""):
        # ★ 2.3.7 (review UX-31) — ระบบตอบว่าไม่ผ่าน = ถามรหัสใหม่ได้ (ต่อไม่ได้/ใบรับรองไม่ผ่านข้างบน = ถามใหม่ไม่ช่วย)
        raise DOLAuthError("เข้าสู่ระบบกรมไม่สำเร็จ — ตรวจชื่อผู้ใช้/รหัสผ่าน หรือมีการเข้าระบบซ้อนอยู่", ask_again=True)
    _old = _AUTH.get("session")
    _AUTH["session"] = s
    _AUTH["credentials"] = (username, password)
    _close_session(_old, keep=s)             # ★ 2.3.7 (review ER-04 · LC-10) — ปิด session ที่ถูกแทน
    return s


def _close_session(old, keep=None):
    """ปิดการเชื่อมต่อค้างของ session ที่เลิกใช้แล้ว (เดิมแค่ทิ้ง reference) · พังก็ไม่เป็นไร"""
    if old is None or old is keep:
        return
    try:
        old.close()
    except Exception:
        pass


def is_logged_in():
    s = _AUTH["session"]
    return bool(s and s.cookies.get("DOL-TOKEN", ""))


def logout():
    _old = _AUTH.get("session")
    _AUTH["session"] = None
    _AUTH["credentials"] = None
    _close_session(_old)                     # ★ 2.3.7 (review ER-04 · LC-10)


def province_code_from_city(city):
    """แยกรหัสจังหวัดจากข้อความ strCity เช่น 'จ.นครนายก อ.องครักษ์ ...' -> '17'

    หมายเหตุ: รหัสนี้เป็นรหัสภายในระบบ DOL (ไม่ตรงกับรหัส 77 จังหวัดมาตรฐาน)
    ต้องเก็บจากระบบจริงทีละจังหวัด — เพิ่มเองได้โดยไม่ต้องแก้โค้ด ผ่าน QSettings:
        MultiLayerEditPro/ProvinceCode/<ชื่อจังหวัด> = <รหัส>
    (Settings → Options → Advanced ใน QGIS หรือสั่งผ่าน Python console)

    ★ 2.3.7 (review DI-17) — อ่านชื่อจังหวัดจากคำ "จ.<ชื่อ>" แล้วเทียบตรงตัว
      เดิมค้นแบบ substring ⇒ 'จ.นราธิวาส อ.ตากใบ' ได้รหัสของ 'ตาก' (ถ้าเพิ่ม ตาก ไว้)
      · ค่าใน QSettings ชนะค่าในโค้ด (เดิมค้นในโค้ดก่อน ⇒ แก้รหัสที่ฝังไว้ไม่ได้)
      · ไม่มีคำ "จ." (เช่น กรุงเทพมหานคร) ค่อยค้นแบบ substring โดยชื่อยาวก่อน"""
    city = str(city or "")
    table = dict(PROVINCE_CODE)
    table.update(_settings_province_codes())          # QSettings ทับค่าในโค้ด
    m = re.search(r"จ\.\s*([^\s,;()]+)", city)
    if m:
        return table.get(m.group(1).strip()) or None
    for name in sorted(table, key=len, reverse=True):
        if name and name in city:
            return table[name]
    return None


def _settings_province_codes():
    """รหัสจังหวัดที่เพิ่ม/แก้ผ่าน QSettings MultiLayerEditPro/ProvinceCode/<ชื่อจังหวัด> = <รหัส> -> dict
    (★ 2.3.7 review DI-17/UX-30) · ชื่อ/รหัสว่างถูกข้าม · อ่านไม่ได้ = {}"""
    out = {}
    try:
        from qgis.PyQt import QtCore
        s = QtCore.QSettings()
        s.beginGroup("MultiLayerEditPro/ProvinceCode")
        try:
            for name in s.childKeys():
                code = str(s.value(name, "", str) or "").strip()
                if str(name).strip() and code:
                    out[str(name).strip()] = code
        finally:
            s.endGroup()
    except Exception:
        pass
    return out


def known_provinces():
    """ชื่อจังหวัดที่ค้นหลักฐานการรังวัดได้ = ในโค้ด ∪ ที่เพิ่มผ่าน QSettings (ไม่ซ้ำ · เรียงตามตัวอักษร)
    ★ 2.3.7 (review UX-30) — เดิมกล่องบอกรายชื่อจาก PROVINCE_CODE อย่างเดียว"""
    return sorted(set(PROVINCE_CODE) | set(_settings_province_codes()))


def survey_doc_url(cadastral_seq, plate_type="1"):
    """URL หน้าหลักฐานการรังวัด (evdsimgs001 id=2) จาก CADASTRAL_SEQ"""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=2&readOnly=2&dataId={cadastral_seq}&plateType={plate_type}&page=1")


def _collect_cadastral(obj, out):
    """ไล่หา record ที่มี CADASTRAL_SEQ ใน response (dict/list ซ้อนกัน)"""
    if isinstance(obj, dict):
        if obj.get("CADASTRAL_SEQ"):
            out.append(obj)
        for v in obj.values():
            _collect_cadastral(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _collect_cadastral(v, out)


def _service_reason(j):
    """★ 2.3.7 (audit C-07) — เหตุผลจากคำตอบ success:false ที่แสดงให้พนักงานได้ = เฉพาะ "ข้อความ" (str)
    ExtJS ส่ง errors เป็น dict/list ได้ ({field: ข้อความ} · [..]) ⇒ เดิม str(why) ⇒ พนักงานเห็น repr ของ Python ({'x': ...})
    ⇒ ไล่ errors → message → msg เอาข้อความข้างใน (ไม่เกิน 3 ข้อความ · 300 ตัวอักษร) · ไม่มีข้อความเลย ⇒ 'ไม่ระบุเหตุผล'
    (คำตอบทั้งก้อนยังอยู่ใน DOLServiceError.detail ⇒ Log ของ MLEP)"""
    found = []

    def _walk(v, depth=0):
        if len(found) >= 3 or depth > 3:
            return
        if isinstance(v, str):
            s = " ".join(v.split())
            if s:
                found.append(s)
        elif isinstance(v, dict):
            for x in v.values():
                _walk(x, depth + 1)
        elif isinstance(v, (list, tuple)):
            for x in v:
                _walk(x, depth + 1)
    for k in ("errors", "message", "msg"):
        _v = j.get(k) if isinstance(j, dict) else None
        if isinstance(_v, (int, float)) and not isinstance(_v, bool):
            # ★ 2.3.7 b17 (audit nit C-07) — ค่าตัวเลขตรง ๆ ({"message": 401}) = สิ่งที่ระบบตอบมา ⇒ แสดง (เดิม 'ไม่ระบุเหตุผล')
            #   ตัวเลขที่ซ้อนในโครงสร้าง ({"errors": {"code": 500, ...}}) ยังไม่แสดง (ไม่ใช่ข้อความ · ทั้งก้อนอยู่ใน detail)
            found.append(str(int(_v)) if isinstance(_v, float) and _v.is_integer() else str(_v))
        else:
            _walk(_v)
        if found:
            break
    return " · ".join(found)[:300] or "ไม่ระบุเหตุผล"


def search_cadastral(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                     province_code, office_seq, zone=47, timeout=None):
    """ค้นหลักฐานรังวัด -> list ของ record (มี CADASTRAL_SEQ); ต้อง login ก่อน
    คืน list (อาจมีหลายรายการต่อแปลง -> ให้ผู้เรียกทำ popup เลือก)"""
    s = _AUTH["session"]
    if not s:
        raise DOLAuthError("ยังไม่ได้เข้าสู่ระบบ DOL", ask_again=True)
    timeout = timeout or T_SURVEY                  # ★ 2.3.7 (review UX-22)
    sc = scale_code(scale)                         # ★ 2.3.7 (review ER-07) — ไม่รู้จัก = DOLError ก่อนยิงเน็ต (เดิมส่งค่าดิบ)
    ln = int(landno) if str(landno).strip().lstrip("-").isdigit() else landno
    crit = {
        "boxnoValue": "", "sheetcodeValue": "", "cadastralnoValue": "",
        "numofsurveyqtyValue": "", "provinceValue": _as_int(province_code, "รหัสจังหวัดของระบบ DOL"),
        "landofficeValue": str(office_seq), "amphurValue": "", "tambolValue": "",
        "surveynoValue": "", "sheettypeValue": 1, "zonelandValue": str(zone),
        "scaleValue": int(sc), "utmmap1Value": str(utmmap1), "utmmap2Value": str(utmmap2),
        "utmmap3Value": str(utmmap3), "utmmap4Value": str(utmmap4),
        "origionmap1Value": None, "origionmap2Value": None, "origionmap3Value": None,
        "airphotomapnameValue": "", "airphotomap1Value": None,
        "airphotomap2Value": None, "airphotomap3Value": None, "landnoValue": ln,
        "typeofsurveyValue": "", "titleValue": "", "surveyorfnameValue": "",
        "surveyorlnameValue": "", "surveyfdateValue": None, "surveyedateValue": None,
    }
    
    def _do_search(session):
        return session.post(EVD_CADASTRAL_URL,
                   data={"action": "load", "func": "search", "data": json.dumps([crit])},
                   headers={"X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
                   timeout=timeout, allow_redirects=False)

    def _parse_json(text):
        try:
            return json.loads(text)
        except ValueError:
            # ระบบของ DOL ตอบกลับเป็น ExtJS format (ไม่มีเครื่องหมายคำพูดครอบ key)
            # เช่น {success:true,results:1,data:[...]} เราต้องแก้ให้เป็น JSON ที่ถูกต้องก่อน
            fixed = re.sub(r'(^\{|,)(success|results|data|errors):', r'\1"\2":', text)
            return json.loads(fixed)

    def _classify(resp):
        """★ 2.3.7 (review ER-04) — จัดประเภทคำตอบครั้งเดียว -> ("expired", None) หรือ ("ok", json)
        เดิมทุกคำตอบที่ parse ไม่ได้ (รวมหน้า HTML ของ 5xx ตอนระบบกรมล่ม) = "token หมดอายุ" ⇒ login ใหม่ด้วยรหัสที่จำไว้
        ใน except กว้าง (เหตุจริงหาย) ⇒ ทิ้ง session ใหม่ ⇒ โชว์ HTML ดิบ + ถามรหัสซ้ำ ทั้งที่สาเหตุคือระบบกรมล่ม"""
        code = resp.status_code
        if 300 <= code < 400 or "/dolauth/login" in (resp.headers.get("Location", "") or ""):
            return "expired", None                 # ถูกส่งไปหน้า login (CAS)
        if code in (401, 403):
            return "expired", None
        body = resp.text or ""
        if code >= 500:
            raise DOLError(f"ระบบ DOL ไม่ตอบ (HTTP {code}) — ลองใหม่ภายหลัง", detail=body[:2000])
        if code >= 400:
            raise DOLError(f"ระบบ DOL ตอบผิดปกติ (HTTP {code}) — ลองใหม่ภายหลัง", detail=body[:2000])
        try:
            return "ok", _parse_json(body)
        except ValueError:
            pass
        if 'name="lt"' in body:                     # ได้หน้าฟอร์ม login ของ CAS แทนข้อมูล
            return "expired", None
        raise DOLError("รูปแบบข้อมูลจากระบบ DOL เปลี่ยน — ค้นหลักฐานการรังวัดไม่ได้ · แจ้งผู้ดูแล",
                       detail=body[:2000])

    def _search(session):
        try:
            resp = _do_search(session)
        except requests.exceptions.SSLError:
            raise DOLError(SSL_MSG)
        except requests.RequestException as e:
            raise DOLError(f"ค้นหารังวัดไม่สำเร็จ: {net_reason(e)}", detail=str(e))   # ★ 2.3.7 (ER-06) ดิบ ⇒ detail/Log
        return _classify(resp)

    kind, j = _search(s)
    if kind == "expired":
        # login ใหม่ด้วยชื่อ/รหัสที่จำไว้ในหน่วยความจำ — ★ ER-04: ไม่ครอบ except กว้างแล้ว
        #   DOLAuthError ของ login (รหัสเปลี่ยน · บัญชีถูกล็อก · ต่อไม่ได้) ถึงผู้ใช้พร้อมเหตุผลจริง
        creds = _AUTH.get("credentials")
        if not creds:
            _AUTH["session"] = None
            raise DOLAuthError("การเข้าระบบหมดอายุ — ต้องเข้าสู่ระบบใหม่", ask_again=True)     # ★ 2.3.7 (audit C-08) เดิม "token หมดอายุ"
        s = login(creds[0], creds[1])
        kind, j = _search(s)                        # session ใหม่ไม่ถูกทิ้ง เว้นแต่ยังถูกปฏิเสธซ้ำ
        if kind == "expired":
            _AUTH["session"] = None
            raise DOLAuthError("ระบบ DOL ไม่ยอมรับการเข้าสู่ระบบ แม้เพิ่งเข้าสู่ระบบใหม่ — บัญชีนี้อาจไม่มีสิทธิ์"
                               "ค้นหลักฐานการรังวัด หรือระบบ DOL ขัดข้อง (ลองใหม่ภายหลัง)")
    # ★ 2.3.7 (review DI-18) — ExtJS success:false = ทำรายการไม่สำเร็จ
    #   เดิมไม่ดูธงนี้ ⇒ ได้ [] ⇒ พนักงานเห็น "ไม่พบหลักฐานการรังวัด" ทั้งที่ระบบตอบ error
    if isinstance(j, dict) and str(j.get("success")).strip().lower() == "false":
        # ★ 2.3.7 (audit C-07) — เหตุผลเฉพาะข้อความ (ไม่ใช่ str() ของ dict/list) · ทั้งก้อนไป detail (Log)
        raise DOLServiceError(f"ระบบ DOL ตอบว่าค้นหาไม่สำเร็จ: {_service_reason(j)}", detail=str(j)[:2000])
    # อ่าน record จาก data ก่อน (ไม่เก็บ CADASTRAL_SEQ ที่โผล่ในส่วนอื่นของคำตอบ) · ไม่มี data ค่อยไล่ทั้งก้อนแบบเดิม
    recs = []
    _collect_cadastral(j["data"] if isinstance(j, dict) and "data" in j else j, recs)
    # ตัดซ้ำตาม CADASTRAL_SEQ
    seen, uniq = set(), []
    for rec in recs:
        cs = str(rec.get("CADASTRAL_SEQ"))
        if cs not in seen:
            seen.add(cs)
            uniq.append(rec)
    return uniq
