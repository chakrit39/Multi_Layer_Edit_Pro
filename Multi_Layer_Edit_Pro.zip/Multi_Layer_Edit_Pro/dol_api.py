"""
DOL iLands API (public — ไม่ต้อง login) สำหรับ Multi-Layer Edit Pro
ค้นหา PARCEL_SEQ จาก "เลขระวาง" (attribute) ผ่าน 2 ขั้น:
  ① ArcGIS : attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ
  ② UDM    : GetMapInformation(centroid) -> strRegParcelSeq (=PARCEL_SEQ) + ข้อมูลแปลง
ใช้ attribute (ไม่พึ่งตำแหน่ง polygon ใน QGIS) -> กันแปลงที่ถูกขยับ/แก้ไข
"""

import json
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE = "https://ilands.dol.go.th"
ARCGIS_PARCEL_LAYER = {
    47: f"{BASE}/arcgis/rest/services/MapDOL_47/MapServer/6",
    48: f"{BASE}/arcgis/rest/services/MapDOL_48/MapServer/6",
}
UDM_MAPINFO_URL = f"{BASE}/UDM_MAP/frmMain.aspx/GetMapInformation"

# session ใช้ร่วม (keep-alive) -> ArcGIS + UDM host เดียวกัน, call ที่ 2 ไม่ต้อง TLS handshake ใหม่
_PUBLIC_SESSION = requests.Session()
_PUBLIC_SESSION.headers.update({"User-Agent": "QGIS-MultiLayerEditPro"})


class DOLError(Exception):
    pass


def doc_url(seq, plate_type="1"):
    """URL หน้าดูภาพลักษณ์ (evdsimgs001) จาก PARCEL_SEQ"""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=1&readOnly=2&dataId={seq}&plateType={plate_type}&page=1")


def _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                        zone=47, near_xy=None, timeout=20):
    """ArcGIS: attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ (None ถ้าไม่พบ)

    near_xy=(x,y) ใน datum 24047: ใช้ตัดสินเมื่อ "ระวางคร่อมหลายสาขา" ทำให้ LAND_NO
    ซ้ำข้ามสาขา (query ได้หลาย feature) -> เลือกแปลงที่ centroid ใกล้จุดที่คลิกที่สุด
    (กันเปิดภาพลักษณ์ผิดสาขา)
    """
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        raise DOLError(f"ไม่รองรับ zone {zone}")
    where = (f"UTMMAP1='{utmmap1}' AND UTMMAP2={int(utmmap2)} AND UTMMAP3='{utmmap3}' "
             f"AND UTMMAP4='{utmmap4}' AND UTMSCALE={int(scale)} AND LAND_NO='{landno}'")
    params = {
        "where": where,
        "outFields": "MAP_PARCEL_SEQ,ORIGIN_X,ORIGIN_Y,LANDOFFICE_SEQ,LAND_NO",
        "returnGeometry": "false", "f": "json",
    }
    r = _PUBLIC_SESSION.get(f"{layer}/query", params=params, verify=False, timeout=timeout)
    r.raise_for_status()
    feats = r.json().get("features", [])
    if not feats:
        return None
    # ระวางคร่อมสาขา -> มีได้หลายแปลง LAND_NO เดียวกัน: เลือกตัวที่ centroid ใกล้จุดคลิกสุด
    if near_xy and len(feats) > 1:
        nx, ny = near_xy
        feats.sort(key=lambda f: (f["attributes"].get("ORIGIN_X", 0) - nx) ** 2
                                 + (f["attributes"].get("ORIGIN_Y", 0) - ny) ** 2)
    att = dict(feats[0]["attributes"])
    att["_match_count"] = len(feats)   # >1 = ระวางกำกวม (เลือกตัวใกล้สุดแล้ว)
    return att


def get_map_information(x, y, zone=47, parcel_type=1, timeout=20):
    """UDM GetMapInformation: พิกัด (X,Y datum 24047) -> ข้อมูลแปลง (dict)"""
    payload = {"Zone": str(zone), "X": str(x), "Y": str(y),
               "PARCEL_TYPE": str(parcel_type), "pid": "", "pr_Sys": "udm"}
    headers = {"Content-Type": "application/json; charset=utf-8",
               "X-Requested-With": "XMLHttpRequest"}
    r = _PUBLIC_SESSION.post(UDM_MAPINFO_URL, data=json.dumps(payload), headers=headers,
                             verify=False, timeout=timeout)
    r.raise_for_status()
    return json.loads(r.json()["d"])  # {"d":"<json string>"} -> dict


def lookup_parcel_by_rawang(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                            zone=47, parcel_type=1, near_xy=None):
    """
    ระวาง(attribute) -> PARCEL_SEQ + ข้อมูลแปลง  (public, ~90ms)
    near_xy=(x,y) 24047: จุด centroid ของแปลงที่คลิก ใช้แก้ปัญหาระวางคร่อมสาขา
    คืน dict (มี key 'verified' กันแปลงผิด, 'match_count' บอกความกำกวม) หรือ None ถ้าไม่พบ
    """
    arc = _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                              zone, near_xy=near_xy)
    if not arc:
        return None
    d = get_map_information(arc["ORIGIN_X"], arc["ORIGIN_Y"], zone, parcel_type)
    map_seq = str(arc.get("MAP_PARCEL_SEQ"))
    return {
        "match_count": arc.get("_match_count", 1),    # >1 = ระวางคร่อมสาขา (เลือกใกล้สุดแล้ว)
        "parcel_seq": d.get("strRegParcelSeq"),       # PARCEL_SEQ ฝั่งโฉนด (ที่ต้องการ)
        "map_parcel_seq": d.get("strMapParcelSeq"),
        "parcel_no": d.get("strParcelNo"),            # เลขโฉนด
        "land_no": d.get("strLandNo"),
        "survey_no": d.get("strSurveyNo"),            # หน้าสำรวจ
        "rawang": d.get("strRawang"),
        "area": d.get("strArea"),
        "owner": d.get("strOwner"),
        "city": d.get("strCity"),
        "office": d.get("strOfficeSname"),
        "office_seq": d.get("strOfficeSeq"),
        "parcel_type": d.get("strParcel_Type"),
        # กันพลาด: centroid ต้องตกบนแปลง MAP_PARCEL_SEQ เดิม
        "verified": str(d.get("strMapParcelSeq")) == map_seq,
        "doc_url": doc_url(d.get("strRegParcelSeq"), "1"),
    }
