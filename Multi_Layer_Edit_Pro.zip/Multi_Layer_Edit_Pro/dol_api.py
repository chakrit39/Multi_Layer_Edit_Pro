"""
DOL iLands API (public — ไม่ต้อง login) สำหรับ Multi-Layer Edit Pro
ค้นหา PARCEL_SEQ จาก "เลขระวาง" (attribute) ผ่าน 2 ขั้น:
  ① ArcGIS : attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ
  ② UDM    : GetMapInformation(centroid) -> strRegParcelSeq (=PARCEL_SEQ) + ข้อมูลแปลง
ใช้ attribute (ไม่พึ่งตำแหน่ง polygon ใน QGIS) -> กันแปลงที่ถูกขยับ/แก้ไข
"""

import re
import json
import requests

import ssl
from requests.adapters import HTTPAdapter

# ★ 2.3.7 (review SE-01 · P0) — ตรวจใบรับรอง TLS ทุกคำขอ
#   เดิม verify=False ทั้ง 6 จุด รวม POST รหัสผ่าน CAS + ปิดคำเตือน InsecureRequestWarning ทั้ง process
#   ⇒ ใครดักเครือข่ายได้ก็ปลอมเป็นระบบกรมแล้วเก็บรหัสผ่าน/คุกกี้ DOL-TOKEN ได้ · ใบรับรองไม่ผ่าน = แจ้งชัด ห้ามถอยไป verify=False
#   เชื่อใบรับรองชุดเดียวกับเบราว์เซอร์: ที่เก็บใบรับรองของ Windows (รวมใบของโปรแกรมป้องกันไวรัสที่ตรวจ HTTPS
#   ซึ่งติดตั้งไว้ในเครื่อง) + ชุดของ certifi — ถ้าใช้ certifi อย่างเดียว เครื่องที่มีโปรแกรมแบบนั้นจะใช้ปุ่ม DOL ไม่ได้เลย
SSL_MSG = ("ตรวจใบรับรองความปลอดภัยของระบบกรมไม่ผ่าน — เครือข่ายหรือโปรแกรมป้องกันไวรัสอาจดักการเชื่อมต่อ "
           "(ยังไม่ได้ส่งข้อมูลใด ๆ) · แจ้งผู้ดูแล")


class _TrustAdapter(HTTPAdapter):
    """ส่ง SSLContext ที่โหลดใบรับรองของระบบ + certifi ให้ urllib3 (ทั้งต่อตรงและผ่าน proxy)"""

    def __init__(self, ctx, **kw):
        self._ctx = ctx
        super().__init__(**kw)

    def init_poolmanager(self, *a, **kw):
        kw["ssl_context"] = self._ctx
        return super().init_poolmanager(*a, **kw)

    def proxy_manager_for(self, proxy, **kw):
        kw["ssl_context"] = self._ctx
        return super().proxy_manager_for(proxy, **kw)


def _trust_context():
    ctx = ssl.create_default_context()          # ตรวจชื่อโฮสต์ + CERT_REQUIRED · Windows = โหลดที่เก็บ ROOT/CA ของระบบ
    try:
        import certifi
        ctx.load_verify_locations(certifi.where())
    except Exception:
        pass
    return ctx


def _new_session(user_agent):
    s = requests.Session()
    s.headers.update({"User-Agent": user_agent})
    try:
        s.mount("https://", _TrustAdapter(_trust_context()))
    except Exception:
        pass        # สร้าง context ไม่ได้ ⇒ ใช้ค่าตั้งต้นของ requests (certifi) — ยังตรวจใบรับรองอยู่ ไม่ถอยไป verify=False
    return s

BASE = "https://ilands.dol.go.th"
ARCGIS_PARCEL_LAYER = {
    47: f"{BASE}/arcgis/rest/services/MapDOL_47/MapServer/6",
    48: f"{BASE}/arcgis/rest/services/MapDOL_48/MapServer/6",
}
UDM_MAPINFO_URL = f"{BASE}/UDM_MAP/frmMain.aspx/GetMapInformation"
LOGIN_URL = f"{BASE}/dolauth/login"
EVD_CADASTRAL_URL = f"{BASE}/evd/servlet/EvdPcadastral001Servlet"

# จังหวัด/มาตราส่วน -> รหัสที่ servlet รังวัดใช้
PROVINCE_CODE = {"ชลบุรี": "11", "นครนายก": "17", "ปทุมธานี": "4"}
SCALE_CODE = {"500": "1", "1000": "2", "2000": "3", "4000": "5"}

# ★ 2.3.7 (review UX-22) — timeout แบบ (ต่อ, อ่าน) · เดิมตัวเลขเดียว 20-30 วิ ใช้ทั้งตอนต่อและตอนอ่าน
#   ⇒ ต่อระบบกรมไม่ได้ = รอ ~20 วิ ต่อคำขอ (สะสมได้หลายช่วง) · ค่าต่อ 6.05 = เลยพหุคูณ 3 วิของการลองต่อ TCP ซ้ำไปเล็กน้อย
#   ⇒ ต่อไม่ได้รู้ใน ~6 วิ · ค่าอ่านคงเดิม (คำค้นที่ช้ายังมีเวลาเท่าเดิม)
#   ผู้เรียกส่ง timeout=None = ใช้ค่าข้างล่าง ณ ตอนเรียก (ไม่ผูกเป็น default argument — แก้ค่าคงที่ทีหลังแล้วมีผลจริง)
T_PUBLIC = (6.05, 20)
T_SHEET = (6.05, 25)
T_LOGIN = (6.05, 20)
T_SURVEY = (6.05, 30)

# session ใช้ร่วม (keep-alive) -> ArcGIS + UDM host เดียวกัน, call ที่ 2 ไม่ต้อง TLS handshake ใหม่
_PUBLIC_SESSION = _new_session("QGIS-MultiLayerEditPro")

# session ที่ login แล้ว (เก็บใน memory เท่านั้น — ปิด QGIS แล้วหาย ไม่บันทึกลงดิสก์)
_AUTH = {"session": None, "credentials": None}


class DOLError(Exception):
    """ข้อผิดพลาดของระบบกรม/ข้อมูล — ข้อความ (str) แสดงให้พนักงานได้
    ★ 2.3.7 (review ER-04) — detail = เนื้อคำตอบดิบจากระบบกรม ไว้เขียนลง Log ของ MLEP ให้ผู้ดูแล (ไม่ใส่ในกล่องข้อความ)"""

    def __init__(self, msg="", detail=""):
        super().__init__(msg)
        self.detail = detail


class DOLServiceError(DOLError):
    """★ 2.3.7 (review DI-18) — บริการค้นหลักฐานรังวัดตอบ success:false = ทำรายการไม่สำเร็จ (≠ "ไม่พบข้อมูล")"""


class DOLAuthError(Exception):
    """login ล้มเหลว / token หมดอายุ
    ★ 2.3.7 (review UX-31 / ER-04) — ask_again=True = ถามชื่อผู้ใช้/รหัสผ่านใหม่แล้วอาจผ่าน
      (ระบบตอบว่าเข้าสู่ระบบไม่ผ่าน · ยังไม่ได้เข้าสู่ระบบ) · False = ถามใหม่ไม่ช่วย
      (ต่อระบบไม่ได้ · ใบรับรองไม่ผ่าน · เข้าสู่ระบบใหม่แล้วยังถูกปฏิเสธ)"""

    def __init__(self, msg="", ask_again=False):
        super().__init__(msg)
        self.ask_again = ask_again


def net_reason(e):
    """★ 2.3.7 (review ER-06) — exception ของ requests ⇒ เหตุภาษาไทยสั้น ๆ · ไม่ใช่ของ requests ⇒ None
    (ข้อความดิบเช่น HTTPSConnectionPool(...): Max retries exceeded ... ไปอยู่ใน detail/Log ไม่ใช่กล่องของพนักงาน)
    🔑 ลำดับสำคัญ: SSLError และ ConnectTimeout เป็นลูกของ ConnectionError ⇒ ตรวจก่อน"""
    try:
        if isinstance(e, requests.exceptions.SSLError):
            return SSL_MSG
        if isinstance(e, requests.exceptions.Timeout):
            return "ระบบปลายทางตอบช้าเกินเวลา (หมดเวลารอ) — ลองใหม่ภายหลัง"
        if isinstance(e, requests.exceptions.ConnectionError):
            return "เชื่อมต่อเครือข่ายไม่ได้ — ตรวจอินเทอร์เน็ต/เครือข่ายของสำนักงาน"
        if isinstance(e, requests.exceptions.HTTPError):
            code = getattr(getattr(e, "response", None), "status_code", None)
            return f"ระบบปลายทางตอบผิดปกติ (HTTP {code})" if code else "ระบบปลายทางตอบผิดปกติ"
        if isinstance(e, requests.exceptions.RequestException):
            return "การเชื่อมต่อผิดพลาด"
    except Exception:
        pass
    return None


def _as_int(v, what):
    """ค่าตัวเลขจาก attribute/QSettings -> int · รับ '2.0' / 4000.0 (ทศนิยมที่เป็นจำนวนเต็ม)
    ★ 2.3.7 (review ER-07) — เดิม int() ตรง ๆ โยน ValueError เปล่า ⇒ กล่อง 'ค้นหาไม่สำเร็จ: invalid literal for int()…'
      ไม่ใช่ตัวเลข ⇒ DOLError ภาษาไทยที่บอกว่าช่องไหน"""
    s = "" if v is None else str(v).strip()
    try:
        return int(s)
    except ValueError:
        pass
    try:
        f = float(s)
    except ValueError:
        f = None
    if f is not None and f.is_integer():
        return int(f)
    raise DOLError(f"{what} ไม่ใช่ตัวเลข: {v!r}")


def scale_code(scale):
    """มาตราส่วนของระวาง -> รหัสที่ servlet ค้นหลักฐานรังวัดใช้
    ★ 2.3.7 (review ER-07) — เดิมมาตราส่วนที่ไม่รู้จักถูกส่งค่าดิบ ⇒ ได้ผลว่าง ⇒ พนักงานเห็น "ไม่พบหลักฐานการรังวัด"
      ทั้งที่จริงคือยังไม่รองรับมาตราส่วนนั้น ⇒ แจ้งตรง ๆ ก่อนยิงเน็ต"""
    code = SCALE_CODE.get(str(scale).strip())
    if code is None:
        try:
            code = SCALE_CODE.get(str(_as_int(scale, "มาตราส่วน")))
        except DOLError:
            code = None
    if code is None:
        raise DOLError(f"ยังไม่รองรับมาตราส่วน 1:{str(scale).strip()} สำหรับค้นหลักฐานการรังวัด")
    return code


def doc_url(seq, plate_type="1"):
    """URL หน้าดูภาพลักษณ์ (evdsimgs001) จาก PARCEL_SEQ"""
    if not seq:
        return ""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=1&readOnly=2&dataId={seq}&plateType={plate_type}&page=1")


def _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                        zone=47, near_xy=None, timeout=None):
    """ArcGIS: attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ (None ถ้าไม่พบ)

    near_xy=(x,y) ใน datum 24047: ใช้ตัดสินเมื่อ "ระวางคร่อมหลายสาขา" ทำให้ LAND_NO
    ซ้ำข้ามสาขา (query ได้หลาย feature) -> เลือกแปลงที่ centroid ใกล้จุดที่คลิกที่สุด
    (กันเปิดภาพลักษณ์ผิดสาขา)
    """
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        raise DOLError(f"ไม่รองรับ zone {zone}")
    def _q(v):
        # escape ' กัน where-clause พัง/ถูกฉีดเงื่อนไข เมื่อค่า attribute มี quote ปน (SQL-92)
        return str(v).replace("'", "''")
    # ★ 2.3.7 (review ER-07) — _as_int: รับ '2.0' · ไม่ใช่ตัวเลข = DOLError ภาษาไทย (เดิม ValueError เปล่า)
    where = (f"UTMMAP1='{_q(utmmap1)}' AND UTMMAP2={_as_int(utmmap2, 'UTMMAP2')} AND UTMMAP3='{_q(utmmap3)}' "
             f"AND UTMMAP4='{_q(utmmap4)}' AND UTMSCALE={_as_int(scale, 'มาตราส่วน')} AND LAND_NO='{_q(landno)}'")
    params = {
        "where": where,
        "outFields": "MAP_PARCEL_SEQ,ORIGIN_X,ORIGIN_Y,LANDOFFICE_SEQ,LAND_NO",
        "returnGeometry": "false", "f": "json",
    }
    try:
        r = _PUBLIC_SESSION.get(f"{layer}/query", params=params, timeout=timeout or T_PUBLIC)
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)
    r.raise_for_status()
    j = r.json()
    # ArcGIS ตอบ error เป็น HTTP 200 + {"error": {...}} — เดิมถูกอ่านเป็น "ไม่พบแปลง" เงียบ ๆ
    if isinstance(j, dict) and "error" in j:
        err = j["error"]
        # error อาจเป็น dict (มาตรฐาน ArcGIS), string หรือ list (proxy/WAF) — และ message อาจว่างโดยมี details แทน
        if isinstance(err, dict):
            det = err.get("details")
            if isinstance(det, (list, tuple)):
                det = "; ".join(str(d) for d in det)   # details เป็น string/int ก็ได้ — ห้าม join ตรง ๆ
            msg = err.get("message") or (str(det) if det else "") or str(err)
        else:
            msg = str(err)
        # ★ 2.3.7 b19 (doc-verify E8) — เดิม "ArcGIS ขัดข้อง: <ข้อความดิบ>" (อังกฤษ/รหัส เช่น 'Unable to complete operation.')
        #   ถึงกล่องของพนักงาน และไม่ลง Log ⇒ ข้อความไทยของเรา · ตัวจริงทั้งก้อนไป detail ⇒ ParcelLookupWorker เขียนลง Log ของ MLEP
        raise DOLError("ระบบแผนที่ของกรมตอบข้อผิดพลาด — ค้นแปลงด้วยระวางนี้ไม่ได้ตอนนี้ ลองใหม่ภายหลัง "
                       "(รายละเอียดอยู่ในแผง Log Messages แท็บ MLEP)",
                       detail=f"ArcGIS error: {msg} · {err}"[:2000])
    feats = j.get("features", [])
    if not feats:
        return None
    # ระวางคร่อมสาขา -> มีได้หลายแปลง LAND_NO เดียวกัน: เลือกตัวที่ centroid ใกล้จุดคลิกสุด
    if near_xy and len(feats) > 1:
        nx, ny = near_xy
        # ★ ArcGIS คืน attribute ที่ว่างเป็น JSON null -> .get(...,0) ได้ None (คีย์มีอยู่ ค่าเป็น null)
        #   เดิม None - nx = TypeError ทำให้การค้นหาล้มทั้งครั้ง · ตอนนี้ดันตัวที่พิกัดว่างไปท้ายแถว
        def _dist2(f):
            a = f.get("attributes") or {}
            x, y = a.get("ORIGIN_X"), a.get("ORIGIN_Y")
            if x is None or y is None:
                return float("inf")
            try:
                return (float(x) - nx) ** 2 + (float(y) - ny) ** 2
            except (TypeError, ValueError):
                return float("inf")
        feats.sort(key=_dist2)
    att = dict(feats[0]["attributes"])
    att["_match_count"] = len(feats)   # >1 = ระวางกำกวม (เลือกตัวใกล้สุดแล้ว)
    return att


def get_map_information(x, y, zone=47, parcel_type=1, timeout=None):
    try:
        return _get_map_information(x, y, zone, parcel_type, timeout or T_PUBLIC)
    except requests.exceptions.SSLError:
        raise DOLError(SSL_MSG)


def _get_map_information(x, y, zone=47, parcel_type=1, timeout=20):
    """UDM GetMapInformation: พิกัด (X,Y datum 24047) -> ข้อมูลแปลง (dict)"""
    payload = {"Zone": str(zone), "X": str(x), "Y": str(y),
               "PARCEL_TYPE": str(parcel_type), "pid": "", "pr_Sys": "udm"}
    headers = {"Content-Type": "application/json; charset=utf-8",
               "X-Requested-With": "XMLHttpRequest"}
    r = _PUBLIC_SESSION.post(UDM_MAPINFO_URL, data=json.dumps(payload), headers=headers,
                             timeout=timeout)
    r.raise_for_status()
    return json.loads(r.json()["d"])  # {"d":"<json string>"} -> dict


def sheet_land_numbers(utmmap1, utmmap2, utmmap3, utmmap4, scale, zone=47, timeout=None):
    """คืนชุดเลขที่ดินที่ **ระบบ DOL มีอยู่จริง** ในระวางนั้น (set ของสตริง)

    ★ 2.3.1 (21 ก.ย. 69) — ใช้ตอบให้ตรงว่า "หาไม่เจอเพราะอะไร"
      เดิมพอ ArcGIS ไม่คืนอะไร ปลั๊กอินขึ้นว่า "ตรวจเลขระวาง / zone UTM"
      ซึ่ง **ชี้ผิดทาง** เมื่อระวางถูกต้องอยู่แล้ว แต่ DOL ไม่มีเลขที่ดินนั้น
      (เคสจริง: องครักษ์ gid 20265 ระวาง 5137 2 1058-07 ที่ดิน 89 —
       ระวางนี้ DOL มี 98 เลข แต่ไม่มี 88/89/105)
    คืน None ถ้าถามไม่ได้ (เน็ตล่ม/บริการตอบ error) — ผู้เรียกต้องแยกจาก set ว่าง
    """
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        return None

    def _q(v):
        return str(v).replace("'", "''")
    where = (f"UTMMAP1='{_q(utmmap1)}' AND UTMMAP2={_as_int(utmmap2, 'UTMMAP2')} AND UTMMAP3='{_q(utmmap3)}' "
             f"AND UTMMAP4='{_q(utmmap4)}' AND UTMSCALE={_as_int(scale, 'มาตราส่วน')}")      # ★ 2.3.7 ER-07
    try:
        r = _PUBLIC_SESSION.get(f"{layer}/query", timeout=timeout or T_SHEET, params={
            "where": where, "outFields": "LAND_NO", "returnGeometry": "false",
            "f": "json", "resultRecordCount": 3000})
        r.raise_for_status()
        j = r.json()
        if not isinstance(j, dict) or "error" in j:
            return None
        return {str((f.get("attributes") or {}).get("LAND_NO")).strip()
                for f in (j.get("features") or [])}
    except Exception:
        return None


def lookup_parcel_by_rawang(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                            zone=47, parcel_type=1, near_xy=None, timeout=None):
    """
    ระวาง(attribute) -> PARCEL_SEQ + ข้อมูลแปลง  (public · 2-3 คำขอ ต่อคำขอ ≤ ~6 วิถ้าต่อไม่ได้ · timeout=None = T_PUBLIC/T_SHEET)
    near_xy=(x,y) 24047: จุด centroid ของแปลงที่คลิก ใช้แก้ปัญหาระวางคร่อมสาขา
    คืน dict (มี key 'verified' กันแปลงผิด, 'match_count' บอกความกำกวม) หรือ None ถ้าไม่พบ
    """
    arc = _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                              zone, near_xy=near_xy, timeout=timeout)
    if not arc:
        # ★ 2.3.1 — หาไม่เจอ: ถามต่อว่า "ระวางมี แต่ไม่มีเลขนี้" หรือ "ไม่มีระวางนี้เลย"
        #   ทำในเธรดเบื้องหลังตัวเดียวกัน (ไม่หน่วง UI) · ล้มเหลวก็คืนรูปเดิมได้
        เลข = sheet_land_numbers(utmmap1, utmmap2, utmmap3, utmmap4, scale, zone, timeout=timeout)
        return {"not_found": True,
                "sheet_exists": (None if เลข is None else bool(เลข)),
                "sheet_land_count": (None if เลข is None else len(เลข)),
                "asked_land_no": str(landno).strip()}
    # ★ กันส่ง None ต่อไปให้ UDM (จะกลายเป็นสตริง 'None' แล้วได้ผลลัพธ์มั่ว) — แจ้งสาเหตุตรง ๆ แทน
    if arc.get("ORIGIN_X") is None or arc.get("ORIGIN_Y") is None:
        raise DOLError("ระบบ DOL ไม่มีพิกัดศูนย์กลาง (ORIGIN_X/Y) ของแปลงนี้ — ค้นด้วยระวางนี้ไม่ได้")
    d = get_map_information(arc["ORIGIN_X"], arc["ORIGIN_Y"], zone, parcel_type, timeout=timeout)
    # ★ 2.3.3 (23 ก.ย. 69) — UDM ไม่มีข้อมูลที่พิกัดนั้น ⇒ คืน None
    #   เดิมบรรทัดถัดไปเอา `in` ไปใช้กับ None ทันที ได้
    #   TypeError: argument of type 'NoneType' is not iterable ซึ่งชี้ผิดทางสิ้นเชิง
    #   กันที่นี่ที่เดียวไม่พอ — `get_v()` ข้างล่างก็ใช้ `in d` / `d.get()` ต่อ
    #   เจอจริง: ระวาง 5137 3 7054-00 1:4000 เลขที่ดิน 514
    if not d:
        raise DOLError("ระบบ DOL ไม่มีข้อมูลแปลงที่พิกัดของระวางนี้ — ค้นด้วยระวางนี้ไม่ได้")
    map_seq = str(arc.get("MAP_PARCEL_SEQ")).strip()

    idx = -1
    if "strMapParcelSeqs" in d and d["strMapParcelSeqs"]:
        _seqs = d["strMapParcelSeqs"]
        try:
            # ★ 2.3.7 (review DI-16) — รายการ: เทียบแบบ str+strip ทั้งสองฝั่ง (UDM ส่งเป็นตัวเลข/มีช่องว่าง
            #   ⇒ เดิมหาไม่เจอ ⇒ ได้ค่าเดี่ยวของแปลงอื่น + verified=False) · ไม่ใช่รายการ = แบบเดิม
            if isinstance(_seqs, (list, tuple)):
                idx = [str(_x).strip() for _x in _seqs].index(map_seq)
            else:
                idx = _seqs.index(map_seq)
        except ValueError:
            pass

    def get_v(singular, plural):
        if idx >= 0 and plural in d and d[plural] and idx < len(d[plural]):
            return d[plural][idx]
        return d.get(singular)

    parcel_seq = get_v("strRegParcelSeq", "strRegParcelSeqs")
    # 🔧 2.2.10 (17 ก.ย. 69) — แปลงที่ "ไม่มีทะเบียน" ในระบบ DOL: UDM ตอบ strDisplayNotRegData='1'
    #   และไม่ส่ง PARCEL_SEQ / ชื่อจังหวัด-ตำบลมา (แต่ยังส่งชื่อสำนักงานมา)
    #   เจอจริง: gid 211734 ปทุม L1-RTK 179 ⇒ ปุ่มหลักฐานรังวัดขึ้น "ยังไม่รองรับจังหวัด ()" ชี้ผิดทาง
    not_reg = (str(get_v("strDisplayNotRegData", "strDisplayNotRegDatas")) == "1") or not parcel_seq
    return {
        "not_registered": not_reg,
        "match_count": arc.get("_match_count", 1),    # >1 = ระวางคร่อมสาขา (เลือกใกล้สุดแล้ว)
        "parcel_seq": parcel_seq,                     # PARCEL_SEQ ฝั่งโฉนด (ที่ต้องการ)
        "map_parcel_seq": get_v("strMapParcelSeq", "strMapParcelSeqs"),
        "parcel_no": get_v("strParcelNo", "strParcelNos"),
        "land_no": get_v("strLandNo", "strLandNos"),
        "survey_no": get_v("strSurveyNo", "strSurveyNos"),
        "rawang": get_v("strRawang", "strRawangs"),
        "area": get_v("strArea", "strAreas"),
        "owner": get_v("strOwner", "strOwners"),
        "city": get_v("strCity", "strCitys"),
        "office": get_v("strOfficeSname", "strOfficeSnames"),
        "office_seq": get_v("strOfficeSeq", "strOfficeSeqs"),
        "parcel_type": get_v("strParcel_Type", "strParcel_Types"),
        "verified": str(get_v("strMapParcelSeq", "strMapParcelSeqs")).strip() == map_seq,
        "doc_url": doc_url(parcel_seq, "1"),
    }


# ====================================================================
#  หลักฐานการรังวัด (ต้อง login — EvdPcadastral001Servlet)
# ====================================================================
def login(username, password, timeout=None):
    """login CAS -> เก็บ session (มี DOL-TOKEN) ใน memory. raise DOLAuthError ถ้าไม่สำเร็จ"""
    timeout = timeout or T_LOGIN              # ★ 2.3.7 (review UX-22) — (ต่อ, อ่าน)
    s = _new_session("Mozilla/5.0 QGIS-MultiLayerEditPro")
    try:
        r = s.get(LOGIN_URL, timeout=timeout)
        r.raise_for_status()
        m = re.search(r'name="lt"\s+value="([^"]*)"', r.text)
        lt = m.group(1) if m else ""
        r = s.post(LOGIN_URL, data={"username": username, "password": password,
                                    "lt": lt, "_eventId": "submit", "warn": "true"},
                   timeout=timeout, allow_redirects=True)
        r.raise_for_status()
    except requests.exceptions.SSLError:
        raise DOLAuthError(SSL_MSG)
    except requests.RequestException as e:
        # ★ 2.3.7 (ER-06) เดิมข้อความดิบของ requests · (audit C-08) ไม่ใช้คำว่า "ระบบ login" ในข้อความที่พนักงานเห็น
        raise DOLAuthError(f"เชื่อมต่อระบบเข้าใช้งานของกรมไม่ได้: {net_reason(e)}")
    if not s.cookies.get("DOL-TOKEN", ""):
        # ★ 2.3.7 (review UX-31) — ระบบตอบว่าไม่ผ่าน = ถามรหัสใหม่ได้ (ต่อไม่ได้/ใบรับรองไม่ผ่านข้างบน = ถามใหม่ไม่ช่วย)
        raise DOLAuthError("เข้าสู่ระบบกรมไม่สำเร็จ — ตรวจชื่อผู้ใช้/รหัสผ่าน หรือมีการเข้าระบบซ้อนอยู่", ask_again=True)
    _old = _AUTH.get("session")
    _AUTH["session"] = s
    _AUTH["credentials"] = (username, password)
    _close_session(_old, keep=s)             # ★ 2.3.7 (review ER-04 · LC-10) — ปิด session ที่ถูกแทน
    return s


def _close_session(old, keep=None):
    """ปิดการเชื่อมต่อค้างของ session ที่เลิกใช้แล้ว (เดิมแค่ทิ้ง reference) · พังก็ไม่เป็นไร"""
    if old is None or old is keep:
        return
    try:
        old.close()
    except Exception:
        pass


def is_logged_in():
    s = _AUTH["session"]
    return bool(s and s.cookies.get("DOL-TOKEN", ""))


def logout():
    _old = _AUTH.get("session")
    _AUTH["session"] = None
    _AUTH["credentials"] = None
    _close_session(_old)                     # ★ 2.3.7 (review ER-04 · LC-10)


def province_code_from_city(city):
    """แยกรหัสจังหวัดจากข้อความ strCity เช่น 'จ.นครนายก อ.องครักษ์ ...' -> '17'

    หมายเหตุ: รหัสนี้เป็นรหัสภายในระบบ DOL (ไม่ตรงกับรหัส 77 จังหวัดมาตรฐาน)
    ต้องเก็บจากระบบจริงทีละจังหวัด — เพิ่มเองได้โดยไม่ต้องแก้โค้ด ผ่าน QSettings:
        MultiLayerEditPro/ProvinceCode/<ชื่อจังหวัด> = <รหัส>
    (Settings → Options → Advanced ใน QGIS หรือสั่งผ่าน Python console)

    ★ 2.3.7 (review DI-17) — อ่านชื่อจังหวัดจากคำ "จ.<ชื่อ>" แล้วเทียบตรงตัว
      เดิมค้นแบบ substring ⇒ 'จ.นราธิวาส อ.ตากใบ' ได้รหัสของ 'ตาก' (ถ้าเพิ่ม ตาก ไว้)
      · ค่าใน QSettings ชนะค่าในโค้ด (เดิมค้นในโค้ดก่อน ⇒ แก้รหัสที่ฝังไว้ไม่ได้)
      · ไม่มีคำ "จ." (เช่น กรุงเทพมหานคร) ค่อยค้นแบบ substring โดยชื่อยาวก่อน"""
    city = str(city or "")
    table = dict(PROVINCE_CODE)
    table.update(_settings_province_codes())          # QSettings ทับค่าในโค้ด
    m = re.search(r"จ\.\s*([^\s,;()]+)", city)
    if m:
        return table.get(m.group(1).strip()) or None
    for name in sorted(table, key=len, reverse=True):
        if name and name in city:
            return table[name]
    return None


def _settings_province_codes():
    """รหัสจังหวัดที่เพิ่ม/แก้ผ่าน QSettings MultiLayerEditPro/ProvinceCode/<ชื่อจังหวัด> = <รหัส> -> dict
    (★ 2.3.7 review DI-17/UX-30) · ชื่อ/รหัสว่างถูกข้าม · อ่านไม่ได้ = {}"""
    out = {}
    try:
        from qgis.PyQt import QtCore
        s = QtCore.QSettings()
        s.beginGroup("MultiLayerEditPro/ProvinceCode")
        try:
            for name in s.childKeys():
                code = str(s.value(name, "", str) or "").strip()
                if str(name).strip() and code:
                    out[str(name).strip()] = code
        finally:
            s.endGroup()
    except Exception:
        pass
    return out


def known_provinces():
    """ชื่อจังหวัดที่ค้นหลักฐานการรังวัดได้ = ในโค้ด ∪ ที่เพิ่มผ่าน QSettings (ไม่ซ้ำ · เรียงตามตัวอักษร)
    ★ 2.3.7 (review UX-30) — เดิมกล่องบอกรายชื่อจาก PROVINCE_CODE อย่างเดียว"""
    return sorted(set(PROVINCE_CODE) | set(_settings_province_codes()))


def survey_doc_url(cadastral_seq, plate_type="1"):
    """URL หน้าหลักฐานการรังวัด (evdsimgs001 id=2) จาก CADASTRAL_SEQ"""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=2&readOnly=2&dataId={cadastral_seq}&plateType={plate_type}&page=1")


def _collect_cadastral(obj, out):
    """ไล่หา record ที่มี CADASTRAL_SEQ ใน response (dict/list ซ้อนกัน)"""
    if isinstance(obj, dict):
        if obj.get("CADASTRAL_SEQ"):
            out.append(obj)
        for v in obj.values():
            _collect_cadastral(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _collect_cadastral(v, out)


def _service_reason(j):
    """★ 2.3.7 (audit C-07) — เหตุผลจากคำตอบ success:false ที่แสดงให้พนักงานได้ = เฉพาะ "ข้อความ" (str)
    ExtJS ส่ง errors เป็น dict/list ได้ ({field: ข้อความ} · [..]) ⇒ เดิม str(why) ⇒ พนักงานเห็น repr ของ Python ({'x': ...})
    ⇒ ไล่ errors → message → msg เอาข้อความข้างใน (ไม่เกิน 3 ข้อความ · 300 ตัวอักษร) · ไม่มีข้อความเลย ⇒ 'ไม่ระบุเหตุผล'
    (คำตอบทั้งก้อนยังอยู่ใน DOLServiceError.detail ⇒ Log ของ MLEP)"""
    found = []

    def _walk(v, depth=0):
        if len(found) >= 3 or depth > 3:
            return
        if isinstance(v, str):
            s = " ".join(v.split())
            if s:
                found.append(s)
        elif isinstance(v, dict):
            for x in v.values():
                _walk(x, depth + 1)
        elif isinstance(v, (list, tuple)):
            for x in v:
                _walk(x, depth + 1)
    for k in ("errors", "message", "msg"):
        _v = j.get(k) if isinstance(j, dict) else None
        if isinstance(_v, (int, float)) and not isinstance(_v, bool):
            # ★ 2.3.7 b17 (audit nit C-07) — ค่าตัวเลขตรง ๆ ({"message": 401}) = สิ่งที่ระบบตอบมา ⇒ แสดง (เดิม 'ไม่ระบุเหตุผล')
            #   ตัวเลขที่ซ้อนในโครงสร้าง ({"errors": {"code": 500, ...}}) ยังไม่แสดง (ไม่ใช่ข้อความ · ทั้งก้อนอยู่ใน detail)
            found.append(str(int(_v)) if isinstance(_v, float) and _v.is_integer() else str(_v))
        else:
            _walk(_v)
        if found:
            break
    return " · ".join(found)[:300] or "ไม่ระบุเหตุผล"


def search_cadastral(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                     province_code, office_seq, zone=47, timeout=None):
    """ค้นหลักฐานรังวัด -> list ของ record (มี CADASTRAL_SEQ); ต้อง login ก่อน
    คืน list (อาจมีหลายรายการต่อแปลง -> ให้ผู้เรียกทำ popup เลือก)"""
    s = _AUTH["session"]
    if not s:
        raise DOLAuthError("ยังไม่ได้เข้าสู่ระบบ DOL", ask_again=True)
    timeout = timeout or T_SURVEY                  # ★ 2.3.7 (review UX-22)
    sc = scale_code(scale)                         # ★ 2.3.7 (review ER-07) — ไม่รู้จัก = DOLError ก่อนยิงเน็ต (เดิมส่งค่าดิบ)
    ln = int(landno) if str(landno).strip().lstrip("-").isdigit() else landno
    crit = {
        "boxnoValue": "", "sheetcodeValue": "", "cadastralnoValue": "",
        "numofsurveyqtyValue": "", "provinceValue": _as_int(province_code, "รหัสจังหวัดของระบบ DOL"),
        "landofficeValue": str(office_seq), "amphurValue": "", "tambolValue": "",
        "surveynoValue": "", "sheettypeValue": 1, "zonelandValue": str(zone),
        "scaleValue": int(sc), "utmmap1Value": str(utmmap1), "utmmap2Value": str(utmmap2),
        "utmmap3Value": str(utmmap3), "utmmap4Value": str(utmmap4),
        "origionmap1Value": None, "origionmap2Value": None, "origionmap3Value": None,
        "airphotomapnameValue": "", "airphotomap1Value": None,
        "airphotomap2Value": None, "airphotomap3Value": None, "landnoValue": ln,
        "typeofsurveyValue": "", "titleValue": "", "surveyorfnameValue": "",
        "surveyorlnameValue": "", "surveyfdateValue": None, "surveyedateValue": None,
    }
    
    def _do_search(session):
        return session.post(EVD_CADASTRAL_URL,
                   data={"action": "load", "func": "search", "data": json.dumps([crit])},
                   headers={"X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"},
                   timeout=timeout, allow_redirects=False)

    def _parse_json(text):
        try:
            return json.loads(text)
        except ValueError:
            # ระบบของ DOL ตอบกลับเป็น ExtJS format (ไม่มีเครื่องหมายคำพูดครอบ key)
            # เช่น {success:true,results:1,data:[...]} เราต้องแก้ให้เป็น JSON ที่ถูกต้องก่อน
            fixed = re.sub(r'(^\{|,)(success|results|data|errors):', r'\1"\2":', text)
            return json.loads(fixed)

    def _classify(resp):
        """★ 2.3.7 (review ER-04) — จัดประเภทคำตอบครั้งเดียว -> ("expired", None) หรือ ("ok", json)
        เดิมทุกคำตอบที่ parse ไม่ได้ (รวมหน้า HTML ของ 5xx ตอนระบบกรมล่ม) = "token หมดอายุ" ⇒ login ใหม่ด้วยรหัสที่จำไว้
        ใน except กว้าง (เหตุจริงหาย) ⇒ ทิ้ง session ใหม่ ⇒ โชว์ HTML ดิบ + ถามรหัสซ้ำ ทั้งที่สาเหตุคือระบบกรมล่ม"""
        code = resp.status_code
        if 300 <= code < 400 or "/dolauth/login" in (resp.headers.get("Location", "") or ""):
            return "expired", None                 # ถูกส่งไปหน้า login (CAS)
        if code in (401, 403):
            return "expired", None
        body = resp.text or ""
        if code >= 500:
            raise DOLError(f"ระบบ DOL ไม่ตอบ (HTTP {code}) — ลองใหม่ภายหลัง", detail=body[:2000])
        if code >= 400:
            raise DOLError(f"ระบบ DOL ตอบผิดปกติ (HTTP {code}) — ลองใหม่ภายหลัง", detail=body[:2000])
        try:
            return "ok", _parse_json(body)
        except ValueError:
            pass
        if 'name="lt"' in body:                     # ได้หน้าฟอร์ม login ของ CAS แทนข้อมูล
            return "expired", None
        raise DOLError("รูปแบบข้อมูลจากระบบ DOL เปลี่ยน — ค้นหลักฐานการรังวัดไม่ได้ · แจ้งผู้ดูแล",
                       detail=body[:2000])

    def _search(session):
        try:
            resp = _do_search(session)
        except requests.exceptions.SSLError:
            raise DOLError(SSL_MSG)
        except requests.RequestException as e:
            raise DOLError(f"ค้นหารังวัดไม่สำเร็จ: {net_reason(e)}", detail=str(e))   # ★ 2.3.7 (ER-06) ดิบ ⇒ detail/Log
        return _classify(resp)

    kind, j = _search(s)
    if kind == "expired":
        # login ใหม่ด้วยชื่อ/รหัสที่จำไว้ในหน่วยความจำ — ★ ER-04: ไม่ครอบ except กว้างแล้ว
        #   DOLAuthError ของ login (รหัสเปลี่ยน · บัญชีถูกล็อก · ต่อไม่ได้) ถึงผู้ใช้พร้อมเหตุผลจริง
        creds = _AUTH.get("credentials")
        if not creds:
            _AUTH["session"] = None
            raise DOLAuthError("การเข้าระบบหมดอายุ — ต้องเข้าสู่ระบบใหม่", ask_again=True)     # ★ 2.3.7 (audit C-08) เดิม "token หมดอายุ"
        s = login(creds[0], creds[1])
        kind, j = _search(s)                        # session ใหม่ไม่ถูกทิ้ง เว้นแต่ยังถูกปฏิเสธซ้ำ
        if kind == "expired":
            _AUTH["session"] = None
            raise DOLAuthError("ระบบ DOL ไม่ยอมรับการเข้าสู่ระบบ แม้เพิ่งเข้าสู่ระบบใหม่ — บัญชีนี้อาจไม่มีสิทธิ์"
                               "ค้นหลักฐานการรังวัด หรือระบบ DOL ขัดข้อง (ลองใหม่ภายหลัง)")
    # ★ 2.3.7 (review DI-18) — ExtJS success:false = ทำรายการไม่สำเร็จ
    #   เดิมไม่ดูธงนี้ ⇒ ได้ [] ⇒ พนักงานเห็น "ไม่พบหลักฐานการรังวัด" ทั้งที่ระบบตอบ error
    if isinstance(j, dict) and str(j.get("success")).strip().lower() == "false":
        # ★ 2.3.7 (audit C-07) — เหตุผลเฉพาะข้อความ (ไม่ใช่ str() ของ dict/list) · ทั้งก้อนไป detail (Log)
        raise DOLServiceError(f"ระบบ DOL ตอบว่าค้นหาไม่สำเร็จ: {_service_reason(j)}", detail=str(j)[:2000])
    # อ่าน record จาก data ก่อน (ไม่เก็บ CADASTRAL_SEQ ที่โผล่ในส่วนอื่นของคำตอบ) · ไม่มี data ค่อยไล่ทั้งก้อนแบบเดิม
    recs = []
    _collect_cadastral(j["data"] if isinstance(j, dict) and "data" in j else j, recs)
    # ตัดซ้ำตาม CADASTRAL_SEQ
    seen, uniq = set(), []
    for rec in recs:
        cs = str(rec.get("CADASTRAL_SEQ"))
        if cs not in seen:
            seen.add(cs)
            uniq.append(rec)
    return uniq
