# -*- coding: utf-8 -*-
"""แก้ข้อมูลแปลง (ระวาง/เลขที่ดิน) พร้อมค้นเนื้อที่

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import re
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsExpression, QgsFeatureRequest,
                       QgsPointXY, QgsProject)
from ..core.util import (_area_num, _branch_office_of, _dol_area_diff, _dol_area_m2, _dol_doc_code, _dol_here_hint,
                         _dol_history_where, _dol_lis_hint, _dol_more_hint, _dol_via_note, _ep_hist_block_note,
                         _ep_hist_deed, _ep_hist_key, _ep_hist_ok_note, _EP_HIST_MAP_WHY, _EP_HIST_WHY, _ep_normalize,
                         _EP_SCALES, _fld_idx, _log_exc, _marker_type_from_parcel, _norm_utm, _probe_xy_24047,
                         _public_landno, _REG_COLS, _REG_IDS, _reg_txt, _reg_vals, _rngw, _txt, _TYPE_NOT_ON_MARKER,
                         _UTM_FIELD_NAMES)
from ..lock_rules import L1_TYPES, norm_type
from ..map_tools import PolygonPickTool
from ..services.workers import ParcelLookupWorker


class EditParcelMixin:
    """แก้ข้อมูลแปลง (ระวาง/เลขที่ดิน) พร้อมค้นเนื้อที่"""

    def _ep_fields(self, poly_lyr, point_lyr):
        """ชื่อคอลัมน์จริงที่ต้องใช้ -> dict หรือ None (ขาดคอลัมน์คีย์ = ทำไม่ได้)"""
        out = {"poly": {}, "point": {}}
        for tag, lyr in (("poly", poly_lyr), ("point", point_lyr)):
            fl = lyr.fields()
            for k in self._EP_KEYS:
                i = _fld_idx(fl, k)
                if i < 0:
                    return None
                out[tag][k] = fl.at(i).name()
            u = self._resolve_field(lyr, _UTM_FIELD_NAMES)
            if not u:
                return None
            out[tag]["UTM"] = u
        for k in ("AREA", "DIFF_AREA", "REGIS", "Type", "DOC_TYPE",           # ★ 2.4.3 DOC_TYPE (📝 แก้ชนิดเอกสารได้)
                  self._PN_FIELD) + _REG_COLS:                                 # ★ 2.4.5 rc2 parcel_name · ★ 2.4.8 คอลัมน์ทะเบียน 7 ตัว
            i = _fld_idx(poly_lyr.fields(), k)
            out["poly"][k] = poly_lyr.fields().at(i).name() if i >= 0 else None
        out["point"]["Type"] = self._resolve_field(point_lyr, {'type'})         # ★ 2.4.3 Type หมุดตามแปลง (ยุบ 🏷)
        return out

    def start_edit_parcel_data(self):
        ready = self._admin_ready(self._EP_TITLE)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        flds = self._ep_fields(poly_lyr, point_lyr)
        if flds is None:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ชั้นแปลงหรือชั้นหมุดไม่มีคอลัมน์ UTMMAP1-4 / UTMSCALE / LANDNO / UTM ครบ — แก้ไม่ได้")
            return
        for lyr, cols in ((poly_lyr, list(self._EP_KEYS) + ["UTM", "AREA", "DIFF_AREA", "REGIS"]),
                          (point_lyr, list(self._EP_KEYS) + ["UTM"])):
            tag = "poly" if lyr is poly_lyr else "point"
            for c in cols:
                name = flds[tag].get(c)
                if name and not self._need_column_or_warn(lyr, name, self._EP_TITLE):
                    return
        self.cancel_transform()
        self._dol_clear_highlight()
        self._editparcel_lids = (poly_lyr.id(), point_lyr.id())
        canvas = self.iface.mapCanvas()
        self.temp_tool = PolygonPickTool(
            canvas, poly_lyr, self._edit_parcel_picked, self._dol_on_hover,
            msg_title=self._EP_TITLE, choose_prompt="เลือกแปลงที่ต้องการแก้ไขข้อมูล:")
        canvas.setMapTool(self.temp_tool)
        self.temp_tool.push_hint(                                       # ★ 2.3.7 (UX-01) ข้อความของเครื่องมือ
            self._EP_TITLE, f"คลิกแปลงใน '{poly_lyr.name()}' ที่ต้องการแก้ระวาง/มาตราส่วน/เลขที่ดิน • Esc = ยกเลิก",
            level=0, duration=10)

    def _ep_ready_again(self, layer=None):
        """ด่านซ้ำหลังคลิก/หลังรอระบบกรม: ยังเป็นผู้ดูแล + คู่ชั้นเดิมกับตอนกดปุ่ม -> (poly, point) หรือ None"""
        ready = self._admin_ready(self._EP_TITLE)
        if not ready:
            return None
        poly_lyr, point_lyr = ready
        if getattr(self, "_editparcel_lids", None) != (poly_lyr.id(), point_lyr.id()) or \
                (layer is not None and layer.id() != poly_lyr.id()):
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม (หรือแปลงที่คลิกอยู่คนละชั้น) — ยกเลิก\n"
                      "กดปุ่ม 📝 แก้ไขข้อมูลรูปแปลง ใหม่อีกครั้ง")
            return None
        return poly_lyr, point_lyr

    def _edit_parcel_picked(self, feat, layer):
        self.iface.actionSelect().trigger()
        self._dol_clear_highlight()
        ready = self._ep_ready_again(layer)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        try:
            feat = poly_lyr.getFeature(feat.id())
        except Exception:
            pass
        if feat is None or not feat.isValid():
            return
        flds = self._ep_fields(poly_lyr, point_lyr)
        if flds is None:
            return
        cur_type = _txt(feat[flds["poly"]["Type"]]).upper() if flds["poly"]["Type"] else ""
        if cur_type in ("L1-RTK", "L1-TS", "CT-RTK") and not self._l1_unlocked():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"แปลงนี้เป็น {cur_type} (ชั้นอ้างอิงพิกัดหลัก)\nต้องกดปุ่ม 🔓 ปลดล็อก L1 ก่อน จึงจะแก้ข้อมูลได้")
            return
        newv = self._ep_dialog(poly_lyr, feat, flds)
        if newv is None:
            return
        # ★ 2.4.3 rc2 (เจ้าของงาน 22 ต.ค. 69) เลขที่ดิน 0 = ที่สาธารณะ ⇒ คิดเลขที่ว่างของระวางใหม่จากข้อมูลตอนกด OK
        #   (กล่องเปิดค้างได้ · ทางเรียกตรงส่ง '0' มาตรง ๆ) — เดิมใช้ 0 ตรง ๆ ⇒ ซ้ำแปลงที่สาธารณะเลข 0 ⇒ กล่องแปลงแฝด E1
        _pub_note = None
        if newv.get("_pub0") or _txt(newv.get("LANDNO")) == "0":
            _df = flds["poly"].get("DOC_TYPE")      # ★ 2.4.7 ชนิดหลังแก้ (หมายเหตุของเอกสารกลุ่ม ข)
            _fd = _txt(newv.get("_doc")) if newv.get("_doc") is not None else (_txt(feat[_df]) if _df else "")
            newv, _pub_note = self._ep_public_landno(poly_lyr, point_lyr, feat, flds, dict(newv, LANDNO="0"),
                                                     what=_fd if _fd in self._DOC_NOKEY else None)
        # ★ 2.4.3 (ยุบ 🏷 · ด่านโฉนด) — แยกว่าเปลี่ยนอะไร · สิทธิ์คอลัมน์ Type/DOC_TYPE ตรวจเฉพาะที่เปลี่ยนจริง
        #   (ตรวจตอนกดปุ่มจะกันผู้ดูแลที่ไม่มีสิทธิ์คอลัมน์นั้นจากงานแก้คีย์)
        ch = self._ep_changes(feat, flds, newv)
        # ★ 2.4.6 ผลค้นในกล่องของคีย์นี้ (🔍) ⇒ ใช้ต่อ (ไม่ถามระบบกรมซ้ำ) และทุกการแก้ไปทางเต็ม (เขียน AREA/REGIS ตามผลค้นด้วย)
        _lk = newv.get("_lk")
        # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 2) ผลค้นในกล่องเป็นของชนิดเอกสารตอนค้นด้วย — ทางเรียกตรงที่ชนิดเปลี่ยนแล้วไม่ใช้ (กล่องทิ้งให้อยู่แล้ว)
        _df0 = flds["poly"].get("DOC_TYPE")
        _fdoc = _txt(newv.get("_doc")) or (_txt(feat[_df0]) if _df0 else "")
        _lk_ok = (bool(_lk) and _txt(_lk.get("utm")) == _txt(newv.get("UTM"))
                  and (_lk.get("doc") is None or not self._lk_doc_moved(_lk.get("doc"), _fdoc)))
        if ch["nokey"]:
            # ★ 2.4.7 คีย์กลุ่ม ข — เลขบวกใหม่ของเอกสารที่ทะเบียนไม่มีระวาง UTM ⇒ บอกก่อนถามระบบกรม (ทางเรียกตรงด้วย · กล่องกันไว้แล้ว)
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"แก้ไม่ได้ — {ch['nokey']} ไม่มีเลขที่ดินบนระวาง UTM · พิมพ์เลขที่ดิน 0 แล้วปลั๊กอินจะคิดเลขที่ว่างให้เอง (0, -1, -2, …)\n"
                      "(ยังไม่ได้แก้อะไร)")
            return
        if ch["deed"] and _public_landno(newv.get("LANDNO")):
            # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪8) ที่สาธารณะ (เลขที่ดิน ≤ 0) เป็นโฉนดที่ดินไม่ได้ — บอกก่อนถามระบบกรม
            _cd1 = _txt(feat[_df0]) if _df0 else ""             # ★ 2.4.8 (ผลตรวจ Windows 2.4.7 rc1 ⚪1) ชนิดเดิมกลุ่ม ข
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      (f"แก้ไม่ได้ — เลขที่ดิน ≤ 0 เป็นคีย์ที่ปลั๊กอินตั้งให้ของ {_cd1} เป็นโฉนดที่ดินไม่ได้ · "
                       "พิมพ์เลขที่ดินของโฉนด (เลขบวก) แล้วค้นทะเบียน\n" if _cd1 in self._DOC_NOKEY else
                       "แก้ไม่ได้ — เลขที่ดิน ≤ 0 = ที่สาธารณะ เป็นโฉนดที่ดินไม่ได้ · เลือกชนิดเอกสารให้ตรง (เช่น ที่สาธารณประโยชน์)\n")
                      + "(ยังไม่ได้แก้อะไร)")
            return
        # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "fix dropdown type ไว้เลย" · "Doc_type ด้วย") ค่าใหม่ต้องอยู่ในรายการตายตัว (ทางเรียกตรง ·
        #   ชนิดเอกสาร: ล้างค่าที่มีเป็นว่างไม่ได้ — คำตัดสิน 21 ต.ค.)
        if (ch["type"] and ch["type"][1] not in self._CP_TYPES_ALL) or (ch["doc"] and ch["doc"][1] not in self._CP_DOC_CODES):
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      ("Type" if ch["type"] and ch["type"][1] not in self._CP_TYPES_ALL else "ชนิดเอกสารสิทธิ์")
                      + " ที่เลือกไม่อยู่ในรายการที่ใช้ได้ (ชนิดเอกสารล้างเป็นว่างไม่ได้) — ยกเลิก (ยังไม่ได้แก้อะไร)")
            return
        # ★ 2.4.6 ไม่มีช่องติ๊กปรับ Type หมุดแล้ว — สิทธิ์คอลัมน์ Type ของหมุดที่ต้องปรับตามแปลง ตรวจใน _ep_type_ok (เฉพาะเมื่อมีหมุดต้องปรับ)
        _need = ((ch["type"], poly_lyr, flds["poly"].get("Type")),
                 (ch["type"], point_lyr, flds["point"].get("Type")),
                 (ch["doc"], poly_lyr, flds["poly"].get("DOC_TYPE")),
                 (ch["pname"], poly_lyr, flds["poly"].get(self._PN_FIELD)))          # ★ 2.4.5 rc2
        for need, lyr, col in _need:
            if need and col and not self._need_column_or_warn(lyr, col, self._EP_TITLE):
                return
        # ★ 2.4.3 (review 🟡2) — ช่องคีย์ที่ต่างแค่รูปแบบ (เช่น ระวาง 'IV' → '4' · LANDNO '0435') ไม่ใช่ "แก้แค่ Type":
        #   กล่องบอกว่าจะแก้ช่องให้ตรง UTM + ดึงเนื้อที่ทะเบียนใหม่ ⇒ ไปทางแก้ข้อมูลเต็ม (ช่องคีย์ + Type ลงคำสั่งเดียว)
        #   เดิมเข้าทาง 🏷 ⇒ ช่องที่กล่องบอกว่าจะแก้ไม่ถูกแก้ และไม่ได้ดึงเนื้อที่
        _fmt = any(_txt(feat[flds["poly"][k]]) != newv[k] for k in self._EP_KEYS + ("UTM",))
        if not ch["key"] and not _fmt and not ch["doc"] and not ch["pname"] and ch["type"] and not _lk_ok:
            # เปลี่ยนแค่ Type (คีย์/ชนิดเอกสารเดิม) ⇒ ทาง 🏷 เดิมทั้งชุด (ด่าน L1/แฝด/หมุดล็อก · กล่องยืนยัน · คำสั่งเดียว · Move_Log
            #   'retyped' · ปรับ Type หมุดให้ตรงแปลง) · ไม่ถามระบบกรม (คำตัดสิน 21 ต.ค.: ด่านโฉนดเฉพาะเปลี่ยนคีย์/ชนิดเอกสาร)
            #   ★ 2.4.6 ค้นในกล่องแล้ว ⇒ ทางเต็ม (เขียน AREA/REGIS ตามผลค้นพร้อม Type) · ไม่เปลี่ยนอะไร ⇒ ทางเต็ม (ดึงเนื้อที่ใหม่ +
            #   ปรับ Type หมุดให้ตรงแปลง — เดิมต้องติ๊กช่อง ⇒ ทาง 🏷)
            self._change_type_execute(poly_lyr, point_lyr, feat, preset=ch["type"][1])
            return
        plan = self._ep_plan(poly_lyr, point_lyr, feat, flds, newv)
        if plan is None:
            return
        plan["ch"] = ch
        plan["pub_note"] = _pub_note             # ★ rc2 กล่องยืนยันบอกเลขที่คิดให้ (notes ถูกคำนวณใหม่หลังรอ)
        plan["lk"] = _lk if _lk_ok else None     # ★ 2.4.6 _ep_lookup ใช้ผลค้นในกล่อง
        if ch["deed"]:
            # ★ 2.4.3 ด่านโฉนดที่ดิน — คีย์ต้องไม่ซ้ำ: บล็อก (ไม่ใช่กล่องเตือน E1 ที่ตอบ Yes ผ่านได้) · หมุดค้างคีย์นี้ก็นับ
            why = self._ep_deed_dup(poly_lyr, point_lyr, feat, flds, newv, plan)
            if why:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          f"แก้ไม่ได้ — โฉนดที่ดินต้องมีคีย์ไม่ซ้ำ\n{why}\n(ยังไม่ได้แก้อะไร)")
                return
        elif ch["public"]:
            # ★ 2.4.3 rc2 ที่สาธารณะคีย์ซ้ำ ⇒ บล็อก (ไม่ใช่กล่องแปลงแฝด E1 · ฐานมี unique index) — เลขที่คิดให้เองไม่ซ้ำอยู่แล้ว
            #   (ด่านนี้จับเลขติดลบที่พิมพ์เอง) · คีย์ที่ไม่ใช่ที่สาธารณะ = กล่องเตือน E1 เดิม
            if self._ep_public_dup_block(poly_lyr, point_lyr, feat, flds, newv, plan):
                return
        elif plan["dup"] and not self._ep_dup_confirm(plan):     # ★ 2.4.2 เตือนก่อนไปถามระบบกรม (ตอบ No = จบ ไม่เสียเวลารอ)
            return
        if not self._ep_type_ok(poly_lyr, point_lyr, feat, plan, sync=False):     # ★ 2.4.6 ชุดหมุดที่ต้องปรับคิดหลังรอระบบกรม
            return
        _dfn = flds["poly"].get("DOC_TYPE")
        if (ch["doc"][1] if ch["doc"] else (_txt(feat[_dfn]) if _dfn else "")) in self._DOC_NOKEY:
            # ★ 2.4.8 ขั้น E กลุ่ม ข — ทะเบียนค้นด้วยเลขที่เอกสาร (🔍 ในกล่อง) ไม่ใช่คีย์ ⇒ มีผลค้นในกล่องของค่านี้ = ใช้ผลนั้น ·
            #   ไม่มี = ไม่ถามระบบกรม (ค้นด้วยคีย์ ⇒ เจอโฉนดที่คีย์ตรงกัน = ผลผิดแปลง · แบบ 🟡2 ของ ท.ค.)
            if _lk_ok and (_lk or {}).get("q") is not None:
                self._ep_lookup(plan)
            else:
                self._ep_after_lookup(dict(plan, skip_dol="nokey"), None, None)       # ★ ข้อความบอกให้ค้นด้วยเลขที่ (ไม่เรียกที่สาธารณะ)
            return
        _dfa = flds["poly"].get("DOC_TYPE")
        if (ch["doc"][1] if ch["doc"] else (_txt(feat[_dfa]) if _dfa else "")) in self._DOC_LIKE_PUB:
            # ★ 2.4.7 rc2 (ผลตรวจ Windows rc1 🟡2 · เจ้าของงาน 26 ต.ค. 69 20:1x "ทำ rc2 แก้ 🟡1 + 🟡2") — ท.ค./อื่นๆ = แบบที่สาธารณะ
            #   (17:2x–17:3x) ⇒ ไม่ถามระบบกรมทุกเลข · เนื้อที่/REGIS คงเดิม (เดิมเลขบวกยังถาม ⇒ ได้ REGIS/AREA ของโฉนดที่คีย์ตรงกัน) ·
            #   ผลค้นในกล่องก็ไม่ใช้ (ปุ่ม 🔍 ปิดสำหรับชนิดนี้แล้ว) · ★ 2.4.8 rc2 ตรวจก่อนทางที่สาธารณะ (เลข ≤ 0 ของ ท.ค./อื่นๆ เดิมได้
            #   หมายเหตุ "ที่สาธารณะ" · ⚪D เปลี่ยนเป็นชนิดนี้ ⇒ REGIS 'ไม่มีทะเบียน' + ล้าง AREA/DIFF ใน _ep_after_lookup)
            self._ep_after_lookup(dict(plan, skip_dol="likepub"), None, None)
            return
        if _public_landno(newv.get("LANDNO")):
            # ★ 2.4.3 rc2 ที่สาธารณะไม่มีทะเบียนให้ค้น (แบบ ➕ 🔍) ⇒ ไม่ถามระบบกรม (เดิมถามด้วยเลข 0/ติดลบ ⇒ ไม่พบ · อาจเด้งกล่องเข้าสู่ระบบ iLands)
            self._ep_after_lookup(dict(plan, skip_dol="public"), None, None)
            return
        # ★ 2.4.9 (แผน 2.4.9 ข้อ 2.3) เปลี่ยนเป็น น.ส.ล. ⇒ ถามระบบกรมเสมอ (ด่านใน _ep_apply: ทะเบียนต้องเป็น น.ส.ล.) — เดิมคีย์เดิม = ไม่ถาม
        #   ⇒ โฉนดที่เปลี่ยนเป็น น.ส.ล. ยังถือ REGIS 'มีทะเบียน' + AREA ของโฉนด (เคส gid 92903)
        _to_nsl = bool(ch["doc"]) and _txt(ch["doc"][1]) == "น.ส.ล."
        if not ch["key"] and not ch["deed"] and (ch["doc"] or ch["pname"]) and not _lk_ok and not _to_nsl:
            # ★ 2.4.3 เปลี่ยนชนิดเอกสาร (ไม่ใช่เป็นโฉนด) ± Type · คีย์เดิม ⇒ ไม่ต้องถามระบบกรม (ด่านซ้ำใน _ep_after_lookup ยังทำครบ)
            #   ★ 2.4.5 rc2 แก้แค่ชื่อทางสาธารณะ ก็ไม่ถามระบบกรมเช่นกัน · ★ 2.4.6 ค้นในกล่องแล้ว ⇒ ใช้ผลค้น (ทาง _ep_lookup)
            self._ep_after_lookup(dict(plan, skip_dol=True), None, None)
            return
        self._ep_lookup(plan)

    def _ep_dialog(self, poly_lyr, feat, flds):
        """กล่องกรอก UTMMAP1-4 · UTMSCALE · LANDNO (ค่าเดิมเติมไว้) -> dict ค่าที่จัดรูปแล้ว หรือ None
        ★ 2.4.6 (เจ้าของงาน 26 ต.ค. 69 "ปุ่มแก้ไขข้อมูลอยากให้กดค้นหาทะเบียนได้ก่อน เหมือนปุ่มสร้างรูปแปลงด้วย" · "ให้ทำเป็นปุ่มสร้างเลยก็ได้
          แค่ไม่ต้องกดสร้างรูปแปลงก่อน และให้คิดค่า diff แสดงให้เห็นด้วย ส่วนช่องติ๊กเปลี่ยน type หมุดตาม ให้เอาออก บังคับให้เปลี่ยนตาม
          type แปลงไปเลย") — กล่องแบบ ➕: 🔍 ค้นทะเบียนในกล่อง · REGIS ล็อก (ค่าที่จะเขียนตามผลค้น) · ชนิดเอกสารล็อกเมื่อทะเบียนบอกโฉนด ·
          AREA/DIFF · ไม่มีช่องติ๊กปรับ Type หมุด (หมุดตาม Type แปลงเสมอ — _ep_type_ok) · ค้นแล้วกด OK ⇒ _lk = ผลค้นของคีย์นี้
          (_ep_lookup ใช้ต่อ ไม่ถามระบบกรมซ้ำ) · ไม่ได้ค้น ⇒ ค้นหลังกด OK แบบเดิม"""
        import html as _html
        cur = {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS}
        old_utm = _txt(feat[flds["poly"]["UTM"]])
        # ★ 2.4.7 rc2 (ผลตรวจ Windows rc1 🟡1) — ช่องคีย์เดิมที่จัดรูปแล้ว: ด่านเลขบวกของกลุ่ม ข เทียบช่องคีย์ ไม่ใช่สตริง UTM ในฐาน
        #   (UTM ว่าง/ไม่ตรงช่องคีย์ ⇒ แปลงเลขบวกเดิมแก้แค่ Type ไม่ได้) · จัดรูปไม่ได้ = None (นับว่าคีย์เปลี่ยน) ·
        #   ★ 2.4.8 แปลง น.ส.3 ก จัดรูปแบบระวางรูปถ่ายก่อน (ไม่ได้ ⇒ แบบ UTM เดิม — แบบ _ep_changes)
        _air_c = (_txt(feat[flds["poly"]["DOC_TYPE"]]) if flds["poly"].get("DOC_TYPE") else "") == self._DOC_AIR
        _vo0, _eo0 = _ep_normalize(cur["UTMMAP1"], cur["UTMMAP2"], cur["UTMMAP3"], cur["UTMMAP4"], cur["UTMSCALE"], cur["LANDNO"],
                                   public_neg=True, airphoto=_air_c)
        if _eo0 and _air_c:
            _vo0, _eo0 = _ep_normalize(cur["UTMMAP1"], cur["UTMMAP2"], cur["UTMMAP3"], cur["UTMMAP4"], cur["UTMSCALE"], cur["LANDNO"],
                                       public_neg=True)
        _old_key = None if _eo0 else tuple(_vo0[k] for k in self._EP_KEYS)
        # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 ⚪1) แปลง น.ส.3 ก ที่คีย์เดิมเป็นแบบระวาง UTM (ข้อมูลเก่า · ฐานจริง 0 แปลง) — ช่องคีย์ถูกแปลงเป็นแบบ
        #   ระวางรูปถ่ายเอง (UTMMAP3 ทิ้ง · มาตราส่วน 5000) ⇒ เดิมกล่องเสนอคีย์ไร้ความหมาย ("5137 3 -000 · 1:5000") และ 🔍 ค้างด้วยคีย์นี้
        _air_legacy = _air_c and _old_key is not None and bool(_vo0.get("UTMMAP3"))
        # ★ 2.4.3 rc2 ชั้นหมุดของปุ่มนี้ (คู่ชั้นตอนกดปุ่ม — `_ep_ready_again` ตรวจแล้ว) ใช้คิดเลขที่สาธารณะ · หาไม่ได้ = นับเฉพาะแปลง
        _pid = (getattr(self, "_editparcel_lids", None) or (None, None))[1]
        point_lyr = QgsProject.instance().mapLayer(_pid) if _pid else None
        # ★ 2.4.6 เนื้อที่รูป + AREA/REGIS เดิม · DIFF คิดจากรูปตอนนี้ (สูตรเดียวกับค่าที่เขียน — _dol_area_diff)
        try:
            ga = self._geom_area_m2(poly_lyr, feat.geometry()) if feat.hasGeometry() else None
        except Exception:
            ga = None
        af, rf = flds["poly"].get("AREA"), flds["poly"].get("REGIS")
        cur_area = _area_num(feat[af]) if af else None
        cur_regis = _txt(feat[rf]) if rf else ""
        _dff = flds["poly"].get("DIFF_AREA")
        cur_diff = _area_num(feat[_dff]) if _dff else None      # ★ 2.4.8 rc2 ⚪D ค่าที่จะล้างเมื่อเปลี่ยนเป็น ท.ค./อื่นๆ
        _d0 = _dol_area_diff(ga, cur_area)
        d = QtWidgets.QDialog(self.iface.mainWindow())
        d.setWindowTitle("📝 " + self._EP_TITLE)
        lay = QtWidgets.QVBoxLayout(d)
        lay.addWidget(QtWidgets.QLabel(f"แปลง gid {feat.id()} · UTM เดิม {old_utm or '(ว่าง)'}"))
        if ga is not None:
            _hd = QtWidgets.QLabel(f"เนื้อที่รูป {ga:,.2f} ตร.ม. ({_rngw(ga)} ไร่-งาน-วา) · AREA เดิม "
                                   + (f"{cur_area:,.2f} ตร.ม." if cur_area is not None else "(ว่าง)")
                                   + " · DIFF " + (f"{_d0:+.2f}%" if _d0 is not None else "-")
                                   + (f" · REGIS {cur_regis}" if cur_regis else ""))
            _hd.setTextFormat(QtCore.Qt.PlainText)
            _hd.setWordWrap(True)                     # ★ 2.4.9 ข้อ 2.4
            lay.addWidget(_hd)
        form = QtWidgets.QFormLayout()
        eds = {}
        _air0 = (_txt(feat[flds["poly"]["DOC_TYPE"]]) if flds["poly"].get("DOC_TYPE") else "") == self._DOC_AIR
        for k, mx in (("UTMMAP1", 4), ("UTMMAP2", 3), ("UTMMAP3", 4), ("UTMMAP4", 3 if _air0 else 2)):
            # ★ 2.4.8 แปลง น.ส.3 ก = แผ่นที่ระวางรูปถ่าย 3 หลัก ⇒ ตั้งความยาวก่อนใส่ค่า (setMaxLength หลังใส่จะตัด '001' เหลือ '00')
            ed = QtWidgets.QLineEdit()
            ed.setMaxLength(mx)
            ed.setText(cur[k])
            eds[k] = ed
            form.addRow(k, ed)
        cb = QtWidgets.QComboBox()
        cb.addItems(list(_EP_SCALES))
        if cur["UTMSCALE"] in _EP_SCALES:
            cb.setCurrentIndex(_EP_SCALES.index(cur["UTMSCALE"]))
        else:
            cb.insertItem(0, cur["UTMSCALE"] or "(ว่าง)")
            cb.setCurrentIndex(0)
        form.addRow("UTMSCALE", cb)
        ed_ln = QtWidgets.QLineEdit(cur["LANDNO"])
        ed_ln.setMaxLength(7)
        ed_ln.setPlaceholderText("เลขที่ดิน (0 = คิดเลขให้เอง: ที่สาธารณะ · น.ส.3 ฯลฯ)")       # ★ 2.4.3 rc2 แบบ ➕ · ★ 2.4.7 คีย์กลุ่ม ข
        form.addRow("LANDNO", ed_ln)
        # ★ 2.4.8 ขั้น E กลุ่ม ข — แถวค้นด้วยเลขที่เอกสาร · หมู่ · ตำบล (แสดงเฉพาะ น.ส.3 · ใบจอง · ส.ค.1) · เติมจากคอลัมน์ทะเบียนของแปลง
        #   เฉพาะแปลงที่เดิมเป็นกลุ่ม ข (แปลงโฉนดที่เปลี่ยนชนิด ⇒ เลขในฐานเป็นเลขโฉนด ไม่ใช่เลขของเอกสารใหม่)
        _cd0 = _txt(feat[flds["poly"]["DOC_TYPE"]]) if flds["poly"].get("DOC_TYPE") else ""
        dq = self._dq_widgets({k: (_txt(feat[flds["poly"][c]]) if flds["poly"].get(c) and _cd0 in self._DOC_NOKEY else "")
                               for k, c in (("no", "PARCEL_NO"), ("moo", "MOO"), ("tb", "TAMBOL"), ("am", "AMPHUR"))},
                              office=_branch_office_of(poly_lyr))       # ★ 2.4.8 อำเภอ/ตำบลเป็นกล่องเลือกตามสำนักงานของชั้น
        form.addRow(dq["lbl"], dq["w"])
        # ★ 2.4.6 ปุ่มค้นทะเบียนในกล่อง (แบบ ➕ · ไม่บังคับ — ไม่ได้ค้น ⇒ ค้นหลังกด OK เมื่อการแก้ต้องถามระบบกรม)
        btn_lk = QtWidgets.QPushButton("🔍 ค้นทะเบียนจากระบบกรม")
        lk_idle = "ยังไม่ได้ค้น — กดปุ่มเพื่อดูเนื้อที่/สถานะทะเบียนก่อนแก้ (ไม่บังคับ — ไม่ได้ค้น โปรแกรมค้นให้หลังกด OK)"
        lk_lbl = QtWidgets.QLabel(lk_idle)
        lk_lbl.setWordWrap(True)
        lk_lbl.setTextFormat(QtCore.Qt.PlainText)        # ค่าจากระบบกรม (เลขโฉนด/เนื้อที่) ⇒ ข้อความล้วน (แบบ ➕ · audit A3-07)
        form.addRow(btn_lk, lk_lbl)
        # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "ยุบปุ่มเปลี่ยน type ไปรวมกับปุ่มแก้ไขข้อมูล และให้แก้ doc type ได้ด้วย")
        #   Type = เลือกจากรายการเท่านั้น (ไม่มี CT-RTK · ค่าเดิมนอกรายการ = ตัวเลือก "(เดิม) X" ที่เลือกแล้วไม่เปลี่ยน)
        tf, docf = flds["poly"].get("Type"), flds["poly"].get("DOC_TYPE")
        cur_tp, cur_doc = (_txt(feat[tf]) if tf else ""), (_txt(feat[docf]) if docf else "")
        cb_tp = QtWidgets.QComboBox()
        if not cur_tp:
            cb_tp.addItem(self.TYPE_KEEP, "")
        for t in self._ep_type_choices(poly_lyr, tf):
            cb_tp.addItem(t, t)
        if cur_tp and cb_tp.findData(cur_tp) < 0:
            cb_tp.insertItem(0, f"(เดิม) {cur_tp}", cur_tp)
        cb_tp.setCurrentIndex(max(0, cb_tp.findData(cur_tp)))
        if not tf:
            cb_tp.setEnabled(False)
            cb_tp.setToolTip("ชั้นแปลงนี้ไม่มีคอลัมน์ Type")
        form.addRow("ประเภทแปลง (Type)", cb_tp)
        # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "Doc_type ด้วย" · คำตัดสิน: ล้างเป็นว่างไม่ได้) — 13 ค่าของตาราง doc_type_codes เท่านั้น ·
        #   "(ว่าง — ไม่เปลี่ยน)" มีเฉพาะแปลงที่ชนิดเอกสารว่างอยู่ (คงว่างได้) · ค่าเดิมนอกรายการ = "(เดิม) X" (ไม่เปลี่ยน)
        cb_doc = QtWidgets.QComboBox()
        if not cur_doc:
            cb_doc.addItem(self.DOC_KEEP, "")
        for c in self._CP_DOC_CODES:
            cb_doc.addItem(c, c)
        if cur_doc and cb_doc.findData(cur_doc) < 0:
            cb_doc.insertItem(0, f"(เดิม) {cur_doc}", cur_doc)
        cb_doc.setCurrentIndex(max(0, cb_doc.findData(cur_doc)))
        if not docf:
            cb_doc.setEnabled(False)
            cb_doc.setToolTip("ชั้นแปลงนี้ไม่มีคอลัมน์ DOC_TYPE")
        # ★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 21:4x "ปุ่มแก้ไขด้วย" — ชนิดเอกสารขึ้นบนสุดแบบ ➕) · ลำดับ Tab ตั้งหลังใส่ฟอร์มลงกล่อง
        form.insertRow(0, "ชนิดเอกสารสิทธิ์", cb_doc)
        # ★ 2.4.5 rc2 (เจ้าของงาน 23–24 ต.ค. 69) parcel_name — แก้/ล้างได้เมื่อชนิดเอกสารหลังแก้เปิดช่อง · เปลี่ยนชนิดเอกสารเป็นชนิดที่ปิดช่อง
        #   ⇒ ล้างชื่อ (บอกในกล่องนี้ + กล่องยืนยัน) · ชนิดเดิมที่ปิดช่อง ⇒ ชื่อเดิมคงไว้ (ไม่ล้างเงียบ)
        #   ★ 2.4.7 เปิดเฉพาะชนิดสาธารณะ (_pn_open · เท่า 2.4.5 · 2.4.6 เปิดทุกชนิดยกเว้นโฉนดที่ดิน) · รายการแนะนำแยกตามชนิด (2.4.6 rc2)
        pnf = flds["poly"].get(self._PN_FIELD)
        cur_pn = _txt(feat[pnf]) if pnf else ""
        cb_pn = QtWidgets.QComboBox()
        cb_pn.setEditable(True)
        cb_pn.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        cb_pn.lineEdit().setMaxLength(self._PN_MAX)
        pn_have = {}                                  # ★ 2.4.6 rc2 (🟡1) {ชนิดสาธารณะ: ชื่อที่มีในชั้นของชนิดนั้น}
        if pnf:
            pn_have = self._pn_have_by_doc(poly_lyr)
        else:
            cb_pn.setToolTip("ชั้นแปลงนี้ยังไม่มีคอลัมน์ parcel_name")
        cb_pn.setEditText(cur_pn)
        pn_lbl = QtWidgets.QLabel(self._pn_label(cur_doc))
        form.addRow(pn_lbl, cb_pn)
        # ★ 2.4.6 REGIS แบบ ➕ — ช่องล็อก แสดงค่าที่จะเขียน (เดิม · ผลค้นของคีย์นี้)
        cb_rg = QtWidgets.QComboBox()
        for r in self._CP_REGIS:
            cb_rg.addItem(r or "(ว่าง)", r)
        if cb_rg.findData(cur_regis) < 0:
            cb_rg.insertItem(0, f"(เดิม) {cur_regis}", cur_regis)
        cb_rg.setCurrentIndex(max(0, cb_rg.findData(cur_regis)))
        cb_rg.setEnabled(False)
        cb_rg.setToolTip("ตั้งตามผลค้นทะเบียน (🔍 หรือหลังกด OK) — ไม่ได้ค้น/ไม่พบ = คงเดิม" if rf else "ชั้นแปลงนี้ไม่มีคอลัมน์ REGIS")
        form.addRow("สถานะทะเบียน (REGIS)", cb_rg)
        lay.addLayout(form)
        # ★ 2.4.8 ลำดับ Tab ตามแถวบนจอ (ชนิดเอกสารก่อน · แบบ ➕)
        _tab = ([cb_doc] + [eds[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4")]
                + [cb, ed_ln, dq["no"], dq["moo"], dq["am"], dq["tb"], btn_lk, cb_tp, cb_pn, cb_rg])
        for _a, _b in zip(_tab, _tab[1:]):
            QtWidgets.QWidget.setTabOrder(_a, _b)
        prev = QtWidgets.QLabel()
        prev.setWordWrap(True)
        lay.addWidget(prev)
        # ★ 2.4.9 (แผน 2.4.9 ข้อ 2.4 · เจ้าของงาน 27 ต.ค. 69 "แก้หน้าต่างแก้ไข ใหญ่เกินไป") ป้ายหมายเหตุตัดบรรทัด — เดิมบรรทัดยาวสุด
        #   กำหนดความกว้างทั้งกล่อง (~1,350 px)
        _ft = QtWidgets.QLabel(
            "🔍 ค้นทะเบียนก่อนได้ — ค้นแล้วกด OK ใช้ผลนั้นเลย · ไม่ได้ค้น: กด OK แล้วโปรแกรมจะดึงเนื้อที่ทะเบียนจากระบบกรมให้ "
            "แล้วขึ้นกล่องยืนยันอีกครั้งก่อนแก้\n"
            "(เปลี่ยนแค่ Type/ชนิดเอกสารที่ไม่ใช่โฉนดที่ดิน/ชื่อทางสาธารณะ ไม่ต้องถามระบบกรม · โฉนดที่ดินที่เปลี่ยนคีย์/ชนิดเอกสาร "
            "ต้องคีย์ไม่ซ้ำและได้เนื้อที่ทะเบียนก่อนจึงจะแก้ได้)\n"
            "หมุดของแปลงปรับ Type ให้ตรงแปลงทุกครั้ง · ที่สาธารณะ · ท.ค. · อื่นๆ และเอกสารที่ทะเบียนไม่มีระวาง UTM (น.ส.3 · ใบจอง · ส.ค.1) "
            "ปลั๊กอินตั้งคีย์ให้ (ช่องคีย์แก้ไม่ได้ · เลขที่ดิน ≤ 0 ตัวที่ว่างของระวาง: 0, -1, -2, …) ไม่ถามระบบกรม")
        _ft.setWordWrap(True)
        lay.addWidget(_ft)
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        bb.button(QtWidgets.QDialogButtonBox.Ok).setText("แก้ไขข้อมูล")
        lay.addWidget(bb)
        res = {}
        _used = {}                       # ★ 2.4.3 rc2 เลข ≤ 0 ที่มีแปลง/หมุดใช้ ต่อระวาง (ถามชั้นครั้งเดียวต่อระวางต่อกล่อง)
        # ★ 2.4.6 lk = ผลค้นในกล่อง {utm, res, err, ar} (ของคีย์ utm เท่านั้น) · busy = กำลังค้น · doc_lock = ชนิดเอกสารล็อกตามผลทะเบียน
        #   pn_doc = ชนิดของรายการแนะนำ parcel_name ตอนนี้ (None = ช่องปิด · 2.4.5 rc2 _pn_st)
        #   ★ (ตรวจอิสระ ⚪2) lk['final'] = ผลที่ตัดสินได้ (ค้นไม่สำเร็จ/ยังไม่ได้ค้นทะเบียน iLands = ไม่ใช่ ⇒ ไม่ใช้ต่อ · ค้นใหม่หลัง OK)
        #   ★ (ตรวจอิสระ ⚪3) doc_back/doc_set = ชนิดเอกสารก่อน/หลังผลค้นเติมให้ (ผลถูกทิ้ง ⇒ คืนค่าเดิม ถ้ายังเป็นค่าที่ผลค้นเติม)
        st = {"lk": None, "busy": False, "doc_lock": False, "pn_doc": "", "gate": "", "doc_back": None, "doc_set": None}

        def _pn_sync(doc_eff):
            on = bool(pnf) and self._pn_open(doc_eff)
            _k = doc_eff if on else ("ปิด", bool(_txt(doc_eff)))     # (ตรวจอิสระ ⚪6) ยังไม่เลือกชนิด/ชนิดที่ปิดช่อง ⇒ ข้อความจางต่างกัน
            if st["pn_doc"] == _k:
                return
            t = cb_pn.currentText()
            cb_pn.blockSignals(True)
            try:
                cb_pn.clear()
                if on:
                    sug = list(self._PN_SUGGEST[_txt(doc_eff)])
                    cb_pn.addItem("")
                    cb_pn.addItems(sug + [x for x in pn_have.get(_txt(doc_eff), []) if x not in sug])
                cb_pn.setEditText(t)
            finally:
                cb_pn.blockSignals(False)
            cb_pn.setEnabled(on)
            st["pn_doc"] = _k
            pn_lbl.setText(self._pn_label(doc_eff))
            cb_pn.lineEdit().setPlaceholderText(
                ("ไม่บังคับ — ชื่อเรียกของแปลง" if _txt(doc_eff) in self._DOC_LIKE_PUB else
                 "ไม่บังคับ — เลือกแล้วพิมพ์ต่อได้ เช่น ลำรางสาธารณะบ้านหนองแค") if on else
                "ชั้นแปลงนี้ยังไม่มีคอลัมน์ parcel_name" if not pnf else
                "เฉพาะทางสาธารณประโยชน์ (ทางน้ำ/ทางบก) · ที่สาธารณประโยชน์ · ท.ค. · อื่นๆ" if _txt(doc_eff) else "เลือกชนิดเอกสารก่อน")

        def _air_now():
            return (eds["UTMMAP1"].text(), eds["UTMMAP2"].text(), eds["UTMMAP4"].text(), cb.currentText(), ed_ln.text())

        def _key():
            # ★ 2.4.8 ชนิดที่ปลั๊กอินตั้งคีย์ให้ (_key_lock_sync · st['kauto']) ⇒ 0 = คิดเลข ≤ 0 ที่ว่าง (ช่องแสดงเลขที่ได้)
            return _ep_normalize(eds["UTMMAP1"].text(), eds["UTMMAP2"].text(), eds["UTMMAP3"].text(),
                                 eds["UTMMAP4"].text(), cb.currentText(), "0" if st.get("kauto") else ed_ln.text(), public_neg=True,
                                 airphoto=bool(st.get("air")))          # ★ 2.4.8 น.ส.3 ก = คีย์ระวางรูปถ่าย (_key_mode_sync)

        _gk = {}

        def _auto_key(doc):
            """★ 2.4.8 คีย์ที่ระบบเลือกของชนิดที่ไม่ใช้เลขของทะเบียน — ระวาง: ของแปลงเดิม (ครบ) ไม่งั้นของแปลงข้างเคียง (_cp_guess_key) ·
            เลขที่ดิน: ชนิดเดิม + ระวางเดิม ⇒ เลขเดิม (แปลงเลขบวกเดิมแก้อย่างอื่นได้ · กติกา 2.4.7) · เปลี่ยนเข้าชนิดนี้ ⇒ เลข ≤ 0 เดิม
            หรือ 0 (คิดเลขที่ว่างให้) · ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 🟡 agent B) ระวาง/เลขเดิมนับจากคีย์เดิมที่จัดรูปแล้ว (_vo0 —
            เช่น UTMMAP4 ว่างของ 1:4000 ⇒ '00') · เดิมดูค่าดิบในฐาน ⇒ ช่องว่าง = "ระวางไม่ครบ" ⇒ เดาระวางข้างเคียง + คิดเลข ≤ 0 ใหม่ ⇒ แก้แค่ Type
            ก็เปลี่ยนคีย์ (น.ส.3 #15 → -2 · 2.4.7 คงคีย์เดิม) · คีย์เดิมจัดรูปไม่ได้ / แปลง น.ส.3 ก (คีย์ระวางรูปถ่าย ไม่ใช่ระวาง UTM) ⇒ เดาแบบเดิม"""
            own = _old_key is not None and bool(_vo0.get("UTMMAP3"))      # คีย์ระวางรูปถ่าย (UTMMAP3 ว่าง) ไม่ใช่ระวาง UTM
            if own:
                sh = {k: _vo0[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE")}
            else:
                if "g" not in _gk:
                    _gk["g"] = self._cp_guess_key(poly_lyr, feat.geometry()) if feat.hasGeometry() else {}
                sh = dict(_gk["g"])
            keep = own and (_txt(doc) == _txt(cur_doc) or _public_landno(_vo0["LANDNO"]))
            return dict(sh, LANDNO=_vo0["LANDNO"] if keep else "0")

        def _unlock_doc():
            """ผลค้นถูกทิ้ง ⇒ ปลดล็อกชนิดเอกสาร + คืนค่าก่อนผลค้นเติม -> True = คืนค่าแล้ว (ผู้เรียกคำนวณกล่องใหม่)"""
            if st["doc_lock"]:
                st["doc_lock"] = False
                cb_doc.setEnabled(bool(docf))
                cb_doc.setToolTip("" if docf else "ชั้นแปลงนี้ไม่มีคอลัมน์ DOC_TYPE")
            i0, i1 = st["doc_back"], st["doc_set"]
            st["doc_back"] = st["doc_set"] = None
            if i0 is not None and i1 == cb_doc.currentIndex() and i0 != i1:
                cb_doc.blockSignals(True)
                cb_doc.setCurrentIndex(i0)
                cb_doc.blockSignals(False)
                return True
            return False

        def _upd(*_a):
            # ★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 22:5x · แบบ ➕) ชนิดที่ไม่ใช้เลขของทะเบียน ⇒ ช่องคีย์แสดงค่าของระบบ พิมพ์ไม่ได้ (_auto_key) ·
            #   ปลดก่อน / ล็อกหลัง _key_mode_sync
            _dnow = (_txt(cb_doc.currentData()) if docf else "") or cur_doc
            _klock = self._key_auto_doc(_dnow)
            if not _klock:
                self._key_lock_sync(st, eds, cb, ed_ln, False)
            self._key_mode_sync(st, eds, cb, form, _dnow, lk_lbl)     # ★ 2.4.8
            if _klock:
                self._key_lock_sync(st, eds, cb, ed_ln, True, _auto_key(_dnow))
            v, err = _key()
            if _air_legacy and st.get("air"):
                # ★ 2.4.8 rc2 (⚪1) ยังเป็นค่าที่แปลงมาเอง (ผู้ใช้ไม่ได้พิมพ์คีย์ระวางรูปถ่าย) ⇒ ข้อผิด แทนการเสนอคีย์ใหม่ · พิมพ์แล้ว/เปลี่ยนชนิด ⇒ ทำต่อได้
                #   ★ 2.4.8 rc3 (ผลตรวจ Windows 2.4.8 rc2 ⚪1) "พิมพ์แล้ว" = แผ่นที่/มาตราส่วนถูกแก้ — เดิมแก้แค่เลขที่ดินข้อผิดก็หาย
                #   แล้วกล่องยืนยันเสนอระวางที่แปลงมาเอง ('5137 3 -000 · 1:5000')
                st.setdefault("air0", _air_now())
                if _air_now()[2:4] == st["air0"][2:4]:
                    err = list(err) + ["แปลง น.ส.3 ก นี้มีคีย์แบบระวาง UTM (ข้อมูลเก่า) — ช่องคีย์ข้างบนเป็นค่าที่แปลงมาเอง ไม่ใช่คีย์ของเอกสาร · "
                                       "พิมพ์คีย์ระวางรูปถ่ายตามเอกสาร (UTMMAP4 แผ่นที่ 3 หลัก · มาตราส่วน · เลขที่ดิน) หรือเปลี่ยนชนิดเอกสาร "
                                       "(ปลั๊กอินไม่เสนอคีย์ใหม่เอง)"]
            # ★ 2.4.3 ค่าที่เลือก (None = ไม่มีคอลัมน์ = ไม่เปลี่ยน)
            res["tp"] = _txt(cb_tp.currentData()) if tf else None
            res["doc"] = _txt(cb_doc.currentData()) if docf else None
            _tp_ch = res["tp"] is not None and res["tp"] != "" and res["tp"] != cur_tp
            _doc_ch = res["doc"] is not None and res["doc"] != cur_doc
            _deed_after = (res["doc"] if res["doc"] is not None else cur_doc) == self._DEED
            # ★ 2.4.5 rc2 parcel_name หลังแก้ (None = ไม่มีคอลัมน์) — ชนิดหลังแก้เปิดช่อง ⇒ ค่าในช่อง · เปลี่ยนเป็นชนิดที่ปิดช่อง ⇒ ล้าง ·
            #   ชนิดเดิม ⇒ คงเดิม · ★ 2.4.7 ช่องเปิดเฉพาะชนิดสาธารณะ (_pn_open · เท่า 2.4.5)
            _doc_after = res["doc"] if (res["doc"] is not None and res["doc"] != "") else cur_doc
            _pn_sync(_doc_after)
            _dqon = _txt(_doc_after) in self._DOC_NOKEY                  # ★ 2.4.8 ขั้น E กลุ่ม ข
            dq["lbl"].setVisible(_dqon)
            dq["w"].setVisible(_dqon)
            _q = (_txt(_doc_after), self._dq_vals(dq)) if _dqon else None
            _pn_err = ""
            if not pnf:
                res["pn"] = None
            elif self._pn_open(_doc_after):
                res["pn"], _pn_err = self._pn_value(_doc_after, cb_pn.currentText())
                res["pn"] = res["pn"] or ""
            else:
                res["pn"] = "" if _doc_ch else cur_pn
            _pn_ch = res["pn"] is not None and res["pn"] != cur_pn
            # ★ 2.4.3 rc2 (เจ้าของงาน 22 ต.ค. 69) ที่สาธารณะ: 0 ⇒ คิดเลขที่ว่างให้เองแบบ ➕ (แปลงนี้เป็นที่สาธารณะของระวางนี้อยู่แล้ว
            #   ⇒ คงเลขเดิม) · เลขติดลบที่มีแปลง/หมุดอื่นใช้ ⇒ ข้อผิด (ไม่ใช่กล่องแปลงแฝด) · ที่สาธารณะเป็นโฉนดไม่ได้ (⚪8)
            _pub, _pub_note = False, ""
            res["pub0"] = False
            if not err and _public_landno(v["LANDNO"]):
                _pub = True
                head = "".join(v[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"))
                if head not in _used:
                    _used[head] = self._cp_used_landno_le0(poly_lyr, point_lyr, head, own=feat)
                if v["LANDNO"] == "0":
                    v, _pub_note = self._ep_public_landno(poly_lyr, point_lyr, feat, flds, v, used=_used[head],
                                                          what=_txt(_doc_after) if _txt(_doc_after) in self._DOC_NOKEY else None)
                    res["pub0"] = True
                    if st.get("kauto") and v["LANDNO"] != ed_ln.text():
                        ed_ln.blockSignals(True)                 # ★ 2.4.8 แสดงเลข ≤ 0 ที่คิดได้ (ช่องปิด · ค่าที่ส่งตรวจยังเป็น 0)
                        ed_ln.setText(v["LANDNO"])
                        ed_ln.blockSignals(False)
                elif _norm_utm(v["UTM"]) != _norm_utm(old_utm) and v["LANDNO"] in _used[head]:
                    # ★ 2.4.8 (ผลตรวจ Windows 2.4.7 rc1 ⚪) กลุ่ม ข เลข ≤ 0 ไม่ใช่ที่สาธารณะ ⇒ บอกชนิดเอกสาร
                    _who = (f"{_txt(_doc_after)} (เลขที่ดิน ≤ 0 ที่ปลั๊กอินตั้งให้) " if _txt(_doc_after) in self._DOC_NOKEY else "ที่สาธารณะ")
                    err = err + [f"เลขที่ดิน {v['LANDNO']} ของระวางนี้มีแปลง/หมุดอื่นใช้แล้ว — {_who}ใช้คีย์ซ้ำไม่ได้ · "
                                 "พิมพ์ 0 แล้วปลั๊กอินจะคิดเลขที่ว่างให้เอง"]
                if not err and _deed_after and (v["UTM"] != old_utm or _doc_ch):
                    # ★ 2.4.8 (ผลตรวจ Windows 2.4.7 rc1 ⚪1) แปลงกลุ่ม ข (เลข ≤ 0 ที่ปลั๊กอินตั้งให้) → โฉนด (งานจริง: น.ส.3 ออกโฉนด) ⇒
                    #   บอกให้ใส่เลขที่ดินของโฉนด ไม่ใช่ชี้ไปชนิดสาธารณะ
                    err = err + [(f"เลขที่ดิน ≤ 0 เป็นคีย์ที่ปลั๊กอินตั้งให้ของ {cur_doc} — เป็นโฉนดที่ดินไม่ได้ · โฉนดใช้เลขที่ดินบนระวาง: "
                                  "พิมพ์เลขที่ดินของโฉนด (เลขบวก) แล้ว 🔍 ค้นทะเบียน") if cur_doc in self._DOC_NOKEY else
                                 "เลขที่ดิน ≤ 0 = ที่สาธารณะ — เป็นโฉนดที่ดินไม่ได้ · เลือกชนิดเอกสารให้ตรง "
                                 "(เช่น ทางสาธารณประโยชน์ / ที่สาธารณประโยชน์)"]
            if not err and _txt(_doc_after) in self._DOC_NOKEY and re.fullmatch(r"[1-9][0-9]*", _txt(v.get("LANDNO"))) \
                    and (tuple(v[k] for k in self._EP_KEYS) != _old_key or _doc_ch):
                # ★ 2.4.7 คีย์กลุ่ม ข — เลขบวกใหม่ (เปลี่ยนคีย์/ชนิดเอกสาร) ใส่ไม่ได้ · แปลงเดิมที่เลขบวกอยู่แล้วแก้อย่างอื่นได้ (ไม่บังคับเปลี่ยนคีย์)
                #   ★ rc2 (ผลตรวจ Windows rc1 🟡1) "คีย์เปลี่ยน" = ช่องคีย์ที่จัดรูปแล้วต่างจากเดิม (เดิมเทียบสตริง UTM ในฐาน)
                err = err + [f"{_txt(_doc_after)} ไม่มีเลขที่ดินบนระวาง UTM — พิมพ์เลขที่ดิน 0 แล้วปลั๊กอินจะคิดเลขที่ว่างให้เอง (0, -1, -2, …)"]
            if _pn_err:
                err = err + [_pn_err]
            res["v"], res["err"] = v, err
            # ★ 2.4.6 ผลค้นในกล่องใช้ได้เฉพาะคีย์ที่ค้น — คีย์เปลี่ยน/กรอกผิด/กลายเป็นที่สาธารณะ ⇒ ทิ้งผล (เนื้อที่ · REGIS · ล็อกชนิดเอกสาร)
            lk = st["lk"]
            # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 2) ชนิดเอกสารเปลี่ยนหลังค้น (คีย์เดิม) ⇒ ผลเป็นของหน้าทะเบียน/ชนิดเดิม ⇒ ทิ้ง
            _ldch = lk is not None and lk.get("doc") is not None and self._lk_doc_moved(lk["doc"], _doc_after)
            # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪C) ท.ค./อื่นๆ ไม่มีทะเบียน ⇒ ผลค้นของชนิดใดก็ทิ้ง (เดิมแปลง ท.ค. เลขบวกเดิม
            #   ค้นตอนเป็นโฉนดแล้วเปลี่ยนกลับ ⇒ กล่องโชว์ REGIS/เนื้อที่ของผลนั้นเป็นค่าที่จะเขียน ทั้งที่ทาง 'likepub' ไม่ใช้)
            _lp = _txt(_doc_after) in self._DOC_LIKE_PUB
            if lk is not None and (err or (_pub and lk.get("q") is None) or lk["utm"] != v.get("UTM")
                                   or (lk.get("q") is not None and lk["q"] != _q) or _ldch or _lp):    # ★ 2.4.8 ขั้น E ค่าค้นกลุ่ม ข เปลี่ยน
                st["lk"] = lk = None
                lk_lbl.setText("ชนิดเอกสารเปลี่ยนหลังค้น — กดค้นใหม่ได้ (ไม่ค้น = โปรแกรมค้นให้หลังกด OK)" if _ldch else
                               "คีย์เปลี่ยนหลังค้น — กดค้นใหม่ได้ (ไม่ค้น = โปรแกรมค้นให้หลังกด OK)")
                if _unlock_doc():
                    _upd()                                    # ชนิดเอกสารถูกคืน ⇒ คำนวณทั้งกล่องใหม่
                    return
            lkf = lk if (lk and lk.get("final")) else None     # ผลค้นที่ใช้ต่อได้ (ค้นไม่สำเร็จ ⇒ ค้นใหม่หลัง OK)
            ar = lkf["ar"] if lkf else None
            # REGIS (ช่องล็อก) = ค่าที่จะเขียน: ผลค้นของคีย์นี้ (มีค่า) · ไม่ได้ค้น/ไม่พบ = คงเดิม ·
            #   ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪D · เจ้าของงาน 27 ต.ค. 69 "ล้างให้ตรง ➕") เปลี่ยนเป็น ท.ค./อื่นๆ = 'ไม่มีทะเบียน'
            _lp_new = _lp and _doc_ch
            _rg = ("ไม่มีทะเบียน" if (_lp_new and rf) else
                   ar["regis"] if (ar and ar.get("regis") is not None and rf) else cur_regis)
            _ri = cb_rg.findData(_rg)
            if _ri < 0:
                cb_rg.addItem(_rg, _rg)
                _ri = cb_rg.findData(_rg)
            if _ri != cb_rg.currentIndex():
                cb_rg.blockSignals(True)
                cb_rg.setCurrentIndex(_ri)
                cb_rg.blockSignals(False)
            # ★ 2.4.6 ด่านโฉนดในกล่อง (แบบ ➕) — ค้นแล้ว + การแก้นี้เข้าด่านโฉนด + ผลไม่ผ่าน ⇒ ปุ่ม OK ปิดพร้อมเหตุ
            #   (ไม่ได้ค้น ⇒ ไม่ปิด — ค้นหลังกด OK แล้วด่านเดิมใน _ep_after_lookup ตัดสิน)
            gate = ""
            if not err and lkf:
                _ch = self._ep_changes(feat, flds, dict(v, _type=res["tp"], _doc=res["doc"], _sync=False, _pname=res["pn"]))
                if _ch["deed"]:
                    _why = self._ep_deed_block(lkf["res"], ar or {})
                    if _why:
                        gate = "โฉนดที่ดิน — แก้ไม่ได้: " + _why
            st["gate"] = gate
            _E = _html.escape
            if err:
                prev.setText("<span style='color:#b71c1c'>" + "<br>".join(_E(e) for e in err) + "</span>")
            else:
                _same = v["UTM"] == old_utm
                _fix = _same and any(cur[k] != v[k] for k in self._EP_KEYS)        # ★ 2.3.7 b19 (doc-verify E3)
                # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪2) — ค่าจากฐานใส่ในข้อความ rich text ⇒ escape · ข้อความบอกตามทางที่ทำจริง
                _more = []
                if _tp_ch:
                    _more.append(f"Type: {_E(cur_tp or '(ว่าง)')} → <b>{_E(res['tp'])}</b> (แปลง + หมุดของแปลง)")
                if _doc_ch:
                    _more.append(f"ชนิดเอกสาร: {_E(cur_doc or '(ว่าง)')} → <b>{_E(res['doc'] or '(ว่าง)')}</b>")
                if _pn_ch:                                              # ★ 2.4.5 rc2
                    # ★ 2.4.8 (ผลตรวจ Windows 2.4.7 rc1 ⚪4) ล้างชื่อ ⇒ ชื่อแถวตามชนิดเดิม (ท.ค. = "ชื่อแปลง")
                    _more.append(f"{_E(self._pn_label(_doc_after if res['pn'] else cur_doc))}: {_E(cur_pn or '(ว่าง)')} → "
                                 f"<b>{_E(res['pn'] or '(ว่าง)')}</b>"
                                 + ("" if res["pn"] or self._pn_open(_doc_after) else
                                    " (ชนิดเอกสารใหม่ไม่ใช่ทางสาธารณะ ⇒ ล้างชื่อ)"))
                if lk and not lkf:
                    _more.append("ค้นทะเบียนไม่สำเร็จ — กด OK แล้วโปรแกรมจะค้นใหม่ (หรือกด 🔍 อีกครั้ง)")
                if lkf:
                    # ★ 2.4.6 (เจ้าของงาน 26 ต.ค. 69 "คิดค่า diff แสดงให้เห็น") — AREA/DIFF/REGIS ที่จะเขียนจากผลค้นนี้
                    if ar and ar.get("area") is not None:
                        _dn = _dol_area_diff(ga, ar["area"])
                        _more.append("AREA (เนื้อที่ทะเบียน): " + _E(f"{cur_area:,.2f}" if cur_area is not None else "(ว่าง)")
                                     + f" → <b>{ar['area']:,.2f}</b> ตร.ม. · DIFF_AREA: "
                                     + _E(f"{_d0:+.2f}%" if _d0 is not None else "-") + " → <b>"
                                     + _E(f"{_dn:+.2f}%" if _dn is not None else "-") + "</b>")
                    else:
                        _more.append("AREA/DIFF คงเดิม (ผลค้นไม่ได้เนื้อที่ทะเบียน)")
                    if rf and _rg != cur_regis:
                        _more.append(f"REGIS: {_E(cur_regis or '(ว่าง)')} → <b>{_E(_rg)}</b>")
                    if ar and ar.get("reg") and any(flds["poly"].get(k) for k in _REG_COLS):
                        _more.append(_E(_reg_txt(ar["reg"])))                    # ★ 2.4.8 ค่าทะเบียนที่จะเขียน
                    if ar and ar.get("hist_ok"):
                        _more.append("<span style='color:#e65100'>⚠️ คีย์ชั้นประวัติของแผนที่กรม — ทะเบียน iLands ยืนยันว่าโฉนดยังใช้อยู่ "
                                     "· กด OK แล้วจะถามยืนยันอีกครั้ง</span>")
                if _lp_new:
                    # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪D · เจ้าของงาน 27 ต.ค. 69 "ล้างให้ตรง ➕") ค่าที่จะเขียนแบบ ➕ _cp_apply ·
                    #   กล่องยืนยันบอกอีกครั้ง (_ep_after_lookup 'likepub')
                    if rf and _rg != cur_regis:
                        _more.append(f"REGIS: {_E(cur_regis or '(ว่าง)')} → <b>{_E(_rg)}</b>")
                    if cur_area is not None or cur_diff is not None:
                        _more.append("AREA: " + _E(f"{cur_area:,.2f}" if cur_area is not None else "(ว่าง)")
                                     + " → <b>(ว่าง)</b> · DIFF_AREA: " + _E(f"{cur_diff:+.2f}%" if cur_diff is not None else "(ว่าง)")
                                     + f" → <b>(ว่าง)</b> ({_E(_txt(_doc_after))} ไม่มีทะเบียน — แบบ ➕)")
                if st["doc_lock"]:
                    _more.append("ชนิดเอกสารล็อกตามผลทะเบียน (โฉนดที่ดิน) — เปลี่ยนคีย์แล้วค้นใหม่ถ้าไม่ใช่แปลงนี้")
                _nk = _txt(_doc_after) in self._DOC_NOKEY
                if _lp:
                    # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪B) ท.ค./อื่นๆ ไม่ถามระบบกรมทุกทาง (_edit_parcel_picked 'likepub') — เดิมบางทาง
                    #   บอก "ดึงเนื้อที่ทะเบียนใหม่อย่างเดียว" / "ที่สาธารณะ" คู่กับหมายเหตุ "ไม่ได้ถามระบบกรม" ในกล่องเดียวกัน
                    _sfx = (("  (UTM ไม่เปลี่ยน — แก้ช่องระวาง/เลขที่ดินให้ตรงกับ UTM · " if _fix else
                             "  (คีย์ไม่เปลี่ยน · " if _same and (_tp_ch or _doc_ch or _pn_ch) else
                             "  (ไม่เปลี่ยน — " if _same else "  (")
                            + f"{_E(_txt(_doc_after))} ไม่มีทะเบียนให้ค้น · ไม่ถามระบบกรม)")
                elif _fix:
                    # ★ rc3 (ผลตรวจ Windows rc2 ⚪1) ตรงกับทางที่ทำจริง · ★ 2.4.6 ค้นในกล่องแล้ว ⇒ ใช้ผลนั้น ·
                    #   ★ 2.4.8 rc2 กลุ่ม ข ไม่ได้ค้นในกล่อง ⇒ ไม่ถามระบบกรมด้วยคีย์ ('nokey')
                    _nodol = ((_doc_ch or _pn_ch) and not (_doc_ch and _deed_after)) or _pub or _nk
                    _sfx = ("  (UTM ไม่เปลี่ยน — แก้ช่องระวาง/เลขที่ดินให้ตรงกับ UTM"
                            + (" · ไม่ถามระบบกรม)" if _nodol and not lkf else
                               " · ใช้ผลค้นทะเบียนในกล่องนี้)" if lkf else " + ดึงเนื้อที่ทะเบียนใหม่)"))
                elif _same and lkf:
                    _sfx = "  (คีย์ไม่เปลี่ยน · ใช้ผลค้นทะเบียนในกล่องนี้)"
                elif _same and (_tp_ch or _doc_ch or _pn_ch):
                    _sfx = "  (คีย์ไม่เปลี่ยน" + (" · ค้นทะเบียน (โฉนดที่ดิน))" if (_doc_ch and _deed_after) else " · ไม่ถามระบบกรม)")
                elif _same:
                    _sfx = ((("  (ไม่เปลี่ยน — เลขที่ดิน ≤ 0 เป็นคีย์ที่ปลั๊กอินตั้งให้ ไม่มีทะเบียนให้ค้นด้วยคีย์)"     # ★ 2.4.7 คีย์กลุ่ม ข
                              if _txt(_doc_after) in self._DOC_NOKEY else "  (ไม่เปลี่ยน — ที่สาธารณะไม่มีทะเบียนให้ค้น)") if _pub
                            # ★ 2.4.8 rc2 กลุ่ม ข เลขบวกเดิม ไม่ได้ค้นในกล่อง ⇒ ทาง 'nokey' ไม่ถามระบบกรม (เดิมบอกว่าดึงเนื้อที่ใหม่)
                            else "  (ไม่เปลี่ยน — ทะเบียนชนิดนี้ค้นด้วยเลขที่เอกสาร (🔍) · ไม่ได้ค้น = ไม่ถามระบบกรม)" if _nk
                            else "  (ไม่เปลี่ยน — ดึงเนื้อที่ทะเบียนใหม่อย่างเดียว)"))
                elif lkf:
                    _sfx = "  (ใช้ผลค้นทะเบียนในกล่องนี้)"
                else:
                    _sfx = (("  (เลขที่ดิน ≤ 0 เป็นคีย์ที่ปลั๊กอินตั้งให้ — ไม่ถามระบบกรม)" if _txt(_doc_after) in self._DOC_NOKEY
                             else "  (ที่สาธารณะ — ไม่ถามระบบกรม)") if _pub else "")      # ★ 2.4.7 คีย์กลุ่ม ข
                if _pub_note:
                    _more.insert(0, _E(_pub_note))
                if st.get("klock"):                          # ★ 2.4.8 ช่องคีย์ที่ปลั๊กอินตั้งให้
                    _more.insert(0, _E(f"🔒 คีย์ของ {_txt(_doc_after)} ตั้งให้อัตโนมัติ (ช่องคีย์แก้ไม่ได้) — "
                                       + ("ระวาง/เลขที่ดินเดิมของแปลง" if not st.get("kauto") and st.get("ksheet") else
                                          ("ระวาง" + ("เดิม/ของแปลงข้างเคียง" if st.get("ksheet") else "ที่พิมพ์ (ไม่มีแปลงข้างเคียงให้เดา)")
                                           + " · เลขที่ดิน ≤ 0 ตัวที่ว่าง"))))
                if gate:
                    _more.append("<span style='color:#b71c1c'>" + _E(gate) + "</span>")
                prev.setText(f"UTM ใหม่: <b>{_E(v['UTM'])}</b>" + _sfx + "".join("<br>" + m for m in _more))
            bb.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(not err and not gate and not st["busy"])
            # ★ 2.4.6 ปุ่มค้น: คีย์ครบ · ไม่ใช่ที่สาธารณะ · ไม่มีงานค้นค้างอยู่ (กันค้นซ้อน — แบบ ➕ rc5 ข้อพบ 1)
            _kv, _ke = _key()
            _pk = _q is None and _public_landno(_kv.get("LANDNO"))                    # ที่สาธารณะ (เลข ≤ 0 ที่ไม่ใช่กลุ่ม ข)
            _non = _q is not None and not _q[1]["no"]                                 # ★ ขั้น E กลุ่ม ข ต้องมีเลขที่เอกสาร
            _on = (not st["busy"] and not _ke and not err                             # ★ 2.4.8 ขั้น D · ⚪ rc1 กล่องมีข้อผิด ⇒ ปิด
                   and not _non and not _pk and not _lp)                              # ★ 2.4.7 rc2 🟡2 ท.ค./อื่นๆ แบบที่สาธารณะ
            btn_lk.setEnabled(_on)
            # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪B) ปุ่มที่ปิดบอกเหตุ · ป้ายข้างปุ่มบอกตามชนิด/คีย์ (เดิม "ยังไม่ได้ค้น — กดปุ่ม…
            #   ไม่ได้ค้น โปรแกรมค้นให้หลังกด OK" ทั้งที่ปุ่มปิด/ทาง OK ไม่ถามระบบกรม) · กลุ่ม ข ไม่ทับผลค้น (_lk_hint_sync)
            _dname = _txt(_doc_after)
            btn_lk.setToolTip("" if _on else "กำลังค้นจากระบบกรม…" if st["busy"] else
                              f"{_dname} ไม่มีทะเบียนให้ค้น (แบบที่สาธารณะ)" if _lp else
                              "กรอกคีย์ให้ครบ/แก้ข้อผิดในกล่องก่อน" if (_ke or err) else
                              f"{_dname} — ใส่เลขที่เอกสารก่อน (ทะเบียนชนิดนี้ไม่มีระวาง UTM)" if _non else
                              "ที่สาธารณะ (เลขที่ดิน ≤ 0) ไม่มีทะเบียนให้ค้น")
            _pkh = _pk and not _ke
            self._lk_hint_sync(st, lk_lbl,
                               (f"{_dname} — ไม่มีทะเบียนให้ค้น (แบบที่สาธารณะ) · ไม่ถามระบบกรม · "
                                + ("REGIS = ไม่มีทะเบียน · ล้าง AREA/DIFF (แบบ ➕)" if _lp_new else "เนื้อที่/REGIS คงเดิม")) if _lp else
                               "ที่สาธารณะ (เลขที่ดิน ≤ 0) — ไม่มีทะเบียนให้ค้น · ไม่ถามระบบกรม · เนื้อที่/REGIS คงเดิม" if _pkh else
                               (f"{_dname} — ค้นทะเบียนด้วยเลขที่เอกสาร (+ หมู่ · ตำบล) แล้วกด 🔍 "
                                "(ไม่บังคับ — ไม่ได้ค้น = ไม่ถามระบบกรม · เนื้อที่/REGIS คงเดิม)") if _q is not None else None,
                               lk_idle, force=_lp or _pkh)

        def _lookup():
            if st["busy"]:
                return
            v, err = _key()
            if err:
                return
            if _txt((_txt(cb_doc.currentData()) if docf else "") or cur_doc) in self._DOC_LIKE_PUB:      # ★ 2.4.7 rc2 🟡2 (ทางเรียกตรง)
                lk_lbl.setText(f"{(_txt(cb_doc.currentData()) if docf else '') or cur_doc} — ไม่มีทะเบียนให้ค้นด้วยคีย์ (แบบที่สาธารณะ)")
                return
            _dd = _txt((_txt(cb_doc.currentData()) if docf else "") or cur_doc)
            _q = (_dd, self._dq_vals(dq)) if _dd in self._DOC_NOKEY else None      # ★ 2.4.8 ขั้น E กลุ่ม ข ค้นด้วยเลขที่เอกสาร
            if _q is not None and not _q[1]["no"]:
                lk_lbl.setText(f"{_dd} — ใส่เลขที่เอกสาร (+ หมู่ · ตำบล) แล้วกด 🔍 (ทะเบียนชนิดนี้ไม่มีระวาง UTM)")
                return
            if _q is None and _public_landno(v["LANDNO"]):
                lk_lbl.setText("ที่สาธารณะ — ไม่มีทะเบียนให้ค้น")
                return
            attrs = self._ep_attrs(poly_lyr, feat, v, air=bool(st.get("air")))      # ★ 2.4.8 ขั้น D น.ส.3 ก ⇒ หน้า QNS3K
            if _q is not None:
                attrs.update(docsearch=True, doc=_dd, no=_q[1]["no"], moo=_q[1]["moo"], tambol=_q[1]["tb"], amphur=_q[1]["am"],
                             seq="", row={})
            elif _dd in self._DOC_UTMDOC:             # ★ 2.4.8 ขั้น E1 โฉนดตราจอง/ตราจองฯ ⇒ หน้าของชนิดนั้นด้วยคีย์ UTM
                attrs.update(utmdoc=True, doc=_dd)
            st["busy"] = True
            btn_lk.setEnabled(False)
            lk_lbl.setText("กำลังค้นจากระบบกรม…")
            _upd()
            # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 4) ผลนี้เป็นของคีย์ที่กล่องคิดไว้ (เลขที่ดิน 0 ⇒ เลข ≤ 0 ที่ว่าง) — เดิมใช้คีย์ดิบ (…0) ⇒ ไม่ตรงกับ
            #   ที่ _upd เก็บ (…-1) ⇒ ผลค้นกลุ่ม ข ถูกทิ้งเป็น "คีย์เปลี่ยนระหว่างค้น" ทุกครั้ง
            _u0 = _txt((res.get("v") or {}).get("UTM")) if not res.get("err") else v["UTM"]
            w = ParcelLookupWorker(attrs, zone=47, lis_more=True)
            if not hasattr(self, "_net_workers"):
                self._net_workers = []
            self._net_workers.append(w)

            def _drop(_w=w):
                try:
                    self._net_workers.remove(_w)
                except Exception:
                    pass
                try:
                    _w.deleteLater()
                except Exception:
                    pass

            def _abandon():
                st["busy"] = False
                try:
                    lk_lbl.setText("ยกเลิกการค้นทะเบียน iLands แล้ว — กดค้นใหม่ได้")
                    _upd()
                except RuntimeError:
                    pass                                      # กล่องถูกปิดไปก่อน

            def _moved(_utm, _q0=None, _d0=None):
                """คีย์ในกล่องเปลี่ยนระหว่างค้น (หรือกรอกผิด) ⇒ ผลนี้เป็นของคีย์เดิม · ★ 2.4.8 ขั้น E ชนิด/เลขที่/หมู่/ตำบลที่ค้นเปลี่ยนก็เช่นกัน ·
                ★ 2.4.8 (ผลตรวจอิสระ ข้อ 2–3) ชนิดเอกสารเปลี่ยน ⇒ ผลของหน้าเดิม · กล่องถูกปิด/ลบก่อนผลมา ⇒ ทิ้ง (ไม่โยน RuntimeError)
                -> '' = ใช้ผลได้ · 'doc' = ชนิดเอกสารเปลี่ยน · 'key' = คีย์/ค่าค้นเปลี่ยนหรือกล่องปิดแล้ว"""
                try:
                    _dn = _txt((_txt(cb_doc.currentData()) if docf else "") or cur_doc)
                    if _d0 is not None and self._lk_doc_moved(_d0, _dn):
                        return "doc"
                    if _q0 is not None and (_dn, self._dq_vals(dq)) != _q0:
                        return "key"
                except RuntimeError:
                    return "key"
                return "key" if (bool(res.get("err")) or _txt((res.get("v") or {}).get("UTM")) != _txt(_utm)) else ""

            def _moved_txt(why):
                return ("ชนิดเอกสารเปลี่ยนระหว่างค้น — ผลที่ได้เป็นของชนิดเดิม (ไม่ได้ใช้) · กดค้นใหม่" if why == "doc" else
                        "คีย์เปลี่ยนระหว่างค้น — ผลที่ได้เป็นของคีย์เดิม (ไม่ได้ใช้) · กดค้นใหม่")

            def _end(r, e, _utm=_u0, _q0=_q, _d0=_dd):
                _mv = _moved(_utm, _q0, _d0)
                if _mv:
                    if not (isinstance(r, dict) and r.get("lis") == "login"):
                        self._dol_log_lis_trace(r)
                    st["busy"] = False
                    try:
                        lk_lbl.setText(_moved_txt(_mv))
                        _upd()
                    except RuntimeError:
                        pass
                    return
                if e is None and isinstance(r, dict) and r.get("lis") == "login":
                    # ต้องค้นทะเบียน iLands แต่ยังไม่เข้าสู่ระบบ ⇒ กล่องเข้าสู่ระบบ แล้วค้นต่อ (ยกเลิก = ผลจากแผนที่) — แบบ ➕
                    try:
                        lk_lbl.setText("ต้องค้นต่อในทะเบียน iLands — เข้าสู่ระบบในกล่องที่เด้ง…")
                    except RuntimeError:
                        return                                # กล่องถูกปิดไปก่อนผลมา
                    self._dol_lis_continue(r, attrs, lambda r2: _end(r2, None), on_abandon=_abandon)
                    return
                self._dol_log_lis_trace(r)
                if e is None and isinstance(r, dict) and r.get("choices"):
                    # ★ 2.4.8 ขั้น E ทะเบียนมีเลขนี้หลายฉบับ ⇒ กล่องเลือก (ไม่มีชื่อบุคคล) แล้วเปิดหน้ารายละเอียดของฉบับที่เลือก (1 คำขอ)
                    try:
                        row = self._doc_choose(r["choices"], _txt(r.get("parcel_type")) or _dd, parent=d, shape_m2=ga)
                    except RuntimeError:
                        return                                # กล่องถูกปิดไปก่อนผลมา
                    if row is None:
                        st["busy"] = False
                        try:
                            lk_lbl.setText(f"ทะเบียนมีเลขนี้ {len(r['choices'])} ฉบับ — ไม่ได้เลือก · ใส่หมู่/ตำบลให้ตรงแล้วค้นใหม่ได้")
                            _upd()
                        except RuntimeError:
                            pass
                        return
                    # ★ 2.4.9 (แผน 2.4.9 ข้อ 2.5 · เจ้าของงาน 27 ต.ค. 69 "ตอนกดเลือกฉบับนี้ มันไม่เติมข้อมูลให้") แถวค้นกลุ่ม ข ตามฉบับที่เลือก
                    #   (หมู่ · อำเภอ · ตำบล) ⇒ ค่าค้นของผลฉบับนี้ = ค่าใหม่ (เดิมแถวค้นว่างตามที่พิมพ์ · เติมเองภายหลัง ⇒ ผลถูกทิ้ง)
                    if _q0 is not None:
                        self._dq_fill_row(dq, row)
                    _qn = (_q0[0], self._dq_vals(dq)) if _q0 is not None else None
                    w2 = ParcelLookupWorker(dict(attrs, seq=_txt(row.get("parcel_seq")), row=dict(row)), zone=47, lis_more=True)
                    self._net_workers.append(w2)
                    w2.finished.connect(lambda _w=w2: _drop(_w))
                    w2.done.connect(lambda r2, _q=_qn: _end(r2, None, _q0=_q))
                    w2.fail.connect(lambda m2, _q=_qn: _end(None, m2, _q0=_q))
                    try:
                        lk_lbl.setText("กำลังเปิดฉบับที่เลือกจากทะเบียน…")
                    except RuntimeError:
                        return
                    w2.start()
                    return
                st["busy"] = False
                try:
                    self._ep_mark_in_layer(poly_lyr, r, own=feat.id())
                    ar = self._ep_area_result(r, e, shape_m2=ga)
                except Exception:
                    ar = {"area": None, "regis": None, "note": "อ่านผลจากระบบกรมไม่ได้"}
                try:
                    _mv = _moved(_utm, _q0, _d0)
                    if _mv:
                        lk_lbl.setText(_moved_txt(_mv))
                        _upd()
                        return
                    # ★ (ตรวจอิสระ ⚪2) ค้นไม่สำเร็จ (ล้ม · ทะเบียนไม่ว่าง/ยกเลิกเข้าสู่ระบบ/ค้นทะเบียนล้ม) ⇒ ไม่ใช่ผลที่ตัดสินได้
                    _fin = e is None and not (isinstance(r, dict) and r.get("lis") in ("busy", "skipped", "error"))
                    st["lk"] = {"utm": _utm, "res": r, "err": e, "ar": ar, "final": _fin, "q": _q0,     # ★ 2.4.8 ขั้น E q = ค่าค้นกลุ่ม ข
                                "doc": _d0}                   # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 2) ชนิดเอกสารของผลนี้
                    lk_lbl.setText(re.sub(r"ตั้ง REGIS = '[^']*' · ", "", _txt(ar.get("note")))
                                   .replace("กดปุ่มนี้ซ้ำภายหลังเพื่อดึงใหม่", "กดค้นใหม่ภายหลังได้"))
                    # ★ แบบ ➕ (2.4.3 ⚪4 · rc2 ⚪5) — ผลที่ยืนยันเป็นแปลงนี้ได้บอกชนิดเอกสาร ⇒ เติมให้ (โฉนดที่ดิน = ล็อก กันเปลี่ยนหลบด่านโฉนด)
                    _sure = (isinstance(r, dict) and bool(r.get("verified")) and not r.get("cross_office")
                             and (ar.get("area") is not None or bool(ar.get("regis")))
                             and not ((r.get("match_count") or 1) > 1 and not r.get("branch_office")))
                    pt_ = _txt(r.get("parcel_type")) if _sure else ""
                    if pt_ and docf and _fin:
                        i = cb_doc.findData(pt_)
                        if i >= 0 and (pt_ == self._DEED or not cb_doc.currentData()):
                            if i != cb_doc.currentIndex():
                                st["doc_back"], st["doc_set"] = cb_doc.currentIndex(), i      # ผลถูกทิ้ง ⇒ คืนค่าเดิม
                            st["lk"]["doc"] = pt_             # ชนิดที่ผลทะเบียนเติมให้ = ชนิดของผลนี้ (ไม่นับว่าเปลี่ยนหลังค้น)
                            cb_doc.setCurrentIndex(i)
                            if pt_ == self._DEED:
                                st["doc_lock"] = True
                                cb_doc.setEnabled(False)
                                cb_doc.setToolTip("ล็อกตามผลทะเบียน: แปลงนี้เป็นโฉนดที่ดิน")
                    _upd()
                except RuntimeError:
                    pass                                      # กล่องถูกปิดไปก่อนผลมา
            w.finished.connect(_drop)
            w.done.connect(lambda r: _end(r, None))
            w.fail.connect(lambda msg: _end(None, msg))
            w.start()

        for w in list(eds.values()) + [ed_ln]:
            w.textChanged.connect(_upd)
        for _sg in dq["sig"]:                         # ★ 2.4.8 ขั้น E แถวค้นกลุ่ม ข (เลขที่ · หมู่ · อำเภอ · ตำบล)
            _sg.connect(_upd)
        cb.currentIndexChanged.connect(_upd)
        cb_tp.currentIndexChanged.connect(_upd)
        cb_doc.currentIndexChanged.connect(_upd)
        cb_pn.editTextChanged.connect(_upd)          # ★ 2.4.5 rc2
        btn_lk.clicked.connect(_lookup)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        _upd()
        self._modal_busy = True                      # ★ 2.4.6 แบบ ➕ — กล่องเข้าสู่ระบบ/ผลค้นมาระหว่างกล่องเปิด
        try:
            ok = d.exec_() == QtWidgets.QDialog.Accepted
        finally:
            self._modal_busy = False
            d.deleteLater()
        if not ok or res.get("err") or st.get("gate") or st.get("busy"):
            return None
        # ★ 2.4.3 — ค่า Type/ชนิดเอกสารที่เลือก (_type/_doc: None = ไม่มีคอลัมน์) · ★ 2.4.6 _sync เลิกใช้ (หมุดตาม Type แปลงเสมอ)
        #   ★ rc2 _pub0 = ผู้ใช้พิมพ์เลขที่ดิน 0 (เลขที่สาธารณะในค่าที่คืน = ที่กล่องคิดไว้ — ผู้เรียกคิดใหม่จากข้อมูลตอนกด OK)
        #   ★ 2.4.5 rc2 _pname = ชื่อหลังแก้ (None = ไม่มีคอลัมน์ · '' = ว่าง/ล้าง)
        #   ★ 2.4.6 _lk = ผลค้นในกล่องของคีย์นี้ (None = ไม่ได้ค้น/คีย์เปลี่ยนหลังค้น)
        _lk = st["lk"] if (st["lk"] and st["lk"].get("final") and st["lk"]["utm"] == res["v"].get("UTM")) else None
        return dict(res["v"], _type=res.get("tp"), _doc=res.get("doc"), _sync=False, _pub0=bool(res.get("pub0")),
                    _pname=res.get("pn"), _lk=_lk)

    def _ep_type_choices(self, poly_lyr, tf):
        """★ 2.4.3 (ยุบ 🏷) รายการ Type ของ 📝 — ตายตัว (เจ้าของงาน 21 ต.ค. 69 "เรา fix dropdown type ไว้เลยได้ไหมว่ามีอะไรบ้าง")
        = _CP_TYPES_ALL (L1-RTK · L1-TS · L2-TS · L2-RO · L2-LM — ค่าที่ใช้จริงทั้ง 5 ฐาน ตรวจ 21 ต.ค.) · ไม่ดึงค่าจากชั้นแล้ว
        (★ review 🟡3 — เดิมต่อท้ายด้วยค่าในชั้น ⇒ 'CT_RTK' 'L1TS' ถูกเสนอและเขียนลงแปลง+หมุดได้) · ไม่มี CT-RTK (อยู่ชั้น CT_ เท่านั้น)
        ค่าเดิมของแปลงที่อยู่นอกรายการ = ตัวเลือก "(เดิม) X" ในกล่อง (เลือกแล้วไม่เปลี่ยน)"""
        return list(self._CP_TYPES_ALL)

    def _ep_reg_changes(self, poly_lyr, feat, flds, ch, ar):
        """★ 2.4.8 คอลัมน์ทะเบียน 7 ตัว (แผน 2.4.7 ข้อ 5 · ข้อ 11.5) -> [(lyr, fid, field, ใหม่, เดิม)]
        ผลค้นที่ยืนยันแปลงนี้ได้ (ar['reg'] = _reg_vals) ⇒ คอลัมน์ที่ผลมีคีย์: เลขอ้างอิง (REG_SEQ · PARCEL_NO · SURVEY_NO · MOO) ตามผลทั้งชุด
        (ผลไม่มีค่า = ล้าง) · ตำบล/อำเภอ/จังหวัดเขียนเมื่อผลมีค่า · ผลไม่มีหมู่ + เป็นเอกสารคนละฉบับ (REG_SEQ เปลี่ยน) ⇒ ล้างหมู่เดิม ·
        ไม่ได้ผลทะเบียนใหม่ แต่คีย์/ชนิดเอกสารเปลี่ยน ⇒ ล้างเลขอ้างอิงเดิม (ไม่ใช่ของเอกสารนี้แล้ว · ตำแหน่งคงไว้) — ยกเว้นเปลี่ยนแค่คีย์ของ
        เอกสารกลุ่ม ข (_DOC_NOKEY: คีย์เป็นเลข ≤ 0 ที่ปลั๊กอินตั้งให้ ไม่ใช่ตัวระบุเอกสาร) · ชั้นที่ยังไม่มีคอลัมน์ = ข้าม"""
        reg = (ar or {}).get("reg") or {}
        docf = flds["poly"].get("DOC_TYPE")
        _fdoc = (ch["doc"][1] if ch.get("doc") else _txt(feat[docf])) if docf else ""
        _gone = bool(ch.get("doc")) or (bool(ch.get("key")) and _txt(_fdoc) not in self._DOC_NOKEY)
        fseq = flds["poly"].get("REG_SEQ")
        _other = bool(reg) and (not fseq or _txt(feat[fseq]) != _txt(reg.get("REG_SEQ")))
        out = []
        for k in _REG_COLS:
            fk = flds["poly"].get(k)
            if not fk:
                continue
            if reg:
                if k in reg:
                    nv_ = reg[k]
                elif k == "MOO" and _other:
                    nv_ = None
                else:
                    continue
                if _txt(feat[fk]) != _txt(nv_):
                    out.append((poly_lyr, feat.id(), fk, nv_ or None, feat[fk]))
            elif _gone and k in _REG_IDS and _txt(feat[fk]):
                out.append((poly_lyr, feat.id(), fk, None, feat[fk]))
        # ★ 2.4.9 (เจ้าของงาน 27 ต.ค. 69 "ถ้าเจอสาธารณประโยชน์ ในชื่อให้ใส่ใน parcel name") โฉนดที่ผู้ถือกรรมสิทธิ์เป็นสาธารณประโยชน์
        #   ⇒ parcel_name = ชื่อผู้ถือ (ชนิดหลังแก้ต้องเป็นโฉนดที่ดิน · ทับค่าที่กล่องจะล้างตอนเปลี่ยนชนิดเป็นโฉนด — _ep_apply ข้ามการล้างนั้น)
        pnf = flds["poly"].get(self._PN_FIELD)
        _pn = self._pn_clean(reg.get("parcel_name"))[:self._PN_MAX]
        if pnf and _pn and _txt(_fdoc) == self._DEED and _txt(feat[pnf]) != _pn:
            out.append((poly_lyr, feat.id(), pnf, _pn, feat[pnf]))
        return out

    def _ep_public_landno(self, poly_lyr, point_lyr, feat, flds, v, used=None, what=None):
        """★ 2.4.3 rc2 (เจ้าของงาน 22 ต.ค. 69 — 📝 พิมพ์เลขที่ดิน 0 จะทำเป็นทางสาธารณะ แล้วขึ้น "UTM ซ้ำกับแปลงอื่น")
        เลขที่ดิน 0 = ที่สาธารณะ ⇒ คิดเลขให้เองแบบ ➕ (`_cp_free_public_landno` · คำสั่ง 24 ก.ย.) · แปลงนี้มีเลข ≤ 0 ในระวางเดียวกัน
        อยู่แล้ว ⇒ คงเลขเดิม (ไม่เลื่อนไปเลขอื่น) · v = ค่าที่จัดรูปแล้ว (LANDNO '0') -> (ค่าใหม่, หมายเหตุ)
        (ฐานจริงมี unique index คีย์ที่สาธารณะ — public-utm-unique-index ⇒ คีย์ซ้ำบันทึกไม่ได้อยู่แล้ว)
        ★ 2.4.7 what = ชนิดเอกสารกลุ่ม ข หลังแก้ (หมายเหตุบอกว่าคิดเลขให้เพราะไม่มีระวาง UTM · `_cp_free_public_landno`)"""
        head = "".join(v[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"))
        cur = _norm_utm(feat[flds["poly"]["UTM"]])
        mine = cur[len(head):] if cur.startswith(head) else ""
        if _public_landno(mine):
            n, note = mine, ("เลขที่ดิน 0 = %s ⇒ ใช้เลข %s (เลขเดิมของแปลงนี้ในระวางนี้)"
                             % ("คิดเลขให้เอง (%s ไม่มีระวาง UTM)" % what if what else "ที่สาธารณะ", mine))
        else:
            n, note = self._cp_free_public_landno(poly_lyr, point_lyr, head, used=used, own=feat, what=what)
        return dict(v, LANDNO=str(n), UTM=head + str(n)), note

    def _ep_public_dup_block(self, poly_lyr, point_lyr, feat, flds, newv, plan):
        """★ 2.4.3 rc2 — คีย์ใหม่เป็นที่สาธารณะ (เลขที่ดิน ≤ 0) ที่แปลงอื่น/หมุดที่ไม่ใช่ของแปลงนี้ใช้อยู่ ⇒ บล็อก (ไม่มีกล่องแปลงแฝด E1 —
        ที่สาธารณะคีย์ซ้ำไม่ได้: ฐานมี unique index) · เกณฑ์เดียวกับด่านโฉนด `_ep_deed_dup` -> True = บล็อกแล้ว (แจ้งแล้ว)"""
        why = self._ep_deed_dup(poly_lyr, point_lyr, feat, flds, newv, plan)
        if not why:
            return False
        # ★ 2.4.8 (ผลตรวจ Windows 2.4.7 rc1 ⚪) กลุ่ม ข เลข ≤ 0 ไม่ใช่ที่สาธารณะ ⇒ บอกชนิดเอกสาร
        _ch = (plan or {}).get("ch") or {}
        _df = flds["poly"].get("DOC_TYPE")
        _fd = _txt(_ch["doc"][1] if _ch.get("doc") else (feat[_df] if _df else ""))
        _who = f"{_fd} (เลขที่ดิน ≤ 0 ที่ปลั๊กอินตั้งให้)" if _fd in self._DOC_NOKEY else "ที่สาธารณะ (เลขที่ดิน ≤ 0)"
        self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                  f"แก้ไม่ได้ — {_who} ใช้คีย์ซ้ำกับแปลง/หมุดอื่นไม่ได้\n{why}\n"
                  "พิมพ์เลขที่ดิน 0 แล้วปลั๊กอินจะคิดเลขที่ว่างของระวางนี้ให้เอง (0, -1, -2, …)\n(ยังไม่ได้แก้อะไร)")
        return True

    def _ep_changes(self, feat, flds, newv):
        """★ 2.4.3 สิ่งที่ผู้ใช้เปลี่ยนในกล่อง 📝 -> {'key', 'type', 'doc', 'sync', 'pname', 'deed', 'public'}
        key = คีย์เปลี่ยนจริง (เทียบหลังจัดรูป — ต่างแค่รูปแบบ เช่น โรมัน/เลขศูนย์นำหน้า ไม่นับ · ช่องเดิมจัดรูปไม่ได้ = นับว่าเปลี่ยน)
        type / doc = (ค่าเดิม, ค่าใหม่) หรือ None · sync = ติ๊กปรับ Type หมุดให้ตรงแปลง
        deed = ด่านโฉนด (คำตัดสิน 21 ต.ค. 69: เฉพาะเมื่อเปลี่ยนคีย์/ชนิดเอกสาร และชนิดเอกสารหลังแก้เป็นโฉนดที่ดิน)
        public = ★ rc2 เปลี่ยนคีย์ไปเป็นที่สาธารณะ (เลขที่ดิน ≤ 0) ⇒ คีย์ซ้ำ = บล็อก (`_ep_public_dup_block`)"""
        old = {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS}
        old_utm = _txt(feat[flds["poly"]["UTM"]])
        # ★ 2.4.8 คีย์เดิมตรวจแบบของชนิดเดิม (น.ส.3 ก = คีย์ระวางรูปถ่าย) · แปลง น.ส.3 ก ที่คีย์แบบระวาง UTM (ก่อน 2.4.8) ⇒ เทียบแบบเดิม
        _air_old = (_txt(feat[flds["poly"]["DOC_TYPE"]]) if flds["poly"].get("DOC_TYPE") else "") == self._DOC_AIR
        vo, eo = _ep_normalize(old["UTMMAP1"], old["UTMMAP2"], old["UTMMAP3"], old["UTMMAP4"], old["UTMSCALE"], old["LANDNO"],
                               public_neg=True, airphoto=_air_old)
        if eo and _air_old:
            vo, eo = _ep_normalize(old["UTMMAP1"], old["UTMMAP2"], old["UTMMAP3"], old["UTMMAP4"], old["UTMSCALE"], old["LANDNO"],
                                   public_neg=True)
        same_f = (not eo) and all(vo[k] == newv[k] for k in self._EP_KEYS)        # ★ 2.4.7 rc2 ช่องคีย์เท่าเดิม (ไม่ดู UTM ในฐาน)
        same = same_f and bool(old_utm) and _norm_utm(old_utm) == _norm_utm(newv["UTM"])
        tf, docf = flds["poly"].get("Type"), flds["poly"].get("DOC_TYPE")
        cur_tp = _txt(feat[tf]) if tf else ""
        cur_doc = _txt(feat[docf]) if docf else ""
        ntp, ndoc = newv.get("_type"), newv.get("_doc")
        tp = (cur_tp, ntp) if (tf and ntp and ntp != cur_tp) else None
        doc = (cur_doc, ndoc) if (docf and ndoc is not None and ndoc != cur_doc) else None
        final_doc = ndoc if (docf and ndoc is not None) else cur_doc
        # ★ 2.4.5 rc2 ชื่อทางสาธารณะ (ค่าเดิม, ค่าใหม่) หรือ None — ค่าใหม่ '' = ล้าง
        pnf = flds["poly"].get(self._PN_FIELD)
        npn = newv.get("_pname")
        if npn is not None:
            npn = self._pn_clean(npn)            # ★ rc3 (⚪2) ทางเรียกตรงล้างแบบเดียวกับกล่อง (กล่องล้างใน _pn_value แล้ว)
        pn = (_txt(feat[pnf]), npn) if (pnf and npn is not None and npn != _txt(feat[pnf])) else None
        return {"key": not same, "type": tp, "doc": doc, "sync": bool(newv.get("_sync")), "pname": pn,
                "deed": bool(((not same) or doc) and final_doc == self._DEED),
                "public": bool((not same) and _public_landno(newv.get("LANDNO"))),
                # ★ 2.4.7 คีย์กลุ่ม ข — ชนิดเอกสารหลังแก้ที่ทะเบียนไม่มีระวาง UTM + เลขบวกใหม่ (เปลี่ยนคีย์/ชนิด) ⇒ ชื่อชนิด (= บล็อก) · ไม่ใช่ = ''
                #   ★ rc2 (ผลตรวจ Windows rc1 🟡1) เทียบช่องคีย์ (same_f) — แปลงเลขบวกเดิมที่ UTM ในฐานว่าง/ไม่ตรง แก้อย่างอื่นได้
                "nokey": final_doc if (((not same_f) or doc) and final_doc in self._DOC_NOKEY
                                       and re.fullmatch(r"[1-9][0-9]*", _txt(newv.get("LANDNO")))) else ""}

    def _ep_deed_dup(self, poly_lyr, point_lyr, feat, flds, newv, plan):
        """★ 2.4.3 ด่านโฉนด "คีย์ไม่ซ้ำ" ของ 📝 — ความหมายเดียวกับ ➕ (_cp_check): แปลงอื่นคีย์เดียวกัน + หมุดคีย์นี้ที่ไม่ใช่ของแปลงนี้
        (คำตัดสิน 21 ต.ค. Q4: หมุดค้างคีย์ใหม่นับว่าซ้ำ) -> None = ผ่าน · ข้อความ = เหตุที่บล็อก · ตรวจไม่ได้ = บล็อก (fail-closed)"""
        try:
            pu = flds["poly"]["UTM"]
            tw = [t for t in self._utm_twin_fids(poly_lyr, pu, newv["UTM"], _norm_utm(newv["UTM"])) if t != feat.id()]
            if tw:
                return (f"UTM {newv['UTM']} ซ้ำกับแปลงอื่นที่มีอยู่แล้ว (gid " + ", ".join(str(x) for x in tw[:5])
                        + (" …" if len(tw) > 5 else "") + ") — แก้ระวาง/เลขที่ดิน หรือแก้คีย์ของแปลงที่ซ้ำก่อน")
            own = set(plan.get("mk_ids") or [])
            if _norm_utm(_txt(feat[pu])) == _norm_utm(newv["UTM"]):
                info = self._parcel_markers(poly_lyr, point_lyr, feat)      # คีย์เดิม ⇒ หมุดคีย์นี้ของแปลงนี้เองไม่นับ
                if info is None:
                    return "อ่านรายชื่อหมุดของแปลงนี้ไม่ได้ — ตรวจคีย์ซ้ำไม่ได้"
                own |= set(info["mk_ids"])
            ex = '"%s" = %s' % (flds["point"]["UTM"], QgsExpression.quotedValue(newv["UTM"]))
            it = point_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(ex).setNoAttributes()
                                       .setFlags(QgsFeatureRequest.NoGeometry))
            try:
                stray = [m.id() for m in it if m.id() not in own]
            finally:
                it.close()
            if stray:
                return f"มีหมุดคีย์ {newv['UTM']} ที่ไม่ใช่ของแปลงนี้อยู่แล้ว {len(stray)} ดวง (แต่ไม่มีแปลง) — ตรวจ/ลบหมุดค้างก่อน"
        except Exception:
            _log_exc("📝 ตรวจคีย์ซ้ำของโฉนดไม่สำเร็จ")
            return "ตรวจคีย์ซ้ำไม่สำเร็จ — ไม่แก้ให้ (กันคีย์ซ้ำ)"
        return None

    def _ep_type_ok(self, poly_lyr, point_lyr, feat, plan, sync=True):
        """★ 2.4.3 (ยุบ 🏷) ด่านของการเปลี่ยน Type ที่มากับการแก้คีย์/ชนิดเอกสาร — กติกาเดียวกับ 🏷 _change_type_execute
        -> True = ผ่าน (plan['type_mk'] = หมุดที่จะได้ Type ตามแปลง) · False = ปฏิเสธ (แจ้งแล้ว)
        คีย์เปลี่ยน ⇒ หมุดชุดที่ย้ายตามคีย์ (_ep_plan คัดมุมร่วมกับแฝดออก + ผ่านด่านหมุดล็อกแล้ว) ·
        คีย์เดิม ⇒ หมุดทั้งหมดของแปลง · แปลงแฝด (หมุดแชร์ตามคีย์) ปฏิเสธ · หมุด Type L1 ต้องปลดล็อก (DU-01)
        ★ 2.4.6 (เจ้าของงาน 26 ต.ค. 69 "ช่องติ๊กเปลี่ยน type หมุดตาม ให้เอาออก บังคับให้เปลี่ยนตาม type แปลงไปเลย") — Type แปลงไม่เปลี่ยน ⇒
          หมุดของแปลงที่ Type ไม่ตรงแปลงปรับให้ตรงในคำสั่งเดียวกับการแก้ (plan['sync_mk'] = {fid: Type เดิม}) · ไม่ปรับ (บอกใน
          plan['sync_note']): หมุดที่แชร์กับแปลงแฝด (คีย์เดิม + มีแฝด) · หมุด Type L1 ที่ล็อกอยู่ (ต้องปลดล็อก L1 — DU-01) ·
          Type แปลงว่าง/นอกรายการ/CT-RTK (ไม่รู้ว่าหมุดควรเป็นอะไร — แบบ 🏷 ที่ไม่ลามค่าผิดไปหมุด) · บัญชีไม่มีสิทธิ์คอลัมน์ Type ของหมุด
          sync=False ⇒ ยังไม่คิดชุดหมุด (ทางก่อนรอระบบกรม — _ep_after_lookup คิดใหม่หลังรออยู่แล้ว · ตรวจอิสระ ⚪7 ลดการอ่านหมุดซ้ำ)"""
        ch = plan.get("ch") or {}
        plan["type_mk"], plan["sync_mk"], plan["sync_note"] = [], {}, ""
        if not ch.get("type"):
            return self._ep_sync_plan(poly_lyr, point_lyr, feat, plan) if sync else True
        new = ch["type"][1]
        if new.upper() in _TYPE_NOT_ON_MARKER:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"{new} อยู่ในชั้น CT_ ของสาขาเท่านั้น — ตั้งเป็น Type ของแปลง/หมุดไม่ได้")
            return False
        if new not in self._CP_TYPES_ALL:            # ★ 2.4.3 (review 🟡3 · รายการตายตัว) ทางเรียกตรง
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"Type \"{new}\" ไม่อยู่ในรายการ Type ที่ใช้ได้ (" + " · ".join(self._CP_TYPES_ALL) + ") — ยกเลิก")
            return False
        if ch.get("key"):
            mk = list(plan.get("mk_ids") or [])
        else:
            info = self._parcel_markers(poly_lyr, point_lyr, feat)
            if info is None:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          "อ่านค่า UTM/รายชื่อหมุดของแปลงนี้ไม่ได้ — ยกเลิก (กันแก้ Type แปลงแล้วหมุดไม่ตาม)")
                return False
            if info["n_twin"] > 1:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          f"พบแปลงคีย์ซ้ำ (UTM เดียวกัน {info['n_twin']} แปลง) — เปลี่ยน Type อัตโนมัติไม่ได้\n"
                          "เพราะหมุดถูกแชร์ตามคีย์ จะไปโดนหมุดของแปลงแฝดด้วย · แก้คีย์ซ้ำก่อน")
                return False
            if self._parcel_locked_block(info, self._EP_TITLE, "เปลี่ยน Type แปลงนี้ไม่ได้"):
                return False
            mk = list(info["mk_ids"])
        plan["type_mk"] = mk if plan["flds"]["point"].get("Type") else []
        return True

    def _ep_sync_plan(self, poly_lyr, point_lyr, feat, plan):
        """★ 2.4.6 หมุดของแปลงที่ Type ไม่ตรง Type แปลง (Type แปลงไม่เปลี่ยน) ⇒ plan['sync_mk'] / plan['type_mk'] / plan['sync_note']
        -> True เสมอ (ไม่มีหมุดต้องปรับ/ปรับไม่ได้ ⇒ plan['sync_note'] บอกเหตุ · ไม่บล็อกงานแก้อื่น)"""
        tf, mtf = plan["flds"]["poly"].get("Type"), plan["flds"]["point"].get("Type")
        if not (tf and mtf):
            return True
        want = _marker_type_from_parcel(_txt(feat[tf]))
        if not want or want not in self._CP_TYPES_ALL:
            return True
        if (plan.get("ch") or {}).get("key"):
            cand, locked = list(plan.get("mk_ids") or []), {}     # ชุดที่ย้ายตามคีย์ผ่านด่านหมุดล็อกใน _ep_plan แล้ว
        else:
            info = self._parcel_markers(poly_lyr, point_lyr, feat)
            if info is None:
                plan["sync_note"] = "อ่านรายชื่อหมุดของแปลงนี้ไม่ได้ — ไม่ได้ปรับ Type หมุด"
                return True
            if info["n_twin"] > 1:
                plan["sync_note"] = (f"มีแปลงแฝด (UTM เดียวกัน {info['n_twin']} แปลง) — ไม่ปรับ Type หมุด "
                                     "(หมุดแชร์ตามคีย์กับแปลงแฝด)")
                return True
            cand = list(info["mk_ids"])
            locked = {} if self._l1_unlocked() else dict(info.get("locked") or {})
        if not cand:
            return True
        drift = {}
        mi = point_lyr.fields().indexOf(mtf)
        if mi < 0:
            return True
        it = point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(cand).setFlags(QgsFeatureRequest.NoGeometry)
                                   .setSubsetOfAttributes([mi]))
        try:
            for f in it:
                if _txt(f.attribute(mi)) != want:
                    drift[f.id()] = norm_type(f.attribute(mi)) or ""
        finally:
            it.close()
        skip = [fid for fid in drift if fid in locked]
        for fid in skip:
            drift.pop(fid)
        if skip:
            plan["sync_note"] = (f"หมุด Type L1 {len(skip):,} ดวง Type ไม่ตรงแปลง — ไม่ปรับ (ล็อก L1 อยู่ · "
                                 "ปลดล็อก L1 แล้วกด 📝 ใหม่ถ้าต้องการปรับ)")
        if drift and self._can_update_column(point_lyr, mtf) is False:
            # ★ (ตรวจอิสระ ⚪7) ไม่มีสิทธิ์ ⇒ ไม่ปรับ + บอก (ไม่บล็อกงานแก้อื่น · ไม่เด้งกล่อง — เดิมบัญชีแบบนี้แก้ 📝 อะไรไม่ได้เลย)
            plan["sync_note"] = (f"บัญชีนี้ไม่มีสิทธิ์แก้คอลัมน์ Type ของชั้นหมุด — ไม่ปรับ Type หมุด {len(drift):,} ดวง "
                                 "(แจ้งผู้ดูแลฐานข้อมูล)")
            return True
        plan["sync_mk"], plan["type_mk"] = drift, list(drift)
        return True

    def _ep_sync_lines(self, plan, final_type):
        """★ 2.4.6 บรรทัดกล่องยืนยันของการปรับ Type หมุดตามแปลง (Type แปลงไม่เปลี่ยน) — แจกแจง Type เดิม + เน้นหมุดชนิดอ้างอิง (แบบ 🏷)"""
        out = []
        drift = plan.get("sync_mk") or {}
        if drift:
            c = {}
            for o in drift.values():
                c[o] = c.get(o, 0) + 1
            tally = " · ".join(f"{o or '(ว่าง)'} {n:,}" for o, n in sorted(c.items(), key=lambda kv: (kv[0] != "", -kv[1], kv[0])))
            out.append(f"Type หมุด: ปรับ {len(drift):,} ดวงให้ตรงแปลง ({final_type}) — Type เดิม {tally}")
            ref = [o for o in drift.values() if o in L1_TYPES]
            # ★ (ตรวจอิสระ 🟡1) ผลกับการล็อกตามกรณีแบบ 🏷 (_change_type_sync_markers) — แปลง L1-TS: L1-RTK ถูกลด (ล็อกอ่อนลง) ·
            #   แปลงไม่ใช่ L1: ไม่ล็อกด้วย Type ของตัวเองอีก · แปลง L1-RTK: หมุด L1-TS ล็อกแรงขึ้น (ไม่ต้องเตือน)
            if "L1-RTK" in ref and final_type == "L1-TS":
                out.append("🔴 หมุด L1-RTK จะถูกลดเป็น L1-TS (ล็อกอ่อนลง: Transform 2 จุดไปต่อ L1-RTK ขยับได้)")
            elif ref and final_type not in L1_TYPES:
                out.append(f"🔴 ในนี้มีหมุดชนิดอ้างอิง (L1) {len(ref):,} ดวง — ปรับแล้วจะไม่ถูกล็อกด้วย Type ของตัวเองอีก")
        if plan.get("sync_note"):
            out.append("ℹ️ " + plan["sync_note"])
        return out

    def _ep_attrs(self, lyr, feat, v, air=False):
        """★ 2.4.6 คำขอค้นของ 📝 (ปุ่ม 🔍 ในกล่อง + หลังกด OK — แยกจาก _ep_lookup เดิม) — คีย์ + จุดกลาง/จุดในรูป (EPSG:24047) + สาขาของชั้น
        ★ 2.4.8 ขั้น D air = น.ส.3 ก คีย์ระวางรูปถ่าย ⇒ ตัวค้นไปหน้า QNS3K"""
        near_xy = _probe = _office = None
        try:
            c = feat.geometry().centroid().asPoint()
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            if lyr.crs() != dst:
                c = QgsCoordinateTransform(lyr.crs(), dst, QgsProject.instance()).transform(c)
            near_xy = (c.x(), c.y())
        except Exception:
            near_xy = None
        try:
            _probe = _probe_xy_24047(feat.geometry(), lyr.crs())     # ★ 2.3.9 ทางสำรอง iLands
        except Exception:
            _probe = None
        try:
            _office = _branch_office_of(lyr)                         # ★ 2.3.10 ล็อกสาขา
        except Exception:
            _office = None
        return {"m1": v["UTMMAP1"], "m2": v["UTMMAP2"], "m3": v["UTMMAP3"], "m4": v["UTMMAP4"],
                "scale": v["UTMSCALE"], "landno": v["LANDNO"], "near_xy": near_xy, "probe_xy": _probe,
                "office_seq": _office, "air": bool(air)}

    def _ep_mark_in_layer(self, poly_lyr, res, own=None):
        """★ 2.4.6 (เคสองครักษ์ #730 — ข้อความให้แก้คีย์เป็น #718 ที่มีแปลงในฐานแล้ว) แปลงของแผนที่กรมที่ตำแหน่งเดิม (history.now) /
        ใต้รูป (udm_here) มีคีย์นี้ในชั้นของเราแล้ว ⇒ p['in_layer'] = [gid] (ข้อความ _dol_in_layer_note) · อ่านไม่ได้/ไม่มีคีย์ = ไม่ใส่"""
        if not isinstance(res, dict) or poly_lyr is None:
            return res
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        if not pu:
            return res
        for p in (((res.get("history") or {}).get("now")), res.get("udm_here")):
            k = p.get("key") if isinstance(p, dict) else None
            if not k or p.get("in_layer") is not None:
                continue
            try:
                utm = "%s%s%s%02d%s%s" % (k[0], k[1], k[2], int(k[3]), k[4], k[5])
                p["in_layer"] = [t for t in self._utm_twin_fids(poly_lyr, pu, utm, _norm_utm(utm)) if t != own][:5]
            except Exception:
                p["in_layer"] = []
        return res

    def _ep_plan(self, poly_lyr, point_lyr, feat, flds, newv):
        """เตรียมงาน: หมุดที่จะเปลี่ยนคีย์ · แปลงแฝด · UTM ใหม่ซ้ำแปลงอื่น -> dict หรือ None (ยกเลิก/แจ้งแล้ว)"""
        pu = flds["poly"]["UTM"]
        old_raw = _txt(feat[pu])
        notes = []
        mk_ids = []
        # ★ 2.3.7 b19 (doc-verify E3) — UTM เท่าเดิมแต่ช่องระวาง/เลขที่ดินของแปลงไม่ตรง (ว่าง/ผิดรูป เช่น MAP3 '684' · LANDNO '0435')
        #   ⇒ หมุดของแปลงต้องได้ช่องเดียวกับแปลงด้วย (เดิมหาหมุดเฉพาะเมื่อ UTM เปลี่ยน ⇒ แปลงได้ช่องใหม่ หมุดค้างช่องเก่า)
        _fix_keys = bool(old_raw) and old_raw == newv["UTM"] and \
            any(_txt(feat[flds["poly"][k]]) != newv[k] for k in self._EP_KEYS)
        if not old_raw:
            notes.append("⚠️ แปลงนี้ไม่มี UTM เดิม — หาหมุดของแปลงไม่ได้ จะเปลี่ยนเฉพาะรูปแปลง (ตรวจ/เติมหมุดเอง)")
        elif old_raw != newv["UTM"] or _fix_keys:
            info = self._parcel_markers(poly_lyr, point_lyr, feat)
            if info is None:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          "อ่านรายชื่อหมุดของแปลงนี้ไม่ได้ (query ล้มเหลว) — ยกเลิก (กันแก้แปลงแล้วหมุดไม่ตาม)")
                return None
            mk_ids = list(info["mk_ids"])
            if info["n_twin"] > 1:
                # แปลงแฝด (UTM เดิมเดียวกัน): เปลี่ยนเฉพาะหมุดบนมุมของแปลงนี้ ที่ไม่ได้อยู่บนมุมของแปลงแฝดด้วย
                mine = [QgsPointXY(v.x(), v.y()) for v in feat.geometry().vertices()]
                twin_v = []
                # ★ 2.3.7 (ให้ตรงกับ 🍩 ข้อ 10 d) — แปลงแฝดชุดเดียวกับที่นับ n_twin (normalise · _utm_twin_fids)
                #   เดิมดึงมุมของแฝดด้วย old_raw ตรงทุกตัวอักษร ⇒ แฝด 'X ' / 'X.0' ถูกนับแต่ไม่ถูกดึงมุมมาเทียบ
                #   ⇒ หมุดบนมุมร่วมกับแฝดถูกเปลี่ยนคีย์ไปด้วย (แฝดเสียหมุด)
                _tw = [t for t in (info.get("twin_fids") or []) if t != feat.id()]
                it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(_tw)) if _tw else None
                try:
                    for tf in (it if it is not None else []):
                        if tf.hasGeometry():
                            twin_v.extend(QgsPointXY(v.x(), v.y()) for v in tf.geometry().vertices())
                finally:
                    if it is not None:
                        it.close()
                keep, at_shared = [], {}
                for mf in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(mk_ids)):
                    if not mf.hasGeometry():
                        continue
                    p = mf.geometry().asPoint()
                    near = [i for i, q in enumerate(mine) if p.distance(q) <= 0.01]
                    if not near:
                        continue
                    if not _fix_keys and any(p.distance(q) <= 0.01 for q in twin_v):
                        # UTM เปลี่ยน ⇒ หมุดมุมร่วมต้องอยู่กับแฝด · ★ b19 E3 UTM เท่าเดิม ⇒ ยังเป็นหมุดของทั้งคู่ แก้ช่องให้ตรง UTM ได้
                        # ★ 2.4.2 — จัดกลุ่มตามมุมของแปลงนี้ (มุมใกล้สุด · คีย์ปัดมิลลิเมตร เพราะจุดปิดวงซ้ำจุดแรก)
                        _c = mine[min(near, key=lambda i: p.distance(mine[i]))]
                        at_shared.setdefault((round(_c.x(), 3), round(_c.y(), 3)), []).append(mf.id())
                        continue
                    keep.append(mf.id())
                moved = single = 0
                for _ids in at_shared.values():
                    if len(_ids) >= 2:
                        # ★ 2.4.2 (เหตุ 15 ต.ค. ปทุมฯ 37 → 688 → 37) — มุมร่วมกับแฝดมีหมุด UTM เดิมซ้อน ≥ 2 ดวง ⇒ ดวงหนึ่งเป็นของแปลงนี้
                        #   (เปลี่ยนคีย์ไปซ้ำแปลงข้างเคียงแล้วเปลี่ยนกลับ: เดิมไม่เปลี่ยนทั้งคู่ ⇒ แปลงนี้มุมไม่มีหมุด + แฝดมีหมุดซ้อน)
                        #   ⇒ ย้ายดวงใหม่สุด 1 ดวงมาเป็นของแปลงนี้ (งานที่ยังไม่บันทึกก่อน แล้ว gid มากสุด) · ที่เหลือคงไว้กับแฝด
                        keep.append(sorted(_ids, key=lambda f: (f >= 0, -abs(f)))[0])
                        moved += 1
                    else:
                        single += 1
                notes.append(f"⚠️ มีแปลงแฝด (UTM เดิมเดียวกัน {info['n_twin']} แปลง) — เปลี่ยนเฉพาะหมุดของแปลงนี้ {len(keep)} ดวง"
                             + (f" · มุมร่วมกับแปลงแฝด {moved} มุมมีหมุดซ้อน ⇒ ย้ายมาเป็นของแปลงนี้มุมละ 1 ดวง" if moved else "")
                             + (f" · มุมร่วมอีก {single} มุมมีหมุดดวงเดียวที่แปลงแฝดใช้อยู่ ไม่เปลี่ยน "
                                "(มุมนั้นของแปลงนี้ต้องเติมหมุดเอง)" if single else ""))
                mk_ids = keep
            # ★ 2.4.0 (review DU-01) — หมุดล็อก (Type L1) ในชุดที่จะเปลี่ยนคีย์ ⇒ ต้องปลดล็อก L1 ก่อน (แบบแก้ชื่อหมุด)
            if self._parcel_locked_block(info, self._EP_TITLE, "แก้ข้อมูลแปลงนี้ไม่ได้", fids=mk_ids):
                return None
        # UTM ใหม่ซ้ำแปลงอื่น (คำตัดสิน 3 ต.ค.: เตือน + ยืนยันเอง)
        dup = []
        if newv["UTM"] != old_raw:
            # ★ 2.3.7 (ให้ตรงกับ 🍩 ข้อ 10 d) — เทียบแบบ normalise (แปลงที่คีย์มีช่องว่างหัว/ท้าย/'.0' นับว่าซ้ำด้วย)
            dup = [t for t in self._utm_twin_fids(poly_lyr, pu, newv["UTM"], _norm_utm(newv["UTM"]))
                   if t != feat.id()]
        return {"poly_lid": poly_lyr.id(), "point_lid": point_lyr.id(), "fid": feat.id(), "flds": flds,
                "old": {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS}, "old_utm": old_raw,
                "new": newv, "mk_ids": mk_ids, "dup": dup, "notes": notes,
                "dup_info": self._ep_dup_info(poly_lyr, feat, flds, dup)}

    def _ep_dup_info(self, poly_lyr, feat, flds, dup):
        """★ 2.4.2 — แปลงที่ UTM ใหม่ไปซ้ำ -> [(gid, Type, มุมร่วมกับแปลงนี้ ≤ 1 ซม., ติดกัน ≤ 1 ซม.)] (ไม่เกิน 20 แปลง)
        ใช้บอกในกล่องเตือนว่ามุมร่วมกี่มุมจะมีหมุด UTM เดียวกันซ้อน · ตรวจไม่ได้ = [] (กล่องเตือนยังขึ้นด้วยรายชื่อ gid)"""
        if not dup:
            return []
        out = []
        try:
            g0 = feat.geometry()
            mine = {}
            for v in g0.vertices():
                mine.setdefault((round(v.x(), 3), round(v.y(), 3)), QgsPointXY(v.x(), v.y()))
            tf_name = flds["poly"].get("Type")
            it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(dup)[:20]))
            try:
                for tf in it:
                    tv = [QgsPointXY(v.x(), v.y()) for v in tf.geometry().vertices()] if tf.hasGeometry() else []
                    k = sum(1 for p in mine.values() if any(p.distance(q) <= 0.01 for q in tv))
                    touch = bool(tv) and not g0.isEmpty() and tf.geometry().distance(g0) <= 0.01
                    out.append((tf.id(), _txt(tf[tf_name]) if tf_name else "", k, touch))
            finally:
                it.close()
        except Exception:
            _log_exc("📝 นับมุมร่วมกับแปลงที่ UTM ซ้ำไม่สำเร็จ")
            return []
        return out

    def _ep_dup_confirm(self, plan):
        """★ 2.4.2 (เจ้าของงานสั่ง 15 ต.ค. "เวลาแก้ไขแล้วไปซ้ำกัน ให้เตือนด้วย") — กล่องเตือนแยกเมื่อ UTM ใหม่ซ้ำแปลงอื่น
        (เดิมเป็นบรรทัดเดียวในกล่องยืนยันยาว ๆ — เหตุ 15 ต.ค. ปทุมฯ: พิมพ์ 688 ที่เป็นเลขของแปลงข้างเคียง แล้วตอบยืนยัน)
        ปุ่มตั้งต้น No · คืน True = ตั้งใจให้เป็นแปลงแฝด (ทำต่อ)"""
        dup, info = plan.get("dup") or [], plan.get("dup_info") or []
        if not dup:
            return True
        n = plan["new"]
        lines = [f"UTM ใหม่ {n['UTM']} (ระวาง {n['UTMMAP1']} {n['UTMMAP2']} {n['UTMMAP3']}-{n['UTMMAP4']} "
                 f"ที่ดิน {n['LANDNO']}) ซ้ำกับแปลงอื่นที่มีอยู่แล้ว {len(dup)} แปลง:"]
        if info:
            for gid, tp, k, touch in info[:5]:
                lines.append(f"  • gid {gid}" + (f" ({tp})" if tp else "")
                             + (f" — ติดกับแปลงนี้ ใช้มุมร่วม {k} มุม" if k else
                                (" — ติดกับแปลงนี้" if touch else " — ไม่ติดกับแปลงนี้")))
        else:
            lines.append("  • gid " + ", ".join(str(x) for x in dup[:5]))
        if len(dup) > 5:
            lines.append(f"  • … อีก {len(dup) - 5} แปลง")
        k_all = sum(k for _g, _t, k, _tc in info)
        lines += ["", "ถ้าเปลี่ยน แปลงนี้จะเป็นแปลงแฝด (UTM เดียวกัน) กับแปลงข้างบน"
                  + (" — ใช้ได้เฉพาะโฉนดเดียวกันที่มีหลายรูป" if not k_all else "")]
        if k_all:
            lines.append(f"⚠️ มุมร่วม {k_all} มุมจะมีหมุด UTM เดียวกันซ้อน 2 ดวง (ด่านก่อนบันทึกจะเตือนหมุดซ้อน) "
                         "และแยกไม่ได้แล้วว่าดวงไหนเป็นของแปลงไหน")
        lines += ["ถ้าพิมพ์เลขผิด ให้ตอบ No · ถ้าเปลี่ยนไปแล้ว ให้กด ↺ Undo ของปลั๊กอิน (คืนแปลงและหมุดครบ)",
                  "", "ตั้งใจให้เป็นแปลงแฝดจริงหรือไม่?"]
        ans = self._ask(QtWidgets.QMessageBox.Warning, "UTM ซ้ำกับแปลงอื่น", "\n".join(lines),
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            self.iface.messageBar().pushMessage(self._EP_TITLE, "ยกเลิก — ยังไม่ได้แก้อะไร (UTM ใหม่ซ้ำกับแปลงอื่น)",
                                                level=0, duration=6)
            return False
        return True

    def _ep_lookup(self, plan):
        """ดึงเนื้อที่ทะเบียนจากระบบกรม (public · thread เบื้องหลัง) แล้วไปขั้นยืนยัน
        ★ 2.4.6 ค้นในกล่องแล้ว (plan['lk'] ของคีย์นี้) ⇒ ใช้ผลนั้นไปขั้นยืนยันเลย ไม่ถามระบบกรมซ้ำ"""
        lk = plan.get("lk")
        if lk and _txt(lk.get("utm")) == _txt(plan["new"].get("UTM")):
            self._ep_after_lookup(plan, lk.get("res"), lk.get("err"))
            return
        _w0 = getattr(self, "_ep_worker", None)
        try:
            if _w0 is not None and _w0.isRunning():
                self.iface.messageBar().pushMessage(self._EP_TITLE, "กำลังดึงเนื้อที่อยู่ — รอผลก่อน", level=1, duration=5)
                return
        except Exception:
            pass
        v = plan["new"]
        lyr = QgsProject.instance().mapLayer(plan["poly_lid"])
        # ★ 2.4.8 ขั้น D — ชนิดเอกสารหลังแก้เป็น น.ส.3 ก + คีย์ระวางรูปถ่าย (ไม่มี UTMMAP3) ⇒ หน้า QNS3K
        _ch, _df = plan.get("ch") or {}, (plan.get("flds") or {}).get("poly", {}).get("DOC_TYPE")
        try:
            _f0 = lyr.getFeature(plan["fid"])
            _fd = (_ch["doc"][1] if _ch.get("doc") else (_txt(_f0[_df]) if _df else ""))
        except Exception:
            _f0, _fd = None, ""
        _air = _txt(_fd) == self._DOC_AIR and not _txt(v.get("UTMMAP3"))
        try:
            attrs = self._ep_attrs(lyr, _f0, v, air=_air)                         # ★ 2.4.6 ใช้ร่วมกับปุ่ม 🔍 ในกล่อง
        except Exception:
            attrs = {"m1": v["UTMMAP1"], "m2": v["UTMMAP2"], "m3": v["UTMMAP3"], "m4": v["UTMMAP4"],
                     "scale": v["UTMSCALE"], "landno": v["LANDNO"], "near_xy": None, "probe_xy": None, "office_seq": None,
                     "air": _air}
        if _txt(_fd) in self._DOC_UTMDOC:             # ★ 2.4.8 ขั้น E1 โฉนดตราจอง/ตราจองฯ ⇒ หน้าของชนิดนั้นด้วยคีย์ UTM
            attrs.update(utmdoc=True, doc=_txt(_fd))
        busy = QtWidgets.QProgressDialog(
            f"กำลังดึงเนื้อที่ทะเบียนจากระบบกรม...\nระวาง {self._dol_rawang_text(attrs)}", None, 0, 0, self.iface.mainWindow())
        busy.setWindowTitle(self._EP_TITLE)
        busy.setCancelButton(None)
        busy.setWindowModality(QtCore.Qt.WindowModal)
        busy.show()
        # ★ 2.4.2 rc4 (เจ้าของงาน 21 ต.ค. 69 "ในปุ่มแก้ไขข้อมูลรูปแปลง ถ้าใน arcgis ไม่เจอ ให้ไปหาใน LIS ด้วย")
        #   ค้นทะเบียน iLands แบบ 🔍 (ไม่พบ · ชั้นรอจด · แผนที่บอกไม่มีทะเบียน · ยืนยันแปลงไม่ได้) · ยังไม่เข้าสู่ระบบ ⇒ เด้งกล่องเข้าสู่ระบบ
        w = ParcelLookupWorker(attrs, zone=47, lis_more=True)
        self._ep_worker = w
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)

        def _drop(_w=w):
            try:
                self._net_workers.remove(_w)
            except Exception:
                pass
            try:
                _w.deleteLater()          # finished ยิงหลัง thread จบจริงแล้ว — ลบปลอดภัย (ไม่ลบใน done/fail)
            except Exception:
                pass

        def _end(res, err):
            try:
                busy.close()
                busy.deleteLater()
            except Exception:
                pass
            if not getattr(self, "_alive", True):
                return
            # ★ 2.4.6 คีย์ชั้นประวัติ ⇒ เด้งกล่องเข้าสู่ระบบเหมือนกรณีอื่น (2.4.3 rc5 ข้าม 'hist' เพราะผลทะเบียนใช้ไม่ได้ ·
            #   ตอนนี้ทะเบียนยืนยันได้ว่าโฉนดยังใช้อยู่ — _ep_hist_deed)
            if err is None and isinstance(res, dict) and res.get("lis") == "login":
                # ★ 2.4.2 rc4 — ต้องค้นทะเบียน iLands แต่ยังไม่เข้าสู่ระบบ ⇒ กล่องเข้าสู่ระบบ แล้วค้นต่อ (ยกเลิก = ผลจากแผนที่)
                self._dol_lis_continue(res, attrs, lambda r: self._ep_after_lookup(plan, r, None))
                return
            self._ep_after_lookup(plan, res, err)
        w.finished.connect(_drop)
        w.done.connect(lambda res: _end(res, None))
        w.fail.connect(lambda msg: _end(None, msg))
        w.start()

    @staticmethod
    def _ep_area_result(res, err, shape_m2=None):
        """ผลจากระบบกรม -> {'area': ตร.ม. หรือ None, 'regis': ค่าใหม่หรือ None, 'note': ข้อความ}
        คำตัดสิน 3 ต.ค.: ดึงไม่ได้ = AREA/REGIS คงเดิม + เตือน · ระบบกรมตอบไม่มีทะเบียน = REGIS 'ไม่มีทะเบียน'
        ★ 2.4.6 shape_m2 = เนื้อที่รูป (ตร.ม.) — คีย์ชั้นประวัติที่ทะเบียน iLands ยืนยัน (_ep_hist_deed) ⇒ ใช้ผลทะเบียนพร้อมคำเตือน
          ('hist_ok') · ไม่ส่ง = เทียบไม่ได้ = บล็อกแบบเดิม"""
        keep = "คงเนื้อที่ทะเบียนเดิม — กดปุ่มนี้ซ้ำภายหลังเพื่อดึงใหม่"
        if err:
            return {"area": None, "regis": None, "note": f"⚠️ ดึงเนื้อที่ทะเบียนจากระบบกรมไม่ได้ ({err}) — {keep}"}
        # ★ 2.4.3 rc4 (ผลตรวจ Windows rc3 🟡1 · เจ้าของงาน 23 ต.ค. "ไม่นับเนื้อที่จากชั้นประวัติในด่านโฉนด") — คีย์ที่แผนที่กรมยกเลิกแล้ว
        #   (ชั้นประวัติอย่างเดียว) ⇒ ➕/📝 ไม่ใช้ผลทะเบียน: ไม่เติม AREA/REGIS · ไม่ล็อกชนิดเอกสาร · ให้แก้คีย์เป็นเลขปัจจุบันก่อน
        #   (🔍 ยังเปิดภาพลักษณ์ + กล่องเทียบเนื้อที่พร้อมคำเตือน) · ★ 2.4.3 rc5 (ผลตรวจ Windows rc4 🟡1) ไม่ว่าผลจะมาทางไหน
        #   (เดิมเฉพาะ via='lis' ⇒ ไม่ได้เข้าสู่ระบบ/ทะเบียนไม่มี ⇒ หมายเหตุ "ไม่พบ" ไม่บอกให้แก้คีย์)
        if _ep_hist_key(res):
            # ★ 2.4.6 (เจ้าของงาน 26 ต.ค. 69 "ทำข้อ 1 2" · เคสองครักษ์ #730) — ทะเบียนยืนยันว่าโฉนดยังใช้อยู่ (เนื้อที่ตรงรูป ±10%) ⇒ ใช้ได้
            #   พร้อมคำเตือน (ผู้เรียกถามยืนยันอีกครั้ง) · ไม่ผ่าน ⇒ บล็อกแบบเดิม + เหตุเป็นตัวเลข + ทางไปต่อ (hist_why = ข้อความของด่านโฉนด)
            _ok, _d, _why = _ep_hist_deed(res, shape_m2)
            if _ok:
                return {"area": _dol_area_m2(res.get("area")), "regis": "มีทะเบียน", "via": "lis", "hist": True, "hist_ok": True,
                        "note": "⚠️ " + _ep_hist_ok_note(res, shape_m2), "reg": _reg_vals(res)}
            _hw = _ep_hist_block_note(res, _why)
            return {"area": None, "regis": None, "hist": True, "hist_why": _hw, "note": "⚠️ " + _hw}
        if not isinstance(res, dict) or res.get("not_found"):
            # ★ rc5 — เลขถูกยกเลิก/รอจด/ผลทะเบียน iLands · ยังไม่เข้าสู่ระบบ ⇒ บอกทางค้นทะเบียน (ทางสุดท้าย ต้อง login)
            _lg = (" · เข้าสู่ระบบ DOL (ปุ่ม 📐 หลักฐานการรังวัด) แล้วค้นใหม่ เพื่อค้นต่อในทะเบียน iLands"
                   if isinstance(res, dict) and res.get("lis") == "login" else "")
            # ★ 2.3.11 — ค้นแบบล็อกสาขา: ไม่พบ "ในสาขานี้" · เลขนี้เป็นของสำนักงานอื่น ⇒ บอกตรง ๆ ที่หัวหมายเหตุ (ไม่ซ้ำบรรทัด ℹ️)
            _d = res if isinstance(res, dict) else {}
            if _d.get("air"):
                # ★ 2.4.8 ขั้น D น.ส.3 ก — ค้นหน้า QNS3K อย่างเดียว (ไม่มีแผนที่กรม/สำนักงานอื่นให้บอก)
                return {"area": None, "regis": None,
                        "note": {"none": "⚠️ ทะเบียน iLands (หน้า น.ส.3 ก) ไม่พบคีย์ระวางรูปถ่ายนี้",
                                 "error": "⚠️ ค้นทะเบียน iLands (หน้า น.ส.3 ก) ไม่สำเร็จ"
                                          + (f" ({_txt(_d.get('lis_error'))})" if _d.get("lis_error") else "")
                                 }.get(_d.get("lis"), "⚠️ ยังไม่ได้ค้นทะเบียน iLands (หน้า น.ส.3 ก)") + f" — {keep}" + _lg}
            if _d.get("docsearch") or _d.get("utmdoc"):
                # ★ 2.4.8 กลุ่ม ข (เลขที่เอกสาร) · ตราจอง (คีย์ UTM) ค้นหน้าทะเบียนของชนิดนั้นอย่างเดียว — เดิมตกไปข้อความของโฉนด
                #   "ระบบกรมไม่พบแปลงตามระวาง/เลขที่ดินนี้" (ไม่ได้ค้นด้วยระวางสำหรับกลุ่ม ข · ไม่บอกว่าค้นไม่สำเร็จ)
                _pg = "หน้า " + (_txt(_d.get("doc")) or "เอกสาร")
                _what = ("เลขที่ " + _txt(_d.get("no")) + (f" หมู่ {_txt(_d.get('moo'))}" if _txt(_d.get("moo")) else "")
                         + (f" ต.{_txt(_d.get('tambol'))}" if _txt(_d.get("tambol")) else "")
                         + (f" อ.{_txt(_d.get('amphur'))}" if _txt(_d.get("amphur")) else "")) if _d.get("docsearch") else "คีย์ระวางนี้"
                return {"area": None, "regis": None,
                        "note": {"none": f"⚠️ ทะเบียน iLands ({_pg}) ไม่พบ{_what}",
                                 "error": f"⚠️ ค้นทะเบียน iLands ({_pg}) ไม่สำเร็จ"
                                          + (f" ({_txt(_d.get('lis_error'))})" if _d.get("lis_error") else "")
                                 }.get(_d.get("lis"), f"⚠️ ยังไม่ได้ค้นทะเบียน iLands ({_pg})") + f" — {keep}" + _lg}
            _oo = str((_d.get("other_office") or {}).get("office_seq") or "").strip()
            if _oo:
                _หัว = f"⚠️ เลขนี้เป็นแปลงของสำนักงานที่ดินอื่น (รหัส {_oo}) ไม่มีในสำนักงานที่ดินของสาขานี้ — {keep}"
            elif _d.get("arc_miss"):            # ★ 2.4.1 แผนที่มีเลขนี้ แต่ถามทะเบียนที่จุดกลางไม่ได้
                # ★ 2.4.1 rc2 (ผลตรวจ Windows rc1 ข้อสังเกต 6) — กดซ้ำได้ผลเดิมจนกว่าข้อมูลของกรมจะแก้ ⇒ ไม่ชวนกดซ้ำ
                _หัว = ("⚠️ แผนที่กรมมีเลขนี้ แต่ระบบทะเบียนไม่มีข้อมูลที่ตำแหน่งของแปลงนั้น" if _d.get("arc_miss") == "udm_empty"
                        else "⚠️ แผนที่กรมมีเลขนี้ แต่ไม่มีพิกัดจุดกลางของแปลง") + " — คงเนื้อที่ทะเบียนเดิม"
            elif _d.get("branch_office"):
                _หัว = f"⚠️ ระบบกรมไม่พบแปลงของสาขานี้ตามระวาง/เลขที่ดินนี้ — {keep}"
            else:
                _หัว = f"⚠️ ระบบกรมไม่พบแปลงตามระวาง/เลขที่ดินนี้ — {keep}"
            return {"area": None, "regis": None,
                    "note": _หัว
                            + ((_dol_here_hint(res) + _dol_more_hint(res, skip_other=bool(_oo))).replace("\n\n", " · ")
                               if isinstance(res, dict) else "") + _lg}
        # ★ 2.3.7 b19 (doc-verify E10) — ตัดสิน "ยืนยันแปลงไม่ได้" ก่อน "ไม่มีทะเบียน": dol_api หา MAP_PARCEL_SEQ ของระวางนี้
        #   ในคำตอบ UDM ไม่เจอ ⇒ ใช้ค่าเดี่ยวที่อาจเป็นของแปลงข้างเคียง (not_registered ด้วย) · เดิมตั้ง REGIS 'ไม่มีทะเบียน'
        #   ให้แปลงที่คลิกได้จากผลของแปลงอื่น ⇒ ยืนยันไม่ได้ = คง AREA/REGIS (แบบเดียวกับเนื้อที่)
        # ★ 2.4.2 rc4 — 📝/➕ ค้นทะเบียน iLands แบบ 🔍 แล้ว ⇒ ต่อท้ายผลของทะเบียน (ไม่มีเลขนี้ · ค้นไม่สำเร็จ · ไม่ได้เข้าสู่ระบบ)
        _lh = _dol_lis_hint(res).replace("\n\n", " · ")
        if (res.get("air") or res.get("docsearch") or res.get("utmdoc")) and not res.get("verified"):   # ★ ขั้น E/E1 ก็เช่นกัน
            # ★ 2.4.8 ขั้น D — คีย์ระวางรูปถ่ายเดียวกันมีหลายฉบับคนละตำบล (พบจริงที่บางละมุง) ⇒ ยังเลือกฉบับไม่ได้ · คงค่าเดิม
            return {"area": None, "regis": None,
                    "note": f"⚠️ {_txt(res.get('area_why')) or 'ทะเบียน iLands มีคีย์นี้หลายฉบับ — เลือกฉบับไม่ได้'} · {keep}"}
        if res.get("via") == "lis" and res.get("cross_office"):
            # ★ 2.4.2 rc4 — ทะเบียนมีเลขนี้ แต่ชั้นไม่ล็อกสาขา + แผนที่มีเลขนี้หลายสำนักงาน ⇒ อาจเป็นแปลงของสำนักงานอื่น = ยืนยันไม่ได้
            return {"area": None, "regis": None,
                    "note": f"⚠️ ทะเบียน iLands มีเลขนี้ แต่ระวาง/เลขที่ดินนี้มี {res.get('cross_office')} แปลงบนแผนที่กรม (คร่อมสาขา) "
                            f"— ยืนยันไม่ได้ว่าเป็นแปลงนี้ · {keep}"}
        if not res.get("verified"):
            _a = _txt(res.get("area"))
            return {"area": None, "regis": None,
                    "note": "⚠️ ระบบกรมตอบแปลงที่ยืนยันไม่ได้ว่าตรงกับระวางนี้"
                            + (f" (เนื้อที่ที่ได้ {_a})" if _a else "") + f" — {keep}" + _lh}
        if res.get("not_registered") and res.get("via") == "arcgis_temp":
            # ★ rc5 — ชั้นแปลงรอจดของกรม + UDM ยืนยันคีย์ตรง แต่ยังไม่มีทะเบียน ⇒ 'รอจดทะเบียน' (ค่าเดียวกับ _CP_REGIS)
            return {"area": None, "regis": "รอจดทะเบียน",
                    "note": "ℹ️ พบในชั้นแปลงรอจดทะเบียนของกรม (รังวัดแล้ว ยังไม่จดทะเบียน) — ตั้ง REGIS = 'รอจดทะเบียน' · คงเนื้อที่เดิม"
                            + _lh}
        if res.get("not_registered"):
            return {"area": None, "regis": "ไม่มีทะเบียน",
                    "note": "⚠️ ระบบกรมแจ้งว่าแปลงนี้ไม่มีทะเบียน — ตั้ง REGIS = 'ไม่มีทะเบียน' · คงเนื้อที่เดิม" + _lh}
        if res.get("via") == "lis":
            # ★ rc5 — พบในทะเบียน iLands ⇒ มีทะเบียนแน่
            # ★ 2.4.2 E9 — เนื้อที่จากหน้ารายละเอียดของทะเบียน (คีย์ในหน้าตรงทุกท่อน · ทะเบียนตอบรายการเดียว) · ไม่ได้ ⇒ เนื้อที่คงเดิม + เหตุ
            #   (เดิม: ตารางผลค้นของหน้า LIS ไม่มีเนื้อที่ ⇒ ไม่เคยได้เนื้อที่จากทางนี้)
            _โฉนด = (f"น.ส.3 ก เลขที่ {_txt(res.get('parcel_no')) or '-'}" if res.get("air") else          # ★ 2.4.8 ขั้น D
                     f"{_txt(res.get('parcel_type'))} เลขที่ {_txt(res.get('parcel_no')) or '-'}"            # ★ ขั้น E กลุ่ม ข
                     + (f" หมู่ {_txt(res.get('moo'))}" if _txt(res.get("moo")) else "") if res.get("docsearch") else
                     f"{_txt(res.get('parcel_type'))} เลขที่ {_txt(res.get('parcel_no')) or '-'}"            # ★ ขั้น E1 ตราจอง
                     + (f" · หน้าสำรวจ {_txt(res.get('survey_no'))}" if _txt(res.get("survey_no")) else "") if res.get("utmdoc") else
                     f"โฉนด {_txt(res.get('parcel_no')) or '-'} · หน้าสำรวจ {_txt(res.get('survey_no')) or '-'}")
            m2 = _dol_area_m2(res.get("area"))
            if m2 is not None and m2 <= 0:            # ★ 2.4.9 ทะเบียนตอบ 0-0-0 = ไม่มีเนื้อที่ (เดิมเขียน AREA 0)
                m2, res = None, dict(res, area_why=_txt(res.get("area_why")) or "ทะเบียนตอบเนื้อที่ 0-0-0")
            if m2 is None:
                _why = _txt(res.get("area_why"))
                return {"area": None, "regis": "มีทะเบียน", "reg": _reg_vals(res),
                        "note": f"{_dol_via_note(res)} ({_โฉนด}) — ไม่ได้เนื้อที่ทะเบียน" + (f" ({_why})" if _why else "")
                                + f" · {keep}"}
            return {"area": m2, "regis": "มีทะเบียน", "via": "lis", "reg": _reg_vals(res),
                    "note": f"เนื้อที่ทะเบียนจากทะเบียน iLands: {_rngw(m2)} ไร่-งาน-วา = {m2:,.2f} ตร.ม. "
                            f"({_โฉนด} · {_dol_via_note(res)})"}
        m2 = _dol_area_m2(res.get("area"))
        if m2 is None:
            return {"area": None, "regis": None,
                    "note": f"⚠️ อ่านเนื้อที่จากระบบกรมไม่ได้ ('{_txt(res.get('area'))}') — {keep}"}
        if m2 <= 0:
            # ★ 2.4.9 (เจ้าของงาน 27 ต.ค. 69 ภาพ 📝 gid 86039 "นสล ผิดที่") ระบบกรมตอบ 0-0-0 (เช่น น.ส.ล. นย146) = ไม่มีเนื้อที่ —
            #   เดิมขึ้น "→ 0.00 ตร.ม." และจะเขียน AREA 0 · ทะเบียนยังยืนยันแปลงได้ ⇒ REGIS/ข้อมูลทะเบียนตามผลเดิม
            return {"area": None, "regis": "มีทะเบียน", "via": res.get("via"), "reg": _reg_vals(res),
                    "note": f"ระบบกรมไม่มีเนื้อที่ของแปลงนี้ (ตอบ 0-0-0) — {keep}"}
        note = f"เนื้อที่ทะเบียนจากระบบกรม: {_rngw(m2)} ไร่-งาน-วา = {m2:,.2f} ตร.ม."
        if (res.get("match_count") or 1) > 1:
            note += (f" (พบเลขนี้ {res.get('match_count')} แปลงในสาขานี้ — เลือกแปลงที่ใกล้รูปนี้ที่สุดแล้ว)"   # ★ 2.3.11
                     if res.get("branch_office") else " (ระวางคร่อมสาขา — เลือกแปลงที่ใกล้รูปนี้ที่สุดแล้ว)")
        if _dol_via_note(res):                   # ★ rc5 — udm_point · ชั้นรอจด · ชั้นประวัติ
            note += " (%s)" % _dol_via_note(res)
        # ★ 2.4.3 (review ⚪5) via = ที่มาของเนื้อที่ (ด่านโฉนดสุดท้ายใน _ep_apply ไม่นับชั้นประวัติ)
        return {"area": m2, "regis": "มีทะเบียน", "note": note, "via": res.get("via"), "reg": _reg_vals(res)}     # ★ 2.4.8 reg

    @staticmethod
    def _ep_deed_block(res, ar):
        """★ 2.4.3 ด่านโฉนดที่ดินของ ➕/📝 (เจ้าของงาน 21 ต.ค. 69 "ถ้าเป็นโฉนดที่ดิน ต้องค้นหาทะเบียนและได้เนื้อที่ทะเบียนมาด้วย
        และคีย์ไม่ซ้ำ ถึงจะสร้างได้" · "ปุ่มแก้ไขข้อมูลด้วย … ถึงจะเปลี่ยนได้") — ar = ผล `_ep_area_result`
        -> None = ผ่าน · ข้อความ = เหตุที่บล็อก
        คำตัดสิน: ไม่ได้เนื้อที่ (ไม่พบ · กรมบอกรอจด · ระบบกรมล่ม · ยังไม่เข้าสู่ระบบ LIS) = บล็อกทุกกรณี ·
                  เนื้อที่จากชั้นประวัติแผนที่กรม (เลขถูกยกเลิก/เปลี่ยนแล้ว) ไม่นับ"""
        if _ep_hist_key(res):                                    # ★ 2.4.3 rc4 (ผลตรวจ Windows rc3 🟡1) · rc5 ทุกทาง (rc4 🟡1)
            if ar.get("hist_ok") and ar.get("area") is not None:
                return None                                      # ★ 2.4.6 ทะเบียนยืนยัน ⇒ ผ่าน (ผู้เรียกถามยืนยันพร้อมคำเตือน)
            return ar.get("hist_why") or ((_EP_HIST_WHY if res.get("via") == "lis" else _EP_HIST_MAP_WHY) + _dol_history_where(res))
        if ar.get("area") is not None:
            if isinstance(res, dict) and res.get("via") == "arcgis_history":
                return "พบแค่ในชั้นประวัติของแผนที่กรม (เลขนี้ถูกยกเลิก/เปลี่ยนไปแล้ว) — ใช้เป็นเนื้อที่ทะเบียนของโฉนดไม่ได้"
            # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪5 · เจ้าของงาน 22 ต.ค. "บล็อก") — ได้เนื้อที่แต่ทะเบียนบอกว่าเป็นชนิดอื่น
            #   (เช่น น.ส.3 ก) ⇒ เป็นโฉนดที่ดินไม่ได้ · ทะเบียนไม่บอกชนิด/อ่านชนิดไม่ออก ⇒ ด่านเดิม
            _pt = _txt(res.get("parcel_type")) if isinstance(res, dict) else ""
            _rd = _dol_doc_code(_pt)
            if _rd and _rd != "โฉนดที่ดิน":
                return f"ทะเบียนบอกว่าแปลงนี้เป็น {_pt} ไม่ใช่โฉนดที่ดิน — เลือกชนิดเอกสารให้ตรงทะเบียน"
            return None
        why = {"รอจดทะเบียน": "กรมแจ้งว่ารอจดทะเบียน (ยังไม่มีเนื้อที่ทะเบียน)",
               "ไม่มีทะเบียน": "กรมแจ้งว่าแปลงนี้ไม่มีทะเบียน",
               "มีทะเบียน": "พบในทะเบียน แต่ไม่ได้เนื้อที่ทะเบียน"}.get(ar.get("regis"))
        if why is None:
            why = _txt(ar.get("note")).split(" — ")[0].replace("⚠️ ", "").replace("ℹ️ ", "") or "ไม่ได้เนื้อที่ทะเบียน"
        _lis = (res or {}).get("lis") if isinstance(res, dict) else None
        if _lis == "login":
            why += " · ยังไม่ได้ค้นทะเบียน iLands (ต้องเข้าสู่ระบบ)"
        elif _lis == "skipped":
            why += " · ยกเลิกการเข้าสู่ระบบทะเบียน iLands"
        elif _lis == "busy":                          # ★ 2.4.3 (review ⚪6) ไม่ได้ค้นเพราะมีงานอื่นค้าง — ผู้ใช้ไม่ได้ยกเลิก
            why += " · ยังไม่ได้ค้นทะเบียน iLands (มีงานค้นทะเบียนอื่นหรือกล่องเข้าสู่ระบบค้างอยู่ — ปิดงานนั้นแล้วลองใหม่)"
        return why

    def _ep_after_lookup(self, plan, res, err):
        self._dol_log_lis_trace(res)                  # ★ 2.4.2 rc4 (ผลตรวจ Windows rc3 ข้อพบ 7)
        ready = self._ep_ready_again()
        if not ready:
            return
        poly_lyr, point_lyr = ready
        if (poly_lyr.id(), point_lyr.id()) != (plan["poly_lid"], plan["point_lid"]):
            return
        feat = poly_lyr.getFeature(plan["fid"])
        if feat is None or not feat.isValid():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE, "ไม่พบแปลงนี้แล้ว (ถูกลบระหว่างรอ?) — ยกเลิก")
            return
        flds = plan["flds"]
        # ★ 2.3.7 b19 (doc-verify E1) — เทียบคอลัมน์ UTM ด้วย (เดิมเทียบแค่ 6 ช่องคีย์ ⇒ UTM ถูกแก้ระหว่างรอแล้วยังเขียนทับ ·
        #   หมุดในแผนเป็นชุดของ UTM ตอนคลิก) · ไม่ตรง = ไม่เขียนอะไร
        if {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS} != plan["old"] or \
                _txt(feat[flds["poly"]["UTM"]]) != plan["old_utm"]:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ข้อมูลระวาง/UTM ของแปลงนี้ถูกแก้ระหว่างรอระบบกรม — ยกเลิก (ยังไม่ได้แก้อะไร) กดปุ่มใหม่อีกครั้ง")
            return
        # ★ 2.3.7 b19 (doc-verify E1) — ด่านล็อก L1 ซ้ำหลังรอ: เดิมตรวจแค่ตอนคลิก ⇒ กด Esc ที่กล่องรอ → 🔒 ล็อก L1 กลับ → Yes
        #   = แก้คีย์แปลง L1 ทั้งที่ล็อกอยู่ (probe a2) · อ่าน Type สดจากแปลง (Type เปลี่ยนเป็น L1 ระหว่างรอก็ถูกกัน)
        #   กล่องยืนยันข้างล่างเป็น application-modal ⇒ หลังด่านนี้สลับล็อก/แก้แปลงไม่ได้จนตอบกล่อง
        _tp = _txt(feat[flds["poly"]["Type"]]).upper() if flds["poly"]["Type"] else ""
        if _tp in ("L1-RTK", "L1-TS", "CT-RTK") and not self._l1_unlocked():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"แปลงนี้เป็น {_tp} (ชั้นอ้างอิงพิกัดหลัก) และตอนนี้ล็อก L1 อยู่ — ยกเลิก (ยังไม่ได้แก้อะไร)\n"
                      "ต้องกดปุ่ม 🔓 ปลดล็อก L1 ก่อน แล้วกดปุ่ม 📝 แก้ไขข้อมูลรูปแปลง ใหม่อีกครั้ง")
            return
        # ★ rc2 (audit A3-02 + ข้อที่ผู้ตรวจทานพบเพิ่ม) — ตรวจแผนซ้ำหลังรอระบบกรม (กล่องรอปิดด้วย Esc ได้ ⇒ ระหว่างรอแก้งานต่อได้)
        #   เดิมใช้ชุดหมุด (mk_ids) · ด่านหมุดล็อก (DU-01 `_parcel_locked_block`) · ผล "UTM ใหม่ซ้ำแปลงอื่น" (dup) ของตอนคลิก
        #   ⇒ 🔒 ล็อก L1 กลับระหว่างรอ = หมุด Type L1 ถูกเปลี่ยนคีย์ทั้งที่ล็อก · Add Node มุมใหม่ระหว่างรอ = หมุดใหม่ค้างคีย์เดิม (หมุดลอย)
        #   · มีคน ➕ สร้างแปลงด้วยคีย์ใหม่ระหว่างรอ = กล่องยืนยันไม่เตือนคีย์ซ้ำ
        #   ⇒ คำนวณแผนใหม่: ด่านล็อกไม่ผ่าน = หยุด (แจ้งแล้ว) · ชุดหมุดเปลี่ยน = ยกเลิก · ใช้ dup/หมายเหตุชุดใหม่
        _p2 = self._ep_plan(poly_lyr, point_lyr, feat, flds, plan["new"])
        if _p2 is None:
            return
        if set(_p2["mk_ids"]) != set(plan["mk_ids"]):
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "หมุดของแปลงนี้เปลี่ยนระหว่างรอระบบกรม — ยกเลิก (ยังไม่ได้แก้อะไร) กดปุ่ม 📝 ใหม่อีกครั้ง")
            return
        _new_dup = set(_p2["dup"]) - set(plan.get("dup") or [])
        plan = dict(plan, dup=_p2["dup"], notes=_p2["notes"], dup_info=_p2.get("dup_info") or [])
        ch = plan.get("ch") or {}
        if ch.get("deed"):
            # ★ 2.4.3 ด่านโฉนด ซ้ำหลังรอระบบกรม — มีแปลง/หมุดใช้คีย์นี้เพิ่มระหว่างรอ ⇒ บล็อก (ไม่ใช่กล่องเตือน E1)
            why = self._ep_deed_dup(poly_lyr, point_lyr, feat, flds, plan["new"], plan)
            if why:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          f"แก้ไม่ได้ — โฉนดที่ดินต้องมีคีย์ไม่ซ้ำ\n{why}\n(ยังไม่ได้แก้อะไร)")
                return
        elif ch.get("public"):
            if self._ep_public_dup_block(poly_lyr, point_lyr, feat, flds, plan["new"], plan):    # ★ 2.4.3 rc2 ที่สาธารณะ: ซ้ำ = บล็อก
                return
        elif _new_dup and not self._ep_dup_confirm(plan):    # ★ 2.4.2 มีแปลงใช้ UTM นี้เพิ่มระหว่างรอระบบกรม ⇒ เตือนแยกอีกครั้ง
            return
        if not self._ep_type_ok(poly_lyr, point_lyr, feat, plan):    # ★ 2.4.3 ด่าน Type ซ้ำหลังรอ (หมุด/แฝดอาจเปลี่ยนระหว่างรอ)
            return
        try:
            _ga = self._geom_area_m2(poly_lyr, feat.geometry()) if feat.hasGeometry() else None    # ★ 2.4.6 DIFF + คีย์ชั้นประวัติ
        except Exception:
            _ga = None
        if plan.get("skip_dol"):
            # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪D · เจ้าของงาน 27 ต.ค. 69 "ล้างให้ตรง ➕") เปลี่ยนชนิดเอกสารเป็น ท.ค./อื่นๆ ⇒
            #   REGIS 'ไม่มีทะเบียน' + ล้าง AREA/DIFF_AREA แบบ ➕ _cp_apply (เดิมคง REGIS/เนื้อที่ของโฉนดไว้) · ชนิดเดิมเป็น ท.ค./อื่นๆ
            #   อยู่แล้ว ⇒ คงเดิม (2.4.7 rc2 🟡2) · ไม่ถามระบบกรมทั้งสองทาง
            _lpn = plan.get("skip_dol") == "likepub" and bool(ch.get("doc"))
            ar = {"area": None, "regis": "ไม่มีทะเบียน" if _lpn else None, "clear_area": _lpn,
                  # ★ 2.4.8 (ผลตรวจ Windows 2.4.7 rc1 ⚪2) ที่สาธารณะ = ถ้อยคำเดิมของ 2.4.6 rc2 ตรงตัว (กลุ่ม ข แยกไปทาง 'nokey' แล้ว)
                  "note": (f"ℹ️ เปลี่ยนเป็น {ch['doc'][1]} — ไม่มีทะเบียน (แบบ ➕ · ไม่ได้ถามระบบกรม) ⇒ REGIS = 'ไม่มีทะเบียน' · "
                           "ล้าง AREA/DIFF_AREA" if _lpn else
                           "ℹ️ ที่สาธารณะ (เลขที่ดิน ≤ 0) ไม่มีทะเบียนให้ค้น — ไม่ได้ถามระบบกรม · เนื้อที่/REGIS คงเดิม"
                           if plan.get("skip_dol") == "public" else
                           "ℹ️ ท.ค./อื่นๆ ไม่มีทะเบียนให้ค้นด้วยคีย์ (แบบที่สาธารณะ) — ไม่ได้ถามระบบกรม · เนื้อที่/REGIS คงเดิม"     # ★ 2.4.7 rc2 🟡2
                           if plan.get("skip_dol") == "likepub" else
                           "ℹ️ น.ส.3/ใบจอง/ส.ค.1 ค้นทะเบียนด้วยเลขที่เอกสาร (🔍 ในกล่อง) — ไม่ได้ค้น · ไม่ถามระบบกรมด้วยคีย์ · เนื้อที่/REGIS คงเดิม"
                           if plan.get("skip_dol") == "nokey" else                                                     # ★ 2.4.8 ขั้น E
                           "ℹ️ ไม่ได้ถามระบบกรม (เปลี่ยนแค่ Type/ชนิดเอกสาร/ชื่อทางสาธารณะ) — เนื้อที่/REGIS คงเดิม")}
        else:
            self._ep_mark_in_layer(poly_lyr, res, own=feat.id())        # ★ 2.4.6 เลขแนะนำที่มีแปลงในชั้นแล้ว
            ar = self._ep_area_result(res, err, shape_m2=_ga)
        _docf = flds["poly"].get("DOC_TYPE")
        _fdoc = ((ch["doc"][1] if ch.get("doc") else _txt(feat[_docf])) if _docf else "")     # ชนิดเอกสารหลังแก้
        if ar.get("hist_ok") and _fdoc != self._DEED:
            # ★ 2.4.6 (ตรวจอิสระ ⚪4) คีย์ชั้นประวัติใช้ผลทะเบียนได้เฉพาะแปลงที่ชนิดเอกสารหลังแก้เป็นโฉนดที่ดิน (คำสั่งเรื่องโฉนด ·
            #   🔍 ในกล่องเติม/ล็อกโฉนดให้แล้ว) · ชนิดอื่น ⇒ ไม่ใช้เนื้อที่/REGIS แบบ 2.4.5 + บอกทางแก้
            _hw = ("เลขที่ดินนี้อยู่ในชั้นประวัติของแผนที่กรม — ทะเบียน iLands ยืนยันโฉนดนี้ได้ แต่ชนิดเอกสารของแปลงไม่ใช่โฉนดที่ดิน "
                   "⇒ ไม่ใช้เนื้อที่/สถานะทะเบียน (ถ้าแปลงนี้เป็นโฉนด ให้เลือกชนิดเอกสารเป็นโฉนดที่ดินแล้วแก้ใหม่)" + _dol_history_where(res))
            ar = {"area": None, "regis": None, "hist": True, "hist_why": _hw, "note": "⚠️ " + _hw}
        if ch.get("deed"):
            # ★ 2.4.3 ด่านโฉนดที่ดิน (คำตัดสิน 21 ต.ค. 69: ไม่ได้เนื้อที่ทุกกรณี = บล็อก · ชั้นประวัติไม่นับ) — ไม่แก้อะไรเลย (REGIS ก็ไม่ตั้ง)
            why = self._ep_deed_block(res, ar)
            if why:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          # ★ 2.4.4 (ผลตรวจ Windows 2.4.3 rc5 ⚪4) คีย์ชั้นประวัติ ⇒ ไม่ขึ้นหัว "ต้องค้นทะเบียน…" (ต้องแก้คีย์ ไม่ใช่ค้นซ้ำ)
                          (f"แก้ไม่ได้ — {why}\n(ยังไม่ได้แก้อะไร)" if (why.startswith("ทะเบียนบอกว่าแปลงนี้เป็น")    # ★ rc2 ⚪5
                                                                      or _ep_hist_key(res)) else
                           "แก้ไม่ได้ — โฉนดที่ดินต้องค้นทะเบียนและได้เนื้อที่ทะเบียนก่อน จึงจะเปลี่ยนคีย์/ชนิดเอกสารได้\n"
                           f"{why}\n(ยังไม่ได้แก้อะไร)"))
                return
        o, n = plan["old"], plan["new"]
        line = lambda d: f"ระวาง {d['UTMMAP1']} {d['UTMMAP2']} {d['UTMMAP3']}-{d['UTMMAP4']} · 1:{d['UTMSCALE']} · ที่ดิน {d['LANDNO']}"  # noqa: E731
        txt = [f"แปลง gid {plan['fid']}"]
        if ch.get("type"):
            # ★ 2.4.3 (ยุบ 🏷) หัวแดงแบบ 🏷 เมื่อถอดออก/เลื่อนขึ้นชั้นอ้างอิง
            _o_t, _n_t = ch["type"]
            if _o_t.upper() in ("L1-RTK", "L1-TS", "CT-RTK"):
                txt.insert(0, f"🔴 กำลังถอดแปลงออกจากชั้นอ้างอิง ({_o_t} -> {_n_t}) — "
                              "แปลงข้างเคียงที่เคยยึดพิกัดจากแปลงนี้จะไม่มีตัวอ้างอิงแล้ว\n")
            elif _n_t.upper() in ("L1-RTK", "L1-TS", "CT-RTK"):
                txt.insert(0, f"🔴 กำลังเลื่อนแปลงขึ้นเป็นชั้นอ้างอิง ({_o_t or '(ว่าง)'} -> {_n_t}) — "
                              "แปลงนี้จะถูกล็อกห้ามขยับ และคนอื่นจะเอาไปใช้ยึดพิกัด\n")
        if ar.get("hist_ok"):
            # ★ 2.4.6 คีย์ชั้นประวัติที่ทะเบียน iLands ยืนยัน — หัวแดงในกล่องยืนยัน (ปุ่มตั้งต้น No) · รายละเอียดอยู่ในหมายเหตุ (ar['note'])
            txt.insert(0, "🔴 คีย์ชั้นประวัติของแผนที่กรม — ใช้โฉนดตามทะเบียน iLands (ตรวจภาพลักษณ์โฉนดก่อนยืนยัน)\n")
        _keys_diff = any(o[k] != n[k] for k in self._EP_KEYS)
        if n["UTM"] != plan["old_utm"] or _keys_diff:
            txt.append(f"{line(o)}\n  →  {line(n)}")
            if n["UTM"] != plan["old_utm"]:
                txt.append(f"UTM: {plan['old_utm'] or '(ว่าง)'}  →  {n['UTM']}")
                txt.append(f"หมุดของแปลงนี้ที่จะเปลี่ยนคีย์ตาม: {len(plan['mk_ids'])} ดวง")
            else:
                # ★ 2.3.7 b19 (doc-verify E3) — UTM เท่าเดิม: แก้แค่ช่องระวาง/เลขที่ดินให้ตรงกับ UTM (แปลง + หมุดของแปลง)
                txt.append(f"UTM: {n['UTM']} (ไม่เปลี่ยน — แก้ช่องระวาง/เลขที่ดินให้ตรงกับ UTM)")
                txt.append(f"หมุดของแปลงนี้ที่จะแก้ช่องระวาง/เลขที่ดินตาม: {len(plan['mk_ids'])} ดวง")
        else:
            # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪B) ทางที่ไม่ถามระบบกรม (skip_dol) ไม่บอกว่าดึงเนื้อที่ใหม่
            txt.append("ระวาง/เลขที่ดินไม่เปลี่ยน" + ("" if (ch.get("type") or ch.get("doc") or ch.get("pname") or plan.get("skip_dol"))
                                                    else " — ดึงเนื้อที่ทะเบียนใหม่อย่างเดียว"))
        txt += plan["notes"]
        if plan.get("pub_note"):                            # ★ 2.4.3 rc2 เลขที่สาธารณะที่คิดให้
            txt.append(plan["pub_note"])
        if ch.get("type"):                                  # ★ 2.4.3 (ยุบ 🏷)
            txt.append(f"Type: {ch['type'][0] or '(ว่าง)'}  →  {ch['type'][1]} (แปลง + หมุดของแปลง {len(plan.get('type_mk') or [])} ดวง)")
        else:                                               # ★ 2.4.6 หมุดตาม Type แปลงเสมอ (ไม่มีช่องติ๊กแล้ว)
            txt += self._ep_sync_lines(plan, _txt(feat[flds["poly"]["Type"]]) if flds["poly"].get("Type") else "")
        if ch.get("doc"):                                   # ★ 2.4.3 ชนิดเอกสารสิทธิ์
            txt.append(f"ชนิดเอกสาร: {ch['doc'][0] or '(ว่าง)'}  →  {ch['doc'][1] or '(ว่าง)'}")
        # ★ 2.4.8 (ผลตรวจ Windows 2.4.7 rc1 ⚪4) ล้างชื่อ ⇒ ชื่อแถวตามชนิดเดิม (ท.ค./อื่นๆ = "ชื่อแปลง")
        _pnl = self._pn_label(_fdoc if (ch.get("pname") or ("", ""))[1] else
                              ((ch["doc"][0] if ch.get("doc") else _txt(feat[_docf])) if _docf else ""))
        if ch.get("pname"):                                 # ★ 2.4.5 rc2 ชื่อทางสาธารณะ · ★ 2.4.6 ชื่อแถวตามชนิด (ตรวจอิสระ ⚪5)
            txt.append(f"{_pnl}: {ch['pname'][0] or '(ว่าง)'}  →  {ch['pname'][1] or '(ว่าง)'}"
                       + ("" if ch["pname"][1] else " (ล้างชื่อ)"))
        if plan["dup"]:
            _k = sum(k for _g, _t, k, _tc in (plan.get("dup_info") or []))      # ★ 2.4.2 มุมร่วมที่จะมีหมุดซ้อน
            txt.append(f"⚠️ UTM ใหม่ซ้ำกับแปลงอื่นในชั้นนี้ {len(plan['dup'])} แปลง (gid "
                       + ", ".join(str(x) for x in plan["dup"][:5]) + (" …" if len(plan["dup"]) > 5 else "")
                       + ")" + (f" · มุมร่วม {_k} มุมจะมีหมุด UTM เดียวกันซ้อน" if _k else "")
                       + " — ตั้งใจให้เป็นแปลงแฝดหรือไม่?")
        txt.append(ar["note"])
        af = flds["poly"]["AREA"]
        if ar["area"] is not None and af:
            old_a = _txt(feat[af])
            txt.append(f"AREA: {old_a or '(ว่าง)'}  →  {ar['area']:,.2f} ตร.ม.")
            # ★ 2.4.6 (เจ้าของงาน 26 ต.ค. 69 "คิดค่า diff แสดงให้เห็น") — DIFF_AREA ที่จะเขียน (สูตรเดียวกับ _ep_apply)
            _dfn = flds["poly"].get("DIFF_AREA")
            _dn = _dol_area_diff(_ga, ar["area"])
            if _dfn and _dn is not None:
                txt.append(f"DIFF_AREA: {_txt(feat[_dfn]) or '(ว่าง)'}  →  {_dn:+.2f}% (รูป {_ga:,.2f} ตร.ม.)")
        elif ar.get("clear_area"):                          # ★ 2.4.8 rc2 ⚪D เปลี่ยนเป็น ท.ค./อื่นๆ (แบบ ➕)
            for _k in ("AREA", "DIFF_AREA"):
                _fk = flds["poly"].get(_k)
                if _fk and _txt(feat[_fk]):
                    txt.append(f"{_k}: {_txt(feat[_fk])}  →  (ว่าง)")
        rf = flds["poly"]["REGIS"]
        if ar["regis"] is not None and rf and _txt(feat[rf]) != ar["regis"]:
            txt.append(f"REGIS: {_txt(feat[rf]) or '(ว่าง)'}  →  {ar['regis']}")
        _rc = self._ep_reg_changes(poly_lyr, feat, flds, ch, ar)               # ★ 2.4.8 คอลัมน์ทะเบียน 7 ตัว
        if _rc and ar.get("reg"):
            txt.append(_reg_txt(ar["reg"]))
        elif _rc:
            txt.append("ล้างเลขอ้างอิงทะเบียนเดิม (REG_SEQ · PARCEL_NO · SURVEY_NO · MOO) — คีย์/ชนิดเอกสารเปลี่ยน และไม่ได้ผลทะเบียนใหม่")
        # ★ 2.3.7 b19 (doc-verify E3) — ช่องระวาง/เลขที่ดินเปลี่ยน (UTM เท่าเดิม) ก็ต้องแก้ แม้ดึงเนื้อที่ไม่ได้ (เดิม "ไม่มีอะไรต้องแก้")
        if not (n["UTM"] != plan["old_utm"] or _keys_diff or ar["area"] is not None or
                (ar["regis"] is not None and rf and _txt(feat[rf]) != ar["regis"]) or ch.get("type") or ch.get("doc")
                or ch.get("pname") or plan.get("sync_mk")            # ★ 2.4.6 หมุดที่ต้องปรับ Type ตามแปลง
                or _rc):                                             # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 7) ค่าทะเบียนที่จะเขียน/ล้าง
            self._ask(QtWidgets.QMessageBox.Information, self._EP_TITLE, "\n".join(txt + ["", "ไม่มีอะไรต้องแก้"]))
            return
        ans = self._ask(QtWidgets.QMessageBox.Question, "ยืนยัน" + self._EP_TITLE, "\n".join(txt + ["", "ยืนยัน?"]),
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return
        # ★ 2.4.3 rc2 (⚪5) ชนิดเอกสารที่ทะเบียนบอก — ด่านสุดท้ายใน _ep_apply ใช้ซ้ำ
        ar["reg_doc"] = _dol_doc_code(res.get("parcel_type")) if isinstance(res, dict) else None
        if self._ep_apply(poly_lyr, point_lyr, feat, plan, ar):
            _ex = ((f" · Type {ch['type'][1]}" if ch.get("type") else "")
                   + (f" · ชนิดเอกสาร {ch['doc'][1] or '(ว่าง)'}" if ch.get("doc") else "")
                   + (f" · {_pnl} {ch['pname'][1] or '(ล้าง)'}" if ch.get("pname") else "")
                   + (f" · Type หมุด {len(plan['sync_mk']):,} ดวงตามแปลง" if plan.get("sync_mk") else ""))
            self.iface.messageBar().pushMessage(
                self._EP_TITLE, f"แก้แล้ว (ยังไม่บันทึก) — UTM {n['UTM']} · หมุด {len(plan['mk_ids'])} ดวง{_ex} · กด 💾 บันทึก",
                level=0, duration=8)     # ★ 2.3.7 (review UX-35) ยังไม่ลงฐาน ⇒ ฟ้า (เดิมเขียว "สำเร็จ")

    def _ep_apply(self, poly_lyr, point_lyr, feat, plan, ar):
        """เขียนลง edit buffer ในคำสั่งเดียว (แปลง + หมุด) — ล้มที่ใด = ทิ้งทั้งชุดด้วย destroyEditCommand (DI-33)
        ★ 2.4.3 Type (แปลง + หมุด plan['type_mk']) และ DOC_TYPE ลงคำสั่งเดียวกัน (↺ Undo ครั้งเดียวคืนครบ)"""
        flds, n = plan["flds"], plan["new"]
        ch = plan.get("ch") or {}
        # ★ 2.4.3 ด่านโฉนดสุดท้าย (ทางเรียกตรง) — ไม่มีเนื้อที่ทะเบียน = ไม่เขียน
        #   ★ (review ⚪5) ไม่เชื่อ plan['ch'] อย่างเดียว: คำนวณซ้ำจากแปลง + ค่าใหม่ (ชนิดเอกสารหลังแก้เป็นโฉนด และคีย์/ชนิดเอกสารเปลี่ยน) ·
        #   เนื้อที่จากชั้นประวัติแผนที่กรม (ar['via']) ก็ไม่นับ — แบบ _ep_deed_block
        _docf = flds["poly"].get("DOC_TYPE")
        _fdoc = ((ch["doc"][1] if ch.get("doc") else _txt(feat[_docf])) if _docf else "")
        _kch = _norm_utm(_txt(feat[flds["poly"]["UTM"]])) != _norm_utm(n["UTM"]) or not _txt(feat[flds["poly"]["UTM"]])
        if (ch.get("deed") or (_fdoc == self._DEED and (_kch or ch.get("doc")))) and \
                (ar.get("area") is None or ar.get("via") == "arcgis_history" or (ar.get("hist") and not ar.get("hist_ok"))
                 or (ar.get("reg_doc") and ar.get("reg_doc") != self._DEED)):          # ★ rc2 (⚪5) ทะเบียนบอกชนิดอื่น
            # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪8) — เดิมปฏิเสธเงียบ ⇒ บอกเหตุ (เกิดเมื่อชนิดเอกสาร/คีย์ถูกแก้นอกปลั๊กอินระหว่างรอ)
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "แก้ไม่ได้ (ด่านสุดท้ายก่อนเขียน) — โฉนดที่ดินต้องได้เนื้อที่ทะเบียนของคีย์นี้ และทะเบียนต้องไม่บอกว่าเป็นชนิดอื่น\n"
                      "(ชนิดเอกสารหรือคีย์อาจถูกแก้ระหว่างรอระบบกรม — ตรวจแล้วกดปุ่มใหม่)\n(ยังไม่ได้แก้อะไร)")
            return False
        # ★ 2.4.9 (แผน 2.4.9 ข้อ 2.3 · เจ้าของงาน 27 ต.ค. 69 "gid 92903 ทำไมมีทะเบียนทั้งในโฉนดที่ดิน และ นสล") น.ส.ล. ค้นทางแผนที่กรม
        #   ด้วยคีย์เดียวกับโฉนด ⇒ ทะเบียนต้องบอกว่าเป็น น.ส.ล. ด้วย — เดิมรับผลโฉนดของคีย์นั้น (มีทะเบียน + เนื้อที่ + เลขโฉนด) ไปเขียนเป็น น.ส.ล.
        #   เฉพาะตอนเปลี่ยนชนิดเป็น น.ส.ล. (แปลง น.ส.ล. เดิมที่แก้คีย์ = กติกาเดิม 2.4.5 · sim117 E3)
        if ch.get("doc") and _txt(ch["doc"][1]) == "น.ส.ล." and ar.get("reg_doc") and ar.get("reg_doc") != "น.ส.ล.":
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"แก้ไม่ได้ — ทะเบียนบอกว่าแปลงนี้เป็น {ar.get('reg_doc')} ไม่ใช่ น.ส.ล. · เลือกชนิดเอกสารให้ตรงทะเบียน\n(ยังไม่ได้แก้อะไร)")
            return False
        # ★ 2.4.3 rc2 ด่านสุดท้าย (ทางเรียกตรง) — คีย์ใหม่เป็นที่สาธารณะที่แปลง/หมุดอื่นใช้อยู่ ⇒ ไม่เขียน (ฐานมี unique index)
        if _kch and _public_landno(n.get("LANDNO")) and \
                self._ep_public_dup_block(poly_lyr, point_lyr, feat, flds, n, plan):
            return False
        # ★ 2.4.3 (review 🟡3 · รายการตายตัว เจ้าของงาน 21 ต.ค.) Type/ชนิดเอกสารใหม่ต้องอยู่ในรายการ (_ep_type_ok / กล่องแจ้งแล้ว)
        if ch.get("type") and ch["type"][1] not in self._CP_TYPES_ALL:
            return False
        if ch.get("doc") and ch["doc"][1] not in self._CP_DOC_CODES:
            return False                                # รวมล้างเป็นว่าง (คำตัดสิน 21 ต.ค.: ล้างไม่ได้)
        changes = []                                    # (lyr, fid, field_name, new, old)
        for k in self._EP_KEYS + ("UTM",):
            fn = flds["poly"][k]
            old = feat[fn]
            if _txt(old) != n[k]:
                # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 ⚪B2) ค่าว่าง (UTMMAP3 ของ น.ส.3 ก) เขียน NULL แบบ ➕ — เดิมเขียน '' (แปลง + หมุด)
                changes.append((poly_lyr, feat.id(), fn, n[k] if n[k] != "" else None, old))
        if ar["area"] is not None and flds["poly"]["AREA"]:
            fa = flds["poly"]["AREA"]
            changes.append((poly_lyr, feat.id(), fa, float(round(ar["area"], 2)), feat[fa]))
            if flds["poly"]["DIFF_AREA"] and ar["area"] > 0:
                # trigger คำนวณ DIFF_AREA เฉพาะตอน geom เปลี่ยน ⇒ คำนวณเองด้วยสูตรเดียวกัน (ร้อยละ · ★ 2.4.6 _dol_area_diff ตัวเดียวกับกล่อง)
                fd = flds["poly"]["DIFF_AREA"]
                ga = self._geom_area_m2(poly_lyr, feat.geometry())
                changes.append((poly_lyr, feat.id(), fd, _dol_area_diff(ga, ar["area"]), feat[fd]))
        _lpc = []                                       # ★ 2.4.8 rc2 ⚪D ค่าที่ตั้ง/ล้างเพราะเปลี่ยนเป็น ท.ค./อื่นๆ (แบบ ➕ _cp_apply)
        if ar["area"] is None and ar.get("clear_area"):
            for k in ("AREA", "DIFF_AREA"):
                fk = flds["poly"].get(k)
                if fk and _txt(feat[fk]):
                    _lpc.append((poly_lyr, feat.id(), fk, None, feat[fk]))
        if ar["regis"] is not None and flds["poly"]["REGIS"]:
            fr = flds["poly"]["REGIS"]
            if _txt(feat[fr]) != ar["regis"]:
                (_lpc if ar.get("clear_area") else changes).append((poly_lyr, feat.id(), fr, ar["regis"], feat[fr]))
        # ★ 2.4.8 rc2 ⚪D คีย์เปลี่ยนด้วย ⇒ อยู่กับคีย์ (แถว 'rekeyed') · เปลี่ยนแค่ชนิดเอกสาร ⇒ อยู่กับชนิดเอกสาร (แถว 'redoc' ·
        #   ไม่ให้เกิดแถว 'rekeyed' "UTM X -> X" — แบบคอลัมน์ทะเบียน _rc ด้านล่าง)
        _lpc_base = bool(_lpc) and bool(ch.get("key"))
        if _lpc_base:
            changes += _lpc
        # ★ 2.4.8 คอลัมน์ทะเบียน 7 ตัว — ผลค้นใหม่/คีย์เปลี่ยน ⇒ อยู่กับคีย์/เนื้อที่/REGIS (แถว 'rekeyed') · ล้างเพราะเปลี่ยนชนิดเอกสาร
        #   อย่างเดียว ⇒ อยู่กับชนิดเอกสาร (ไม่ให้เกิดแถว 'rekeyed' "UTM X -> X" ของการเปลี่ยนชนิด)
        _rc = self._ep_reg_changes(poly_lyr, feat, flds, ch, ar)
        _rc_base = bool(_rc) and (bool(ar.get("reg")) or bool(ch.get("key")))
        if _rc_base:
            changes += _rc
        # ★ 2.3.7 b19 (doc-verify E3) — หมุดในแผนได้ช่องเดียวกับแปลงเสมอ (UTM เปลี่ยน หรือแก้ช่องระวางให้ตรง UTM · เดิมเฉพาะ UTM เปลี่ยน)
        #   แผนใส่หมุดเฉพาะสองกรณีนี้ ⇒ ดึงเนื้อที่อย่างเดียวยังไม่แตะหมุด
        if plan["mk_ids"]:
            for mf in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(plan["mk_ids"])):
                for k in self._EP_KEYS + ("UTM",):
                    fn = flds["point"][k]
                    if _txt(mf[fn]) != n[k]:
                        changes.append((point_lyr, mf.id(), fn, n[k] if n[k] != "" else None, mf[fn]))      # ★ 2.4.8 rc2 ⚪B2
        n_base = len(changes)                           # ★ 2.4.3 คีย์/เนื้อที่/REGIS (แถว 'rekeyed') — ที่ต่อจากนี้ = Type/ชนิดเอกสาร
        tf, mtf, docf = flds["poly"].get("Type"), flds["point"].get("Type"), flds["poly"].get("DOC_TYPE")
        _sync = {}                                      # ★ 2.4.6 {fid: (Type เดิม, ชื่อหมุด)} หมุดที่ปรับตามแปลง (Type แปลงไม่เปลี่ยน)
        if ch.get("type") and tf:
            _nt = ch["type"][1]
            if _txt(feat[tf]) != _nt:
                changes.append((poly_lyr, feat.id(), tf, _nt, feat[tf]))
            _mt = _marker_type_from_parcel(_nt)         # แบบ ➕/Add Node (CT-RTK ไม่ลงหมุด — แต่ไม่มีในรายการอยู่แล้ว)
        else:
            # ★ 2.4.6 (เจ้าของงาน 26 ต.ค. 69 "บังคับให้เปลี่ยนตาม type แปลงไปเลย") — Type แปลงไม่เปลี่ยน ⇒ หมุดชุด _ep_sync_plan
            #   ปรับตาม Type แปลง (Type แปลงนอกรายการ ⇒ ไม่ลามไปหมุด)
            _mt = _marker_type_from_parcel(_txt(feat[tf])) if tf else None
            if _mt not in self._CP_TYPES_ALL:
                _mt = None
        if mtf and _mt and plan.get("type_mk"):
            _ni = _fld_idx(point_lyr.fields(), "BND_NAME")
            for mf in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(plan["type_mk"])):
                if _txt(mf[mtf]) != _mt:
                    changes.append((point_lyr, mf.id(), mtf, _mt, mf[mtf]))
                    if not ch.get("type"):
                        _sync[mf.id()] = (_txt(mf[mtf]), _txt(mf.attribute(_ni)) if _ni >= 0 else "")
        if ch.get("doc") and docf:
            changes.append((poly_lyr, feat.id(), docf, ch["doc"][1] or None, feat[docf]))
        if _rc and not _rc_base:
            changes += _rc
        if _lpc and not _lpc_base:
            changes += _lpc
        pnf = flds["poly"].get(self._PN_FIELD)
        if ch.get("pname") and pnf and not any(c[2] == pnf for c in _rc):     # ★ 2.4.5 rc2 ชื่อทางสาธารณะ ('' = ล้างเป็น NULL) ·
            #                                                ★ 2.4.9 ผลทะเบียนตั้งชื่อผู้ถือสาธารณประโยชน์ให้แล้ว ⇒ ไม่ล้างทับ
            if len(ch["pname"][1]) > self._PN_MAX:
                return False                            # ทางเรียกตรง (กล่องจำกัด 100 ตัวอักษรแล้ว)
            changes.append((poly_lyr, feat.id(), pnf, ch["pname"][1] or None, feat[pnf]))
        if not changes:
            return False
        lyrs = [poly_lyr] + ([point_lyr] if any(c[0] is point_lyr for c in changes) else [])
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(*lyrs, title=self._EP_TITLE, what="ยังไม่ได้แก้ข้อมูลแปลง"):
            return False
        self._op_begin(lyrs)
        for l in lyrs:
            l.beginEditCommand(self._EP_TITLE)
        ok_all = True
        try:
            for l, fid, fn, new, old in changes:
                ok_all = bool(l.changeAttributeValue(fid, l.fields().indexOf(fn), new, old)) and ok_all
        except Exception:
            ok_all = False
        for l in lyrs:
            try:
                (l.endEditCommand if ok_all else l.destroyEditCommand)()
            except Exception:
                pass
        self._op_commit()
        if not ok_all:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "เขียนค่าไม่สำเร็จบางส่วน — ทิ้งทั้งชุดแล้ว (ไม่มีอะไรเปลี่ยน)")
            return False
        _ux = self._ux_mark(poly_lyr)                   # ★ 2.3.7 (audit F8) ผูกกับคำสั่งแก้ไข (ทุกแถวของคำสั่งนี้)
        _base = [c for c in changes[:n_base] if c[0] is poly_lyr]
        _tp_final = ch["type"][1] if (ch.get("type") and tf) else (_txt(feat[tf]) if tf else "")
        if changes[:n_base]:                            # ★ 2.4.3 แถว 'rekeyed' เฉพาะเมื่อแก้คีย์/เนื้อที่/REGIS (Type/ชนิดเอกสาร = แถวของตัวเอง)
            self._pending_type_log.append({
                'lid': poly_lyr.id(), 'ux': _ux,
                # ★ 2.3.7 b17 (audit R2-D2) — คอลัมน์ของแปลงที่เปลี่ยน + ค่าก่อน/หลัง (คีย์ · UTM · AREA · DIFF_AREA · REGIS)
                'fx': ('attr', tuple(c[2] for c in _base), tuple(_txt(c[4]) for c in _base), tuple(_txt(c[3]) for c in _base)),
                'gid': feat.id(), 'utm': n["UTM"], 'old': None, 'new': _tp_final,
                'n_mk': len(plan["mk_ids"]), 'action': 'rekeyed',
                'op': (f"UTM {plan['old_utm'] or '(ว่าง)'} -> {n['UTM']}"
                       + (" (แก้ช่องระวาง/เลขที่ดินให้ตรง UTM)" if n["UTM"] == plan["old_utm"]           # ★ b19 E3
                          and any(plan["old"][k] != n[k] for k in self._EP_KEYS) else "")
                       + (f" · AREA {ar['area']:.2f}" if ar["area"] is not None else
                          " · ล้าง AREA/DIFF_AREA" if _lpc_base and any(c[2] != flds["poly"]["REGIS"] for c in _lpc)     # ★ 2.4.8 rc2 ⚪D
                          else " · AREA คงเดิม")
                       + (f" · REGIS {ar['regis']}" if ar["regis"] and (_lpc_base or not ar.get("clear_area")) else "")
                       + (" · คีย์ชั้นประวัติ (ทะเบียน iLands ยืนยัน)" if ar.get("hist_ok") else "")      # ★ 2.4.6
                       + ((" · " + _reg_txt(ar["reg"]).replace("ข้อมูลทะเบียน: ", "ทะเบียน ")) if _rc_base and ar.get("reg")
                          else " · ล้างเลขอ้างอิงทะเบียน" if _rc_base else "")                             # ★ 2.4.8
                       + f" · หมุด {len(plan['mk_ids'])} จุด · MLEP {self.version}")})
        if ch.get("type") and tf:
            # ★ 2.4.3 (ยุบ 🏷) แถว 'retyped' แบบ 🏷 (trigger ของฐานไม่จับการเปลี่ยน Type)
            _n_mt = sum(1 for c in changes[n_base:] if c[0] is point_lyr)
            self._pending_type_log.append({
                'lid': poly_lyr.id(), 'gid': feat.id(), 'utm': n["UTM"], 'old': ch["type"][0], 'new': ch["type"][1],
                'n_mk': _n_mt, 'ux': _ux, 'fx': ('attr', (tf,), (_txt(feat[tf]),), (_txt(ch["type"][1]),)),
                'op': f"Type {ch['type'][0] or '(ว่าง)'} -> {ch['type'][1]} · หมุด {_n_mt} จุด · 📝 · MLEP {self.version}"})
        if _sync:
            # ★ 2.4.6 หมุดที่ปรับ Type ตามแปลง ⇒ แถว Move_Log หมุดละแถวแบบ 🏷 ปรับ Type หมุดให้ตรงแปลง (_change_type_sync_markers)
            for mid, (old, nm) in _sync.items():
                _o = norm_type(old)
                self._pending_type_log.append({
                    'lid': point_lyr.id(), 'gid': mid, 'utm': n["UTM"], 'layer': 'POINT', 'bnd': nm or None,
                    'old': _o, 'new': _mt, 'n_mk': 1,
                    'op': f"Type หมุด {_o or '(ว่าง)'} -> {_mt} (ปรับให้ตรงแปลง gid {int(feat.id())}) · 📝 · MLEP {self.version}",
                    'ux': self._ux_mark(point_lyr), 'fx': ('attr', (mtf,), (old,), (_txt(_mt),))})
        if ch.get("doc") and docf:
            # ★ 2.4.3 แถว 'redoc' (ใหม่ · Move_Log ไม่มี CHECK ของ action — ตรวจฐานจริงแล้ว 21 ต.ค.)
            self._pending_type_log.append({
                'lid': poly_lyr.id(), 'gid': feat.id(), 'utm': n["UTM"], 'old': None, 'new': _tp_final,
                'n_mk': 0, 'action': 'redoc', 'ux': _ux,
                'fx': ('attr', (docf,), (_txt(feat[docf]),), (_txt(ch["doc"][1]),)),
                'op': f"DOC_TYPE {ch['doc'][0] or '(ว่าง)'} -> {ch['doc'][1] or '(ว่าง)'}"
                      # ★ 2.4.8 rc2 ⚪D เปลี่ยนเป็น ท.ค./อื่นๆ (คีย์เดิม) ⇒ REGIS/AREA ที่ตั้ง/ล้างพร้อมชนิดเอกสาร
                      + ("".join(" · REGIS " + _txt(c[3]) if c[2] == flds["poly"]["REGIS"] else "" for c in _lpc)
                         + (" · ล้าง AREA/DIFF_AREA" if any(c[2] != flds["poly"]["REGIS"] for c in _lpc) else "")
                         if _lpc and not _lpc_base else "")
                      # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 ⚪B3) ล้างเลขอ้างอิงทะเบียนพร้อมชนิดเอกสาร ⇒ บอกในแถวนี้ (เดิมมีแค่ DOC_TYPE … -> …)
                      + (" · ล้างเลขอ้างอิงทะเบียน" if _rc and not _rc_base else "")
                      + f" · 📝 · MLEP {self.version}"})
        if ch.get("pname") and pnf:
            # ★ 2.4.5 rc2 แถว 'pname' (ชื่อทางสาธารณะ · แบบ 'redoc')
            self._pending_type_log.append({
                'lid': poly_lyr.id(), 'gid': feat.id(), 'utm': n["UTM"], 'old': None, 'new': _tp_final,
                'n_mk': 0, 'action': 'pname', 'ux': _ux,
                'fx': ('attr', (pnf,), (_txt(feat[pnf]),), (_txt(ch["pname"][1]),)),
                'op': f"parcel_name {ch['pname'][0] or '(ว่าง)'} -> {ch['pname'][1] or '(ว่าง)'} · 📝 · MLEP {self.version}"})
        self._locked_cache = None        # แผนที่ล็อก L1 ผูกกับ UTM/Type — คีย์/Type เปลี่ยนต้องอ่านใหม่
        return True
