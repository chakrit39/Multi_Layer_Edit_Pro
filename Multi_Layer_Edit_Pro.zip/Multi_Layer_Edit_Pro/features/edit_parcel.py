# -*- coding: utf-8 -*-
"""แก้ข้อมูลแปลง (ระวาง/เลขที่ดิน) พร้อมค้นเนื้อที่

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsExpression, QgsFeatureRequest,
                       QgsPointXY, QgsProject)
from ..core.util import (_branch_office_of, _dol_area_m2, _dol_doc_code, _dol_here_hint, _dol_history_now,
                         _dol_lis_hint, _dol_more_hint, _dol_via_note, _ep_hist_key, _EP_HIST_MAP_WHY,
                         _EP_HIST_WHY, _ep_normalize, _EP_SCALES, _fld_idx, _log_exc, _marker_type_from_parcel,
                         _norm_utm, _probe_xy_24047, _public_landno, _rngw, _txt, _TYPE_NOT_ON_MARKER,
                         _UTM_FIELD_NAMES)
from ..map_tools import PolygonPickTool
from ..services.workers import ParcelLookupWorker


class EditParcelMixin:
    """แก้ข้อมูลแปลง (ระวาง/เลขที่ดิน) พร้อมค้นเนื้อที่"""

    def _ep_fields(self, poly_lyr, point_lyr):
        """ชื่อคอลัมน์จริงที่ต้องใช้ -> dict หรือ None (ขาดคอลัมน์คีย์ = ทำไม่ได้)"""
        out = {"poly": {}, "point": {}}
        for tag, lyr in (("poly", poly_lyr), ("point", point_lyr)):
            fl = lyr.fields()
            for k in self._EP_KEYS:
                i = _fld_idx(fl, k)
                if i < 0:
                    return None
                out[tag][k] = fl.at(i).name()
            u = self._resolve_field(lyr, _UTM_FIELD_NAMES)
            if not u:
                return None
            out[tag]["UTM"] = u
        for k in ("AREA", "DIFF_AREA", "REGIS", "Type", "DOC_TYPE"):          # ★ 2.4.3 DOC_TYPE (📝 แก้ชนิดเอกสารได้)
            i = _fld_idx(poly_lyr.fields(), k)
            out["poly"][k] = poly_lyr.fields().at(i).name() if i >= 0 else None
        out["point"]["Type"] = self._resolve_field(point_lyr, {'type'})         # ★ 2.4.3 Type หมุดตามแปลง (ยุบ 🏷)
        return out

    def start_edit_parcel_data(self):
        ready = self._admin_ready(self._EP_TITLE)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        flds = self._ep_fields(poly_lyr, point_lyr)
        if flds is None:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ชั้นแปลงหรือชั้นหมุดไม่มีคอลัมน์ UTMMAP1-4 / UTMSCALE / LANDNO / UTM ครบ — แก้ไม่ได้")
            return
        for lyr, cols in ((poly_lyr, list(self._EP_KEYS) + ["UTM", "AREA", "DIFF_AREA", "REGIS"]),
                          (point_lyr, list(self._EP_KEYS) + ["UTM"])):
            tag = "poly" if lyr is poly_lyr else "point"
            for c in cols:
                name = flds[tag].get(c)
                if name and not self._need_column_or_warn(lyr, name, self._EP_TITLE):
                    return
        self.cancel_transform()
        self._dol_clear_highlight()
        self._editparcel_lids = (poly_lyr.id(), point_lyr.id())
        canvas = self.iface.mapCanvas()
        self.temp_tool = PolygonPickTool(
            canvas, poly_lyr, self._edit_parcel_picked, self._dol_on_hover,
            msg_title=self._EP_TITLE, choose_prompt="เลือกแปลงที่ต้องการแก้ไขข้อมูล:")
        canvas.setMapTool(self.temp_tool)
        self.temp_tool.push_hint(                                       # ★ 2.3.7 (UX-01) ข้อความของเครื่องมือ
            self._EP_TITLE, f"คลิกแปลงใน '{poly_lyr.name()}' ที่ต้องการแก้ระวาง/มาตราส่วน/เลขที่ดิน • Esc = ยกเลิก",
            level=0, duration=10)

    def _ep_ready_again(self, layer=None):
        """ด่านซ้ำหลังคลิก/หลังรอระบบกรม: ยังเป็นผู้ดูแล + คู่ชั้นเดิมกับตอนกดปุ่ม -> (poly, point) หรือ None"""
        ready = self._admin_ready(self._EP_TITLE)
        if not ready:
            return None
        poly_lyr, point_lyr = ready
        if getattr(self, "_editparcel_lids", None) != (poly_lyr.id(), point_lyr.id()) or \
                (layer is not None and layer.id() != poly_lyr.id()):
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม (หรือแปลงที่คลิกอยู่คนละชั้น) — ยกเลิก\n"
                      "กดปุ่ม 📝 แก้ไขข้อมูลรูปแปลง ใหม่อีกครั้ง")
            return None
        return poly_lyr, point_lyr

    def _edit_parcel_picked(self, feat, layer):
        self.iface.actionSelect().trigger()
        self._dol_clear_highlight()
        ready = self._ep_ready_again(layer)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        try:
            feat = poly_lyr.getFeature(feat.id())
        except Exception:
            pass
        if feat is None or not feat.isValid():
            return
        flds = self._ep_fields(poly_lyr, point_lyr)
        if flds is None:
            return
        cur_type = _txt(feat[flds["poly"]["Type"]]).upper() if flds["poly"]["Type"] else ""
        if cur_type in ("L1-RTK", "L1-TS", "CT-RTK") and not self._l1_unlocked():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"แปลงนี้เป็น {cur_type} (ชั้นอ้างอิงพิกัดหลัก)\nต้องกดปุ่ม 🔓 ปลดล็อก L1 ก่อน จึงจะแก้ข้อมูลได้")
            return
        newv = self._ep_dialog(poly_lyr, feat, flds)
        if newv is None:
            return
        # ★ 2.4.3 rc2 (เจ้าของงาน 22 ต.ค. 69) เลขที่ดิน 0 = ที่สาธารณะ ⇒ คิดเลขที่ว่างของระวางใหม่จากข้อมูลตอนกด OK
        #   (กล่องเปิดค้างได้ · ทางเรียกตรงส่ง '0' มาตรง ๆ) — เดิมใช้ 0 ตรง ๆ ⇒ ซ้ำแปลงที่สาธารณะเลข 0 ⇒ กล่องแปลงแฝด E1
        _pub_note = None
        if newv.get("_pub0") or _txt(newv.get("LANDNO")) == "0":
            newv, _pub_note = self._ep_public_landno(poly_lyr, point_lyr, feat, flds, dict(newv, LANDNO="0"))
        # ★ 2.4.3 (ยุบ 🏷 · ด่านโฉนด) — แยกว่าเปลี่ยนอะไร · สิทธิ์คอลัมน์ Type/DOC_TYPE ตรวจเฉพาะที่เปลี่ยนจริง
        #   (ตรวจตอนกดปุ่มจะกันผู้ดูแลที่ไม่มีสิทธิ์คอลัมน์นั้นจากงานแก้คีย์)
        ch = self._ep_changes(feat, flds, newv)
        if ch["deed"] and _public_landno(newv.get("LANDNO")):
            # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪8) ที่สาธารณะ (เลขที่ดิน ≤ 0) เป็นโฉนดที่ดินไม่ได้ — บอกก่อนถามระบบกรม
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "แก้ไม่ได้ — เลขที่ดิน ≤ 0 = ที่สาธารณะ เป็นโฉนดที่ดินไม่ได้ · เลือกชนิดเอกสารให้ตรง (เช่น ที่สาธารณประโยชน์)\n"
                      "(ยังไม่ได้แก้อะไร)")
            return
        # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "fix dropdown type ไว้เลย" · "Doc_type ด้วย") ค่าใหม่ต้องอยู่ในรายการตายตัว (ทางเรียกตรง ·
        #   ชนิดเอกสาร: ล้างค่าที่มีเป็นว่างไม่ได้ — คำตัดสิน 21 ต.ค.)
        if (ch["type"] and ch["type"][1] not in self._CP_TYPES_ALL) or (ch["doc"] and ch["doc"][1] not in self._CP_DOC_CODES):
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      ("Type" if ch["type"] and ch["type"][1] not in self._CP_TYPES_ALL else "ชนิดเอกสารสิทธิ์")
                      + " ที่เลือกไม่อยู่ในรายการที่ใช้ได้ (ชนิดเอกสารล้างเป็นว่างไม่ได้) — ยกเลิก (ยังไม่ได้แก้อะไร)")
            return
        _need = ((ch["type"] or ch["sync"], poly_lyr, flds["poly"].get("Type")),
                 (ch["type"] or ch["sync"], point_lyr, flds["point"].get("Type")),
                 (ch["doc"], poly_lyr, flds["poly"].get("DOC_TYPE")))
        for need, lyr, col in _need:
            if need and col and not self._need_column_or_warn(lyr, col, self._EP_TITLE):
                return
        # ★ 2.4.3 (review 🟡2) — ช่องคีย์ที่ต่างแค่รูปแบบ (เช่น ระวาง 'IV' → '4' · LANDNO '0435') ไม่ใช่ "แก้แค่ Type":
        #   กล่องบอกว่าจะแก้ช่องให้ตรง UTM + ดึงเนื้อที่ทะเบียนใหม่ ⇒ ไปทางแก้ข้อมูลเต็ม (ช่องคีย์ + Type ลงคำสั่งเดียว)
        #   เดิมเข้าทาง 🏷 ⇒ ช่องที่กล่องบอกว่าจะแก้ไม่ถูกแก้ และไม่ได้ดึงเนื้อที่
        _fmt = any(_txt(feat[flds["poly"][k]]) != newv[k] for k in self._EP_KEYS + ("UTM",))
        if not ch["key"] and not _fmt and not ch["doc"] and (ch["type"] or ch["sync"]):
            # เปลี่ยนแค่ Type (คีย์/ชนิดเอกสารเดิม) ⇒ ทาง 🏷 เดิมทั้งชุด (ด่าน L1/แฝด/หมุดล็อก · กล่องยืนยัน · คำสั่งเดียว · Move_Log
            #   'retyped' · ปรับ Type หมุดให้ตรงแปลง) · ไม่ถามระบบกรม (คำตัดสิน 21 ต.ค.: ด่านโฉนดเฉพาะเปลี่ยนคีย์/ชนิดเอกสาร)
            self._change_type_execute(poly_lyr, point_lyr, feat,
                                      preset=ch["type"][1] if ch["type"] else self._poly_type_str(poly_lyr, feat))
            return
        plan = self._ep_plan(poly_lyr, point_lyr, feat, flds, newv)
        if plan is None:
            return
        plan["ch"] = ch
        plan["pub_note"] = _pub_note             # ★ rc2 กล่องยืนยันบอกเลขที่คิดให้ (notes ถูกคำนวณใหม่หลังรอ)
        if ch["deed"]:
            # ★ 2.4.3 ด่านโฉนดที่ดิน — คีย์ต้องไม่ซ้ำ: บล็อก (ไม่ใช่กล่องเตือน E1 ที่ตอบ Yes ผ่านได้) · หมุดค้างคีย์นี้ก็นับ
            why = self._ep_deed_dup(poly_lyr, point_lyr, feat, flds, newv, plan)
            if why:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          f"แก้ไม่ได้ — โฉนดที่ดินต้องมีคีย์ไม่ซ้ำ\n{why}\n(ยังไม่ได้แก้อะไร)")
                return
        elif ch["public"]:
            # ★ 2.4.3 rc2 ที่สาธารณะคีย์ซ้ำ ⇒ บล็อก (ไม่ใช่กล่องแปลงแฝด E1 · ฐานมี unique index) — เลขที่คิดให้เองไม่ซ้ำอยู่แล้ว
            #   (ด่านนี้จับเลขติดลบที่พิมพ์เอง) · คีย์ที่ไม่ใช่ที่สาธารณะ = กล่องเตือน E1 เดิม
            if self._ep_public_dup_block(poly_lyr, point_lyr, feat, flds, newv, plan):
                return
        elif plan["dup"] and not self._ep_dup_confirm(plan):     # ★ 2.4.2 เตือนก่อนไปถามระบบกรม (ตอบ No = จบ ไม่เสียเวลารอ)
            return
        if not self._ep_type_ok(poly_lyr, point_lyr, feat, plan):
            return
        if _public_landno(newv.get("LANDNO")):
            # ★ 2.4.3 rc2 ที่สาธารณะไม่มีทะเบียนให้ค้น (แบบ ➕ 🔍) ⇒ ไม่ถามระบบกรม (เดิมถามด้วยเลข 0/ติดลบ ⇒ ไม่พบ · อาจเด้งกล่องเข้าสู่ระบบ iLands)
            self._ep_after_lookup(dict(plan, skip_dol="public"), None, None)
            return
        if not ch["key"] and not ch["deed"] and ch["doc"]:
            # ★ 2.4.3 เปลี่ยนชนิดเอกสาร (ไม่ใช่เป็นโฉนด) ± Type · คีย์เดิม ⇒ ไม่ต้องถามระบบกรม (ด่านซ้ำใน _ep_after_lookup ยังทำครบ)
            self._ep_after_lookup(dict(plan, skip_dol=True), None, None)
            return
        self._ep_lookup(plan)

    def _ep_dialog(self, poly_lyr, feat, flds):
        """กล่องกรอก UTMMAP1-4 · UTMSCALE · LANDNO (ค่าเดิมเติมไว้) -> dict ค่าที่จัดรูปแล้ว หรือ None"""
        import html as _html
        cur = {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS}
        old_utm = _txt(feat[flds["poly"]["UTM"]])
        # ★ 2.4.3 rc2 ชั้นหมุดของปุ่มนี้ (คู่ชั้นตอนกดปุ่ม — `_ep_ready_again` ตรวจแล้ว) ใช้คิดเลขที่สาธารณะ · หาไม่ได้ = นับเฉพาะแปลง
        _pid = (getattr(self, "_editparcel_lids", None) or (None, None))[1]
        point_lyr = QgsProject.instance().mapLayer(_pid) if _pid else None
        d = QtWidgets.QDialog(self.iface.mainWindow())
        d.setWindowTitle("📝 " + self._EP_TITLE)
        lay = QtWidgets.QVBoxLayout(d)
        lay.addWidget(QtWidgets.QLabel(f"แปลง gid {feat.id()} · UTM เดิม {old_utm or '(ว่าง)'}"))
        form = QtWidgets.QFormLayout()
        eds = {}
        for k, mx in (("UTMMAP1", 4), ("UTMMAP2", 3), ("UTMMAP3", 4), ("UTMMAP4", 2)):
            ed = QtWidgets.QLineEdit(cur[k])
            ed.setMaxLength(mx)
            eds[k] = ed
            form.addRow(k, ed)
        cb = QtWidgets.QComboBox()
        cb.addItems(list(_EP_SCALES))
        if cur["UTMSCALE"] in _EP_SCALES:
            cb.setCurrentIndex(_EP_SCALES.index(cur["UTMSCALE"]))
        else:
            cb.insertItem(0, cur["UTMSCALE"] or "(ว่าง)")
            cb.setCurrentIndex(0)
        form.addRow("UTMSCALE", cb)
        ed_ln = QtWidgets.QLineEdit(cur["LANDNO"])
        ed_ln.setMaxLength(7)
        ed_ln.setPlaceholderText("เลขที่ดิน (0 = ที่สาธารณะ — คิดเลขให้เอง)")       # ★ 2.4.3 rc2 แบบ ➕
        form.addRow("LANDNO", ed_ln)
        # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "ยุบปุ่มเปลี่ยน type ไปรวมกับปุ่มแก้ไขข้อมูล และให้แก้ doc type ได้ด้วย")
        #   Type = เลือกจากรายการเท่านั้น (ไม่มี CT-RTK · ค่าเดิมนอกรายการ = ตัวเลือก "(เดิม) X" ที่เลือกแล้วไม่เปลี่ยน)
        tf, docf = flds["poly"].get("Type"), flds["poly"].get("DOC_TYPE")
        cur_tp, cur_doc = (_txt(feat[tf]) if tf else ""), (_txt(feat[docf]) if docf else "")
        cb_tp = QtWidgets.QComboBox()
        if not cur_tp:
            cb_tp.addItem(self.TYPE_KEEP, "")
        for t in self._ep_type_choices(poly_lyr, tf):
            cb_tp.addItem(t, t)
        if cur_tp and cb_tp.findData(cur_tp) < 0:
            cb_tp.insertItem(0, f"(เดิม) {cur_tp}", cur_tp)
        cb_tp.setCurrentIndex(max(0, cb_tp.findData(cur_tp)))
        if not tf:
            cb_tp.setEnabled(False)
            cb_tp.setToolTip("ชั้นแปลงนี้ไม่มีคอลัมน์ Type")
        form.addRow("ประเภทแปลง (Type)", cb_tp)
        # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "Doc_type ด้วย" · คำตัดสิน: ล้างเป็นว่างไม่ได้) — 13 ค่าของตาราง doc_type_codes เท่านั้น ·
        #   "(ว่าง — ไม่เปลี่ยน)" มีเฉพาะแปลงที่ชนิดเอกสารว่างอยู่ (คงว่างได้) · ค่าเดิมนอกรายการ = "(เดิม) X" (ไม่เปลี่ยน)
        cb_doc = QtWidgets.QComboBox()
        if not cur_doc:
            cb_doc.addItem(self.DOC_KEEP, "")
        for c in self._CP_DOC_CODES:
            cb_doc.addItem(c, c)
        if cur_doc and cb_doc.findData(cur_doc) < 0:
            cb_doc.insertItem(0, f"(เดิม) {cur_doc}", cur_doc)
        cb_doc.setCurrentIndex(max(0, cb_doc.findData(cur_doc)))
        if not docf:
            cb_doc.setEnabled(False)
            cb_doc.setToolTip("ชั้นแปลงนี้ไม่มีคอลัมน์ DOC_TYPE")
        form.addRow("ชนิดเอกสารสิทธิ์", cb_doc)
        chk_sync = QtWidgets.QCheckBox("ปรับ Type ของหมุดของแปลงนี้ให้ตรงกับแปลง (ใช้เมื่อ Type แปลงไม่เปลี่ยน)")
        chk_sync.setEnabled(bool(tf and flds["point"].get("Type")))
        form.addRow("", chk_sync)
        lay.addLayout(form)
        prev = QtWidgets.QLabel()
        prev.setWordWrap(True)
        lay.addWidget(prev)
        lay.addWidget(QtWidgets.QLabel(
            "กด OK แล้วโปรแกรมจะดึงเนื้อที่ทะเบียนจากระบบกรมใหม่ แล้วขึ้นกล่องยืนยันอีกครั้งก่อนแก้\n"
            "(เปลี่ยนแค่ Type/ชนิดเอกสารที่ไม่ใช่โฉนดที่ดิน ไม่ต้องถามระบบกรม · โฉนดที่ดินที่เปลี่ยนคีย์/ชนิดเอกสาร "
            "ต้องคีย์ไม่ซ้ำและได้เนื้อที่ทะเบียนก่อนจึงจะแก้ได้)\n"
            "เลขที่ดิน 0 = ที่สาธารณะ: คิดเลขที่ว่างของระวางให้เอง (0, -1, -2, …) ไม่ถามระบบกรม"))
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        lay.addWidget(bb)
        res = {}
        _used = {}                       # ★ 2.4.3 rc2 เลข ≤ 0 ที่มีแปลง/หมุดใช้ ต่อระวาง (ถามชั้นครั้งเดียวต่อระวางต่อกล่อง)

        def _upd(*_a):
            v, err = _ep_normalize(eds["UTMMAP1"].text(), eds["UTMMAP2"].text(), eds["UTMMAP3"].text(),
                                   eds["UTMMAP4"].text(), cb.currentText(), ed_ln.text(), public_neg=True)
            # ★ 2.4.3 ค่าที่เลือก (None = ไม่มีคอลัมน์ = ไม่เปลี่ยน)
            res["tp"] = _txt(cb_tp.currentData()) if tf else None
            res["doc"] = _txt(cb_doc.currentData()) if docf else None
            res["sync"] = chk_sync.isChecked()
            _tp_ch = res["tp"] is not None and res["tp"] != "" and res["tp"] != cur_tp
            _doc_ch = res["doc"] is not None and res["doc"] != cur_doc
            _deed_after = (res["doc"] if res["doc"] is not None else cur_doc) == self._DEED
            # ★ 2.4.3 rc2 (เจ้าของงาน 22 ต.ค. 69) ที่สาธารณะ: 0 ⇒ คิดเลขที่ว่างให้เองแบบ ➕ (แปลงนี้เป็นที่สาธารณะของระวางนี้อยู่แล้ว
            #   ⇒ คงเลขเดิม) · เลขติดลบที่มีแปลง/หมุดอื่นใช้ ⇒ ข้อผิด (ไม่ใช่กล่องแปลงแฝด) · ที่สาธารณะเป็นโฉนดไม่ได้ (⚪8)
            _pub, _pub_note = False, ""
            res["pub0"] = False
            if not err and _public_landno(v["LANDNO"]):
                _pub = True
                head = "".join(v[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"))
                if head not in _used:
                    _used[head] = self._cp_used_landno_le0(poly_lyr, point_lyr, head, own=feat)
                if v["LANDNO"] == "0":
                    v, _pub_note = self._ep_public_landno(poly_lyr, point_lyr, feat, flds, v, used=_used[head])
                    res["pub0"] = True
                elif _norm_utm(v["UTM"]) != _norm_utm(old_utm) and v["LANDNO"] in _used[head]:
                    err = err + [f"เลขที่ดิน {v['LANDNO']} ของระวางนี้มีแปลง/หมุดอื่นใช้แล้ว — ที่สาธารณะใช้คีย์ซ้ำไม่ได้ · "
                                 "พิมพ์ 0 แล้วปลั๊กอินจะคิดเลขที่ว่างให้เอง"]
                if not err and _deed_after and (v["UTM"] != old_utm or _doc_ch):
                    err = err + ["เลขที่ดิน ≤ 0 = ที่สาธารณะ — เป็นโฉนดที่ดินไม่ได้ · เลือกชนิดเอกสารให้ตรง "
                                 "(เช่น ทางสาธารณประโยชน์ / ที่สาธารณประโยชน์)"]
            res["v"], res["err"] = v, err
            if err:
                prev.setText("<span style='color:#b71c1c'>" + "<br>".join(_html.escape(e) for e in err) + "</span>")
            else:
                _same = v["UTM"] == old_utm
                _fix = _same and any(cur[k] != v[k] for k in self._EP_KEYS)        # ★ 2.3.7 b19 (doc-verify E3)
                # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪2) — ค่าจากฐานใส่ในข้อความ rich text ⇒ escape · ข้อความบอกตามทางที่ทำจริง:
                #   ติ๊กปรับ Type หมุดอย่างเดียว / แก้แค่ Type = ทาง 🏷 (ไม่ถามกรม) · ชนิดเอกสารที่ไม่ใช่โฉนดโดยคีย์เดิม = ไม่ถามกรม
                _E = _html.escape
                _more = []
                if _tp_ch:
                    _more.append(f"Type: {_E(cur_tp or '(ว่าง)')} → <b>{_E(res['tp'])}</b> (แปลง + หมุดของแปลง)")
                if _doc_ch:
                    _more.append(f"ชนิดเอกสาร: {_E(cur_doc or '(ว่าง)')} → <b>{_E(res['doc'] or '(ว่าง)')}</b>")
                if _fix:
                    _sfx = ("  (UTM ไม่เปลี่ยน — แก้ช่องระวาง/เลขที่ดินให้ตรงกับ UTM"
                            + (" · ไม่ถามระบบกรม)" if ((_doc_ch and not _deed_after) or _pub) else " + ดึงเนื้อที่ทะเบียนใหม่)"))
                elif _same and res["sync"] and not _tp_ch and not _doc_ch:
                    _sfx = "  (คีย์ไม่เปลี่ยน — ปรับ Type ของหมุดให้ตรงแปลง · ไม่ถามระบบกรม)"
                elif _same and (_tp_ch or _doc_ch):
                    _sfx = "  (คีย์ไม่เปลี่ยน" + (" · ค้นทะเบียน (โฉนดที่ดิน))" if (_doc_ch and _deed_after) else " · ไม่ถามระบบกรม)")
                elif _same:
                    _sfx = ("  (ไม่เปลี่ยน — ที่สาธารณะไม่มีทะเบียนให้ค้น)" if _pub
                            else "  (ไม่เปลี่ยน — ดึงเนื้อที่ทะเบียนใหม่อย่างเดียว)")
                else:
                    _sfx = "  (ที่สาธารณะ — ไม่ถามระบบกรม)" if _pub else ""
                if _pub_note:
                    _more.insert(0, _E(_pub_note))
                prev.setText(f"UTM ใหม่: <b>{_E(v['UTM'])}</b>" + _sfx + "".join("<br>" + m for m in _more))
            bb.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(not err)
        for w in list(eds.values()) + [ed_ln]:
            w.textChanged.connect(_upd)
        cb.currentIndexChanged.connect(_upd)
        cb_tp.currentIndexChanged.connect(_upd)
        cb_doc.currentIndexChanged.connect(_upd)
        chk_sync.toggled.connect(_upd)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        _upd()
        try:
            ok = d.exec_() == QtWidgets.QDialog.Accepted
        finally:
            d.deleteLater()
        if not ok or res.get("err"):
            return None
        # ★ 2.4.3 — ค่า Type/ชนิดเอกสารที่เลือก (_type/_doc: None = ไม่มีคอลัมน์ · _sync = ปรับ Type หมุดให้ตรงแปลง)
        #   ★ rc2 _pub0 = ผู้ใช้พิมพ์เลขที่ดิน 0 (เลขที่สาธารณะในค่าที่คืน = ที่กล่องคิดไว้ — ผู้เรียกคิดใหม่จากข้อมูลตอนกด OK)
        return dict(res["v"], _type=res.get("tp"), _doc=res.get("doc"), _sync=bool(res.get("sync")), _pub0=bool(res.get("pub0")))

    def _ep_type_choices(self, poly_lyr, tf):
        """★ 2.4.3 (ยุบ 🏷) รายการ Type ของ 📝 — ตายตัว (เจ้าของงาน 21 ต.ค. 69 "เรา fix dropdown type ไว้เลยได้ไหมว่ามีอะไรบ้าง")
        = _CP_TYPES_ALL (L1-RTK · L1-TS · L2-TS · L2-RO · L2-LM — ค่าที่ใช้จริงทั้ง 5 ฐาน ตรวจ 21 ต.ค.) · ไม่ดึงค่าจากชั้นแล้ว
        (★ review 🟡3 — เดิมต่อท้ายด้วยค่าในชั้น ⇒ 'CT_RTK' 'L1TS' ถูกเสนอและเขียนลงแปลง+หมุดได้) · ไม่มี CT-RTK (อยู่ชั้น CT_ เท่านั้น)
        ค่าเดิมของแปลงที่อยู่นอกรายการ = ตัวเลือก "(เดิม) X" ในกล่อง (เลือกแล้วไม่เปลี่ยน)"""
        return list(self._CP_TYPES_ALL)

    def _ep_public_landno(self, poly_lyr, point_lyr, feat, flds, v, used=None):
        """★ 2.4.3 rc2 (เจ้าของงาน 22 ต.ค. 69 — 📝 พิมพ์เลขที่ดิน 0 จะทำเป็นทางสาธารณะ แล้วขึ้น "UTM ซ้ำกับแปลงอื่น")
        เลขที่ดิน 0 = ที่สาธารณะ ⇒ คิดเลขให้เองแบบ ➕ (`_cp_free_public_landno` · คำสั่ง 24 ก.ย.) · แปลงนี้มีเลข ≤ 0 ในระวางเดียวกัน
        อยู่แล้ว ⇒ คงเลขเดิม (ไม่เลื่อนไปเลขอื่น) · v = ค่าที่จัดรูปแล้ว (LANDNO '0') -> (ค่าใหม่, หมายเหตุ)
        (ฐานจริงมี unique index คีย์ที่สาธารณะ — public-utm-unique-index ⇒ คีย์ซ้ำบันทึกไม่ได้อยู่แล้ว)"""
        head = "".join(v[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"))
        cur = _norm_utm(feat[flds["poly"]["UTM"]])
        mine = cur[len(head):] if cur.startswith(head) else ""
        if _public_landno(mine):
            n, note = mine, f"เลขที่ดิน 0 = ที่สาธารณะ ⇒ ใช้เลข {mine} (เลขเดิมของแปลงนี้ในระวางนี้)"
        else:
            n, note = self._cp_free_public_landno(poly_lyr, point_lyr, head, used=used, own=feat)
        return dict(v, LANDNO=str(n), UTM=head + str(n)), note

    def _ep_public_dup_block(self, poly_lyr, point_lyr, feat, flds, newv, plan):
        """★ 2.4.3 rc2 — คีย์ใหม่เป็นที่สาธารณะ (เลขที่ดิน ≤ 0) ที่แปลงอื่น/หมุดที่ไม่ใช่ของแปลงนี้ใช้อยู่ ⇒ บล็อก (ไม่มีกล่องแปลงแฝด E1 —
        ที่สาธารณะคีย์ซ้ำไม่ได้: ฐานมี unique index) · เกณฑ์เดียวกับด่านโฉนด `_ep_deed_dup` -> True = บล็อกแล้ว (แจ้งแล้ว)"""
        why = self._ep_deed_dup(poly_lyr, point_lyr, feat, flds, newv, plan)
        if not why:
            return False
        self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                  f"แก้ไม่ได้ — ที่สาธารณะ (เลขที่ดิน ≤ 0) ใช้คีย์ซ้ำกับแปลง/หมุดอื่นไม่ได้\n{why}\n"
                  "พิมพ์เลขที่ดิน 0 แล้วปลั๊กอินจะคิดเลขที่ว่างของระวางนี้ให้เอง (0, -1, -2, …)\n(ยังไม่ได้แก้อะไร)")
        return True

    def _ep_changes(self, feat, flds, newv):
        """★ 2.4.3 สิ่งที่ผู้ใช้เปลี่ยนในกล่อง 📝 -> {'key', 'type', 'doc', 'sync', 'deed', 'public'}
        key = คีย์เปลี่ยนจริง (เทียบหลังจัดรูป — ต่างแค่รูปแบบ เช่น โรมัน/เลขศูนย์นำหน้า ไม่นับ · ช่องเดิมจัดรูปไม่ได้ = นับว่าเปลี่ยน)
        type / doc = (ค่าเดิม, ค่าใหม่) หรือ None · sync = ติ๊กปรับ Type หมุดให้ตรงแปลง
        deed = ด่านโฉนด (คำตัดสิน 21 ต.ค. 69: เฉพาะเมื่อเปลี่ยนคีย์/ชนิดเอกสาร และชนิดเอกสารหลังแก้เป็นโฉนดที่ดิน)
        public = ★ rc2 เปลี่ยนคีย์ไปเป็นที่สาธารณะ (เลขที่ดิน ≤ 0) ⇒ คีย์ซ้ำ = บล็อก (`_ep_public_dup_block`)"""
        old = {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS}
        old_utm = _txt(feat[flds["poly"]["UTM"]])
        vo, eo = _ep_normalize(old["UTMMAP1"], old["UTMMAP2"], old["UTMMAP3"], old["UTMMAP4"], old["UTMSCALE"], old["LANDNO"],
                               public_neg=True)
        same = (not eo) and all(vo[k] == newv[k] for k in self._EP_KEYS) and bool(old_utm) \
            and _norm_utm(old_utm) == _norm_utm(newv["UTM"])
        tf, docf = flds["poly"].get("Type"), flds["poly"].get("DOC_TYPE")
        cur_tp = _txt(feat[tf]) if tf else ""
        cur_doc = _txt(feat[docf]) if docf else ""
        ntp, ndoc = newv.get("_type"), newv.get("_doc")
        tp = (cur_tp, ntp) if (tf and ntp and ntp != cur_tp) else None
        doc = (cur_doc, ndoc) if (docf and ndoc is not None and ndoc != cur_doc) else None
        final_doc = ndoc if (docf and ndoc is not None) else cur_doc
        return {"key": not same, "type": tp, "doc": doc, "sync": bool(newv.get("_sync")),
                "deed": bool(((not same) or doc) and final_doc == self._DEED),
                "public": bool((not same) and _public_landno(newv.get("LANDNO")))}

    def _ep_deed_dup(self, poly_lyr, point_lyr, feat, flds, newv, plan):
        """★ 2.4.3 ด่านโฉนด "คีย์ไม่ซ้ำ" ของ 📝 — ความหมายเดียวกับ ➕ (_cp_check): แปลงอื่นคีย์เดียวกัน + หมุดคีย์นี้ที่ไม่ใช่ของแปลงนี้
        (คำตัดสิน 21 ต.ค. Q4: หมุดค้างคีย์ใหม่นับว่าซ้ำ) -> None = ผ่าน · ข้อความ = เหตุที่บล็อก · ตรวจไม่ได้ = บล็อก (fail-closed)"""
        try:
            pu = flds["poly"]["UTM"]
            tw = [t for t in self._utm_twin_fids(poly_lyr, pu, newv["UTM"], _norm_utm(newv["UTM"])) if t != feat.id()]
            if tw:
                return (f"UTM {newv['UTM']} ซ้ำกับแปลงอื่นที่มีอยู่แล้ว (gid " + ", ".join(str(x) for x in tw[:5])
                        + (" …" if len(tw) > 5 else "") + ") — แก้ระวาง/เลขที่ดิน หรือแก้คีย์ของแปลงที่ซ้ำก่อน")
            own = set(plan.get("mk_ids") or [])
            if _norm_utm(_txt(feat[pu])) == _norm_utm(newv["UTM"]):
                info = self._parcel_markers(poly_lyr, point_lyr, feat)      # คีย์เดิม ⇒ หมุดคีย์นี้ของแปลงนี้เองไม่นับ
                if info is None:
                    return "อ่านรายชื่อหมุดของแปลงนี้ไม่ได้ — ตรวจคีย์ซ้ำไม่ได้"
                own |= set(info["mk_ids"])
            ex = '"%s" = %s' % (flds["point"]["UTM"], QgsExpression.quotedValue(newv["UTM"]))
            it = point_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(ex).setNoAttributes()
                                       .setFlags(QgsFeatureRequest.NoGeometry))
            try:
                stray = [m.id() for m in it if m.id() not in own]
            finally:
                it.close()
            if stray:
                return f"มีหมุดคีย์ {newv['UTM']} ที่ไม่ใช่ของแปลงนี้อยู่แล้ว {len(stray)} ดวง (แต่ไม่มีแปลง) — ตรวจ/ลบหมุดค้างก่อน"
        except Exception:
            _log_exc("📝 ตรวจคีย์ซ้ำของโฉนดไม่สำเร็จ")
            return "ตรวจคีย์ซ้ำไม่สำเร็จ — ไม่แก้ให้ (กันคีย์ซ้ำ)"
        return None

    def _ep_type_ok(self, poly_lyr, point_lyr, feat, plan):
        """★ 2.4.3 (ยุบ 🏷) ด่านของการเปลี่ยน Type ที่มากับการแก้คีย์/ชนิดเอกสาร — กติกาเดียวกับ 🏷 _change_type_execute
        -> True = ผ่าน (plan['type_mk'] = หมุดที่จะได้ Type ใหม่) · False = ปฏิเสธ (แจ้งแล้ว)
        คีย์เปลี่ยน ⇒ หมุดชุดที่ย้ายตามคีย์ (_ep_plan คัดมุมร่วมกับแฝดออก + ผ่านด่านหมุดล็อกแล้ว) ·
        คีย์เดิม ⇒ หมุดทั้งหมดของแปลง · แปลงแฝด (หมุดแชร์ตามคีย์) ปฏิเสธ · หมุด Type L1 ต้องปลดล็อก (DU-01)"""
        ch = plan.get("ch") or {}
        plan["type_mk"] = []
        if not ch.get("type"):
            return True
        new = ch["type"][1]
        if new.upper() in _TYPE_NOT_ON_MARKER:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"{new} อยู่ในชั้น CT_ ของสาขาเท่านั้น — ตั้งเป็น Type ของแปลง/หมุดไม่ได้")
            return False
        if new not in self._CP_TYPES_ALL:            # ★ 2.4.3 (review 🟡3 · รายการตายตัว) ทางเรียกตรง
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"Type \"{new}\" ไม่อยู่ในรายการ Type ที่ใช้ได้ (" + " · ".join(self._CP_TYPES_ALL) + ") — ยกเลิก")
            return False
        if ch.get("key"):
            mk = list(plan.get("mk_ids") or [])
        else:
            info = self._parcel_markers(poly_lyr, point_lyr, feat)
            if info is None:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          "อ่านค่า UTM/รายชื่อหมุดของแปลงนี้ไม่ได้ — ยกเลิก (กันแก้ Type แปลงแล้วหมุดไม่ตาม)")
                return False
            if info["n_twin"] > 1:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          f"พบแปลงคีย์ซ้ำ (UTM เดียวกัน {info['n_twin']} แปลง) — เปลี่ยน Type อัตโนมัติไม่ได้\n"
                          "เพราะหมุดถูกแชร์ตามคีย์ จะไปโดนหมุดของแปลงแฝดด้วย · แก้คีย์ซ้ำก่อน")
                return False
            if self._parcel_locked_block(info, self._EP_TITLE, "เปลี่ยน Type แปลงนี้ไม่ได้"):
                return False
            mk = list(info["mk_ids"])
        plan["type_mk"] = mk if plan["flds"]["point"].get("Type") else []
        return True

    def _ep_plan(self, poly_lyr, point_lyr, feat, flds, newv):
        """เตรียมงาน: หมุดที่จะเปลี่ยนคีย์ · แปลงแฝด · UTM ใหม่ซ้ำแปลงอื่น -> dict หรือ None (ยกเลิก/แจ้งแล้ว)"""
        pu = flds["poly"]["UTM"]
        old_raw = _txt(feat[pu])
        notes = []
        mk_ids = []
        # ★ 2.3.7 b19 (doc-verify E3) — UTM เท่าเดิมแต่ช่องระวาง/เลขที่ดินของแปลงไม่ตรง (ว่าง/ผิดรูป เช่น MAP3 '684' · LANDNO '0435')
        #   ⇒ หมุดของแปลงต้องได้ช่องเดียวกับแปลงด้วย (เดิมหาหมุดเฉพาะเมื่อ UTM เปลี่ยน ⇒ แปลงได้ช่องใหม่ หมุดค้างช่องเก่า)
        _fix_keys = bool(old_raw) and old_raw == newv["UTM"] and \
            any(_txt(feat[flds["poly"][k]]) != newv[k] for k in self._EP_KEYS)
        if not old_raw:
            notes.append("⚠️ แปลงนี้ไม่มี UTM เดิม — หาหมุดของแปลงไม่ได้ จะเปลี่ยนเฉพาะรูปแปลง (ตรวจ/เติมหมุดเอง)")
        elif old_raw != newv["UTM"] or _fix_keys:
            info = self._parcel_markers(poly_lyr, point_lyr, feat)
            if info is None:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          "อ่านรายชื่อหมุดของแปลงนี้ไม่ได้ (query ล้มเหลว) — ยกเลิก (กันแก้แปลงแล้วหมุดไม่ตาม)")
                return None
            mk_ids = list(info["mk_ids"])
            if info["n_twin"] > 1:
                # แปลงแฝด (UTM เดิมเดียวกัน): เปลี่ยนเฉพาะหมุดบนมุมของแปลงนี้ ที่ไม่ได้อยู่บนมุมของแปลงแฝดด้วย
                mine = [QgsPointXY(v.x(), v.y()) for v in feat.geometry().vertices()]
                twin_v = []
                # ★ 2.3.7 (ให้ตรงกับ 🍩 ข้อ 10 d) — แปลงแฝดชุดเดียวกับที่นับ n_twin (normalise · _utm_twin_fids)
                #   เดิมดึงมุมของแฝดด้วย old_raw ตรงทุกตัวอักษร ⇒ แฝด 'X ' / 'X.0' ถูกนับแต่ไม่ถูกดึงมุมมาเทียบ
                #   ⇒ หมุดบนมุมร่วมกับแฝดถูกเปลี่ยนคีย์ไปด้วย (แฝดเสียหมุด)
                _tw = [t for t in (info.get("twin_fids") or []) if t != feat.id()]
                it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(_tw)) if _tw else None
                try:
                    for tf in (it if it is not None else []):
                        if tf.hasGeometry():
                            twin_v.extend(QgsPointXY(v.x(), v.y()) for v in tf.geometry().vertices())
                finally:
                    if it is not None:
                        it.close()
                keep, at_shared = [], {}
                for mf in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(mk_ids)):
                    if not mf.hasGeometry():
                        continue
                    p = mf.geometry().asPoint()
                    near = [i for i, q in enumerate(mine) if p.distance(q) <= 0.01]
                    if not near:
                        continue
                    if not _fix_keys and any(p.distance(q) <= 0.01 for q in twin_v):
                        # UTM เปลี่ยน ⇒ หมุดมุมร่วมต้องอยู่กับแฝด · ★ b19 E3 UTM เท่าเดิม ⇒ ยังเป็นหมุดของทั้งคู่ แก้ช่องให้ตรง UTM ได้
                        # ★ 2.4.2 — จัดกลุ่มตามมุมของแปลงนี้ (มุมใกล้สุด · คีย์ปัดมิลลิเมตร เพราะจุดปิดวงซ้ำจุดแรก)
                        _c = mine[min(near, key=lambda i: p.distance(mine[i]))]
                        at_shared.setdefault((round(_c.x(), 3), round(_c.y(), 3)), []).append(mf.id())
                        continue
                    keep.append(mf.id())
                moved = single = 0
                for _ids in at_shared.values():
                    if len(_ids) >= 2:
                        # ★ 2.4.2 (เหตุ 15 ต.ค. ปทุมฯ 37 → 688 → 37) — มุมร่วมกับแฝดมีหมุด UTM เดิมซ้อน ≥ 2 ดวง ⇒ ดวงหนึ่งเป็นของแปลงนี้
                        #   (เปลี่ยนคีย์ไปซ้ำแปลงข้างเคียงแล้วเปลี่ยนกลับ: เดิมไม่เปลี่ยนทั้งคู่ ⇒ แปลงนี้มุมไม่มีหมุด + แฝดมีหมุดซ้อน)
                        #   ⇒ ย้ายดวงใหม่สุด 1 ดวงมาเป็นของแปลงนี้ (งานที่ยังไม่บันทึกก่อน แล้ว gid มากสุด) · ที่เหลือคงไว้กับแฝด
                        keep.append(sorted(_ids, key=lambda f: (f >= 0, -abs(f)))[0])
                        moved += 1
                    else:
                        single += 1
                notes.append(f"⚠️ มีแปลงแฝด (UTM เดิมเดียวกัน {info['n_twin']} แปลง) — เปลี่ยนเฉพาะหมุดของแปลงนี้ {len(keep)} ดวง"
                             + (f" · มุมร่วมกับแปลงแฝด {moved} มุมมีหมุดซ้อน ⇒ ย้ายมาเป็นของแปลงนี้มุมละ 1 ดวง" if moved else "")
                             + (f" · มุมร่วมอีก {single} มุมมีหมุดดวงเดียวที่แปลงแฝดใช้อยู่ ไม่เปลี่ยน "
                                "(มุมนั้นของแปลงนี้ต้องเติมหมุดเอง)" if single else ""))
                mk_ids = keep
            # ★ 2.4.0 (review DU-01) — หมุดล็อก (Type L1) ในชุดที่จะเปลี่ยนคีย์ ⇒ ต้องปลดล็อก L1 ก่อน (แบบแก้ชื่อหมุด)
            if self._parcel_locked_block(info, self._EP_TITLE, "แก้ข้อมูลแปลงนี้ไม่ได้", fids=mk_ids):
                return None
        # UTM ใหม่ซ้ำแปลงอื่น (คำตัดสิน 3 ต.ค.: เตือน + ยืนยันเอง)
        dup = []
        if newv["UTM"] != old_raw:
            # ★ 2.3.7 (ให้ตรงกับ 🍩 ข้อ 10 d) — เทียบแบบ normalise (แปลงที่คีย์มีช่องว่างหัว/ท้าย/'.0' นับว่าซ้ำด้วย)
            dup = [t for t in self._utm_twin_fids(poly_lyr, pu, newv["UTM"], _norm_utm(newv["UTM"]))
                   if t != feat.id()]
        return {"poly_lid": poly_lyr.id(), "point_lid": point_lyr.id(), "fid": feat.id(), "flds": flds,
                "old": {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS}, "old_utm": old_raw,
                "new": newv, "mk_ids": mk_ids, "dup": dup, "notes": notes,
                "dup_info": self._ep_dup_info(poly_lyr, feat, flds, dup)}

    def _ep_dup_info(self, poly_lyr, feat, flds, dup):
        """★ 2.4.2 — แปลงที่ UTM ใหม่ไปซ้ำ -> [(gid, Type, มุมร่วมกับแปลงนี้ ≤ 1 ซม., ติดกัน ≤ 1 ซม.)] (ไม่เกิน 20 แปลง)
        ใช้บอกในกล่องเตือนว่ามุมร่วมกี่มุมจะมีหมุด UTM เดียวกันซ้อน · ตรวจไม่ได้ = [] (กล่องเตือนยังขึ้นด้วยรายชื่อ gid)"""
        if not dup:
            return []
        out = []
        try:
            g0 = feat.geometry()
            mine = {}
            for v in g0.vertices():
                mine.setdefault((round(v.x(), 3), round(v.y(), 3)), QgsPointXY(v.x(), v.y()))
            tf_name = flds["poly"].get("Type")
            it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(dup)[:20]))
            try:
                for tf in it:
                    tv = [QgsPointXY(v.x(), v.y()) for v in tf.geometry().vertices()] if tf.hasGeometry() else []
                    k = sum(1 for p in mine.values() if any(p.distance(q) <= 0.01 for q in tv))
                    touch = bool(tv) and not g0.isEmpty() and tf.geometry().distance(g0) <= 0.01
                    out.append((tf.id(), _txt(tf[tf_name]) if tf_name else "", k, touch))
            finally:
                it.close()
        except Exception:
            _log_exc("📝 นับมุมร่วมกับแปลงที่ UTM ซ้ำไม่สำเร็จ")
            return []
        return out

    def _ep_dup_confirm(self, plan):
        """★ 2.4.2 (เจ้าของงานสั่ง 15 ต.ค. "เวลาแก้ไขแล้วไปซ้ำกัน ให้เตือนด้วย") — กล่องเตือนแยกเมื่อ UTM ใหม่ซ้ำแปลงอื่น
        (เดิมเป็นบรรทัดเดียวในกล่องยืนยันยาว ๆ — เหตุ 15 ต.ค. ปทุมฯ: พิมพ์ 688 ที่เป็นเลขของแปลงข้างเคียง แล้วตอบยืนยัน)
        ปุ่มตั้งต้น No · คืน True = ตั้งใจให้เป็นแปลงแฝด (ทำต่อ)"""
        dup, info = plan.get("dup") or [], plan.get("dup_info") or []
        if not dup:
            return True
        n = plan["new"]
        lines = [f"UTM ใหม่ {n['UTM']} (ระวาง {n['UTMMAP1']} {n['UTMMAP2']} {n['UTMMAP3']}-{n['UTMMAP4']} "
                 f"ที่ดิน {n['LANDNO']}) ซ้ำกับแปลงอื่นที่มีอยู่แล้ว {len(dup)} แปลง:"]
        if info:
            for gid, tp, k, touch in info[:5]:
                lines.append(f"  • gid {gid}" + (f" ({tp})" if tp else "")
                             + (f" — ติดกับแปลงนี้ ใช้มุมร่วม {k} มุม" if k else
                                (" — ติดกับแปลงนี้" if touch else " — ไม่ติดกับแปลงนี้")))
        else:
            lines.append("  • gid " + ", ".join(str(x) for x in dup[:5]))
        if len(dup) > 5:
            lines.append(f"  • … อีก {len(dup) - 5} แปลง")
        k_all = sum(k for _g, _t, k, _tc in info)
        lines += ["", "ถ้าเปลี่ยน แปลงนี้จะเป็นแปลงแฝด (UTM เดียวกัน) กับแปลงข้างบน"
                  + (" — ใช้ได้เฉพาะโฉนดเดียวกันที่มีหลายรูป" if not k_all else "")]
        if k_all:
            lines.append(f"⚠️ มุมร่วม {k_all} มุมจะมีหมุด UTM เดียวกันซ้อน 2 ดวง (ด่านก่อนบันทึกจะเตือนหมุดซ้อน) "
                         "และแยกไม่ได้แล้วว่าดวงไหนเป็นของแปลงไหน")
        lines += ["ถ้าพิมพ์เลขผิด ให้ตอบ No · ถ้าเปลี่ยนไปแล้ว ให้กด ↺ Undo ของปลั๊กอิน (คืนแปลงและหมุดครบ)",
                  "", "ตั้งใจให้เป็นแปลงแฝดจริงหรือไม่?"]
        ans = self._ask(QtWidgets.QMessageBox.Warning, "UTM ซ้ำกับแปลงอื่น", "\n".join(lines),
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            self.iface.messageBar().pushMessage(self._EP_TITLE, "ยกเลิก — ยังไม่ได้แก้อะไร (UTM ใหม่ซ้ำกับแปลงอื่น)",
                                                level=0, duration=6)
            return False
        return True

    def _ep_lookup(self, plan):
        """ดึงเนื้อที่ทะเบียนจากระบบกรม (public · thread เบื้องหลัง) แล้วไปขั้นยืนยัน"""
        _w0 = getattr(self, "_ep_worker", None)
        try:
            if _w0 is not None and _w0.isRunning():
                self.iface.messageBar().pushMessage(self._EP_TITLE, "กำลังดึงเนื้อที่อยู่ — รอผลก่อน", level=1, duration=5)
                return
        except Exception:
            pass
        v = plan["new"]
        near_xy = None
        try:
            lyr = QgsProject.instance().mapLayer(plan["poly_lid"])
            c = lyr.getFeature(plan["fid"]).geometry().centroid().asPoint()
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            if lyr.crs() != dst:
                c = QgsCoordinateTransform(lyr.crs(), dst, QgsProject.instance()).transform(c)
            near_xy = (c.x(), c.y())
        except Exception:
            near_xy = None
        _probe = None
        try:
            _probe = _probe_xy_24047(lyr.getFeature(plan["fid"]).geometry(), lyr.crs())    # ★ 2.3.9 ทางสำรอง iLands
        except Exception:
            _probe = None
        try:
            _office = _branch_office_of(QgsProject.instance().mapLayer(plan["poly_lid"]))     # ★ 2.3.10 ล็อกสาขา
        except Exception:
            _office = None
        attrs = {"m1": v["UTMMAP1"], "m2": v["UTMMAP2"], "m3": v["UTMMAP3"], "m4": v["UTMMAP4"],
                 "scale": v["UTMSCALE"], "landno": v["LANDNO"], "near_xy": near_xy, "probe_xy": _probe,
                 "office_seq": _office}
        busy = QtWidgets.QProgressDialog(
            f"กำลังดึงเนื้อที่ทะเบียนจากระบบกรม...\nระวาง {attrs['m1']} {attrs['m2']} {attrs['m3']}-{attrs['m4']} "
            f"ที่ดิน {attrs['landno']}", None, 0, 0, self.iface.mainWindow())
        busy.setWindowTitle(self._EP_TITLE)
        busy.setCancelButton(None)
        busy.setWindowModality(QtCore.Qt.WindowModal)
        busy.show()
        # ★ 2.4.2 rc4 (เจ้าของงาน 21 ต.ค. 69 "ในปุ่มแก้ไขข้อมูลรูปแปลง ถ้าใน arcgis ไม่เจอ ให้ไปหาใน LIS ด้วย")
        #   ค้นทะเบียน iLands แบบ 🔍 (ไม่พบ · ชั้นรอจด · แผนที่บอกไม่มีทะเบียน · ยืนยันแปลงไม่ได้) · ยังไม่เข้าสู่ระบบ ⇒ เด้งกล่องเข้าสู่ระบบ
        w = ParcelLookupWorker(attrs, zone=47, lis_more=True)
        self._ep_worker = w
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)

        def _drop(_w=w):
            try:
                self._net_workers.remove(_w)
            except Exception:
                pass
            try:
                _w.deleteLater()          # finished ยิงหลัง thread จบจริงแล้ว — ลบปลอดภัย (ไม่ลบใน done/fail)
            except Exception:
                pass

        def _end(res, err):
            try:
                busy.close()
                busy.deleteLater()
            except Exception:
                pass
            if not getattr(self, "_alive", True):
                return
            if err is None and isinstance(res, dict) and res.get("lis") == "login" and _ep_hist_key(res):
                # ★ 2.4.3 rc5 (ผลตรวจ Windows rc4 🟡1) — คีย์ชั้นประวัติ: ผลทะเบียนใช้กับ 📝 ไม่ได้อยู่แล้ว ⇒ ไม่เด้งกล่องเข้าสู่ระบบ
                res = dict(res, lis="hist")
            if err is None and isinstance(res, dict) and res.get("lis") == "login":
                # ★ 2.4.2 rc4 — ต้องค้นทะเบียน iLands แต่ยังไม่เข้าสู่ระบบ ⇒ กล่องเข้าสู่ระบบ แล้วค้นต่อ (ยกเลิก = ผลจากแผนที่)
                self._dol_lis_continue(res, attrs, lambda r: self._ep_after_lookup(plan, r, None))
                return
            self._ep_after_lookup(plan, res, err)
        w.finished.connect(_drop)
        w.done.connect(lambda res: _end(res, None))
        w.fail.connect(lambda msg: _end(None, msg))
        w.start()

    @staticmethod
    def _ep_area_result(res, err):
        """ผลจากระบบกรม -> {'area': ตร.ม. หรือ None, 'regis': ค่าใหม่หรือ None, 'note': ข้อความ}
        คำตัดสิน 3 ต.ค.: ดึงไม่ได้ = AREA/REGIS คงเดิม + เตือน · ระบบกรมตอบไม่มีทะเบียน = REGIS 'ไม่มีทะเบียน'"""
        keep = "คงเนื้อที่ทะเบียนเดิม — กดปุ่มนี้ซ้ำภายหลังเพื่อดึงใหม่"
        if err:
            return {"area": None, "regis": None, "note": f"⚠️ ดึงเนื้อที่ทะเบียนจากระบบกรมไม่ได้ ({err}) — {keep}"}
        # ★ 2.4.3 rc4 (ผลตรวจ Windows rc3 🟡1 · เจ้าของงาน 23 ต.ค. "ไม่นับเนื้อที่จากชั้นประวัติในด่านโฉนด") — คีย์ที่แผนที่กรมยกเลิกแล้ว
        #   (ชั้นประวัติอย่างเดียว) ⇒ ➕/📝 ไม่ใช้ผลทะเบียน: ไม่เติม AREA/REGIS · ไม่ล็อกชนิดเอกสาร · ให้แก้คีย์เป็นเลขปัจจุบันก่อน
        #   (🔍 ยังเปิดภาพลักษณ์ + กล่องเทียบเนื้อที่พร้อมคำเตือน) · ★ 2.4.3 rc5 (ผลตรวจ Windows rc4 🟡1) ไม่ว่าผลจะมาทางไหน
        #   (เดิมเฉพาะ via='lis' ⇒ ไม่ได้เข้าสู่ระบบ/ทะเบียนไม่มี ⇒ หมายเหตุ "ไม่พบ" ไม่บอกให้แก้คีย์)
        if _ep_hist_key(res):
            return {"area": None, "regis": None, "hist": True,
                    "note": "⚠️ " + (_EP_HIST_WHY if res.get("via") == "lis" else _EP_HIST_MAP_WHY) + _dol_history_now(res)}
        if not isinstance(res, dict) or res.get("not_found"):
            # ★ rc5 — เลขถูกยกเลิก/รอจด/ผลทะเบียน iLands · ยังไม่เข้าสู่ระบบ ⇒ บอกทางค้นทะเบียน (ทางสุดท้าย ต้อง login)
            _lg = (" · เข้าสู่ระบบ DOL (ปุ่ม 📐 หลักฐานการรังวัด) แล้วค้นใหม่ เพื่อค้นต่อในทะเบียน iLands"
                   if isinstance(res, dict) and res.get("lis") == "login" else "")
            # ★ 2.3.11 — ค้นแบบล็อกสาขา: ไม่พบ "ในสาขานี้" · เลขนี้เป็นของสำนักงานอื่น ⇒ บอกตรง ๆ ที่หัวหมายเหตุ (ไม่ซ้ำบรรทัด ℹ️)
            _d = res if isinstance(res, dict) else {}
            _oo = str((_d.get("other_office") or {}).get("office_seq") or "").strip()
            if _oo:
                _หัว = f"⚠️ เลขนี้เป็นแปลงของสำนักงานที่ดินอื่น (รหัส {_oo}) ไม่มีในสำนักงานที่ดินของสาขานี้ — {keep}"
            elif _d.get("arc_miss"):            # ★ 2.4.1 แผนที่มีเลขนี้ แต่ถามทะเบียนที่จุดกลางไม่ได้
                # ★ 2.4.1 rc2 (ผลตรวจ Windows rc1 ข้อสังเกต 6) — กดซ้ำได้ผลเดิมจนกว่าข้อมูลของกรมจะแก้ ⇒ ไม่ชวนกดซ้ำ
                _หัว = ("⚠️ แผนที่กรมมีเลขนี้ แต่ระบบทะเบียนไม่มีข้อมูลที่ตำแหน่งของแปลงนั้น" if _d.get("arc_miss") == "udm_empty"
                        else "⚠️ แผนที่กรมมีเลขนี้ แต่ไม่มีพิกัดจุดกลางของแปลง") + " — คงเนื้อที่ทะเบียนเดิม"
            elif _d.get("branch_office"):
                _หัว = f"⚠️ ระบบกรมไม่พบแปลงของสาขานี้ตามระวาง/เลขที่ดินนี้ — {keep}"
            else:
                _หัว = f"⚠️ ระบบกรมไม่พบแปลงตามระวาง/เลขที่ดินนี้ — {keep}"
            return {"area": None, "regis": None,
                    "note": _หัว
                            + ((_dol_here_hint(res) + _dol_more_hint(res, skip_other=bool(_oo))).replace("\n\n", " · ")
                               if isinstance(res, dict) else "") + _lg}
        # ★ 2.3.7 b19 (doc-verify E10) — ตัดสิน "ยืนยันแปลงไม่ได้" ก่อน "ไม่มีทะเบียน": dol_api หา MAP_PARCEL_SEQ ของระวางนี้
        #   ในคำตอบ UDM ไม่เจอ ⇒ ใช้ค่าเดี่ยวที่อาจเป็นของแปลงข้างเคียง (not_registered ด้วย) · เดิมตั้ง REGIS 'ไม่มีทะเบียน'
        #   ให้แปลงที่คลิกได้จากผลของแปลงอื่น ⇒ ยืนยันไม่ได้ = คง AREA/REGIS (แบบเดียวกับเนื้อที่)
        # ★ 2.4.2 rc4 — 📝/➕ ค้นทะเบียน iLands แบบ 🔍 แล้ว ⇒ ต่อท้ายผลของทะเบียน (ไม่มีเลขนี้ · ค้นไม่สำเร็จ · ไม่ได้เข้าสู่ระบบ)
        _lh = _dol_lis_hint(res).replace("\n\n", " · ")
        if res.get("via") == "lis" and res.get("cross_office"):
            # ★ 2.4.2 rc4 — ทะเบียนมีเลขนี้ แต่ชั้นไม่ล็อกสาขา + แผนที่มีเลขนี้หลายสำนักงาน ⇒ อาจเป็นแปลงของสำนักงานอื่น = ยืนยันไม่ได้
            return {"area": None, "regis": None,
                    "note": f"⚠️ ทะเบียน iLands มีเลขนี้ แต่ระวาง/เลขที่ดินนี้มี {res.get('cross_office')} แปลงบนแผนที่กรม (คร่อมสาขา) "
                            f"— ยืนยันไม่ได้ว่าเป็นแปลงนี้ · {keep}"}
        if not res.get("verified"):
            _a = _txt(res.get("area"))
            return {"area": None, "regis": None,
                    "note": "⚠️ ระบบกรมตอบแปลงที่ยืนยันไม่ได้ว่าตรงกับระวางนี้"
                            + (f" (เนื้อที่ที่ได้ {_a})" if _a else "") + f" — {keep}" + _lh}
        if res.get("not_registered") and res.get("via") == "arcgis_temp":
            # ★ rc5 — ชั้นแปลงรอจดของกรม + UDM ยืนยันคีย์ตรง แต่ยังไม่มีทะเบียน ⇒ 'รอจดทะเบียน' (ค่าเดียวกับ _CP_REGIS)
            return {"area": None, "regis": "รอจดทะเบียน",
                    "note": "ℹ️ พบในชั้นแปลงรอจดทะเบียนของกรม (รังวัดแล้ว ยังไม่จดทะเบียน) — ตั้ง REGIS = 'รอจดทะเบียน' · คงเนื้อที่เดิม"
                            + _lh}
        if res.get("not_registered"):
            return {"area": None, "regis": "ไม่มีทะเบียน",
                    "note": "⚠️ ระบบกรมแจ้งว่าแปลงนี้ไม่มีทะเบียน — ตั้ง REGIS = 'ไม่มีทะเบียน' · คงเนื้อที่เดิม" + _lh}
        if res.get("via") == "lis":
            # ★ rc5 — พบในทะเบียน iLands ⇒ มีทะเบียนแน่
            # ★ 2.4.2 E9 — เนื้อที่จากหน้ารายละเอียดของทะเบียน (คีย์ในหน้าตรงทุกท่อน · ทะเบียนตอบรายการเดียว) · ไม่ได้ ⇒ เนื้อที่คงเดิม + เหตุ
            #   (เดิม: ตารางผลค้นของหน้า LIS ไม่มีเนื้อที่ ⇒ ไม่เคยได้เนื้อที่จากทางนี้)
            _โฉนด = f"โฉนด {_txt(res.get('parcel_no')) or '-'} · หน้าสำรวจ {_txt(res.get('survey_no')) or '-'}"
            m2 = _dol_area_m2(res.get("area"))
            if m2 is None:
                _why = _txt(res.get("area_why"))
                return {"area": None, "regis": "มีทะเบียน",
                        "note": f"{_dol_via_note(res)} ({_โฉนด}) — ไม่ได้เนื้อที่ทะเบียน" + (f" ({_why})" if _why else "")
                                + f" · {keep}"}
            return {"area": m2, "regis": "มีทะเบียน", "via": "lis",
                    "note": f"เนื้อที่ทะเบียนจากทะเบียน iLands: {_rngw(m2)} ไร่-งาน-วา = {m2:,.2f} ตร.ม. "
                            f"({_โฉนด} · {_dol_via_note(res)})"}
        m2 = _dol_area_m2(res.get("area"))
        if m2 is None:
            return {"area": None, "regis": None,
                    "note": f"⚠️ อ่านเนื้อที่จากระบบกรมไม่ได้ ('{_txt(res.get('area'))}') — {keep}"}
        note = f"เนื้อที่ทะเบียนจากระบบกรม: {_rngw(m2)} ไร่-งาน-วา = {m2:,.2f} ตร.ม."
        if (res.get("match_count") or 1) > 1:
            note += (f" (พบเลขนี้ {res.get('match_count')} แปลงในสาขานี้ — เลือกแปลงที่ใกล้รูปนี้ที่สุดแล้ว)"   # ★ 2.3.11
                     if res.get("branch_office") else " (ระวางคร่อมสาขา — เลือกแปลงที่ใกล้รูปนี้ที่สุดแล้ว)")
        if _dol_via_note(res):                   # ★ rc5 — udm_point · ชั้นรอจด · ชั้นประวัติ
            note += " (%s)" % _dol_via_note(res)
        # ★ 2.4.3 (review ⚪5) via = ที่มาของเนื้อที่ (ด่านโฉนดสุดท้ายใน _ep_apply ไม่นับชั้นประวัติ)
        return {"area": m2, "regis": "มีทะเบียน", "note": note, "via": res.get("via")}

    @staticmethod
    def _ep_deed_block(res, ar):
        """★ 2.4.3 ด่านโฉนดที่ดินของ ➕/📝 (เจ้าของงาน 21 ต.ค. 69 "ถ้าเป็นโฉนดที่ดิน ต้องค้นหาทะเบียนและได้เนื้อที่ทะเบียนมาด้วย
        และคีย์ไม่ซ้ำ ถึงจะสร้างได้" · "ปุ่มแก้ไขข้อมูลด้วย … ถึงจะเปลี่ยนได้") — ar = ผล `_ep_area_result`
        -> None = ผ่าน · ข้อความ = เหตุที่บล็อก
        คำตัดสิน: ไม่ได้เนื้อที่ (ไม่พบ · กรมบอกรอจด · ระบบกรมล่ม · ยังไม่เข้าสู่ระบบ LIS) = บล็อกทุกกรณี ·
                  เนื้อที่จากชั้นประวัติแผนที่กรม (เลขถูกยกเลิก/เปลี่ยนแล้ว) ไม่นับ"""
        if _ep_hist_key(res):                                    # ★ 2.4.3 rc4 (ผลตรวจ Windows rc3 🟡1) · rc5 ทุกทาง (rc4 🟡1)
            return (_EP_HIST_WHY if res.get("via") == "lis" else _EP_HIST_MAP_WHY) + _dol_history_now(res)
        if ar.get("area") is not None:
            if isinstance(res, dict) and res.get("via") == "arcgis_history":
                return "พบแค่ในชั้นประวัติของแผนที่กรม (เลขนี้ถูกยกเลิก/เปลี่ยนไปแล้ว) — ใช้เป็นเนื้อที่ทะเบียนของโฉนดไม่ได้"
            # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪5 · เจ้าของงาน 22 ต.ค. "บล็อก") — ได้เนื้อที่แต่ทะเบียนบอกว่าเป็นชนิดอื่น
            #   (เช่น น.ส.3 ก) ⇒ เป็นโฉนดที่ดินไม่ได้ · ทะเบียนไม่บอกชนิด/อ่านชนิดไม่ออก ⇒ ด่านเดิม
            _pt = _txt(res.get("parcel_type")) if isinstance(res, dict) else ""
            _rd = _dol_doc_code(_pt)
            if _rd and _rd != "โฉนดที่ดิน":
                return f"ทะเบียนบอกว่าแปลงนี้เป็น {_pt} ไม่ใช่โฉนดที่ดิน — เลือกชนิดเอกสารให้ตรงทะเบียน"
            return None
        why = {"รอจดทะเบียน": "กรมแจ้งว่ารอจดทะเบียน (ยังไม่มีเนื้อที่ทะเบียน)",
               "ไม่มีทะเบียน": "กรมแจ้งว่าแปลงนี้ไม่มีทะเบียน",
               "มีทะเบียน": "พบในทะเบียน แต่ไม่ได้เนื้อที่ทะเบียน"}.get(ar.get("regis"))
        if why is None:
            why = _txt(ar.get("note")).split(" — ")[0].replace("⚠️ ", "").replace("ℹ️ ", "") or "ไม่ได้เนื้อที่ทะเบียน"
        _lis = (res or {}).get("lis") if isinstance(res, dict) else None
        if _lis == "login":
            why += " · ยังไม่ได้ค้นทะเบียน iLands (ต้องเข้าสู่ระบบ)"
        elif _lis == "skipped":
            why += " · ยกเลิกการเข้าสู่ระบบทะเบียน iLands"
        elif _lis == "busy":                          # ★ 2.4.3 (review ⚪6) ไม่ได้ค้นเพราะมีงานอื่นค้าง — ผู้ใช้ไม่ได้ยกเลิก
            why += " · ยังไม่ได้ค้นทะเบียน iLands (มีงานค้นทะเบียนอื่นหรือกล่องเข้าสู่ระบบค้างอยู่ — ปิดงานนั้นแล้วลองใหม่)"
        return why

    def _ep_after_lookup(self, plan, res, err):
        self._dol_log_lis_trace(res)                  # ★ 2.4.2 rc4 (ผลตรวจ Windows rc3 ข้อพบ 7)
        ready = self._ep_ready_again()
        if not ready:
            return
        poly_lyr, point_lyr = ready
        if (poly_lyr.id(), point_lyr.id()) != (plan["poly_lid"], plan["point_lid"]):
            return
        feat = poly_lyr.getFeature(plan["fid"])
        if feat is None or not feat.isValid():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE, "ไม่พบแปลงนี้แล้ว (ถูกลบระหว่างรอ?) — ยกเลิก")
            return
        flds = plan["flds"]
        # ★ 2.3.7 b19 (doc-verify E1) — เทียบคอลัมน์ UTM ด้วย (เดิมเทียบแค่ 6 ช่องคีย์ ⇒ UTM ถูกแก้ระหว่างรอแล้วยังเขียนทับ ·
        #   หมุดในแผนเป็นชุดของ UTM ตอนคลิก) · ไม่ตรง = ไม่เขียนอะไร
        if {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS} != plan["old"] or \
                _txt(feat[flds["poly"]["UTM"]]) != plan["old_utm"]:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ข้อมูลระวาง/UTM ของแปลงนี้ถูกแก้ระหว่างรอระบบกรม — ยกเลิก (ยังไม่ได้แก้อะไร) กดปุ่มใหม่อีกครั้ง")
            return
        # ★ 2.3.7 b19 (doc-verify E1) — ด่านล็อก L1 ซ้ำหลังรอ: เดิมตรวจแค่ตอนคลิก ⇒ กด Esc ที่กล่องรอ → 🔒 ล็อก L1 กลับ → Yes
        #   = แก้คีย์แปลง L1 ทั้งที่ล็อกอยู่ (probe a2) · อ่าน Type สดจากแปลง (Type เปลี่ยนเป็น L1 ระหว่างรอก็ถูกกัน)
        #   กล่องยืนยันข้างล่างเป็น application-modal ⇒ หลังด่านนี้สลับล็อก/แก้แปลงไม่ได้จนตอบกล่อง
        _tp = _txt(feat[flds["poly"]["Type"]]).upper() if flds["poly"]["Type"] else ""
        if _tp in ("L1-RTK", "L1-TS", "CT-RTK") and not self._l1_unlocked():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"แปลงนี้เป็น {_tp} (ชั้นอ้างอิงพิกัดหลัก) และตอนนี้ล็อก L1 อยู่ — ยกเลิก (ยังไม่ได้แก้อะไร)\n"
                      "ต้องกดปุ่ม 🔓 ปลดล็อก L1 ก่อน แล้วกดปุ่ม 📝 แก้ไขข้อมูลรูปแปลง ใหม่อีกครั้ง")
            return
        # ★ rc2 (audit A3-02 + ข้อที่ผู้ตรวจทานพบเพิ่ม) — ตรวจแผนซ้ำหลังรอระบบกรม (กล่องรอปิดด้วย Esc ได้ ⇒ ระหว่างรอแก้งานต่อได้)
        #   เดิมใช้ชุดหมุด (mk_ids) · ด่านหมุดล็อก (DU-01 `_parcel_locked_block`) · ผล "UTM ใหม่ซ้ำแปลงอื่น" (dup) ของตอนคลิก
        #   ⇒ 🔒 ล็อก L1 กลับระหว่างรอ = หมุด Type L1 ถูกเปลี่ยนคีย์ทั้งที่ล็อก · Add Node มุมใหม่ระหว่างรอ = หมุดใหม่ค้างคีย์เดิม (หมุดลอย)
        #   · มีคน ➕ สร้างแปลงด้วยคีย์ใหม่ระหว่างรอ = กล่องยืนยันไม่เตือนคีย์ซ้ำ
        #   ⇒ คำนวณแผนใหม่: ด่านล็อกไม่ผ่าน = หยุด (แจ้งแล้ว) · ชุดหมุดเปลี่ยน = ยกเลิก · ใช้ dup/หมายเหตุชุดใหม่
        _p2 = self._ep_plan(poly_lyr, point_lyr, feat, flds, plan["new"])
        if _p2 is None:
            return
        if set(_p2["mk_ids"]) != set(plan["mk_ids"]):
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "หมุดของแปลงนี้เปลี่ยนระหว่างรอระบบกรม — ยกเลิก (ยังไม่ได้แก้อะไร) กดปุ่ม 📝 ใหม่อีกครั้ง")
            return
        _new_dup = set(_p2["dup"]) - set(plan.get("dup") or [])
        plan = dict(plan, dup=_p2["dup"], notes=_p2["notes"], dup_info=_p2.get("dup_info") or [])
        ch = plan.get("ch") or {}
        if ch.get("deed"):
            # ★ 2.4.3 ด่านโฉนด ซ้ำหลังรอระบบกรม — มีแปลง/หมุดใช้คีย์นี้เพิ่มระหว่างรอ ⇒ บล็อก (ไม่ใช่กล่องเตือน E1)
            why = self._ep_deed_dup(poly_lyr, point_lyr, feat, flds, plan["new"], plan)
            if why:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          f"แก้ไม่ได้ — โฉนดที่ดินต้องมีคีย์ไม่ซ้ำ\n{why}\n(ยังไม่ได้แก้อะไร)")
                return
        elif ch.get("public"):
            if self._ep_public_dup_block(poly_lyr, point_lyr, feat, flds, plan["new"], plan):    # ★ 2.4.3 rc2 ที่สาธารณะ: ซ้ำ = บล็อก
                return
        elif _new_dup and not self._ep_dup_confirm(plan):    # ★ 2.4.2 มีแปลงใช้ UTM นี้เพิ่มระหว่างรอระบบกรม ⇒ เตือนแยกอีกครั้ง
            return
        if not self._ep_type_ok(poly_lyr, point_lyr, feat, plan):    # ★ 2.4.3 ด่าน Type ซ้ำหลังรอ (หมุด/แฝดอาจเปลี่ยนระหว่างรอ)
            return
        if plan.get("skip_dol"):
            ar = {"area": None, "regis": None,
                  "note": ("ℹ️ ที่สาธารณะ (เลขที่ดิน ≤ 0) ไม่มีทะเบียนให้ค้น — ไม่ได้ถามระบบกรม · เนื้อที่/REGIS คงเดิม"
                           if plan.get("skip_dol") == "public" else
                           "ℹ️ ไม่ได้ถามระบบกรม (เปลี่ยนแค่ Type/ชนิดเอกสาร) — เนื้อที่/REGIS คงเดิม")}
        else:
            ar = self._ep_area_result(res, err)
        if ch.get("deed"):
            # ★ 2.4.3 ด่านโฉนดที่ดิน (คำตัดสิน 21 ต.ค. 69: ไม่ได้เนื้อที่ทุกกรณี = บล็อก · ชั้นประวัติไม่นับ) — ไม่แก้อะไรเลย (REGIS ก็ไม่ตั้ง)
            why = self._ep_deed_block(res, ar)
            if why:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          (f"แก้ไม่ได้ — {why}\n(ยังไม่ได้แก้อะไร)" if why.startswith("ทะเบียนบอกว่าแปลงนี้เป็น") else    # ★ rc2 ⚪5
                           "แก้ไม่ได้ — โฉนดที่ดินต้องค้นทะเบียนและได้เนื้อที่ทะเบียนก่อน จึงจะเปลี่ยนคีย์/ชนิดเอกสารได้\n"
                           f"{why}\n(ยังไม่ได้แก้อะไร)"))
                return
        o, n = plan["old"], plan["new"]
        line = lambda d: f"ระวาง {d['UTMMAP1']} {d['UTMMAP2']} {d['UTMMAP3']}-{d['UTMMAP4']} · 1:{d['UTMSCALE']} · ที่ดิน {d['LANDNO']}"  # noqa: E731
        txt = [f"แปลง gid {plan['fid']}"]
        if ch.get("type"):
            # ★ 2.4.3 (ยุบ 🏷) หัวแดงแบบ 🏷 เมื่อถอดออก/เลื่อนขึ้นชั้นอ้างอิง
            _o_t, _n_t = ch["type"]
            if _o_t.upper() in ("L1-RTK", "L1-TS", "CT-RTK"):
                txt.insert(0, f"🔴 กำลังถอดแปลงออกจากชั้นอ้างอิง ({_o_t} -> {_n_t}) — "
                              "แปลงข้างเคียงที่เคยยึดพิกัดจากแปลงนี้จะไม่มีตัวอ้างอิงแล้ว\n")
            elif _n_t.upper() in ("L1-RTK", "L1-TS", "CT-RTK"):
                txt.insert(0, f"🔴 กำลังเลื่อนแปลงขึ้นเป็นชั้นอ้างอิง ({_o_t or '(ว่าง)'} -> {_n_t}) — "
                              "แปลงนี้จะถูกล็อกห้ามขยับ และคนอื่นจะเอาไปใช้ยึดพิกัด\n")
        _keys_diff = any(o[k] != n[k] for k in self._EP_KEYS)
        if n["UTM"] != plan["old_utm"] or _keys_diff:
            txt.append(f"{line(o)}\n  →  {line(n)}")
            if n["UTM"] != plan["old_utm"]:
                txt.append(f"UTM: {plan['old_utm'] or '(ว่าง)'}  →  {n['UTM']}")
                txt.append(f"หมุดของแปลงนี้ที่จะเปลี่ยนคีย์ตาม: {len(plan['mk_ids'])} ดวง")
            else:
                # ★ 2.3.7 b19 (doc-verify E3) — UTM เท่าเดิม: แก้แค่ช่องระวาง/เลขที่ดินให้ตรงกับ UTM (แปลง + หมุดของแปลง)
                txt.append(f"UTM: {n['UTM']} (ไม่เปลี่ยน — แก้ช่องระวาง/เลขที่ดินให้ตรงกับ UTM)")
                txt.append(f"หมุดของแปลงนี้ที่จะแก้ช่องระวาง/เลขที่ดินตาม: {len(plan['mk_ids'])} ดวง")
        else:
            txt.append("ระวาง/เลขที่ดินไม่เปลี่ยน" + ("" if (ch.get("type") or ch.get("doc"))
                                                    else " — ดึงเนื้อที่ทะเบียนใหม่อย่างเดียว"))
        txt += plan["notes"]
        if plan.get("pub_note"):                            # ★ 2.4.3 rc2 เลขที่สาธารณะที่คิดให้
            txt.append(plan["pub_note"])
        if ch.get("type"):                                  # ★ 2.4.3 (ยุบ 🏷)
            txt.append(f"Type: {ch['type'][0] or '(ว่าง)'}  →  {ch['type'][1]} (แปลง + หมุดของแปลง {len(plan.get('type_mk') or [])} ดวง)")
        if ch.get("doc"):                                   # ★ 2.4.3 ชนิดเอกสารสิทธิ์
            txt.append(f"ชนิดเอกสาร: {ch['doc'][0] or '(ว่าง)'}  →  {ch['doc'][1] or '(ว่าง)'}")
        if plan["dup"]:
            _k = sum(k for _g, _t, k, _tc in (plan.get("dup_info") or []))      # ★ 2.4.2 มุมร่วมที่จะมีหมุดซ้อน
            txt.append(f"⚠️ UTM ใหม่ซ้ำกับแปลงอื่นในชั้นนี้ {len(plan['dup'])} แปลง (gid "
                       + ", ".join(str(x) for x in plan["dup"][:5]) + (" …" if len(plan["dup"]) > 5 else "")
                       + ")" + (f" · มุมร่วม {_k} มุมจะมีหมุด UTM เดียวกันซ้อน" if _k else "")
                       + " — ตั้งใจให้เป็นแปลงแฝดหรือไม่?")
        txt.append(ar["note"])
        af = flds["poly"]["AREA"]
        if ar["area"] is not None and af:
            old_a = _txt(feat[af])
            txt.append(f"AREA: {old_a or '(ว่าง)'}  →  {ar['area']:,.2f} ตร.ม.")
        rf = flds["poly"]["REGIS"]
        if ar["regis"] is not None and rf and _txt(feat[rf]) != ar["regis"]:
            txt.append(f"REGIS: {_txt(feat[rf]) or '(ว่าง)'}  →  {ar['regis']}")
        # ★ 2.3.7 b19 (doc-verify E3) — ช่องระวาง/เลขที่ดินเปลี่ยน (UTM เท่าเดิม) ก็ต้องแก้ แม้ดึงเนื้อที่ไม่ได้ (เดิม "ไม่มีอะไรต้องแก้")
        if not (n["UTM"] != plan["old_utm"] or _keys_diff or ar["area"] is not None or
                (ar["regis"] is not None and rf and _txt(feat[rf]) != ar["regis"]) or ch.get("type") or ch.get("doc")):
            self._ask(QtWidgets.QMessageBox.Information, self._EP_TITLE, "\n".join(txt + ["", "ไม่มีอะไรต้องแก้"]))
            return
        ans = self._ask(QtWidgets.QMessageBox.Question, "ยืนยัน" + self._EP_TITLE, "\n".join(txt + ["", "ยืนยัน?"]),
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return
        # ★ 2.4.3 rc2 (⚪5) ชนิดเอกสารที่ทะเบียนบอก — ด่านสุดท้ายใน _ep_apply ใช้ซ้ำ
        ar["reg_doc"] = _dol_doc_code(res.get("parcel_type")) if isinstance(res, dict) else None
        if self._ep_apply(poly_lyr, point_lyr, feat, plan, ar):
            _ex = ((f" · Type {ch['type'][1]}" if ch.get("type") else "")
                   + (f" · ชนิดเอกสาร {ch['doc'][1] or '(ว่าง)'}" if ch.get("doc") else ""))
            self.iface.messageBar().pushMessage(
                self._EP_TITLE, f"แก้แล้ว (ยังไม่บันทึก) — UTM {n['UTM']} · หมุด {len(plan['mk_ids'])} ดวง{_ex} · กด 💾 บันทึก",
                level=0, duration=8)     # ★ 2.3.7 (review UX-35) ยังไม่ลงฐาน ⇒ ฟ้า (เดิมเขียว "สำเร็จ")
            if ch.get("sync") and not ch.get("type"):
                # ★ 2.4.3 ติ๊ก "ปรับ Type หมุดให้ตรงแปลง" มากับการแก้อย่างอื่น ⇒ ขั้นต่อ (ทาง 🏷 เดิม · กล่องแจกแจง · คำสั่งแยก)
                _f2 = poly_lyr.getFeature(plan["fid"])
                if _f2 is not None and _f2.isValid():
                    self._change_type_execute(poly_lyr, point_lyr, _f2, preset=self._poly_type_str(poly_lyr, _f2))

    def _ep_apply(self, poly_lyr, point_lyr, feat, plan, ar):
        """เขียนลง edit buffer ในคำสั่งเดียว (แปลง + หมุด) — ล้มที่ใด = ทิ้งทั้งชุดด้วย destroyEditCommand (DI-33)
        ★ 2.4.3 Type (แปลง + หมุด plan['type_mk']) และ DOC_TYPE ลงคำสั่งเดียวกัน (↺ Undo ครั้งเดียวคืนครบ)"""
        flds, n = plan["flds"], plan["new"]
        ch = plan.get("ch") or {}
        # ★ 2.4.3 ด่านโฉนดสุดท้าย (ทางเรียกตรง) — ไม่มีเนื้อที่ทะเบียน = ไม่เขียน
        #   ★ (review ⚪5) ไม่เชื่อ plan['ch'] อย่างเดียว: คำนวณซ้ำจากแปลง + ค่าใหม่ (ชนิดเอกสารหลังแก้เป็นโฉนด และคีย์/ชนิดเอกสารเปลี่ยน) ·
        #   เนื้อที่จากชั้นประวัติแผนที่กรม (ar['via']) ก็ไม่นับ — แบบ _ep_deed_block
        _docf = flds["poly"].get("DOC_TYPE")
        _fdoc = ((ch["doc"][1] if ch.get("doc") else _txt(feat[_docf])) if _docf else "")
        _kch = _norm_utm(_txt(feat[flds["poly"]["UTM"]])) != _norm_utm(n["UTM"]) or not _txt(feat[flds["poly"]["UTM"]])
        if (ch.get("deed") or (_fdoc == self._DEED and (_kch or ch.get("doc")))) and \
                (ar.get("area") is None or ar.get("via") == "arcgis_history" or ar.get("hist")
                 or (ar.get("reg_doc") and ar.get("reg_doc") != self._DEED)):          # ★ rc2 (⚪5) ทะเบียนบอกชนิดอื่น
            # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪8) — เดิมปฏิเสธเงียบ ⇒ บอกเหตุ (เกิดเมื่อชนิดเอกสาร/คีย์ถูกแก้นอกปลั๊กอินระหว่างรอ)
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "แก้ไม่ได้ (ด่านสุดท้ายก่อนเขียน) — โฉนดที่ดินต้องได้เนื้อที่ทะเบียนของคีย์นี้ และทะเบียนต้องไม่บอกว่าเป็นชนิดอื่น\n"
                      "(ชนิดเอกสารหรือคีย์อาจถูกแก้ระหว่างรอระบบกรม — ตรวจแล้วกดปุ่มใหม่)\n(ยังไม่ได้แก้อะไร)")
            return False
        # ★ 2.4.3 rc2 ด่านสุดท้าย (ทางเรียกตรง) — คีย์ใหม่เป็นที่สาธารณะที่แปลง/หมุดอื่นใช้อยู่ ⇒ ไม่เขียน (ฐานมี unique index)
        if _kch and _public_landno(n.get("LANDNO")) and \
                self._ep_public_dup_block(poly_lyr, point_lyr, feat, flds, n, plan):
            return False
        # ★ 2.4.3 (review 🟡3 · รายการตายตัว เจ้าของงาน 21 ต.ค.) Type/ชนิดเอกสารใหม่ต้องอยู่ในรายการ (_ep_type_ok / กล่องแจ้งแล้ว)
        if ch.get("type") and ch["type"][1] not in self._CP_TYPES_ALL:
            return False
        if ch.get("doc") and ch["doc"][1] not in self._CP_DOC_CODES:
            return False                                # รวมล้างเป็นว่าง (คำตัดสิน 21 ต.ค.: ล้างไม่ได้)
        changes = []                                    # (lyr, fid, field_name, new, old)
        for k in self._EP_KEYS + ("UTM",):
            fn = flds["poly"][k]
            old = feat[fn]
            if _txt(old) != n[k]:
                changes.append((poly_lyr, feat.id(), fn, n[k], old))
        if ar["area"] is not None and flds["poly"]["AREA"]:
            fa = flds["poly"]["AREA"]
            changes.append((poly_lyr, feat.id(), fa, float(round(ar["area"], 2)), feat[fa]))
            if flds["poly"]["DIFF_AREA"] and ar["area"] > 0:
                # trigger คำนวณ DIFF_AREA เฉพาะตอน geom เปลี่ยน ⇒ คำนวณเองด้วยสูตรเดียวกัน (ร้อยละ)
                fd = flds["poly"]["DIFF_AREA"]
                ga = self._geom_area_m2(poly_lyr, feat.geometry())
                changes.append((poly_lyr, feat.id(), fd, round((ga - ar["area"]) / ar["area"] * 100.0, 2), feat[fd]))
        if ar["regis"] is not None and flds["poly"]["REGIS"]:
            fr = flds["poly"]["REGIS"]
            if _txt(feat[fr]) != ar["regis"]:
                changes.append((poly_lyr, feat.id(), fr, ar["regis"], feat[fr]))
        # ★ 2.3.7 b19 (doc-verify E3) — หมุดในแผนได้ช่องเดียวกับแปลงเสมอ (UTM เปลี่ยน หรือแก้ช่องระวางให้ตรง UTM · เดิมเฉพาะ UTM เปลี่ยน)
        #   แผนใส่หมุดเฉพาะสองกรณีนี้ ⇒ ดึงเนื้อที่อย่างเดียวยังไม่แตะหมุด
        if plan["mk_ids"]:
            for mf in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(plan["mk_ids"])):
                for k in self._EP_KEYS + ("UTM",):
                    fn = flds["point"][k]
                    if _txt(mf[fn]) != n[k]:
                        changes.append((point_lyr, mf.id(), fn, n[k], mf[fn]))
        n_base = len(changes)                           # ★ 2.4.3 คีย์/เนื้อที่/REGIS (แถว 'rekeyed') — ที่ต่อจากนี้ = Type/ชนิดเอกสาร
        tf, mtf, docf = flds["poly"].get("Type"), flds["point"].get("Type"), flds["poly"].get("DOC_TYPE")
        if ch.get("type") and tf:
            _nt = ch["type"][1]
            if _txt(feat[tf]) != _nt:
                changes.append((poly_lyr, feat.id(), tf, _nt, feat[tf]))
            _mt = _marker_type_from_parcel(_nt)         # แบบ ➕/Add Node (CT-RTK ไม่ลงหมุด — แต่ไม่มีในรายการอยู่แล้ว)
            if mtf and _mt and plan.get("type_mk"):
                for mf in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(plan["type_mk"])):
                    if _txt(mf[mtf]) != _mt:
                        changes.append((point_lyr, mf.id(), mtf, _mt, mf[mtf]))
        if ch.get("doc") and docf:
            changes.append((poly_lyr, feat.id(), docf, ch["doc"][1] or None, feat[docf]))
        if not changes:
            return False
        lyrs = [poly_lyr] + ([point_lyr] if any(c[0] is point_lyr for c in changes) else [])
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(*lyrs, title=self._EP_TITLE, what="ยังไม่ได้แก้ข้อมูลแปลง"):
            return False
        self._op_begin(lyrs)
        for l in lyrs:
            l.beginEditCommand(self._EP_TITLE)
        ok_all = True
        try:
            for l, fid, fn, new, old in changes:
                ok_all = bool(l.changeAttributeValue(fid, l.fields().indexOf(fn), new, old)) and ok_all
        except Exception:
            ok_all = False
        for l in lyrs:
            try:
                (l.endEditCommand if ok_all else l.destroyEditCommand)()
            except Exception:
                pass
        self._op_commit()
        if not ok_all:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "เขียนค่าไม่สำเร็จบางส่วน — ทิ้งทั้งชุดแล้ว (ไม่มีอะไรเปลี่ยน)")
            return False
        _ux = self._ux_mark(poly_lyr)                   # ★ 2.3.7 (audit F8) ผูกกับคำสั่งแก้ไข (ทุกแถวของคำสั่งนี้)
        _base = [c for c in changes[:n_base] if c[0] is poly_lyr]
        _tp_final = ch["type"][1] if (ch.get("type") and tf) else (_txt(feat[tf]) if tf else "")
        if changes[:n_base]:                            # ★ 2.4.3 แถว 'rekeyed' เฉพาะเมื่อแก้คีย์/เนื้อที่/REGIS (Type/ชนิดเอกสาร = แถวของตัวเอง)
            self._pending_type_log.append({
                'lid': poly_lyr.id(), 'ux': _ux,
                # ★ 2.3.7 b17 (audit R2-D2) — คอลัมน์ของแปลงที่เปลี่ยน + ค่าก่อน/หลัง (คีย์ · UTM · AREA · DIFF_AREA · REGIS)
                'fx': ('attr', tuple(c[2] for c in _base), tuple(_txt(c[4]) for c in _base), tuple(_txt(c[3]) for c in _base)),
                'gid': feat.id(), 'utm': n["UTM"], 'old': None, 'new': _tp_final,
                'n_mk': len(plan["mk_ids"]), 'action': 'rekeyed',
                'op': (f"UTM {plan['old_utm'] or '(ว่าง)'} -> {n['UTM']}"
                       + (" (แก้ช่องระวาง/เลขที่ดินให้ตรง UTM)" if n["UTM"] == plan["old_utm"]           # ★ b19 E3
                          and any(plan["old"][k] != n[k] for k in self._EP_KEYS) else "")
                       + (f" · AREA {ar['area']:.2f}" if ar["area"] is not None else " · AREA คงเดิม")
                       + (f" · REGIS {ar['regis']}" if ar["regis"] else "")
                       + f" · หมุด {len(plan['mk_ids'])} จุด · MLEP {self.version}")})
        if ch.get("type") and tf:
            # ★ 2.4.3 (ยุบ 🏷) แถว 'retyped' แบบ 🏷 (trigger ของฐานไม่จับการเปลี่ยน Type)
            _n_mt = sum(1 for c in changes[n_base:] if c[0] is point_lyr)
            self._pending_type_log.append({
                'lid': poly_lyr.id(), 'gid': feat.id(), 'utm': n["UTM"], 'old': ch["type"][0], 'new': ch["type"][1],
                'n_mk': _n_mt, 'ux': _ux, 'fx': ('attr', (tf,), (_txt(feat[tf]),), (_txt(ch["type"][1]),)),
                'op': f"Type {ch['type'][0] or '(ว่าง)'} -> {ch['type'][1]} · หมุด {_n_mt} จุด · 📝 · MLEP {self.version}"})
        if ch.get("doc") and docf:
            # ★ 2.4.3 แถว 'redoc' (ใหม่ · Move_Log ไม่มี CHECK ของ action — ตรวจฐานจริงแล้ว 21 ต.ค.)
            self._pending_type_log.append({
                'lid': poly_lyr.id(), 'gid': feat.id(), 'utm': n["UTM"], 'old': None, 'new': _tp_final,
                'n_mk': 0, 'action': 'redoc', 'ux': _ux,
                'fx': ('attr', (docf,), (_txt(feat[docf]),), (_txt(ch["doc"][1]),)),
                'op': f"DOC_TYPE {ch['doc'][0] or '(ว่าง)'} -> {ch['doc'][1] or '(ว่าง)'} · 📝 · MLEP {self.version}"})
        self._locked_cache = None        # แผนที่ล็อก L1 ผูกกับ UTM/Type — คีย์/Type เปลี่ยนต้องอ่านใหม่
        return True
