# -*- coding: utf-8 -*-
"""แก้ข้อมูลแปลง (ระวาง/เลขที่ดิน) พร้อมค้นเนื้อที่

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeatureRequest, QgsPointXY,
                       QgsProject)
from ..core.util import (_branch_office_of, _dol_area_m2, _dol_here_hint, _dol_more_hint, _dol_via_note,
                         _ep_normalize, _EP_SCALES, _fld_idx, _norm_utm, _probe_xy_24047, _rngw, _txt,
                         _UTM_FIELD_NAMES)
from ..map_tools import PolygonPickTool
from ..services.workers import ParcelLookupWorker


class EditParcelMixin:
    """แก้ข้อมูลแปลง (ระวาง/เลขที่ดิน) พร้อมค้นเนื้อที่"""

    def _ep_fields(self, poly_lyr, point_lyr):
        """ชื่อคอลัมน์จริงที่ต้องใช้ -> dict หรือ None (ขาดคอลัมน์คีย์ = ทำไม่ได้)"""
        out = {"poly": {}, "point": {}}
        for tag, lyr in (("poly", poly_lyr), ("point", point_lyr)):
            fl = lyr.fields()
            for k in self._EP_KEYS:
                i = _fld_idx(fl, k)
                if i < 0:
                    return None
                out[tag][k] = fl.at(i).name()
            u = self._resolve_field(lyr, _UTM_FIELD_NAMES)
            if not u:
                return None
            out[tag]["UTM"] = u
        for k in ("AREA", "DIFF_AREA", "REGIS", "Type"):
            i = _fld_idx(poly_lyr.fields(), k)
            out["poly"][k] = poly_lyr.fields().at(i).name() if i >= 0 else None
        return out

    def start_edit_parcel_data(self):
        ready = self._admin_ready(self._EP_TITLE)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        flds = self._ep_fields(poly_lyr, point_lyr)
        if flds is None:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ชั้นแปลงหรือชั้นหมุดไม่มีคอลัมน์ UTMMAP1-4 / UTMSCALE / LANDNO / UTM ครบ — แก้ไม่ได้")
            return
        for lyr, cols in ((poly_lyr, list(self._EP_KEYS) + ["UTM", "AREA", "DIFF_AREA", "REGIS"]),
                          (point_lyr, list(self._EP_KEYS) + ["UTM"])):
            tag = "poly" if lyr is poly_lyr else "point"
            for c in cols:
                name = flds[tag].get(c)
                if name and not self._need_column_or_warn(lyr, name, self._EP_TITLE):
                    return
        self.cancel_transform()
        self._dol_clear_highlight()
        self._editparcel_lids = (poly_lyr.id(), point_lyr.id())
        canvas = self.iface.mapCanvas()
        self.temp_tool = PolygonPickTool(
            canvas, poly_lyr, self._edit_parcel_picked, self._dol_on_hover,
            msg_title=self._EP_TITLE, choose_prompt="เลือกแปลงที่ต้องการแก้ไขข้อมูล:")
        canvas.setMapTool(self.temp_tool)
        self.temp_tool.push_hint(                                       # ★ 2.3.7 (UX-01) ข้อความของเครื่องมือ
            self._EP_TITLE, f"คลิกแปลงใน '{poly_lyr.name()}' ที่ต้องการแก้ระวาง/มาตราส่วน/เลขที่ดิน • Esc = ยกเลิก",
            level=0, duration=10)

    def _ep_ready_again(self, layer=None):
        """ด่านซ้ำหลังคลิก/หลังรอระบบกรม: ยังเป็นผู้ดูแล + คู่ชั้นเดิมกับตอนกดปุ่ม -> (poly, point) หรือ None"""
        ready = self._admin_ready(self._EP_TITLE)
        if not ready:
            return None
        poly_lyr, point_lyr = ready
        if getattr(self, "_editparcel_lids", None) != (poly_lyr.id(), point_lyr.id()) or \
                (layer is not None and layer.id() != poly_lyr.id()):
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม (หรือแปลงที่คลิกอยู่คนละชั้น) — ยกเลิก\n"
                      "กดปุ่ม 📝 แก้ไขข้อมูลรูปแปลง ใหม่อีกครั้ง")
            return None
        return poly_lyr, point_lyr

    def _edit_parcel_picked(self, feat, layer):
        self.iface.actionSelect().trigger()
        self._dol_clear_highlight()
        ready = self._ep_ready_again(layer)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        try:
            feat = poly_lyr.getFeature(feat.id())
        except Exception:
            pass
        if feat is None or not feat.isValid():
            return
        flds = self._ep_fields(poly_lyr, point_lyr)
        if flds is None:
            return
        cur_type = _txt(feat[flds["poly"]["Type"]]).upper() if flds["poly"]["Type"] else ""
        if cur_type in ("L1-RTK", "L1-TS", "CT-RTK") and not self._l1_unlocked():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"แปลงนี้เป็น {cur_type} (ชั้นอ้างอิงพิกัดหลัก)\nต้องกดปุ่ม 🔓 ปลดล็อก L1 ก่อน จึงจะแก้ข้อมูลได้")
            return
        newv = self._ep_dialog(poly_lyr, feat, flds)
        if newv is None:
            return
        plan = self._ep_plan(poly_lyr, point_lyr, feat, flds, newv)
        if plan is None:
            return
        self._ep_lookup(plan)

    def _ep_dialog(self, poly_lyr, feat, flds):
        """กล่องกรอก UTMMAP1-4 · UTMSCALE · LANDNO (ค่าเดิมเติมไว้) -> dict ค่าที่จัดรูปแล้ว หรือ None"""
        cur = {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS}
        old_utm = _txt(feat[flds["poly"]["UTM"]])
        d = QtWidgets.QDialog(self.iface.mainWindow())
        d.setWindowTitle("📝 " + self._EP_TITLE)
        lay = QtWidgets.QVBoxLayout(d)
        lay.addWidget(QtWidgets.QLabel(f"แปลง gid {feat.id()} · UTM เดิม {old_utm or '(ว่าง)'}"))
        form = QtWidgets.QFormLayout()
        eds = {}
        for k, mx in (("UTMMAP1", 4), ("UTMMAP2", 3), ("UTMMAP3", 4), ("UTMMAP4", 2)):
            ed = QtWidgets.QLineEdit(cur[k])
            ed.setMaxLength(mx)
            eds[k] = ed
            form.addRow(k, ed)
        cb = QtWidgets.QComboBox()
        cb.addItems(list(_EP_SCALES))
        if cur["UTMSCALE"] in _EP_SCALES:
            cb.setCurrentIndex(_EP_SCALES.index(cur["UTMSCALE"]))
        else:
            cb.insertItem(0, cur["UTMSCALE"] or "(ว่าง)")
            cb.setCurrentIndex(0)
        form.addRow("UTMSCALE", cb)
        ed_ln = QtWidgets.QLineEdit(cur["LANDNO"])
        ed_ln.setMaxLength(7)
        form.addRow("LANDNO", ed_ln)
        lay.addLayout(form)
        prev = QtWidgets.QLabel()
        prev.setWordWrap(True)
        lay.addWidget(prev)
        lay.addWidget(QtWidgets.QLabel(
            "กด OK แล้วโปรแกรมจะดึงเนื้อที่ทะเบียนจากระบบกรมใหม่ แล้วขึ้นกล่องยืนยันอีกครั้งก่อนแก้"))
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        lay.addWidget(bb)
        res = {}

        def _upd(*_a):
            v, err = _ep_normalize(eds["UTMMAP1"].text(), eds["UTMMAP2"].text(), eds["UTMMAP3"].text(),
                                   eds["UTMMAP4"].text(), cb.currentText(), ed_ln.text())
            res["v"], res["err"] = v, err
            if err:
                prev.setText("<span style='color:#b71c1c'>" + "<br>".join(err) + "</span>")
            else:
                _same = v["UTM"] == old_utm
                _fix = _same and any(cur[k] != v[k] for k in self._EP_KEYS)        # ★ 2.3.7 b19 (doc-verify E3)
                prev.setText(f"UTM ใหม่: <b>{v['UTM']}</b>" + (
                    "  (UTM ไม่เปลี่ยน — แก้ช่องระวาง/เลขที่ดินให้ตรงกับ UTM + ดึงเนื้อที่ทะเบียนใหม่)" if _fix else
                    "  (ไม่เปลี่ยน — ดึงเนื้อที่ทะเบียนใหม่อย่างเดียว)" if _same else ""))
            bb.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(not err)
        for w in list(eds.values()) + [ed_ln]:
            w.textChanged.connect(_upd)
        cb.currentIndexChanged.connect(_upd)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        _upd()
        try:
            ok = d.exec_() == QtWidgets.QDialog.Accepted
        finally:
            d.deleteLater()
        if not ok or res.get("err"):
            return None
        return res["v"]

    def _ep_plan(self, poly_lyr, point_lyr, feat, flds, newv):
        """เตรียมงาน: หมุดที่จะเปลี่ยนคีย์ · แปลงแฝด · UTM ใหม่ซ้ำแปลงอื่น -> dict หรือ None (ยกเลิก/แจ้งแล้ว)"""
        pu = flds["poly"]["UTM"]
        old_raw = _txt(feat[pu])
        notes = []
        mk_ids = []
        # ★ 2.3.7 b19 (doc-verify E3) — UTM เท่าเดิมแต่ช่องระวาง/เลขที่ดินของแปลงไม่ตรง (ว่าง/ผิดรูป เช่น MAP3 '684' · LANDNO '0435')
        #   ⇒ หมุดของแปลงต้องได้ช่องเดียวกับแปลงด้วย (เดิมหาหมุดเฉพาะเมื่อ UTM เปลี่ยน ⇒ แปลงได้ช่องใหม่ หมุดค้างช่องเก่า)
        _fix_keys = bool(old_raw) and old_raw == newv["UTM"] and \
            any(_txt(feat[flds["poly"][k]]) != newv[k] for k in self._EP_KEYS)
        if not old_raw:
            notes.append("⚠️ แปลงนี้ไม่มี UTM เดิม — หาหมุดของแปลงไม่ได้ จะเปลี่ยนเฉพาะรูปแปลง (ตรวจ/เติมหมุดเอง)")
        elif old_raw != newv["UTM"] or _fix_keys:
            info = self._parcel_markers(poly_lyr, point_lyr, feat)
            if info is None:
                self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                          "อ่านรายชื่อหมุดของแปลงนี้ไม่ได้ (query ล้มเหลว) — ยกเลิก (กันแก้แปลงแล้วหมุดไม่ตาม)")
                return None
            mk_ids = list(info["mk_ids"])
            if info["n_twin"] > 1:
                # แปลงแฝด (UTM เดิมเดียวกัน): เปลี่ยนเฉพาะหมุดบนมุมของแปลงนี้ ที่ไม่ได้อยู่บนมุมของแปลงแฝดด้วย
                mine = [QgsPointXY(v.x(), v.y()) for v in feat.geometry().vertices()]
                twin_v = []
                # ★ 2.3.7 (ให้ตรงกับ 🍩 ข้อ 10 d) — แปลงแฝดชุดเดียวกับที่นับ n_twin (normalise · _utm_twin_fids)
                #   เดิมดึงมุมของแฝดด้วย old_raw ตรงทุกตัวอักษร ⇒ แฝด 'X ' / 'X.0' ถูกนับแต่ไม่ถูกดึงมุมมาเทียบ
                #   ⇒ หมุดบนมุมร่วมกับแฝดถูกเปลี่ยนคีย์ไปด้วย (แฝดเสียหมุด)
                _tw = [t for t in (info.get("twin_fids") or []) if t != feat.id()]
                it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(_tw)) if _tw else None
                try:
                    for tf in (it if it is not None else []):
                        if tf.hasGeometry():
                            twin_v.extend(QgsPointXY(v.x(), v.y()) for v in tf.geometry().vertices())
                finally:
                    if it is not None:
                        it.close()
                keep, shared = [], 0
                for mf in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(mk_ids)):
                    if not mf.hasGeometry():
                        continue
                    p = mf.geometry().asPoint()
                    if not any(p.distance(q) <= 0.01 for q in mine):
                        continue
                    if not _fix_keys and any(p.distance(q) <= 0.01 for q in twin_v):
                        # UTM เปลี่ยน ⇒ หมุดมุมร่วมต้องอยู่กับแฝด · ★ b19 E3 UTM เท่าเดิม ⇒ ยังเป็นหมุดของทั้งคู่ แก้ช่องให้ตรง UTM ได้
                        shared += 1
                        continue
                    keep.append(mf.id())
                notes.append(f"⚠️ มีแปลงแฝด (UTM เดิมเดียวกัน {info['n_twin']} แปลง) — เปลี่ยนเฉพาะหมุดบนมุมของแปลงนี้ "
                             f"{len(keep)} ดวง" + (f" · หมุด {shared} ดวงอยู่บนมุมของแปลงแฝดด้วย ไม่เปลี่ยน "
                                                   "(มุมนั้นของแปลงนี้ต้องเติมหมุดเอง)" if shared else ""))
                mk_ids = keep
            # ★ 2.4.0 (review DU-01) — หมุดล็อก (Type L1) ในชุดที่จะเปลี่ยนคีย์ ⇒ ต้องปลดล็อก L1 ก่อน (แบบแก้ชื่อหมุด)
            if self._parcel_locked_block(info, self._EP_TITLE, "แก้ข้อมูลแปลงนี้ไม่ได้", fids=mk_ids):
                return None
        # UTM ใหม่ซ้ำแปลงอื่น (คำตัดสิน 3 ต.ค.: เตือน + ยืนยันเอง)
        dup = []
        if newv["UTM"] != old_raw:
            # ★ 2.3.7 (ให้ตรงกับ 🍩 ข้อ 10 d) — เทียบแบบ normalise (แปลงที่คีย์มีช่องว่างหัว/ท้าย/'.0' นับว่าซ้ำด้วย)
            dup = [t for t in self._utm_twin_fids(poly_lyr, pu, newv["UTM"], _norm_utm(newv["UTM"]))
                   if t != feat.id()]
        return {"poly_lid": poly_lyr.id(), "point_lid": point_lyr.id(), "fid": feat.id(), "flds": flds,
                "old": {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS}, "old_utm": old_raw,
                "new": newv, "mk_ids": mk_ids, "dup": dup, "notes": notes}

    def _ep_lookup(self, plan):
        """ดึงเนื้อที่ทะเบียนจากระบบกรม (public · thread เบื้องหลัง) แล้วไปขั้นยืนยัน"""
        _w0 = getattr(self, "_ep_worker", None)
        try:
            if _w0 is not None and _w0.isRunning():
                self.iface.messageBar().pushMessage(self._EP_TITLE, "กำลังดึงเนื้อที่อยู่ — รอผลก่อน", level=1, duration=5)
                return
        except Exception:
            pass
        v = plan["new"]
        near_xy = None
        try:
            lyr = QgsProject.instance().mapLayer(plan["poly_lid"])
            c = lyr.getFeature(plan["fid"]).geometry().centroid().asPoint()
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            if lyr.crs() != dst:
                c = QgsCoordinateTransform(lyr.crs(), dst, QgsProject.instance()).transform(c)
            near_xy = (c.x(), c.y())
        except Exception:
            near_xy = None
        _probe = None
        try:
            _probe = _probe_xy_24047(lyr.getFeature(plan["fid"]).geometry(), lyr.crs())    # ★ 2.3.9 ทางสำรอง iLands
        except Exception:
            _probe = None
        try:
            _office = _branch_office_of(QgsProject.instance().mapLayer(plan["poly_lid"]))     # ★ 2.3.10 ล็อกสาขา
        except Exception:
            _office = None
        attrs = {"m1": v["UTMMAP1"], "m2": v["UTMMAP2"], "m3": v["UTMMAP3"], "m4": v["UTMMAP4"],
                 "scale": v["UTMSCALE"], "landno": v["LANDNO"], "near_xy": near_xy, "probe_xy": _probe,
                 "office_seq": _office}
        busy = QtWidgets.QProgressDialog(
            f"กำลังดึงเนื้อที่ทะเบียนจากระบบกรม...\nระวาง {attrs['m1']} {attrs['m2']} {attrs['m3']}-{attrs['m4']} "
            f"ที่ดิน {attrs['landno']}", None, 0, 0, self.iface.mainWindow())
        busy.setWindowTitle(self._EP_TITLE)
        busy.setCancelButton(None)
        busy.setWindowModality(QtCore.Qt.WindowModal)
        busy.show()
        w = ParcelLookupWorker(attrs, zone=47)
        self._ep_worker = w
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)

        def _drop(_w=w):
            try:
                self._net_workers.remove(_w)
            except Exception:
                pass
            try:
                _w.deleteLater()          # finished ยิงหลัง thread จบจริงแล้ว — ลบปลอดภัย (ไม่ลบใน done/fail)
            except Exception:
                pass

        def _end(res, err):
            try:
                busy.close()
                busy.deleteLater()
            except Exception:
                pass
            if not getattr(self, "_alive", True):
                return
            self._ep_after_lookup(plan, res, err)
        w.finished.connect(_drop)
        w.done.connect(lambda res: _end(res, None))
        w.fail.connect(lambda msg: _end(None, msg))
        w.start()

    @staticmethod
    def _ep_area_result(res, err):
        """ผลจากระบบกรม -> {'area': ตร.ม. หรือ None, 'regis': ค่าใหม่หรือ None, 'note': ข้อความ}
        คำตัดสิน 3 ต.ค.: ดึงไม่ได้ = AREA/REGIS คงเดิม + เตือน · ระบบกรมตอบไม่มีทะเบียน = REGIS 'ไม่มีทะเบียน'"""
        keep = "คงเนื้อที่ทะเบียนเดิม — กดปุ่มนี้ซ้ำภายหลังเพื่อดึงใหม่"
        if err:
            return {"area": None, "regis": None, "note": f"⚠️ ดึงเนื้อที่ทะเบียนจากระบบกรมไม่ได้ ({err}) — {keep}"}
        if not isinstance(res, dict) or res.get("not_found"):
            # ★ rc5 — เลขถูกยกเลิก/รอจด/ผลทะเบียน iLands · ยังไม่เข้าสู่ระบบ ⇒ บอกทางค้นทะเบียน (ทางสุดท้าย ต้อง login)
            _lg = (" · เข้าสู่ระบบ DOL (ปุ่ม 📐 หลักฐานการรังวัด) แล้วค้นใหม่ เพื่อค้นต่อในทะเบียน iLands"
                   if isinstance(res, dict) and res.get("lis") == "login" else "")
            # ★ 2.3.11 — ค้นแบบล็อกสาขา: ไม่พบ "ในสาขานี้" · เลขนี้เป็นของสำนักงานอื่น ⇒ บอกตรง ๆ ที่หัวหมายเหตุ (ไม่ซ้ำบรรทัด ℹ️)
            _d = res if isinstance(res, dict) else {}
            _oo = str((_d.get("other_office") or {}).get("office_seq") or "").strip()
            if _oo:
                _หัว = f"⚠️ เลขนี้เป็นแปลงของสำนักงานที่ดินอื่น (รหัส {_oo}) ไม่มีในสำนักงานที่ดินของสาขานี้ — {keep}"
            elif _d.get("arc_miss"):            # ★ 2.4.1 แผนที่มีเลขนี้ แต่ถามทะเบียนที่จุดกลางไม่ได้
                # ★ 2.4.1 rc2 (ผลตรวจ Windows rc1 ข้อสังเกต 6) — กดซ้ำได้ผลเดิมจนกว่าข้อมูลของกรมจะแก้ ⇒ ไม่ชวนกดซ้ำ
                _หัว = ("⚠️ แผนที่กรมมีเลขนี้ แต่ระบบทะเบียนไม่มีข้อมูลที่ตำแหน่งของแปลงนั้น" if _d.get("arc_miss") == "udm_empty"
                        else "⚠️ แผนที่กรมมีเลขนี้ แต่ไม่มีพิกัดจุดกลางของแปลง") + " — คงเนื้อที่ทะเบียนเดิม"
            elif _d.get("branch_office"):
                _หัว = f"⚠️ ระบบกรมไม่พบแปลงของสาขานี้ตามระวาง/เลขที่ดินนี้ — {keep}"
            else:
                _หัว = f"⚠️ ระบบกรมไม่พบแปลงตามระวาง/เลขที่ดินนี้ — {keep}"
            return {"area": None, "regis": None,
                    "note": _หัว
                            + ((_dol_here_hint(res) + _dol_more_hint(res, skip_other=bool(_oo))).replace("\n\n", " · ")
                               if isinstance(res, dict) else "") + _lg}
        # ★ 2.3.7 b19 (doc-verify E10) — ตัดสิน "ยืนยันแปลงไม่ได้" ก่อน "ไม่มีทะเบียน": dol_api หา MAP_PARCEL_SEQ ของระวางนี้
        #   ในคำตอบ UDM ไม่เจอ ⇒ ใช้ค่าเดี่ยวที่อาจเป็นของแปลงข้างเคียง (not_registered ด้วย) · เดิมตั้ง REGIS 'ไม่มีทะเบียน'
        #   ให้แปลงที่คลิกได้จากผลของแปลงอื่น ⇒ ยืนยันไม่ได้ = คง AREA/REGIS (แบบเดียวกับเนื้อที่)
        if not res.get("verified"):
            _a = _txt(res.get("area"))
            return {"area": None, "regis": None,
                    "note": "⚠️ ระบบกรมตอบแปลงที่ยืนยันไม่ได้ว่าตรงกับระวางนี้"
                            + (f" (เนื้อที่ที่ได้ {_a})" if _a else "") + f" — {keep}"}
        if res.get("not_registered") and res.get("via") == "arcgis_temp":
            # ★ rc5 — ชั้นแปลงรอจดของกรม + UDM ยืนยันคีย์ตรง แต่ยังไม่มีทะเบียน ⇒ 'รอจดทะเบียน' (ค่าเดียวกับ _CP_REGIS)
            return {"area": None, "regis": "รอจดทะเบียน",
                    "note": "ℹ️ พบในชั้นแปลงรอจดทะเบียนของกรม (รังวัดแล้ว ยังไม่จดทะเบียน) — ตั้ง REGIS = 'รอจดทะเบียน' · คงเนื้อที่เดิม"}
        if res.get("not_registered"):
            return {"area": None, "regis": "ไม่มีทะเบียน",
                    "note": "⚠️ ระบบกรมแจ้งว่าแปลงนี้ไม่มีทะเบียน — ตั้ง REGIS = 'ไม่มีทะเบียน' · คงเนื้อที่เดิม"}
        if res.get("via") == "lis":
            # ★ rc5 — พบในทะเบียน iLands (หน้า LIS ไม่มีเนื้อที่) ⇒ มีทะเบียนแน่ · เนื้อที่คงเดิม
            return {"area": None, "regis": "มีทะเบียน",
                    "note": f"พบในทะเบียน iLands (โฉนด {_txt(res.get('parcel_no')) or '-'} · หน้าสำรวจ "
                            f"{_txt(res.get('survey_no')) or '-'}) — แปลงนี้ไม่มีรูปบนแผนที่กรม จึงไม่มีเนื้อที่ทะเบียนให้ · {keep}"}
        m2 = _dol_area_m2(res.get("area"))
        if m2 is None:
            return {"area": None, "regis": None,
                    "note": f"⚠️ อ่านเนื้อที่จากระบบกรมไม่ได้ ('{_txt(res.get('area'))}') — {keep}"}
        note = f"เนื้อที่ทะเบียนจากระบบกรม: {_rngw(m2)} ไร่-งาน-วา = {m2:,.2f} ตร.ม."
        if (res.get("match_count") or 1) > 1:
            note += (f" (พบเลขนี้ {res.get('match_count')} แปลงในสาขานี้ — เลือกแปลงที่ใกล้รูปนี้ที่สุดแล้ว)"   # ★ 2.3.11
                     if res.get("branch_office") else " (ระวางคร่อมสาขา — เลือกแปลงที่ใกล้รูปนี้ที่สุดแล้ว)")
        if _dol_via_note(res):                   # ★ rc5 — udm_point · ชั้นรอจด · ชั้นประวัติ
            note += " (%s)" % _dol_via_note(res)
        return {"area": m2, "regis": "มีทะเบียน", "note": note}

    def _ep_after_lookup(self, plan, res, err):
        ready = self._ep_ready_again()
        if not ready:
            return
        poly_lyr, point_lyr = ready
        if (poly_lyr.id(), point_lyr.id()) != (plan["poly_lid"], plan["point_lid"]):
            return
        feat = poly_lyr.getFeature(plan["fid"])
        if feat is None or not feat.isValid():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE, "ไม่พบแปลงนี้แล้ว (ถูกลบระหว่างรอ?) — ยกเลิก")
            return
        flds = plan["flds"]
        # ★ 2.3.7 b19 (doc-verify E1) — เทียบคอลัมน์ UTM ด้วย (เดิมเทียบแค่ 6 ช่องคีย์ ⇒ UTM ถูกแก้ระหว่างรอแล้วยังเขียนทับ ·
        #   หมุดในแผนเป็นชุดของ UTM ตอนคลิก) · ไม่ตรง = ไม่เขียนอะไร
        if {k: _txt(feat[flds["poly"][k]]) for k in self._EP_KEYS} != plan["old"] or \
                _txt(feat[flds["poly"]["UTM"]]) != plan["old_utm"]:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "ข้อมูลระวาง/UTM ของแปลงนี้ถูกแก้ระหว่างรอระบบกรม — ยกเลิก (ยังไม่ได้แก้อะไร) กดปุ่มใหม่อีกครั้ง")
            return
        # ★ 2.3.7 b19 (doc-verify E1) — ด่านล็อก L1 ซ้ำหลังรอ: เดิมตรวจแค่ตอนคลิก ⇒ กด Esc ที่กล่องรอ → 🔒 ล็อก L1 กลับ → Yes
        #   = แก้คีย์แปลง L1 ทั้งที่ล็อกอยู่ (probe a2) · อ่าน Type สดจากแปลง (Type เปลี่ยนเป็น L1 ระหว่างรอก็ถูกกัน)
        #   กล่องยืนยันข้างล่างเป็น application-modal ⇒ หลังด่านนี้สลับล็อก/แก้แปลงไม่ได้จนตอบกล่อง
        _tp = _txt(feat[flds["poly"]["Type"]]).upper() if flds["poly"]["Type"] else ""
        if _tp in ("L1-RTK", "L1-TS", "CT-RTK") and not self._l1_unlocked():
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      f"แปลงนี้เป็น {_tp} (ชั้นอ้างอิงพิกัดหลัก) และตอนนี้ล็อก L1 อยู่ — ยกเลิก (ยังไม่ได้แก้อะไร)\n"
                      "ต้องกดปุ่ม 🔓 ปลดล็อก L1 ก่อน แล้วกดปุ่ม 📝 แก้ไขข้อมูลรูปแปลง ใหม่อีกครั้ง")
            return
        # ★ rc2 (audit A3-02 + ข้อที่ผู้ตรวจทานพบเพิ่ม) — ตรวจแผนซ้ำหลังรอระบบกรม (กล่องรอปิดด้วย Esc ได้ ⇒ ระหว่างรอแก้งานต่อได้)
        #   เดิมใช้ชุดหมุด (mk_ids) · ด่านหมุดล็อก (DU-01 `_parcel_locked_block`) · ผล "UTM ใหม่ซ้ำแปลงอื่น" (dup) ของตอนคลิก
        #   ⇒ 🔒 ล็อก L1 กลับระหว่างรอ = หมุด Type L1 ถูกเปลี่ยนคีย์ทั้งที่ล็อก · Add Node มุมใหม่ระหว่างรอ = หมุดใหม่ค้างคีย์เดิม (หมุดลอย)
        #   · มีคน ➕ สร้างแปลงด้วยคีย์ใหม่ระหว่างรอ = กล่องยืนยันไม่เตือนคีย์ซ้ำ
        #   ⇒ คำนวณแผนใหม่: ด่านล็อกไม่ผ่าน = หยุด (แจ้งแล้ว) · ชุดหมุดเปลี่ยน = ยกเลิก · ใช้ dup/หมายเหตุชุดใหม่
        _p2 = self._ep_plan(poly_lyr, point_lyr, feat, flds, plan["new"])
        if _p2 is None:
            return
        if set(_p2["mk_ids"]) != set(plan["mk_ids"]):
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "หมุดของแปลงนี้เปลี่ยนระหว่างรอระบบกรม — ยกเลิก (ยังไม่ได้แก้อะไร) กดปุ่ม 📝 ใหม่อีกครั้ง")
            return
        plan = dict(plan, dup=_p2["dup"], notes=_p2["notes"])
        ar = self._ep_area_result(res, err)
        o, n = plan["old"], plan["new"]
        line = lambda d: f"ระวาง {d['UTMMAP1']} {d['UTMMAP2']} {d['UTMMAP3']}-{d['UTMMAP4']} · 1:{d['UTMSCALE']} · ที่ดิน {d['LANDNO']}"  # noqa: E731
        txt = [f"แปลง gid {plan['fid']}"]
        _keys_diff = any(o[k] != n[k] for k in self._EP_KEYS)
        if n["UTM"] != plan["old_utm"] or _keys_diff:
            txt.append(f"{line(o)}\n  →  {line(n)}")
            if n["UTM"] != plan["old_utm"]:
                txt.append(f"UTM: {plan['old_utm'] or '(ว่าง)'}  →  {n['UTM']}")
                txt.append(f"หมุดของแปลงนี้ที่จะเปลี่ยนคีย์ตาม: {len(plan['mk_ids'])} ดวง")
            else:
                # ★ 2.3.7 b19 (doc-verify E3) — UTM เท่าเดิม: แก้แค่ช่องระวาง/เลขที่ดินให้ตรงกับ UTM (แปลง + หมุดของแปลง)
                txt.append(f"UTM: {n['UTM']} (ไม่เปลี่ยน — แก้ช่องระวาง/เลขที่ดินให้ตรงกับ UTM)")
                txt.append(f"หมุดของแปลงนี้ที่จะแก้ช่องระวาง/เลขที่ดินตาม: {len(plan['mk_ids'])} ดวง")
        else:
            txt.append("ระวาง/เลขที่ดินไม่เปลี่ยน — ดึงเนื้อที่ทะเบียนใหม่อย่างเดียว")
        txt += plan["notes"]
        if plan["dup"]:
            txt.append(f"⚠️ UTM ใหม่ซ้ำกับแปลงอื่นในชั้นนี้ {len(plan['dup'])} แปลง (gid "
                       + ", ".join(str(x) for x in plan["dup"][:5]) + (" …" if len(plan["dup"]) > 5 else "")
                       + ") — ตั้งใจให้เป็นแปลงแฝดหรือไม่?")
        txt.append(ar["note"])
        af = flds["poly"]["AREA"]
        if ar["area"] is not None and af:
            old_a = _txt(feat[af])
            txt.append(f"AREA: {old_a or '(ว่าง)'}  →  {ar['area']:,.2f} ตร.ม.")
        rf = flds["poly"]["REGIS"]
        if ar["regis"] is not None and rf and _txt(feat[rf]) != ar["regis"]:
            txt.append(f"REGIS: {_txt(feat[rf]) or '(ว่าง)'}  →  {ar['regis']}")
        # ★ 2.3.7 b19 (doc-verify E3) — ช่องระวาง/เลขที่ดินเปลี่ยน (UTM เท่าเดิม) ก็ต้องแก้ แม้ดึงเนื้อที่ไม่ได้ (เดิม "ไม่มีอะไรต้องแก้")
        if not (n["UTM"] != plan["old_utm"] or _keys_diff or ar["area"] is not None or
                (ar["regis"] is not None and rf and _txt(feat[rf]) != ar["regis"])):
            self._ask(QtWidgets.QMessageBox.Information, self._EP_TITLE, "\n".join(txt + ["", "ไม่มีอะไรต้องแก้"]))
            return
        ans = self._ask(QtWidgets.QMessageBox.Question, "ยืนยัน" + self._EP_TITLE, "\n".join(txt + ["", "ยืนยัน?"]),
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return
        if self._ep_apply(poly_lyr, point_lyr, feat, plan, ar):
            self.iface.messageBar().pushMessage(
                self._EP_TITLE, f"แก้แล้ว (ยังไม่บันทึก) — UTM {n['UTM']} · หมุด {len(plan['mk_ids'])} ดวง · กด 💾 บันทึก",
                level=0, duration=8)     # ★ 2.3.7 (review UX-35) ยังไม่ลงฐาน ⇒ ฟ้า (เดิมเขียว "สำเร็จ")

    def _ep_apply(self, poly_lyr, point_lyr, feat, plan, ar):
        """เขียนลง edit buffer ในคำสั่งเดียว (แปลง + หมุด) — ล้มที่ใด = ทิ้งทั้งชุดด้วย destroyEditCommand (DI-33)"""
        flds, n = plan["flds"], plan["new"]
        changes = []                                    # (lyr, fid, field_name, new, old)
        for k in self._EP_KEYS + ("UTM",):
            fn = flds["poly"][k]
            old = feat[fn]
            if _txt(old) != n[k]:
                changes.append((poly_lyr, feat.id(), fn, n[k], old))
        if ar["area"] is not None and flds["poly"]["AREA"]:
            fa = flds["poly"]["AREA"]
            changes.append((poly_lyr, feat.id(), fa, float(round(ar["area"], 2)), feat[fa]))
            if flds["poly"]["DIFF_AREA"] and ar["area"] > 0:
                # trigger คำนวณ DIFF_AREA เฉพาะตอน geom เปลี่ยน ⇒ คำนวณเองด้วยสูตรเดียวกัน (ร้อยละ)
                fd = flds["poly"]["DIFF_AREA"]
                ga = self._geom_area_m2(poly_lyr, feat.geometry())
                changes.append((poly_lyr, feat.id(), fd, round((ga - ar["area"]) / ar["area"] * 100.0, 2), feat[fd]))
        if ar["regis"] is not None and flds["poly"]["REGIS"]:
            fr = flds["poly"]["REGIS"]
            if _txt(feat[fr]) != ar["regis"]:
                changes.append((poly_lyr, feat.id(), fr, ar["regis"], feat[fr]))
        # ★ 2.3.7 b19 (doc-verify E3) — หมุดในแผนได้ช่องเดียวกับแปลงเสมอ (UTM เปลี่ยน หรือแก้ช่องระวางให้ตรง UTM · เดิมเฉพาะ UTM เปลี่ยน)
        #   แผนใส่หมุดเฉพาะสองกรณีนี้ ⇒ ดึงเนื้อที่อย่างเดียวยังไม่แตะหมุด
        if plan["mk_ids"]:
            for mf in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(plan["mk_ids"])):
                for k in self._EP_KEYS + ("UTM",):
                    fn = flds["point"][k]
                    if _txt(mf[fn]) != n[k]:
                        changes.append((point_lyr, mf.id(), fn, n[k], mf[fn]))
        if not changes:
            return False
        lyrs = [poly_lyr] + ([point_lyr] if any(c[0] is point_lyr for c in changes) else [])
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(*lyrs, title=self._EP_TITLE, what="ยังไม่ได้แก้ข้อมูลแปลง"):
            return False
        self._op_begin(lyrs)
        for l in lyrs:
            l.beginEditCommand(self._EP_TITLE)
        ok_all = True
        try:
            for l, fid, fn, new, old in changes:
                ok_all = bool(l.changeAttributeValue(fid, l.fields().indexOf(fn), new, old)) and ok_all
        except Exception:
            ok_all = False
        for l in lyrs:
            try:
                (l.endEditCommand if ok_all else l.destroyEditCommand)()
            except Exception:
                pass
        self._op_commit()
        if not ok_all:
            self._ask(QtWidgets.QMessageBox.Warning, self._EP_TITLE,
                      "เขียนค่าไม่สำเร็จบางส่วน — ทิ้งทั้งชุดแล้ว (ไม่มีอะไรเปลี่ยน)")
            return False
        self._pending_type_log.append({
            'lid': poly_lyr.id(), 'ux': self._ux_mark(poly_lyr),                # ★ 2.3.7 (audit F8) ผูกกับคำสั่งแก้ไข
            # ★ 2.3.7 b17 (audit R2-D2) — คอลัมน์ของแปลงที่เปลี่ยน + ค่าก่อน/หลัง (คีย์ · UTM · AREA · DIFF_AREA · REGIS)
            'fx': ('attr', tuple(c[2] for c in changes if c[0] is poly_lyr),
                   tuple(_txt(c[4]) for c in changes if c[0] is poly_lyr),
                   tuple(_txt(c[3]) for c in changes if c[0] is poly_lyr)),
            'gid': feat.id(), 'utm': n["UTM"], 'old': None,
            'new': _txt(feat[flds["poly"]["Type"]]) if flds["poly"]["Type"] else "",
            'n_mk': len(plan["mk_ids"]), 'action': 'rekeyed',
            'op': (f"UTM {plan['old_utm'] or '(ว่าง)'} -> {n['UTM']}"
                   + (" (แก้ช่องระวาง/เลขที่ดินให้ตรง UTM)" if n["UTM"] == plan["old_utm"]           # ★ b19 E3
                      and any(plan["old"][k] != n[k] for k in self._EP_KEYS) else "")
                   + (f" · AREA {ar['area']:.2f}" if ar["area"] is not None else " · AREA คงเดิม")
                   + (f" · REGIS {ar['regis']}" if ar["regis"] else "")
                   + f" · หมุด {len(plan['mk_ids'])} จุด · MLEP {self.version}")})
        self._locked_cache = None        # แผนที่ล็อก L1 ผูกกับ UTM — คีย์เปลี่ยนต้องอ่านใหม่
        return True
