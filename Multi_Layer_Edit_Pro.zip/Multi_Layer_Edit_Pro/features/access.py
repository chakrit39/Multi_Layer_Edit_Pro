# -*- coding: utf-8 -*-
"""ชั้นสิทธิ์ฐานข้อมูล (staff/mod/admin), โหมดพิเศษ, ปลดล็อก L1 และการตรวจสิทธิ์คอลัมน์/ตารางก่อนเขียน

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import Qgis, QgsExpression, QgsMessageLog, QgsProject
from ..core.util import _log_exc, _PERM_DENIED_RE, _PERM_OBJ_RE, _scrub


class AccessMixin:
    """ชั้นสิทธิ์ฐานข้อมูล (staff/mod/admin), โหมดพิเศษ, ปลดล็อก L1 และการตรวจสิทธิ์คอลัมน์/ตารางก่อนเขียน"""

    def _role_tier(self):
        """ชั้นสิทธิ์ของ role ที่ต่อ DB อยู่ — 0/1/2 หรือ None ถ้าเช็คไม่ได้
        (ยังไม่เปิดโปรเจกต์อำเภอ / ไม่ใช่ชั้น PostGIS / คิวรีล้ม)"""
        # ★ 18 ก.ย. รอบ 2 — ผู้ตรวจ Windows ชี้ว่ามี `return None` เงียบอีก 4 ทาง **นอก** except
        #   ⇒ กรณี "เปิด QGIS ตอนฐานล่มอยู่แล้ว" เลเยอร์โหลดไม่ขึ้นตั้งแต่ต้น จึงไม่มีบรรทัดใน Log เลย
        #     (มีเฉพาะกรณีเน็ตหลุดกลางทางที่ตกลงมาถึง except)
        #   ⇒ ทุกทางที่คืน None ต้องบอกเหตุผลลง Log เหมือนกันหมด · หน้าจอยังเงียบสนิทตามกติกา
        def _no(why):
            try:
                QgsMessageLog.logMessage(
                    "_role_tier: เช็คชั้นสิทธิ์ไม่ได้ — %s" % why, "MLEP", Qgis.Warning)
            except Exception:
                pass
            return None

        if not hasattr(self, "poly_cb"):
            return _no("ยังไม่ได้เปิดหน้าต่างปลั๊กอิน")
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if lyr is None:
            return _no("ยังไม่ได้เลือกชั้นแปลง หรือชั้นโหลดไม่ขึ้น (เช่น เปิด QGIS ตอนฐานล่มอยู่แล้ว)")
        try:
            dp = lyr.dataProvider()
            if dp is None:
                return _no("ชั้นแปลง '%s' ไม่มี dataProvider" % lyr.name())
            if dp.name() != "postgres":
                return _no("ชั้นแปลง '%s' ไม่ใช่ชั้น PostGIS (provider=%s)" % (lyr.name(), dp.name()))
            from qgis.core import QgsDataSourceUri, QgsProviderRegistry
            uri = QgsDataSourceUri(dp.dataSourceUri())
            _dead = self._role_tcp_dead(uri)            # ★ rc1 (F8 · review B1-04) ฐานปิด/เครือข่ายหลุด ⇒ ไม่ค้าง 6 วิ ไม่เด้งกล่องรหัสผ่าน
            if _dead:
                return _no(_dead)
            md = QgsProviderRegistry.instance().providerMetadata("postgres")
            conn = md.createConnection(uri.connectionInfo(True), {})
            # 🔑 ถาม role ผ่าน oid ใน subquery — ถ้าคลัสเตอร์ไหนยังไม่มี mlep_mod
            #    subquery จะไม่คืนแถว (bool_or = NULL) แล้ว CASE ตกไปข้อถัดไปเอง
            #    ถ้าเขียน pg_has_role(current_user,'mlep_mod','MEMBER') ตรง ๆ จะ error ทั้งคิวรี
            # ★ 2.4.0 (review DI-09-followup) — มีเพดานรอ: ต่อฐาน ≤ _ROLE_CONNECT_TIMEOUT_S (_pg_connect_timeout)
            #   + คิวรี ≤ _ROLE_STMT_TIMEOUT_MS (SET LOCAL ในสตริงเดียวกัน = ทรานแซกชันโดยนัยเดียวกัน ⇒ ใช้กับ SELECT นี้แล้วหมดไป)
            #   เกินเพดาน = executeSql โยน error ⇒ ตกไป except ข้างล่าง ⇒ None (ไม่ปลดล็อก) เหมือนฐานล่ม
            # ★ 2.4.0 (review DI-09-followup) — + เพดานฝั่งเรา _ROLE_WAIT_S (_role_sql_bounded) ครอบคอนเนกชันใน pool ที่เงียบไป
            _key = (uri.host() or uri.service(), uri.port(), uri.database(), uri.username())     # ★ 2.4.1 (R3-04)
            with self._busy("role-tier"), self._pg_connect_timeout(self._ROLE_CONNECT_TIMEOUT_S):  # ★ 2.3.7 (review PF-03) ถามฐานผ่านเครือข่าย
                rows = self._role_sql_bounded(
                    conn,
                    "SET LOCAL statement_timeout = %d; " % int(self._ROLE_STMT_TIMEOUT_MS) +
                    "SELECT CASE"
                    " WHEN current_setting('is_superuser')::bool THEN 2"
                    " WHEN (SELECT bool_or(pg_has_role(current_user, oid, 'MEMBER'))"
                    "       FROM pg_roles WHERE rolname = 'mlep_admin') THEN 2"
                    " WHEN (SELECT bool_or(pg_has_role(current_user, oid, 'MEMBER'))"
                    "       FROM pg_roles WHERE rolname = 'mlep_mod') THEN 1"
                    " ELSE 0 END, session_user",                  # ★ 2.4.8 ชื่อบัญชี (ค่าเริ่มต้นช่องมอบหมายของ ➕ · _db_login_name)
                    key=_key)
                v = rows[0][0] if rows and rows[0] else None
                if v is not None:
                    self._role_login = str(rows[0][1]) if len(rows[0]) > 1 and rows[0][1] else ""     # ★ 2.4.8
                    # ★ 2.5.1 ชื่อจากตารางจับคู่ชื่อ — เฉพาะชั้นที่ใช้ ➕ ได้ (mod ขึ้นไป) · คิวรีแยก ล้มก็ไม่กระทบชั้นสิทธิ์
                    self._role_alias = self._role_alias_fetch(conn, _key) if int(v) >= 1 and self._role_login else ""
            if v is None:
                return _no("คิวรีถามชั้นสิทธิ์ไม่คืนค่า")
            return int(v)
        except Exception as e:
            # ★ 2.3.0 — ยัง **เงียบบนหน้าจอ** ตามกติกา "ห้ามเผยว่ามีฟีเจอร์"
            #   แต่เขียนเหตุผลลง Log (View → Panels → Log Messages → แท็บ MLEP)
            #   ⇒ ถ้าเน็ตหลุด/ฐานล่ม ผู้ดูแลตัวจริงกดปุ่มลัดแล้วไม่มีอะไรเกิดขึ้น
            #     จะยังตามเรื่องได้ว่าเพราะอะไร · ผู้ใช้ทั่วไปไม่เห็นอะไรเหมือนเดิม
            #     (ข้อสังเกต ๔.๓ จากผู้ตรวจ Windows 18 ก.ย. 69)
            try:
                QgsMessageLog.logMessage(
                    "_role_tier: ถามชั้นสิทธิ์จากฐานไม่ได้ — %s" % _scrub(e), "MLEP", Qgis.Warning)
            except Exception:
                pass
            return None

    _ALIAS_TBL = "public.mlep_name_alias"

    def _role_alias_fetch(self, conn, key):
        """★ 2.5.1 (เจ้าของงาน 2 พ.ย. 69 "ตารางจับคู่ชื่อในฐาน") ชื่อผู้รับผิดชอบของบัญชีที่ต่ออยู่จากตารางจับคู่ชื่อของผู้ดูแล
        `public.mlep_name_alias (login → assign_name)` — สำหรับคนที่ชื่อในช่อง NAME สะกดต่างจากชื่อบัญชี · ใช้กับช่องมอบหมายของ ➕
        เรียกจาก _role_tier (อยู่ใน _busy/_pg_connect_timeout เดียวกัน · เพดานเดียวกับคิวรีชั้นสิทธิ์) ·
        ถามว่ามีตารางก่อน (to_regclass) ⇒ ฐานที่ยังไม่สร้างตารางไม่เกิด error · ไม่มีตาราง/ไม่มีแถว/ถามไม่ได้ = '' (ถามไม่ได้บันทึก Log)"""
        st = "SET LOCAL statement_timeout = %d; " % int(self._ROLE_STMT_TIMEOUT_MS)
        try:
            rows = self._role_sql_bounded(conn, st + "SELECT to_regclass('%s') IS NOT NULL" % self._ALIAS_TBL, key=key)
            if not (rows and rows[0] and str(rows[0][0]).strip().lower() in ("true", "t", "1")):
                return ""
            rows = self._role_sql_bounded(
                conn, st + "SELECT btrim(assign_name) FROM %s WHERE lower(btrim(login)) = lower(session_user)"
                           " AND btrim(coalesce(assign_name, '')) <> '' LIMIT 1" % self._ALIAS_TBL, key=key)
            return str(rows[0][0]).strip() if rows and rows[0] and rows[0][0] else ""
        except Exception as e:
            try:
                QgsMessageLog.logMessage("_role_alias_fetch: อ่านตารางจับคู่ชื่อไม่ได้ (ใช้ชื่อจากชั้น/ชื่อบัญชีแทน) — %s"
                                         % _scrub(e), "MLEP", Qgis.Warning)
            except Exception:
                pass
            return ""

    def _db_alias_name(self, lyr):
        """★ 2.5.1 ชื่อจากตารางจับคู่ชื่อของบัญชีที่ใช้ชั้นนี้ — ได้มาพร้อมคิวรีชั้นสิทธิ์ (_role_tier) ·
        ใช้เฉพาะเมื่อบัญชีของชั้นตรงกับบัญชีที่ถามชั้นสิทธิ์ (ไม่ตรง/ไม่รู้ = '')"""
        try:
            lg = str(self._db_login_name(lyr) or "").strip().lower()
            if lg and lg == str(getattr(self, "_role_login", "") or "").strip().lower():
                return str(getattr(self, "_role_alias", "") or "").strip()
        except Exception:
            pass
        return ""

    def _db_login_name(self, lyr):
        """★ 2.4.8 ชื่อบัญชีฐานข้อมูลของคนที่ใช้ชั้นนี้ (ค่าเริ่มต้นช่องมอบหมายของ ➕ — _nm_for_login) — ชื่อผู้ใช้ในการเชื่อมต่อของชั้น ·
        ไม่มี (ต่อด้วย authcfg) ⇒ session_user ที่ได้มาพร้อมคิวรีชั้นสิทธิ์ (_role_tier · ต้องผ่านก่อนเข้าโหมดที่ใช้ ➕ ได้) · ไม่ถามฐานเพิ่ม ·
        ไม่ใช่ชั้น PostGIS/ไม่รู้ = ''"""
        try:
            dp = lyr.dataProvider() if lyr is not None else None
            if dp is None or dp.name() != "postgres":
                return ""
            from qgis.core import QgsDataSourceUri
            return QgsDataSourceUri(dp.dataSourceUri()).username() or str(getattr(self, "_role_login", "") or "")
        except Exception:
            return ""

    def _role_sql_bounded(self, conn, sql, key=None):
        """★ 2.4.0 (review DI-09-followup) — conn.executeSql(sql) ในเธรดแยก เธรดหลักรอไม่เกิน _ROLE_WAIT_S แล้วคืนแถว
        เกินเพดาน = โยน TimeoutError (ผู้เรียก ⇒ None = ไม่ปลดล็อก) ปล่อยเธรดนั้นจบเอง (executeSql ปล่อย GIL ระหว่างรอฐาน)
          · error ของคิวรีโยนต่อให้ผู้เรียกเหมือนเรียกตรง
          · คิวรีครั้งก่อนยังค้างอยู่ = ไม่ถามซ้อน (โยน TimeoutError ทันที) ⇒ เธรดค้างไม่สะสมจนกิน pool ของ QGIS
          · key: ★ 2.4.1 (review R3-04) คีย์ของคอนเนกชัน (host/service, port, ฐาน, ผู้ใช้ — ไม่มีรหัสผ่าน) · นับเธรดค้าง/เพดานแยกต่อคีย์
            ⇒ เธรดที่ค้างของฐานหนึ่งไม่ทำให้ชั้นของฐานอื่น (ที่ตอบปกติ) โดน "ไม่ถามซ้อน" แล้วถูกพักถาม 60 วิ
            (pool ของ QGIS แยกตามคอนเนกชันอยู่แล้ว) · ไม่ส่ง = กลุ่มเดียวกันหมด (แบบเดิม)
          · ไม่ใช้ QgsFeedback.cancel(): QGIS ส่ง PQCancel บนเธรดที่สั่งยกเลิก (= เธรดหลัก) และรอฐานตอบ ⇒ ฐานค้างก็ค้างอีก
            ส่วนฐานที่ยังตอบได้ statement_timeout ตัดคิวรีให้แล้ว
          · ไม่ processEvents ระหว่างรอ (กติกา _Busy · กันสัญญาณเปลี่ยนชั้นแปลงแทรกระหว่างถามสิทธิ์กับจำคอนเนกชันใน toggle_unlock_l1)"""
        import threading
        import time as _time
        # ★ rc1 2.4.0 (F8 · review B2-02) — เธรดที่ยังค้าง: เพิ่งค้าง (< _ROLE_STUCK_RETRY_S) = ไม่ถามซ้อนเหมือนเดิม ·
        #   ค้างนานแล้ว (ฐานกลับมาแต่ socket เดิมยังไม่ตาย) = ยอมถามใหม่ จนเธรดค้างครบ _ROLE_MAX_STUCK ⇒ บอกให้ปิดเปิด QGIS (_role_stuck)
        self._role_stuck = False
        _alive = [t for t in (getattr(self, "_role_ths", None) or []) if t.is_alive()]
        prev = getattr(self, "_role_th", None)
        if prev is not None and prev.is_alive() and prev not in _alive:
            _alive.append(prev)
        self._role_ths = _alive
        _same = [t for t in _alive if getattr(t, "_mlep_key", None) == key]     # ★ 2.4.1 (R3-04) เฉพาะคอนเนกชันเดียวกัน
        if _same:
            _now = _time.monotonic()
            if any(_now - getattr(t, "_mlep_t0", _now) < float(self._ROLE_STUCK_RETRY_S) for t in _same):
                raise TimeoutError("คิวรีถามชั้นสิทธิ์ครั้งก่อนยังรอฐานอยู่ (ฐานไม่ตอบ) — ไม่ถามซ้อน")
            if len(_same) >= int(self._ROLE_MAX_STUCK):
                self._role_stuck = True
                raise TimeoutError("คิวรีถามชั้นสิทธิ์ค้างอยู่ %d ครั้ง (คอนเนกชันเดิมเงียบไปกลางทาง) — ปิดแล้วเปิด QGIS ใหม่"
                                   % len(_same))
        box = {}

        def _run():
            try:
                box["rows"] = conn.executeSql(sql)
            except BaseException as e:      # noqa — ส่งทุกอย่างกลับไปโยนบนเธรดหลัก
                box["err"] = e

        th = threading.Thread(target=_run, name="MLEP-role-tier", daemon=True)
        th._mlep_t0 = _time.monotonic()
        th._mlep_key = key
        self._role_th = th
        self._role_ths.append(th)
        th.start()
        th.join(float(self._ROLE_WAIT_S))
        if th.is_alive():
            raise TimeoutError("ฐานไม่ตอบภายใน %g วินาที (คอนเนกชันเงียบ/ฐานค้าง)" % float(self._ROLE_WAIT_S))
        if "err" in box:
            raise box["err"]
        return box.get("rows")

    def _role_tcp_dead(self, uri):
        """★ rc1 2.4.0 (F8 · review B1-04) — ลองต่อ TCP ไปเครื่อง/พอร์ตของฐานจากเธรดหลัก (≤ _ROLE_PROBE_S)
        ต่อไม่ได้ ⇒ คืนเหตุผล (ผู้เรียกตอบ None = ไม่ปลดล็อก/ไม่เข้าโหมด ทันที) · ต่อได้/ตรวจแบบนี้ไม่ได้ ⇒ None (ถามฐานตามเดิม)
        ข้าม (None): ไม่มีชื่อเครื่อง (socket ในเครื่อง) · หลายเครื่องในชื่อเดียว (libpq เลือกเอง)
        ★ rc10 (ผลตรวจ Windows rc9 ⚪5 · agent B) URI แบบ service= ⇒ อ่านเครื่อง/พอร์ตจาก pg_service.conf แบบที่ libpq หา (_pg_service_hostport)
        — rc9 ข้ามด่านนี้ทั้งหมด ⇒ ฐานปิดแล้วต่อค้างจนหมดเพดาน · หา service ไม่เจอ/ไม่มีชื่อเครื่อง ⇒ ข้ามแบบเดิม"""
        try:
            host = (uri.host() or "").strip()
            port = (uri.port() or "").strip()
            svc = uri.service() or ""                   # ★ rc11 ชื่อดิบ (libpq หา '[ชื่อ]' ตรงตัว — rc10 ตัดช่องว่างท้าย · agent A ⚪4 (20))
            if svc.strip() and (not host or not port):
                hp = self._pg_service_hostport(svc)
                if hp is None:
                    return None
                host, port = host or hp[0], port or hp[1]
            import os as _os
            port = int(port or _os.environ.get("PGPORT") or 5432)
            if not host or host.startswith("/") or "," in host:
                return None
        except Exception:
            return None
        import socket as _socket
        try:
            _s = _socket.create_connection((host, port), timeout=float(self._ROLE_PROBE_S))
            try:
                _s.close()
            except Exception:
                pass
            return None
        except OSError as e:
            return "ต่อเครื่องฐานข้อมูล %s:%d ไม่ได้ (ฐานปิด/เครือข่ายหลุด) — %s" % (host, port, _scrub(e))

    @staticmethod
    def _pg_service_hostport(name):
        """★ rc10 (ผลตรวจ Windows rc9 ⚪5) เครื่อง/พอร์ตของ service ใน pg_service.conf ตามลำดับที่ libpq หา -> (host, port) · ไม่พบ = None
        ไฟล์ของผู้ใช้: PGSERVICEFILE (ตั้งไว้ = ใช้ไฟล์นี้แทน) · ไม่ตั้ง ⇒ Windows %APPDATA%\\postgresql\\.pg_service.conf / อื่น ~/.pg_service.conf ·
        แล้วไฟล์ของระบบ PGSYSCONFDIR/pg_service.conf · hostaddr มาก่อน host (ที่อยู่ที่ libpq ต่อจริง) · อ่านไม่ได้ = ข้ามไฟล์นั้น
        ★ rc11 (ผลตรวจ Windows rc10 ⚪4 · agent A ⚪4) อ่านแบบ libpq (_pg_service_parse) แทน configparser — rc10: บรรทัดย่อหน้ากลายเป็นค่าต่อของ
        บรรทัดก่อน (host = '10.5.5.5\\nport=9' ⇒ ด่าน TCP บอกฐานปิดผิด ⇒ ปลดล็อก/เข้าโหมดไม่ได้) · คีย์ซ้ำ/หมวดซ้ำใช้ตัวหลัง (libpq ตัวแรก) ·
        ตามลำดับ libpq: พบหมวดในไฟล์ของผู้ใช้ = ใช้ไฟล์นั้น (ไม่ดูไฟล์ระบบ) · ไฟล์ที่ libpq จะปฏิเสธ (บรรทัดไม่มี '=' · service ซ้อน · ยาวเกิน) /
        PGSERVICEFILE ชี้ไฟล์ที่ไม่มี (libpq ต่อไม่ได้) / ไม่ตั้ง PGSYSCONFDIR (ไม่รู้โฟลเดอร์ที่ libpq คอมไพล์มา) ⇒ None (ข้ามด่านแบบ rc9 · ไม่เดา)"""
        import os as _os
        if not (name or "").strip():
            return None
        files = []
        if _os.environ.get("PGSERVICEFILE"):
            files.append((_os.environ["PGSERVICEFILE"], True))
        elif _os.name == "nt":
            if _os.environ.get("APPDATA"):
                files.append((_os.path.join(_os.environ["APPDATA"], "postgresql", ".pg_service.conf"), False))
        else:
            files.append((_os.path.expanduser("~/.pg_service.conf"), False))
        if _os.environ.get("PGSYSCONFDIR"):
            files.append((_os.path.join(_os.environ["PGSYSCONFDIR"], "pg_service.conf"), False))
        for fn, must in files:
            try:
                if not _os.path.isfile(fn):
                    if must:
                        return None             # libpq: PGSERVICEFILE ไม่มีไฟล์ ⇒ ต่อไม่ได้ (ไม่ไปไฟล์ระบบ)
                    continue
                with open(fn, "rb") as fh:
                    got = AccessMixin._pg_service_parse(fh.read(), name)
            except Exception:
                return None
            if got is None:
                return None                     # libpq ปฏิเสธไฟล์นี้ ⇒ ไม่เดา
            if got is False:
                continue                        # ไม่มีหมวดนี้ ⇒ ไฟล์ถัดไป (แบบ libpq)
            return ((got.get("hostaddr") or got.get("host") or "").strip(), (got.get("port") or "").strip())
        return None

    @staticmethod
    def _pg_login_failed(e):
        """★ rc11 (ผลตรวจ Windows rc10 ⚪5 · agent A ⚪9) error ตอนถามฐานที่ด่าน TCP ผ่านแล้ว = เข้าฐานไม่ได้ (รหัสผ่านผิด/ถูกเปลี่ยน · ยกเลิกกล่อง
        Enter Credentials ของ QGIS — ข้อความเป็น 'Connection failed: …' ไม่บอกเหตุ) ไหม · ผู้เรียก (_l1_kinds_for · _l1_capture_pg) จำผลล้มแบบนี้จน
        ปิด QGIS (ไม่ต่อซ้ำ = ไม่เด้งกล่องรหัสผ่านทุก 5 นาที) · ฐานปิด (ด่าน TCP) / คิวรีล้ม ('Error executing SQL') = จำ 5 นาทีตามเดิม"""
        import re as _re
        try:
            s = str(e) or ""
        except Exception:
            return False
        return bool(_re.search(r"connection failed|authenticat|password|fe_sendauth|credential", s, _re.I))

    @staticmethod
    def _pg_service_parse(raw, name):
        """★ rc11 อ่านไฟล์ service แบบ parseServiceFile ของ libpq -> {คีย์: ค่า} ของหมวด name · False = ไม่มีหมวดนี้ · None = ไฟล์ที่ libpq ปฏิเสธ
        ทีละบรรทัด (ไบต์ · ยาว ≥ 1023 = ปฏิเสธ) · ตัดช่องว่างแบบ C (isspace: ช่องว่าง \\t \\n \\v \\f \\r) หัว/ท้ายบรรทัด · ว่าง/ขึ้นต้นด้วย # = ข้าม ·
        '[ชื่อ' + ']' ตรงตัว (ตัวพิมพ์ตรง · หลัง ']' มีอะไรก็ได้) = หมวดที่หา · เจอหมวดถัดไปหลังพบแล้ว = จบ (หมวดซ้ำทีหลังไม่อ่าน) · ในหมวด: แยกที่ '='
        ตัวแรก (คีย์/ค่าไม่ตัดช่องว่าง — 'host = x' libpq ถือเป็นคีย์ผิด) · ไม่มี '=' / คีย์ service = ปฏิเสธ · คีย์ซ้ำ: ค่าแรกชนะ"""
        if isinstance(raw, str):
            raw = raw.encode("utf-8")
        ws = b" \t\n\v\f\r"
        nm = name.encode("utf-8")
        found = False
        opts = {}
        for line in raw.split(b"\n"):           # fgets แยกที่ \n เท่านั้น (\r ท้ายบรรทัดถูกตัดเป็นช่องว่าง)
            if len(line) + 1 >= 1023:           # libpq: บรรทัด (รวม \n) ≥ 1023 ไบต์ = "line too long" ⇒ ต่อไม่ได้
                return None
            line = line.strip(ws)
            if not line or line.startswith(b"#"):
                continue
            if line.startswith(b"["):
                if found:
                    break
                found = line[1:1 + len(nm)] == nm and line[1 + len(nm):2 + len(nm)] == b"]"
                continue
            if not found:
                continue
            if b"=" not in line:
                return None
            k, v = line.split(b"=", 1)
            if k == b"service":
                return None
            opts.setdefault(k.decode("utf-8", "replace"), v.decode("utf-8", "replace"))
        return opts if found else False

    def _pg_timeout_recover(self):
        """★ rc1 2.4.0 (F4 · review B2-01) — ตอนเริ่มปลั๊กอิน: เจอธงของ _pg_connect_timeout ค้าง (QGIS ดับระหว่างถามสิทธิ์)
        ⇒ คืน providers/PostgreSQL/default_timeout เป็นค่าเดิม (ไม่มีเดิม = ลบคีย์) **เฉพาะเมื่อ** ค่าในไฟล์ผู้ใช้ยังเป็นค่าที่หดไว้
        (ผู้ใช้/โปรแกรมอื่นตั้งค่าใหม่ไปแล้ว = ไม่แตะ) แล้วล้างธง · อ่าน/เขียนไม่ได้ = ลง Log แล้วไปต่อ (ไม่ขวางการเปิดปลั๊กอิน)"""
        try:
            import json as _json
            from qgis.core import QgsSettings
            st = QgsSettings()
            raw = st.value(self._PG_TO_FLAG, "")
            if not raw:
                return False
            key = "PostgreSQL/default_timeout"
            try:
                d = _json.loads(str(raw))
            except ValueError:
                d = {}
            fn = st.fileName()
            usr = QtCore.QSettings(fn, QtCore.QSettings.IniFormat if fn.lower().endswith(".ini")
                                   else QtCore.QSettings.NativeFormat)
            ukey = "providers/" + key
            cur = usr.value(ukey) if usr.contains(ukey) else None
            fixed = False
            if isinstance(d, dict) and cur is not None and str(cur) == str(d.get("set")):
                if d.get("had") and d.get("old") is not None:
                    st.setValue(key, d.get("old"), QgsSettings.Providers)
                else:
                    st.remove(key, QgsSettings.Providers)
                fixed = True
            st.remove(self._PG_TO_FLAG)
            st.sync()
            if fixed:
                QgsMessageLog.logMessage(
                    "คืนค่าตั้ง %s ที่ค้างจากครั้งก่อน (QGIS ปิดไม่ปกติระหว่างถามชั้นสิทธิ์)" % key, "MLEP", Qgis.Info)
            return fixed
        except Exception:
            _log_exc("_pg_timeout_recover: ตรวจ/คืนค่าตั้ง default_timeout ที่ค้างไม่ได้")
            return False

    def _pg_connect_timeout(self, secs):
        """★ 2.4.0 (review DI-09-followup) — ช่วงที่คอนเนกชัน PostgreSQL ใหม่ของ QGIS ใช้ connect_timeout = secs วินาที
        QGIS 3.40 ตัด connect_timeout ที่ใส่ใน URI ทิ้ง (QgsDataSourceUri ไม่รู้จักคีย์นี้) แล้วเติม connect_timeout จากค่าตั้ง
        providers/PostgreSQL/default_timeout (ไม่ตั้ง = 30 วิ) ทุกครั้งที่เปิดคอนเนกชันใหม่ ⇒ ทางเดียวที่ทำได้คือหดค่าตั้งนี้ชั่วคราว
          · หดอย่างเดียว (ผู้ใช้ตั้งไว้สั้นกว่าอยู่แล้ว = ไม่แตะ) · คืนค่าเดิมเสมอเมื่อออกจากช่วง (ไฟล์ค่าตั้งของผู้ใช้ไม่มีคีย์นี้ = ลบคีย์ทิ้งเหมือนเดิม ไม่ตรึงค่ากลางลงโปรไฟล์)
          · มีผลเฉพาะคอนเนกชันที่เปิดใหม่ในช่วงนี้ (คอนเนกชันใน pool ที่ยังดีอยู่ไม่ต้องต่อใหม่)
          · อ่าน/เขียนค่าตั้งไม่ได้ = ข้ามไป (ถามฐานต่อด้วยเพดานของ QGIS เดิม)"""
        import contextlib

        @contextlib.contextmanager
        def _cm():
            key = "PostgreSQL/default_timeout"
            st = had = old = None
            try:
                from qgis.core import QgsSettings
                st = QgsSettings()
                # ★ 2.4.0 (review DI-09-followup) — มี/ไม่มีค่าเดิม ดูจากไฟล์ของผู้ใช้เท่านั้น: QgsSettings.contains/value รวมค่าตั้งกลาง
                #   (qgis_global_settings.ini ของ QGIS มี PostgreSQL\default_timeout=30) ⇒ เดิมคืนค่าโดยเขียน 30 ลงโปรไฟล์ผู้ใช้ถาวร
                #   ไม่มีในไฟล์ผู้ใช้ = ลบคีย์ตอนออก (ค่ากลางกลับมามีผล) · ค่าที่มีผลอยู่ (ผู้ใช้หรือค่ากลาง) ใช้ตัดสินว่าต้องหดไหม
                ukey = "providers/" + key
                fn = st.fileName()
                usr = QtCore.QSettings(fn, QtCore.QSettings.IniFormat if fn.lower().endswith(".ini")
                                       else QtCore.QSettings.NativeFormat)
                had = usr.contains(ukey)
                old = usr.value(ukey) if had else None
                eff = st.value(key, None, section=QgsSettings.Providers)
                try:
                    cur = int(eff) if eff not in (None, "") else 30
                except (TypeError, ValueError):
                    cur = 30
                if 0 < cur <= int(secs):
                    st = None                       # สั้นพออยู่แล้ว ⇒ ไม่แตะ
                else:
                    # ★ rc1 (F4 · review B2-01) — ค่าที่หดลงไฟล์ INI จริงระหว่างรอ ⇒ QGIS ดับ/ถูก kill ในช่วงนี้ = default_timeout=5
                    #   ค้างในโปรไฟล์ถาวร (ทุกคอนเนกชัน PG ของเครื่องนั้นรอต่อฐานแค่ 5 วิ) ⇒ จดธง "ค่าเดิม" ลงไฟล์ก่อนหด (sync)
                    #   แล้วล้างธงหลังคืนค่า · เปิด QGIS ครั้งถัดไปเจอธงค้าง ⇒ _pg_timeout_recover คืนค่าให้
                    import json as _json
                    st.setValue(self._PG_TO_FLAG, _json.dumps(
                        {"had": bool(had), "old": None if old is None else str(old), "set": int(secs)}))
                    st.sync()
                    st.setValue(key, int(secs), QgsSettings.Providers)
            except Exception as e:
                st = None
                try:
                    QgsMessageLog.logMessage(
                        "_pg_connect_timeout: ตั้งเพดานต่อฐานไม่ได้ — %s" % _scrub(e), "MLEP", Qgis.Warning)
                except Exception:
                    pass
            try:
                yield
            finally:
                if st is not None:
                    try:
                        from qgis.core import QgsSettings
                        if had:
                            st.setValue(key, old, QgsSettings.Providers)
                        else:
                            st.remove(key, QgsSettings.Providers)
                        st.remove(self._PG_TO_FLAG)            # ★ rc1 (F4) คืนแล้ว ⇒ ล้างธง
                        st.sync()
                    except Exception as e:
                        try:
                            QgsMessageLog.logMessage(
                                "_pg_connect_timeout: คืนค่าตั้ง %s ไม่ได้ — %s" % (key, _scrub(e)), "MLEP", Qgis.Warning)
                        except Exception:
                            pass
        return _cm()

    def _admin_role_ok(self):
        """True เมื่อชั้นถึงผู้ดูแล, None ถ้าเช็คไม่ได้
        ★ 2.4.0 (review DI-09) — toggle_unlock_l1 ถามซ้ำทุกครั้งที่จะปลดล็อก (ชั้นที่จำไว้ตอนเข้าโหมดอาจมาจากอีกคอนเนกชัน)
          · ถามฐาน 1 คิวรีบนเธรดหลัก (เหมือนตอนเข้าโหมด)
          ★ 2.4.0 (review DI-09-followup) — มีเพดานรอ (ต่อฐาน _ROLE_CONNECT_TIMEOUT_S · คิวรี _ROLE_STMT_TIMEOUT_MS
            · รวมทั้งหมดฝั่งเรา _ROLE_WAIT_S) ⇒ เกิน = None"""
        t = self._role_tier()
        return None if t is None else (t >= self.TIER_ADMIN)

    def _col_ok(self, layer, column):
        """★ 2.3.7 (review DI-13) — เขียนคอลัมน์นี้ได้ "แน่นอน" ไหม (ใช้ก่อนเขียนชื่อหมุด BND_NAME ลง buffer)
        (★ b12 — ปลั๊กอินไม่เขียน ALT_NAME แล้ว · เจ้าของงานตัดสิน 3 ต.ค. 69)
        ไม่ใช่ PostGIS ⇒ True (ไม่มีสิทธิ์รายคอลัมน์ให้กัน เหมือนเดิม) · PostGIS ⇒ ต้องยืนยันได้ว่า True
        ยังไม่รู้ (None) ⇒ False (เตือนชื่อหาย แทนเขียนแล้วไปล้มตอน 💾 ซึ่งชั้นแปลงลงฐานไปก่อน = แปลงกับหมุดไม่ตรงกันถาวร)
        ลำดับ: รู้ผลแล้ว (True/False จากแคช) ⇒ ใช้ผลนั้นก่อนเสมอ · ไม่รู้ + ไม่ใช่ PostGIS ⇒ True
        ★ rc2 (audit A5-01) — เลิก "ถามใหม่ 1 ครั้งแบบไม่ใช้แคช" เมื่อได้ None: _can_update_column คืน None ได้ทางเดียวคือเพิ่งถาม
          ฐานไปแล้ว (ไม่จำ None) ⇒ รอบสองซ้ำเสมอ = รอฐานเงียบ 2 เท่าบนเธรดหลัก"""
        v = self._can_update_column(layer, column)
        if v is None:
            try:
                dp = layer.dataProvider()
                if dp is None or dp.name() != "postgres":
                    return True
            except Exception:
                return False
        return v is True

    def _commit_preflight(self, layers):
        """★ 2.3.7 (review DI-13) — คอลัมน์ที่แก้ค้างใน buffer แต่ "ยืนยันได้ว่าไม่มีสิทธิ์ UPDATE" -> ['ชั้น X: คอลัมน์ Y', ...]
        ตรวจก่อน commit ชั้นแรก — QGIS commit ทีละชั้น ⇒ ชั้นแปลงลงแล้วชั้นหมุดล้มเพราะสิทธิ์ = คู่แปลง-หมุดพังถาวร
        (อ่านสิทธิ์ไม่ได้ = ไม่กัน)
        ★ rc2 (audit A5-01) — ถามฐานคิวรีเดียวต่อชั้น (_perm_prefetch · มีเพดานเวลา) แทนคอลัมน์ละ 2 ครั้งบนเธรดหลักไม่มีเพดาน
          · ไม่ถามซ้ำเมื่อได้ None · ฐานเงียบ = พักถาม _PERM_DOWN_S วิ (💾 ครั้งถัดไปไม่ค้างซ้ำ)
        ★ rc2 (audit A5-02) — แถวที่เพิ่ม: นอกจาก INSERT ของตาราง (has_any_column_privilege) ตรวจ INSERT ของทุกคอลัมน์ที่แถวใหม่มีค่า
          (GRANT INSERT รายคอลัมน์ที่ไม่รวมคอลัมน์นั้น ⇒ ชั้นแปลงลงฐานแล้วชั้นหมุดล้ม = ครึ่งคู่)"""
        out = []
        for lyr in layers:
            try:
                if lyr is None or not lyr.isEditable():
                    continue
                eb = lyr.editBuffer()
                if eb is None:
                    continue
            except Exception:
                continue
            upd, ins, gcol = [], [], None
            try:
                idxs = set()
                for _fid, amap in eb.changedAttributeValues().items():
                    idxs.update(amap.keys())
                fl = lyr.fields()
                upd = [fl.at(i).name() for i in sorted(idxs) if 0 <= i < fl.count()]
                _ng = sum(1 for _fid in eb.changedGeometries().keys() if _fid >= 0)
                _added = eb.addedFeatures()
                if _ng or _added:
                    try:
                        from qgis.core import QgsDataSourceUri
                        gcol = QgsDataSourceUri(lyr.dataProvider().dataSourceUri()).geometryColumn() or "geom"
                    except Exception:
                        gcol = "geom"
                if _added:
                    _ii = set()
                    for _f in _added.values():
                        for i, _v in enumerate(_f.attributes()):
                            if i not in _ii and i < fl.count() and _v is not None and not (
                                    hasattr(_v, "isNull") and _v.isNull()) and fl.fieldOrigin(i) == fl.OriginProvider:
                                _ii.add(i)
                    ins = [fl.at(i).name() for i in sorted(_ii)]
                    if gcol and any(_f.hasGeometry() for _f in _added.values()):
                        ins.append(gcol)
                want = ([("upd", c) for c in upd] + ([("upd", gcol)] if _ng else [])
                        + ([("tbl", "DELETE")] if eb.deletedFeatureIds() else [])
                        + ([("tbl", "INSERT")] if _added else []) + [("ins", c) for c in ins])
                self._perm_prefetch(lyr, want)
            except Exception:
                _log_exc("ตรวจสิทธิ์ก่อนบันทึก: รวบรวมรายการไม่ได้")
            try:
                for name in upd:
                    if self._can_update_column(lyr, name) is False:
                        out.append(f"ชั้น '{lyr.name()}': คอลัมน์ {name}")
            except Exception:
                pass
            # ★ 2.4.0 (review DI-13) — รูปที่แก้ค้าง (ย้าย/แก้รูปแถวเดิม) ใช้สิทธิ์ UPDATE ของคอลัมน์ geometry
            #   เดิมไม่ตรวจ ⇒ บัญชีที่ไม่มี UPDATE(geom) ของชั้นหมุด: Move ลงชั้นแปลงไปก่อนแล้วชั้นหมุดล้ม = บันทึกครึ่งเดียว
            #   และกด 💾 ซ้ำก็ไปล้มที่ฐานอีก · แถวใหม่ (fid < 0) ใช้สิทธิ์ INSERT (ตรวจข้างล่าง)
            try:
                _ng = sum(1 for _fid in eb.changedGeometries().keys() if _fid >= 0)
                if _ng and self._can_update_column(lyr, gcol or "geom") is False:
                    out.append(f"ชั้น '{lyr.name()}': คอลัมน์ {gcol or 'geom'} (ย้าย/แก้รูป {_ng:,} รายการ)")
            except Exception:
                pass
            # ★ 2.3.7 (audit F7) — แถวที่ลบ/เพิ่มค้างใน buffer ใช้สิทธิ์ DELETE/INSERT ของตาราง (ไม่ใช่ UPDATE รายคอลัมน์)
            #   เดิมไม่ตรวจ ⇒ บัญชีที่ไม่มีสิทธิ์ลบ/เพิ่มบนชั้นหนึ่ง: ชั้นแรกลงฐานแล้วชั้นที่สองล้ม = บันทึกครึ่งเดียว (คาดเดาได้ล่วงหน้า)
            #   ⇒ ถามฐาน has_table_privilege เฉพาะเมื่อ buffer มีลบ/เพิ่ม · ไม่ใช่ PostGIS / ถามไม่ได้ = ไม่กัน (แบบเดียวกับคอลัมน์)
            try:
                _tbl_no = False
                for _priv, _n, _what in (("DELETE", len(eb.deletedFeatureIds()), "ลบ"),
                                         ("INSERT", len(eb.addedFeatures()), "เพิ่ม")):
                    if not _n:
                        continue
                    if self._can_table_priv(lyr, _priv) is False:
                        out.append(f"ชั้น '{lyr.name()}': {_what} {_n:,} รายการ (ไม่มีสิทธิ์ {_priv})")
                        _tbl_no = _tbl_no or _priv == "INSERT"
                # ★ rc2 (audit A5-02) — INSERT รายคอลัมน์ของค่าที่แถวใหม่เขียน (ไม่มี INSERT ทั้งตารางอยู่แล้ว = บอกบรรทัดเดียวพอ)
                if ins and not _tbl_no:
                    _nn = len(eb.addedFeatures())
                    for name in ins:
                        if self._can_insert_column(lyr, name) is False:
                            out.append(f"ชั้น '{lyr.name()}': คอลัมน์ {name} (เพิ่ม {_nn:,} รายการ · ไม่มีสิทธิ์ INSERT)")
            except Exception:
                continue
        return out

    def _commit_fail_perm(self, failed, layers):
        """★ 2.4.0 (review DI-13) — commit ที่ล้ม "เพราะสิทธิ์ไม่พอ" ไหม -> (True/False, ['ชั้น X: คอลัมน์ Y' / 'ตาราง Z', ...])
        ดูจาก commitErrors ก่อน (permission denied / 42501) · ไม่ใช่เรื่องสิทธิ์ = (False, []) โดยไม่ถามฐาน
        (เน็ตหลุด/ฐานไม่ตอบ ⇒ ถามสิทธิ์ทีละคอลัมน์จะค้างรอทุกคอลัมน์)
        เป็นเรื่องสิทธิ์ ⇒ ทิ้งผลสิทธิ์ที่จำไว้ของชั้นที่ล้ม (สิทธิ์อาจถูกถอนกลางเซสชัน: แคชบอก True แต่ฐานปฏิเสธ)
        แล้วถาม _commit_preflight ใหม่กับงานที่ยังค้าง = บอกได้ว่าคอลัมน์ไหน + กด 💾 รอบหน้าถูกกันก่อน commit ชั้นแรก"""
        txt = "\n".join(str(e) for _n, e in failed)
        if not _PERM_DENIED_RE.search(txt):
            return False, []
        names = {n for n, _e in failed}
        lyrs = [l for l in layers if l is not None and l.name() in names]
        items = []
        try:
            ids = {l.id() for l in lyrs}
            pc = getattr(self, "_perm_cache", None)
            if pc:
                for k in [k for k in pc if k[0] in ids]:
                    pc.pop(k, None)
            items = list(self._commit_preflight(lyrs))
        except Exception:
            _log_exc("ตรวจสิทธิ์หลังบันทึกไม่สำเร็จ (DI-13)")
        for obj in dict.fromkeys(_PERM_OBJ_RE.findall(txt)):
            if not any(obj in x for x in items):
                items.append(f"ตาราง {obj}")
        return True, items

    # ---------- ★ rc2 (audit A5-01 · A5-02 · A5-07) ถามสิทธิ์จากฐาน: มีเพดานเวลา · คิวรีเดียวหลายค่า · พักถามเมื่อฐานเงียบ ----------
    #   เดิม _can_*_uncached เรียก conn.executeSql ตรง ๆ บนเธรดหลัก (ไม่มี connect_timeout/statement_timeout/เธรดแยก) และไม่จำ None
    #   ⇒ ฐานเงียบ/คอนเนกชันใน pool ค้าง: 💾 ค้างคอลัมน์ละ 2 รอบ · ทุกครั้งที่กดเครื่องมือ (_need_column_or_warn · ➕ · 🗑) ค้างใหม่
    #   ⇒ ใช้เพดานชุดเดียวกับ _role_tier (_role_tcp_dead → _pg_connect_timeout → statement_timeout → _role_sql_bounded)
    #     + ฐานไม่ตอบ = จด "ช่วงพัก" ต่อชั้น _PERM_DOWN_S วิ ระหว่างนั้นตอบ None ทันที (ผู้เรียกทำตามกติกาเดิมของ None)
    def _perm_is_down(self, layer):
        try:
            t = (getattr(self, "_perm_down", None) or {}).get(layer.id())
        except Exception:
            return False
        if t is None:
            return False
        import time as _time
        if _time.monotonic() < t:
            return True
        self._perm_down.pop(layer.id(), None)
        return False

    def _perm_mark_down(self, layer, why):
        import time as _time
        try:
            if not hasattr(self, "_perm_down") or self._perm_down is None:
                self._perm_down = {}
            self._perm_down[layer.id()] = _time.monotonic() + float(self._PERM_DOWN_S)
        except Exception:
            pass
        try:
            QgsMessageLog.logMessage(_scrub("ถามสิทธิ์จากฐานไม่ได้ (ชั้น '%s') — %s · พักถาม %g วิ (ระหว่างนี้ไม่กันตามสิทธิ์)"
                                            % (layer.name(), why, float(self._PERM_DOWN_S))), "MLEP", Qgis.Warning)
        except Exception:
            pass

    def _perm_sql(self, layer, items):
        """ถามสิทธิ์ของ current_user บนตารางของชั้น หลายรายการในคิวรีเดียว (มีเพดานเวลา) -> [True/False/None ...] ตามลำดับ items
        หรือ None ทั้งชุด (ไม่ใช่ PostGIS · ไม่ใช่ตาราง · ช่วงพัก · ฐานไม่ตอบ/ล้ม)
        items = [(kind, name)] — 'upd'/'ins' = UPDATE/INSERT ของคอลัมน์ name (has_column_privilege · คอลัมน์ไม่มีในตาราง = None
        ไม่ทำให้ทั้งคิวรีล้ม) · 'tbl' = name เป็น 'DELETE' (has_table_privilege) หรือ 'INSERT' (has_any_column_privilege — ได้ทั้ง
        GRANT ระดับตารางและรายคอลัมน์) · ชื่อตาราง/คอลัมน์ผ่าน QgsExpression.quotedValue ทุกตัว (★ A5-07 เดิม '{tbl}' ไม่ escape)"""
        if not items:
            return []
        try:
            dp = layer.dataProvider()
            if dp is None or dp.name() != "postgres":
                return None
            from qgis.core import QgsDataSourceUri, QgsProviderRegistry
            uri = QgsDataSourceUri(dp.dataSourceUri())
            if not uri.table():
                return None
        except Exception:
            return None
        if self._perm_is_down(layer):
            return None
        sch = uri.schema() or "public"
        tbl = QgsExpression.quotedValue(f'"{sch}"."{uri.table()}"')
        exprs = []
        for kind, name in items:
            if kind == "tbl":
                fn = "has_any_column_privilege" if name == "INSERT" else "has_table_privilege"
                exprs.append(f"{fn}(current_user, {tbl}, {QgsExpression.quotedValue(name)})")
            else:
                q = QgsExpression.quotedValue(str(name))
                pv = "'INSERT'" if kind == "ins" else "'UPDATE'"
                exprs.append(f"CASE WHEN EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = {tbl}::regclass AND attname = {q} "
                             f"AND attnum > 0 AND NOT attisdropped) THEN has_column_privilege(current_user, {tbl}, {q}, {pv}) END")
        dead = self._role_tcp_dead(uri)
        if dead:
            self._perm_mark_down(layer, dead)
            return None
        try:
            md = QgsProviderRegistry.instance().providerMetadata("postgres")
            conn = md.createConnection(uri.connectionInfo(True), {})
            with self._busy("perm"), self._pg_connect_timeout(self._ROLE_CONNECT_TIMEOUT_S):
                rows = self._role_sql_bounded(
                    conn, "SET LOCAL statement_timeout = %d; SELECT %s" % (int(self._ROLE_STMT_TIMEOUT_MS), ", ".join(exprs)),
                    key=(uri.host() or uri.service(), uri.port(), uri.database(), uri.username()))   # ★ 2.4.1 (R3-04) ต่อคอนเนกชัน
        except Exception as e:
            _m = str(e)
            import re as _re
            if isinstance(e, TimeoutError) or _re.search(
                    r"connect|connection|timeout|timed out|server closed|terminat|could not|SSL|network|statement_timeout",
                    _m, _re.I):
                self._perm_mark_down(layer, _m[:200])
            else:
                try:
                    QgsMessageLog.logMessage(_scrub("ถามสิทธิ์จากฐานไม่ได้ (ชั้น '%s') — %s" % (layer.name(), _m[:300])),
                                             "MLEP", Qgis.Warning)
                except Exception:
                    pass
            return None
        row = rows[0] if rows else None
        if not row or len(row) != len(items):
            return None
        out = []
        for v in row:
            out.append(True if v in (True, "t", "true", "1", 1) else False if v in (False, "f", "false", "0", 0) else None)
        return out

    def _perm_prefetch(self, layer, items):
        """เติม _perm_cache ของรายการที่ยังไม่รู้ผลด้วยคิวรีเดียว (ชั้น PostGIS เท่านั้น · ไม่จำ None)
        items = [('upd', คอลัมน์) / ('ins', คอลัมน์) / ('tbl', 'DELETE'|'INSERT')] — คีย์แคชเดียวกับ _can_update_column /
        _can_insert_column / _can_table_priv"""
        try:
            dp = layer.dataProvider()
            if dp is None or dp.name() != "postgres":
                return
        except Exception:
            return
        if not hasattr(self, "_perm_cache"):
            self._perm_cache = {}

        def _key(it):
            k, n = it
            return (layer.id(), n if k == "upd" else (("@ins", n) if k == "ins" else ("@table", n)))
        todo = list(dict.fromkeys(it for it in items if it[1] and _key(it) not in self._perm_cache))
        if not todo:
            return
        vals = self._perm_sql(layer, todo)
        for it, v in zip(todo, vals or ()):
            if v is not None:
                self._perm_cache[_key(it)] = v

    def _can_table_priv(self, layer, priv):
        """★ 2.3.7 (audit F7) — สิทธิ์ระดับตาราง (DELETE / INSERT) ของ role ที่ต่อฐาน → True / False / None (ถามไม่ได้)
        จำผลต่อ (ชั้น, สิทธิ์) ใน _perm_cache แบบ _can_update_column · ไม่จำ None (ถามใหม่ได้รอบหน้า)
        ★ rc2 (audit A5-01) — ช่วงพักหลังฐานไม่ตอบ (_perm_is_down) ⇒ None ทันที ไม่ถามซ้ำ"""
        ckey = (layer.id() if layer is not None else None, ("@table", priv))
        if not hasattr(self, "_perm_cache"):
            self._perm_cache = {}
        if ckey in self._perm_cache:
            return self._perm_cache[ckey]
        if layer is not None and self._perm_is_down(layer):
            return None
        val = self._can_table_priv_uncached(layer, priv)
        if val is not None:
            self._perm_cache[ckey] = val
        return val

    def _can_table_priv_uncached(self, layer, priv):
        """★ 2.3.7 (audit F7) — สิทธิ์ priv ของ current_user บนตารางของชั้น → True / False / None
        DELETE = has_table_privilege (PostgreSQL ไม่มี DELETE รายคอลัมน์)
        INSERT = has_any_column_privilege — ได้ทั้ง GRANT INSERT ระดับตารางและรายคอลัมน์ (GRANT INSERT (คอลัมน์) …)
          ซึ่ง has_table_privilege ตอบ false ⇒ ถ้าใช้ตัวนั้นจะกัน Add Node ของบัญชีที่เพิ่มหมุดได้จริง (กันเกินจริง)
          (คอลัมน์ที่แถวใหม่เขียนจริงตรวจแยกใน _can_insert_column — rc2 A5-02)
        ไม่ใช่ PostGIS · ชั้นที่ไม่ใช่ตาราง (คิวรี/ไม่มีชื่อตาราง) · ถามไม่ได้ ⇒ None (= ไม่กัน)
        ★ rc2 (audit A5-01) — ถามผ่าน _perm_sql (เพดานเวลา · เธรดแยก)"""
        if priv not in ("DELETE", "INSERT"):
            return None
        try:
            r = self._perm_sql(layer, [("tbl", priv)])
        except Exception:
            return None
        return r[0] if r else None

    def _can_insert_column(self, layer, column):
        """★ rc2 (audit A5-02) — INSERT รายคอลัมน์ (has_column_privilege … 'INSERT') → True / False / None · จำผลแบบ _can_update_column"""
        ckey = (layer.id() if layer is not None else None, ("@ins", column))
        if not hasattr(self, "_perm_cache"):
            self._perm_cache = {}
        if ckey in self._perm_cache:
            return self._perm_cache[ckey]
        if layer is None or self._perm_is_down(layer):
            return None
        try:
            r = self._perm_sql(layer, [("ins", column)])
        except Exception:
            r = None
        val = r[0] if r else None
        if val is not None:
            self._perm_cache[ckey] = val
        return val

    def _can_update_column(self, layer, column):
        # ★ 31 ส.ค. 69 — เดิมเปิดคอนเนกชันใหม่และยิง SQL ทุกครั้งที่กดปุ่ม บน UI thread
        #   ถ้าฐานข้อมูลช้า/ไม่ตอบ หน้าจอจะค้าง ซึ่งเป็นอาการเดียวกับที่เรากำลังตามอยู่พอดี
        #   สิทธิ์ GRANT แทบไม่เปลี่ยนระหว่างเซสชัน -> จำผลไว้ต่อ (เลเยอร์, คอลัมน์)
        # ★ rc2 (audit A5-01 + ผู้ตรวจทานพบเพิ่ม) — ช่วงพักหลังฐานไม่ตอบ ⇒ None ทันที (ตอนเริ่มเครื่องมือไม่ค้างซ้ำทุกครั้งที่กด)
        ckey = (layer.id() if layer is not None else None, column)
        if not hasattr(self, "_perm_cache"):
            self._perm_cache = {}
        if ckey in self._perm_cache:
            return self._perm_cache[ckey]
        if layer is not None and self._perm_is_down(layer):
            return None
        val = self._can_update_column_uncached(layer, column)
        # ไม่จำผลตอนเช็คไม่ได้ (None) เผื่อเน็ตสะดุดชั่วคราวแล้วรอบหน้าถามได้ใหม่
        if val is not None:
            self._perm_cache[ckey] = val
        return val

    def _can_update_column_uncached(self, layer, column):
        """role ที่ต่อ DB เขียนคอลัมน์นี้ได้ไหม -> True / False / None (เช็คไม่ได้)

        ★ 31 ส.ค. 69 — พนักงานได้ GRANT UPDATE แค่บางคอลัมน์ (ชั้นแปลง: geom, SCORE,
          REMARK, cluster_id · ชั้นหมุด: geom, SCORE) ถ้าเครื่องมือไปเขียนคอลัมน์อื่น
          QGIS จะรับไว้ใน buffer แล้วไป **ล้มตอน commit** พร้อมพางานอื่นที่ค้างอยู่ตกไปด้วย
          -> ต้องถามฐานข้อมูลก่อนเริ่มเครื่องมือ ไม่ใช่ไปรู้ตอนกดบันทึก
        ★ 2.4.0 (review DI-13) — รายการข้างบนเป็นของ 31 ส.ค. · ตั้งแต่แบ่ง 3 ชั้นสิทธิ์ (18 ก.ย.) พนักงานได้ UPDATE(BND_NAME)
          ของชั้นหมุดเพิ่ม (✏️ แก้ชื่อหมุดแบบจำกัด · Add Node ตั้งชื่อหมุด) · โค้ดไม่ยึดรายการใดเลย
          ถามฐานจริงทุกครั้งผ่านฟังก์ชันนี้ (จำผลต่อชั้น/คอลัมน์) ⇒ ถ้าฐานไหนไม่ได้ GRANT ก็กันได้ตรงตามฐานนั้น
        ★ rc2 (audit A5-01 · A5-07) — ถามผ่าน _perm_sql (เพดานเวลา · เธรดแยก · ชื่อตาราง escape)"""
        try:
            r = self._perm_sql(layer, [("upd", column)])
        except Exception:
            return None
        return r[0] if r else None

    def _need_column_or_warn(self, layer, column, title):
        """คืน True ถ้าเขียนคอลัมน์ได้ (หรือเช็คไม่ได้ = ปล่อยผ่านแบบเดิม)"""
        ok = self._can_update_column(layer, column)
        if ok is False:
            self._ask(
                QtWidgets.QMessageBox.Warning, title,
                f"บัญชีที่ใช้อยู่ไม่มีสิทธิ์แก้คอลัมน์ '{column}' ของชั้น '{layer.name()}'\n\n"
                "ถ้าฝืนใช้ ระบบจะรับการแก้ไว้ก่อนแล้วไปล้มตอนกดบันทึก "
                "ซึ่งจะทำให้งานอื่นที่ยังไม่ได้บันทึกตกไปด้วย\n\n"
                "แจ้งผู้ดูแลฐานข้อมูลให้เพิ่มสิทธิ์ก่อน")
            return False
        return True

    def toggle_admin_mode(self):
        """Ctrl+Shift+F12: สลับเข้า/ออกโหมดพิเศษ (ต้องเปิดหน้าต่างปลั๊กอินก่อน)

        ★ 2.3.0 — ปุ่มลัดเดียวกันทั้งผู้ช่วยผู้ดูแลและผู้ดูแล **แต่ได้ไม่เท่ากัน**
          mlep_mod   -> โหมดผู้ช่วยผู้ดูแล : ลบ Node/แก้ชื่อหมุด "แบบเต็ม" · กล่อง ADMIN ยังซ่อน
          mlep_admin -> โหมดผู้ดูแล        : ของผู้ช่วย + กล่อง ADMIN (ลบแปลง · เปลี่ยน Type · มอบหมาย · ปลดล็อก L1)
        """
        # ★ 2.4.0 (review DI-09) — ออกจากโหมด = ทำได้เสมอ (ย้ายขึ้นก่อนด่านแผง)
        #   เข้าโหมด = ต้องเห็นแผงอยู่ (เดิมเช็คแค่ dlg is None ⇒ ปิดแผงแล้วยังกดเข้าโหมดได้โดยไม่เห็นแถบแดง) · เงียบเหมือนเดิม
        if getattr(self, "_admin_on", False):
            was = self.TIER_NAME.get(getattr(self, "_mode_tier", 0), "")
            self._set_admin_mode(False)
            self.iface.messageBar().pushInfo("MLEP", "ออกจากโหมด%sแล้ว" % was)
            return
        if not self._dlg_shown():
            return
        tier = self._role_tier()
        if tier is None or tier < self.TIER_MOD:
            # เช็คไม่ได้ หรือเป็นพนักงานทั่วไป -> เงียบ (ไม่เผยว่ามีฟีเจอร์)
            return
        self._set_admin_mode(True, tier)
        self.iface.messageBar().pushMessage(
            "MLEP", "เข้าสู่โหมด%sแล้ว (กด Ctrl+Shift+F12 อีกครั้งเพื่อออก)"
                    % self.TIER_NAME.get(tier, ""), level=1, duration=5)

    def _on_main_dialog_closed(self):
        """ปิดหน้าต่างหลัก = ล้าง cache (เดิม) + ★ 2.3.7 (review DI-09) ออกจากโหมดพิเศษ/ล็อก L1 กลับ
        (คีย์ลัดใช้ได้ทั้งที่หน้าต่างปิด = มองไม่เห็นแถบแดงว่ายังอยู่ในโหมด)"""
        try:
            self._clear_caches()
        except Exception:
            pass
        if getattr(self, "_admin_on", False) or getattr(self, "_admin_unlock_l1", False):
            try:
                self._set_admin_mode(False)
            except Exception:
                pass

    def _set_admin_mode(self, on, tier=None):
        """เปิด/ปิดโหมดพิเศษ · `tier` = ชั้นที่ได้ — **ต้องส่งทุกครั้งที่เปิด** (ผู้เรียกจริงส่งชั้นจาก role ในฐาน)

        ★ 2.3.7 (review MT-05-D) — เดิมไม่ส่ง tier = ได้ชั้นผู้ดูแลเต็มโดยไม่เช็ค role (ค่าปริยายไม่ปลอดภัย)
          ⇒ ไม่ส่ง tier หรือชั้นต่ำกว่าผู้ช่วยผู้ดูแล = **ไม่เปิดโหมด** (ปิดไว้ก่อนเมื่อไม่แน่ใจ) + บันทึก Log"""
        if on and (tier is None or int(tier) < self.TIER_MOD):
            try:
                QgsMessageLog.logMessage(
                    "_set_admin_mode: เปิดโหมดโดย%s — ไม่เปิดให้" % (
                        "ไม่ระบุชั้น" if tier is None else "ชั้น %s" % tier), "MLEP", Qgis.Warning)
            except Exception:
                pass
            on = False
        self._admin_on = bool(on)
        self._mode_tier = int(tier) if on else self.TIER_STAFF
        if not on:
            self._admin_unlock_l1 = False
            # ★ 2.3.7 (review UX-04 / DI-09) — ออกจากโหมดตอนปลดล็อกอยู่ ⇒ ป้ายเดิมค้างเป็น "🔒 ล็อก L1 กลับ" (สถานะกลับด้าน)
            _ub = getattr(self, "_admin_unlock_btn", None)
            if _ub is not None:
                try:
                    _ub.setText("🔓 ปลดล็อก L1")
                except Exception:
                    pass
        # ★ 2.3.7 rc3 (เจ้าของงานสั่ง 4 ต.ค.: คีย์ลัดโหมดผู้ดูแล) — คีย์ลัดของปุ่มโหมดพิเศษตามโหมด/ชั้นใหม่ทุกครั้ง
        #   เข้าโหมด/เปลี่ยนชั้น ⇒ สร้างเฉพาะปุ่มที่ชั้นนี้ใช้ได้ · ออกจากโหมด ⇒ ทิ้งหมด · ทำก่อนแตะวิดเจ็ตของแผง (แผงพังก็ยังทิ้งได้)
        self._sync_admin_shortcuts("_set_admin_mode")
        b = getattr(self, "_admin_banner", None)
        if b is not None:
            b.setVisible(self._admin_on)
        # 🔴 ปุ่มชั้นผู้ดูแลต้องโผล่เฉพาะชั้นผู้ดูแล · ★ 2.3.9 ผู้ช่วยผู้ดูแลเห็นกล่องนี้แต่เฉพาะปุ่มชั้นตัวเอง (🍩 · ➕)
        self._adm_apply_tier()
        self._admin_refresh_banner()
        self._fit_dialog_height()

    # ---------- ตัวช่วยอ่านชั้นที่ "โหมดตอนนี้" ให้ ----------
    def _tier_now(self):
        return getattr(self, "_mode_tier", self.TIER_STAFF) if getattr(self, "_admin_on", False) \
            else self.TIER_STAFF

    def _is_mod(self):
        """ชั้นผู้ช่วยผู้ดูแลขึ้นไป — ใช้กับ ลบ Node/แก้ชื่อหมุด 'แบบเต็ม'"""
        return self._tier_now() >= self.TIER_MOD

    def _is_admin(self):
        """ชั้นผู้ดูแล — ใช้กับ ลบแปลง · เปลี่ยน Type · มอบหมาย · ปลดล็อก L1"""
        return self._tier_now() >= self.TIER_ADMIN

    def _is_landsmaps(self, poly_lyr, pf):
        """แปลงที่เลือกเป็นของ LandsMaps ไหม (Type = L2-LM) — ใช้ผ่อนด่านสิทธิ์ให้พนักงาน"""
        try:
            i = self._field_index(poly_lyr.fields(), 'type')
            if i == -1:
                return False
            v = pf[i]
            return v is not None and str(v).strip().upper() in self.LANDSMAPS_TYPES
        except Exception:
            return False

    def _adm_keep(self, bid, btn):
        """★ 2.3.9 — จำปุ่มของกล่องโหมดพิเศษตาม id (ใช้ซ่อน/โชว์ตามชั้นใน _set_admin_mode) แล้วคืนปุ่มเดิม"""
        if not hasattr(self, "_adm_btn"):
            self._adm_btn = {}
        self._adm_btn[bid] = btn
        return btn

    def _adm_apply_tier(self):
        """★ 2.3.9 — กล่องโหมดพิเศษ: ผู้ดูแลเห็นทุกปุ่ม · ผู้ช่วยผู้ดูแลเห็นเฉพาะปุ่มที่ชั้นตัวเองใช้ได้
        (ตามชั้นใน _admin_shortcut_actions — ตารางเดียวกับคีย์ลัด) · ไม่อยู่ในโหมด = ซ่อนทั้งกล่อง"""
        g = getattr(self, "_admin_group", None)
        if g is None:
            return
        t = self._tier_now() if getattr(self, "_admin_on", False) else self.TIER_STAFF
        ชั้นปุ่ม = {r[0]: r[3] for r in self._admin_shortcut_actions()}
        for bid, btn in (getattr(self, "_adm_btn", None) or {}).items():
            try:
                btn.setVisible(t >= ชั้นปุ่ม.get(bid, self.TIER_ADMIN))
            except Exception:
                pass
        try:
            g.setTitle("ผู้ดูแล (ADMIN)" if t >= self.TIER_ADMIN else "ผู้ช่วยผู้ดูแล (MOD)")
        except Exception:
            pass
        g.setVisible(self._admin_on and t >= self.TIER_MOD)

    def _admin_refresh_banner(self):
        # ★ 2.4.0 (review DI-09) — ปลดล็อก L1 อยู่ ⇒ ชื่อหน้าต่างบอกด้วย (เห็นได้แม้ป้ายแดงอยู่นอกจอ/แผงถูกบัง) · ล็อกอยู่ = ชื่อเดิม
        d = getattr(self, "dlg", None)
        if d is not None:
            try:
                d.setWindowTitle(f"Multi-Layer Edit Pro {self.version}"
                                 + (" — ปลดล็อก L1" if getattr(self, "_admin_unlock_l1", False) else ""))
            except Exception:
                pass
        b = getattr(self, "_admin_banner", None)
        if b is None:
            return
        if getattr(self, "_admin_unlock_l1", False):
            b.setText("🔓 โหมดผู้ดูแล + ปลดล็อก L1 แล้ว — ระวัง!")
        elif self._tier_now() >= self.TIER_ADMIN:
            b.setText("🔓 โหมดผู้ดูแล (ADMIN)")
        else:
            # ★ 2.3.0 ผู้ช่วยผู้ดูแล — ข้อความบอกให้ชัดว่าได้อะไรเพิ่ม จะได้ไม่เข้าใจว่าเป็นแอดมินเต็ม
            b.setText("🔎 โหมดผู้ช่วยผู้ดูแล (MOD) — ลบ Node / แก้ชื่อหมุด ได้เต็ม · แบ่งหัก/แยก · สร้างรูปแปลง (L2)")

    def toggle_unlock_l1(self, why=None):
        # 🔴 2.3.0 — ด่านชั้นผู้ดูแล ไม่พึ่ง "ซ่อนปุ่ม" อย่างเดียว
        #   ผู้ช่วยผู้ดูแลเปิดโหมดได้เหมือนกัน กล่อง ADMIN แค่ถูก setVisible(False)
        #   ซึ่งกันเมาส์ได้ แต่ไม่ได้กันการเรียกเมธอดจากทางอื่น (ปุ่มลัด/สคริปต์/คอนโซล)
        # ★ 2.4.0 (review DI-09) — why = เหตุที่โค้ดสั่งล็อกกลับเอง (ต่อท้ายข้อความ "ล็อก L1 กลับแล้ว") · ปุ่ม/คีย์ลัดไม่ส่ง
        if not self._is_admin():
            return
        if not getattr(self, "_admin_unlock_l1", False):
            # ★ 2.4.0 (review DI-09) — ปลดล็อกได้เฉพาะตอนแผงเปิดให้เห็นอยู่ (ทุกทาง: ปุ่ม · คีย์ลัด · คอนโซล) · ล็อกกลับได้เสมอ
            if not self._dlg_shown():
                return
            # ★ 2.4.0 (review DI-09) — ถาม role จากฐานของชั้นแปลงที่เลือกอยู่ "ตอนนี้" ทุกทาง (เดิมเฉพาะคีย์ลัด ⇒ ปุ่มในแผงใช้ชั้นที่จำไว้ตอนเข้าโหมด
            #   ⇒ เข้าโหมดบนคอนเนกชัน A แล้วสลับคอมโบไปชั้นของคอนเนกชัน B ที่เป็นพนักงาน ก็ยังปลดล็อกได้) · ถามไม่ได้/ไม่ใช่ PostGIS = ไม่ปลดล็อก
            #   ข้อความขึ้นได้เฉพาะตอนอยู่ในโหมดผู้ดูแลแล้ว (_is_admin ข้างบน) · เหตุผลละเอียดอยู่ใน Log ของ _role_tier
            _ok = self._admin_role_ok()
            if _ok is not True:
                # ★ rc2 (audit A5-06) — แยกเหตุ: None = ถามฐานไม่ได้ (ฐานไม่ตอบ/เครือข่าย/ไม่ใช่ชั้น PostGIS) ⇒ ลองใหม่ได้
                #   · False = ฐานตอบว่าบัญชีนี้ไม่ใช่ผู้ดูแล · เดิมข้อความเดียว "ตรวจ…ไม่ผ่าน" ⇒ ผู้ดูแลเข้าใจว่าถูกถอนสิทธิ์
                _msg = ("ไม่ปลดล็อก L1 — ถามสิทธิ์จากฐานข้อมูลของชั้นแปลงที่เลือกอยู่ไม่ได้ (ฐานไม่ตอบ/เครือข่าย/ไม่ใช่ชั้นฐานข้อมูล) "
                        "— ลองใหม่อีกครั้ง (เหตุผลอยู่ใน Log Messages แท็บ MLEP)" if _ok is None else
                        "ไม่ปลดล็อก L1 — ฐานข้อมูลของชั้นแปลงที่เลือกอยู่ตอบว่าบัญชีนี้ไม่ใช่ผู้ดูแล")
                self.iface.messageBar().pushMessage(
                    "ADMIN", _msg
                    # ★ rc1 (F8 · review B2-02) คิวรีตรวจสิทธิ์ค้างจนถามใหม่ไม่ได้ ⇒ บอกทางออก (เดิมไม่บอก)
                    + (" · คิวรีตรวจสิทธิ์ครั้งก่อนค้างอยู่ — ถ้าฐานข้อมูลกลับมาแล้ว ให้ปิดแล้วเปิด QGIS ใหม่"
                       if getattr(self, "_role_stuck", False) else ""),
                    level=1, duration=(10 if getattr(self, "_role_stuck", False) else 6))
                return
            # จำคอนเนกชันที่ตรวจผ่าน ⇒ คอมโบแปลงย้ายไปคอนเนกชันอื่น = ล็อกกลับเอง (_admin_unlock_follow_conn)
            self._admin_unlock_conn = self._poly_conn_key()
        self._admin_unlock_l1 = not getattr(self, "_admin_unlock_l1", False)
        self._admin_refresh_banner()
        if self._admin_unlock_l1:
            # ★ 2.4.0 (review DI-09) — ปลดล็อกอยู่ = ป้ายแดงต้องโผล่เสมอ (ไม่พึ่งว่าตอนเข้าโหมดตั้งไว้แล้ว)
            _b = getattr(self, "_admin_banner", None)
            if _b is not None:
                try:
                    _b.setVisible(True)
                except Exception:
                    pass
        btn = getattr(self, "_admin_unlock_btn", None)
        if btn is not None:
            btn.setText("🔒 ล็อก L1 กลับ" if self._admin_unlock_l1 else "🔓 ปลดล็อก L1")
        self.iface.messageBar().pushMessage(
            "ADMIN",
            "ปลดล็อก L1 แล้ว — แก้ไข/ลบได้ทุกแปลง (ระวัง)"
            if self._admin_unlock_l1 else ("ล็อก L1 กลับแล้ว" + (" — " + why if why else "")),
            level=(2 if self._admin_unlock_l1 else 1), duration=(5 if self._admin_unlock_l1 or not why else 8))
        if self._admin_unlock_l1:
            self._l1_prefetch()

    def _l1_prefetch(self):
        """★ rc11 (ผลตรวจ Windows rc10 · agent A ข้อสังเกต · agent B ⚪9) ตอนปลดล็อก L1 (ฐานเพิ่งตอบสิทธิ์ = ต่อได้) ถามล่วงหน้า: trigger capture ของ
        ชั้นแปลง + ชนิดเหตุ L1 ⇒ ด่านลำดับบันทึกใช้ค่าที่จำ (_l1_stale_ok) ไม่ต้องต่อฐานในเธรดหน้าจอกลางรอบ Save All (rc10 ถาม pg_trigger ระหว่าง
        beforeCommit ของชั้นหมุด · ฐานปิด +1.5 วิ) · ถามไม่ได้ = ไม่เป็นไร (ด่านถามเองตอนบันทึกแบบเดิม)"""
        try:
            lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
            if lyr is None:
                return
            if hasattr(self, "_l1_capture_on"):
                self._l1_capture_on(lyr)
            if hasattr(self, "_l1_kinds_for"):
                self._l1_kinds_for(lyr)
        except Exception:
            pass

    def _poly_conn_key(self):
        """★ 2.4.0 (review DI-09) — กุญแจคอนเนกชันของชั้นแปลงในคอมโบ (ฐาน · เครื่อง · พอร์ต · บัญชี = ที่ _role_tier ถาม)
        ไม่ใช่ชั้น PostGIS / ไม่มีชั้น / อ่านไม่ได้ = None · ไม่ถามฐาน (อ่านจาก URI ของชั้นเท่านั้น)"""
        try:
            lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
            dp = lyr.dataProvider() if lyr is not None else None
            if dp is None or dp.name() != "postgres":
                return None
            from qgis.core import QgsDataSourceUri
            return QgsDataSourceUri(dp.dataSourceUri()).connectionInfo(False) or None
        except Exception:
            return None

    def _admin_unlock_follow_conn(self):
        """★ 2.4.0 (review DI-09) — ปลดล็อก L1 อยู่ แล้วคอมโบแปลงชี้ไปคนละคอนเนกชันกับที่ตรวจสิทธิ์ตอนปลดล็อก ⇒ ล็อกกลับเอง
        (สิทธิ์ผู้ดูแลตรวจกับคอนเนกชันนั้นคอนเนกชันเดียว · ปลดล็อกใหม่ได้ = ถามฐานของคอนเนกชันใหม่)
        เรียกจาก _on_layer_combo_changed (ผู้ใช้สลับเอง) และ refresh_layers (ชั้นที่เลือกถูกลบ/เลือกให้ใหม่ — สัญญาณถูกปิดไว้)"""
        if not getattr(self, "_admin_unlock_l1", False):
            return
        try:
            if self._poly_conn_key() == getattr(self, "_admin_unlock_conn", None):
                return
            self.toggle_unlock_l1(why="ชั้นแปลงที่เลือกอยู่บนคอนเนกชันฐานข้อมูลอื่น (ปลดล็อกใหม่ได้ ระบบจะตรวจสิทธิ์กับคอนเนกชันนี้)")
        except Exception:
            _log_exc("_admin_unlock_follow_conn: ล็อก L1 กลับไม่สำเร็จ", once_key="_admin_unlock_follow_conn")

    # ---------- เครื่องมือผู้ดูแล ----------
    def _admin_ready(self, title):
        """คืน (poly_lyr, point_lyr) ถ้าพร้อมใช้เครื่องมือ **ชั้นผู้ดูแล**, ไม่งั้น None

        ★ 2.3.0 — ผู้ช่วยผู้ดูแล (mlep_mod) เปิดโหมดได้เหมือนกัน แต่ต้องไม่ผ่านด่านนี้
          (ลบแปลง · เปลี่ยน Type · มอบหมาย · ปลดล็อก L1 = ผู้ดูแลเท่านั้น)
        """
        if not self._is_admin():
            return None
        return self._tool_ready(title)

    def _mod_ready(self, title):
        """★ 2.3.9 — เหมือน `_admin_ready` แต่ชั้น **ผู้ช่วยผู้ดูแลขึ้นไป** (🍩 แบ่งหัก/แยก · ➕ สร้างรูปแปลง — เจ้าของงานสั่ง 11 ต.ค.)
        สิ่งที่ยังเป็นของผู้ดูแลเท่านั้นยังกันในตัวเอง (ปลดล็อก L1 ⇒ ผู้ช่วยแตะแปลง L1 ไม่ได้)"""
        if not self._is_mod():
            return None
        return self._tool_ready(title)
