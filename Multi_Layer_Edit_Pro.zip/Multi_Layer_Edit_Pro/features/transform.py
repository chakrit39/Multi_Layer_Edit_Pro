# -*- coding: utf-8 -*-
"""Move / Rotate / Scale / Transform: จุดควบคุม, ภาพตัวอย่าง และการคำนวณ

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import math
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import (Qgis, QgsFeatureRequest, QgsGeometry, QgsMessageLog, QgsPointLocator, QgsPointXY,
                       QgsProject, QgsUnitTypes, QgsVectorLayer, QgsWkbTypes)
from qgis.gui import QgsRubberBand, QgsVertexMarker
from ..core.const import _CLICK_LIMIT, _PREVIEW_MODES, _PREVIEW_VERTEX_BUDGET
from ..core.util import _log_exc, _txt, _UTM_FIELD_NAMES
from ..lock_rules import is_l1_type, L1_TYPES, norm_type
from ..ui.qt_helpers import _EmitClickTool


class TransformMixin:
    """Move / Rotate / Scale / Transform: จุดควบคุม, ภาพตัวอย่าง และการคำนวณ"""

    @staticmethod
    def _ctl_tol(lyr):
        """ระยะต่ำสุดระหว่างจุดควบคุม (หน่วยของชั้น): 1 มม. · ชั้นที่เป็นองศา ≈ 1e-8° (~1 มม.)"""
        try:
            if lyr is not None and lyr.crs().isValid() and lyr.crs().mapUnits() == QgsUnitTypes.DistanceDegrees:
                return 1e-8
        except Exception:
            pass
        return 0.001

    def _check_control_points(self, mode, pts, lyr=None):
        """★ 2.3.7 (review DI-24) — จุดควบคุมซ้อน/ชิดกันเกินไป ⇒ ข้อความบอกเหตุ (None = ใช้ได้)
        เดิมไม่ตรวจเลย: Transform ที่ ② กับ ④ ทับกัน เขียนแปลง+หมุดที่เลือกทั้งหมดยุบเป็นจุดเดียวโดยไม่ถาม
        · ① ทับ ③ ขึ้นกล่องแดงโทษว่า "เขียนรูปทรงไม่สำเร็จ" · Scale จุดอ้างอิงทับจุดหมุน = คำสั่งแก้ไขเปล่า (DI-28)
        ตรวจเฉพาะคู่ที่มีจุดครบแล้ว (เรียกได้ทุกคลิก) · เทียบในพิกัดของชั้น (จุดถูกแปลงตอนคลิกแล้ว — DI-03)
        Move: ห้ามแค่ "ปลายทาง = จุดเดิมเป๊ะ" (ขยับระดับ มม. เพื่อปิดช่องว่างเป็นงานจริง)"""
        tol = self._ctl_tol(lyr)
        p, n = list(pts), len(pts)

        def near(a, b):
            return math.hypot(a.x() - b.x(), a.y() - b.y()) < tol
        if mode == 'move':
            if n >= 2 and p[0].x() == p[1].x() and p[0].y() == p[1].y():
                return "จุดปลายทางเป็นจุดเดียวกับจุดอ้างอิง — ไม่มีอะไรต้องขยับ (คลิกจุดปลายทางใหม่)"
        elif mode in ('rotate', 'scale'):
            if n >= 2 and near(p[0], p[1]):
                return "จุดอ้างอิงทับหรือชิดจุดหมุนเกินไป (ต้องห่างกันอย่างน้อย 1 มม.) — คลิกจุดอ้างอิงใหม่"
            if n >= 3 and near(p[0], p[2]):
                return ("จุดยืนยันทับหรือชิดจุดหมุนเกินไป — แปลงจะยุบเป็นจุดเดียว คลิกใหม่" if mode == 'scale'
                        else "จุดยืนยันทับหรือชิดจุดหมุนเกินไป — วัดมุมไม่ได้ คลิกใหม่")
        elif mode == 'transform':
            if n >= 3 and near(p[0], p[2]):
                return "③ ต้นทาง 2 ทับหรือชิด ① ต้นทาง 1 เกินไป (ต้องห่างกันอย่างน้อย 1 มม.) — คลิก ③ ใหม่"
            if n >= 4 and near(p[1], p[3]):
                return "④ ปลายทาง 2 ทับหรือชิด ② ปลายทาง 1 เกินไป — แปลงจะยุบเป็นจุดเดียว คลิก ④ ใหม่"
        elif mode == 'align':
            if n >= 2 and near(p[0], p[1]):
                return "จุดที่ 2 ทับหรือชิดจุดที่ 1 เกินไป (ต้องห่างกันอย่างน้อย 1 มม.) — คลิกจุดที่ 2 ใหม่"
        return None

    def _bound_pair_now(self, attr, title):
        """★ 2.3.7 (review DI-10) — คู่ชั้น (แปลง, หมุด) ที่ "ผูกไว้ตอนกดปุ่ม" ต้องยังเป็นคู่ในคอมโบตอนนี้
        เดิมอ่านคอมโบใหม่ตอนลงมือ ⇒ สลับคอมโบระหว่างเครื่องมือค้าง arm (Move/Rotate/Scale ค้างข้ามรอบ) = เขียนผิดชั้น
        ไม่ตรง ⇒ ยกเลิกเครื่องมือ + แจ้ง แล้วคืน None · ตรง/ไม่ได้ผูก (เรียกตรงจากโค้ด) ⇒ คืน (poly, point) ปัจจุบัน"""
        poly = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point = QgsProject.instance().mapLayer(self.point_cb.currentData())
        lids = getattr(self, attr, None)
        if lids is not None:
            try:
                now = (poly.id() if poly else None, point.id() if point else None)
            except RuntimeError:
                now = None
            if now != tuple(lids):
                self.cancel_transform()
                self.iface.messageBar().pushMessage(
                    title, "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดเครื่องมือ — ยกเลิกเพื่อกันแก้ผิดชั้น "
                           "(กดปุ่มเครื่องมือใหม่อีกครั้ง)", level=1, duration=8)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                return None
        return poly, point

    def _xform_hint_text(self, mode, k):
        """★ 2.3.7 (review UX-20) — ข้อความ "ทำอะไรอยู่ + ขั้นต่อไป" ของเครื่องมือขยับแปลง (k = จำนวนจุดที่คลิกแล้ว)"""
        steps = self._XFORM_STEPS.get(mode)
        if not steps:
            return None
        n = len(steps)
        k = max(0, min(int(k), n - 1))
        circ = "①②③④"
        order = " → ".join(f"{circ[i]} {s}" + (" ✓" if i < k else "") for i, s in enumerate(steps))
        nxt = f"คลิก {circ[k]} {steps[k]}"
        if mode in _PREVIEW_MODES and k == n - 1:
            nxt += " (เลื่อนเมาส์ดูเงาก่อนคลิก)"
        return (f"{order} · ต่อไป: {nxt} — จุด {k}/{n} · "
                "คลิกขวา/Esc = ยกเลิก · Backspace = ถอยจุดล่าสุด")

    def _xform_hint(self, text, level=0):
        """ข้อความขั้นตอนของเครื่องมือขยับแปลง — มีได้ทีละอัน ค้างไว้จนเลิกใช้เครื่องมือ (เอาออกใน _map_tool_changed)"""
        self._xform_hint_pop()
        if not text:
            return
        title = (getattr(self, "mode", "") or "MLEP").capitalize()
        bar = self.iface.messageBar()
        try:
            from qgis.gui import QgsMessageBar
            item = QgsMessageBar.createMessage(title, text)
            got = bar.pushWidget(item, level, 0)
            self._xform_hint_item = got if got is not None else item
        except Exception:
            bar.pushMessage(title, text, level=level, duration=10)

    def _xform_hint_pop(self):
        it, self._xform_hint_item = getattr(self, "_xform_hint_item", None), None
        if it is not None:
            try:
                self.iface.messageBar().popWidget(it)
            except Exception:
                pass

    def _xform_tool_active(self):
        t = getattr(self, "_xform_tool", None)
        try:
            return t is not None and self.iface.mapCanvas().mapTool() is t
        except Exception:
            return False

    def _xform_step_hint(self):
        """อัปเดตข้อความขั้นตอนตามจำนวนจุดที่คลิกแล้ว — เฉพาะตอนเครื่องมือขยับแปลงยังอยู่บนแคนวาส"""
        if self._xform_tool_active():
            self._xform_hint(self._xform_hint_text(self.mode, len(self.src_pts)))
        else:
            self._xform_hint_pop()

    def _xform_key(self, what):
        """★ 2.3.7 (review UX-02) — Esc = ยกเลิก (เหมือนคลิกขวา) · Backspace/Delete = ถอยจุดที่คลิกล่าสุด"""
        if what == "esc":
            self.cancel_transform()
            return
        if not self.src_pts:
            self.iface.messageBar().pushMessage(
                (self.mode or "MLEP").capitalize(), "ยังไม่มีจุดให้ถอย (คลิกขวา/Esc = ยกเลิก)", level=0, duration=3)
            return
        self.src_pts.pop()
        if self.markers:
            m = self.markers.pop()
            try:
                self.iface.mapCanvas().scene().removeItem(m)
            except Exception:
                pass
        if self.src_pts:
            self._preview_hide()       # จำนวนจุดเปลี่ยน ⇒ เงาวาดใหม่ตอนขยับเมาส์
        else:
            self._preview_clear()      # ถอยถึงจุดแรก ⇒ คลิกแรกรอบหน้าจับคู่หมุด + ดึงเงาใหม่
        self._xform_step_hint()

    def _align_leftovers_clear(self):
        """★ 2.3.7 (review LC-04) — ของบนแคนวาสของ Align (ไฮไลต์หมุด · เส้นนำ · สี่เหลี่ยม snap) ที่อาจค้างจอ
        ล้างโดยไม่แตะ selection (start_interactive ต้องใช้ selection ต่อ — cancel_transform ล้าง selection ทุกชั้น)"""
        for fn in (self._align_clear_highlight, self.clear_rubber_band):
            try:
                fn()
            except Exception:
                pass
        self._align_picked_ids = set()
        _si = getattr(self, "snap_indicator", None)
        if _si is not None:
            try:
                _si.setMatch(QgsPointLocator.Match())
            except Exception:
                pass

    def start_interactive(self, mode):
        if not self._pair_key_ok("เครื่องมือขยับแปลง"):
            return
        # ★ 2.3.7 (review DI-03) — ชั้นแปลง/หมุดคนละระบบพิกัด = ขยับให้ตรงกันไม่ได้ ⇒ ไม่เริ่ม
        if not self._pair_crs_ok("เครื่องมือขยับแปลง",
                                 QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                                 QgsProject.instance().mapLayer(self.point_cb.currentData())):
            return
        # 0. ล้างเงาตัวอย่างของรอบก่อน (ต้องอยู่ก่อน early-return ข้อ 2 ไม่งั้นเงาค้างจอ)
        self._preview_clear()

        # 1. เลือก UTM ก่อน
        self.process_selection('utm')

        # 2. เช็คว่ามีอะไรถูกเลือกไหม
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_lyr or poly_lyr.selectedFeatureCount() == 0:
            # ★ 2.3.7 (review UX-35) — คำแนะนำ ไม่ใช่ความล้มเหลว ⇒ เหลือง (เดิมแดง)
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกแปลงที่ต้องการก่อน", level=1, duration=10)
            return
        # ★ 2.3.7 (review DI-10) — ผูกคู่ชั้นตอนกดปุ่ม (เครื่องมือค้าง arm ข้ามรอบได้ · ตรวจใน handle_click/execute_tool)
        _pt0 = QgsProject.instance().mapLayer(self.point_cb.currentData())
        self._xform_lids = (poly_lyr.id(), _pt0.id() if _pt0 else None)

        # 3. เคลียร์ Marker เก่า (แต่ไม่เคลียร์ Selection!)
        self.clear_markers()
        self.src_pts = []
        self._xform_sel_snap = None        # ★ 2.3.7 b17 (audit R2-D1) รอบใหม่ — จดชุดที่คลิกแรก
        
        # 4. ตั้งค่า Tool
        # ★ 2.3.7 (review LC-04) — ไฮไลต์หมุด/เส้นนำของ Align ที่ค้างจอ (ไม่แตะ selection · ตั้ง mode ใหม่แล้ว
        #   _map_tool_changed จะไม่รู้ว่าเพิ่งออกจาก Align)
        self._align_leftovers_clear()
        self.mode = mode
        self.setup_snapping()
        # ★ 2.3.7 (review UX-02) — เครื่องมือคลิกที่มีคีย์: Esc = ยกเลิก (เหมือนคลิกขวา) · Backspace/Delete = ถอยจุดล่าสุด
        #   (และกินคีย์ไว้ ไม่ให้ QGIS เอา Delete ไปลบแปลง/หมุดที่เลือกค้างอยู่)
        self.temp_tool = _EmitClickTool(self.iface.mapCanvas(), self._xform_key)
        self._xform_tool = self.temp_tool
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.temp_tool.canvasMoveEvent = self.handle_generic_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

        # 5. บอกวิธีใช้ + ขั้นต่อไป — ★ 2.3.7 (review UX-20) ข้อความเดียวค้างไว้จนเลิกใช้เครื่องมือ อัปเดตทุกคลิก
        #    (เดิมมีแค่ move/rotate/scale แบบหายเอง · Transform ไม่มีคำแนะนำเลยทั้งที่ต้องคลิก 4 จุดตามลำดับ)
        self._xform_step_hint()
        self._crs_info("เครื่องมือขยับแปลง", poly_lyr)      # ★ 2.3.7 (b9) แผนที่คนละระบบพิกัดกับชั้น = บอกเบา ๆ ครั้งเดียว

    def handle_click(self, point, button):
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return
        # ★ 2.3.7 (review DI-10) — คู่ชั้นต้องเป็นคู่เดียวกับตอนกดปุ่ม (Move/Rotate/Scale ค้าง arm ข้ามรอบได้)
        _pair = self._bound_pair_now("_xform_lids", "เครื่องมือขยับแปลง")
        if _pair is None:
            return
        poly_lyr, point_lyr = _pair
        _lyr0 = poly_lyr or point_lyr

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        
        # 2. เลือกพิกัด: ถ้า Snap ติดใช้จุด Snap ถ้าไม่ติดใช้ point (ที่ว่าง) ตรงๆ
        pt = match.point() if match.isValid() and match.point().x() != 0 else point
        # ★ 2.3.7 (review DI-03) — จุดบนแผนที่ → พิกัดของชั้น "ตอนคลิก" (src_pts เก็บเป็นพิกัดของชั้นแล้ว)
        try:
            lp = self._map_to_layer(pt, _lyr0)
        except Exception:
            self.cancel_transform()
            self.iface.messageBar().pushMessage(
                "เครื่องมือขยับแปลง", "แปลงพิกัดจุดที่คลิกเป็นระบบพิกัดของชั้นข้อมูลไม่ได้ — ยกเลิก ยังไม่ได้แก้อะไร "
                "(ตรวจระบบพิกัดของโปรเจกต์/ชั้น)", level=2, duration=10)
            return
        # ★ 2.3.7 (review DI-06) — คลิกแรกของรอบ = จับคู่หมุดใหม่จาก selection ตอนนี้
        #   เครื่องมือค้าง arm หลัง Move/Rotate/Scale ⇒ selection เปลี่ยนได้ระหว่างรอบ (ตารางแอตทริบิวต์ ฯลฯ)
        #   เดิมใช้หมุดที่เลือกค้างจากกลุ่มก่อน ⇒ ขยับแปลงใหม่พร้อมหมุดของกลุ่มเก่า (process_selection มี cache ⇒ เรียกซ้ำได้ถูก)
        if not self.src_pts:
            self.process_selection('utm')
            if self._xform_markers_only(poly_lyr, point_lyr):       # ★ 2.3.7 (audit F2) แปลงถูกล้างการเลือกระหว่างรอบ
                return
            if self._xform_nothing_selected(poly_lyr, point_lyr):   # ★ 2.3.7 b19 (doc-verify E7) ไม่มีอะไรเลือก ⇒ บอกเหตุ
                return
            if poly_lyr and point_lyr and poly_lyr.selectedFeatureCount() > 0 \
                    and point_lyr.selectedFeatureCount() == 0:
                self.iface.messageBar().pushMessage(
                    "ยกเลิก — หมุดไม่ถูกเลือกสักตัว",
                    f"เลือกแปลงไว้ {poly_lyr.selectedFeatureCount()} แปลง แต่ชั้นหมุด '{point_lyr.name()}' "
                    "ไม่มีหมุดถูกเลือกเลย ถ้าทำต่อ แปลงจะขยับไปโดยหมุดอยู่ที่เดิม — "
                    "สาเหตุที่พบบ่อย: ค่า UTM ของแปลงว่าง หรือเลือกชั้นหมุดผิดสาขา", level=1, duration=0)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                self.cancel_transform()
                return
            # ★ 2.3.7 b17 (audit R2-D1) — จดชุดแปลง+หมุดที่จับคู่แล้วของรอบนี้ (คลิกถัดไป/ตอนลงมือต้องยังเป็นชุดเดิม)
            self._xform_sel_snap = self._xform_sel_ids(poly_lyr, point_lyr)
        elif self._xform_markers_only(poly_lyr, point_lyr) or self._xform_sel_moved(poly_lyr, point_lyr):
            return          # ★ 2.3.7 b17 (audit R2-D1) — การเลือกเปลี่ยนระหว่างคลิกของรอบนี้ ⇒ ปฏิเสธแล้ว (เหลือง · ยกเลิกเครื่องมือ)
        # ★ 2.3.7 (review DI-24) — จุดควบคุมซ้อน/ชิดกันเกินไป ⇒ ไม่รับจุดนี้ (จุดก่อนหน้ายังอยู่) ให้คลิกใหม่
        _bad = self._check_control_points(self.mode, list(self.src_pts) + [lp], _lyr0)
        if _bad:
            self.iface.messageBar().pushMessage((self.mode or "MLEP").capitalize(), _bad, level=1, duration=6)
            return
        
        # กำหนดสี Marker: Snap=แดง, ที่ว่าง=น้ำเงิน
        color = QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255)

        # 3. วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setPenWidth(4)
        m.setColor(color)
        # ★ 2.3.7 (review UX-20) — Transform: ต้นทาง (①③) = กากบาท · ปลายทาง (②④) = วงกลม (เดิมกากบาทเหมือนกันทั้ง 4 จุด)
        m.setIconType(QgsVertexMarker.ICON_CIRCLE if (self.mode == 'transform' and len(self.src_pts) % 2 == 1)
                      else QgsVertexMarker.ICON_X)
        self.markers.append(m)
        self.src_pts.append(lp)            # ★ 2.3.7 (DI-03) พิกัดของชั้น (เดิม = พิกัดแผนที่)

        # 3.5 คลิกแรกของรอบ = จังหวะเตรียมเงาตัวอย่าง (ดึง geometry ครั้งเดียวจบ)
        #     ดึงตอนนี้ ไม่ใช่ตอนกดปุ่ม: selection ณ ตอนนี้คือของจริงแน่นอน
        #     (หลัง execute_tool มี restore_selection ตาม timer 100ms — กว่าคนจะคลิกใหม่ก็คืนค่าแล้ว)
        if len(self.src_pts) == 1 and not self._preview_items:
            self._preview_arm()

        # 4. ตรวจสอบจำนวนจุดตามโหมด
        limit = _CLICK_LIMIT.get(self.mode, 2)

        if len(self.src_pts) < limit:
            self._xform_step_hint()        # ★ 2.3.7 (UX-20) ขั้นต่อไป
            return
        # ★ 2.3.7 (review AR-02-D) — execute_tool ล้มด้วย exception (สแกน/อ่านชั้น/เปิดแก้ไข ฯลฯ นอก try รายชั้น)
        #   เดิม src_pts ค้างครบ 2-4 จุด ⇒ คลิกถัดไปต่อท้ายลิสต์แล้วลงมือด้วยจุดของรอบก่อน (ย้ายซ้ำ) + baseline ค้าง
        #   ⇒ รีเซ็ตทุกทางออก · ส่วนที่เขียนไปแล้ว (ถ้ามี) เก็บเป็น 1 รายการให้กด ↺ ได้
        #   ห้าม restore_selection ตรงนี้ (จะคืน selection ของรอบก่อนในทางที่ถูกปฏิเสธ)
        _b0 = self._op_baseline
        try:
            self.execute_tool()
        except Exception:
            import traceback
            QgsMessageLog.logMessage("execute_tool ล้ม: " + traceback.format_exc(), "MLEP", Qgis.Critical)
            self.iface.messageBar().pushMessage(
                "เครื่องมือขยับแปลง", "ทำงานไม่สำเร็จ (หยุดกลางคัน) — ถ้ามีส่วนที่เขียนไปแล้ว กด ↺ ย้อนกลับได้ "
                "· รายละเอียดอยู่ในแผง Log Messages แท็บ MLEP", level=2, duration=0)
        finally:
            if self._op_baseline is not None and self._op_baseline is not _b0:
                self._op_commit()
            self.src_pts = []
            self._xform_sel_snap = None    # ★ 2.3.7 b17 (audit R2-D1) จบรอบ ⇒ รอบหน้าจับคู่ + จดใหม่ที่คลิกแรก
            self.clear_markers()
            self._preview_clear()
            self._xform_step_hint()        # ★ 2.3.7 (UX-20) ค้าง arm ⇒ กลับขั้นแรก · ออกจากเครื่องมือแล้ว = เอาข้อความออก
            
    def _xform_markers_only(self, poly_lyr, point_lyr):
        """★ 2.3.7 (audit F2 · P1) — Move/Rotate/Scale/Transform ค้าง arm ข้ามรอบ ⇒ ระหว่างรอบการเลือก "แปลง" ถูกล้างได้
        โดยเครื่องมือไม่เปลี่ยน (Ctrl+Shift+A ตอนชั้นแปลง active · Deselect ในตารางแอตทริบิวต์) แต่หมุดยังเลือกค้าง
        ⇒ เดิมรอบถัดไปขยับแต่หมุด (แปลงอยู่ที่เดิม = มุมเปลือย + หมุดลอยทั้งกลุ่ม · ผู้ตรวจ p05)
        ⇒ หมุดเลือกอยู่แต่แปลงไม่ได้เลือก = ปฏิเสธก่อนเขียน + ยกเลิกเครื่องมือ · คืน True = ปฏิเสธแล้ว (ผู้เรียกต้องหยุด)"""
        try:
            if not (poly_lyr and point_lyr):
                return False
            n = point_lyr.selectedFeatureCount()
            if n == 0 or poly_lyr.selectedFeatureCount() > 0:
                return False
            _pn, _tn = poly_lyr.name(), point_lyr.name()
        except Exception:
            return False
        self.iface.messageBar().pushMessage(
            "ยกเลิก — แปลงไม่ถูกเลือก",
            f"ชั้นหมุด '{_tn}' มีหมุดเลือกค้างอยู่ {n:,} ดวง แต่ชั้นแปลง '{_pn}' ไม่มีแปลงถูกเลือก "
            "(การเลือกแปลงถูกล้างระหว่างรอบ) ถ้าทำต่อ หมุดจะขยับไปโดยแปลงอยู่ที่เดิม — ยังไม่ได้แก้อะไร "
            "· เลือกแปลงแล้วกดปุ่มเครื่องมือใหม่", level=1, duration=10)
        self.cancel_transform()
        return True

    def _xform_nothing_selected(self, poly_lyr, point_lyr):
        """★ 2.3.7 b19 (doc-verify E7) — เครื่องมือค้าง arm แต่ไม่มีแปลง (และหมุด) ถูกเลือกเลย (การเลือกถูกล้างหลังกดปุ่ม/หลังรอบก่อน
        · Ctrl+Shift+A · Deselect ในตารางแอตทริบิวต์) ⇒ เดิมคลิกแรกรับเงียบ คลิกที่สองเครื่องมือหลุดเงียบ (execute_tool: ไม่มีชั้นที่เลือก
        ⇒ cancel_transform ไม่มีข้อความ) ⇒ บอกเหตุ (เหลือง) + ยกเลิกเครื่องมือ · คืน True = ปฏิเสธแล้ว (ผู้เรียกต้องหยุด)
        หมุดเลือกค้างแต่แปลงไม่ได้เลือก = กรณีของ _xform_markers_only (ตรวจก่อน)"""
        try:
            if poly_lyr is not None and poly_lyr.selectedFeatureCount() > 0:
                return False
            if point_lyr is not None and point_lyr.selectedFeatureCount() > 0:
                return False
        except Exception:
            return False
        self.iface.messageBar().pushMessage(
            "ยกเลิก — ไม่มีแปลงที่เลือก",
            "ไม่มีแปลงถูกเลือกอยู่ (การเลือกถูกล้างไปแล้ว) — ยังไม่ได้แก้อะไร · เลือกแปลงแล้วกดปุ่มเครื่องมือใหม่",
            level=1, duration=8)
        self.cancel_transform()
        return True

    def _xform_sel_ids(self, poly_lyr, point_lyr):
        """★ 2.3.7 b17 (audit R2-D1) — ชุด id ที่เลือกอยู่ (แปลง, หมุด) · อ่านไม่ได้ = None (ถือว่าเปลี่ยน ⇒ ปฏิเสธ)"""
        try:
            return (frozenset(poly_lyr.selectedFeatureIds()) if poly_lyr else frozenset(),
                    frozenset(point_lyr.selectedFeatureIds()) if point_lyr else frozenset())
        except Exception:
            return None

    def _xform_sel_moved(self, poly_lyr, point_lyr):
        """★ 2.3.7 b17 (audit R2-D1 · ต่อจาก F2) — การเลือกแปลง/หมุด "เปลี่ยน" ระหว่างคลิกของรอบเดียว (เลือกแปลงอื่นในตารางแอตทริบิวต์
        · ขยายการเลือก · Ctrl+A ทั้งชั้น · ยกเลิกหมุดบางดวง) ⇒ เดิมลงมือกับชุดใหม่ทั้งที่จับคู่หมุดไว้กับชุดเดิมตอนคลิกแรก
        ⇒ แปลงกับหมุดขยับแยกกัน (ผู้ตรวจ r03 S2: เลือก B แทน A = มุมเปลือย 8 หมุดลอย 8 · Ctrl+A = ทั้งสาขาขยับพร้อมหมุดของ A อย่างเดียว)
        ⇒ ชุดตอนนี้ ≠ ชุดที่จดตอนคลิกแรก = ปฏิเสธก่อนเขียน (เหลือง) + ยกเลิกเครื่องมือ · ไม่จับคู่ใหม่เงียบ ๆ (เงาตัวอย่างเป็นของชุดเดิม)
        ไม่ได้จด (เรียกตรงจากโค้ด/เทส · ยังไม่ถึงคลิกแรก) ⇒ ไม่ตรวจ · คืน True = ปฏิเสธแล้ว (ผู้เรียกต้องหยุด)"""
        snap = getattr(self, "_xform_sel_snap", None)
        if snap is None:
            return False
        if self._xform_sel_ids(poly_lyr, point_lyr) == snap:
            return False
        self.iface.messageBar().pushMessage(
            "ยกเลิก — การเลือกเปลี่ยนระหว่างคลิก",
            "แปลงหรือหมุดที่เลือกถูกเปลี่ยนหลังคลิกจุดแรก (เช่น เลือก/ยกเลิกการเลือกในตารางแอตทริบิวต์) "
            "ถ้าทำต่อ แปลงกับหมุดจะขยับไม่ตรงกัน — ยังไม่ได้แก้อะไร · เลือกแปลงแล้วกดปุ่มเครื่องมือใหม่", level=1, duration=10)
        self.cancel_transform()
        return True

    def handle_generic_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือทั่วไป (แก้ไข Error) + ขยับเงาตัวอย่าง Move/Rotate/Scale"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return

        match = self.snap_utils.snapToMap(event.mapPoint())
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            # แทนที่จะใส่ None ให้ใช้ Match ว่างๆ แทนครับ
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # จุดของเงา = สูตรเดียวกับ handle_click เป๊ะ (รวม .x() != 0) -> เงาอยู่ตรงที่คลิกจะลงจริง
        pt = match.point() if match.isValid() and match.point().x() != 0 else event.mapPoint()
        self._preview_update(QgsPointXY(pt.x(), pt.y()))

    # ============ เงาตัวอย่าง (preview) ของ Move/Rotate/Scale ============
    def _preview_arm(self):
        """เตรียมเงาของรอบนี้: ดึง geometry ที่เลือก "ครั้งเดียว" + สร้าง rubber band ต่อเลเยอร์

        เก็บ geom เป็น CRS ของเลเยอร์ดิบๆ — ★ 2.3.7 (DI-03) จุดคลิก/เมาส์ถูกแปลงเป็นพิกัดของชั้นก่อนคำนวณ
        ทั้งในเงาและใน execute_tool (สูตรเดียวกัน) — เงาต้องเหมือนของจริงเป๊ะ (ดู _preview_geom)
        ห้ามย้ายการดึงนี้ไปไว้ใน mouse-move: บน PostgreSQL = 1 query ต่อเฟรมต่อเลเยอร์
        ซึ่งเป็นปัญหาที่ 1.7.0 เพิ่งไล่แก้ทั้งรุ่น"""
        self._preview_clear()
        if self.mode not in _PREVIEW_MODES:
            return
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in (poly_lyr, point_lyr) if l and l.selectedFeatureCount() > 0]
        if not layers:
            return

        # แปลงล็อกตัดจบตั้งแต่คลิกแรก: execute_tool ปฏิเสธ L1-RTK/L1-TS แน่นอนอยู่แล้ว
        # -> โชว์เงาว่าขยับได้ทั้งที่สุดท้ายมันไม่ขยับ = เงาโกหก จึงไม่โชว์แล้วบอกเหตุผลไปเลย
        # (แค่บอกล่วงหน้า ไม่บล็อก — คนตัดสินใจจริงยังเป็น execute_tool เหมือนเดิมทุกประการ)
        locked = self._preview_locked_type(poly_lyr)
        if locked and not self._l1_unlocked():          # ★ admin: โชว์เงา preview ได้ตามปกติ
            self.iface.messageBar().pushMessage(
                "MLEP Lock",
                f"แปลงที่เลือกมีประเภท {locked} ซึ่งเป็นพิกัดอ้างอิง ขยับไม่ได้ — "
                "จะไม่มีเงาตัวอย่างให้ (คลิกครบจุดแล้วระบบจะปฏิเสธ)", level=1, duration=8)
            return

        canvas = self.iface.mapCanvas()
        srcs, total = [], 0
        for lyr in layers:
            # request ชุดเดียวกับ execute_tool -> เงาครอบ feature ชุดเดียวกับที่จะถูกแก้จริง
            req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
            parts = []
            for f in lyr.getFeatures(req):
                g = f.geometry()
                if g.isNull():
                    continue                    # ข้ามแบบเดียวกับ execute_tool
                # แตก multipart ให้เหลือชิ้นเดี่ยวล้วน -> ของที่ส่งเข้า collectGeometry ชนิดเดียวกันหมด
                parts.extend(g.asGeometryCollection() if g.isMultipart() else [QgsGeometry(g)])
            if not parts:
                continue
            # รวมเป็นก้อนเดียวต่อเลเยอร์ -> ต่อเฟรมเรียก C++ ครั้งเดียว ไม่ว่าจะเลือกกี่แปลง
            coll = QgsGeometry.collectGeometry(parts)
            if coll is None or coll.isNull():
                continue
            # OPT (2026-08-07): นับด้วย C++ ครั้งเดียว แทนวน python ทีละ vertex
            # ★ 2.4.0 (review PF-10) — นับเฉพาะชั้นที่งบนี้ย่อได้ (ชั้นแปลง ⇒ convex hull ข้างล่าง)
            #   เดิมรวม vertex ของชั้นหมุดด้วย ทั้งที่หมุดไม่เคยถูกย่อ ⇒ เงาแปลงกลายเป็นกรอบรวมเร็วกว่าที่ตั้งใจ (~1,950 แทน ~3,550 แปลง)
            if lyr.geometryType() == QgsWkbTypes.PolygonGeometry:
                try:
                    total += coll.constGet().nCoordinates()
                except Exception:
                    total += sum(1 for _ in coll.vertices())
            srcs.append((lyr, coll))

        # เลือกทั้งระวางแล้ว vertex บานปลาย -> ย่อเฉพาะ "ชั้นแปลง" เป็นกรอบรวม (convex hull)
        # ชั้นหมุดไม่ย่อ: 1 หมุด = 1 vertex ไม่ใช่ต้นเหตุความหน่วง และ hull ของหมุดจะกลายเป็นแผ่นทึบ
        heavy = total > _PREVIEW_VERTEX_BUDGET
        self._preview_heavy = heavy
        for lyr, coll in srcs:
            src = (coll.convexHull() if heavy and lyr.geometryType() == QgsWkbTypes.PolygonGeometry
                   else coll)
            if src is None or src.isNull():
                continue
            gtype = src.type()          # อ่านชนิดจาก geometry ตรงๆ -> band กับของที่ใส่ตรงกันเสมอ
            # ฟ้า (cyan) = สีเดียวที่ยังว่าง (แดง=Snap/DOL • น้ำเงิน=คลิกที่ว่าง • เหลือง=hover
            #  • แดงเข้ม=ล็อก • เขียว=เลือกแล้ว • ส้ม=vertex • ม่วง=snap หมุด)
            rb = QgsRubberBand(canvas, gtype)
            rb.setColor(QtGui.QColor(0, 200, 200))
            rb.setFillColor(QtGui.QColor(0, 200, 200, 45))
            rb.setWidth(2)
            if gtype == QgsWkbTypes.PointGeometry:
                rb.setIcon(QgsRubberBand.ICON_X)    # กากบาทให้เข้าชุดกับ Marker ตอนคลิก
                rb.setIconSize(8)
            rb.show()
            self._preview_items.append((lyr, src, rb, gtype))

        # จดว่าเงารอบนี้เป็นของเครื่องมือตัวไหน — ต้องอยู่หลัง setMapTool ของ start_interactive
        # (ตอนนี้ถูกเรียกจากคลิกแรกอยู่แล้ว จึงพ้นจังหวะนั้นแน่นอน) ดู _map_tool_changed
        if self._preview_items:
            self._preview_tool = self.temp_tool

        # ★ 2.3.7 (review DI-03) — เลิกเตือน 15 วิ "เลเยอร์กับโปรเจกต์คนละระบบพิกัด" แล้ว: จุดคลิก/เมาส์ถูกแปลงเป็น
        #   พิกัดของชั้นทั้งในเงาและของจริง (ของจริงเคยเหวี่ยงไปหลายร้อยกม. ตอนโปรเจกต์เป็น 4326 ทั้งที่เตือนแค่แถบเหลือง)

    def _preview_locked_type(self, poly_lyr):
        """คืน 'L1-RTK' / 'L1-TS' ถ้าแปลงที่เลือกมีตัวที่ถูกล็อก • '' ถ้าไม่มี
        คิวรีเดียว NoGeometry ชุดเดียวกับ execute_tool — ยิงตอนคลิกแรกเท่านั้น ไม่ใช่ทุกเฟรม"""
        if not poly_lyr:
            return ""
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        ids = poly_lyr.selectedFeatureIds()
        if type_idx == -1 or not ids:
            return ""
        req = (QgsFeatureRequest().setFilterFids(ids)
               .setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([type_idx]))
        found = ""
        _fit2885 = poly_lyr.getFeatures(req)
        try:
            for f in _fit2885:
                # ★ 2.4.0 (review DU-01-followup) — ชนิดล็อกจาก lock_rules (เดิมพิมพ์สตริง L1-RTK / L1-TS เอง) · NULL-safe
                v = norm_type(f.attribute(type_idx))
                if not is_l1_type(v):
                    continue
                if v == L1_TYPES[0]:
                    return v            # L1-RTK เข้มสุด -> ตัดจบเลย
                found = v
        finally:
            _fit2885.close()
        return found

    def _preview_geom(self, src, cur):
        """คำนวณ geometry ของเงา 1 ก้อน: copy จาก src แล้วแปลงตามตำแหน่งเมาส์ cur

        สูตรทุกบรรทัดลอกจาก execute_tool มาทั้งดุ้น — ตั้งใจให้เหมือนของจริงทุกกรณี ถ้าของจริงเพี้ยน เงาต้องเพี้ยนตาม
        ไม่งั้นเงาจะโกหกว่าผลลัพธ์จะออกมาดี · ★ 2.3.7 (DI-03) cur และ src_pts เป็นพิกัดของชั้นแล้ว (แปลงตอนคลิก/ขยับเมาส์)"""
        p = self.src_pts
        g = QgsGeometry(src)   # copy ก่อนแตะ — QgsGeometry เป็น copy-on-write ต้นฉบับใน cache ไม่กระทบ

        # --- 1. Move ---
        if self.mode == 'move':
            g.translate(cur.x() - p[0].x(), cur.y() - p[0].y())

        # --- 2. Rotate (ลบหน้ามุมตามของจริง) ---
        #     ห้ามแก้เครื่องหมาย และห้ามเขียนใหม่ด้วย QTransform:
        #     QgsGeometry.rotate บวก = ตามเข็ม แต่ QTransform.rotate บวก = ทวนเข็ม (ตรงข้ามกัน)
        #     -> ถ้าเปลี่ยนมาใช้ QTransform โดยไม่พลิกเครื่องหมาย เงาจะหมุนกลับทางกับของจริง
        elif self.mode == 'rotate':
            a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
            a2 = math.atan2(cur.y()-p[0].y(), cur.x()-p[0].x())
            g.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))

        # --- 3. Scale ---
        elif self.mode == 'scale':
            d1 = math.sqrt(p[0].sqrDist(p[1]))
            d2 = math.sqrt(p[0].sqrDist(cur))
            if d1 > 0:      # d1 == 0 -> ของจริงข้าม changeGeometry ทั้งก้อน -> เงาต้องนิ่งที่เดิม
                s = d2 / d1
                # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                g.translate(-p[0].x(), -p[0].y())
                matrix = QtGui.QTransform(); matrix.scale(s, s)
                g.transform(matrix)
                g.translate(p[0].x(), p[0].y())
                # s == 0 (เมาส์ทับ p0) ของจริงยุบแปลงเป็นจุด -> เงาต้องยุบตาม ห้ามใส่ guard เพิ่ม
        return g

    def _preview_update(self, cur):
        """ขยับเงาตามเมาส์ — ถูกเรียกทุกเฟรม
        ห้ามยิง query และห้ามเรียก canvas.refresh() ในนี้ (rubber band วาดตัวเองอยู่แล้ว)
        ใช้แต่ geometry ที่ cache ไว้ตอน _preview_arm"""
        if not self._preview_items:
            return                       # ยังไม่คลิกแรก / โหมดไม่มีเงา / แปลงล็อก
        need = _CLICK_LIMIT.get(self.mode, 2) - 1
        if self.mode not in _PREVIEW_MODES or len(self.src_pts) != need:
            self._preview_hide()         # คลิกยังไม่พอ -> ไม่มีเงา
            return
        # snap ดูดในรัศมี 20 px -> เมาส์ขยับหลายพิกเซลแล้วได้จุดเดิม ไม่ต้องวาดซ้ำ
        key = (self.mode, cur.x(), cur.y())
        if key == self._preview_last:
            return
        # ★ 2.3.7 (review DI-03) — เมาส์อยู่ในพิกัดแผนที่ → พิกัดของชั้น (สูตรเดียวกับจุดที่คลิกใน handle_click)
        _l0 = self._preview_items[0][0]
        try:
            cur = self._map_to_layer(cur, _l0)
        except Exception:
            self._preview_hide()
            return
        # ★ 2.3.7 (review DI-24) — ตำแหน่งนี้ทำให้จุดควบคุมซ้อน ⇒ ของจริงจะไม่รับจุดนี้ ⇒ ไม่โชว์เงายุบ บอกเหตุที่แถบสถานะแทน
        _bad = self._check_control_points(self.mode, list(self.src_pts) + [cur], _l0)
        if _bad:
            self._preview_hide()
            try:
                self.iface.statusBarIface().showMessage(f"{(self.mode or '').capitalize()}: {_bad}")
            except Exception:
                pass
            return
        self._preview_last = key
        for lyr, src, rb, _gt in self._preview_items:
            # ส่ง lyr เข้าไปด้วย -> band แปลง CRS เลเยอร์->จอ แบบเดียวกับที่ renderer ทำตอน commit
            rb.setToGeometry(self._preview_geom(src, cur), lyr)
        self._preview_msg(cur)

    def _preview_hide(self):
        """ซ่อนเงาชั่วคราว (คลิกยังไม่ครบ) โดยไม่ทิ้ง band/cache -> ไม่ต้องดึง geometry ใหม่
        _preview_last is None = ไม่มีเงาบนจออยู่แล้ว -> ออกเลย (กันทำงานซ้ำทุกเฟรมก่อนคลิกแรก)"""
        if self._preview_last is None:
            return
        for _lyr, _src, rb, gt in self._preview_items:
            try:
                rb.reset(gt)
            except Exception:
                pass
        self._preview_last = None
        self._preview_msg(None)

    def _preview_clear(self):
        """ลบเงาออกจากจอ + ทิ้ง cache — เรียกซ้ำได้เสมอ ปลอดภัยแม้ยังไม่เคยมีเงา
        ไม่แตะ layer ที่ cache ไว้เลย (แตะแค่ rubber band) -> เรียกตอนเลเยอร์ถูกลบไปแล้วก็ปลอดภัย"""
        had = bool(getattr(self, "_preview_items", [])) or self._preview_last is not None
        for _lyr, _src, rb, _gt in getattr(self, "_preview_items", []):
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
        self._preview_items = []
        self._preview_last = None
        self._preview_tool = None
        self._preview_heavy = False
        # ล้างแถบสถานะเฉพาะตอนที่เราเคยเขียนไว้จริง — สลับเครื่องมือตอนไม่ได้ใช้ปลั๊กอิน
        # ไม่ควรไปลบข้อความของ QGIS/ปลั๊กอินอื่นที่ค้างอยู่
        if had:
            self._preview_msg(None)

    def _preview_msg(self, cur):
        """ตัวเลขกำกับเงา (ระยะ/มุม/สเกล) -> แถบสถานะ • cur=None = ล้างข้อความ
        ไม่ใช้ message bar เพราะจะเด้ง widget ใหม่ทุกเฟรม — bar สงวนไว้ให้ตอนคลิก/จบงาน/error"""
        try:
            bar = self.iface.statusBarIface()
            if bar is None:
                return
            p = self.src_pts
            txt = ""
            if cur is None:
                pass
            elif self.mode == 'move' and len(p) >= 1:
                txt = f"Move: เลื่อน {math.sqrt(p[0].sqrDist(cur)):.3f} ม."
            elif self.mode == 'rotate' and len(p) >= 2:
                a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                a2 = math.atan2(cur.y()-p[0].y(), cur.x()-p[0].x())
                deg = (math.degrees(a2 - a1) + 180) % 360 - 180   # คุมช่วงเป็น -180..180 อ่านง่าย
                txt = f"Rotate: หมุน {deg:+.4f}° (+ = ทวนเข็มนาฬิกา)"
            elif self.mode == 'scale' and len(p) >= 2:
                d1 = math.sqrt(p[0].sqrDist(p[1]))
                d2 = math.sqrt(p[0].sqrDist(cur))
                txt = (f"Scale: สเกล {d2/d1:.6f} ({d1:.3f} → {d2:.3f} ม.)" if d1 > 0
                       else "Scale: จุดอ้างอิงทับจุดหมุน — ปรับสเกลไม่ได้ (คลิกขวา = ยกเลิก)")
            # เงาถูกย่อ -> บอกไปตรงๆ ไม่งั้นผู้ใช้เห็นกรอบแทนแปลงแล้วนึกว่าเสีย
            if txt and self._preview_heavy:
                txt += "  •  เงาย่อเป็นกรอบรวม (แปลงเยอะ) — ผลจริงยังแก้ครบทุกแปลง"
            bar.showMessage(txt)
        except Exception:
            pass   # แถบสถานะเป็นของแถม — หายไปได้ ขอแค่เงายังทำงาน

    def execute_tool(self):
        # ★ 2.3.7 (review DI-10) — คู่ชั้นต้องเป็นคู่ที่ผูกไว้ตอนกดปุ่ม (ตรวจซ้ำตรงนี้เพราะเครื่องมือค้าง arm ข้ามรอบ)
        _pair = self._bound_pair_now("_xform_lids", "เครื่องมือขยับแปลง")
        if _pair is None:
            return
        poly_lyr, point_lyr = _pair
        # ★ 2.3.7 (review DI-03) — สองชั้นต้องระบบพิกัดเดียวกัน (จุดใน src_pts เป็นพิกัดของชั้นแล้ว)
        if not self._pair_crs_ok("เครื่องมือขยับแปลง", poly_lyr, point_lyr):
            self.cancel_transform()
            return
        # ★ 2.3.7 (review DI-24 / DI-28) — จุดควบคุมซ้อน/ชิดกันเกินไป ⇒ ปฏิเสธก่อนเปิดคำสั่งแก้ไขใด ๆ
        #   (เครื่องมือยังค้าง arm + selection เดิม ⇒ คลิกใหม่ได้ทันที · Scale d1==0 ไม่เหลือคำสั่งแก้ไขเปล่าแล้ว)
        _bad = self._check_control_points(self.mode, self.src_pts, poly_lyr or point_lyr)
        if _bad:
            self.iface.messageBar().pushMessage((self.mode or "MLEP").capitalize(), _bad, level=1, duration=8)
            self.src_pts = []
            self.clear_markers()
            self._preview_clear()
            return
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        # ★ 28 ส.ค. 69 (audit 2.2) — ด่านเทียบ "สิ่งที่เลือก" สองชั้นก่อนเขียน
        #   เดิมชั้นที่ selection ว่างจะหลุดจาก layers "เงียบ ๆ" แล้วขยับอีกชั้นฝ่ายเดียว
        #   จนจบฟังก์ชันก็ไม่มีข้อความใด ๆ -> ผู้ใช้ไม่มีทางรู้ว่าหมุดไม่ได้ตามไป
        #   (ปกติ process_selection('utm') เลือกให้ครบทั้งสองชั้นอยู่แล้ว ถ้ามาถึงตรงนี้แล้วยังไม่ครบ
        #    แปลว่ามีอะไรผิดปกติ เช่น UTM เป็น NULL หรือคู่เลเยอร์ผิดสาขา -> ต้องหยุด ไม่ใช่เดินต่อ)
        if self.mode in ('move', 'rotate', 'scale', 'transform') and poly_lyr and point_lyr:
            if self._xform_markers_only(poly_lyr, point_lyr):       # ★ 2.3.7 (audit F2) ด่านซ้ำก่อนเขียน
                return
            if self._xform_sel_moved(poly_lyr, point_lyr):          # ★ 2.3.7 b17 (audit R2-D1) ชุดต้องเป็นชุดที่จับคู่ตอนคลิกแรก
                return
            _np, _nt = poly_lyr.selectedFeatureCount(), point_lyr.selectedFeatureCount()
            if _np > 0 and _nt == 0:
                self.iface.messageBar().pushMessage(
                    "ยกเลิก — หมุดไม่ถูกเลือกสักตัว",
                    f"เลือกแปลงไว้ {_np} แปลง แต่ชั้นหมุด '{point_lyr.name()}' ไม่มีหมุดถูกเลือกเลย "
                    "ถ้าทำต่อ แปลงจะขยับไปโดยหมุดอยู่ที่เดิม (ผิดกติกาทุก node ต้องมีหมุด) — "
                    "สาเหตุที่พบบ่อย: ค่า UTM ของแปลงว่าง หรือเลือกชั้นหมุดผิดสาขา",
                    level=1, duration=0)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                self.cancel_transform()
                return
        
        if not layers:
            # ★ 2.3.7 b19 (doc-verify E7) — เดิมยกเลิกเงียบ ๆ (เครื่องมือหลุดโดยไม่บอกเหตุ) ⇒ บอกเหตุแล้วยกเลิก
            if not self._xform_nothing_selected(poly_lyr, point_lyr):
                self.cancel_transform()
            return
            
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self.last_layers = layers
        p = self.src_pts

        # ★ OPT (2026-08-07): ผลของ "P2/P4 อยู่บน node ของแปลง L1-RTK ไหม" ไม่ขึ้นกับ feature ที่วนอยู่
        #   (p[1]/p[3] คงที่ทั้ง operation) แต่เดิมถูกเรียกซ้ำ "ในลูป" ทั้งฝั่งแปลงและฝั่งหมุด
        #   -> ยิง setFilterRect เข้า PostGIS 2 ครั้ง/feature · กลุ่ม 50 แปลง+300 หมุด ≈ 700 round-trip
        #   คิดครั้งเดียวแบบ lazy (คิดต่อเมื่อเจอเคส L1-TS จริง) แล้วใช้ซ้ำ
        _rtk_ok_cache = {}
        _ts_exc = {}             # ★ rc1 (F6) ใช้ข้อยกเว้น L1-TS (Transform 2 จุดไปต่อ L1-RTK) ในงานนี้ ⇒ จดงานให้ด่านตอนบันทึกไม่ถาม
        #   {layer id: {fid}} — ★ rc1 S5 (review R3-01) จดเฉพาะฟีเจอร์ที่ผ่านข้อยกเว้นจริง (_op_begin l1_only)

        def _rtk_ends_ok():
            """P2 และ P4 อยู่บน node ของแปลง L1-RTK ทั้งคู่ไหม (คิดครั้งเดียวต่อ operation)"""
            if 'v' not in _rtk_ok_cache:
                try:
                    _rtk_ok_cache['v'] = bool(
                        len(p) >= 4
                        and self._is_point_on_rtk_node(poly_lyr, p[1])
                        and self._is_point_on_rtk_node(poly_lyr, p[3]))
                except Exception:
                    _rtk_ok_cache['v'] = False
            return _rtk_ok_cache['v']

        # ─── ตรวจสอบกฎการล็อกแปลง L1-RTK / L1-TS ───
        if poly_lyr:
            type_idx = self._field_index(poly_lyr.fields(), 'type')
            if type_idx != -1:
                poly_ids = poly_lyr.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    _fit3068 = poly_lyr.getFeatures(req_type)
                    try:
                        for f in _fit3068:
                            # ★ 2.4.0 (review DU-01-followup) — ชนิดล็อกจาก lock_rules (is_l1_type · NULL-safe) แทนสตริงที่พิมพ์เอง
                            #   คงแยก L1-RTK (ห้ามเด็ดขาด) กับ L1-TS (ยกเว้น Transform 2 จุดไปต่อ L1-RTK) ไว้ตามเดิมโดยตั้งใจ
                            val_str = norm_type(f.attribute(type_idx))
                            # ★ admin ปลดล็อก L1: ข้ามด่านล็อกแปลง polygon ทั้งก้อน (เดิมเช็ก admin เฉพาะฝั่งหมุด 1670)
                            if is_l1_type(val_str) and not self._l1_unlocked():
                                if val_str == "L1-RTK":
                                    self.iface.messageBar().pushMessage(
                                        "MLEP Lock", 
                                        f"{self._feat_label(poly_lyr, f)} เป็นประเภท L1-RTK ซึ่งเป็นพิกัดอ้างอิงหลัก "
                                        "ไม่สามารถขยับได้!",              # ★ 2.3.7 (review ER-06) เดิมบอกด้วย fid
                                        level=1, duration=10     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                                    )
                                    self.cancel_transform()
                                    return
                                else:                    # L1-TS
                                    # ยกเว้นกรณีใช้ปุ่ม transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                                    if self.mode == 'transform' and _rtk_ends_ok():
                                        _ts_exc.setdefault(poly_lyr.id(), set()).add(f.id())
                                        continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                                        
                                    self.iface.messageBar().pushMessage(
                                        "MLEP Lock", 
                                        f"{self._feat_label(poly_lyr, f)} เป็นประเภท L1-TS ไม่สามารถขยับได้ "
                                        "ยกเว้นใช้โหมด Transform (2 Pts) ไปต่อกับ L1-RTK เท่านั้น!",   # ★ 2.3.7 ER-06
                                        level=1, duration=10     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                                    )
                                    self.cancel_transform()
                                    return
                    finally:
                        _fit3068.close()

        # ตรวจสอบสิทธิ์การขยับพิกัดผ่านจุดหมุด (กรณีจุดหมุดถูกเลือก)
        # ★ 2.4.0 (review DU-01) — ไม่มีชั้นแปลงก็ยังตรวจ Type ของหมุดเอง (ตาราง UTM ล็อก = {})
        if point_lyr and point_lyr.selectedFeatureCount() > 0:
            # ตาราง UTM ล็อกทั้งหมดในคิวรีเดียว (เดิม query ต่อค่า UTM — N round-trips บน PostgreSQL)
            locked_map = (self._locked_map_or_block(poly_lyr, "MLEP Lock")    # ★ 2.3.7 fail-closed (PF-01)
                          if poly_lyr else {})
            if locked_map is None:
                self.cancel_transform()
                return
            # ★ ดึงเฉพาะคอลัมน์ UTM ไม่เอา geometry — เช็ค lock ใช้แค่ค่า UTM
            #   (เดิม selectedFeatures() ดึงทุก attribute + geometry ของทุกหมุดที่เลือก)
            # ★ 2.4.0 (review DU-01) — + คอลัมน์ Type ของหมุด (กติกาเดียว _marker_locked) · ไม่มีแปลง L1 ในชั้นก็ยังต้องตรวจ
            #   (เดิมข้ามทั้งด่านเมื่อตาราง UTM ล็อกว่าง ⇒ หมุด Type L1 ที่ UTM ไม่ตรงแปลง L1 ใดย้ายได้) · ปลดล็อกอยู่ = ไม่ต้องอ่าน
            _sel_ids = point_lyr.selectedFeatureIds() if not self._l1_unlocked() else []
            _ureq = QgsFeatureRequest().setFilterFids(_sel_ids).setFlags(QgsFeatureRequest.NoGeometry)
            _uf = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            _ui = point_lyr.fields().indexOf(_uf) if _uf else -1
            _ti = self._field_index(point_lyr.fields(), 'type')
            _ureq.setSubsetOfAttributes([i for i in (_ui, _ti) if i >= 0])
            _fit3107 = point_lyr.getFeatures(_ureq) if _sel_ids else None
            try:
                for pt_f in (_fit3107 if _fit3107 is not None else []):
                    is_locked, type_str = self._marker_locked(pt_f, locked_map, _uf, _ti)
                    if is_locked:
                        # ข้อยกเว้นเฉพาะโหมด transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                        if type_str == "L1-TS" and self.mode == 'transform' and _rtk_ends_ok():
                            _ts_exc.setdefault(point_lyr.id(), set()).add(pt_f.id())
                            continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                            # (★ 2.3.7 review ER-06 — ลบบล็อกข้อความที่อยู่หลัง continue ซึ่งไม่มีวันทำงาน)
                        else:
                            # ★ 2.4.0 (review DU-01 รอบตรวจทาน) — บอกเหตุให้ตรงกติกาที่ทำให้ล็อก (เดิม "เป็นหมุด X หรือหมุดของแปลง X")
                            #   Type ของตัวหมุดเองเป็น L1 ⇒ "เป็นหมุด X" · ไม่งั้น (UTM ตรงแปลง L1) ⇒ "เป็นหมุดของแปลง X (UTM …)"
                            _own = norm_type(pt_f.attribute(_ti)) if _ti >= 0 else ""
                            # ★ rc1 (F8 · §5.1 DU-01 ต่อ) — หมุด Type L1-TS ที่ UTM ตรงแปลง L1-RTK: ที่ล็อกคือแปลง L1-RTK
                            #   (เดิมบอก "เป็นหมุด L1-TS" ⇒ ดูขัดกับหมุด L1-TS อื่นที่ Transform 2 จุดขยับได้) ⇒ ใช้ถ้อยคำฝั่ง UTM
                            if _own in L1_TYPES and not (type_str == "L1-RTK" and _own != "L1-RTK"):
                                _why = f"เป็นหมุด {_own}"
                            else:
                                _uk = _txt(pt_f[_uf]) if _uf else ""
                                _why = f"เป็นหมุดของแปลง {type_str}" + (f" (UTM {_uk})" if _uk else "")
                            self.iface.messageBar().pushMessage(
                                "MLEP Lock",
                                f"{self._feat_label(point_lyr, pt_f)} {_why} "
                                "ซึ่งถูกล็อกขยับ!",                # ★ 2.3.7 (review ER-06) เดิมบอกด้วย fid · ★ 2.4.0 (DU-01) รวมหมุดที่ Type เป็น L1
                                level=1, duration=10     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                            )
                            self.cancel_transform()
                            return
            finally:
                if _fit3107 is not None:
                    _fit3107.close()

        # เปิด edit ทั้งเลเยอร์แปลง+หมุดที่ตั้งค่าไว้ แยกจากเงื่อนไข selection
        # (แก้: บางทีหมุดไม่ถูกเลือก -> point layer ไม่ขึ้น edit)
        # ★ fail-closed (2026-08-06): เดิมไม่เช็คผล startEditing -> เลเยอร์ที่เปิดแก้ไม่ได้
        #   (สิทธิ์ไม่พอ/read-only) จะเงียบ แล้วอีกเลเยอร์ถูกแก้ฝ่ายเดียว = แปลงกับหมุดหลุดคู่กัน
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — ผ่าน _ensure_editing (ตรวจ isEditable ซ้ำ · Log Warning พร้อมเหตุจาก provider)
        #   เดิมเชื่อค่าที่ startEditing() คืน ⇒ ชั้นใน transaction group ที่คืน True แต่ไม่เข้าโหมดแก้ไข ไหลไปถึงกล่อง "แก้รูปไม่สำเร็จ"
        for _l in (poly_lyr, point_lyr):
            if not _l or self._ensure_editing(_l, title="MLEP", warn=False,
                                              what="ยกเลิกทั้งงาน" if _l in layers else "ไม่มีสิ่งที่เลือกในชั้นนี้"):
                continue
            if _l in layers:                 # เลเยอร์ที่ "จะถูกเขียนจริง" -> เปิดไม่ได้ = หยุดทั้งงาน
                self.iface.messageBar().pushMessage(
                    "MLEP Error",
                    f"เปิดโหมดแก้ไข '{_l.name()}' ไม่ได้ (สิทธิ์ไม่พอ / เลเยอร์อ่านอย่างเดียว) "
                    "— ยกเลิกทั้งงาน เพื่อไม่ให้แปลงกับหมุดหลุดคู่กัน", level=2, duration=0)
                self.cancel_transform()
                return
            # ★ เลเยอร์ที่ไม่มีอะไรถูกเลือก = ไม่ถูกเขียนอยู่แล้ว -> แค่เตือน ไม่บล็อกงาน
            #   (release gate: เดิมบล็อกทั้ง gesture ทั้งที่เลเยอร์นั้นไม่เกี่ยวข้องเลย)
            self.iface.messageBar().pushMessage(
                "MLEP", f"เปิดโหมดแก้ไข '{_l.name()}' ไม่ได้ (ไม่มีสิ่งที่เลือกในชั้นนี้ จึงทำงานต่อได้)",
                level=1, duration=6)

        # ★ rc1 2.4.0 (F6 · handoff §3.3) — Transform 2 จุดของแปลง/หมุด L1-TS ไปต่อ L1-RTK = ข้อยกเว้นที่ปลั๊กอินอนุญาตเอง
        #   ⇒ จดงานนี้แบบเดียวกับงานตอนปลดล็อก (_op_begin l1_ok → _op_commit → _l1_note_ok) ด่าน L1 ตอนบันทึกจึงไม่ถาม
        #   (เดิมถามหนึ่งครั้งตอนบันทึก) · แก้ต่อด้วยเครื่องมืออื่น / ย้อนงานนี้แล้ว ⇒ ถามตามปกติ (_l1_commit_hits)
        #   ★ rc1 S5 (review R3-01) — จดเฉพาะฟีเจอร์ใน _ts_exc ที่ "ไม่มีงาน L1 ที่ยังไม่อนุญาตค้างอยู่ก่อน" (l1_only)
        #     เดิมจดทุก fid ที่รูปเปลี่ยน ⇒ ลากมุม L1-TS ด้วย Vertex Tool / ย้ายหมุดด้วย Move Feature แล้วค่อย Transform
        #     = รูปที่บิดติดไปกับผลและถูกจดว่าอนุญาต (ฟอกงาน) ⇒ บันทึกไม่ถาม
        self._op_begin(layers, l1_ok=bool(_ts_exc), l1_only=_ts_exc)   # เริ่มนับ undo-step ต่อเลเยอร์
        _done = []               # เลเยอร์ที่แก้เสร็จแล้ว (ไว้ย้อนถ้าเลเยอร์ถัดไปพัง)
        for lyr in layers:
            lyr.beginEditCommand(f"MLEP {self.mode}")
            
            try:
                # Optimize: ดึงเฉพาะ Geometry และรวบรวมเป็น list ก่อนวนลูปแก้ไข เพื่อป้องกันปัญหา cursor ล็อกขณะเขียนข้อมูล
                req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
                features = list(lyr.getFeatures(req))
                # ★ เช็คผลทุกการเขียน (2026-08-06): changeGeometry/moveVertex คืน False ได้เงียบ ๆ
                #   (provider ปฏิเสธ/ฟีเจอร์หาย) -> เดิมนับว่าสำเร็จ = อีกเลเยอร์ขยับฝ่ายเดียว
                #   โยน RuntimeError ให้ except ด้านล่างย้อน "ทั้งชุด" ตามกติกาทั้งคู่หรือไม่ทำเลย
                #   (นิยามครั้งเดียวต่อเลเยอร์ ไม่สร้างใหม่ทุก feature)
                def _w(ok, fid_, what=""):
                    if not ok:
                        raise RuntimeError(f"เขียนรูปทรงไม่สำเร็จที่ feature {fid_} {what}")

                for f in features:
                    geom = f.geometry()
                    if geom.isNull(): continue

                    # --- 1. Move ---
                    if self.mode == 'move' and len(p) >= 2:
                        dx, dy = p[1].x() - p[0].x(), p[1].y() - p[0].y()
                        geom.translate(dx, dy)
                        _w(lyr.changeGeometry(f.id(), geom), f.id(), "(move)")

                    # --- 2. Rotate (ใส่ลบหน้ามุมตามที่ตกลงกัน) ---
                    elif self.mode == 'rotate' and len(p) >= 3:
                        a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                        a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
                        geom.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))
                        _w(lyr.changeGeometry(f.id(), geom), f.id(), "(rotate)")

                    # --- 3. Scale (ปรับใหม่ให้ชัวร์) ---
                    elif self.mode == 'scale' and len(p) >= 3:
                        d1 = math.sqrt(p[0].sqrDist(p[1]))
                        d2 = math.sqrt(p[0].sqrDist(p[2]))
                        if d1 > 0:
                            s = d2 / d1
                            # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                            geom.translate(-p[0].x(), -p[0].y())
                            matrix = QtGui.QTransform(); matrix.scale(s, s)
                            geom.transform(matrix)
                            geom.translate(p[0].x(), p[0].y())
                            _w(lyr.changeGeometry(f.id(), geom), f.id(), "(scale)")

                    # --- 4. Transform ---
                    elif self.mode == 'transform' and len(p) >= 4:
                        _w(self.apply_similarity_direct(lyr, f, p), f.id(), "(transform)")

                    # ★ rc2 (audit A2-07) — ตัดสาขา 'modify_node' (ไม่มีทางถึง: Move Node ใช้ SyncVertexTool ไม่ผ่าน handle_click
                    #   · ถ้ามีคนต่อสายในอนาคตจะย้ายมุมโดยหมุดไม่ตาม ไม่มีด่านคู่) — โหมดอื่นไม่เขียนอะไร
                
                lyr.endEditCommand()
                _done.append(lyr)                 # สำเร็จแล้ว (ถูก push ลง undo-stack)
            except Exception:
                # ★ 2.3.7 (review ER-06) — traceback ลง Log ก่อน (ข้อความดิบมี fid/ข้อความของ provider ไม่ใช่สำหรับพนักงาน)
                _log_exc(f"execute_tool ล้มที่ชั้น '{lyr.name()}' ({self.mode})", Qgis.Critical)
                # ★ ทั้งคู่หรือไม่ทำเลย (2026-08-06): เดิม destroy เฉพาะเลเยอร์ที่พัง แล้ว "ลูปเดินต่อ"
                #   ไปแปลงอีกเลเยอร์ => แปลงไม่ขยับ แต่หมุดขยับทั้งกลุ่ม = ผิดกติกาเหล็กทั้งชุด
                #   ตอนนี้: ย้อนเลเยอร์ที่ทำสำเร็จไปแล้วด้วย (undo ตาม delta จาก baseline) แล้วหยุด
                lyr.destroyEditCommand()
                # ★ 2.3.7 (review DI-33) — ย้อนชั้นที่เสร็จไปแล้วกลับ baseline แล้วล้าง Redo (เดิมเหลือ Redo รายชั้น
                #   = กด Redo ชั้นเดียวได้งานคู่กลับมาครึ่งเดียว) · บอก "ย้อนให้ทั้งหมดแล้ว" เฉพาะเมื่อทุกชั้นกลับถึง baseline จริง
                _all_back = True
                for _d in _done + [lyr]:
                    try:
                        _base = (self._op_baseline or {}).get(_d.id())
                        if _d is not lyr:
                            _n = _d.undoStack().index() - (_base[1] if _base else _d.undoStack().index())
                            for _ in range(max(0, _n)):
                                _d.undoStack().undo()
                            self._purge_redo(_d)
                        if _base and _d.undoStack().index() != _base[1]:
                            _all_back = False
                    except Exception:
                        _all_back = False
                self._ask(
                    QtWidgets.QMessageBox.Critical, "ยกเลิกทั้งการทำงาน",
                    f"แก้รูปแปลง/หมุดในชั้น '{lyr.name()}' ไม่สำเร็จ\n\n"            # ★ 2.3.7 (ER-06) เดิมแปะ exception ดิบ
                    + ("ย้อนกลับให้ทั้งหมดแล้ว (แปลงและหมุดยังตรงกันเหมือนเดิม) — กรุณาลองใหม่" if _all_back else
                       "⚠️ ย้อนกลับได้ไม่ครบ — แปลงกับหมุดบริเวณนี้อาจไม่ตรงกัน ตรวจก่อนบันทึก "
                       "(ดูแผง View ▸ Panels ▸ Undo/Redo ของ QGIS ว่าเหลืออะไรค้างอยู่)")   # ★ 2.4.0 (review DI-13) เดิมอ้างเมนูที่ไม่มี
                    + f"\n\n({self._LOG_HINT})")
                # 🔧 8 ก.ย. 69 — เดิมเป็น print() ที่มองไม่เห็นใน QGIS ⇒ ★ 2.3.7 ลง Log พร้อม traceback แล้ว (ต้น except)
                break

        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        self.iface.mapCanvas().refresh()
        self.clear_markers()
        # ทิ้งเงา (geometry ใน cache เป็นของก่อนแก้ = ล้าสมัยแล้ว)
        # ไม่ขยับ cache ตามสูตรที่เพิ่งแก้ เพราะถ้า changeGeometry ล้มเหลวเงียบๆ เงาจะโกหกทันที
        # -> คลิกแรกของรอบหน้าไปดึงของจริงมาใหม่ ช้ากว่านิดเดียว (1 คิวรีต่อรอบ) แต่ไม่มีทางโกหก
        self._preview_clear()
        self.src_pts = []
        if self.mode == 'transform' :
            self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def apply_similarity_direct(self, lyr, f, p):
        """คำนวณ Transform แบบ Matrix (Similarity)"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return False
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        # x' = ax - by + tx , y' = bx + ay + ty
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        # ★ 28 ส.ค. 69 คืนผลการเขียนออกไปให้ผู้เรียกตรวจ (audit 2.1)
        #   เดิมเรียกลอย ๆ ไม่ดูค่าคืน ขณะที่ move/rotate/scale ห่อด้วย _w() ทุกจุด
        #   -> ถ้าชั้นแปลงเขียนไม่ผ่าน (เช่นไม่มี capability ChangeGeometries) ลูปจะเดินต่อ
        #      ไปเขียนชั้นหมุดจนสำเร็จ = หมุดขยับ แปลงอยู่ที่เดิม เงียบสนิท
        return lyr.changeGeometry(f.id(), geom)

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        """ล้างค่าหน้าจอและทำลายตัวช่วย Snap อย่างปลอดภัย"""
        if hasattr(self, 'snap_indicator') and self.snap_indicator:
            # ล้างสัญลักษณ์บนหน้าจอก่อนทำลาย Object
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            self.snap_indicator = None

        self.clear_rubber_band()
        self._preview_clear()
        try:
            self._donut_clear_bands()      # 2.3.1 — ไฮไลต์ส้มของ 🍩 แบ่งหัก/แยก
        except Exception:
            pass
        self._dol_clear_highlight()
        self._align_picked_ids = set()
        self._align_clear_highlight()
        try:
            self._pair_hl_clear_marks()    # ★ 2.4.0 (review UX-09) ✖ Reset ⇒ เก็บเครื่องหมาย "จุดที่ต้องแก้" (แถบยังอยู่)
        except Exception:
            pass
        
        # รีเซ็ตเครื่องมือ Semi-Auto (ถ้ามี)
        if hasattr(self, 'temp_tool') and self.temp_tool:
            if hasattr(self.temp_tool, 'reset_tool'):
                try:
                    self.temp_tool.reset_tool()
                except Exception:
                    pass

        if hasattr(self, 'markers'):
            for m in self.markers:
                if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []
        self.src_pts = []
        self._xform_sel_snap = None        # ★ 2.3.7 b17 (audit R2-D1)

        # ล้าง feature ที่ถูกเลือกไว้ในทุกเลเยอร์ของ QGIS
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if isinstance(lyr, QgsVectorLayer) and lyr.selectedFeatureCount():
                    lyr.removeSelection()
            except Exception:
                pass

        self.iface.mapCanvas().refresh()
        self.iface.actionSelect().trigger()
            
    def clear_rubber_band(self):
        """ลบ Rubber Band ออกจากหน้าจอและหน่วยความจำอย่างเด็ดขาด"""
        if self.rubber_band:
            self.rubber_band.hide() # ซ่อนทันที
            self.iface.mapCanvas().scene().removeItem(self.rubber_band) # ลบออกจาก Scene
            self.rubber_band = None # คืนค่าว่าง
