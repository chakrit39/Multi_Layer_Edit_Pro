# -*- coding: utf-8 -*-
"""Delete Parcel, Change Type และข้อมูลแปลง

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import re
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import (Qgis, QgsDistanceArea, QgsExpression, QgsFeatureRequest, QgsMessageLog, QgsPointXY,
                       QgsProject, QgsUnitTypes, QgsWkbTypes)
from ..core.util import (_date_th, _date_val, _fld_idx, _norm_utm, _osa, _public_landno, _ROMAN_OF, _rngw, _sheet_str, _txt,
                         _TYPE_NOT_ON_MARKER, _UTM_FIELD_NAMES, _wrap_th, _กริดจุด)
from ..lock_rules import L1_TYPES, norm_type
from ..map_tools import PolygonPickTool


class ParcelsMixin:
    """Delete Parcel, Change Type และข้อมูลแปลง"""

    # ---------- ผู้ดูแล: ลบทั้งแปลง (รูปแปลง + หมุดของแปลงนั้น) ----------
    def start_delete_parcel(self):
        ready = self._admin_ready("ลบแปลง")
        if not ready:
            return
        poly_lyr, point_lyr = ready
        # ★ rc2 (audit A3-08) — ถามสิทธิ์ลบ (DELETE) ของทั้งสองชั้นตั้งแต่กดปุ่ม แบบ ➕ ที่ถาม INSERT
        #   เดิมไปรู้ตอน 💾 (ด่าน _commit_preflight กันครึ่งคู่ไว้แล้ว แต่ผู้ใช้ทำงานไปเปล่า ๆ) · ถามไม่ได้ (None) = ไม่กัน
        for lyr, what in ((poly_lyr, "แปลง"), (point_lyr, "หมุด")):
            if self._can_table_priv(lyr, "DELETE") is False:
                self._ask(QtWidgets.QMessageBox.Warning, "ลบแปลง",
                          f"บัญชีที่ใช้อยู่ยังไม่มีสิทธิ์ลบ{what}ในชั้น '{lyr.name()}' (DELETE)\n\n"
                          "แจ้งผู้ดูแลฐานข้อมูลให้เพิ่มสิทธิ์ก่อน — ถ้าฝืนลบ จะไปล้มตอนกดบันทึก")
                return
        self.cancel_transform()
        self._dol_clear_highlight()
        # ★ จำคู่เลเยอร์ตอน arm — ถ้าคอมโบถูกสลับก่อนคลิก ให้ยกเลิก (กันหาหมุดผิดชั้น)
        self._delparcel_lids = (poly_lyr.id(), point_lyr.id())
        canvas = self.iface.mapCanvas()
        # ใช้ตัวเลือกแปลงตัวเดียวกับปุ่มค้นหาภาพลักษณ์ — มี popup ให้เลือกเมื่อแปลงซ้อนกัน
        self.temp_tool = PolygonPickTool(
            canvas, poly_lyr, self._delete_parcel_picked, self._dol_on_hover,
            msg_title="ลบแปลง", choose_prompt="เลือกแปลงที่ต้องการลบ:")      # ★ rc1 (F8 · §5.1 DI-44) เดิมหัวเรื่อง "DOL"
        canvas.setMapTool(self.temp_tool)
        self.temp_tool.push_hint(                                       # ★ 2.3.7 (UX-01) ข้อความของเครื่องมือ
            "ลบแปลง", f"⚠️ คลิกแปลงใน '{poly_lyr.name()}' ที่ต้องการลบ "
                          "(ลบรูปแปลง + หมุดของแปลงนั้นทั้งหมด) • Esc = ยกเลิก", level=2, duration=10)

    def _delete_parcel_picked(self, feat, layer):
        """callback จาก PolygonPickTool — คืน cursor ปกติแล้วเข้าขั้นยืนยัน/ลบ"""
        self.iface.actionSelect().trigger()
        self._dol_clear_highlight()
        ready = self._admin_ready("ลบแปลง")
        if not ready:
            return
        poly_lyr, point_lyr = ready
        # ★ ทั้งคู่ต้องเป็นเลเยอร์เดิมตอนกดปุ่ม (กันสลับคอมโบ "ชั้นหมุด" ระหว่าง arm→คลิก
        #   ซึ่งจะทำให้หาหมุดในชั้นผิด = ลบแปลงแต่หมุดจริงค้าง — 2026-08-05)
        armed = getattr(self, "_delparcel_lids", None)
        if armed != (poly_lyr.id(), point_lyr.id()) or (layer is not None and layer.id() != poly_lyr.id()):
            self._ask(
                QtWidgets.QMessageBox.Warning, "ลบแปลง",
                "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม (หรือแปลงที่คลิกอยู่คนละชั้น) — ยกเลิก\n"
                "กดปุ่ม 🗑 ลบแปลง ใหม่อีกครั้ง")
            return
        self._delete_parcel_execute(poly_lyr, point_lyr, feat)

    def _parcel_markers(self, poly_lyr, point_lyr, feat):
        """คืน dict {mk_ids, n_on_node, utm_norm, n_twin, n_vtx} = หมุด "ของแปลงนี้" (UTM ตรงกับแปลง)
        หรือ None = ตรวจไม่ได้ (คีย์ว่าง/NULL หรือ query ล้ม) -> ผู้เรียกต้องยกเลิกการลบ (fail-closed)
        ค้น 2 ทางแล้วรวมกัน กันพลาด:
          (1) expression บน UTM  -> ได้ครบแม้หมุดหลงอยู่นอกขอบเขตแปลง
          (2) กวาดตามขอบเขตแปลง + เทียบ _norm_utm -> กันเคสค่า UTM เขียนต่างรูปแบบเล็กน้อย
        n_twin = จำนวนแปลงในชั้นที่ถือ UTM เดียวกัน (>1 = คีย์ซ้ำ ห้ามลบ) · n_vtx = จำนวนมุมแปลง
        ★ 2.4.0 (review DU-01) locked = {fid: ชนิด L1} ของหมุดที่ล็อก (_marker_locked · Type ของตัวหมุดเอง) — ผู้เรียก
          (🗑 ลบแปลง · 🏷 เปลี่ยน Type · 🍩 · 📝) ต้องปฏิเสธด้วย _parcel_locked_block ไม่งั้นหมุด Type L1 บนแปลงที่ไม่ใช่ L1
          ถูกลบ/ถูกเขียน Type ใหม่ (= ปลดล็อกถาวร) ทั้งที่ยังไม่ได้กดปลดล็อก L1 · ฝั่ง UTM ของกติกาไม่ต้องสแกนเพิ่ม: หมุดชุดนี้
          UTM เท่าแปลงนี้ ⇒ ตรงแปลง L1 ได้ก็ต่อเมื่อแปลงนี้เป็น L1 เอง (ผู้เรียกมีด่าน Type แปลงแล้ว) หรือมีแปลง L1 เป็นแฝด
          (n_twin > 1 ⇒ 🗑/🏷/🍩 ปฏิเสธอยู่แล้ว · 📝 เปลี่ยนเฉพาะหมุดบนมุมของแปลงนี้) · ไม่มีคิวรีเพิ่ม (อ่าน Type จากแถวเดิม)"""
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        if not tu or not pu:
            return None
        utm_raw = feat[pu]
        # ★ NULL/ว่าง = ลบอัตโนมัติไม่ได้ (2026-08-05): _norm_utm(NULL) คืนสตริง 'None'/'NULL'
        #   ซึ่ง truthy — ถ้าปล่อยผ่าน การกวาด bbox จะจับ "หมุดคีย์ว่างของแปลงข้างเคียง" มาลบด้วย
        # ★ รอบ 9d (ง · ผู้ตรวจรอบ 9b A ข้อ 3) — ด่านนี้ตายตั้งแต่ 2.3.5: _norm_utm คืนค่าแทน "\x00ไม่มีค่า<n>" ที่เป็นจริงเสมอ
        #   ⇒ แปลงคีย์ '' / คำว่า 'NULL' ได้หมุดที่มีค่าดิบเดียวกันทั้งชั้น (🗑 ลบหมุดของแปลงอื่น · 🏷 เปลี่ยน Type ให้หมุดของแปลงอื่น
        #   · 🍩 ลบหมุดของแปลงข้างเคียงเป็น "หมุดค้าง") ⇒ ตรวจค่าดิบก่อน normalize · สร้างนิพจน์จากค่าดิบที่ผ่าน _txt
        #   (NULL แบบมีชนิดจาก provider ไม่กลายเป็น = 'NULL' อีก)
        raw_s = _txt(utm_raw)
        if not raw_s or raw_s.upper() in ("NONE", "NULL", "NAN"):
            return None
        utm_norm = _norm_utm(utm_raw)
        # fail-closed ทั้งฟังก์ชัน: query พัง = คืน None (ยกเลิกการลบ) — ห้ามลบทั้งที่รายชื่อหมุดไม่ครบ
        # (provider อาจคืน iterator ว่าง/สั้นแบบเงียบ ๆ ตอนหลุด connection — กันเพิ่มด้วย n_vtx เทียบใน dialog)
        _bz = self._busy("parcel-markers").begin()   # ★ 2.3.7 (review PF-03) 3 คิวรี (UTM ไม่มี index = seq scan)
        _ti = self._field_index(point_lyr.fields(), 'type')      # ★ 2.4.0 (review DU-01) Type ของหมุด
        locked = {}

        def _lk(f):
            _l, _t = self._marker_locked(f, {}, tu, _ti)
            if _l:
                locked[f.id()] = _t
        try:
            ids = {}
            req = QgsFeatureRequest().setFilterExpression(
                f"{QgsExpression.quotedColumnRef(tu)} = {QgsExpression.quotedValue(raw_s)}")
            for f in point_lyr.getFeatures(req):
                ids[f.id()] = f.geometry()
                _lk(f)
            geom = feat.geometry()
            bb = geom.boundingBox()
            bb.grow(1.0)          # เผื่อหมุดที่นั่งพอดีขอบ
            for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(bb)):
                if f.id() not in ids and _norm_utm(f[tu]) == utm_norm:
                    ids[f.id()] = f.geometry()
                    _lk(f)
            # แปลงคีย์ซ้ำ (แฝด): ลบหมุดตาม UTM จะพังแปลงแฝดด้วย -> นับไว้ให้ execute ปฏิเสธ
            # ★ 2.3.7 (known-2.3.6 ข้อ 10 d) — นับแบบ normalise (_utm_twin_fids) เดิมนับด้วยข้อความตรงทุกตัวอักษร
            #   ⇒ 'X ' / ' X' ไม่นับเป็นแฝดของ 'X' · ต้องเจอแปลงนี้เองด้วย ไม่งั้นถือว่าถามชั้นไม่สำเร็จ (fail-closed)
            twin_fids = self._utm_twin_fids(poly_lyr, pu, raw_s, utm_norm)
            if feat.id() not in twin_fids:
                QgsMessageLog.logMessage("_parcel_markers: หาแปลงคีย์ซ้ำแล้วไม่เจอแปลงนี้เอง (fid %s) — ตรวจไม่ได้"
                                         % feat.id(), "MLEP", Qgis.Warning)
                return None
            n_twin = len(twin_fids)
        except Exception:
            return None
        finally:
            _bz.end()
        # นับหมุดที่ทับมุมแปลงจริง + จำนวนมุมแปลง (โชว์ในกล่องยืนยันให้คนเห็นว่าครบไหม)
        n_on_node = 0
        g = feat.geometry()
        for gm in ids.values():
            try:
                if gm is None or gm.isNull():
                    continue
                cv = g.closestVertex(gm.asPoint())
                if cv[4] is not None and cv[4] < self._MK_WELD_TOL ** 2:   # ทับมุมแปลง < 1 ซม. (★ 2.4.0 DU-02 ค่าคงที่)
                    n_on_node += 1
            except Exception:
                continue          # หมุด geometry แปลก (multipoint/พัง) ข้ามตัวนั้น ไม่ล้มการนับทั้งชุด
        try:
            n_vtx = sum(1 for _ in g.vertices())
        except Exception:
            n_vtx = 0
        # ★ 2.3.7 (review DI-56) — มุมจริง = จุดของทุกวง/ทุกก้อน "ไม่รวมจุดปิดวง" (_ring_points) · มุมที่มีหมุดของแปลงนี้ ≤ 1 ซม.
        #   เดิมกล่องยืนยันลบแปลงแสดง "หมุดที่ทับ vertex / vertex ทั้งหมด" ⇒ จุดปิดวงนับเป็นมุม: สี่เหลี่ยมที่ครบ = '4/5 มุม'
        #   แปลงมีรู/หลายก้อน (🍩 สร้างได้แล้ว) ขึ้น '⚠️ ไม่ครบทุกมุม' ทั้งที่ครบ · ตารางแฮชช่องละ 1 ซม. (แบบ _bare_nodes)
        corners = [q for ring in self._ring_points(g) for q in ring]
        _mk_pts = []
        for gm in ids.values():
            try:
                if gm is not None and not gm.isNull():
                    _mk_pts.append(QgsPointXY(gm.asPoint()))
            except Exception:
                continue          # หมุด geometry แปลก (multipoint/พัง) ไม่นับเป็นหมุดของมุมไหน
        # ★ 2.4.0 (review DU-02) — "มุมที่มีหมุด" = หมุดบนมุม ≤ 1 มม. (_corner_n · เกณฑ์เดียวกับด่านก่อนบันทึก)
        #   เดิม ≤ 1 ซม. ⇒ แปลงที่หมุดเยื้องมุม 1 มม.–1 ซม. ขึ้น "ครบทุกมุม" ทั้งที่ด่านก่อนบันทึกเตือนว่ามุมไม่มีหมุด
        #   (ตัวเลขแสดงในกล่องยืนยันอย่างเดียว · ชุดหมุดที่จะลบ mk_ids ไม่เปลี่ยน)
        _grid = _กริดจุด(_mk_pts, self._MK_AT_CORNER_TOL)
        n_corner_mk = sum(1 for q in corners if self._corner_n(_grid, q))
        return {"mk_ids": list(ids.keys()), "n_on_node": n_on_node,
                "utm_norm": utm_norm, "n_twin": n_twin, "n_vtx": n_vtx,
                "n_corner": len(corners), "n_corner_mk": n_corner_mk,        # ★ 2.3.7 (DI-56)
                "twin_fids": twin_fids,          # ★ 2.3.7 (ข้อ 10 d) — fid แปลงที่ใช้ UTM เดียวกัน (รวมแปลงนี้)
                "locked": locked}                # ★ 2.4.0 (review DU-01) — {fid: ชนิด L1} หมุดล็อกของแปลงนี้

    def _utm_twin_fids(self, poly_lyr, pu, raw_s, utm_norm):
        """★ 2.3.7 (known-2.3.6 ข้อ 10 d) — fid ของแปลงในชั้นที่ถือ UTM เดียวกัน **หลัง normalise** (_norm_utm) รวมแปลงนี้เอง
        เดิมนับด้วยนิพจน์ "UTM" = '<ค่าตรงทุกตัวอักษร>' ⇒ ' X' / 'X ' / 'X.0' ไม่นับเป็นแฝดของ 'X' (แปลงที่คีย์มีช่องว่างหัว/ท้าย
        ไม่นับแม้แต่ตัวเอง) ⇒ 🗑/🏷/🍩 ผ่านด่าน "แปลงคีย์ซ้ำ" ทั้งที่หมุดถูกแชร์ตามคีย์
        ถามชั้นด้วยนิพจน์ "กว้างกว่า" ที่สร้างจากค่าจริงที่ผ่าน _txt แล้วเท่านั้น (🔴 ห้ามใส่ค่าแทน \\x00 ของ _norm_utm ในนิพจน์)
          · คอลัมน์ข้อความ: "UTM" LIKE '%<ค่า>%' (PostGIS คำนวณฝั่งเซิร์ฟเวอร์ · ค่าที่มี % _ \\ ⇒ trim("UTM") IN (…))
          · คอลัมน์ตัวเลข: "UTM" = <ค่า> แบบเดิม (ตัวเลขไม่มีช่องว่างให้ต่าง)
        แล้วคัดด้วย _norm_utm ในปลั๊กอิน = เกณฑ์เดียวกับการจับคู่หมุดทุกที่ · query ล้ม ⇒ raise (ผู้เรียก fail-closed)"""
        col = QgsExpression.quotedColumnRef(pu)
        idx = poly_lyr.fields().indexOf(pu)
        if poly_lyr.fields().at(idx).isNumeric():
            expr = f"{col} = {QgsExpression.quotedValue(raw_s)}"
        elif any(ch in raw_s for ch in "%_\\"):
            vals = sorted({raw_s, utm_norm, utm_norm + ".0"})
            expr = f"trim({col}) IN ({', '.join(QgsExpression.quotedValue(v) for v in vals)})"
        else:
            expr = f"{col} LIKE {QgsExpression.quotedValue('%' + utm_norm + '%')}"
        req = (QgsFeatureRequest().setFilterExpression(expr)
               .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([idx]))
        out = []
        it = poly_lyr.getFeatures(req)
        try:
            for f in it:
                if _norm_utm(f[pu]) == utm_norm:
                    out.append(f.id())
        finally:
            it.close()
        return out

    def _delete_parcel_execute(self, poly_lyr, point_lyr, feat):
        """ลบรูปแปลง + หมุดของแปลงนั้นพร้อมกัน (ทั้งคู่หรือไม่ทำเลย)"""
        if feat is None or not feat.isValid():
            return False
        info = self._parcel_markers(poly_lyr, point_lyr, feat)
        if info is None:
            self._ask(
                QtWidgets.QMessageBox.Warning, "ลบแปลง",
                "อ่านค่า UTM/รายชื่อหมุดของแปลงนี้ไม่ได้ (คีย์ว่าง หรือ query ล้มเหลว)\n"
                "— ยกเลิกการลบ (กันลบผิดแปลง/ลบหมุดไม่ครบ)")
            return False
        mk_ids = info["mk_ids"]
        utm_norm, n_twin = info["utm_norm"], info["n_twin"]
        # ★ 2.3.7 (review DI-56) — นับ "มุมจริง" (ไม่รวมจุดปิดวง) แทน n_on_node/n_vtx เดิม
        n_corner, n_corner_mk = info.get("n_corner", 0), info.get("n_corner_mk", 0)
        if not n_corner:
            self._ask(QtWidgets.QMessageBox.Warning, "ลบแปลง",
                      "แปลงนี้ไม่มีรูป/นับมุมของแปลงไม่ได้ — ยกเลิกการลบ (ตรวจรูปแปลงก่อน)")
            return False
        if n_twin > 1:
            self._ask(
                QtWidgets.QMessageBox.Warning, "ลบแปลง",
                f"พบแปลงคีย์ซ้ำ (UTM เดียวกัน {n_twin} แปลง) — ลบอัตโนมัติไม่ได้\n"
                "เพราะหมุดถูกแชร์ตามคีย์ ลบแล้วแปลงแฝดจะหมุดหาย · แก้คีย์ซ้ำก่อน")
            return False
        if not mk_ids:
            a0 = self._ask(
                QtWidgets.QMessageBox.Question, "ลบแปลง — ผิดปกติ",
                "ไม่พบหมุดของแปลงนี้เลย (ตามกติกาเหล็ก ทุกมุมควรมีหมุด)\n"
                "อาจเลือกชั้นหมุดผิด หรือการค้นหมุดล้มเหลวเงียบ ๆ\n\n"
                "ยืนยันลบ 'เฉพาะรูปแปลง' โดยไม่แตะหมุดเลย?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if a0 != QtWidgets.QMessageBox.Yes:
                return False

        gv = lambda name: _sheet_str(feat, name)      # noqa: E731  (ดู _sheet_str)

        tp = self._poly_type_str(poly_lyr, feat)
        try:
            area_m2 = feat.geometry().area()
        except Exception:
            area_m2 = 0.0
        warn_ref = tp in ("L1-RTK", "L1-TS", "CT-RTK")
        # ★ แปลงอ้างอิง: ต้องกด "🔓 ปลดล็อก L1" ก่อนถึงลบได้ (สอดคล้องกับทุกเครื่องมือ admin
        #   ที่แตะ L1 — double-confirm อย่างเดียวยังง่ายไปสำหรับ destructive · 2026-08-05)
        if warn_ref and not self._l1_unlocked():
            self._ask(
                QtWidgets.QMessageBox.Warning, "ลบแปลง",
                f"แปลงนี้เป็น {tp} (ชั้นอ้างอิงพิกัดหลัก)\n"
                "ต้องกดปุ่ม 🔓 ปลดล็อก L1 ก่อน จึงจะลบได้")
            return False
        if self._parcel_locked_block(info, "ลบแปลง", "ลบแปลงนี้ไม่ได้"):      # ★ 2.4.0 (review DU-01) หมุด Type L1
            return False
        head = ("🔴 แปลงนี้เป็น " + tp + " = ชั้นอ้างอิงพิกัดหลัก!\n"
                "ลบแล้วจะเสียหมุดอ้างอิงที่แปลงข้างเคียงใช้ยึด\n\n") if warn_ref else ""
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ยืนยันลบแปลง",
            f"{head}"
            f"ระวาง {gv('UTMMAP1')} {gv('UTMMAP2')} {gv('UTMMAP3')}-{gv('UTMMAP4') or '00'}"
            f"  มาตราส่วน {gv('UTMSCALE')}\n"
            f"เลขที่ดิน {gv('LANDNO')}  |  ประเภท {tp or '-'}  |  เนื้อที่รูป {area_m2:,.1f} ตร.ม.\n"
            f"UTM: {utm_norm}\n\n"
            f"จะลบ: รูปแปลง 1 แปลง + หมุดของแปลงนี้ {len(mk_ids)} จุด"
            f" (มุมแปลงที่มีหมุด {n_corner_mk}/{n_corner} มุม"               # ★ 2.3.7 (DI-56) ไม่นับจุดปิดวง
            + ("" if n_corner_mk >= n_corner else " ⚠️ ไม่ครบทุกมุม — เช็คชั้นหมุดก่อน")
            + ")\n\n"
            f"ลบแปลงนี้?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        if warn_ref:
            a2 = self._ask(
                QtWidgets.QMessageBox.Question, "ยืนยันอีกครั้ง (แปลงอ้างอิง)",
                f"ยืนยันซ้ำ: แปลง {tp} เลขที่ดิน {gv('LANDNO')} จะถูกลบถาวรเมื่อกดบันทึก\n\nแน่ใจหรือไม่?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if a2 != QtWidgets.QMessageBox.Yes:
                return False

        lyrs = [poly_lyr] + ([point_lyr] if mk_ids else [])
        # ★ 2.4.0 (review DI-15) — เปิดโหมดแก้ไขทุกชั้นก่อนเปิดคำสั่ง (เดิมไม่ดูผล) · เปิดไม่ได้ = ไม่ลบอะไร
        if not self._ensure_editing(*lyrs, title="ลบแปลง", what="ยังไม่ได้ลบแปลงและหมุด"):
            return False
        self._op_begin(lyrs)
        poly_lyr.beginEditCommand("Delete Parcel")
        if mk_ids:
            point_lyr.beginEditCommand("Delete Parcel Markers")
        ok = False
        try:
            ok = bool(poly_lyr.deleteFeature(feat.id()))
            if ok and mk_ids:
                if not point_lyr.deleteFeatures(mk_ids):
                    ok = False        # ลบหมุดไม่ครบ -> ถือว่าล้มทั้ง operation (กันแปลงหายแต่หมุดค้าง)
        finally:
            # ทั้งคู่หรือไม่ทำเลย: ถ้าครึ่งทาง ย้อนทิ้งทั้ง command (เหมือนด่านของ "ลบ Node")
            if ok:
                poly_lyr.endEditCommand()
                if mk_ids:
                    point_lyr.endEditCommand()
            else:
                poly_lyr.destroyEditCommand()
                if mk_ids:
                    point_lyr.destroyEditCommand()
        self._op_commit()
        if not ok:
            self.iface.messageBar().pushMessage(
                "ลบแปลง", "ลบไม่สำเร็จ — ย้อนกลับให้แล้ว (แปลงและหมุดยังอยู่ครบ)",
                level=2, duration=8)
            return False
        self.iface.mapCanvas().refresh()
        # การลบถูกบันทึกใน <D>_Move_Log ผ่าน trg_log_delete (เก็บ geom เดิมไว้ กู้คืนได้) ตอนกดบันทึก
        self.iface.messageBar().pushMessage(
            "ลบแปลง", f"ลบแปลง (เลขที่ดิน {gv('LANDNO')}) + หมุด {len(mk_ids)} จุดแล้ว "
                          "• กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล", level=0, duration=8)
        return True

    def start_change_type(self):
        """คลิกแปลง -> เปลี่ยนค่า Type ของทั้งแปลงและหมุดของแปลงนั้นพร้อมกัน

        ★ 31 ส.ค. 69 — เคสที่เจอจริง: แปลงถูกจัดเป็น L1-TS (ชั้นอ้างอิงพิกัดหลัก)
          แต่ตรวจแล้วค่าพิกัดผิดตำแหน่ง ต้องลดชั้นเป็น L2-TS ทั้งแปลงและหมุด
          เดิมต้องแก้ในฐานข้อมูลตรง ๆ ซึ่งไม่มีร่องรอยให้คนอื่นตามได้
          (trigger ในฐานข้อมูลไม่จับการเปลี่ยน Type -> ปุ่มนี้เขียนล็อกเองที่ _flush_type_log)"""
        ready = self._admin_ready("เปลี่ยน Type")
        if not ready:
            return
        poly_lyr, point_lyr = ready
        _tf = self._resolve_field(poly_lyr, {'type'})
        if not _tf:
            self._ask(QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                      "ชั้นแปลงไม่มีคอลัมน์ Type — เปลี่ยนไม่ได้")
            return
        if not self._need_column_or_warn(poly_lyr, _tf, "เปลี่ยน Type"):
            return
        # ★ 31 ส.ค. 69 — ปุ่มนี้เขียน Type ของ "ชั้นหมุด" ด้วย ต้องถามสิทธิ์ทั้งสองชั้น
        #   ไม่งั้นแปลงเปลี่ยนได้แต่หมุดล้มตอน commit = ข้อมูลสองชั้นไม่ตรงกัน
        _mtf0 = self._resolve_field(point_lyr, {'type'})
        if _mtf0 and not self._need_column_or_warn(point_lyr, _mtf0, "เปลี่ยน Type"):
            return
        self.cancel_transform()
        self._dol_clear_highlight()
        # ★ จำคู่เลเยอร์ตอน arm — แนวเดียวกับปุ่ม 🗑 ลบแปลง (กันสลับคอมโบก่อนคลิก
        #   แล้วไปแก้ Type ของหมุดผิดชั้น)
        self._chgtype_lids = (poly_lyr.id(), point_lyr.id())
        canvas = self.iface.mapCanvas()
        self.temp_tool = PolygonPickTool(
            canvas, poly_lyr, self._change_type_picked, self._dol_on_hover,
            msg_title="เปลี่ยน Type", choose_prompt="เลือกแปลงที่ต้องการเปลี่ยนประเภท:")   # ★ rc1 (F8 · §5.1 DI-44) เดิม "DOL"
        canvas.setMapTool(self.temp_tool)
        self.temp_tool.push_hint(                                       # ★ 2.3.7 (UX-01) ข้อความของเครื่องมือ
            "เปลี่ยน Type", f"คลิกแปลงใน '{poly_lyr.name()}' ที่ต้องการเปลี่ยนประเภท "
                            "(เปลี่ยนทั้งแปลงและหมุดของแปลงนั้น) • Esc = ยกเลิก",
            level=0, duration=10)

    def _change_type_picked(self, feat, layer):
        """callback จาก PolygonPickTool — คืน cursor ปกติแล้วเข้าขั้นยืนยัน"""
        self.iface.actionSelect().trigger()
        self._dol_clear_highlight()
        ready = self._admin_ready("เปลี่ยน Type")
        if not ready:
            return
        poly_lyr, point_lyr = ready
        armed = getattr(self, "_chgtype_lids", None)
        if armed != (poly_lyr.id(), point_lyr.id()) or (layer is not None and layer.id() != poly_lyr.id()):
            self._ask(
                QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม (หรือแปลงที่คลิกอยู่คนละชั้น) — ยกเลิก\n"
                "กดปุ่ม 🏷 ใหม่อีกครั้ง")
            return
        self._change_type_execute(poly_lyr, point_lyr, feat)

    def _change_type_execute(self, poly_lyr, point_lyr, feat, preset=None):
        """เปลี่ยน Type ของแปลง + หมุดของแปลงนั้นพร้อมกัน (ทั้งคู่หรือไม่ทำเลย)
        ★ 2.4.3 (ยุบ 🏷 เข้า 📝) preset = Type ที่เลือกในกล่อง 📝 แล้ว (จากรายการ · ไม่มี CT-RTK) ⇒ ไม่ถามรายการซ้ำ ·
          ไม่ตรวจตัวสะกด/ค่าใหม่ (ไม่มีทางพิมพ์เอง) · ด่านอื่นทั้งหมด + กล่องยืนยันเหมือนเดิม · preset = Type เดิม ⇒ ปรับ Type หมุดให้ตรงแปลง"""
        if feat is None or not feat.isValid():
            return False
        ptf = self._resolve_field(poly_lyr, {'type'})
        if not ptf:
            return False
        cur = self._poly_type_str(poly_lyr, feat)

        # ★ แปลงอ้างอิง: ต้องกด 🔓 ปลดล็อก L1 ก่อน — กติกาเดียวกับปุ่ม 🗑 ลบแปลง
        #   (การเปลี่ยน Type ของ L1 คือการถอดแปลงออกจากชั้นอ้างอิง ผลกระทบกว้างพอ ๆ กับลบ)
        warn_ref = cur in ("L1-RTK", "L1-TS", "CT-RTK")
        if warn_ref and not self._l1_unlocked():
            self._ask(
                QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                f"แปลงนี้เป็น {cur} (ชั้นอ้างอิงพิกัดหลัก)\n"
                "ต้องกดปุ่ม 🔓 ปลดล็อก L1 ก่อน จึงจะเปลี่ยนได้")
            return False

        # หมุดของแปลงนี้ — fail-closed เหมือนลบทั้งแปลง: อ่านไม่ได้ = ไม่ทำ
        info = self._parcel_markers(poly_lyr, point_lyr, feat)
        if info is None:
            self._ask(
                QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                "อ่านค่า UTM/รายชื่อหมุดของแปลงนี้ไม่ได้ (คีย์ว่าง หรือ query ล้มเหลว)\n"
                "— ยกเลิก (กันแก้แปลงแล้วหมุดไม่ตาม)")
            return False
        mk_ids, utm_norm, n_twin = info["mk_ids"], info["utm_norm"], info["n_twin"]
        if n_twin > 1:
            self._ask(
                QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                f"พบแปลงคีย์ซ้ำ (UTM เดียวกัน {n_twin} แปลง) — เปลี่ยนอัตโนมัติไม่ได้\n"
                "เพราะหมุดถูกแชร์ตามคีย์ จะไปโดนหมุดของแปลงแฝดด้วย · แก้คีย์ซ้ำก่อน")
            return False
        # ★ 2.4.0 (review DU-01) — หมุด Type L1 บนแปลงที่ไม่ใช่ L1: เขียน Type ใหม่ให้หมุด = ปลดล็อกหมุดถาวร ⇒ ต้องปลดล็อก L1 ก่อน
        if self._parcel_locked_block(info, "เปลี่ยน Type", "เปลี่ยน Type แปลงนี้ไม่ได้"):
            return False

        # ★ แปลงที่ไม่มีหมุดของตัวเองเลยเป็นเรื่องผิดปกติ (ผิดกติกาเหล็ก) — ถามก่อน
        if not mk_ids:
            _a = self._ask(
                QtWidgets.QMessageBox.Question, "เปลี่ยน Type",
                f"แปลงนี้ (UTM {utm_norm}) ไม่มีหมุดของตัวเองเลยสักจุด ซึ่งผิดปกติ\n"
                "จะเปลี่ยน Type ให้เฉพาะรูปแปลงต่อไปหรือไม่?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if _a != QtWidgets.QMessageBox.Yes:
                return False

        # รายการค่าให้เลือก = ค่าที่มีอยู่จริงในชั้นข้อมูล (ไม่ hardcode เผื่อสาขาใช้ค่าต่างกัน)
        # ★ 31 ส.ค. 69 — ลำดับตายตัวตามที่เจ้าของงานกำหนด ไม่เรียงตามตัวอักษร
        #   (เรียงตัวอักษรจะได้ L2-RO มาก่อน L2-TS ซึ่งสลับกับลำดับที่ใช้จริง)
        #   ไม่เสนอ CT-RTK ให้เลือก แต่ด่านกันด้านบนยังอยู่: แปลงที่ "เป็น" CT-RTK
        #   ต้องปลดล็อก L1 ก่อนถึงเปลี่ยนได้
        ORDER = ("L1-RTK", "L1-TS", "L2-TS", "L2-RO")
        NOT_OFFERED = ("CT-RTK",)
        try:
            # ★ 2.3.7 (review DI-01) — NULL จาก provider ไม่ใช่ชนิดแปลง (เดิม str() ได้ 'NULL' ⇒ โผล่ในรายการ
            #   เลือกแล้วเขียนคำว่า 'NULL' ลงแปลงและหมุด)
            found = {_txt(v) for v in
                     poly_lyr.uniqueValues(poly_lyr.fields().indexOf(ptf), 50)
                     if _txt(v)}
        except Exception:
            found = set()
        found = {v for v in found if v.upper() not in NOT_OFFERED}
        vals = list(ORDER)
        # ค่าอื่นที่มีจริงในข้อมูลแต่ไม่อยู่ในลำดับมาตรฐาน -> ต่อท้าย จะได้ไม่หายไปเงียบ ๆ
        vals += sorted(v for v in found if v not in ORDER)
        # ค่าเดิมไม่อยู่ในรายการ (NULL / CT-RTK / ค่านอกลำดับ) -> อย่าไปชี้ L1-RTK ให้
        # ใส่ค่าเดิมกลับเข้าไปเป็นตัวเลือกแรก จะได้ "กด OK เฉย ๆ = ไม่เปลี่ยนอะไร"
        if cur and cur not in vals:
            vals.insert(0, cur)
        # ★ 2.3.7 (review DI-01) — Type เดิมว่าง/NULL ⇒ ตัวเลือกแรกเป็นกลาง (เดิม idx_cur = 0 ชี้ L1-RTK ให้
        #   ⇒ กด OK = เลื่อนแปลงขึ้นเป็นชั้นอ้างอิง) · เลือกตัวนี้ = ยกเลิก
        if not cur:
            vals.insert(0, self.TYPE_KEEP)
        try:
            idx_cur = vals.index(cur) if cur in vals else 0
        except Exception:
            idx_cur = 0
        # ★ รู้ตั้งแต่ก่อนถาม ว่าจะเปลี่ยนหมุดให้ได้จริงกี่จุด — เดิมไปรู้ตอนเขียนเสร็จแล้ว
        _mtf = self._resolve_field(point_lyr, {'type'}) if mk_ids else None
        n_mk = len(mk_ids) if (mk_ids and _mtf) else 0
        if preset is None:
            new, ok = QtWidgets.QInputDialog.getItem(
                self.iface.mainWindow(), "เปลี่ยน Type",
                f"UTM: {utm_norm}\n"
                f"Type เดิม: {cur or '(ว่าง)'}\n"
                f"จะเปลี่ยนให้ทั้งแปลง 1 แปลง + หมุด {n_mk} จุด"
                + ("" if _mtf or not mk_ids else "  (ชั้นหมุดไม่มีคอลัมน์ Type — จะเปลี่ยนให้เฉพาะแปลง)")
                + "\n\n"
                "Type ใหม่ (พิมพ์เองได้):",
                vals, idx_cur, True)
            if not ok:
                return False
        else:
            new = preset                              # ★ 2.4.3 มาจากกล่อง 📝 (เลือกจากรายการแล้ว)
            # ★ 2.4.3 (review 🟡3 · รายการตายตัว) — ไม่ผ่านด่านตัวสะกด DI-55 (ไม่ได้พิมพ์เอง) ⇒ ต้องอยู่ในรายการ _CP_TYPES_ALL
            #   (ทางเรียกตรง · ปรับ Type หมุดตามแปลงที่ Type ของแปลงอยู่นอกรายการ เช่น 'L1TS' ⇒ จะลามไปหมุด)
            #   CT-RTK ไปด่านเดิมด้านล่าง (ข้อความเดิม)
            _raw = " ".join(_txt(preset).split()).upper()
            if _raw and _raw not in _TYPE_NOT_ON_MARKER and _raw not in self._CP_TYPES_ALL:
                self._ask(QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                          f"Type \"{_raw}\" ไม่อยู่ในรายการ Type ที่ใช้ได้ (" + " · ".join(self._CP_TYPES_ALL) + ")"
                          + (" — ปรับ Type ของหมุดตามแปลงไม่ได้: เลือก Type ที่ถูกต้องของแปลงจากรายการในกล่อง 📝 ก่อน"
                             if _raw == cur else " — ยกเลิก"))
                return False
        if " ".join((new or "").split()) == self.TYPE_KEEP:
            return False                              # ★ 2.3.7 DI-01 — เลือก "(ว่าง — ไม่เปลี่ยน)"
        # ★ ค่าที่พิมพ์เองต้องผ่านการปรับรูปแบบก่อน ไม่งั้นได้ ' l2-ts ' ปนกับ 'L2-TS'
        #   ในคอลัมน์เดียวกัน แล้วด่านล็อก L1 (ที่เทียบตัวพิมพ์ใหญ่) จะมองไม่เห็น
        new = " ".join((new or "").split()).upper()
        if not new:
            self.iface.messageBar().pushMessage(
                "เปลี่ยน Type", "ค่าว่าง — ยกเลิก", level=1, duration=5)
            return False
        # ★ 2.3.7 (review DI-01) — คำว่า NULL/NONE ไม่ใช่ชนิดแปลง (เดิมถูกเขียนเป็นสตริงลงแปลงและหมุด)
        if new in ("NULL", "NONE"):
            self._ask(QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                      f"\"{new}\" ใช้เป็นค่า Type ไม่ได้ — ยกเลิก")
            return False
        # ★ 2.3.7 (review DI-55) — ความยาวตามคอลัมน์จริงของทั้งสองชั้น (ค่าบวกที่น้อยกว่า · ไม่รู้ = 32 แบบเดิม)
        _lens = []
        for _l, _n in ((poly_lyr, ptf), (point_lyr, self._resolve_field(point_lyr, {'type'}))):
            try:
                _i = _l.fields().indexOf(_n) if (_l is not None and _n) else -1
                if _i >= 0 and _l.fields().at(_i).length() > 0:
                    _lens.append(_l.fields().at(_i).length())
            except Exception:
                pass
        _lim = min(_lens) if _lens else 32
        if len(new) > _lim:
            self._ask(QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                      f"ค่า Type ยาวเกินไป ({len(new)} ตัวอักษร · คอลัมน์รับได้ {_lim}) — ยกเลิก")
            return False
        # ★ 2.3.7 (review DI-55) — ค่าที่สะกดเพี้ยนจากชนิดอ้างอิง (L1-RTK / L1-TS / CT-RTK) ห้ามผ่านเงียบ ๆ
        #   เดิม 'L1TS' / 'L1 TS' / 'L1-T5' ผ่านการปรับรูปแบบแล้วถูกเขียนลงแปลง+หมุด โดยไม่ขึ้นหัวแดง
        #   "เลื่อนขึ้นเป็นชั้นอ้างอิง" และแปลงไม่ถูกล็อก (เจตนากติกาล็อก L1 หายเงียบ) แล้วยังไปโผล่ในรายการครั้งต่อไป
        def _c(x):
            return re.sub(r"[^A-Z0-9]", "", x)
        _known = {str(v).upper() for v in vals if v != self.TYPE_KEEP} | set(self._TYPE_REF.values())
        if preset is None and new not in self._TYPE_REF.values():       # ★ 2.4.3 ค่าจากกล่อง 📝 ไม่ต้องตรวจตัวสะกด
            if _c(new) in self._TYPE_REF:
                # ตัวอักษรเดียวกับชนิดอ้างอิง ต่างแค่ขีด/ช่องว่าง ⇒ เสนอตัวสะกดที่ถูก
                ถูก = self._TYPE_REF[_c(new)]
                if self._ask(QtWidgets.QMessageBox.Question, "เปลี่ยน Type",
                             f"\"{new}\" สะกดต่างจาก \"{ถูก}\" — ค่าที่สะกดต่างจะไม่ถูกนับเป็น {ถูก}\n"
                             "(แปลงจะไม่ถูกล็อกตามกติกา L1)\n\n"
                             f"ใช้ \"{ถูก}\" แทนไหม?  (No = ยกเลิก)",
                             default=QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                    return False
                new = ถูก
            elif new not in _known:
                # เพี้ยน 1 ตัวจากชนิดอ้างอิง (และไม่ใกล้ค่าอื่นที่มีอยู่แล้วกว่า เช่น 'L2 - TS' ใกล้ L2-TS) หรือขึ้นต้นด้วย L1 ⇒ ปฏิเสธ
                ใกล้ = min(self._TYPE_REF.values(), key=lambda k: _osa(_c(new), _c(k)))
                d_ref = _osa(_c(new), _c(ใกล้))
                d_oth = min([_osa(_c(new), _c(k)) for k in _known
                             if k not in self._TYPE_REF.values() and _c(k)] or [99])
                if (d_ref <= 1 and d_ref < d_oth) or _c(new).startswith("L1"):
                    แนะ = ใกล้ if (d_ref <= 1 and d_ref < d_oth) else "L1-RTK หรือ L1-TS"
                    self._ask(QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                              f"\"{new}\" คล้ายชนิดแปลงอ้างอิงแต่สะกดไม่ตรง — ถ้าบันทึกไป แปลงจะไม่ถูกล็อกตามกติกา L1\n"
                              f"ถ้าต้องการชนิดนี้ ให้เลือก {แนะ} จากรายการ — ยกเลิก")
                    return False
        # ★ rc2 (audit A3-03 · กติกาเจ้าของงาน 13 ต.ค. 69) — CT-RTK อยู่ในชั้น CT_<สาขา> เท่านั้น ⇒ ตั้งเป็น Type ไม่ได้
        #   🏷 เขียน Type ใหม่ลงทั้งแปลงและหมุด (และ F2 เขียน Type ของแปลงลงหมุด) ⇒ เดิมเกิดหมุด CT-RTK ในชั้นหมุดได้
        #   แปลงที่ "เป็น" CT-RTK อยู่แล้ว ยังเปลี่ยนเป็น Type อื่นได้ตามเดิม (ต้องปลดล็อก L1 ก่อน · ด่านด้านบน)
        if new in _TYPE_NOT_ON_MARKER:
            self._ask(QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                      f"{new} อยู่ในชั้น CT_ ของสาขาเท่านั้น — ตั้งเป็น Type ของแปลง/หมุดไม่ได้\n"
                      + ("แปลงนี้เป็น CT-RTK อยู่แล้ว: เลือก Type ที่ถูกต้องของแปลงจากรายการ" if cur == new else "ยกเลิก"))
            return False
        # ★ 2.3.7 (review DI-55) — ค่าที่ยังไม่มีในชั้นข้อมูล ⇒ ถามซ้ำ (กันพิมพ์ผิดแล้วกลายเป็นชนิดใหม่ · ปุ่มตั้งต้น No)
        #   ★ 2.4.3 ค่าจากรายการของ 📝 (เช่น L2-LM ที่ชั้นยังไม่มี) ไม่ใช่การพิมพ์ผิด ⇒ ไม่ถาม
        if preset is None and new not in _known:
            if self._ask(QtWidgets.QMessageBox.Question, "เปลี่ยน Type",
                         f"\"{new}\" เป็นค่าใหม่ที่ยังไม่มีในชั้นข้อมูล\n"
                         "จะกลายเป็นชนิดแปลงใหม่ในคอลัมน์ Type — สะกดถูกแล้วใช่ไหม?",
                         default=QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                return False
        if new == cur:
            # ★ rc1 2.4.0 (F2 · DU01) — Type แปลงถูกอยู่แล้วแต่หมุดของแปลง Type ไม่ตรง (ข้อมูลเก่า · Add Node ก่อน 2.4.0
            #   ไม่ใส่ Type · แก้แปลงจากตารางแอตทริบิวต์/SQL แล้วหมุดไม่ตาม) ⇒ เสนอปรับเฉพาะหมุดให้ตรงแปลง (ปุ่มตั้งต้น No)
            #   เดิมปฏิเสธ "ค่าเดิมอยู่แล้ว" ⇒ ต้องอ้อมด้วยการเปลี่ยนเป็น Type อื่นแล้วเปลี่ยนกลับ
            #   ด่านเดิมอยู่ครบ (อยู่ก่อนถึงตรงนี้): แปลง L1 / หมุด Type L1 ต้องปลดล็อก L1 · คีย์แฝดปฏิเสธ · แปลงไม่ถูกแตะ
            return self._change_type_sync_markers(point_lyr, mk_ids, _mtf, cur, utm=utm_norm, pgid=feat.id())

        # เลื่อน "ขึ้น" เป็นชั้นอ้างอิง = ต้องยืนยันซ้ำ (คนอื่นจะเอาแปลงนี้ไปยึดพิกัด)
        to_ref = new.upper() in ("L1-RTK", "L1-TS", "CT-RTK")
        head = ""
        if warn_ref:
            head = (f"🔴 กำลังถอดแปลงออกจากชั้นอ้างอิง ({cur} -> {new})\n"
                    "แปลงข้างเคียงที่เคยยึดพิกัดจากแปลงนี้จะไม่มีตัวอ้างอิงแล้ว\n\n")
        elif to_ref:
            head = (f"🔴 กำลังเลื่อนแปลงขึ้นเป็นชั้นอ้างอิง ({cur or '(ว่าง)'} -> {new})\n"
                    "แปลงนี้จะถูกล็อกห้ามขยับ และคนอื่นจะเอาไปใช้ยึดพิกัด\n\n")
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ยืนยันเปลี่ยน Type",
            f"{head}"
            f"UTM: {utm_norm}\n"
            f"Type: {cur or '(ว่าง)'}  ->  {new}\n\n"
            f"จะเปลี่ยน: รูปแปลง 1 แปลง + หมุดของแปลงนี้ {n_mk} จุด\n\n"
            "ยืนยัน?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return False

        # ---- ลงมือ: แปลง + หมุด ในชุดเดียวกัน ถอยพร้อมกันถ้าพลาด ----
        mtf = _mtf
        lyrs = [poly_lyr] + ([point_lyr] if (mk_ids and mtf) else [])
        # ★ 2.4.0 (review DI-15) — เปิดโหมดแก้ไขทุกชั้นก่อนเปิดคำสั่ง (เดิมไม่ดูผล) · เปิดไม่ได้ = ไม่เปลี่ยนอะไร
        if not self._ensure_editing(*lyrs, title="เปลี่ยน Type", what="ยังไม่ได้เปลี่ยน Type ของแปลงและหมุด"):
            return False
        self._op_begin(lyrs)
        for l in lyrs:
            l.beginEditCommand("Change Type")
        ok_all = True
        try:
            ok_all = bool(poly_lyr.changeAttributeValue(
                feat.id(), poly_lyr.fields().indexOf(ptf), new, feat[ptf])) and ok_all
            if mk_ids and mtf:
                midx = point_lyr.fields().indexOf(mtf)
                for mid in mk_ids:
                    ok_all = bool(point_lyr.changeAttributeValue(mid, midx, new)) and ok_all
        except Exception:
            ok_all = False
        finally:
            # ★ 2.3.7 (review DI-33) — ไม่สำเร็จ = destroyEditCommand (ย้อน + ไม่ทิ้ง Redo) แทน endEditCommand แล้ว undo()
            for l in lyrs:
                if ok_all:
                    l.endEditCommand()
                else:
                    l.destroyEditCommand()
        if not ok_all:
            # ★ แปลงเปลี่ยนแต่หมุดไม่เปลี่ยน (หรือกลับกัน) = ข้อมูลไม่ตรงกัน แย่กว่าไม่ทำเลย (ย้อนแล้วด้านบน)
            self._op_commit()
            self._ask(
                QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                "เขียนค่าไม่สำเร็จบางส่วน — ย้อนคืนทั้งชุดแล้ว (ไม่มีอะไรเปลี่ยน)")
            return False
        self._op_commit()
        # เข้าคิวล็อก — เขียนจริงตอน commit สำเร็จ (ดู _flush_type_log)
        self._pending_type_log.append({
            'lid': poly_lyr.id(), 'gid': feat.id(), 'utm': utm_norm,
            'old': cur, 'new': new, 'n_mk': n_mk,
            'ux': self._ux_mark(poly_lyr),                  # ★ 2.3.7 (audit F8) ผูกกับคำสั่งแก้ไข (ย้อนด้วย QGIS = ไม่เขียน)
            'fx': ('attr', (ptf,), (_txt(feat[ptf]),), (_txt(new),))})     # ★ b17 (audit R2-D2) Type ก่อน/หลัง
        # ★ 31 ส.ค. 69 — _locked_utm_map() แคชตาราง UTM ของแปลง L1 ไว้ทั้ง session
        #   โดยอ้างว่า "Type เปลี่ยนไม่ได้จากพนักงาน" (ดูคอมเมนต์ที่ _locked_utm_map)
        #   ปุ่มนี้ทำลายข้อสมมตินั้น -> ต้องล้างเอง ไม่งั้น
        #     ลด L1-TS -> L2-TS แล้วแปลงยัง "ถูกล็อก" ขยับไม่ได้ทั้งเซสชัน (เคสที่ใช้จริง)
        #     เลื่อนขึ้นเป็น L1 แล้วแปลงยังขยับได้ ทั้งที่ควรถูกล็อกทันที
        self._locked_cache = None
        if mk_ids and not mtf:
            self.iface.messageBar().pushMessage(
                "เปลี่ยน Type", "ชั้นหมุดไม่มีคอลัมน์ Type — เปลี่ยนให้เฉพาะรูปแปลง",
                level=1, duration=8)
        self.iface.messageBar().pushMessage(
            "เปลี่ยน Type",
            f"เปลี่ยน {cur or '(ว่าง)'} -> {new} ให้แปลง + หมุด {len(mk_ids) if mtf else 0} จุดแล้ว "
            "• กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล",
            level=0, duration=8)
        return True

    def _change_type_sync_markers(self, point_lyr, mk_ids, mtf, cur, utm=None, pgid=None):
        """★ rc1 2.4.0 (F2 · DU01) — 🏷 เลือก Type เดิมของแปลง: ปรับ Type ของหมุดของแปลงที่ไม่ตรง ให้เป็น cur
        ผู้เรียก (_change_type_execute) ผ่านด่านล็อก/คีย์แฝด/อ่านหมุดแล้ว · เขียนเฉพาะชั้นหมุดในคำสั่งเดียว (ย้อนพร้อมกัน)
        คืน True = ปรับแล้ว (รอ 💾) · False = ไม่มีอะไรต้องปรับ / ยกเลิก / เขียนไม่สำเร็จ (ย้อนทั้งชุดแล้ว)
        ★ rc1 S5 (review R3-03) — กล่องแจกแจง Type เดิมของหมุดที่ไม่ตรง และเน้นหมุดชนิดอ้างอิง (L1-RTK · L1-TS · CT-RTK) ที่จะถูก
          เขียนทับ พร้อมผลกับการล็อก · มีทั้งหมุดอ้างอิงและหมุดอื่น ⇒ ถามต่อว่าจะรวมหมุดอ้างอิงไหม (ปุ่มตั้งต้น = ไม่รวม)
          เดิมบอกแค่ "N ดวง Type ไม่ตรง" ⇒ ซ่อมหมุด Type ว่างแล้วเขียนทับ CT-RTK / ลดหมุด L1-RTK เป็น L1-TS โดยไม่รู้ตัว
        ★ rc1 S5 (review R1-01 · R3-04) — เข้าคิว Move_Log (action 'retyped' · layer 'POINT') หมุดละแถว แบบ 🏷 ปกติ
          (trigger ในฐานไม่จับการเปลี่ยน Type) · เขียนหลังชั้นหมุดบันทึกสำเร็จ (_flush_type_log) · ย้อน/ทิ้งงาน = ไม่เขียน"""
        drift = {}                                    # {fid: Type เดิม (norm_type · '' = ว่าง)}
        names = {}
        raw = {}                                      # {fid: ค่าเดิมตามที่อยู่ในชั้น (_txt)} — fx ของคิว Move_Log เทียบแบบ _fx_now
        mi = point_lyr.fields().indexOf(mtf) if (mk_ids and mtf) else -1
        if mi >= 0:
            ni = _fld_idx(point_lyr.fields(), "BND_NAME")
            it = point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(mk_ids))
                                       .setFlags(QgsFeatureRequest.NoGeometry)
                                       .setSubsetOfAttributes([i for i in (mi, ni) if i >= 0]))
            try:
                for f in it:
                    old = norm_type(f.attribute(mi))
                    if old != cur:
                        drift[f.id()] = old
                        names[f.id()] = _txt(f.attribute(ni)) if ni >= 0 else ""
                        raw[f.id()] = _txt(f.attribute(mi))
            finally:
                it.close()
        if not drift:
            self.iface.messageBar().pushMessage(
                "เปลี่ยน Type", f"ค่าเดิมอยู่แล้ว ({cur}) — ไม่มีอะไรเปลี่ยน", level=1, duration=5)
            return False
        # ★ rc2 (audit A3-03 · กติกาเจ้าของงาน 13 ต.ค. 69) — CT-RTK ไม่ใช่ "หมุดชนิดอ้างอิง" ที่ควรคงไว้: ชั้นหมุดต้องไม่มี CT-RTK
        #   ⇒ นับเป็นหมุดที่ต้องปรับตามแปลงตามปกติ (ไม่ถามกล่องที่สอง · ไม่มีบรรทัด 🔴) · บอกในกล่องแรกว่าทำไมต้องปรับ
        REF = L1_TYPES

        def _tally(olds):
            c = {}
            for o in olds:
                c[o] = c.get(o, 0) + 1
            return " · ".join(f"{o or '(ว่าง)'} {n:,}" for o, n in sorted(c.items(), key=lambda kv: (kv[0] != "", -kv[1], kv[0])))
        ref = {fid: o for fid, o in drift.items() if o in REF}
        warn = ""
        if ref:
            olds = set(ref.values())
            eff = []
            if "L1-RTK" in olds and cur == "L1-TS":
                eff.append("หมุด L1-RTK จะถูกลดเป็น L1-TS (ล็อกอ่อนลง: Transform 2 จุดไปต่อ L1-RTK ขยับได้)")
            elif olds & set(L1_TYPES) and cur not in L1_TYPES:
                eff.append("หมุด L1 จะไม่ถูกล็อกด้วย Type ของตัวเองอีก")
            warn = (f"🔴 ในนี้มีหมุดชนิดอ้างอิง {_tally(ref.values())} ดวง — ปรับแล้วจะกลายเป็น {cur}"
                    + ("\n" + " · ".join(eff) if eff else "") + "\n")
        _n_ct = sum(1 for o in drift.values() if o in _TYPE_NOT_ON_MARKER)
        if _n_ct:
            warn += f"หมุด CT-RTK {_n_ct:,} ดวง: ชั้นหมุดต้องไม่มี CT-RTK (อยู่ในชั้น CT_ เท่านั้น) — จะปรับเป็น {cur} ด้วย\n"
        if self._ask(QtWidgets.QMessageBox.Question, "เปลี่ยน Type",
                     f"แปลงนี้เป็น {cur} อยู่แล้ว แต่หมุดของแปลง {len(drift):,} ดวง Type ไม่ตรงกับแปลง\n"
                     f"Type เดิมของหมุดที่ไม่ตรง: {_tally(drift.values())}\n"
                     f"{warn}\n"
                     f"ปรับ Type ของหมุดเหล่านี้เป็น {cur} ให้ตรงแปลงไหม?  (รูปแปลงและค่าของแปลงไม่ถูกแตะ)",
                     default=QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return False
        if ref and len(ref) < len(drift):
            rest = len(drift) - len(ref)
            if self._ask(QtWidgets.QMessageBox.Question, "เปลี่ยน Type",
                         f"รวมหมุดชนิดอ้างอิง ({_tally(ref.values())}) ด้วยไหม?\n\n"
                         f"Yes = ปรับทั้ง {len(drift):,} ดวง\n"
                         f"No = ปรับเฉพาะ {rest:,} ดวงที่ไม่ใช่ชนิดอ้างอิง (หมุดชนิดอ้างอิงคงเดิม)",
                         default=QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                drift = {fid: o for fid, o in drift.items() if fid not in ref}
        if not self._ensure_editing(point_lyr, title="เปลี่ยน Type", what="ยังไม่ได้ปรับ Type ของหมุด"):
            return False
        self._op_begin([point_lyr])
        point_lyr.beginEditCommand("Sync marker Type")
        ok_all = True
        try:
            for mid in drift:
                ok_all = bool(point_lyr.changeAttributeValue(mid, mi, cur)) and ok_all
        except Exception:
            ok_all = False
        finally:
            if ok_all:
                point_lyr.endEditCommand()
            else:
                point_lyr.destroyEditCommand()
        self._op_commit()
        if not ok_all:
            self._ask(QtWidgets.QMessageBox.Warning, "เปลี่ยน Type",
                      "เขียนค่าไม่สำเร็จบางส่วน — ย้อนคืนทั้งชุดแล้ว (ไม่มีอะไรเปลี่ยน)")
            return False
        # ★ rc1 S5 (review R1-01 · R3-04) — เข้าคิว Move_Log หมุดละแถว (ผูกกับคำสั่งนี้ · ย้อนด้วย Undo/↺ = ไม่เขียน)
        _ux = self._ux_mark(point_lyr)
        for mid, old in drift.items():
            self._pending_type_log.append({
                'lid': point_lyr.id(), 'gid': mid, 'utm': utm, 'layer': 'POINT', 'bnd': names.get(mid) or None,
                'old': old, 'new': cur, 'n_mk': 1,
                'op': (f"Type หมุด {old or '(ว่าง)'} -> {cur} (ปรับให้ตรงแปลง"
                       + (f" gid {int(pgid)}" if pgid is not None else "") + f") · MLEP {self.version}"),
                'ux': _ux,
                'fx': ('attr', (mtf,), (raw.get(mid, old),), (_txt(cur),))})
        self.iface.messageBar().pushMessage(
            "เปลี่ยน Type", f"ปรับ Type หมุด {len(drift):,} ดวงเป็น {cur} ให้ตรงแปลงแล้ว • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล",
            level=0, duration=8)
        return True

    def start_parcel_info(self):
        """คลิกแปลง -> หน้าต่างข้อมูลแปลง · เครื่องมือค้างไว้แบบ Identify ของ QGIS (คลิกแปลงอื่นต่อได้ · Esc = เลิก)
        อ่านอย่างเดียว ไม่แตะ selection (ไม่เรียก cancel_transform)"""
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData()) if getattr(self, "poly_cb", None) else None
        if lyr is None or lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, self._INFO_TITLE, "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        self._dol_clear_highlight()
        canvas = self.iface.mapCanvas()
        self.temp_tool = PolygonPickTool(
            canvas, lyr, self._on_parcel_info_picked, self._dol_on_hover,
            keep_active=True, msg_title=self._INFO_TITLE, choose_prompt="เลือกแปลงที่ต้องการดูข้อมูล:")
        canvas.setMapTool(self.temp_tool)
        self.temp_tool.push_hint(                                       # ★ 2.3.7 (UX-01) ข้อความของเครื่องมือ
            self._INFO_TITLE, f"คลิกแปลงใน '{lyr.name()}' เพื่อดูเนื้อที่รูปแปลงเทียบเนื้อที่ทะเบียน (Esc = เลิก)",
            level=0, duration=8)

    def _on_parcel_info_picked(self, feat, layer):
        """callback ของ PolygonPickTool — อ่านแปลงซ้ำตาม id (= รูปปัจจุบันรวม edit buffer) แล้วแสดง"""
        f = feat
        try:
            _f = layer.getFeature(feat.id())
            if _f is not None and _f.isValid():
                f = _f
        except Exception:
            pass
        self._parcel_info_show(layer, f)

    def _geom_area_m2(self, layer, geom):
        """เนื้อที่รูปแปลง ตร.ม. — ชั้นหน่วยเมตร = ระนาบ (ตรงกับ ST_Area ใน trigger DIFF_AREA) · ชั้นองศา = บนทรงรี"""
        crs = layer.crs()
        if crs.isValid() and not crs.isGeographic() and crs.mapUnits() == QgsUnitTypes.DistanceMeters:
            return float(geom.area())
        da = QgsDistanceArea()
        da.setSourceCrs(crs, QgsProject.instance().transformContext())
        da.setEllipsoid(crs.ellipsoidAcronym() or "WGS84")
        return float(da.convertAreaMeasurement(da.measureArea(geom), QgsUnitTypes.AreaSquareMeters))

    def _parcel_info_text(self, layer, f):
        """ข้อความ (HTML) ของหน้าต่างข้อมูลแปลง — แยกจากตัวหน้าต่างให้เทสตรวจได้"""
        import html as _html
        fl = f.fields()

        def _v(name):
            i = _fld_idx(fl, name)
            return _txt(f[i]) if i >= 0 else ""
        e = _html.escape
        head = (f"ระวาง {_v('UTMMAP1')} {_v('UTMMAP2')} {_v('UTMMAP3')}-{_v('UTMMAP4') or '00'}"
                f"  |  มาตราส่วน {_v('UTMSCALE')}  |  เลขที่ดิน {_v('LANDNO')}")
        if _v("DOC_TYPE") == self._DOC_AIR and not _v("UTMMAP3"):
            # ★ 2.4.8 น.ส.3 ก = คีย์ระวางรูปถ่ายทางอากาศ (ไม่มี UTMMAP3 · แผ่นที่ 3 หลัก) — เขียนแบบหน้าค้น QNS3K "5842 III -001"
            head = (f"ระวางรูปถ่าย {_v('UTMMAP1')} {_ROMAN_OF.get(_v('UTMMAP2'), _v('UTMMAP2'))} -{_v('UTMMAP4')}"
                    f"  |  มาตราส่วน {_v('UTMSCALE')}  |  เลขที่ดิน {_v('LANDNO')}")
        pu = self._resolve_field(layer, _UTM_FIELD_NAMES)
        utm = _txt(f[pu]) if pu else ""
        g = f.geometry()
        a_geom = None
        try:
            if g is not None and not g.isEmpty():
                a_geom = self._geom_area_m2(layer, g)
        except Exception:
            a_geom = None
        a_reg = None
        ai = _fld_idx(fl, "AREA")
        if ai >= 0:
            try:
                a_reg = float(_txt(f[ai])) if _txt(f[ai]) else None
            except ValueError:
                a_reg = None
            if a_reg is not None and a_reg <= 0:
                a_reg = None
        pending = False
        try:
            eb = layer.editBuffer()
            pending = bool(eb) and f.id() in eb.changedGeometries()
        except Exception:
            pass
        regis = _v("REGIS")

        def _area(m2):
            return f"<b>{m2:,.2f}</b> ตร.ม. &nbsp;·&nbsp; <b>{_rngw(m2)}</b> ไร่-งาน-วา"
        # ★ 2.3.7 rc2 (เจ้าของงานสั่ง 4 ต.ค. 69) — แต่ละบรรทัดแสดงเต็ม ไม่ตัดขึ้นบรรทัดใหม่ (ยกเว้น caption ใต้ตาราง)
        nw = "white-space:nowrap"
        td = f"<td style='{nw}'>"
        rows = [f"<div style='font-size:13px; {nw}'><b>{e(head)}</b></div>"]
        # ★ 2.4.7 (เจ้าของงาน 26 ต.ค. 69 17:59 "แสดง gid ของแปลงในปุ่มสอบถามด้วย") — gid = รหัสแปลงในชั้น (แบบหัวกล่อง 📝) ·
        #   แปลงใหม่ที่ยังไม่บันทึกมีรหัสติดลบชั่วคราว ⇒ บอกว่ายังไม่บันทึก
        sub = [f"gid {f.id()}" if f.id() >= 0 else "gid — (ยังไม่บันทึก)"]
        if utm:
            sub.append(f"UTM {e(utm)}")
        if _public_landno(_v("LANDNO")):
            sub.append("เลขที่ดิน ≤ 0 — ไม่ใช่คีย์ทะเบียน")      # ★ 2.4.8 ที่สาธารณะ/คีย์กลุ่ม ข ที่ปลั๊กอินตั้งให้ (แผน 2.4.7 ข้อ 4)
        rows.append(f"<div style='color:#5f6368; {nw}'>{' · '.join(sub)}</div>")
        rows.append("<table cellspacing='0' cellpadding='3' style='margin-top:6px'>")
        # ★ 2.3.8 (เจ้าของงานสั่ง 8 ต.ค. 69) — ประเภทแปลง (Type) + ชนิดเอกสารสิทธิ์ (DOC_TYPE · ช่องใหม่ในฐาน 8 ต.ค.)
        #   ชั้นที่ไม่มีช่อง DOC_TYPE (ชั้นอื่น / โหลดไว้ก่อนเพิ่มช่อง) ⇒ บอกให้เปิดโปรเจกต์ใหม่ ไม่ซ่อนเงียบ (ข้อความสั้น: หน้าต่างกว้างตามบรรทัดยาวสุด)
        muted = "color:#5f6368"
        ty = _v("Type")
        rows.append(f"<tr>{td}ประเภทแปลง</td>{td}" + (f"<b>{e(ty)}</b>" if ty else f"<span style='{muted}'>ไม่มีข้อมูล</span>")
                    + "</td></tr>")
        if _fld_idx(fl, "DOC_TYPE") >= 0:
            doc = _v("DOC_TYPE")
            rows.append(f"<tr>{td}ชนิดเอกสาร</td>{td}"
                        + (f"<b>{e(self._DOC_LABEL.get(doc, doc))}</b>" if doc else f"<span style='{muted}'>ยังไม่ระบุ</span>")
                        + self._info_reg_id(fl, _v, doc) + "</td></tr>")
            # ★ 2.4.8 ที่ตั้งตามทะเบียน (TAMBOL/AMPHUR/PROVINCE · ว่างทั้งหมด/ชั้นไม่มีคอลัมน์ = ไม่มีแถว)
            _loc = " ".join(f"{t}.{e(_v(k))}" for t, k in (("ต", "TAMBOL"), ("อ", "AMPHUR"), ("จ", "PROVINCE")) if _v(k))
            if _loc:
                rows.append(f"<tr>{td}ที่ตั้งตามทะเบียน</td>{td}{_loc}</td></tr>")
        else:
            rows.append(f"<tr>{td}ชนิดเอกสาร</td>{td}<span style='{muted}'>ไม่มีในชั้นนี้ — ปิดแล้วเปิดโปรเจกต์ใหม่</span></td></tr>")
        # ★ 2.4.5 rc2 (เจ้าของงาน 23–24 ต.ค. 69) ชื่อทางสาธารณะ (parcel_name) — แสดงเมื่อมีชื่อ หรือเป็นชนิดที่ใส่ชื่อได้ (ยังไม่ระบุ) ·
        #   ตัดบรรทัดทุก ~45 ตัวอักษรแบบหมายเหตุ (ชื่อยาวได้ 100 ตัวอักษร · แถวในหน้าต่างนี้ไม่ตัดบรรทัดเอง)
        pn = _v(self._PN_FIELD)
        if pn or (_fld_idx(fl, self._PN_FIELD) >= 0 and self._pn_open(_v("DOC_TYPE"))):     # ★ 2.4.7 เฉพาะชนิดสาธารณะ (เท่า 2.4.5)
            rows.append(f"<tr>{td}{self._pn_label(_v('DOC_TYPE'))}</td>{td}"
                        + ("<b>" + "<br>".join(e(x) for x in _wrap_th(pn, 45)) + "</b>" if pn else f"<span style='{muted}'>ยังไม่ระบุ</span>")
                        + "</td></tr>")
        # ★ 2.4.7 (เจ้าของงาน 26 ต.ค. 69 18:00 "วันที่ออกเอกสาร และวันรังวัดด้วย ถ้ามี") — ISSUE_DATE · SURV_DATE ของแปลง (ปี พ.ศ.) ·
        #   ว่าง/ชั้นไม่มีคอลัมน์ = ไม่แสดง · ★ 2.4.8 (21:4x "ย้ายวันออกเอกสารกับวันรังวัดมาใส่ในบรรทัดเดียวกัน") แถวเดียว
        #   'วันที่ | ออกเอกสาร … · รังวัด …' (มีวันเดียว = แสดงวันนั้น)
        _dts = []
        for col, label in (("ISSUE_DATE", "ออกเอกสาร"), ("SURV_DATE", "รังวัด")):
            ci = _fld_idx(fl, col)
            dv = _date_val(f[ci]) if ci >= 0 else None
            if dv is not None:
                _dts.append(f"{label} <b>{e(_date_th(dv))}</b>")
        if _dts:
            rows.append(f"<tr>{td}วันที่</td>{td}{' · '.join(_dts)}</td></tr>")
        # ★ 2.3.8 (เจ้าของงานสั่ง 8 ต.ค. 69) — ผู้รับผิดชอบ (NAME) + หมายเหตุ (REMARK · แถวล่างสุด)
        who = _v("NAME")
        rows.append(f"<tr>{td}ผู้รับผิดชอบ</td>{td}" + (f"<b>{e(who)}</b>" if who else f"<span style='{muted}'>ไม่มีข้อมูล</span>")
                    + "</td></tr>")
        rows.append(f"<tr>{td}เนื้อที่รูปแปลง</td>{td}"
                    + (_area(a_geom) if a_geom is not None else "อ่านรูปแปลงไม่ได้")
                    + ("<br><span style='color:#e65100'>(รวมการแก้ไขที่ยังไม่บันทึก)</span>" if pending else "")
                    + "</td></tr>")
        rows.append(f"<tr>{td}เนื้อที่ทะเบียน</td>{td}"
                    + (_area(a_reg) if a_reg is not None else "ไม่มีข้อมูลเนื้อที่ทะเบียน")
                    + (f"<br><span style='color:#b71c1c'>({e(regis)})</span>"
                       if regis and regis != "มีทะเบียน" else "")
                    + "</td></tr>")
        if a_geom is not None and a_reg is not None:
            d = a_geom - a_reg
            # ★ 2.3.7 rc2 (เจ้าของงานสั่ง 4 ต.ค. 69) — "ต่างจากทะเบียน ±ตร.ม. (±%)" (เดิม "เนื้อที่รูปแปลงต่างจากทะเบียน" + ตร.ว.)
            rows.append(f"<tr>{td}ต่างจากทะเบียน</td>"
                        f"{td}<b>{d:+,.2f}</b> ตร.ม. ({d / a_reg * 100.0:+.2f}%)</td></tr>")
        else:
            rows.append(f"<tr>{td}ต่างจากทะเบียน</td>{td}เทียบไม่ได้</td></tr>")
        # หมายเหตุเป็นข้อความที่พนักงานพิมพ์เอง (ยาวได้) — แถวในหน้าต่างนี้ไม่ตัดบรรทัด ⇒ ตัดเองทุก ~45 ตัวอักษร (~400 px · จอเล็กก็ไม่ล้น)
        #   (ไม่ตัดหน้าสระ/วรรณยุกต์ที่ซ้อนบน-ล่าง) กันหน้าต่างกว้างล้นจอ · escape ทีละท่อนแล้วค่อยต่อด้วย <br>
        note = _v("REMARK")
        rows.append(f"<tr>{td}หมายเหตุ</td>{td}"
                    + ("<br>".join(e(x) for x in _wrap_th(note, 45)) if note else f"<span style='{muted}'>-</span>")
                    + "</td></tr>")
        rows.append("</table>")
        return "".join(rows)

    def _info_reg_id(self, fl, _v, doc):
        """★ 2.4.8 (แผน 2.4.7 ข้อ 4 · เจ้าของงาน 26 ต.ค. 69 16:37 "ปรับปุ่มสอบถามในปลั๊กอินตามประเภทเอกสารสิทธิ์ด้วย") — ตัวตนของเอกสาร
        จากคอลัมน์ทะเบียน ต่อท้ายชนิดเอกสาร: ' เลขที่ 15973 · หน้าสำรวจ 3163' (โฉนด) · ' เลขที่ 45 · หมู่ 10' (น.ส.3) · ยังไม่มีเลข + ชนิดที่มี
        ทะเบียนให้ค้น ⇒ บอกสั้น ๆ (ผู้ดูแลเห็นว่า 📝 ค้นได้) · ชนิดสาธารณะ/ท.ค./อื่นๆ (_pn_open) และชั้นที่ไม่มีคอลัมน์ ⇒ ''"""
        import html as _html
        if _fld_idx(fl, "PARCEL_NO") < 0:
            return ""
        no = _v("PARCEL_NO")
        if no:
            return " เลขที่ " + " · ".join([f"<b>{_html.escape(no)}</b>"] + [
                f"{lab} <b>{_html.escape(_v(k))}</b>" for lab, k in (("หน้าสำรวจ", "SURVEY_NO"), ("หมู่", "MOO")) if _v(k)])
        seq = _v("REG_SEQ") if _fld_idx(fl, "REG_SEQ") >= 0 else ""
        if seq:
            # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 ⚪B5) ผูกทะเบียนแล้ว (มีลำดับที่เอกสารสิทธิ) แต่ไม่มีเลขที่ — เดิมบอก "ยังไม่มีเลขทะเบียนในฐาน"
            return f" · <span style='color:#5f6368'>มีลำดับที่ในทะเบียน {_html.escape(seq)} (ยังไม่มีเลขที่เอกสารในฐาน)</span>"
        if doc and not self._pn_open(doc):
            return (" · <span style='color:#5f6368'>ยังไม่มีเลขทะเบียนในฐาน" + (" — 📝 ค้นได้" if self._is_admin() else "")
                    + "</span>")
        return ""

    def _parcel_info_show(self, layer, f):
        """หน้าต่างข้อมูลแปลง — ไม่ modal ลอยเหนือ QGIS · ใช้หน้าต่างเดิมซ้ำทุกคลิก"""
        dlg = getattr(self, "_info_dlg", None)
        if dlg is None:
            dlg = QtWidgets.QDialog(self.iface.mainWindow())
            dlg.setWindowFlags(dlg.windowFlags() | QtCore.Qt.Tool)
            dlg.setWindowTitle("ℹ️ ข้อมูลแปลง")
            lay = QtWidgets.QVBoxLayout(dlg)
            lbl = QtWidgets.QLabel()
            lbl.setTextFormat(QtCore.Qt.RichText)
            lbl.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
            lbl.setWordWrap(False)        # ★ 2.3.7 rc2 — บรรทัดข้อมูลไม่ตัด (หน้าต่างกว้างตามบรรทัดที่ยาวที่สุด)
            # ★ 2.3.9 — จอเล็ก: ข้อมูลอยู่ในกรอบเลื่อน · กรอบขยายตามข้อความแต่ไม่เกินจอ (ดู _info_fit_screen)
            _isc = QtWidgets.QScrollArea(dlg)
            _isc.setWidgetResizable(True)
            _isc.setFrameShape(QtWidgets.QFrame.NoFrame)
            _isc.setWidget(lbl)
            self._info_scroll = _isc
            lay.addWidget(_isc)
            cap = QtWidgets.QLabel(self._INFO_CAPTION)
            cap.setWordWrap(True)
            cap.setStyleSheet("color:#5f6368; font-size:11px; padding-top:6px;")
            lay.addWidget(cap)
            btn = QtWidgets.QPushButton("ปิด")
            btn.clicked.connect(dlg.close)
            row = QtWidgets.QHBoxLayout()
            row.addStretch(1)
            row.addWidget(btn)
            lay.addLayout(row)
            dlg.setMinimumWidth(420)
            self._info_dlg, self._info_lbl = dlg, lbl
        self._info_lbl.setText(self._parcel_info_text(layer, f))
        self._info_fit_screen()
        dlg.adjustSize()                  # ★ 2.3.7 rc2 — ปรับขนาดตามข้อความของแปลงที่คลิกล่าสุด (caption ตัดบรรทัดตามความกว้างนี้)
        dlg.show()
        dlg.raise_()

    def _info_fit_screen(self):
        """★ 2.3.9 — กรอบข้อมูลของ ℹ️ ขยายพอดีข้อความ แต่ไม่เกิน 90% กว้าง / 75% สูงของจอ (เกิน = เลื่อนดูในกรอบ)
        ตั้งเป็น minimumSize ของกรอบเลื่อน ⇒ adjustSize ของหน้าต่างยังขยายตามข้อความได้เหมือน 2.3.8"""
        sc, lbl, dlg = getattr(self, "_info_scroll", None), getattr(self, "_info_lbl", None), getattr(self, "_info_dlg", None)
        if sc is None or lbl is None or dlg is None:
            return
        try:
            scr = dlg.screen() if (dlg.isVisible() and hasattr(dlg, "screen")) else None
            if scr is None:
                mw = self.iface.mainWindow()
                scr = mw.screen() if (mw is not None and hasattr(mw, "screen")) else None
            if scr is None:
                scr = QtWidgets.QApplication.primaryScreen()
            ag = scr.availableGeometry() if scr is not None else QtCore.QRect(0, 0, 1280, 900)
            h = lbl.sizeHint()
            bar = sc.verticalScrollBar().sizeHint().width()
            w_cap, h_cap = int(ag.width() * 0.9) - 40, int(ag.height() * 0.75)
            need_w, need_h = h.width() + 4, h.height() + 4
            sc.setMinimumSize(min(need_w + (bar if need_h > h_cap else 0), w_cap), min(need_h, h_cap))
        except Exception:
            pass
