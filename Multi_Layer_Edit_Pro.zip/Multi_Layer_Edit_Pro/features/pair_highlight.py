# -*- coding: utf-8 -*-
"""แถบ 📍 หลังคำเตือนจับคู่ตอนบันทึก (review UX-09): ทำเครื่องหมายทุกจุดที่ต้องแก้บนแผนที่ และพาไปดูทีละจุด

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import Qgis, QgsCoordinateTransform, QgsPointXY, QgsProject, QgsRectangle
from qgis.gui import QgsVertexMarker
from ..core.util import _log_exc
from ..ui.qt_helpers import _EscWatch


class PairHighlightMixin:
    """แถบ 📍 หลังคำเตือนจับคู่ตอนบันทึก (review UX-09): ทำเครื่องหมายทุกจุดที่ต้องแก้บนแผนที่ และพาไปดูทีละจุด"""

    def _pair_hl_offer(self, issues):
        """★ 2.4.0 (review UX-09) — ทำเครื่องหมายทุกจุดของผลด่านจับคู่ (list ของ _PairIssues · ตัดจุดซ้ำ) + แถบพาไปดู
        แทนชุดเดิมเสมอ · ไม่มีจุด = ล้างชุดเดิมอย่างเดียว · ห้ามเรียกระหว่าง commitChanges (ดู _pair_hl_after_commit)"""
        self._pair_hl_reset()
        pts, seen = [], set()
        for iss in issues or ():
            crs = getattr(iss, "crs", None) or (None, None)
            for kind, x, y, src, utm in (getattr(iss, "points", None) or ()):
                # ★ 2.4.0 (review UX-09) — คีย์มี UTM ด้วย: มุมร่วมของแปลงติดกัน (คนละ UTM) ที่ขาดหมุดทั้งคู่ = 2 จุดตามที่ด่านนับ
                #   (เดิมตัดเหลือจุดเดียว ⇒ แถบนับน้อยกว่า "ทั้ง N จุด" ในกล่อง และ ◀ ▶ ไม่บอก UTM ของแปลงที่สอง)
                #   ตัดเฉพาะจุดเดียวกันทุกอย่างที่ซ้ำข้ามผลหลายชุด (คู่ชั้น commit ต่อกัน)
                key = (kind, round(x, 3), round(y, 3), src, utm)
                if key in seen:
                    continue
                seen.add(key)
                pts.append((kind, x, y, crs[0] if src == 'poly' else crs[1], utm))
        if not pts:
            return
        self._pair_hl_pts = pts
        self._pair_hl_draw()
        self._pair_hl_bar()

    def _pair_hl_xy(self, rec, cache=None):
        """จุดใน CRS ของชั้น -> CRS ของแผนที่ (ตอนวาด/ไป — แผนที่เปลี่ยน CRS ภายหลังก็ยังถูก) · แปลงไม่ได้ = None"""
        _k, x, y, crs, _u = rec
        try:
            q = QgsPointXY(x, y)
            dst = self.iface.mapCanvas().mapSettings().destinationCrs()
            if crs is not None and crs.isValid() and dst.isValid() and crs != dst:
                key = crs.authid() or crs.toWkt()
                ct = cache.get(key) if cache is not None else None
                if ct is None:
                    ct = QgsCoordinateTransform(crs, dst, QgsProject.instance())
                    if cache is not None:
                        cache[key] = ct
                q = QgsPointXY(ct.transform(q))
            return q
        except Exception:
            return None

    def _pair_hl_draw(self):
        """วาดเครื่องหมายของทุกจุด (ไม่เกิน _PAIR_HL_MAX_MARKS) แทนชุดเดิม + เปิดตัวดัก Esc บนแผนที่"""
        self._pair_hl_clear_marks()
        canvas = self.iface.mapCanvas()
        cache, marks = {}, []
        for rec in (getattr(self, "_pair_hl_pts", None) or [])[:self._PAIR_HL_MAX_MARKS]:
            q = self._pair_hl_xy(rec, cache)
            if q is None:
                continue
            icon, rgb = self._PAIR_HL_STYLE.get(rec[0], self._PAIR_HL_STYLE['stray'])
            m = QgsVertexMarker(canvas)
            m.setIconType(icon)
            m.setColor(QtGui.QColor(*rgb))
            m.setPenWidth(3)
            m.setIconSize(18)
            m.setCenter(q)
            m.show()
            marks.append(m)
        self._pair_hl_marks = marks
        if marks:
            self._pair_hl_esc(True)

    def _pair_hl_clear_marks(self):
        """เก็บเครื่องหมายบนแผนที่ (แถบ + รายการจุดยังอยู่ — ◀ ▶ วาดใหม่ได้) · เรียกซ้ำได้"""
        marks = list(getattr(self, "_pair_hl_marks", None) or [])
        cur = getattr(self, "_pair_hl_cur", None)
        self._pair_hl_marks, self._pair_hl_cur = [], None
        if cur is not None:
            marks.append(cur)
        if marks:
            try:
                scene = self.iface.mapCanvas().scene()
                for m in marks:
                    try:
                        scene.removeItem(m)
                    except Exception:
                        pass
            except Exception:
                pass
        self._pair_hl_esc(False)

    def _pair_hl_esc(self, on):
        """ติด/ถอดตัวดัก Esc บนแผนที่ (ตัวดักสร้างครั้งเดียว เก็บไว้บน self — ถอดจากในตัวดักเองได้ ไม่ถูกลบกลางทาง)"""
        f = getattr(self, "_pair_hl_filter", None)
        if bool(on) == bool(getattr(self, "_pair_hl_filter_on", False)):
            return
        try:
            cv = self.iface.mapCanvas()
            if on:
                if f is None:
                    f = self._pair_hl_filter = _EscWatch(self._pair_hl_clear_marks)
                cv.installEventFilter(f)
            elif f is not None:
                cv.removeEventFilter(f)
            self._pair_hl_filter_on = bool(on)
        except Exception:
            self._pair_hl_filter_on = False

    def _pair_hl_half(self):
        """ครึ่งความกว้างกรอบตอนพาไปดูทีละจุด (หน่วยแผนที่): 15 ม. · แผนที่องศา ≈ 15 ม."""
        try:
            geo = self.iface.mapCanvas().mapSettings().destinationCrs().isGeographic()
        except Exception:
            geo = False
        return 0.00015 if geo else 15.0

    def _pair_hl_text(self):
        pts = getattr(self, "_pair_hl_pts", None) or []
        n, i = len(pts), getattr(self, "_pair_hl_i", -1)
        if 0 <= i < n:
            k, x, y, _c, u = pts[i]
            return f"จุด {i + 1:,}/{n:,}: {self._PAIR_HL_WHAT.get(k, k)} — ระวาง/UTM {u} ที่ {x:.2f}, {y:.2f}"
        cnt = {}
        for rec in pts:
            cnt[rec[0]] = cnt.get(rec[0], 0) + 1
        leg = [f"{s} = {self._PAIR_HL_WHAT[k]} {cnt[k]:,}" for k, s in
               (('bare', "กากบาทเขียว"), ('stacked', "กรอบส้ม"), ('stray', "วงแดง"), ('orphan', "วงแดง")) if cnt.get(k)]
        t = f"{n:,} จุด ({' · '.join(leg)}) — กด ถัดไป ▶ เพื่อไปทีละจุด"
        if n > self._PAIR_HL_MAX_MARKS:
            t += f" · แสดงเครื่องหมาย {self._PAIR_HL_MAX_MARKS:,} จุดแรก (◀ ▶ ไล่ได้ครบทุกจุด)"
        return t + " · Esc/เปลี่ยนเครื่องมือ = เก็บเครื่องหมาย (กด ◀ ▶ แสดงใหม่)"

    def _pair_hl_set_text(self):
        it = getattr(self, "_pair_hl_item", None)
        if it is not None:
            try:
                it.setText(self._pair_hl_text())
            except Exception:
                pass

    def _pair_hl_bar(self):
        """แถบข้อความค้าง (ปิดเอง/ซ่อน) พร้อมปุ่มพาไปดู — ทำไม่ได้ ⇒ เครื่องหมายบนแผนที่อย่างเดียว"""
        try:
            from qgis.gui import QgsMessageBar
            item = QgsMessageBar.createMessage("📍 จุดที่ต้องแก้บนแผนที่", self._pair_hl_text())
            btns = []
            for label, fn in (("🔍 ดูทั้งหมด", self._pair_hl_all),
                              ("◀ ก่อนหน้า", lambda: self._pair_hl_go(-1)),
                              ("ถัดไป ▶", lambda: self._pair_hl_go(1)),
                              ("ซ่อน", self._pair_hl_reset)):
                b = QtWidgets.QPushButton(label)
                # ★ 2.4.0 (review UX-09) — ปุ่มไม่รับโฟกัส: กด ◀ ▶ 🔍 แล้วโฟกัสยังอยู่ที่แผนที่ ⇒ Esc ถึงตัวดักบนแผนที่
                #   (เดิมโฟกัสย้ายมาที่ปุ่ม Esc ไม่ถึงแผนที่ ต้องคลิกแผนที่ก่อน ซึ่งอาจไปสั่งเครื่องมือที่ใช้อยู่)
                b.setFocusPolicy(QtCore.Qt.NoFocus)
                b.clicked.connect(lambda *_a, _f=fn: _f())
                item.layout().addWidget(b)
                btns.append(b)
            item._mlep_btns = btns
            # ผู้ใช้ปิดแถบเอง (✕) ⇒ เก็บเครื่องหมายด้วย · แถบที่ปลั๊กอินถอดเอง (รุ่นเก่ากว่า _pair_hl_gen) ไม่แตะชุดใหม่
            _gen = getattr(self, "_pair_hl_gen", 0)
            item.destroyed.connect(lambda *_a, _g=_gen: self._pair_hl_gone(_g))
            self.iface.messageBar().pushWidget(item, Qgis.Warning, 0)
            self._pair_hl_item = item
        except Exception:
            _log_exc("แถบจุดที่ต้องแก้ (UX-09)")

    def _pair_hl_gone(self, gen):
        if not getattr(self, "_alive", True) or gen != getattr(self, "_pair_hl_gen", 0):
            return
        self._pair_hl_item = None
        self._pair_hl_clear_marks()
        self._pair_hl_pts = []
        self._pair_hl_i = -1

    def _pair_hl_reset(self):
        """ล้างทั้งหมด: เครื่องหมาย + แถบ + รายการจุด (บันทึกครั้งถัดไป · เปลี่ยนโปรเจกต์ · unload · ปุ่มซ่อน) · เรียกซ้ำได้"""
        self._pair_hl_gen = getattr(self, "_pair_hl_gen", 0) + 1
        self._pair_hl_clear_marks()
        self._pair_hl_pts = []
        self._pair_hl_i = -1
        it, self._pair_hl_item = getattr(self, "_pair_hl_item", None), None
        if it is not None:
            try:
                from qgis.PyQt import sip
                if not sip.isdeleted(it):
                    self.iface.messageBar().popWidget(it)
            except Exception:
                pass

    def _pair_hl_go(self, step):
        """◀ (-1) / ▶ (+1): ไปจุดก่อนหน้า/ถัดไป (วนรอบ) — เครื่องหมายถูกเก็บไปแล้ว (Esc/เปลี่ยนเครื่องมือ) ⇒ วาดใหม่
        แผนที่ซูมออกไกล ⇒ ซูมเข้ากรอบ ~30 ม. รอบจุด · ใกล้อยู่แล้ว ⇒ เลื่อนให้จุดอยู่กลางจอ (คงระดับซูมของผู้ใช้)"""
        pts = getattr(self, "_pair_hl_pts", None) or []
        if not pts:
            return
        if not getattr(self, "_pair_hl_marks", None):
            self._pair_hl_draw()
        n, i = len(pts), getattr(self, "_pair_hl_i", -1)
        i = (i + step) % n if i >= 0 else (0 if step > 0 else n - 1)
        self._pair_hl_i = i
        q = self._pair_hl_xy(pts[i])
        if q is not None:
            cv = self.iface.mapCanvas()
            h = self._pair_hl_half()
            ext = cv.extent()
            if ext.isEmpty() or max(ext.width(), ext.height()) > 16 * h:
                cv.setExtent(QgsRectangle(q.x() - h, q.y() - h, q.x() + h, q.y() + h))
            else:
                cv.setCenter(q)
            cv.refresh()        # ★ 2.4.0 (review UX-09) — setExtent/setCenter ไม่สั่งวาดใหม่เอง (เดิมเห็นภาพเก่ายืดเป็นพิกเซลใหญ่)
            cur = getattr(self, "_pair_hl_cur", None)
            if cur is None:
                cur = QgsVertexMarker(cv)
                cur.setIconType(QgsVertexMarker.ICON_CIRCLE)
                cur.setColor(QtGui.QColor(0, 120, 255))      # วงฟ้าใหญ่ = จุดที่กำลังดู
                cur.setPenWidth(3)
                cur.setIconSize(34)
                self._pair_hl_cur = cur
                self._pair_hl_esc(True)
            cur.setCenter(q)
            cur.show()
        self._pair_hl_set_text()

    def _pair_hl_all(self):
        """🔍 ดูทั้งหมด: วาดเครื่องหมาย (ถ้าถูกเก็บ) แล้วซูมให้เห็นทุกจุด"""
        pts = getattr(self, "_pair_hl_pts", None) or []
        if not pts:
            return
        if not getattr(self, "_pair_hl_marks", None):
            self._pair_hl_draw()
        cache, xs, ys = {}, [], []
        for rec in pts:
            q = self._pair_hl_xy(rec, cache)
            if q is not None:
                xs.append(q.x())
                ys.append(q.y())
        if not xs:
            return
        pad = max(self._pair_hl_half(), 0.1 * max(max(xs) - min(xs), max(ys) - min(ys)))
        cv = self.iface.mapCanvas()
        cv.setExtent(QgsRectangle(min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad))
        cv.refresh()            # ★ 2.4.0 (review UX-09) — setExtent ไม่สั่งวาดใหม่เอง

    def _pair_hl_after_commit(self, iss):
        """ทางบันทึกของ QGIS (afterCommitChanges — ยังอยู่ใน commitChanges ⇒ ห้ามสร้าง canvas item ตรงนี้)
        รวมผลของทุกชั้นที่ commit ในรอบเดียวกัน (Save All Edits commit คู่ชั้นต่อกัน) แล้วทำทีเดียวหลัง event loop ว่าง"""
        b = getattr(self, "_pair_hl_batch", None)
        if b is None:
            self._pair_hl_batch = b = []
            QtCore.QTimer.singleShot(0, self._pair_hl_settle)
        if iss and iss[0]:
            b.append(iss)

    def _pair_hl_settle(self):
        b, self._pair_hl_batch = getattr(self, "_pair_hl_batch", None) or [], None
        if not getattr(self, "_alive", True):
            return
        try:
            self._pair_hl_offer(b)      # บันทึกแล้ว = ล้างชุดเดิมเสมอ · พบปัญหาใหม่ = ชุดใหม่
        except Exception:
            _log_exc("ทำเครื่องหมายจุดที่ต้องแก้หลังบันทึก (UX-09)")
