# -*- coding: utf-8 -*-
"""Score, Remark, ผู้รับผิดชอบ (Owner), Audit, Cluster ID และล้าง Score

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import re
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import QgsExpressionContextUtils, QgsFeatureRequest, QgsProject
from ..core.util import _is_l1, _is_sql_null, _log_exc, _natkey, _norm_utm, _txt, _UTM_FIELD_NAMES


class AttributesMixin:
    """Score, Remark, ผู้รับผิดชอบ (Owner), Audit, Cluster ID และล้าง Score"""

    def set_score_value(self, value):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย score จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())

        # ตรวจสอบกฎการห้ามใส่ Score ให้กับแปลง L1-RTK และ L1-TS
        # ★ 2.3.7 (review PF-02) — ค่า SCORE เดิมอ่านมาในคำขอเดียวกับด่าน L1 (ส่งเป็น oldValue · ข้ามแถวที่ค่าเท่าเดิม)
        เดิม = {}                                   # lyr.id() -> {fid: ค่า SCORE เดิมดิบ}
        if poly_layer:
            poly_ids = poly_layer.selectedFeatureIds()
            if poly_ids:
                fl = poly_layer.fields()
                type_idx = self._field_index(fl, 'type')
                s_idx = self._field_index(fl, 'score')
                cols = self._sheet_cols(poly_layer)
                _uf0 = self._resolve_field(poly_layer, _UTM_FIELD_NAMES)
                u_idx = fl.indexOf(_uf0) if _uf0 else -1
                req_type = (QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry)
                            .setSubsetOfAttributes(sorted({i for i in [type_idx, s_idx, u_idx] + cols if i != -1})))
                l1, o = [], {}
                _fit3382 = poly_layer.getFeatures(req_type)
                try:
                    for f in _fit3382:
                        if s_idx != -1:
                            o[f.id()] = f.attribute(s_idx)
                        # ★ 2.3.7 (review UX-06 / DI-01) — นับแปลง L1 "ทุกแปลง" (เดิมหยุดที่แปลงแรกแล้วบอกแค่ fid)
                        if type_idx != -1 and _is_l1(f.attribute(type_idx)):
                            l1.append(f"{self._sheet_of(f, cols, f.attribute(u_idx) if u_idx != -1 else None)}"
                                      f" ({_txt(f.attribute(type_idx)).upper()})")
                finally:
                    _fit3382.close()
                if l1 and not self._l1_unlocked():
                    # ★ 2.3.7 (review UX-06) — นโยบายเดิม (ปฏิเสธทั้งงาน) แต่บอกว่าแปลงไหนด้วยระวาง+เลขที่ดิน ไม่ใช่ fid
                    #   (5 แปลงแรก + "อีก N แปลง" · รายชื่อเต็มลง Log Messages แท็บ MLEP)
                    self.iface.messageBar().pushMessage(
                        "Score Blocked",
                        f"ในสิ่งที่เลือกมีแปลงประเภท L1 (ชั้นอ้างอิง) {len(l1):,} แปลง: "
                        f"{self._name_list('Score Blocked — แปลง L1 ในสิ่งที่เลือก', l1)} "
                        "— ไม่อนุญาตให้ตั้งค่า Score!",
                        level=1, duration=10     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                    )
                    return
                เดิม[poly_layer.id()] = o

        # ★ ด่านฝั่ง "หมุด" (2026-08-06): ถ้าเลือกเฉพาะหมุด (ไม่ได้เลือกแปลง) ด่านบนจะข้ามทั้งก้อน
        #   เพราะ process_selection('utm') จะ return ทันทีเมื่อชั้นแปลงไม่มี selection
        #   -> เดิมเขียน Score ทับหมุดของแปลง L1 ได้ · ใช้กลไกเดียวกับ execute_tool
        # ★ 2.4.0 (review DU-01) — ไม่มีชั้นแปลงก็ยังตรวจ Type ของหมุดเอง (ตาราง UTM ล็อก = {})
        if point_layer and point_layer.selectedFeatureCount() > 0:
            locked_map = (self._locked_map_or_block(poly_layer, "Score Blocked")   # ★ 2.3.7 fail-closed (PF-01)
                          if poly_layer else {})
            if locked_map is None:
                return
            _uf = self._resolve_field(point_layer, _UTM_FIELD_NAMES)
            _ui = point_layer.fields().indexOf(_uf) if _uf else -1
            _si = self._field_index(point_layer.fields(), 'score')
            _ti = self._field_index(point_layer.fields(), 'type')     # ★ 2.4.0 (DU-01) Type ของหมุดเอง
            _req = QgsFeatureRequest().setFilterFids(point_layer.selectedFeatureIds()) \
                                      .setFlags(QgsFeatureRequest.NoGeometry)
            _sub = [i for i in (_ui, _si, _ti) if i != -1]
            if _sub:
                _req.setSubsetOfAttributes(_sub)
            โดน, n_โดน, po = {}, 0, {}
            n_ไม่มี_utm = 0                     # ★ 2.4.0 (DU-01) หมุด Type L1 ที่ UTM ว่าง/ไม่ตรงแปลง L1 (บอกเป็นจำนวน)
            _fit3407 = point_layer.getFeatures(_req)
            try:
                for _pf in _fit3407:
                    if _si != -1:
                        po[_pf.id()] = _pf.attribute(_si)
                    # ★ 2.4.0 (review DU-01) — กติกาเดียว (_marker_locked): Type ของหมุดเอง หรือ UTM ตรงแปลง L1
                    #   เดิมตรวจเฉพาะ UTM และข้ามทั้งด่านเมื่อชั้นไม่มีแปลง L1 ⇒ หมุด Type L1 ที่ UTM ว่าง/ไม่ตรงแปลง L1 ได้ Score
                    _locked, _tp = self._marker_locked(_pf, locked_map, _uf, _ti)
                    if _locked:
                        n_โดน += 1
                        _k = _norm_utm(_pf[_uf]) if _uf else ""
                        # ★ 2.4.0 (review DU-01 รอบตรวจทาน) — ลงรายชื่อ "แปลง L1 เจ้าของหมุด" เฉพาะเมื่อ UTM ตรงแปลง L1 จริง
                        #   (เดิมหมุด Type L1 บนแปลง L2 ขึ้น "UTM U3 (L1-TS)" อ่านเหมือนแปลง U3 เป็น L1) ⇒ ที่เหลือนับเป็นจำนวน
                        if _txt(_k) and not _k.startswith("\x00") and _k in (locked_map or {}):
                            if โดน.get(_k) != "L1-RTK":
                                โดน[_k] = _tp
                        else:
                            n_ไม่มี_utm += 1
            finally:
                _fit3407.close()
            if n_โดน:
                # ★ 2.3.7 (review UX-06) — บอกแปลงเจ้าของหมุด (เดิมบอกแค่ชนิด ไม่รู้ว่าหมุดของแปลงไหน)
                _ชื่อ = [s for s in (
                    ((self._l1_owner_names(poly_layer, โดน, 'Score Blocked — แปลง L1 เจ้าของหมุดที่เลือก') if poly_layer
                      else self._name_list('Score Blocked — หมุด L1 ที่เลือก',
                                           [f"UTM {k} ({t})" for k, t in โดน.items()])) if โดน else ""),
                    (f"หมุดที่ Type เป็น L1 (UTM ว่าง/ไม่ตรงแปลง L1) {n_ไม่มี_utm:,} หมุด" if n_ไม่มี_utm else "")) if s]
                self.iface.messageBar().pushMessage(
                    "Score Blocked",
                    f"มีหมุด L1 / หมุดของแปลงประเภท L1 (ชั้นอ้างอิง) อยู่ในสิ่งที่เลือก {n_โดน:,} หมุด — ได้แก่ "
                    f"{' · '.join(_ชื่อ)} "
                    "— ไม่อนุญาตให้ตั้งค่า Score!",
                    level=1, duration=10)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                return
            เดิม[point_layer.id()] = po

        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return

        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        # ★ 2.3.7 (review PF-02 / DI-28) — เขียนเฉพาะแถวที่ค่าเปลี่ยนจริง + ส่งค่าเดิม (Undo ไม่ต้องอ่านฐานทีละแถว ·
        #   ไม่ส่ง UPDATE เปล่าที่ทำให้ trigger ประทับชื่อคนแก้ทับแปลงที่ไม่ได้แก้) · ชั้นที่ไม่มีอะไรเปลี่ยน = ไม่เปิดแก้ไข/command
        แผน, เท่าเดิม = [], 0
        for lyr in layers:
            idx = self._field_index(lyr.fields(), 'score')
            if idx == -1:
                # ★ 2.3.7 (review ER-06 · UX-35) — หัวข้อไทย · เป็นการข้ามชั้น (ปฏิเสธ) ไม่ใช่ความล้มเหลว ⇒ เหลือง
                self.iface.messageBar().pushMessage(
                    "Score", f"ชั้น '{lyr.name()}' ไม่มีคอลัมน์ Score — ข้ามชั้นนี้", level=1, duration=8)
                continue
            o = เดิม.get(lyr.id())
            if o is None:
                o = self._read_attr(lyr, lyr.selectedFeatureIds(), idx)
            todo = [fid for fid, v in o.items() if _txt(v) != _txt(value)]
            เท่าเดิม += len(o) - len(todo)
            if todo:
                แผน.append((lyr, idx, todo, o))
        if not แผน:
            if เท่าเดิม:
                self.iface.messageBar().pushMessage(
                    "Score", f"สิ่งที่เลือกมี Score = {value} อยู่แล้ว — ไม่มีอะไรเปลี่ยน", level=0, duration=5)
            QtCore.QTimer.singleShot(100, self.restore_selection)
            return

        # ★ 2.4.0 (review DI-15) — เปิดโหมดแก้ไข "ทุกชั้นในแผน" ก่อนเขียนชั้นแรก (เดิมเปิดทีละชั้นในลูปและไม่ดูผล
        #   ⇒ ชั้นหมุดเปิดไม่ได้ = Score ลงแปลงแต่หมุดไม่ลง เงียบ ๆ) · เปิดไม่ได้ = ไม่เขียนชั้นใดเลย
        if not self._ensure_editing(*[e[0] for e in แผน], title="Score", what="ยังไม่ได้ตั้ง Score ให้ชั้นใดเลย"):
            QtCore.QTimer.singleShot(100, self.restore_selection)
            return
        self._op_begin([e[0] for e in แผน])   # เริ่มนับ undo-step ต่อเลเยอร์
        ผล = {}
        _errs = []
        for lyr, idx, todo, o in แผน:
            # 1 undo step ต่อชั้น · นับผล True · 0 แถว = destroyEditCommand (_write_attr)
            n, e = self._write_attr(lyr, f"Change Score to {value}", todo, idx, value, o)
            ผล[lyr.id()] = n
            if e is not None:
                # ★ 2.3.7 (review ER-06) — เดิม 'Error' + ข้อความ exception ดิบ · ชั้นนี้ถูกย้อนทั้งคำสั่งแล้ว (อีกชั้นอาจเขียนไปแล้ว)
                #   · traceback อยู่ใน Log (_write_attr)
                _errs.append(f"ตั้ง Score ให้ชั้น '{lyr.name()}' ไม่สำเร็จ — ชั้นนี้ไม่ถูกแก้")

        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        n_poly = ผล.get(poly_layer.id(), 0) if poly_layer else 0
        n_pt = ผล.get(point_layer.id(), 0) if point_layer else 0
        _summ = (f"ตั้ง Score = {value} ให้ {n_poly:,} แปลง · {n_pt:,} หมุด"
                 + (f" · {เท่าเดิม:,} รายการมีค่านี้อยู่แล้ว" if เท่าเดิม else ""))
        if _errs:
            # ★ rc2 (audit A3-06) — ข้อความเดียว (แดง · ค้าง) รวมเหตุล้มกับสิ่งที่ทำได้จริง (เดิมข้อความสำเร็จดันทับแถบแดงทันที)
            self.iface.messageBar().pushMessage(
                "Score", " · ".join(_errs) + f" · {self._LOG_HINT}" + (f" — ที่ทำได้: {_summ}" if (n_poly or n_pt) else ""),
                level=2, duration=0)
        elif n_poly or n_pt:
            self.iface.messageBar().pushMessage(
                "Score", _summ + " • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล", level=0, duration=5)
        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    # ★ 2.5.0 rc3 (เจ้าของงาน 30 ต.ค. 69 "ตอนสร้างและแก้ไขรูปแปลง อยากให้มีช่องหมายเหตุด้วย") ช่องหมายเหตุ (REMARK) ของ ➕/📝 —
    #   รายการใช้บ่อยเดียวกับปุ่ม 📝 หมายเหตุ (REMARK_PRESETS) หรือพิมพ์เอง · ไม่บังคับ · REMARK เป็น text ไม่จำกัดความยาว (ฐานจริงยาวสุด ~730 ตัว)
    def _remark_norm(self, raw):
        """ข้อความหมายเหตุ -> บรรทัดเดียว (ยุบช่องว่าง/ขึ้นบรรทัด · ลบอักขระล่องหนแบบ _pn_clean) · ตรงกับรายการใช้บ่อยแบบไม่สนตัวพิมพ์
        ⇒ ตัวสะกดในรายการ (" ซ้อน  rtk " = "ซ้อน RTK" แบบปุ่ม 📝 หมายเหตุ) · ว่าง = ''"""
        t = self._pn_clean(raw)
        return next((x for x in self.REMARK_PRESETS if x.casefold() == t.casefold()), t)

    @staticmethod
    def _remark_short(t, n=80):
        """หมายเหตุยาวในข้อความตัวอย่าง/กล่องยืนยัน -> บรรทัดเดียว ≤ n ตัว + …"""
        t = " ".join(_txt(t).split())
        return t if len(t) <= n else t[:n - 1] + "…"

    def _remark_combo(self, cur, has_col):
        """กล่องหมายเหตุของ ➕/📝 (พิมพ์ได้ + รายการใช้บ่อย) · cur = ค่าเดิมตามที่อยู่ในฐาน (📝 · ➕ = '') · ไม่มีคอลัมน์ ⇒ ปิด
        ⚠️ ไม่ตั้ง maxLength 100 — เทสหาช่องชื่อทางสาธารณะด้วย maxLength 100"""
        cb = QtWidgets.QComboBox()
        cb.setEditable(True)
        cb.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        cb.addItem("")
        cb.addItems(self.REMARK_PRESETS)
        cb.setEditText(cur)
        if has_col:
            cb.lineEdit().setPlaceholderText("ไม่บังคับ — เลือกจากรายการ หรือพิมพ์เอง")
            cb.setToolTip(cur if len(cur) > 40 else "หมายเหตุของแปลง (REMARK) — รายการเดียวกับปุ่ม 📝 หมายเหตุ")
        else:
            cb.setEnabled(False)
            cb.lineEdit().setPlaceholderText("ชั้นแปลงนี้ไม่มีคอลัมน์ REMARK")
        return cb

    def set_remark_value(self):
        """ใส่/แก้ "หมายเหตุ" (REMARK) ให้แปลงที่เลือก

        - เลือกจากรายการที่ใช้บ่อย หรือพิมพ์เองก็ได้ (ช่องแก้ไขได้)
        - ถ้าแปลงที่เลือกมีหมายเหตุเดิมเหมือนกันทั้งหมด จะเติมค่านั้นไว้ให้แก้ต่อ
          ★ 2.3.7 ไม่เหมือนกัน/ว่าง ⇒ ตัวเลือกแรกเป็น "(ไม่เปลี่ยน)" (กด OK เฉย ๆ = ไม่แก้อะไร)
        - ★ 2.3.7 ข้อความที่พิมพ์: ยุบช่องว่าง + ตรงกับรายการใช้บ่อยแบบไม่สนตัวพิมพ์ ⇒ ใช้ตัวสะกดในรายการ
        - ★ 2.3.7 เขียนเฉพาะแปลงที่ค่าเปลี่ยนจริง · จะทับ/ลบหมายเหตุอื่นที่มีอยู่ ⇒ ถามก่อน (ปุ่มตั้งต้น No)
        - เว้นว่าง = ลบหมายเหตุออก
        - เขียนเฉพาะ "ชั้นแปลง" (ชั้นหมุดไม่มีคอลัมน์ REMARK)
        """
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_layer:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน", level=1, duration=6)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            return
        fids = poly_layer.selectedFeatureIds()
        if not fids:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", "ยังไม่ได้เลือกแปลง — เลือกแปลงที่ต้องการใส่หมายเหตุก่อน", level=1, duration=6)
            return
        idx = self._field_index(poly_layer.fields(), "remark")
        if idx == -1:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", f"ไม่พบคอลัมน์ REMARK ในเลเยอร์ {poly_layer.name()}", level=1, duration=8)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            return

        # ★★ 2.3.7 (review DI-12 / DI-01) — ค่าเดิม "ดิบ" ต่อแปลง (NULL จริง / ข้อความ) แยกจากค่าที่แสดง (_txt)
        #   เดิมอ่านด้วย `"" if v is None else str(v)` ⇒ NULL จากฐานกลายเป็นคำว่า 'NULL' ⇒ กล่องเปิดมาที่ 'NULL'
        #   กด OK = เขียนสตริง 'NULL' ลงทุกแปลง · หมายเหตุไม่เหมือนกัน ⇒ เปิดที่ 'ซ้อน RTK' กด OK = ทับทั้งกลุ่มโดยไม่ถาม
        ดิบ = {}
        try:
            req = (QgsFeatureRequest().setFilterFids(fids)
                   .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([idx]))
            _fit3500 = poly_layer.getFeatures(req)
            try:
                for ft in _fit3500:
                    ดิบ[ft.id()] = ft.attribute(idx)
            finally:
                _fit3500.close()
        except Exception:
            ดิบ = {}
        if not ดิบ:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", "อ่านหมายเหตุเดิมของแปลงที่เลือกไม่ได้ — ยังไม่ได้แก้อะไร ลองใหม่อีกครั้ง",
                level=2, duration=8)
            return
        from collections import Counter
        แสดง = Counter(_txt(v) for v in ดิบ.values())
        cur = next(iter(แสดง)) if len(แสดง) == 1 else ""
        # ตัวเลือกแรก = ค่าปัจจุบัน (เมื่อทุกแปลงเหมือนกันและไม่ว่าง) ไม่งั้น "(ไม่เปลี่ยน)" — กด OK/Enter เฉย ๆ ต้องไม่ทับอะไร
        items = ([cur] if cur else [self.REMARK_KEEP]) + [x for x in self.REMARK_PRESETS if x != cur]
        ตอนนี้ = " · ".join(f"{k or '(ว่าง)'} {n:,}" for k, n in แสดง.most_common(4))
        if len(แสดง) > 4:
            ตอนนี้ += f" · อีก {len(แสดง) - 4} ค่า"
        txt, ok = QtWidgets.QInputDialog.getItem(
            self.iface.mainWindow(), "หมายเหตุ (REMARK)",
            f"ใส่หมายเหตุให้แปลงที่เลือก {len(fids):,} แปลง\n"
            f"หมายเหตุตอนนี้: {ตอนนี้}\n"
            "(เลือกจากรายการ หรือพิมพ์เอง • เว้นว่าง = ลบหมายเหตุ)",
            items, 0, True)
        if not ok:
            return
        # ★ 2.3.7 (review DI-12) — ยุบช่องว่างซ้ำ + ตรงกับรายการใช้บ่อยแบบไม่สนตัวพิมพ์ ⇒ ใช้ตัวสะกดในรายการ
        #   (" ซ้อน  rtk " = "ซ้อน RTK") กันความหมายเดียวกันสะกดหลายแบบ ซึ่งเป็นเหตุที่ทำรายการนี้ขึ้นมา
        txt = " ".join((txt or "").split())
        if txt == self.REMARK_KEEP:
            return
        txt = next((x for x in self.REMARK_PRESETS if x.casefold() == txt.casefold()), txt)
        ใหม่ = txt if txt else None
        # เขียนเฉพาะแปลงที่ค่าเปลี่ยนจริง — เทียบค่าดิบ ไม่ใช่ _txt (ค่าว่างจึงล้างสตริง 'NULL' ที่บั๊กเดิมเขียนไว้ได้)
        todo = [fid for fid, v in ดิบ.items() if (None if _is_sql_null(v) else str(v).strip()) != ใหม่]
        if not todo:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", (f"แปลงที่เลือกมีหมายเหตุ \"{txt}\" อยู่แล้ว" if txt else "แปลงที่เลือกไม่มีหมายเหตุอยู่แล้ว")
                + " — ไม่มีอะไรเปลี่ยน", level=0, duration=6)
            return
        # จะทับ/ลบหมายเหตุอื่นที่มีอยู่ ⇒ ถามก่อนพร้อมจำนวน (ปุ่มตั้งต้น No · review UX-08)
        ทับ = Counter(_txt(ดิบ[f]) for f in todo
                      if _txt(ดิบ[f]) and " ".join(_txt(ดิบ[f]).split()).casefold() != txt.casefold())
        if ทับ:
            _ท = " · ".join(f"\"{k}\" {n:,}" for k, n in ทับ.most_common(4))
            if len(ทับ) > 4:
                _ท += f" · อีก {len(ทับ) - 4} ค่า"
            what = f"เปลี่ยนเป็น \"{txt}\"" if txt else "ลบหมายเหตุออก"
            if self._ask(QtWidgets.QMessageBox.Question, "หมายเหตุ",
                         f"มี {sum(ทับ.values()):,} แปลงที่มีหมายเหตุอื่นอยู่แล้ว ({_ท})\n"
                         f"จะ{what} — ยืนยันไหม?",
                         default=QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                return

        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(poly_layer, title="หมายเหตุ", what="ยังไม่ได้ใส่หมายเหตุ"):
            return
        self.stored_selection = {poly_layer.id(): list(fids)}
        self._op_begin([poly_layer])
        # ★ 2.3.7 (review PF-02 / DI-28) — ส่งค่าเดิม (Undo เร็ว) · เขียนได้ 0 แถว = ไม่ดัน undo step ว่าง
        n, err = self._write_attr(poly_layer, "Set REMARK", todo, idx, ใหม่, ดิบ)
        self._op_commit()
        if err is not None:
            # ★ 2.3.7 (review ER-06) — เดิม "ผิดพลาด: <exception ดิบ>" · คำสั่งถูกย้อนแล้ว (ชั้นเดียว) · traceback อยู่ใน Log
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", f"เขียนหมายเหตุไม่สำเร็จ — ย้อนกลับแล้ว ไม่มีอะไรเปลี่ยน · {self._LOG_HINT}", level=2, duration=0)
            return
        if not n:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", "เขียนหมายเหตุไม่สำเร็จ — ไม่มีอะไรเปลี่ยน", level=2, duration=8)
            return
        เท่าเดิม = len(ดิบ) - len(todo)
        self.iface.messageBar().pushMessage(
            "หมายเหตุ",
            (f"ลบหมายเหตุของ {n:,} แปลงแล้ว" if not txt else f"ใส่หมายเหตุ \"{txt}\" ให้ {n:,} แปลงแล้ว")
            + (f" · {เท่าเดิม:,} แปลงเป็นค่านี้อยู่แล้ว" if เท่าเดิม else "")
            + " • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล", level=0, duration=8)
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def assign_owner(self):
        """👤 มอบหมาย (โหมดผู้ดูแล) — ตั้งผู้รับผิดชอบ (NAME) ให้แปลงที่เลือก

        ★ 2.2.10 (17 ก.ย. 69) เจ้าของงานสั่ง "เพิ่มปุ่มมอบหมายใน admin mode"
        - ใช้กับแปลงที่เลือกไว้ (เช่นเลือกทั้งกลุ่มด้วย ClusterID ก่อน) · เขียนเฉพาะชั้นแปลง
        - เลือกชื่อจากรายชื่อที่มีในชั้นอยู่แล้ว · ★ 2.5.0 (เจ้าของงาน 29 ต.ค. 69 "fix ชื่อพนักงาน") พิมพ์ชื่อใหม่ในกล่องไม่ได้
          (ชื่อพนักงานใหม่ใส่ครั้งแรกในช่องผู้รับผิดชอบของ ➕ โหมดผู้ดูแล) · ค่านอกรายการมาได้เฉพาะผู้เรียกจากโค้ด ⇒ ยังถามยืนยันแบบเดิม
          🔑 NAME คือ "ผู้รับผิดชอบ" ที่เว็บติดตามงานใช้แยกงานรายคน — สะกดต่างกัน = กลายเป็นคนใหม่
        - แปลงที่มีเจ้าของอยู่แล้ว (คนอื่น) ต้องยืนยันก่อนโอน · L1 ต้องปลดล็อกก่อน
        - ลงบัฟเฟอร์ + Undo ได้ · กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล
        """
        title = "มอบหมาย"
        ready = self._admin_ready(title)
        if not ready:
            return
        poly_layer, _pt = ready
        fids = list(poly_layer.selectedFeatureIds())
        if not fids:
            self.iface.messageBar().pushMessage(
                title, "ยังไม่ได้เลือกแปลง — เลือกแปลงที่จะมอบหมายก่อน (เช่นใช้ ClusterID เลือกทั้งกลุ่ม)",
                level=1, duration=8)
            return
        nf = self._resolve_field(poly_layer, {'name'})
        if not nf:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      f"ชั้นแปลง '{poly_layer.name()}' ไม่มีคอลัมน์ NAME — มอบหมายไม่ได้")
            return
        idx = poly_layer.fields().indexOf(nf)
        if not self._need_column_or_warn(poly_layer, nf, title):
            return
        ti = self._field_index(poly_layer.fields(), 'type')

        # สำรวจแปลงที่เลือก: ผู้รับผิดชอบเดิม + จำนวน L1
        from collections import Counter
        cur = Counter()
        n_l1 = 0
        old = {}
        attrs = [idx] + ([ti] if ti != -1 else [])
        req = (QgsFeatureRequest().setFilterFids(fids)
               .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes(attrs))
        ดิบ = {}                  # ★ 2.3.7 (review PF-02) ค่า NAME เดิมดิบ ⇒ ส่งเป็น oldValue
        _fit = poly_layer.getFeatures(req)
        try:
            for ft in _fit:
                ดิบ[ft.id()] = ft.attribute(idx)
                # ★ 2.3.7 (review DI-01) — NULL จาก provider = "ยังไม่มอบหมาย" (เดิม str() ได้ 'NULL'
                #   ⇒ ขึ้นถาม "มี N แปลงที่มีผู้รับผิดชอบอยู่แล้ว (NULL N)" เหมือนเป็นการโอนงานจากคนชื่อ NULL)
                v = _txt(ดิบ[ft.id()])
                old[ft.id()] = v
                cur[v] += 1
                if ti != -1 and _is_l1(ft.attribute(ti)):
                    n_l1 += 1
        finally:
            _fit.close()
        if n_l1 and not self._l1_unlocked():
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      f"ในแปลงที่เลือกมีแปลง L1-RTK/L1-TS {n_l1:,} แปลง\n"
                      "แปลง L1 ไม่ใช่งานของพนักงาน — ถ้าต้องการมอบหมายจริงให้กด 🔓 ปลดล็อก L1 ก่อน")
            return

        # รายชื่อที่มีอยู่แล้วในชั้นนี้ (DISTINCT ฝั่งฐานข้อมูล — ไม่ไล่ทุกแถว)
        try:
            names = sorted({_txt(v) for v in poly_layer.uniqueValues(idx) if _txt(v)},   # ★ 2.3.7 DI-01
                           key=str.lower)
        except Exception:
            names = []

        def _summ(c):
            parts = [f"{(k or 'ยังไม่มอบหมาย')} {n:,}" for k, n in c.most_common(6)]
            if len(c) > 6:
                parts.append(f"อีก {len(c) - 6} ชื่อ")
            return " · ".join(parts)

        items = [self.ASSIGN_BLANK] + names
        single = next(iter(cur)) if len(cur) == 1 else ""
        start = items.index(single) if single in items else 0
        txt, ok = QtWidgets.QInputDialog.getItem(
            self.iface.mainWindow(), "👤 มอบหมาย",
            f"มอบหมายแปลงที่เลือก {len(fids):,} แปลงให้\n"
            f"ผู้รับผิดชอบตอนนี้: {_summ(cur)}\n"
            "(เลือกชื่อจากรายการเท่านั้น — ชื่อพนักงานใหม่ใส่ครั้งแรกในช่องผู้รับผิดชอบของ ➕)",
            items, start, False)
        if not ok:
            return
        txt = (txt or "").strip()
        if txt == self.ASSIGN_BLANK:
            txt = ""
        if txt:
            same = [n for n in names if n.lower() == txt.lower()]
            if txt in names:
                pass                       # ★ 2.5.0 rc3 (ผลตรวจ Windows rc2 🟡9) เลือกจากรายการ = ตัวสะกดนั้นตรงตัว (ชั้นมีทั้ง Kanjana/kanjana ⇒ เดิมเขียนอีกตัว)
            elif same:
                txt = same[0]              # ใช้ตัวสะกดเดิมในฐานข้อมูล (กันกลายเป็นคนใหม่เพราะตัวพิมพ์)
            elif self._ask(QtWidgets.QMessageBox.Question, title,
                           f"ชื่อ \"{txt}\" ยังไม่เคยมีในชั้นนี้\n"
                           "ชื่อนี้จะแสดงเป็นผู้รับผิดชอบคนใหม่บนเว็บติดตามงาน — สะกดถูกแล้วใช่ไหม?",
                           default=QtWidgets.QMessageBox.No       # ★ 2.3.7 (review UX-08)
                           ) != QtWidgets.QMessageBox.Yes:
                return

        todo = [fid for fid in fids if old.get(fid, "") != txt]
        if not todo:
            self.iface.messageBar().pushMessage(
                title, "แปลงที่เลือกเป็นของผู้รับผิดชอบนี้อยู่แล้ว — ไม่มีอะไรต้องเปลี่ยน", level=0, duration=6)
            return
        moved = Counter(old.get(fid, "") for fid in todo if old.get(fid, ""))
        if moved:
            what = f"เปลี่ยนเป็น \"{txt}\"" if txt else "ยกเลิกการมอบหมาย"
            if self._ask(QtWidgets.QMessageBox.Question, title,
                         f"มี {sum(moved.values()):,} แปลงที่มีผู้รับผิดชอบอยู่แล้ว ({_summ(moved)})\n"
                         f"จะ{what} — ยืนยันไหม?",
                         default=QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:   # ★ 2.3.7 (review UX-08)
                return

        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(poly_layer, title=title, what="ยังไม่ได้มอบหมาย"):
            return
        self.stored_selection = {poly_layer.id(): list(fids)}
        self._op_begin([poly_layer])
        # ★ 2.3.7 (review PF-02 / DI-28) — ส่งค่าเดิม (Undo เร็ว) · เขียนได้ 0 แถว = ไม่ดัน undo step ว่าง
        n, err = self._write_attr(poly_layer, "Assign NAME", todo, idx, txt if txt else None, ดิบ)
        self._op_commit()
        if err is not None:
            self.iface.messageBar().pushMessage(          # ★ 2.3.7 (review ER-06)
                title, f"เขียนชื่อผู้รับผิดชอบไม่สำเร็จ — ย้อนกลับแล้ว ไม่มีอะไรเปลี่ยน · {self._LOG_HINT}", level=2, duration=0)
            return
        if not n:
            self.iface.messageBar().pushMessage(
                title, "เขียนชื่อผู้รับผิดชอบไม่สำเร็จ — ไม่มีอะไรเปลี่ยน", level=2, duration=8)
            return
        self.iface.messageBar().pushMessage(
            title,
            (f"มอบหมาย \"{txt}\" ให้ {n:,} แปลงแล้ว" if txt else f"ยกเลิกการมอบหมาย {n:,} แปลงแล้ว")
            + " • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล", level=0, duration=8)
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def audit_parcels(self):
        """✅ Audit (โหมดผู้ดูแล) — ผลตรวจงานพนักงาน ลงคอลัมน์ `AUDIT`

        ★ 2.3.2 (21 ก.ย. 69) เจ้าของงานสั่ง "สร้างปุ่ม audit ด้านขวามอบหมาย"

        `AUDIT` เป็นคำตัดสินของผู้ดูแล **ที่อยู่เหนือ `SCORE` ของพนักงาน**

        | `SCORE` | `AUDIT` | เว็บติดตามงานนับเป็น |
        |---|---|---|
        | `1` | ว่าง | ผ่าน (หรือ "ต้องแก้" ถ้าตัวตรวจเชิงพื้นที่จับได้) |
        | `1` | `0`  | **ต้องแก้** — ผู้ดูแลตีกลับ |
        | `1` | `1`  | ผ่าน · **ล้างได้เฉพาะธงเนื้อที่** ธงอื่นอีก 10 ข้อยังชนะ |
        | `0` | `1`  | **ผ่าน** — ไม่เข้าช่อง "ไม่ผ่าน" |
        | `0` | ว่าง/`0` | ไม่ผ่าน |

        🔴 **พนักงานเขียนคอลัมน์นี้ไม่ได้** — สิทธิ์ UPDATE ของพนักงานเป็นแบบระดับคอลัมน์
           (REMARK · cluster_id · SCORE · geom เท่านั้น) คอลัมน์ใหม่จึงไม่ถึงมือใครโดยอัตโนมัติ
        🔴 ไม่แตะ L1 เว้นแต่กด 🔓 ปลดล็อก L1 — L1 ไม่ใช่งานของพนักงาน ไม่มีอะไรให้ตรวจ
        · ลงบัฟเฟอร์ + Undo ได้ · ต้องกด 💾 บันทึก ถึงจะลงฐานข้อมูลจริง
        """
        title = "Audit"
        ready = self._admin_ready(title)
        if not ready:
            return
        poly_layer, _pt = ready
        fids = list(poly_layer.selectedFeatureIds())
        if not fids:
            self.iface.messageBar().pushMessage(
                title, "ยังไม่ได้เลือกแปลง — เลือกแปลงที่จะบันทึกผลตรวจก่อน "
                       "(เช่นใช้ ClusterID เลือกทั้งกลุ่ม)", level=1, duration=8)
            return
        af = self._resolve_field(poly_layer, {'audit'})
        if not af:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      f"ชั้นแปลง '{poly_layer.name()}' ไม่มีคอลัมน์ AUDIT\n\n"
                      "คอลัมน์นี้ต้องถูกสร้างในฐานข้อมูลก่อน (ผู้ดูแลฐานข้อมูลเป็นคนสั่ง) "
                      "แล้วต้องถอดชั้นข้อมูลออกแล้วเพิ่มใหม่ใน QGIS ชั้นเดิมถึงจะเห็นคอลัมน์")
            return
        idx = poly_layer.fields().indexOf(af)
        if not self._need_column_or_warn(poly_layer, af, title):
            return
        ti = self._field_index(poly_layer.fields(), 'type')
        si = self._field_index(poly_layer.fields(), 'score')

        req = (QgsFeatureRequest().setFilterFids(fids)
               .setFlags(QgsFeatureRequest.NoGeometry))
        cols = [idx] + [i for i in (ti, si) if i != -1]
        req.setSubsetOfAttributes(cols)
        old, score, ข้าม_l1 = {}, {}, 0
        ดิบ = {}          # ★ 2.3.7 (review PF-02) ค่า AUDIT เดิมดิบ ⇒ ส่งเป็น oldValue
        อ่านได้ = 0       # ★ 2.3.7 (review UX-06) แยก "L1 ทั้งหมด" ออกจาก "อ่านไม่ได้เลย"
        _fit = poly_layer.getFeatures(req)
        try:
            for f in _fit:
                อ่านได้ += 1
                if ti != -1 and not self._l1_unlocked():
                    if _is_l1(f.attribute(ti)):        # ★ 2.3.7 DI-01 (_txt)
                        ข้าม_l1 += 1
                        continue
                v = f.attribute(idx)
                ดิบ[f.id()] = v
                # ★ 2.3.7 (review DI-01) — NULL จาก provider = "ยังไม่ตรวจ" (เดิม str() ได้ 'NULL' ⇒ ไม่เท่ากับ ''
                #   ⇒ กด "ยังไม่ตรวจ" แล้วแปลงที่ว่างอยู่แล้วถูกนับเป็นงานที่ต้องเขียนทับ)
                old[f.id()] = _txt(v)
                if si != -1:
                    score[f.id()] = _txt(f.attribute(si))
        finally:
            _fit.close()
        if not old and not อ่านได้:
            # ★ 2.3.7 (review UX-06) — เดิมขึ้น "เป็นแปลง L1 ทั้งหมด (0 ใบ)" ทั้งที่จริงอ่านแถวไม่ได้สักแถว
            self.iface.messageBar().pushMessage(
                title, f"อ่านข้อมูลแปลงที่เลือกไม่ได้ (0 จาก {len(fids):,} แปลง) — ยังไม่ได้บันทึกอะไร "
                       "ลองใหม่อีกครั้ง", level=2, duration=10)
            return
        if not old:
            self.iface.messageBar().pushMessage(
                title, f"แปลงที่เลือกเป็นแปลง L1 ทั้งหมด ({ข้าม_l1:,} ใบ) — "
                       "L1 ไม่ใช่งานของพนักงาน ไม่มีอะไรให้ตรวจ", level=1, duration=8)
            return

        from collections import Counter
        เดิม = Counter(('ผ่าน' if v == '1' else 'ไม่ผ่าน' if v == '0' else 'ยังไม่ตรวจ')
                       for v in old.values())
        คะแนน = Counter(('พนักงานกดผ่าน' if v == '1' else 'พนักงานกดไม่ผ่าน' if v == '0'
                         else 'ยังไม่ทำ') for v in score.values()) if si != -1 else Counter()

        items = [self.AUDIT_PASS, self.AUDIT_FAIL, self.AUDIT_NONE]
        txt, ok = QtWidgets.QInputDialog.getItem(
            self.iface.mainWindow(), "✅ Audit — ผลตรวจของผู้ดูแล",
            f"บันทึกผลตรวจให้แปลงที่เลือก {len(old):,} แปลง\n"
            + (f"สถานะของพนักงาน: {' · '.join(f'{k} {n:,}' for k, n in คะแนน.most_common())}\n"
               if คะแนน else "")
            + f"ผลตรวจเดิม: {' · '.join(f'{k} {n:,}' for k, n in เดิม.most_common())}\n\n"
            "✅ ผ่าน — แปลงที่พนักงานกด Score 0 จะถูกนับเป็น \"ผ่าน\"\n"
            "        และล้างธง \"เนื้อที่ต่างจากทะเบียน\" ให้ (ธงอื่นยังอยู่)\n"
            "❌ ไม่ผ่าน — แปลงที่พนักงานกด Score 1 จะเข้าช่อง \"แปลงที่ต้องแก้ไข\"",
            items, 0, False)
        if not ok:
            return
        ใหม่ = '1' if txt == self.AUDIT_PASS else '0' if txt == self.AUDIT_FAIL else ''

        todo = [fid for fid, v in old.items() if v != ใหม่]
        if not todo:
            self.iface.messageBar().pushMessage(
                title, "แปลงที่เลือกมีผลตรวจนี้อยู่แล้ว — ไม่มีอะไรต้องเปลี่ยน"
                       + (f" (ข้ามแปลง L1 {ข้าม_l1:,} ใบ)" if ข้าม_l1 else ""),
                level=0, duration=7)
            return
        เตือน = (f"\n\n⚠️ ข้ามแปลง L1 ไป {ข้าม_l1:,} ใบ "
                 "(ถ้าต้องการตรวจด้วย ให้กด 🔓 ปลดล็อก L1 ก่อน)") if ข้าม_l1 else ""
        if อ่านได้ < len(fids):
            เตือน += (f"\n\n⚠️ อ่านข้อมูลได้ {อ่านได้:,} จาก {len(fids):,} แปลง — แปลงที่อ่านไม่ได้จะไม่ถูกแตะ")
        คำ = "ผ่าน" if ใหม่ == '1' else "ไม่ผ่าน" if ใหม่ == '0' else "ยังไม่ตรวจ (ล้างผลตรวจ)"
        # ★ 2.3.7 (review UX-08) — งานจำนวนมาก ⇒ ปุ่มตั้งต้น No (Enter ตามความเคยชิน = ไม่ทำ)
        if self._ask(QtWidgets.QMessageBox.Question, title,
                     f"จะบันทึกผลตรวจ \"{คำ}\" ให้ {len(todo):,} แปลง\n"
                     "ผลจะไปโผล่บนเว็บติดตามงานรอบถัดไป — ยืนยันไหม?"
                     + เตือน, default=QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return

        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(poly_layer, title=title, what="ยังไม่ได้ตั้งค่า Audit"):
            return
        self.stored_selection = {poly_layer.id(): list(fids)}
        self._op_begin([poly_layer])
        # ★ ค่าว่าง = None (NULL จริง) ห้ามส่งสตริง 'NULL' — ฐานมี CHECK กันไว้อีกชั้น
        # ★ 2.3.7 (review PF-02 / DI-28) — ส่งค่าเดิม (Undo เร็ว) · เขียนได้ 0 แถว = ไม่ดัน undo step ว่าง
        n, err = self._write_attr(poly_layer, "Set AUDIT", todo, idx, ใหม่ if ใหม่ else None, ดิบ)
        self._op_commit()
        if err is not None:
            self.iface.messageBar().pushMessage(          # ★ 2.3.7 (review ER-06)
                title, f"เขียนผลตรวจไม่สำเร็จ — ย้อนกลับแล้ว ไม่มีอะไรเปลี่ยน · {self._LOG_HINT}", level=2, duration=0)
            return
        if not n:
            self.iface.messageBar().pushMessage(
                title, "เขียนผลตรวจไม่สำเร็จ — ไม่มีอะไรเปลี่ยน", level=2, duration=8)
            return
        self.iface.messageBar().pushMessage(
            title, f"บันทึกผลตรวจ \"{คำ}\" ให้ {n:,} แปลงแล้ว"
                   + (f" · ข้าม L1 {ข้าม_l1:,} ใบ" if ข้าม_l1 else "")
                   + " • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล", level=0, duration=8)
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def group_cluster_ids(self):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย cluster id จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        title = "Cluster"
        _CL = ('cluster_id', 'clusterid', 'id_cluster')
        target_field = next((f.name() for f in poly_layer.fields() if f.name().lower() in _CL), None)
        if not target_field:
            self.iface.messageBar().pushMessage(
                title, f"ชั้นแปลง '{poly_layer.name()}' ไม่มีคอลัมน์ cluster_id — ไม่ได้แก้อะไร", level=1, duration=6)
            return
        f_idx = poly_layer.fields().indexFromName(target_field)
        # ★★ 2.3.7 (review DI-04 · DU-01-D②) — อ่านทุกแปลงที่เลือก "ในคำขอเดียว" (รวมแปลง L1 แบบอ่านอย่างเดียว
        #   เพื่อให้เข้ากลุ่มเดิมของแปลง L1 ได้) แล้วเลือกค่าแบบแน่นอน ไม่ขึ้นกับลำดับ
        #   เดิมเอาค่าจาก _usable[0] = id แรกของ selectedFeatureIds() ซึ่งเป็น QSet เรียงตาม hash (สุ่มต่อ process)
        #   ⇒ แปลงที่ชนะเป็นการสุ่ม · ถ้าแปลงนั้น cluster_id เป็น NULL ⇒ เขียน NULL ทับทั้งกลุ่มเงียบ ๆ (ผู้ตรวจวัด 2 ใน 5 รอบ)
        #   ⇒ นับค่าที่มีจริงด้วย _txt: ไม่มีเลย = เตือนแล้วออก (ห้ามเขียน NULL) · ค่าเดียว = ใช้เลย ·
        #     หลายค่า = ถาม (ค่าที่มีมากสุดเป็นตัวแรก) · ข้ามแปลง L1 (ถ้ายังไม่ปลดล็อก) **และหมุดของแปลงนั้น**
        #     (เดิมข้ามเฉพาะแปลง ⇒ หมุดของแปลง L1 ที่ถูกเลือกมาด้วย UTM โดนเขียน cluster_id)
        # ★ ด่าน L1 (2026-08-06): "ข้ามเฉพาะแปลง L1" ไม่ใช่ยกเลิกทั้งงาน — กลุ่มระวางส่วนใหญ่มีแปลง L1 ปนอยู่เป็นปกติ
        #   ถ้ายกเลิกทั้งงานจะใช้ปุ่มนี้แทบไม่ได้เลย (แนวเดียวกับ Add Node ที่ข้ามแปลงล็อกแล้วทำแปลงที่เหลือต่อ)
        _t_idx = self._field_index(poly_layer.fields(), 'type')
        _uf = self._resolve_field(poly_layer, _UTM_FIELD_NAMES)
        _u_idx = poly_layer.fields().indexOf(_uf) if _uf else -1
        unlocked = self._l1_unlocked()
        req = (QgsFeatureRequest().setFilterFids(list(poly_layer.selectedFeatureIds()))
               .setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([f_idx] + [i for i in (_t_idx, _u_idx) if i != -1]))
        from collections import Counter
        นับ, ค่าดิบ = Counter(), {}
        old = {}                                  # แปลงที่จะตั้งค่าให้: fid -> ค่าเดิมดิบ (oldValue · PF-02)
        _skip_fids, _skip_utm = set(), set()
        # ★ 9 ก.ย. 69 — ปิด iterator เองเสมอ (กันตัวอ่านค้าง)
        _fit3617 = poly_layer.getFeatures(req)
        try:
            for f in _fit3617:
                v = f.attribute(f_idx)
                t = _txt(v)
                if t:
                    นับ[t] += 1
                    if t not in ค่าดิบ or (str(v) == t and str(ค่าดิบ[t]) != t):
                        ค่าดิบ[t] = v             # ค่าดิบ 1 ค่าต่อข้อความ (คงชนิดของคอลัมน์) · ชอบตัวที่ไม่มีช่องว่างเกิน
                if _t_idx != -1 and not unlocked and _is_l1(f.attribute(_t_idx)):
                    _skip_fids.add(f.id())
                    if _u_idx != -1 and _txt(f.attribute(_u_idx)):
                        _skip_utm.add(_norm_utm(f.attribute(_u_idx)))
                    continue
                old[f.id()] = v
        finally:
            _fit3617.close()
        _l1_note = (f" · ข้ามแปลงอ้างอิง L1 {len(_skip_fids):,} แปลง (และหมุดของแปลงนั้น)" if _skip_fids else "")
        if not old:
            self.iface.messageBar().pushMessage(
                title, (f"แปลงที่เลือกเป็นแปลงอ้างอิง L1 ทั้งหมด ({len(_skip_fids):,} แปลง) — ไม่ตั้ง cluster_id ให้"
                        if _skip_fids else "อ่านข้อมูลแปลงที่เลือกไม่ได้ — ยังไม่ได้แก้อะไร ลองใหม่อีกครั้ง"),
                # ★ 2.3.7 b19 (doc-verify E9) — L1 ทั้งหมด = ปฏิเสธ (เหลือง) · อ่านแถวไม่ได้สักแถว = ผิดพลาดจริง (แดง แบบ Score/หมายเหตุ)
                level=(1 if _skip_fids else 2), duration=8)
            return
        if not นับ:
            self.iface.messageBar().pushMessage(
                title, "แปลงที่เลือกยังไม่มี cluster_id เลยสักแปลง — ไม่รู้จะใช้ค่าไหน (ไม่เขียนค่าว่างทับ) "
                       "· ใส่ cluster_id ให้แปลงหนึ่งก่อนแล้วกดใหม่", level=1, duration=10)
            return
        เรียง = sorted(นับ.items(), key=lambda kv: (-kv[1], _natkey(kv[0])))
        if len(เรียง) == 1:
            chosen = เรียง[0][0]
        else:
            items = [f"{v} ({n:,} แปลง)" for v, n in เรียง]
            pick, ok = QtWidgets.QInputDialog.getItem(
                self.iface.mainWindow(), "Sync Cluster ID",
                f"แปลงที่เลือกมี cluster_id {len(เรียง)} ค่า — เลือกค่าที่จะใช้กับทั้งกลุ่ม\n"
                "(ตัวแรก = ค่าที่มีมากที่สุด)", items, 0, False)
            if not ok or pick not in items:
                return
            chosen = เรียง[items.index(pick)][0]
        main_val = ค่าดิบ[chosen]

        # แผนการเขียนต่อชั้น — ข้ามแถวที่ค่าเท่าเดิม (PF-02) · ชั้นที่ไม่มีคอลัมน์/ไม่มีอะไรเปลี่ยน = ไม่เปิดแก้ไข/command (DI-28)
        แผน = []
        p_todo = [fid for fid, v in old.items() if _txt(v) != chosen]
        if p_todo:
            แผน.append((poly_layer, f_idx, p_todo, old))
        pt_note = ""
        if point_layer and point_layer.selectedFeatureCount() > 0:
            pt_f = next((f.name() for f in point_layer.fields() if f.name().lower() in _CL), None)
            pu = self._resolve_field(point_layer, _UTM_FIELD_NAMES)
            pui = point_layer.fields().indexOf(pu) if pu else -1
            if pt_f and not self._col_ok(point_layer, pt_f):
                # สิทธิ์พนักงานบนชั้นหมุดไม่รวมคอลัมน์ cluster (ถ้ามี) — เขียนลง buffer แล้วไปล้มตอน 💾 พร้อมงานหมุดอื่น ⇒ ข้าม
                pt_note = f" · ชั้นหมุดมีคอลัมน์ {pt_f} แต่บัญชีนี้แก้ไม่ได้ — ตั้งให้เฉพาะแปลง"
                pt_f = None
            elif pt_f and pui == -1 and not unlocked:
                pt_note = " · ชั้นหมุดไม่มีคอลัมน์ UTM (แยกหมุดของแปลง L1 ไม่ได้) — ตั้งให้เฉพาะแปลง"
                pt_f = None
            if pt_f:
                ล็อก = self._locked_map_or_block(poly_layer, title)     # ปลดล็อกอยู่ = {} · สแกนล้ม = None ⇒ หยุด
                if ล็อก is None:
                    return
                pi = point_layer.fields().indexFromName(pt_f)
                pti = self._field_index(point_layer.fields(), 'type')     # ★ 2.4.0 (DU-01) Type ของหมุดเอง
                preq = (QgsFeatureRequest().setFilterFids(list(point_layer.selectedFeatureIds()))
                        .setFlags(QgsFeatureRequest.NoGeometry)
                        .setSubsetOfAttributes([pi] + [i for i in (pui, pti) if i != -1]))
                pold = {}
                n_mk_l1 = 0
                _pit = point_layer.getFeatures(preq)
                try:
                    for f in _pit:
                        if pui != -1 and not unlocked:
                            k = _norm_utm(f.attribute(pui))
                            if k in _skip_utm:
                                continue          # ★ DU-01-D② หมุดของแปลง L1 ไม่แตะ
                        # ★ 2.4.0 (review DU-01) — กติกาเดียว (_marker_locked): UTM ตรงแปลง L1 หรือ Type ของหมุดเป็น L1
                        #   เดิมดูแค่ UTM ⇒ หมุด Type L1 ที่ UTM ไม่ตรงแปลง L1 ใดโดนเขียน cluster_id
                        if self._marker_locked(f, ล็อก, pu, pti)[0]:
                            n_mk_l1 += 1
                            continue
                        pold[f.id()] = f.attribute(pi)
                finally:
                    _pit.close()
                if n_mk_l1:
                    pt_note += f" · ข้ามหมุด L1 / หมุดของแปลง L1 {n_mk_l1:,} หมุด"
                pt_todo = [fid for fid, v in pold.items() if _txt(v) != chosen]
                if pt_todo:
                    แผน.append((point_layer, pi, pt_todo, pold))
        if not แผน:
            self.iface.messageBar().pushMessage(
                title, f"แปลงที่เลือกมี cluster_id = {chosen} อยู่แล้ว — ไม่มีอะไรเปลี่ยน" + _l1_note + pt_note,
                level=0, duration=6)
            return

        self.stored_selection = {l.id(): l.selectedFeatureIds() for l in (poly_layer, point_layer)
                                 if l and l.selectedFeatureCount() > 0}
        # ★ rc2 (audit A3-06 · DI-15 ส่วนที่เหลือ) — เปิดโหมดแก้ไข "ทุกชั้นในแผน" ก่อน _op_begin (แบบ Score)
        #   เดิมเปิดทีละชั้นในลูปหลัง _op_begin ⇒ ชั้นหมุดเปิดไม่ได้ = ชั้นแปลงถูกเขียนไปแล้ว · ไม่มี Log ตาม DI-15
        if not self._ensure_editing(*[e[0] for e in แผน], title=title, what="ยังไม่ได้ตั้ง cluster_id ให้ชั้นใดเลย"):
            QtCore.QTimer.singleShot(100, self.restore_selection)
            return
        self._op_begin([e[0] for e in แผน])   # เริ่มนับ undo-step ต่อเลเยอร์ (เดิมไม่ track -> undo เพี้ยน)
        ผล, err = {}, None
        for lyr, idx, todo, o in แผน:
            n, e = self._write_attr(lyr, "Group Cluster ID", todo, idx, main_val, o)
            ผล[lyr.id()] = n
            if e is not None:
                # ★ 2.3.7 (review ER-06) — เดิมแปะ str(e) ดิบ · ชั้นนี้ถูกย้อนทั้งคำสั่งแล้ว · traceback อยู่ใน Log (_write_attr)
                err = err or f"เขียน cluster_id ของชั้น '{lyr.name()}' ไม่สำเร็จ — ชั้นนี้ไม่ถูกแก้ · {self._LOG_HINT}"
        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        n_poly = ผล.get(poly_layer.id(), 0)
        n_pt = ผล.get(point_layer.id(), 0) if point_layer else 0
        เท่าเดิม = len(old) - len(p_todo)
        _summ = (f"cluster_id = {chosen} -> {n_poly:,} แปลง / {n_pt:,} หมุด"
                 + (f" · {เท่าเดิม:,} แปลงมีค่านี้อยู่แล้ว" if เท่าเดิม else "") + _l1_note + pt_note)
        if err:
            # ★ rc2 (audit A3-06) — ข้อความเดียว (แดง · ค้าง) รวมเหตุล้ม + สิ่งที่ทำได้จริง
            #   เดิมแถบแดงถูกข้อความสำเร็จ (ฟ้า/เหลือง 8 วิ) ดันทับทันที ⇒ ผู้ใช้เห็นแต่ "สำเร็จ"
            self.iface.messageBar().pushMessage(title, f"{err} — ที่ทำได้: {_summ}", level=2, duration=0)
        else:
            self.iface.messageBar().pushMessage(
                title, _summ + " • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล",
                level=1 if (_skip_fids or pt_note) else 0, duration=8)
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def _owner_get(self):
        """ค่าปัจจุบันของ @owner_name (ระดับ global ของ QGIS) — '' = ยังไม่ตั้ง"""
        try:
            v = QgsExpressionContextUtils.globalScope().variable(self.OWNER_VAR)
            return "" if v is None else str(v)
        except Exception:
            return ""

    def _owner_label(self, v=None):
        v = self._owner_get() if v is None else v
        if v == self.OWNER_ALL:
            return "ทุกคน"
        return v or "ยังไม่ได้เลือก"

    def _refresh_owner_ui(self):
        """อัปเดตหัวข้อกลุ่ม + tooltip ให้เห็นว่ากำลังเลือกใครอยู่ (ไม่กินที่บนแถบปุ่ม)"""
        name = self._owner_label()
        g = getattr(self, "_grp_layer", None)
        if g is not None:
            g.setTitle(f"ชั้นข้อมูล      👤 {name}")
        b = getattr(self, "_owner_btn", None)
        if b is not None:
            b.setToolTip(
                f"ผู้รับผิดชอบที่ให้สัญลักษณ์ไฮไลต์: {name}\n"
                "คลิกเพื่อเปลี่ยน — เลือกชื่อคน หรือ 'ทุกคน'\n"
                "(ตั้งเป็นตัวแปร @owner_name ระดับเครื่อง ใช้ได้กับทุกสาขา)")

    @staticmethod
    def _owner_label_base(label, tag="👤"):
        """★ 2.3.7 (review UX-41) — ส่วนหน้าของป้าย rule ก่อนแท็ก "👤ชื่อ" ที่ปลั๊กอินต่อท้าย (ฟังก์ชันบริสุทธิ์ · ป้ายใหม่ = base + ' ' + tag + ชื่อ)
        ① ตัดที่ tag ตัวแรก (แบบเดิม — ป้าย 'L2-TS 👤 ของฉัน' ⇒ 'L2-TS')
        ② ได้ว่าง (ป้ายขึ้นต้นด้วย tag) ⇒ ตัดที่ ' '+tag ตัวแรกแทน: '👤 Mine 👤A' ⇒ '👤 Mine' · ' 👤A' ⇒ '' (= ป้ายว่างที่ปลั๊กอินเติมเอง)
        เดิมข้อ ② ถอยไปใช้ "ทั้งป้าย" เมื่อยังว่าง ⇒ ป้ายว่างงอกทุกรอบ: ' 👤A' → ' 👤A 👤A' → ' 👤A 👤A 👤A'
        ผลของฟังก์ชันนี้ป้อนกลับแล้วต้องได้ค่าเดิม (ป้ายคงที่ตั้งแต่รอบที่ 2) · ป้ายเสียที่เคยเซฟ 'X 👤A 👤A' ⇒ 'X'"""
        lab = "" if label is None else str(label)
        base = lab.split(tag)[0].rstrip()
        if not base:
            base = lab.split(" " + tag)[0].rstrip()
        return base

    def _owner_rule_is_others(self, flt, base):
        """rule ที่ผูก @owner_name นี้เป็นกองของ "คนอื่น" ไหม -> ห้ามติดชื่อที่ป้าย

        ★ 25 ก.ย. 69 — เดิมดูแค่ "filter ขึ้นต้นด้วย not" แต่โปรเจกต์ V3 จริงทั้ง 5 สาขา
          (ไฟล์บนแชร์ อ่าน 25 ก.ย.) เขียนกองคนอื่นด้วย <> แทน:
              coalesce("NAME",'') <> coalesce(nullif(nullif(@owner_name,''),'*'), ...) and "Type" = ...
          ⇒ สารบัญขึ้น "L2-TS (คนอื่น) 👤ทุกคน" ทั้งที่เจ้าของงานสั่งว่าห้ามติดชื่อ
        นับเป็น "คนอื่น" ถ้าเข้าข้อใดข้อหนึ่ง (ไม่สนตัวพิมพ์เล็ก/ใหญ่):
          ① ป้ายมีคำว่า คนอื่น — เจ้าของงานตั้งชื่อกองเอง ตรงกับสิ่งที่พนักงานเห็นที่สุด
             ดูจาก base (ตัด 👤ชื่อ ออกแล้ว) ไม่ใช่ป้ายดิบ ไม่งั้นถ้าชื่อคนบังเอิญมีคำนี้
             เรียกแต่ละครั้งจะสลับติด/ไม่ติดไปมา
          ② filter มี "การเทียบ @owner_name กับคอลัมน์ของแปลง" ที่มีความหมายว่า "ไม่ใช่"
             อ่านจากโครงนิพจน์ของ QGIS ไม่ใช่หาข้อความ — กอง "ของฉัน" ก็มี <> / not ได้ (เช่น "SCORE" <> '1')
             ★ audit รอบ 4-5 (30 ก.ย.-1 ต.ค.) — ไล่ตาม "ขั้ว": NOT กลับขั้ว · การเทียบแบบ = LIKE ILIKE IS IN = ขั้วบวก ·
               <> != NOT LIKE NOT ILIKE IS NOT NOT IN = ขั้วลบ ⇒ ขั้วลบ (หลังคิด NOT ที่ครอบ) = คนอื่น
               นับเฉพาะการเทียบที่ฝั่งหนึ่งอ้าง @owner_name และอีกฝั่งอ้าง **คอลัมน์** (ค่าคงที่/ตัวแปรอื่นไม่นับ)
               ⇒ `not ("NAME" <> @owner_name)` = ของฉัน · `@owner_name <> ''` ไม่นับ ·
                 `"NAME" = @owner_name and not ("SCORE" = '1' and @owner_name = '*')` = ของฉัน
          (filter ที่ QGIS อ่านไม่ออก ⇒ ถอยไปหาข้อความ: ขึ้นต้นด้วย not หรือมี <> / != นอกเครื่องหมายคำพูด)"""
        if "คนอื่น" in (base or ""):
            return True
        flt = flt or ""
        V = self.OWNER_VAR
        try:
            from qgis.core import (QgsExpression, QgsExpressionNodeBinaryOperator as _B,
                                   QgsExpressionNodeUnaryOperator as _U,
                                   QgsExpressionNodeFunction as _F,
                                   QgsExpressionNodeInOperator as _I,
                                   QgsExpressionNodeCondition as _C,
                                   QgsExpressionNodeLiteral as _L)
            e = QgsExpression(flt)
            if e.hasParserError() or e.rootNode() is None:
                raise ValueError(e.parserErrorString())
            บวก = {_B.boEQ, _B.boLike, _B.boILike, _B.boIs, _B.boRegexp}     # ★ รอบ 6 — ~ (regex) = ขั้วบวก
            ลบ = {_B.boNE, _B.boNotLike, _B.boNotILike, _B.boIsNot}

            def อ้าง(nd):
                try:
                    return nd is not None and V in nd.referencedVariables()
                except Exception:
                    return False

            def _attributeชื่อ(nd):
                """★ รอบ 8 (ผู้ตรวจ A R8-1) — attribute(@feature,'X') / attribute('X') ⇒ (ชื่อค่าคงที่ที่เจอ, เจอแบบไม่รู้ชื่อไหม)"""
                ชื่อ, ไม่รู้, st = set(), False, [nd]
                while st:
                    x = st.pop()
                    if x is None:
                        continue
                    if isinstance(x, _F):
                        _as = list(x.args().list()) if x.args() else []
                        try:
                            _fn = QgsExpression.Functions()[x.fnIndex()].name().lower()
                        except Exception:
                            _fn = ""
                        if _fn == "attribute":
                            _lit = [a for a in _as if isinstance(a, _L) and isinstance(a.value(), str)]
                            if _lit:
                                ชื่อ.update(str(a.value()).lower() for a in _lit)
                            else:
                                ไม่รู้ = True
                        st += _as
                    elif isinstance(x, _B):
                        st += [x.opLeft(), x.opRight()]
                    elif isinstance(x, _U):
                        st.append(x.operand())
                    elif isinstance(x, _I):
                        st.append(x.node())
                        st += list(x.list().list()) if x.list() else []
                    elif isinstance(x, _C):
                        for wt in x.conditions():
                            st += [wt.whenExp(), wt.thenExp()]
                        st.append(x.elseExp())
                return ชื่อ, ไม่รู้

            def คอลัมน์(nd):
                """★ รอบ 7 (ผู้ตรวจ A N3) — นับเฉพาะคอลัมน์ผู้รับผิดชอบ (NAME · เทียบแบบไม่สนตัวพิมพ์ เหมือน assign_owner)
                เดิมคอลัมน์ไหนก็ได้ ⇒ กอง "ของฉัน" ที่มี "EDITED_BY" <> @owner_name / not strpos("REMARK", @owner_name)
                ถูกตัดสินเป็นคนอื่น
                ★ รอบ 8 (ผู้ตรวจ A R8-1) — attribute()/attributes() ทำให้ QGIS ตอบ "ทุกคอลัมน์" (#!allattributes!#)
                  ⇒ ดูชื่อค่าคงที่ใน attribute(): มี NAME = นับ · มีแต่ชื่ออื่น = ไม่นับ · บอกไม่ได้ (ชื่อไม่ใช่ค่าคงที่ /
                  map_get(attributes(), ...)) = นับไว้ก่อน (เอียงไปทาง "คนอื่น" = ไม่ติดชื่อ ตามหลักของฟังก์ชันนี้)"""
                try:
                    if nd is None:
                        return False
                    cols = [str(c) for c in nd.referencedColumns()]
                except Exception:
                    return False
                if any(c.lower() == "name" for c in cols):
                    return True
                if any(c.startswith("#!") for c in cols):
                    ชื่อ, ไม่รู้ = _attributeชื่อ(nd)
                    return ("name" in ชื่อ) or ไม่รู้ or not ชื่อ
                return False

            def เทียบ(a, b):
                return (อ้าง(a) and คอลัมน์(b)) or (อ้าง(b) and คอลัมน์(a))

            def มีเทียบ(nd):
                """★ รอบ 6 — ข้างใน nd มีการเทียบ @owner_name กับคอลัมน์ "ชัด ๆ" (= <> LIKE IS ~ IN) ไหม"""
                st = [nd]
                while st:
                    x = st.pop()
                    if x is None:
                        continue
                    if isinstance(x, _B):
                        if (x.op() in บวก or x.op() in ลบ) and เทียบ(x.opLeft(), x.opRight()):
                            return True
                        st += [x.opLeft(), x.opRight()]
                    elif isinstance(x, _U):
                        st.append(x.operand())
                    elif isinstance(x, _I):
                        _ys = list(x.list().list()) if x.list() else []
                        if any(เทียบ(x.node(), y) for y in _ys):
                            return True
                        st.append(x.node())
                        st += _ys
                    elif isinstance(x, _F):
                        st += list(x.args().list()) if x.args() else []
                    elif isinstance(x, _C):
                        for wt in x.conditions():
                            st += [wt.whenExp(), wt.thenExp()]
                        st.append(x.elseExp())
                return False

            def ผูก(nd):
                """★ รอบ 6 — "ความสัมพันธ์" ที่ผูก @owner_name กับคอลัมน์ แต่ข้างในไม่มีการเทียบชัด ๆ = ขั้วบวก
                (array_contains(string_to_array("NAME", ','), @owner_name) · strpos("NAME", @owner_name))"""
                return อ้าง(nd) and คอลัมน์(nd) and not มีเทียบ(nd)
            # (node, ขั้วกลับไหม) · e ต้องมีชีวิตอยู่ตลอดการเดิน (node เป็นของ e)
            stack = [(e.rootNode(), False)]
            while stack:
                nd, กลับ = stack.pop()
                if nd is None:
                    continue
                if isinstance(nd, _B):
                    l, r = nd.opLeft(), nd.opRight()
                    if (nd.op() in บวก or nd.op() in ลบ) and เทียบ(l, r):
                        if (nd.op() in ลบ) != กลับ:
                            return True
                        continue
                    # ★ รอบ 6 — "ความสัมพันธ์ เทียบ ค่าคงที่": strpos("NAME", @owner_name) = 0 · ("NAME" = @owner_name) = false
                    #   · (...) is false ⇒ ค่าคงที่เป็นเท็จ (0 / false / '') = กลับขั้ว
                    if nd.op() in บวก or nd.op() in ลบ:
                        _lit, _rel = (l, r) if isinstance(l, _L) else ((r, l) if isinstance(r, _L) else (None, None))
                        if _lit is not None and อ้าง(_rel) and คอลัมน์(_rel):
                            try:
                                _v = _lit.value()
                            except Exception:
                                _v = None
                            _เท็จ = (_v == "") if isinstance(_v, str) else (_v is not None and _v in (0, False))
                            # ★ รอบ 7 (ผู้ตรวจ A N3) — ไล่เข้าไปใน "ความสัมพันธ์" ด้วยขั้วที่ถูก แทนการถือว่าเป็นขั้วบวกเสมอ
                            #   (("NAME" <> @owner_name) = true · if("NAME" <> @owner_name,1,0) = 1 · CASE ... = 1 = คนอื่น)
                            stack.append((_rel, กลับ != ((nd.op() in ลบ) != _เท็จ)))
                            continue
                    # ★ รอบ 6 (ผู้ตรวจ A B5) — ตัวดำเนินการอื่นที่ผูก @owner_name กับคอลัมน์ (ไม่ใช่ AND/OR) = ขั้วบวก
                    if nd.op() not in (_B.boAnd, _B.boOr) and ผูก(nd):
                        if กลับ:
                            return True
                        continue
                    stack += [(l, กลับ), (r, กลับ)]
                elif isinstance(nd, _U):
                    stack.append((nd.operand(), (not กลับ) if nd.op() == _U.uoNot else กลับ))
                elif isinstance(nd, _I):
                    รายการ = list(nd.list().list()) if nd.list() else []
                    if any(เทียบ(nd.node(), y) for y in รายการ):
                        if bool(nd.isNotIn()) != กลับ:
                            return True
                        continue
                    stack.append((nd.node(), กลับ))
                    stack += [(y, กลับ) for y in รายการ]
                elif isinstance(nd, _F):
                    _args = list(nd.args().list()) if nd.args() else []
                    try:
                        _ชื่อ = QgsExpression.Functions()[nd.fnIndex()].name().lower()
                    except Exception:
                        _ชื่อ = ""
                    # ฟังก์ชันที่ "เทียบ" ข้อความ (regexp_match(NAME, @owner_name)) = การเทียบขั้วบวก
                    if _ชื่อ in ("regexp_match",) and len(_args) >= 2 and เทียบ(_args[0], _args[1]):
                        if กลับ:
                            return True
                        continue
                    # ★ รอบ 6 (ผู้ตรวจ A B5) — ฟังก์ชันอื่นที่ผูก @owner_name กับคอลัมน์ โดยข้างในไม่มีการเทียบชัด ๆ = ขั้วบวก
                    #   ⇒ ใต้ NOT = คนอื่น (รอบ 5 ไม่นับ ⇒ ถดถอยจากรุ่นก่อน: not array_contains(...) กลายเป็น "ของฉัน")
                    if ผูก(nd):
                        if กลับ:
                            return True
                        continue
                    stack += [(y, กลับ) for y in _args]
                elif isinstance(nd, _C):
                    for wt in nd.conditions():
                        stack += [(wt.whenExp(), กลับ), (wt.thenExp(), กลับ)]
                    stack.append((nd.elseExp(), กลับ))
            return False
        except Exception:
            # parse ไม่ได้ (filter พัง ซึ่ง QGIS ก็ไม่วาด rule นั้นอยู่แล้ว / QGIS รุ่นเก่าไม่มีคลาส)
            # -> แบบเก่า: ขึ้นต้นด้วย not · หรือตัดข้อความในเครื่องหมายคำพูดทิ้ง แล้วหา <> / != ตรง ๆ
            #    เอียงไปทาง "ไม่ติดชื่อ" เพราะติดชื่อผิดกองทำให้อ่านผิดความหมาย
            #    ส่วนไม่ติดชื่อแค่ขาดข้อมูล
            if re.match(r"\s*not\b", flt, re.IGNORECASE):
                return True
            t = re.sub(r"'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"", "", flt)
            return re.search(r"<>|!=", t) is not None

    def _owner_labels_after_read(self):
        """★ 2.3.7 (review LC-12) — ซิงก์ป้าย @owner_name หลังเปิดโปรเจกต์ (เรียกผ่าน QTimer จาก _on_project_read)
        ไม่ทำให้โปรเจกต์ขึ้นสถานะ "แก้แล้ว" — เป็นการปรับป้ายให้ตรงชื่อที่เลือก ไม่ใช่งานของพนักงาน
        (ไม่งั้นแค่เปิดไฟล์อำเภอก็ถูกถาม "บันทึกโปรเจกต์ไหม" ตอนปิด QGIS)"""
        if not getattr(self, "_alive", True):
            return
        try:
            prj = QgsProject.instance()
            was_dirty = prj.isDirty()
            self._sync_owner_rule_labels()
            if not was_dirty and prj.isDirty():
                prj.setDirty(False)
        except Exception:
            pass

    def _sync_owner_rule_labels(self, name=None):
        """แก้ป้าย rule ที่ผูกกับ @owner_name ให้โชว์ชื่อที่เลือกอยู่

        ★ 31 ส.ค. 69 — QGIS ไม่ประเมินนิพจน์ในป้าย rule (ทดสอบแล้ว เป็นข้อความล้วน)
          จึงต้องให้ปลั๊กอินเขียนป้ายให้ · setLabel() ไม่ทำให้โปรเจกต์ขึ้น dirty
          แตะเฉพาะ rule ที่นิพจน์กรองมี @owner_name เท่านั้น — โปรเจกต์ที่ยังไม่ได้
          แปลงมาใช้ตัวแปรจะไม่ถูกแตะเลย
        คืนจำนวนป้ายที่แก้"""
        name = self._owner_label() if name is None else name
        n = 0
        try:
            from qgis.core import QgsRuleBasedRenderer
        except Exception:
            return 0
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                r = lyr.renderer()
            except Exception:
                continue
            if not isinstance(r, QgsRuleBasedRenderer):
                continue
            has_owner = False

            def walk(rule):
                nonlocal n, has_owner
                for c in rule.children():
                    try:
                        f = c.filterExpression() or ""
                    except Exception:
                        f = ""
                    if ("@" + self.OWNER_VAR) in f:      # ต้องเป็นตัวแปร ไม่ใช่ชื่อคอลัมน์/สตริงที่บังเอิญคล้าย
                        has_owner = True
                        # ป้ายที่ผู้ใช้ตั้งเองขึ้นต้นด้วย 👤 -> ตัดที่ " 👤" ที่เราต่อท้ายเอง (★ 25 ก.ย. 69)
                        # ★ 2.3.7 (review UX-41) — ป้ายว่าง/ขึ้นต้นด้วย " 👤" เดิมงอกแท็กซ้ำทุกรอบ ⇒ ฟังก์ชันบริสุทธิ์ (ดู docstring)
                        base = self._owner_label_base(c.label(), self._OWNER_TAG)
                        # rule ของ "คนอื่น" ห้ามติดชื่อ — ติดไปจะอ่านผิด
                        # (เห็น "L2-TS (คนอื่น) 👤Ailada" แล้วนึกว่าเป็นของ Ailada)
                        # ★ 25 ก.ย. 69 — ไม่ได้เขียนเป็น not (...) อย่างเดียวแล้ว V3 จริงใช้ <>
                        #   ดูเกณฑ์ใน _owner_rule_is_others · ป้ายที่เคยติดผิดแล้วพนักงานเซฟ
                        #   ลงไฟล์ตัวเอง ถูกล้างกลับตรงนี้ด้วย (base ตัด 👤ชื่อ ออกแล้ว ≠ ป้ายเดิม)
                        neg = self._owner_rule_is_others(f, base)
                        new_lab = base if neg else f"{base} {self._OWNER_TAG}{name}"
                        if c.label() != new_lab:
                            c.setLabel(new_lab)
                            n += 1
                    walk(c)

            walk(r.rootRule())
            if has_owner:
                try:
                    # ★ 31 ส.ค. 69 — QGIS แคชจำนวนแต่ละ rule ไว้ในเลเยอร์ พอเปลี่ยนตัวแปร
                    #   ตัวเลขในวงเล็บของสารบัญไม่นับใหม่ (ทดสอบแล้ว countSymbolFeatures()
                    #   คืนค่าเก่า) การตั้ง renderer ใหม่ด้วย clone() ล้างแคชนั้นได้
                    #   และไม่ทำให้โปรเจกต์ขึ้นสถานะ "แก้แล้ว"
                    lyr.setRenderer(r.clone())
                    # ★ นับใหม่เฉพาะเมื่อผู้ใช้เปิด "Show Feature Count" ไว้จริง —
                    #   บนตาราง PostGIS 200,000+ แถว การนับคือ scan ทั้งตาราง
                    _node = QgsProject.instance().layerTreeRoot().findLayer(lyr.id())
                    if _node is not None and _node.customProperty("showFeatureCount", 0) in (1, "1", True):
                        lyr.countSymbolFeatures()
                except Exception:
                    pass
                try:
                    lyr.triggerRepaint()
                    self.iface.layerTreeView().refreshLayerSymbology(lyr.id())
                except Exception:
                    pass
        return n

    def choose_owner_name(self):
        """เลือกชื่อผู้รับผิดชอบจากค่าที่มีจริงในชั้นแปลง แล้วตั้ง @owner_name"""
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        names = []
        if poly_lyr is not None:
            nf = self._resolve_field(poly_lyr, {'name'})
            if nf:
                try:
                    # ★ 2.3.7 (review DI-01) — NULL แบบมีชนิดจาก provider: str() = 'NULL' ⇒ เดิมได้ชื่อ 'NULL' ในรายการให้เลือก
                    # ★ rc2 (audit A3-11) — ไม่ตัดที่ 200 ค่า (แบบ 👤 มอบหมาย) · เดิมสาขาที่มีชื่อเกิน 200 ค่า ชื่อท้าย ๆ ไม่มีให้เลือก
                    names = sorted({t for t in map(_txt, poly_lyr.uniqueValues(poly_lyr.fields().indexOf(nf))) if t})
                except Exception:
                    names = []
            else:
                self.iface.messageBar().pushMessage(
                    "ผู้รับผิดชอบ", "ชั้นแปลงไม่มีคอลัมน์ NAME — เลือกได้เฉพาะ 'ทุกคน'",
                    level=1, duration=6)
        ALL = "— ทุกคน —"
        items = [ALL] + names
        cur = self._owner_get()
        # ★ ชื่อที่ตั้งค้างไว้อาจไม่อยู่ในรายการของชั้นที่เลือกอยู่ (สลับอำเภอ / ยังไม่มอบหมาย)
        #   ถ้าไม่ใส่กลับเข้าไป กด OK เฉย ๆ จะเด้งไปเลือก "ทุกคน" ทับค่าเดิมโดยไม่ตั้งใจ
        if cur and cur != self.OWNER_ALL and cur not in items:
            items.insert(1, cur)
        idx = items.index(cur) if cur in items else 0
        new, ok = QtWidgets.QInputDialog.getItem(
            self.iface.mainWindow(), "เลือกผู้รับผิดชอบ",
            "สัญลักษณ์ในโปรเจกต์จะไฮไลต์แปลงของคนที่เลือก\n"
            f"ค่าปัจจุบัน: {self._owner_label()}\n\n"
            "เลือกชื่อ (พิมพ์เองได้):",
            items, idx, True)
        if not ok:
            return
        new = (new or "").strip()
        val = self.OWNER_ALL if (new == ALL or not new) else new
        try:
            QgsExpressionContextUtils.setGlobalVariable(self.OWNER_VAR, val)
        except Exception:
            # ★ 2.3.7 (review ER-06) — เดิมแปะ exception ดิบในกล่อง
            self._fail("ผู้รับผิดชอบ", "ตั้งชื่อผู้รับผิดชอบไม่สำเร็จ", "ลองใหม่อีกครั้ง", modal=True, level=1)
            return
        self._refresh_owner_ui()
        n_lab = self._sync_owner_rule_labels()
        # ★ 2.4.0 (review PF-05) — เดิม refreshAllLayers() (reload ทุก provider ในโปรเจกต์ รวมชั้นหมุด/basemap) + refresh() ซ้ำ
        #   ⇒ redrawAllLayers(): ล้าง render cache ทุกชั้นแล้ววาดใหม่รอบเดียว ไม่ reload provider
        #   (@owner_name อาจอยู่ในป้าย/สัญลักษณ์แบบ data-defined ของชั้นใดก็ได้ จึงยังวาดใหม่ทุกชั้น)
        # ★ rc1 (F8 · §5.1 PF-05) — วาดใหม่ทุกแผนที่ 2D (หน้าต่างแผนที่รอง View ▸ New Map View ด้วย · เดิมเฉพาะแผนที่หลัก)
        _main = self.iface.mapCanvas()
        try:
            _cvs = list(self.iface.mapCanvases() or [])
        except Exception:
            _cvs = []
        if _main is not None and not any(c is _main for c in _cvs):
            _cvs.insert(0, _main)
        for _c in _cvs:
            try:
                _c.redrawAllLayers()
            except Exception:
                _log_exc("ผู้รับผิดชอบ: วาดแผนที่ใหม่ไม่สำเร็จ", once_key="PF-05:redraw")
        self.iface.messageBar().pushMessage(
            "ผู้รับผิดชอบ",
            f"ตั้งเป็น '{self._owner_label(val)}' แล้ว — สัญลักษณ์ที่ใช้ @owner_name จะเปลี่ยนตามทันที"
            + (f" · แก้ป้าย rule ให้ {n_lab} รายการ" if n_lab else "")
            + " (ค่านี้อยู่ระดับเครื่อง ใช้ได้ทุกสาขา ไม่ต้องตั้งใหม่)",
            level=0, duration=8)

    # ---------- ผู้ดูแล: เปลี่ยน Type ของแปลง (+หมุดของแปลงนั้น) ----------
    # ==================== 2.3.1 (21 ก.ย. 69) — เจ้าของงานสั่งเพิ่ม 2 ปุ่ม ====================

    def clear_score(self):
        """🧹 ล้าง Score (โหมดผู้ดูแล) — ล้างค่า SCORE ของแปลงที่เลือกให้ว่าง

        ใช้ตอนต้องการให้กลับไปทำใหม่ — เว็บติดตามงานจะนับแปลงนั้นเป็น "ยังไม่ทำ" อีกครั้ง

        🔴 เขียนเป็น **NULL จริง** ไม่ใช่สตริง 'NULL'
           (15 ก.ย. 69 มีคนเขียนสตริง `'NULL'` ลง SCORE 410 แปลง ⇒ เว็บหยุดอัปเดต 15 ชั่วโมง)
        🔴 ข้ามแปลง L1 (ไม่ล้าง · ทำแปลงที่เหลือต่อ) เว้นแต่กด 🔓 ปลดล็อก L1 ไว้
           — ★ 2.3.7 (review UX-06) docstring เดิมบอก "ด่านเดียวกับ set_score_value" ซึ่งไม่จริง: Score ปฏิเสธทั้งงาน
        ★ 2.3.7 (review DI-52) ว่าง "จริง" = NULL ของฐานเท่านั้น — สตริง 'NULL' / '' / ช่องว่าง ถูกล้างด้วย
        ★ 2.3.7 (review DI-53) กล่องยืนยันบอกจำนวนแปลงที่ยังมี AUDIT ค้าง (ปุ่มนี้ไม่ล้าง AUDIT — รอเจ้าของงานตัดสิน)
        · ลงบัฟเฟอร์ + Undo ได้ · ต้องกด 💾 บันทึก ถึงจะลงฐานข้อมูลจริง
        """
        title = "ล้าง Score"
        ready = self._admin_ready(title)
        if not ready:
            return
        poly_layer, _pt = ready
        fids = list(poly_layer.selectedFeatureIds())
        if not fids:
            self.iface.messageBar().pushMessage(
                title, "ยังไม่ได้เลือกแปลง — เลือกแปลงที่จะล้าง Score ก่อน "
                       "(เช่นใช้ ClusterID เลือกทั้งกลุ่ม)", level=1, duration=8)
            return
        sf = self._resolve_field(poly_layer, {'score'})
        if not sf:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      f"ชั้นแปลง '{poly_layer.name()}' ไม่มีคอลัมน์ SCORE — ล้างไม่ได้")
            return
        idx = poly_layer.fields().indexOf(sf)
        if not self._need_column_or_warn(poly_layer, sf, title):
            return
        ti = self._field_index(poly_layer.fields(), 'type')
        # ★ 2.3.7 (review DI-53) — อ่าน AUDIT มาในคำขอเดียวกัน เพื่อบอกในกล่องยืนยันว่ายังค้างกี่แปลง
        _af = self._resolve_field(poly_layer, {'audit'})
        ai = poly_layer.fields().indexOf(_af) if _af else -1

        # อ่านค่าเดิม + คัดแปลง L1 ออก (ถ้ายังไม่ปลดล็อก)
        req = (QgsFeatureRequest().setFilterFids(fids)
               .setFlags(QgsFeatureRequest.NoGeometry))
        cols = [idx] + [i for i in (ti, ai) if i != -1]
        req.setSubsetOfAttributes(cols)
        old, ข้าม_l1 = {}, 0
        ผลตรวจ = {}
        _fit = poly_layer.getFeatures(req)
        try:
            for f in _fit:
                if ti != -1 and not self._l1_unlocked():
                    if _is_l1(f.attribute(ti)):        # ★ 2.3.7 DI-01 (_txt)
                        ข้าม_l1 += 1
                        continue
                # ★ 2.3.7 (review DI-52) — เก็บค่าดิบ (ส่งเป็น oldValue ด้วย · PF-02)
                #   เดิม _txt ⇒ สตริง 'NULL' / '' / ช่องว่าง ถูกนับว่า "ว่างอยู่แล้ว" ⇒ ซ่อมแถวแบบเหตุ 15 ก.ย. ด้วยปุ่มนี้ไม่ได้
                old[f.id()] = f.attribute(idx)
                if ai != -1:
                    ผลตรวจ[f.id()] = _txt(f.attribute(ai))
        finally:
            _fit.close()

        # เฉพาะใบที่ยัง "มีค่าอยู่" เท่านั้นที่ต้องแก้ (NULL จริงอยู่แล้วไม่ต้องแตะ)
        todo = [fid for fid, v in old.items() if not _is_sql_null(v)]
        if not todo:
            self.iface.messageBar().pushMessage(
                title,
                ("แปลงที่เลือกไม่มีค่า SCORE อยู่แล้ว — ไม่มีอะไรต้องล้าง"
                 + (f" (ข้ามแปลง L1 {ข้าม_l1:,} ใบ)" if ข้าม_l1 else "")),
                level=0, duration=7)
            return

        from collections import Counter

        def _ชนิด(v):
            # ★ 2.3.7 (review DI-52) — แยกสตริงขยะให้เห็นในกล่องยืนยัน
            s = str(v).strip()
            if s.upper() == 'NULL':
                return 'สตริง "NULL"'
            if not s:
                return 'ค่าว่าง ""'
            return f'"{s}"'
        สรุป = Counter(_ชนิด(old[f]) for f in todo)
        # สรุปค่าเดิมแบบสั้น (ไม่เรียก `_summ` ของ assign_owner — นั่นเป็นฟังก์ชันในตัวมันเอง)
        _ด = ' · '.join(f'{k} {n:,}' for k, n in สรุป.most_common(6))
        if len(สรุป) > 6:
            _ด += f' · อื่น ๆ อีก {len(สรุป)-6} ค่า'
        เตือน = ""
        if ข้าม_l1:
            เตือน = (f"\n\n⚠️ ข้ามแปลง L1 ไป {ข้าม_l1:,} ใบ "
                     "(ถ้าต้องการล้างด้วย ให้กด 🔓 ปลดล็อก L1 ก่อน)")
        # ★ 2.3.7 (review DI-53 · ส่วนที่ไม่ต้องรอคำตัดสิน) — แปลงที่ล้าง SCORE แล้วแต่ AUDIT เดิมยังอยู่
        #   (เช่น AUDIT=1 ⇒ ทำใหม่แล้วกด Score 0 ถูกนับ "ผ่าน" โดยไม่ได้ตรวจซ้ำ) — ปุ่มนี้ยังไม่ล้าง AUDIT/SCORE หมุด
        ค้าง = Counter(ผลตรวจ[f] for f in todo if ผลตรวจ.get(f))
        if ค้าง:
            _ผ = ' · '.join(f"{'ผ่าน' if k == '1' else 'ไม่ผ่าน' if k == '0' else k} {n:,}"
                            for k, n in ค้าง.most_common())
            เตือน += (f"\n\n⚠️ {sum(ค้าง.values()):,} แปลงในนี้ยังมีผลตรวจ AUDIT ค้างอยู่ ({_ผ}) "
                      "— ปุ่มนี้ไม่ล้าง AUDIT")
        # ★ 2.3.7 (review UX-08) — งานจำนวนมาก ⇒ ปุ่มตั้งต้น No (Enter ตามความเคยชิน = ไม่ทำ)
        if self._ask(QtWidgets.QMessageBox.Question, title,
                     f"จะล้างค่า SCORE ของ {len(todo):,} แปลงให้ว่าง\n"
                     f"ค่าเดิม: {_ด}\n\n"
                     "แปลงพวกนี้จะกลับไปเป็น \"ยังไม่ทำ\" บนเว็บติดตามงาน — ยืนยันไหม?"
                     + เตือน, default=QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return

        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(poly_layer, title=title, what="ยังไม่ได้ล้าง Score"):
            return
        self.stored_selection = {poly_layer.id(): list(fids)}
        self._op_begin([poly_layer])
        # ★ None = NULL จริงในฐานข้อมูล · ห้ามส่งสตริง 'NULL'
        # ★ 2.3.7 (review PF-02 / DI-28) — ส่งค่าเดิม (Undo เร็ว) · เขียนได้ 0 แถว = ไม่ดัน undo step ว่าง
        n, err = self._write_attr(poly_layer, "Clear SCORE", todo, idx, None, old)
        self._op_commit()
        if err is not None:
            self.iface.messageBar().pushMessage(          # ★ 2.3.7 (review ER-06)
                title, f"ล้าง SCORE ไม่สำเร็จ — ย้อนกลับแล้ว ไม่มีอะไรเปลี่ยน · {self._LOG_HINT}", level=2, duration=0)
            return
        if not n:
            self.iface.messageBar().pushMessage(
                title, "เขียนค่าไม่สำเร็จ — ไม่มีอะไรเปลี่ยน", level=2, duration=8)
            return
        self.iface.messageBar().pushMessage(
            title, f"ล้าง SCORE ของ {n:,} แปลงแล้ว"
                   + (f" · ข้าม L1 {ข้าม_l1:,} ใบ" if ข้าม_l1 else "")
                   + " • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล", level=0, duration=8)
        QtCore.QTimer.singleShot(100, self.restore_selection)
