# -*- coding: utf-8 -*-
"""Donut — หักพื้นที่แปลงออกเป็นรู/แบ่งแปลง พร้อมจัดหมุด

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import math
from qgis.PyQt import QtWidgets
from qgis.core import (Qgis, QgsCoordinateTransform, QgsFeature, QgsFeatureRequest, QgsGeometry, QgsMessageLog,
                       QgsPointXY, QgsProject, QgsRectangle, QgsWkbTypes)
from ..core.util import (_fld_idx, _is_chor, _is_l1, _log_exc, _marker_type_from_parcel, _name_key, _newest_name,
                         _norm_utm, _reason_text, _txt, _UTM_FIELD_NAMES, _กริดจุด)
from ..map_tools import PolygonPickTool

# ★ 2.4.0 — บางเมธอดเรียก MultiLayerEditPro.<ชื่อ> ตรง ๆ (ย้ายมาตรงตัว) ⇒ main.py ผูกชื่อนี้เป็นคลาสหลักทันทีหลังสร้างคลาส
MultiLayerEditPro = None


class DonutMixin:
    """Donut — หักพื้นที่แปลงออกเป็นรู/แบ่งแปลง พร้อมจัดหมุด"""

    # ---------- 🍩 แบ่งหัก/แยก ----------
    def start_donut(self):
        """🍩 แบ่งหัก/แยก (โหมดผู้ดูแล) — หักรูปแปลงย่อยออกจากแปลงรวม

        งานเดียว: **ลบส่วนที่ทับออกจากแปลงรวม ให้เหลือเฉพาะส่วนที่ไม่ทับ** (`difference`)
          · แปลงย่อยกินถึงขอบ  ⇒ เหลือแปลงคงเหลือ
          · แปลงย่อยอยู่กลางใบ ⇒ ส่วนที่ทับกลายเป็นรูไปเอง (ไม่ต้องทำอะไรต่าง)
          🔑 21 ก.ย. เจ้าของงานยืนยันเองว่าสองเคสนี้คือเรื่องเดียวกัน

        วิธีใช้ (★ 2.3.6 — เจ้าของงานสั่ง 25 ก.ย. *"คลิกสร้างกรอบตามหมุดภายในแปลง · และวนมาหมุดเดิม"*):
          ① คลิกแปลงที่จะหัก 1 ใบ
          ② คลิก **หมุดที่อยู่ในแปลง/บนขอบแปลง** ทีละดวงตามแนวกรอบ (snap เฉพาะหมุดในแปลง)
          ③ **คลิกหมุดดวงแรกซ้ำ = ปิดกรอบ** → ส่วนในกรอบถูกหักออก **ว่างไว้ ไม่สร้างแปลงใหม่**
          หักต่อได้หลายกรอบในแปลงเดียวกัน · Backspace = ถอยหมุดล่าสุด · Esc = เลิก
          (ของเดิม ≤ 2.3.5: คลิกแปลงเต็มแล้วคลิก "แปลงที่จะหักออก" — เลิกใช้แล้ว)
        🔑 แปลงที่หักออก **ไม่ถูกแตะเลย** เปลี่ยนแค่รูปของแปลงรวม
        · ลงบัฟเฟอร์ + Undo ได้ · ต้องกด 💾 บันทึก ถึงจะลงฐานข้อมูลจริง
        """
        # ★ ล้างสถานะรอบก่อน **ก่อน** ตรวจสิทธิ์ — ไม่งั้นถ้าถูกปฏิเสธ สถานะเก่าจะค้าง
        #   (เจอตอน audit 21 ก.ย.: พนักงานกดแล้วถูกปฏิเสธ แต่ `_donut_stage` ยังเป็น 'inner')
        self._donut_stage = None
        self._donut_inner = []
        self._donut_outer = None
        self._donut_clear_bands()
        ready = self._mod_ready("แบ่งหัก/แยก")         # ★ 2.3.9 ผู้ช่วยผู้ดูแลใช้ได้ (เดิมผู้ดูแลเท่านั้น)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        self.cancel_transform()
        self._dol_clear_highlight()
        self._donut_lids = (poly_lyr.id(), point_lyr.id())
        self._donut_inner = []          # [(fid, geom)] เรียงตามที่คลิก
        self._donut_outer = None        # (fid, feature) ของแปลงเต็ม
        self._donut_stage = 'outer'     # ★ คลิกแปลงเต็มก่อน
        self._donut_arm(poly_lyr)

    def _donut_arm(self, poly_lyr, hint=True):
        """ติดตั้งเครื่องมือคลิกใหม่ทุกครั้ง — PolygonPickTool ออกแบบมาให้คลิกครั้งเดียวจบ
        hint=False ⇒ ไม่ดันข้อความแนะนำทับ (ใช้หลังขึ้นข้อความปฏิเสธ — audit 25 ก.ย.: เดิมคำแนะนำ
        ระดับ 2 ขึ้นทับข้อความ "แปลงนี้เป็น L1" ทันที ผู้ดูแลเลยเห็นแค่ขั้น ① ซ้ำโดยไม่รู้ว่าถูกปฏิเสธ)"""
        canvas = self.iface.mapCanvas()
        # ★ 2.3.1 — ตอนเลือกแปลงใน ให้เครื่องมือ **มองไม่เห็นแปลงเต็ม**
        #   แปลงในซ้อนอยู่ในแปลงเต็ม ⇒ ถ้าไม่ตัดออก จะเด้ง popup ให้เลือกทุกคลิก
        #   และไฮไลต์ตอนเลื่อนเมาส์ก็ขึ้นแปลงเต็ม ทำให้ไม่รู้ว่ากำลังจะคลิกใบไหน
        ข้าม = set()
        of = getattr(self, '_donut_outer', None)
        if self._donut_stage == 'inner' and of:
            ข้าม.add(of[0])
        self.temp_tool = PolygonPickTool(
            canvas, poly_lyr, self._donut_picked, self._dol_on_hover,
            done_cb=None, skip_fids=ข้าม,
            msg_title="แบ่งหัก/แยก", choose_prompt="เลือกแปลง:")      # ★ rc1 (F8 · §5.1 DI-44) เดิมหัวเรื่อง "DOL"
        canvas.setMapTool(self.temp_tool)
        if hint:
            self._donut_hint()

    def _donut_hint(self):
        if self._donut_stage == 'outer':
            # ★ 2.3.7 (review UX-29 · UX-35) — แถบแสดง HTML ⇒ <b> แทน ** · คำแนะนำขั้นตอน = เหลือง (เดิมแดง)
            self._donut_step1_msg("① คลิก <b>แปลงที่จะหัก</b> (คลิกใบเดียว) แล้วคลิกหมุดในแปลงทำกรอบ • Esc = ยกเลิก", 1, 15)

    def _donut_step1_msg(self, text, level=1, duration=8):
        """ข้อความของขั้น ① (คำแนะนำ/เหตุที่ปฏิเสธ) มีได้ทีละอัน และถูกเอาออกเมื่อเข้าขั้น ② / เลิก
        ★ audit รอบ 3 — ข้อความปฏิเสธ (เช่น "แปลงนี้เป็น L1") เคยค้างในกอง แล้วโผล่กลับมาตอนกำลังทำขั้น ②"""
        self._donut_pop_hint()
        bar = self.iface.messageBar()
        try:
            from qgis.gui import QgsMessageBar
            item = QgsMessageBar.createMessage("แบ่งหัก/แยก", text)
            bar.pushWidget(item, level, duration)
            self._donut_hint_item = item
        except Exception:
            bar.pushMessage("แบ่งหัก/แยก", text, level=level, duration=duration)

    def _donut_pop_hint(self):
        """★ audit รอบ 2 — ข้อความ ① (แดง 15 วิ) เคยค้างในกองข้อความ แล้วโผล่กลับมาหลังกด Esc
        และระหว่างขั้น ② หลังหักสำเร็จ ⇒ เอาออกเมื่อเข้าขั้น ② / เลิก / เริ่มใหม่"""
        it, self._donut_hint_item = getattr(self, "_donut_hint_item", None), None
        if it is not None:
            try:
                self.iface.messageBar().popWidget(it)
            except Exception:
                pass

    def _donut_picked(self, feat, layer):
        ready = self._mod_ready("แบ่งหัก/แยก")         # ★ 2.3.9 ผู้ช่วยผู้ดูแลใช้ได้
        if not ready:
            # ★ 2.3.7 (review LC-13) — เดิม return เฉย ๆ ⇒ เครื่องมือยังรอคลิกค้าง และกด Esc แล้วไฮไลต์แดงค้างจอ
            #   (callback ทำงานขณะ _picked=True ⇒ deactivate ไม่ล้างไฮไลต์ให้) ⇒ เลิกงานแบบเดียวกับ _donut_frame_done
            if not self._is_mod():
                self.iface.messageBar().pushMessage(
                    "แบ่งหัก/แยก", "ยกเลิก — ไม่ได้อยู่ในโหมดผู้ดูแล/ผู้ช่วยผู้ดูแลแล้ว (เปิดโหมดแล้วกด 🍩 ใหม่)", level=1, duration=8)
            self._donut_pop_hint()
            self._dol_clear_highlight()
            self._donut_clear_bands()
            self._donut_stage = None
            self.iface.actionSelect().trigger()
            return
        poly_lyr, point_lyr = ready
        # ★ ชั้นข้อมูลต้องเป็นชุดเดิมตอนกดปุ่ม (กันสลับคอมโบระหว่างทาง)
        if getattr(self, "_donut_lids", None) != (poly_lyr.id(), point_lyr.id()) \
                or (layer is not None and layer.id() != poly_lyr.id()):
            self.iface.actionSelect().trigger()
            self._ask(QtWidgets.QMessageBox.Warning, "แบ่งหัก/แยก",
                      "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม — ยกเลิก\nกดปุ่ม 🍩 แบ่งหัก/แยก ใหม่อีกครั้ง")
            return
        if self._donut_stage == 'outer':
            # ① คลิกแปลงที่จะหัก — เก็บไว้แล้วไปขั้นคลิกหมุดสร้างกรอบ (★ 2.3.6)
            g = QgsGeometry(feat.geometry())
            if g.isEmpty():
                self._donut_step1_msg("แปลงที่คลิกไม่มีรูป — คลิกใบอื่น", 1, 8)
                self._donut_arm(poly_lyr, hint=False)
                return
            # ★ 2.3.6 — กันชน L1 ตั้งแต่ตอนเลือก (เดิมไปรู้ตอนลงมือ = วาดกรอบเสร็จแล้วถูกปฏิเสธ)
            ti = self._field_index(poly_lyr.fields(), 'type')
            if ti != -1 and not self._l1_unlocked():
                tv = feat.attribute(ti)
                if _is_l1(tv):                           # ★ 2.4.0 (DU-01) lock_rules · NULL-safe
                    self._donut_step1_msg(
                        f"แปลงนี้เป็น {str(tv).strip()} — ถ้าต้องแก้จริงให้กด 🔓 ปลดล็อก L1 ก่อน", 1, 8)
                    self._donut_arm(poly_lyr, hint=False)
                    return
            # ★ 2.3.6 (audit 25 ก.ย.) — รูปแปลงเสีย (เส้นไขว้/หนาม) ต้องบอกตั้งแต่ตอนเลือก
            #   เดิมปล่อยให้วาดกรอบจนเสร็จ แล้วได้เหตุผลผิด ("ไม่เหลือรูป" / "กรอบไม่ทับแปลง") ทุกครั้งที่ลองใหม่
            # ★ 2.3.7 (b12 · เจ้าของงานขอ 3 ต.ค. ~22:30 "เจอแปลงที่เสีย ให้เด้ง popup ถามให้ซ่อมด้วย") — เดิมปฏิเสธเฉย ๆ
            #   ⇒ กล่องบอกปัญหา + เนื้อที่/มุมก่อน→หลังซ่อม · Yes = ซ่อม (1 ขั้น ↺ · ชั้นแปลงเท่านั้น) แล้วไปขั้นกรอบต่อ · No = ไม่แตะ
            _ซ่อม = ""
            if not g.isGeosValid():
                _ซ่อมได้ = self._donut_repair_offer(poly_lyr, point_lyr, feat, step1=True)
                if _ซ่อมได้ is None:
                    self._donut_arm(poly_lyr, hint=False)
                    return
                feat, _ซ่อม = _ซ่อมได้
            self._donut_outer = (feat.id(), feat)
            self._donut_stage = 'frame'
            self._donut_pop_hint()
            # 🔑 ไม่ไฮไลต์แปลงที่เลือกค้างไว้ — เจ้าของงานสั่ง (21 ก.ย.) ไฮไลต์ค้างแล้วสับสน
            self._dol_clear_highlight()
            self._donut_clear_bands()
            self._donut_arm_frame(poly_lyr, point_lyr)
            if _ซ่อม:                                   # ผลการซ่อมขึ้นบนสุด (เหนือคำแนะนำขั้น ②)
                self.iface.messageBar().pushMessage("แบ่งหัก/แยก", _ซ่อม[0], level=_ซ่อม[1], duration=15)
            return

    def _geom_problems(self, g, สูงสุด=4):
        """ปัญหาเรขาคณิตของ g เป็นข้อความไทย (validateGeometry แบบ GEOS · ตำแหน่งถ้ามี) · อ่านไม่ได้ ⇒ ข้อความกลาง"""
        out = []
        try:
            try:
                errs = g.validateGeometry(Qgis.GeometryValidationEngine.Geos)
            except Exception:
                errs = g.validateGeometry()
            for e in errs:
                w = str(e.what() or "")
                th = next((t for k, t in self._GEOS_TH if k in w.lower()), None) or f"รูปไม่ถูกต้อง ({w})"
                try:
                    if e.hasWhere():
                        th += f" ที่พิกัด {e.where().x():,.3f}, {e.where().y():,.3f}"
                except Exception:
                    pass
                if th not in out:
                    out.append(th)
        except Exception:
            _log_exc("_geom_problems: อ่านปัญหาเรขาคณิตไม่ได้", once_key="_geom_problems")
        if not out:
            out = ["รูปไม่ถูกต้องทางเรขาคณิต (ระบุจุดไม่ได้)"]
        return out[:สูงสุด] + ([f"… อีก {len(out) - สูงสุด:,} จุด"] if len(out) > สูงสุด else [])

    def _corner_count(self, g):
        """จำนวนมุมของทุกวง (ไม่นับจุดปิดวง)"""
        try:
            return sum(len(r) for r in self._ring_points(g))
        except Exception:
            return 0

    def _ring_nodes(self, g):
        """จำนวนจุดที่เส้นขอบของ g ตัด/แตะกันเอง: รวมเส้นขอบทุกวงแล้วแบ่งที่จุดตัด (unaryUnion) ⇒ จุดที่มีปลายเส้นมาบรรจบเกิน 2 เส้น
        ใช้ตัดสินว่าผลซ่อมที่ "แตกเป็นหลายส่วน" อธิบายได้ด้วยจุดตัดไหม: จุดตัด/แตะ k จุด แบ่งรูปเพิ่มได้ไม่เกิน k ส่วน
        (โบว์ไท/เลขแปด 1 จุด ⇒ 2 ส่วน · ซิกแซก 3 จุด ⇒ 4 ส่วน) · นับไม่ได้ ⇒ 0 (= ไม่ยอมให้แตก ปลอดภัยไว้ก่อน)"""
        try:
            เส้น = [QgsGeometry.fromPolylineXY(list(r) + [r[0]]) for r in self._ring_points(g) if len(r) >= 2]
            if not เส้น:
                return 0
            u = QgsGeometry.unaryUnion(เส้น)
            if u is None or u.isEmpty():
                return 0
            ปลาย = {}
            for pl in (u.asMultiPolyline() if u.isMultipart() else [u.asPolyline()]):
                if len(pl) < 2:
                    continue
                for q in (pl[0], pl[-1]):
                    k = (round(q.x(), 6), round(q.y(), 6))
                    ปลาย[k] = ปลาย.get(k, 0) + 1
            return sum(1 for n in ปลาย.values() if n > 2)
        except Exception:
            _log_exc("_ring_nodes: นับจุดที่เส้นขอบตัดกันเองไม่ได้", once_key="_ring_nodes")
            return 0

    def _donut_repair_geom(self, g0, poly_lyr):
        """รูปที่ซ่อมแล้วของ g0 ⇒ (รูป, "", [เนื้อที่แต่ละส่วน ถ้าผลแตกเป็นหลายส่วน มากไปน้อย]) หรือ (None, เหตุที่ไม่ซ่อมให้, [])
        makeValid แบบ Structure ก่อน (ทิ้งส่วนที่ยุบ = หนาม) · ไม่มี/ไม่ผ่าน ⇒ Linework (QGIS < 3.28 มีแบบเดียว)
        เก็บเฉพาะชิ้นที่เป็นรูป (ทิ้งเส้น/จุดที่ยุบ) · ชิ้นเนื้อที่ ~0 (< 1 ตร.มม. = เสื่อม) ทิ้ง · ชนิดตามชั้น (Multi คงเป็น Multi)
        ① ไม่แตก (จำนวนส่วนไม่เพิ่มจากเดิม): ทิ้งเศษ < 0.01 ตร.ม. (เกณฑ์เศษเดียวกับ 🍩) · เนื้อที่เปลี่ยนไม่เกิน max(0.05 ตร.ม., 0.1%)
        ② แตกเป็นหลายส่วน (โบว์ไท/เลขแปด) — ★ เจ้าของงานตอบ 3 ต.ค. ~23:40: เก็บทุกส่วนไว้ในแปลงเดิมแบบหลายส่วน แล้วแบ่งหักต่อ
           · ชั้นต้องเก็บ Multi ได้ (ชั้น Polygon ⇒ ไม่ซ่อม บอกชัด) · ทุกส่วน ≥ 0.01 ตร.ม. (ไม่เก็บเศษเป็นส่วนแยก)
           · ส่วนที่เพิ่ม ≤ จำนวนจุดที่เส้นขอบตัด/แตะกันเอง (_ring_nodes — โบว์ไท 1 จุด ⇒ 2 ส่วน; เกินนั้นแปลว่า makeValid
             แบ่งเพราะอย่างอื่น ⇒ ไม่เดา)
           · ไม่เทียบเนื้อที่กับรูปเดิม (เส้นขอบไขว้ ⇒ เนื้อที่แบบมีเครื่องหมายของวงหักล้างกันเอง เช่นโบว์ไทได้ 0) —
             ผู้เรียกแสดงเนื้อที่แต่ละส่วน + รวม ให้ผู้ใช้ตัดสิน
        ไม่ซ่อมให้: ผลว่าง · ผลไม่ valid · เงื่อนไข ①/② ไม่ผ่าน"""
        try:
            วิธี = [Qgis.MakeValidMethod.Structure, Qgis.MakeValidMethod.Linework]
        except AttributeError:
            วิธี = [None]
        try:
            multi = QgsWkbTypes.isMultiType(poly_lyr.wkbType())
        except Exception:
            multi = g0.isMultipart()
        ก้อน0 = max(1, self._donut_parts(g0))
        a0 = abs(g0.area())
        เหตุ = []
        จุดตัด = None
        for m in วิธี:
            try:
                try:
                    r = g0.makeValid(m, False) if m is not None else g0.makeValid()
                except TypeError:
                    r = g0.makeValid()
            except Exception:
                _log_exc("_donut_repair_geom: makeValid ล้ม", once_key="_donut_repair_geom")
                continue
            if r is None or r.isEmpty():
                เหตุ.append("ซ่อมแล้วไม่เหลือรูป")
                continue
            ชิ้น = []
            for q in (r.asGeometryCollection() if r.isMultipart() else [r]):
                if q is None or q.isEmpty() or q.type() != QgsWkbTypes.PolygonGeometry:
                    continue                      # เส้น/จุดที่ยุบ (หนาม · ขอบซ้อนทับ)
                for q2 in (q.asGeometryCollection() if q.isMultipart() else [q]):
                    if q2.area() >= 1e-6:         # เนื้อที่ ~0 = ชิ้นเสื่อม (หนามที่ยุบเป็นรูปแบน)
                        ชิ้น.append(QgsGeometry(q2))
            แตก = len(ชิ้น) > ก้อน0
            ขนาด = sorted((q.area() for q in ชิ้น), reverse=True)
            if แตก:
                _ส่วน = " + ".join(f"{x:,.2f}" for x in ขนาด)
                if not multi:
                    เหตุ.append(f"ซ่อมแล้วได้ {len(ชิ้น):,} ส่วน ({_ส่วน} ตร.ม.) แต่ชั้นนี้เก็บรูปได้ก้อนเดียว (Polygon) "
                                "— แยกเป็นแปลงตามส่วน หรือแก้เส้นที่ไขว้เอง")
                    continue
                if ขนาด[-1] < 0.01:
                    เหตุ.append(f"ซ่อมแล้วได้ {len(ชิ้น):,} ส่วน แต่มีส่วนเล็กกว่า 0.01 ตร.ม. ({ขนาด[-1]:,.4f} ตร.ม.) "
                                "— ไม่เก็บเศษเป็นส่วนแยก")
                    continue
                if จุดตัด is None:
                    จุดตัด = self._ring_nodes(g0)
                if len(ชิ้น) - ก้อน0 > จุดตัด:
                    เหตุ.append(f"ซ่อมแล้วแตกเป็น {len(ชิ้น):,} ส่วน (เดิม {ก้อน0:,}) มากกว่าที่จุดตัดของเส้นขอบ "
                                f"({จุดตัด:,} จุด) อธิบายได้")
                    continue
            else:
                ชิ้น = [q for q in ชิ้น if q.area() >= 0.01]
            if not ชิ้น:
                เหตุ.append("ซ่อมแล้วไม่เหลือรูป (เหลือแต่เศษ/เส้น)")
                continue
            g1 = ชิ้น[0] if len(ชิ้น) == 1 else QgsGeometry.collectGeometry(ชิ้น)
            if multi:
                g1.convertToMultiType()
            if g1.isEmpty() or not g1.isGeosValid():
                เหตุ.append("ซ่อมแล้วรูปยังไม่ถูกต้อง")
                continue
            if แตก:
                return g1, "", ขนาด
            a1 = g1.area()
            ยอม = max(self._REPAIR_TOL_M2, self._REPAIR_TOL_FRAC * max(a0, a1))
            if abs(a1 - a0) > ยอม:
                เหตุ.append(f"ซ่อมแล้วเนื้อที่เปลี่ยน {a0:,.2f} → {a1:,.2f} ตร.ม. (เกินเกณฑ์ ±{ยอม:,.2f} ตร.ม.)")
                continue
            return g1, "", []
        return None, (เหตุ[0] if เหตุ else "ซ่อมอัตโนมัติไม่ได้"), []

    def _donut_repair_offer(self, poly_lyr, point_lyr, feat, title="แบ่งหัก/แยก", step1=False):
        """แปลงที่รูปไม่ผ่าน isGeosValid ⇒ คำนวณรูปที่ซ่อมก่อน แล้วถาม (Yes = ซ่อมแล้วแบ่งหักต่อ · No/Esc/ปิด = ยกเลิก ไม่แตะอะไร)
        ซ่อม = 1 ขั้น ↺ ของปลั๊กอิน (_op_begin/คำสั่งแก้/_op_commit) เขียนเฉพาะชั้นแปลง · ไม่ย้าย/ลบหมุด (กติกา 1 มม. บอกอย่างเดียว)
        คืน (ฟีเจอร์ที่ซ่อมแล้ว อ่านใหม่จากชั้น, (ข้อความผล, level)) · None = ไม่ได้ซ่อม (ยกเลิก/ปฏิเสธ/ล้ม — แจ้งแล้ว)
        step1=True ⇒ ข้อความปฏิเสธใช้ช่องข้อความขั้น ① (_donut_step1_msg)"""
        g0 = QgsGeometry(feat.geometry())
        ปัญหา = self._geom_problems(g0)
        ชื่อแปลง = self._feat_label(poly_lyr, feat)
        g1, เหตุ, ส่วน = self._donut_repair_geom(g0, poly_lyr)
        if g1 is None:
            t = (f"รูปแปลง {ชื่อแปลง} ไม่ถูกต้องทางเรขาคณิต ({ปัญหา[0]}) — ซ่อมอัตโนมัติไม่ได้: {เหตุ} "
                 "· ซ่อมรูปเองก่อน แล้วค่อยแบ่งหัก")
            if step1:
                self._donut_step1_msg(t, 1, 15)
            else:
                self.iface.messageBar().pushMessage(title, t, level=1, duration=15)
            return None
        a0, a1 = g0.area(), g1.area()
        n0, n1 = self._corner_count(g0), self._corner_count(g1)
        เหล็ก = (self._donut_iron_after(poly_lyr, point_lyr, feat, g0, g1, None, [], [], (), ซ่อม=True)
                 if point_lyr is not None else "")
        # ★ เจ้าของงานตอบ 3 ต.ค. ~23:40 — ผลแตกหลายส่วน (โบว์ไท) ⇒ บอกเนื้อที่แต่ละส่วน + รวม ให้ผู้ใช้ตัดสินเอง
        #   (เนื้อที่ของรูปเดิมเทียบไม่ได้: เส้นขอบไขว้ ⇒ วงสองข้างของจุดตัดหักล้างกันเอง)
        _เนื้อที่ = ((f"ซ่อมรูปให้ได้แบบหลายส่วน — ซ่อมแล้วได้ {len(ส่วน):,} ส่วน: " + " + ".join(f"{x:,.2f}" for x in ส่วน)
                     + f" = {a1:,.2f} ตร.ม. · มุม {n0:,} → {n1:,}\n"
                     "(เก็บทุกส่วนไว้ในแปลงเดิมแบบหลายส่วน · เนื้อที่ของรูปเดิมเทียบไม่ได้ เพราะเส้นขอบไขว้กันจนเนื้อที่หักล้างกันเอง "
                     "— ตรวจเนื้อที่แต่ละส่วนก่อนยืนยัน)\n") if ส่วน else
                    f"ซ่อมรูปให้ได้: เนื้อที่ {a0:,.2f} → {a1:,.2f} ตร.ม. · มุม {n0:,} → {n1:,}\n")
        ข้อความ = (f"รูปแปลง {ชื่อแปลง} ไม่ถูกต้องทางเรขาคณิต — แบ่งหักไม่ได้จนกว่าจะซ่อม\n"
                   "ปัญหาที่พบ:\n" + "\n".join("· " + x for x in ปัญหา) + "\n\n"
                   + _เนื้อที่
                   + เหล็ก
                   + "\nซ่อมรูปแล้วแบ่งหักต่อไหม?\n"
                   "• Yes = ซ่อมรูปแล้วแบ่งหักต่อ (แก้เฉพาะรูปแปลงในบัฟเฟอร์ · ไม่แตะหมุด · กด ↺ ย้อนการซ่อมได้)\n"
                   "• No = ยกเลิก (ไม่แตะอะไร)")
        if self._ask(QtWidgets.QMessageBox.Question, title, ข้อความ,
                     QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                     QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return None
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(poly_lyr, title=title, what="ยังไม่ได้ซ่อมรูปแปลง"):
            return None
        self._op_begin([poly_lyr])
        poly_lyr.beginEditCommand("Donut / repair geometry")
        okv = False
        try:
            okv = bool(poly_lyr.changeGeometry(feat.id(), g1))
        except Exception:
            _log_exc("_donut_repair_offer: เขียนรูปที่ซ่อมไม่ได้")
            okv = False
        finally:
            if okv:
                poly_lyr.endEditCommand()
            else:
                poly_lyr.destroyEditCommand()
        self._op_commit()
        if not okv:
            self.iface.messageBar().pushMessage(
                title, "ซ่อมรูปแปลงไม่สำเร็จ — ไม่มีอะไรเปลี่ยน (รายละเอียดอยู่ในแผง Log Messages แท็บ MLEP)",
                level=2, duration=10)
            return None
        f2 = poly_lyr.getFeature(feat.id())
        ผล = ((f"ซ่อมรูปแปลงแล้ว · ได้ {len(ส่วน):,} ส่วน: " + " + ".join(f"{x:,.2f}" for x in ส่วน) + f" = {a1:,.2f} ตร.ม."
               if ส่วน else f"ซ่อมรูปแปลงแล้ว · เนื้อที่ {a0:,.2f} → {a1:,.2f} ตร.ม.")
              + f" · มุม {n0:,} → {n1:,}"
              + (" · ⚠️ หลังซ่อมผิดกติกาหมุด 1 มม. — แก้ด้วย Add Node / Move Node (รายละเอียดในกล่องก่อนซ่อม)" if เหล็ก else "")
              + " • ↺ ย้อนการซ่อมได้ · คลิกหมุดในแปลงทำกรอบต่อได้เลย")
        return f2, (ผล, 1 if เหล็ก else 0)

    def _donut_arm_frame(self, poly_lyr, point_lyr, hint=True):
        """★ 2.3.6 — ขั้นที่ 2: คลิกหมุดในแปลงสร้างกรอบ · คลิกหมุดดวงแรกซ้ำ = ปิดกรอบแล้วหัก
        อ่านรูปแปลง **สด** ทุกครั้ง (หลังหักรอบก่อน รูปเปลี่ยนแล้ว) · หักต่อได้หลายกรอบจนกด Esc
        hint=False หลังหักสำเร็จ ⇒ ข้อความผลลัพธ์ต้องอยู่บนสุด ไม่ถูกคำแนะนำทับ (audit 25 ก.ย.)"""
        from ..map_tools import DonutFrameTool
        of = getattr(self, '_donut_outer', None)
        if not of:
            return
        f = poly_lyr.getFeature(of[0])
        if f is None or not f.isValid() or f.geometry() is None or f.geometry().isEmpty():
            self.iface.messageBar().pushMessage("แบ่งหัก/แยก", "อ่านแปลงที่เลือกไม่ได้ — กดปุ่มใหม่อีกครั้ง",
                                                level=2, duration=8)       # ★ 2.3.7 b19 (doc-verify E9) อ่านไม่ได้ = แดง
            self._donut_stage = None
            return
        self._donut_outer = (f.id(), f)
        canvas = self.iface.mapCanvas()
        self.temp_tool = DonutFrameTool(canvas, self, poly_lyr, point_lyr, f.geometry(), self._donut_frame_done,
                                        outer_fid=f.id())
        canvas.setMapTool(self.temp_tool)
        if hint:
            self.temp_tool._hint()

    def _donut_frame_done(self, pts):
        """★ 2.3.6 — ปิดกรอบแล้ว (pts = พิกัดหมุดใน CRS ชั้นหมุด เรียงตามที่คลิก) -> หักกรอบออกจากแปลง
        ส่วนในกรอบ **ว่างไว้ ไม่สร้างแปลงใหม่** (เจ้าของงานเลือก 25 ก.ย.)
        คืน True = หักแล้ว (ติดตั้งเครื่องมือกรอบตัวใหม่ทับแล้ว) ·
             False = ไม่ได้หัก ⇒ เครื่องมือเดิมเก็บหมุดที่คลิกไว้ให้ถอย/แก้ต่อได้ (audit 25 ก.ย. —
                     เดิมกรอบผิดหรือตอบ "ไม่" แล้วหมุดที่คลิกมาทั้งหมดหายต้องเริ่มใหม่)"""
        title = "แบ่งหัก/แยก"
        ready = self._mod_ready(title)                  # ★ 2.3.9 ผู้ช่วยผู้ดูแลใช้ได้
        if not ready:
            # ★ audit 25 ก.ย. — ปิดโหมดผู้ดูแลกลางคันแล้วปิดกรอบ เดิมเงียบ กรอบหายไปเฉย ๆ
            #   (audit รอบ 2: ด่านนี้ล้มเพราะเรื่องชั้นข้อมูลได้ด้วย — ตอนนั้นมีกล่องบอกเหตุแล้ว ไม่ต้องขึ้นข้อความผิด)
            if not self._is_mod():
                self.iface.messageBar().pushMessage(
                    title, "ยกเลิก — ไม่ได้อยู่ในโหมดผู้ดูแล/ผู้ช่วยผู้ดูแลแล้ว (เปิดโหมดแล้วกด 🍩 ใหม่)", level=1, duration=8)
            self._donut_stage = None
            self.iface.actionSelect().trigger()
            return False
        poly_lyr, point_lyr = ready
        if getattr(self, "_donut_lids", None) != (poly_lyr.id(), point_lyr.id()):
            self.iface.actionSelect().trigger()
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม — ยกเลิก\nกดปุ่ม 🍩 แบ่งหัก/แยก ใหม่อีกครั้ง")
            return False
        of = getattr(self, '_donut_outer', None)
        if not of:
            return False
        tr = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance())
              if point_lyr.crs() != poly_lyr.crs() else None)
        วง = [tr.transform(q) if tr else QgsPointXY(q) for q in pts]
        เหตุ = None
        if len(วง) < 3:
            เหตุ = "กรอบต้องมีหมุดอย่างน้อย 3 ดวง"
            กรอบ = None
        else:
            กรอบ = QgsGeometry.fromPolygonXY([วง + [วง[0]]])
            # 🔑 เช็ค "แนวเดียวกัน" ด้วย convexHull ไม่ใช่ area() ของกรอบ —
            #    กรอบผีเสื้อ (ตัดกันเอง) สองปีกหักล้างกันจน area() = 0 ⇒ จะบอกเหตุผิด (sim58 จับได้)
            # ★ audit 25 ก.ย. — ใช้เพดาน 1 ตร.ซม. ไม่ใช่ "= 0 เป๊ะ": หมุด 3 ดวงบนขอบเดียวกัน
            #   มีเศษทศนิยม 1e-9 ตร.ม. แล้วผ่านด่านไป (59 ใน 200 ครั้ง)
            if กรอบ is None or กรอบ.isEmpty() or กรอบ.convexHull().area() < 1e-4:
                เหตุ = "กรอบไม่มีพื้นที่ (หมุดอยู่แนวเดียวกัน)"
            elif not กรอบ.isGeosValid():
                เหตุ = "กรอบตัดกันเอง — คลิกหมุดตามลำดับรอบกรอบ ไม่สลับไปมา"
        if เหตุ:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      เหตุ + "\nกด Backspace ถอยหมุดแล้วคลิกใหม่ได้เลย (Esc = เลิก)")
            return False
        เต็ม = poly_lyr.getFeature(of[0])
        if เต็ม is None or not เต็ม.isValid():
            self.iface.messageBar().pushMessage(title, "อ่านแปลงที่เลือกไม่ได้ — กดปุ่มใหม่อีกครั้ง",
                                                level=2, duration=8)       # ★ 2.3.7 b19 (doc-verify E9) อ่านไม่ได้ = แดง
            return False
        self._donut_busy = True
        ok = False
        try:
            self._donut_frame_n = len(วง)
            ok = bool(self._donut_execute_inner(poly_lyr, เต็ม, [(None, กรอบ)], title, True))
        finally:
            self._donut_busy = False
            self._donut_frame_n = 0
        if ok and self._donut_stage == 'frame':        # หักต่อได้อีกกรอบ จนกว่าจะกด Esc
            self._donut_arm_frame(poly_lyr, point_lyr, hint=False)
        return ok

    def _donut_clear_bands(self):
        """เก็บกวาดไฮไลต์หลายใบของเครื่องมือนี้ (ของเดิม `_dol_highlight_feature` ถือได้ใบเดียว)"""
        for rb in getattr(self, '_donut_bands', []):
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
        self._donut_bands = []

    @staticmethod
    def _donut_parts(g):
        try:
            return len(g.asGeometryCollection()) if g.isMultipart() else 1
        except Exception:
            return 1

    @staticmethod
    def _donut_difference(a, b, คืนพิกัด=()):
        """a - b แบบ **ปัดกริด 1 ไมโครเมตร** แล้วคืนพิกัดเดิมเป๊ะให้มุมที่มาจากรูปตั้งต้น
        ★ audit รอบ 1 — หมุดบนขอบ (ไม่ใช่มุม) ตกใน/นอกเส้นขอบแค่ ~1e-12 ม. ⇒ difference แบบทศนิยมเต็ม
          ทิ้ง "หนามกว้างศูนย์" ย้อนไปมุมที่ควรถูกตัด (สุ่ม 80 ครั้งเป็น 62) · ปัดกริดแล้วสะอาด 80/80
        ★ audit รอบ 2 — แต่กริดขยับ **ทุกมุม** ≤ 0.5 ไมโครเมตร ⇒ มุมร่วมกับแปลงข้างเคียงไม่ตรงกันเป๊ะ
          (QGIS จับมุมร่วมด้วยกรอบ 1e-8 ม. ตอนเปิด Topological Editing) ⇒ มุมที่ห่างมุมตั้งต้น ≤ 1.5e-6 ม.
          คืนพิกัดเดิม · เหลือบนกริดเฉพาะจุดตัดที่เกิดใหม่ (ไม่มีใครใช้ร่วมอยู่แล้ว)"""
        try:
            from qgis.core import QgsGeometryParameters
            gp = QgsGeometryParameters()
            gp.setGridSize(1e-6)
            r = a.difference(b, gp)
        except Exception:
            return a.difference(b)             # QGIS ก่อน 3.28 ไม่มีตัวปัดกริด
        if r is None or r.isEmpty():
            return r
        เดิม = {}
        for g in (a, b) + tuple(คืนพิกัด):
            try:
                for v in g.vertices():
                    เดิม.setdefault((round(v.x(), 6), round(v.y(), 6)), (v.x(), v.y()))
            except Exception:
                continue
        r2 = QgsGeometry(r)
        ขยับ = 0
        for i, v in enumerate(r.vertices()):
            o = None
            for dx in (0.0, -1e-6, 1e-6):
                for dy in (0.0, -1e-6, 1e-6):
                    o = เดิม.get((round(v.x() + dx, 6), round(v.y() + dy, 6)))
                    if o is not None:
                        break
                if o is not None:
                    break
            if o is None or (o[0] == v.x() and o[1] == v.y()):
                continue
            if math.hypot(o[0] - v.x(), o[1] - v.y()) <= 1.5e-6:
                r2.moveVertex(o[0], o[1], i)
                ขยับ += 1
        if ขยับ and r2.isGeosValid():
            return r2
        return r

    @staticmethod
    def _donut_turn(pts, j, tol=0.001):
        """มุมเลี้ยว (0-180°) ที่ pts[j] ของวงปิด pts (ไม่มีจุดปิดวงซ้ำ) · ข้ามจุดที่ซ้อนกัน ≤ tol
        0° = จุดบนเส้นตรง · 90° = มุมฉาก"""
        L = len(pts)
        b = pts[j]
        a = next((pts[(j - s) % L] for s in range(1, L) if pts[(j - s) % L].distance(b) > tol), None)
        c = next((pts[(j + s) % L] for s in range(1, L) if pts[(j + s) % L].distance(b) > tol), None)
        if a is None or c is None:
            return 0.0
        l1, l2 = a.distance(b), c.distance(b)
        cs = ((a.x() - b.x()) * (c.x() - b.x()) + (a.y() - b.y()) * (c.y() - b.y())) / (l1 * l2)
        return 180.0 - math.degrees(math.acos(max(-1.0, min(1.0, cs))))

    @staticmethod
    def _donut_needles(g, og0, TH=2.0, W=0.12, TOL_V=0.001, _ฐาน=None, _ที่=None):
        """★ audit รอบ 3 — หนามแหลม/เศษบาง ที่ **เกิดใหม่** ในรูป g (เทียบรูปก่อนหัก og0) → [(QgsPointXY, คำอธิบาย)]
          · หนาม  = มุมระหว่างสองด้าน < 2° และปากกว้าง (ด้านสั้น × sin มุม) < 12 ซม. — ทั้งหนามยื่นออกและรอยแยกเข้า
                    (เข็มจากหมุดเยื้อง 3 ซม. บนด้าน 10 ม. = 0.17° ปาก 3 ซม. · ลิ่มยาวที่ปากกว้างเกิน 12 ซม. = รูปที่วาดจริง ไม่นับ)
          · เศษบาง = ก้อนที่กว้างเฉลี่ย (2·พื้นที่/เส้นรอบรูป) < 2 ซม.
          · ไม่นับของที่รูปเดิมมีอยู่แล้วตรงนั้น (ไม่ใช่ผลของการหักครั้งนี้)
          (เดิมด่านดูแค่ "ก้อน < 0.01 ตร.ม." ⇒ เข็ม 0.01-0.3 ตร.ม. และลิ่มแหลมที่ติดกับแปลงคงเหลือ หลุดลงฐาน)
        ★ 2.3.6 audit รอบ 4 (30 ก.ย.) — เศษบางนับเพิ่ม: ก้อน **< 2 ตร.ม. ที่กว้างเฉลี่ย < 10 ซม.**
          ผู้ตรวจรอบ 4: หน้าแปลงโค้ง (มุมถี่ทุก 1 ม. เลี้ยว 2.3°) หมุดเยื้องเข้าใน 5-9 ซม. ⇒ เขียนเศษก้อนแยก
          0.03-0.1 ตร.ม. กว้าง 2.4-7.4 ซม. ลงฐานได้ถึง 10 ก้อนต่อครั้ง (กล่องบอกแค่ "ผ่ากลางแปลง") เพราะกว้างเกิน 2 ซม.
          · _ฐาน = ผลของ `_donut_needles_base(og0)` ที่คำนวณไว้แล้ว (ลูป ⑤ เรียกซ้ำหลายรอบกับ og0 เดิม)
          · _ที่ = ลิสต์ที่จะเติมรูปของจุดเสีย (QgsGeometry) ให้ลูป ⑤ เลือกหมุดที่อยู่ใกล้จุดเสีย"""
        MLEP = MultiLayerEditPro
        เดิม, เดิม_บาง = _ฐาน if _ฐาน is not None else MLEP._donut_needles_base(og0, TH, TOL_V)
        out = []
        for p, ang, q2 in MLEP._dn_แหลม(g, TH, W, TOL_V):
            if any(p.distance(q) <= TOL_V for q in เดิม) or any(p.distance(q) <= 0.01 for q, _t in out):
                continue
            # บอกปลายอีกข้างด้วย — ปลายแหลมมักอยู่ไกลจากหมุดที่ต้องตรวจ (เช่นแหลมที่ 10,20 แต่ต้นเหตุอยู่ที่มุม 20,20)
            out.append((QgsPointXY(p), "หนามแหลม %.2f° ที่ %.3f, %.3f (ยาว %.2f ม. ไปทาง %.3f, %.3f)"
                        % (ang, p.x(), p.y(), p.distance(q2), q2.x(), q2.y())))
            if _ที่ is not None:
                _ที่.append(QgsGeometry.fromPolylineXY([QgsPointXY(p), QgsPointXY(q2)]))
        for part in MLEP._dn_บาง(g):
            try:
                if any(part.intersects(q) for q in เดิม_บาง):
                    continue
                c = part.pointOnSurface()
                p = QgsPointXY(c.asPoint()) if c is not None and not c.isEmpty() else QgsPointXY()
            except Exception:
                p = QgsPointXY()
            try:
                _P = part.constGet().perimeter()
            except Exception:
                _P = part.length()
            out.append((p, "เศษบาง %.3f ตร.ม. กว้างเฉลี่ย %.1f ซม. ที่ %.3f, %.3f"
                        % (part.area(), (200.0 * part.area() / _P) if _P > 0 else 0.0, p.x(), p.y())))
            if _ที่ is not None:
                _ที่.append(QgsGeometry(part))
        return out

    @staticmethod
    def _dn_ก้อน(geom):
        try:
            return list(geom.asGeometryCollection()) if geom.isMultipart() else [geom]
        except Exception:
            return []

    @staticmethod
    def _dn_แหลม(geom, th, w, TOL_V=0.001):
        """มุมแหลม < th° (และปากกว้าง < w ถ้าให้ w) ของทุกวง → [(จุดยอด, มุม, ปลายอีกข้างของด้านสั้น)]"""
        out = []
        for part in MultiLayerEditPro._dn_ก้อน(geom):
            try:
                rings = part.asPolygon()
            except Exception:
                continue
            for r in rings:
                pts = [QgsPointXY(p) for p in r[:-1]]
                L = len(pts)
                for j in range(L):
                    b = pts[j]
                    a = next((pts[(j - s) % L] for s in range(1, L) if pts[(j - s) % L].distance(b) > TOL_V), None)
                    c = next((pts[(j + s) % L] for s in range(1, L) if pts[(j + s) % L].distance(b) > TOL_V), None)
                    if a is None or c is None:
                        continue
                    l1, l2 = a.distance(b), c.distance(b)
                    cs = ((a.x() - b.x()) * (c.x() - b.x()) + (a.y() - b.y()) * (c.y() - b.y())) / (l1 * l2)
                    ang = math.degrees(math.acos(max(-1.0, min(1.0, cs))))
                    if ang < th and (w is None or min(l1, l2) * math.sin(math.radians(ang)) < w):
                        out.append((b, ang, a if l1 <= l2 else c))     # ปลายอีกข้างของด้านสั้น
        return out

    @staticmethod
    def _dn_บาง(geom):
        out = []
        M = MultiLayerEditPro
        for part in M._dn_ก้อน(geom):
            try:
                P = part.constGet().perimeter()
            except Exception:
                P = part.length()
            if P <= 0:
                continue
            w = 2.0 * part.area() / P
            if w < M._DN_บาง or (w < M._DN_บาง_เล็ก and part.area() < M._DN_เล็ก):
                out.append(part)
        return out

    @staticmethod
    def _donut_needles_base(og0, TH=2.0, TOL_V=0.001):
        """หนาม (เกณฑ์หลวม 2 เท่า) + เศษบาง ที่รูปก่อนหักมีอยู่แล้ว — ใช้กันนับของเดิมเป็นของเสียใหม่"""
        M = MultiLayerEditPro
        return [p for p, _a, _q in M._dn_แหลม(og0, TH * 2, None, TOL_V)], M._dn_บาง(og0)

    def _donut_markers_near(self, poly_lyr, g, pad=0.10):
        """★ รอบ 8 (ผู้ตรวจ A R8-2) — g = **กรอบที่วาด** (เดิมกรอบสี่เหลี่ยมของทั้งแปลง: แปลงถนนแนวทแยงคลุมหมุด 200,000 ดวง
          2.5 วิ ก่อนกล่องยืนยันขึ้น) · มุมใหม่ทุกมุมอยู่บน/ชิดแนวกรอบ ⇒ หมุดที่ยืมชื่อได้ (≤ 1 ซม.) อยู่ในกรอบ +10 ซม. ครบ
        ★ รอบ 7 (ผู้ตรวจ A N1) — ตำแหน่งหมุดทุกดวงรอบรูป g (พิกัดชั้นแปลง) = ชุดเดียวกับที่ _donut_marker_plan
        ยืมชื่อให้มุมใหม่ (โหมดกรอบ: หมุดทุกดวงในรัศมี 1 ซม.) ⇒ _donut_fit_frame นับ "มุมเปลือย" ตรงกับแผนหมุดจริง
        อ่านไม่ได้ ⇒ ลิสต์ว่าง (นับเฉพาะหมุดที่คลิกแบบเดิม · แผนหมุดตอนลงมือยังตรวจชั้นเองอีกชั้น)"""
        out = []
        try:
            point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
            if point_lyr is None or g is None or g.isEmpty():
                return out
            to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), QgsProject.instance())
                     if poly_lyr.crs() != point_lyr.crs() else None)
            to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance())
                       if to_pt is not None else None)
            bb = g.boundingBox()
            bb.grow(pad)
            rect = to_pt.transformBoundingBox(bb) if to_pt is not None else bb
            it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect).setNoAttributes())
            try:
                for f in it:
                    gg = f.geometry()
                    if gg is None or gg.isEmpty():
                        continue
                    try:
                        q = QgsPointXY(gg.asPoint())
                    except Exception:
                        continue
                    out.append(to_poly.transform(q) if to_poly is not None else q)
            finally:
                it.close()
        except Exception:
            return []
        return out

    def _donut_fit_frame(self, og0, frame, other_markers=None):
        """★ 2.3.6 — ให้ขอบแปลงกับกรอบพบกันพอดีที่หมุด (เจ้าของงานเลือก 25 ก.ย. "ย้ายมุมไปทับหมุด")
        🔴 เขียนใหม่หลัง audit รอบ 2 — รุ่นก่อนแทรกหมุดทีละดวงเทียบ "รูปที่ถูกดันไปแล้ว"
           ⇒ ผลขึ้นกับลำดับคลิก (351.50 กับ 350.75 ตร.ม. · บางลำดับได้รู + สะพานบาง) ·
           และหมุดที่เยื้องมุมเดิมไม่กี่ มม./ซม. ถูกแทรกเป็นมุมเพิ่ม "ข้าง" มุมเดิม ⇒ มุมเดิมหลุดเป็นเศษก้อนเล็ก
           (0.2 ตร.ม. มุมแคบ 0.23° แล้วกล่องยืนยันยังบอกว่า "ผ่ากลางแปลง")
        🔴 ปรับหลัง audit รอบ 3 (ผู้ตรวจยิงสุ่ม ~2,000 ครั้ง + คู่แปลงจริง 20265/20187 เยื้องหมุด ≤ 3 ซม.)
           · มุมแปลงที่อยู่ "นอกกรอบ" ห่างแนวกรอบไม่กี่ ซม. ไม่มีใครดู ⇒ เข็มหลุดเป็นก้อนที่ 2 (คู่จริง: เขียนลงไป 13/80)
           · มุมซ้อน (node ซ้อน) ย้ายไปตัวเดียว ⇒ หนาม · ย้ายมุมที่ควรอยู่รอด (จุดบนเส้นตรง/มุมที่มีหมุดทับพอดีแล้ว)
             แล้วหมุดของมุมนั้นถูกลบ · หมุด 2 ดวงแย่งมุมเดียวกัน ⇒ ผลขึ้นกับลำดับคลิก · หมุดใน 5-10 ซม. ไม่ถูกดัน
        🔴 ปรับหลัง audit รอบ 4 (30 ก.ย. 69 — ผู้ตรวจยิงหน้าแปลงโค้ง/แปลง 2,000 มุม/มุมซ้อนเยื้อง/สะท้อนแผนที่)
           · หน้าแปลงโค้งมุมถี่ (เลี้ยว < 10° ⇒ แทรก) หมุดเยื้องเข้าใน 5-9 ซม. ⇒ เศษก้อนแยกกว้าง 2-7 ซม. ถูกเขียนลงฐาน
             (ลูป ⑤ นับแค่หนามแหลม) ⇒ ⑤ นับเศษบาง (< 10 ซม. · < 2 ตร.ม.) ด้วย และลอง "ย้ายทุกดวงที่ใกล้มุม" ก่อน
           · ⑤ ไล่ตามพิกัด x,y แล้วเก็บตัวแรกที่ดีขึ้น ⇒ หมุน/สะท้อนแผนที่ได้คนละผล (4 ใน 8 ทิศ) ⇒ ลองทุกดวงในรอบ
             แล้วเลือกตัวที่ดีสุดด้วยคีย์ที่ไม่ขึ้นกับทิศ (ของเสีย, จำนวนมุมที่ย้าย, ระยะขยับรวม, เลขมุมของแปลง)
           · ④ งอ "ด้านกรอบทั้งด้าน" ไปหามุมแปลง ⇒ ตัดเนื้อที่นอกกรอบที่วาดเงียบ ๆ ถึง 2.45 ตร.ม./รวมรู/แยกก้อน
             ⇒ ดึงเฉพาะเมื่อลิ่มที่ตัดเพิ่ม < 0.5 ตร.ม. หรือส่วนที่ดึงเป็นเศษบางแยกก้อนอยู่แล้ว (_donut_execute_inner บอกเนื้อที่ + รู)
           · แปลง 2,000 มุม ค้างถึง 60 วิ ⇒ ผู้สมัคร ④ คำนวณครั้งเดียว · ตารางแฮช · มุมซ้อนของแต่ละหมุดหาครั้งเดียว ·
             ⑤ มีงบจำนวนครั้งตายตัว (ไม่ขึ้นกับความเร็วเครื่อง) + เพดานเวลากันเหนียว
           · มุมซ้อนเยื้อง ≤ 1 ซม. ข้างมุมกรอบ (หมุดตรงมุมเป๊ะ) ถูกปฏิเสธ ⇒ ดึงเข้าข้างมุมกรอบ ลองทั้งสองข้างแล้วเลือกข้างที่สะอาด
        กติกา — จัดทุกหมุดเทียบ **รูปเดิม** ก่อน แล้วค่อยลงมือ (ไม่ขึ้นกับลำดับคลิก):
          ① ห่างมุมเดิม ≤ 1 มม.  ⇒ ใช้พิกัดมุมเดิมเป๊ะ (ไม่แตะรูป) · มุมนั้นมีเจ้าของแล้ว ดวงอื่นห้ามย้าย
          ② ห่างมุมเดิม ≤ 10 ซม. ⇒ **ย้ายมุมเดิมไปที่หมุด** (หมุดคือมุมนั้น แค่วาดเยื้อง) · มุมซ้อนทุกตัวย้ายไปด้วยกัน
             เฉพาะ "มุมจริง" (เลี้ยว ≥ 10°) ที่หมุดไม่ได้อยู่บนเส้นขอบพอดี (ห่าง ≤ 1 ซม. ย้ายเสมอ)
             จุดบนเส้นตรง/เส้นโค้งถี่ ๆ = คนละจุดกับหมุด ⇒ แทรกหมุดเป็นมุมใหม่ มุมเดิมอยู่ต่อพร้อมหมุดของมัน
             หลายดวงแย่งมุมเดียว ⇒ ดวงที่ใกล้สุดได้ ที่เหลือแทรก
          ③ ห่างขอบ: นอก ≤ 0.5 ม. / ใน ≤ 10 ซม. ⇒ แทรกหมุดเป็นมุมใหม่บนขอบนั้น
          ④ มุมแปลงนอกกรอบที่ห่างแนวกรอบ ≤ 5 ซม. (หรือห่างมุมกรอบ ≤ 1 ซม.) ⇒ ดึงเข้าเป็นมุมของกรอบ
             (ไม่เหลือเศษบางระหว่างกรอบกับขอบ) · เฉพาะที่ลิ่มที่ตัดเพิ่ม < 0.5 ตร.ม. หรือเป็นเศษบางแยกก้อนอยู่แล้ว
          ⑤ ผลยังมีหนามแหลม/เศษบาง ⇒ ลอง "ย้ายทุกดวงที่ใกล้มุม" ก่อน แล้วลองสลับ ย้าย ⇄ แทรก ทีละดวง
             (ทุกดวงที่อยู่ใกล้จุดเสียในรอบเดียวกัน · เลือกตัวที่ดีที่สุด) เก็บเฉพาะที่ของเสียลดลง
          · หมุดที่อยู่ "ใน" แปลง ดันเฉพาะเมื่อหมุดข้างเคียงในกรอบก็ติดขอบด้วย (มุมของ "รู" ที่บังเอิญใกล้ขอบ ไม่ดัน)
          · แปลงหลายก้อน: ดันเฉพาะก้อนที่กรอบตัดผ่านจริง
          · ย้ายแล้วรูปเสีย ⇒ แทรกแทน · แทรกแล้วรูปเสีย ⇒ ข้าม (หนามที่เหลือ ด่านใน _donut_execute_inner ปฏิเสธ)
        คืน (รูปที่ปรับแล้ว, กรอบที่ปรับแล้ว, ขยับ=[(ระยะจากขอบเดิม, อยู่ในแปลงไหม)] ของหมุดที่แทรก,
             ย้ายมุม=[(มุมเดิม, ตำแหน่งใหม่)], ดึง=จำนวนมุมแปลงที่ดึงเข้ากรอบ)"""
        TOL_V, TOL_MUM, TOL_OUT, TOL_IN, TOL_PULL = 0.001, 0.10, 0.5, 0.10, 0.05
        TOL_SAME, MUM_JING = 0.01, 10.0
        TOL_WEDGE = 0.5                       # ★ รอบ 4 — ลิ่มที่ ④ ตัดเพิ่มนอกกรอบที่วาดได้ไม่เกินนี้ (ตร.ม.)
        try:
            ring0 = [QgsPointXY(p) for p in frame.asPolygon()[0][:-1]]
        except Exception:
            return og0, frame, [], [], 0
        n = len(ring0)
        if n < 3:
            return og0, frame, [], [], 0
        # ด้าน/มุมของ "ก้อนที่กรอบตัดผ่าน" · เลข vertex แบบรวมทั้งรูป (ตรงกับที่ QGIS ใช้ รวมจุดปิดวง)
        # allv = มุมทุกก้อนทุกวง (ใช้ตอนย้ายมุมซ้อน/มุมร่วมของวงอื่นไปด้วยกัน)
        polys = og0.asMultiPolygon() if og0.isMultipart() else [og0.asPolygon()]
        segs, verts, allv, turn, base = [], [], [], {}, 0
        ข้างเคียง = {}                                               # ★ รอบ 4 — มุมก่อน/หลังของแต่ละมุม (ข้ามมุมซ้อน ≤ 1 มม.)
        for poly in polys:
            try:
                ok_part = frame.intersects(QgsGeometry.fromPolygonXY(poly))
            except Exception:
                ok_part = True
            for rr in poly:
                pts = [QgsPointXY(p) for p in rr[:-1]]
                L_ = len(pts)
                for j in range(L_):
                    allv.append((base + j, pts[j]))
                    if ok_part:
                        turn[base + j] = self._donut_turn(pts, j, TOL_V)
                        verts.append((base + j, pts[j]))
                        segs.append((base + j + 1, pts[j], pts[(j + 1) % L_]))
                        ข้างเคียง[base + j] = [q for q in (
                            next((pts[(j - s_) % L_] for s_ in range(1, L_) if pts[(j - s_) % L_].distance(pts[j]) > TOL_V), None),
                            next((pts[(j + s_) % L_] for s_ in range(1, L_) if pts[(j + s_) % L_].distance(pts[j]) > TOL_V), None))
                            if q is not None]
                base += len(rr)
        if not segs:
            return og0, frame, [], [], 0

        # ★ รอบ 4 — ตารางแฮชหามุม/ด้านที่ใกล้หมุด (เดิมไล่ทุกมุม × ทุกหมุด = 2,000 × 150 ต่อครั้ง)
        #   ผลเท่าเดิมเป๊ะ: เจอในรัศมีที่ตารางครอบ ⇒ คือตัวใกล้สุดจริง (เสมอกัน = ตัวที่มาก่อน เหมือน min เดิม)
        #   ไม่เจอ (หมุดกลางแปลง) ⇒ ไล่ทั้งหมดแบบเดิม
        CELL = 0.5
        vgrid = _กริดจุด([vp for _vi, vp in verts], CELL)
        sgrid = {}
        for pos, (_af, pa, pb) in enumerate(segs):
            kseg = max(1, int(math.ceil(pa.distance(pb) / (CELL / 2.0))))
            cells = set()
            for s_ in range(kseg + 1):
                tt = s_ / kseg
                cells.add((math.floor((pa.x() + tt * (pb.x() - pa.x())) / CELL),
                           math.floor((pa.y() + tt * (pb.y() - pa.y())) / CELL)))
            for c in cells:
                sgrid.setdefault(c, []).append(pos)

        def _ระยะด้าน(f, pos):
            after, pa, pb = segs[pos]
            dx, dy = pb.x() - pa.x(), pb.y() - pa.y()
            l2 = dx * dx + dy * dy
            t = 0.0 if l2 <= 0 else max(0.0, min(1.0, ((f.x() - pa.x()) * dx + (f.y() - pa.y()) * dy) / l2))
            d = math.hypot(f.x() - (pa.x() + t * dx), f.y() - (pa.y() + t * dy))
            return (d, after, t)

        def ใกล้ด้าน(f):
            cx, cy = math.floor(f.x() / CELL), math.floor(f.y() / CELL)
            best, seen = None, set()
            for ddx in (-2, -1, 0, 1, 2):
                for ddy in (-2, -1, 0, 1, 2):
                    for pos in sgrid.get((cx + ddx, cy + ddy), ()):
                        if pos in seen:
                            continue
                        seen.add(pos)
                        r = _ระยะด้าน(f, pos)
                        if best is None or (r[0], pos) < best[0]:
                            best = ((r[0], pos), r)
            if best is not None and best[1][0] <= 0.6:      # ตัวอย่างบนด้านห่างกัน ≤ 25 ซม. ⇒ ±2 ช่องครอบ 0.6 ม. แน่นอน
                return best[1]
            best = None
            for pos in range(len(segs)):
                r = _ระยะด้าน(f, pos)
                if best is None or r[0] < best[0]:
                    best = r
            return best

        def ใกล้มุม(f):
            h = vgrid.ใกล้สุด(f, CELL)
            return verts[h[0]] if h is not None else min(verts, key=lambda x: x[1].distance(f))

        ข้อมูล = []
        for f in ring0:
            vi, vp = ใกล้มุม(f)
            de, after, t = ใกล้ด้าน(f)
            ข้อมูล.append({'f': f, 'vi': vi, 'vp': vp, 'dv': vp.distance(f), 'de': de, 'after': after, 't': t,
                           'ใน': og0.contains(QgsGeometry.fromPointXY(f))})
        ring = list(ring0)
        ปัก = []                                                     # ① มุมเดิมที่มีหมุดในกรอบทับพอดี
        for k, x in enumerate(ข้อมูล):
            if x['dv'] <= TOL_V:
                ring[k] = QgsPointXY(x['vp'])
                ปัก.append(x['vp'])
        กรอบ0 = QgsGeometry.fromPolygonXY([ring + [ring[0]]])
        if กรอบ0 is None or กรอบ0.isEmpty() or not กรอบ0.isGeosValid():
            return og0, frame, [], [], 0

        def ติดขอบ(x):
            return x['dv'] <= TOL_MUM or x['de'] <= (TOL_IN if x['ใน'] else TOL_OUT)

        งาน, ย้ายได้ = {}, []
        for k, x in enumerate(ข้อมูล):
            if x['dv'] <= TOL_V or not ติดขอบ(x):
                continue                                             # ① · หมุดกลางแปลงตามปกติ
            if x['ใน'] and not (ติดขอบ(ข้อมูล[k - 1]) or ติดขอบ(ข้อมูล[(k + 1) % n])):
                continue                                             # มุมของรูกลางแปลง — ไม่ดันขอบ
            if x['dv'] <= TOL_MUM and not any(x['vp'].distance(q) <= TOL_V for q in ปัก):
                ย้ายได้.append(k)
                ย้ายก่อน = x['dv'] <= TOL_SAME or (turn.get(x['vi'], 0.0) >= MUM_JING and x['de'] > TOL_V)
                งาน[k] = 'ย้าย' if ย้ายก่อน else 'แทรก'             # ②
            else:
                งาน[k] = 'แทรก'                                      # ③

        def คีย์หมุด(k):
            """★ รอบ 4 — ลำดับที่ไม่ขึ้นกับทิศของแผนที่และลำดับคลิก: ระยะ + ตำแหน่งบนแปลง (เลขมุม/ด้าน) — ไม่ใช้ x,y ดิบ"""
            x = ข้อมูล[k]
            return (round(x['dv'], 9), round(x['de'], 9), x['vi'], x['after'], round(x['t'], 9))

        def กันแย่ง(ง):
            """มุมเดียวกัน (≤ 1 มม. รวมมุมซ้อน) ขอย้ายหลายดวง ⇒ ดวงที่ใกล้สุดได้ ที่เหลือแทรก
            ★ รอบ 4 — เสมอกัน ⇒ ตัดสินด้วยคีย์หมุด (เดิมใช้พิกัด x,y ⇒ หมุน/สะท้อนแผนที่ได้คนละดวง)"""
            ได้แล้ว = []
            for k in sorted((k for k, a in ง.items() if a == 'ย้าย'), key=คีย์หมุด):
                if any(ข้อมูล[k]['vp'].distance(q) <= TOL_V for q in ได้แล้ว):
                    ง[k] = 'แทรก'
                else:
                    ได้แล้ว.append(ข้อมูล[k]['vp'])
            return ง

        # ★ รอบ 4 — มุมที่ต้องย้ายไปด้วยกัน (มุมซ้อน/มุมร่วมของวงอื่น) ของแต่ละหมุด: หาครั้งเดียว
        agrid = _กริดจุด([q for _i, q in allv], 0.002)
        ซ้อน = {k: [allv[j][0] for j in agrid.ทั้งหมด(ข้อมูล[k]['vp'], TOL_V)] for k in ย้ายได้}

        # ★ รอบ 4 — ④ ผู้สมัคร "ดึงมุมแปลงเข้ากรอบ" คำนวณครั้งเดียวนอก ลงมือ (เดิมทุกครั้ง = 2,000 มุม × ทุกด้านกรอบ)
        #   ไม่ขึ้นกับแผน ย้าย/แทรก (เทียบ ring + กรอบ0 ซึ่งคงที่) — ตอนลงมือแค่ตัดมุมที่ถูกย้ายไปแล้วออก
        from qgis.core import QgsPoint
        try:
            _eng = QgsGeometry.createGeometryEngine(กรอบ0.constGet())
            _eng.prepareGeometry()
        except Exception:
            _eng = None

        def _ในกรอบ0(vp):
            if _eng is not None:
                return _eng.contains(QgsPoint(vp.x(), vp.y()))
            return กรอบ0.contains(QgsGeometry.fromPointXY(vp))
        try:
            _ขอบ = QgsGeometry.fromPolylineXY(ring + [ring[0]])
        except Exception:
            _ขอบ = None
        rgrid = _กริดจุด(ring, 0.002)
        ดึงได้, สงสัย = [], []            # [(kk, t, จุดที่ดึง, ลิ่ม ตร.ม.)]
        มุมกรอบ = []                     # ★ รอบ 4 — มุมแปลงห่างมุมกรอบ ≤ 1 ซม. [(kc, จุด)]
        for _vi, vp in verts:
            if rgrid.มี(vp, TOL_V):
                continue
            try:
                if _ในกรอบ0(vp):
                    continue
            except Exception:
                continue
            if _ขอบ is not None:
                try:
                    if _ขอบ.distance(QgsGeometry.fromPointXY(vp)) > TOL_PULL + 1e-6:
                        continue                                     # ไกลแนวกรอบ — ไม่ต้องไล่ทุกด้าน
                except Exception:
                    pass
            best = None
            for kk in range(n):
                pa, pb = ring[kk], ring[(kk + 1) % n]
                dx, dy = pb.x() - pa.x(), pb.y() - pa.y()
                l2 = dx * dx + dy * dy
                if l2 <= 0:
                    continue
                t = ((vp.x() - pa.x()) * dx + (vp.y() - pa.y()) * dy) / l2
                if t <= 0 or t >= 1:
                    continue
                d = math.hypot(vp.x() - (pa.x() + t * dx), vp.y() - (pa.y() + t * dy))
                if best is None or d < best[0]:
                    best = (d, kk, t)
            if best is not None and best[0] <= TOL_PULL:
                pa, pb = ring[best[1]], ring[(best[1] + 1) % n]
                ผู้สมัคร = (best[1], best[2], QgsPointXY(vp), 0.5 * pa.distance(pb) * best[0])
                (ดึงได้ if ผู้สมัคร[3] < TOL_WEDGE else สงสัย).append(ผู้สมัคร)
                continue
            kc = min(range(n), key=lambda kk: (round(ring[kk].distance(vp), 12), kk))
            if TOL_V < ring[kc].distance(vp) <= TOL_SAME:
                มุมกรอบ.append((kc, QgsPointXY(vp), _vi))

        def _นับเสีย(geom_frame, og_=None, ที่=None):
            try:
                return len(self._donut_needles(self._donut_difference(og0 if og_ is None else og_, geom_frame, (og0,)), og0,
                                               _ฐาน=ฐาน, _ที่=ที่))
            except Exception:
                return 0
        ฐาน = self._donut_needles_base(og0)
        # มุมเยื้องมุมกรอบ: แทรก "หลัง" หรือ "ก่อน" มุมกรอบ — ลองทั้งสองข้าง
        #   ① ข้างที่ด้านกรอบวิ่งไปทางเดียวกับขอบแปลงที่ออกจากมุมเยื้อง (เบี่ยง < 10°) = ข้างที่มีเศษบางให้กิน
        #      (ตัดสินด้วยทิศ ไม่ใช่ของเสียเทียบรูปเดิม — หมุดปลายอีกด้านที่ถูกแทรกเข้าขอบทีหลังทำให้รูปเดิมหลอกได้:
        #       สุ่ม neardup ของผู้ตรวจ ด้านบนเอียง 1.5 มม. ⇒ เลือกผิดข้าง เหลือเศษ 0.011 ตร.ม.)
        #   ② ไม่ชัด ⇒ ข้างที่ของเสียน้อยกว่า · ลิ่มเล็กกว่า · เสมอ = ข้างที่มาหลังมุมกรอบเมื่อเดินทวนเข็มนาฬิกา (ไม่ขึ้นกับทิศที่คลิก)
        if มุมกรอบ:
            _ccw = sum(ring[i].x() * ring[(i + 1) % n].y() - ring[(i + 1) % n].x() * ring[i].y() for i in range(n)) > 0
            _cos10 = math.cos(math.radians(10.0))
            for kc, vp, vi_ in มุมกรอบ:
                ตัวเลือก = []
                for ข้าง in ('หลัง', 'ก่อน'):
                    kk, t = (kc, 1e-9) if ข้าง == 'หลัง' else ((kc - 1) % n, 1.0 - 1e-9)
                    วง = list(ring)
                    วง.insert(kk + 1, vp)
                    g_ = QgsGeometry.fromPolygonXY([วง + [วง[0]]])
                    if g_ is None or g_.isEmpty() or not g_.isGeosValid():
                        continue
                    อีกมุม = ring[(kc + 1) % n] if ข้าง == 'หลัง' else ring[(kc - 1) % n]
                    ลิ่ม = abs(QgsGeometry.fromPolygonXY([[ring[kc], vp, อีกมุม, ring[kc]]]).area())
                    ux, uy = อีกมุม.x() - ring[kc].x(), อีกมุม.y() - ring[kc].y()
                    แนว = -2.0
                    for u in ข้างเคียง.get(vi_, ()):
                        if u.distance(ring[kc]) <= TOL_SAME:
                            continue                                 # ขอบสั้นกลับไปหามุมกรอบ — ไม่ใช่แนวของเศษ
                        wx, wy = u.x() - vp.x(), u.y() - vp.y()
                        _l = math.hypot(ux, uy) * math.hypot(wx, wy)
                        if _l > 0:
                            แนว = max(แนว, (ux * wx + uy * wy) / _l)
                    ตัวเลือก.append([แนว >= _cos10, round(แนว, 6), ข้าง, (kk, t, vp, ลิ่ม), g_, ลิ่ม])
                ตรง = [c for c in ตัวเลือก if c[0]]
                if len(ตรง) == 1:
                    ดีสุด = ตรง[0][3]
                elif ตัวเลือก:
                    ดีสุด = min(ตัวเลือก, key=lambda c: (_นับเสีย(c[4]), round(c[5], 9),
                                                         0 if (c[2] == 'หลัง') == _ccw else 1))[3]
                else:
                    continue
                (ดึงได้ if ดีสุด[3] < TOL_WEDGE else สงสัย).append(ดีสุด)
        # ลิ่ม ≥ 0.5 ตร.ม. ⇒ ดึงเฉพาะเมื่อส่วนที่ถูกตัดเป็น "เศษบางแยกก้อน" อยู่แล้ว (ขยะที่ด่านจะปฏิเสธอยู่ดี)
        #   ไม่ใช่ส่วนหนึ่งของแปลงคงเหลือ (คอคอดใต้ปลายรอยบาก/ขอบรู/ขอบที่งอ) — กันงอด้านกรอบยาว 100 ม. ตัดเนื้อที่ 2.45 ตร.ม.
        if สงสัย:
            try:
                เศษ = self._dn_บาง(self._donut_difference(og0, กรอบ0, (og0,)))
            except Exception:
                เศษ = []
            for c in สงสัย:
                try:
                    if any(q.distance(QgsGeometry.fromPointXY(c[2])) <= 1e-6 for q in เศษ):
                        ดึงได้.append(c)
                except Exception:
                    continue
        ดึงได้.sort(key=lambda a: (a[0], a[1]))

        # ★ รอบ 6 (ผู้ตรวจ A B1) — ระยะจากมุมถึงแนวกรอบ จำไว้ข้ามทุกรอบของ ⑤ (มุมเดิมของแปลงคำนวณครั้งเดียว)
        _แคชแนว = {}

        def _ชิดแนว(x, y):
            k = (round(x, 6), round(y, 6))
            v = _แคชแนว.get(k)
            if v is None:
                try:
                    v = _ขอบ.distance(QgsGeometry.fromPointXY(QgsPointXY(x, y))) <= TOL_PULL + 1e-6
                except Exception:
                    v = False
                _แคชแนว[k] = v
            return v

        def _ปรับรูป(ง, ทีละขั้น):
            """ย้าย/แทรกตามแผน ง → (g, ขยับ, ย้ายมุม)
            ★ รอบ 6 (ผู้ตรวจ A B7) — ทีละขั้น=False = ทางเร็ว: ทำครบทุกขั้นแล้วตรวจ isGeosValid ครั้งเดียว
              (เดิมตรวจทุกหมุด: กรอบ 300 หมุดบนแปลง 1,904 มุม × 14 รอบของ ⑤ = 4,280 ครั้ง 3.1 วิ)
              ไม่ผ่าน/ย้ายหรือแทรกล้ม ⇒ คืน None แล้วผู้เรียกทำใหม่ทีละขั้นแบบเดิมทุกประการ (ตัดขั้นที่ทำให้รูปเสียทิ้ง)"""
            g = QgsGeometry(og0)
            ขยับ, ย้ายมุม, ตก = [], [], []
            for k in sorted((k for k, a in ง.items() if a == 'ย้าย'), key=lambda k: ข้อมูล[k]['vi']):
                x = ข้อมูล[k]                                        # ย้ายมุมไม่เปลี่ยนเลข vertex ⇒ ทำก่อน
                g2 = QgsGeometry(g) if ทีละขั้น else g
                ok = True
                for i in ซ้อน[k]:                                   # มุมซ้อน/มุมร่วมของวงอื่น ย้ายไปด้วยกัน
                    if not g2.moveVertex(x['f'].x(), x['f'].y(), i):
                        ok = False
                if not ทีละขั้น:
                    if not ok:
                        return None
                    ย้ายมุม.append((QgsPointXY(x['vp']), QgsPointXY(x['f'])))
                elif ok and g2.isGeosValid():
                    g = g2
                    ย้ายมุม.append((QgsPointXY(x['vp']), QgsPointXY(x['f'])))
                else:
                    ตก.append(k)                                     # ย้ายแล้วรูปเสีย ⇒ แทรกแทน
            # แทรกจากเลข vertex มากไปน้อย · ด้านเดียวกันแทรกจากปลายด้านไปหาต้นด้าน ⇒ เลขที่คำนวณจากรูปเดิมยังถูก
            แทรก = [ข้อมูล[k] for k, a in ง.items() if a == 'แทรก'] + [ข้อมูล[k] for k in ตก]
            for x in sorted(แทรก, key=lambda r: (r['after'], r['t']), reverse=True):
                if not ทีละขั้น:
                    if not g.insertVertex(x['f'].x(), x['f'].y(), x['after']):
                        return None
                    if x['de'] > TOL_V:
                        ขยับ.append((x['de'], x['ใน']))
                    continue
                g2 = QgsGeometry(g)
                if g2.insertVertex(x['f'].x(), x['f'].y(), x['after']) and g2.isGeosValid():
                    g = g2
                    if x['de'] > TOL_V:
                        ขยับ.append((x['de'], x['ใน']))
            if not ทีละขั้น and not g.isGeosValid():
                return None
            return g, ขยับ, ย้ายมุม

        def ลงมือ(ง):
            g, ขยับ, ย้ายมุม = _ปรับรูป(ง, False) or _ปรับรูป(ง, True)
            # ④ มุมแปลงนอกกรอบ ห่างแนวกรอบ ≤ 5 ซม. (ตกกลางด้านกรอบ ไม่ใช่หัว/ท้าย) ⇒ ดึงเข้าเป็นมุมของกรอบ
            ย้ายแล้ว = _กริดจุด([a for a, _b in ย้ายมุม], 0.002)
            # ★ รอบ 5 — ลิ่ม ≥ 0.5 ตร.ม.: ตัดสินบน "รูปที่ปรับแล้ว" (หลังดัน/ย้ายมุม) ไม่ใช่รูปเดิม
            #   มุมกรอบที่อยู่ในขอบไม่กี่ มม. ⇒ แถบยังติดกับแปลงคงเหลือ "ก่อน" ดัน แต่แยกเป็นเศษ "หลัง" ดัน
            #   (ผู้ตรวจรอบ 5: ขอบยาว 60-160 ม. หมุดเยื้อง 1-3 ซม. ถูกปฏิเสธ 81-108/450 ทั้งที่รุ่นก่อนตัดสะอาด)
            #   ⇒ ดึงเมื่อ "ชิ้นของ (รูปที่ปรับแล้ว − กรอบ)" ที่มีมุมนี้ อยู่ห่างแนวกรอบไม่เกิน 5 ซม. ทั้งชิ้น
            #     = เลนส์บางระหว่างกรอบกับขอบ (ขยะ) · ชิ้นที่มีส่วนไกลกว่านั้น = แปลงคงเหลือจริง (คอคอด/ขอบรู) ไม่ดึง
            เลนส์ = []
            if สงสัย and _ขอบ is not None:
                try:
                    _d = self._donut_difference(g, กรอบ0, (og0,))
                    _ชิ้น = ((list(_d.asGeometryCollection()) if _d.isMultipart() else [_d])
                             if _d is not None and not _d.isEmpty() else [])
                except Exception:
                    _ชิ้น = []
                # ★ รอบ 6 (ผู้ตรวจ A B1) — เดิมไล่ "ทุกผู้สมัคร × ทุกชิ้น" (q.distance) แล้วไล่ทุกมุมของชิ้นซ้ำทุกผู้สมัคร
                #   เลนส์ยาวมุมถี่ 1,946 มุม = 2.3 ล้านครั้งต่อการลงมือ 1 ครั้ง (6-12 วิ · เพดานเวลาของ ⑤ กันไม่ได้
                #   เพราะเช็กได้แค่ระหว่างการเรียก) ⇒ หาชิ้นของผู้สมัครด้วยตารางมุม · ตัดสินว่าเป็นเลนส์ครั้งเดียวต่อชิ้น
                #   ผลเท่าเดิม: ชิ้นแรก (ลำดับน้อยสุด) ที่มีมุมตรงผู้สมัคร · ทุกมุมของชิ้นห่างแนวกรอบ ≤ 5 ซม.
                _มุมชิ้น, _ของชิ้น = [], []
                for _i, q in enumerate(_ชิ้น):
                    for v in q.vertices():
                        _มุมชิ้น.append(QgsPointXY(v.x(), v.y()))
                        _ของชิ้น.append(_i)
                _ตาราง = _กริดจุด(_มุมชิ้น, 0.002)
                _เป็นเลนส์ = {}
                for c in สงสัย:
                    try:
                        _hit = _ตาราง.ทั้งหมด(c[2], 1e-6)
                        if _hit:
                            _i = min(_ของชิ้น[h] for h in _hit)
                        else:                                        # ไม่ตรงมุมของชิ้นไหน ⇒ ไล่ระยะแบบเดิม
                            _p = QgsGeometry.fromPointXY(c[2])
                            _i = next((j for j, q in enumerate(_ชิ้น) if q.distance(_p) <= 1e-6), None)
                        if _i is None:
                            continue
                        if _i not in _เป็นเลนส์:
                            _เป็นเลนส์[_i] = all(_ชิดแนว(v.x(), v.y()) for v in _ชิ้น[_i].vertices())
                        if _เป็นเลนส์[_i]:
                            เลนส์.append(c)
                    except Exception:
                        pass
            เพิ่ม = [(kk, t, q) for kk, t, q, _l in list(ดึงได้) + [c for c in เลนส์ if c not in ดึงได้]
                    if not ย้ายแล้ว.มี(q, TOL_V)]
            วง = list(ring)
            for kk, _t, q in sorted(เพิ่ม, key=lambda a: (a[0], a[1]), reverse=True):
                วง.insert(kk + 1, q)
            กรอบ, ดึง = QgsGeometry.fromPolygonXY([วง + [วง[0]]]), len(เพิ่ม)
            if เพิ่ม and (กรอบ is None or กรอบ.isEmpty() or not กรอบ.isGeosValid()):
                กรอบ, ดึง = QgsGeometry(กรอบ0), 0                   # ดึงแล้วกรอบเสีย ⇒ ไม่ดึง
            return g, กรอบ, ขยับ, ย้ายมุม, ดึง

        def ตรวจ(r):
            ที่ = []
            return _นับเสีย(r[1], r[0], ที่), ที่

        # ★ รอบ 6 (ผู้ตรวจ A B2) — มุมใหม่ที่ "ไม่มีหมุดให้ยืม" (เกณฑ์เดียวกับ _donut_marker_plan: ไม่ตรงมุมเดิม ≤ 1 มม.
        #   และไม่มีหมุดที่คลิกอยู่ ≤ 1 ซม.) — ใช้กัน ⑤ค ถอยแล้วได้มุมเปลือยเพิ่ม
        _มุมเดิม = _กริดจุด([QgsPointXY(v.x(), v.y()) for v in og0.vertices()], 0.002)
        # ★ รอบ 7 (ผู้ตรวจ A N1) — ชื่อยืมได้จากหมุดที่คลิก **และหมุดทุกดวงรอบแปลง** ในรัศมี 1 ซม. (ตรงกับ _donut_marker_plan)
        #   เดิมนับแค่หมุดที่คลิก ⇒ มุมที่แผนหมุดยืมชื่อหมุดของแปลงเองได้ ถูกนับว่าเปลือย (หลอก) แล้ว ⑤ง ไปหมุนขอบ
        _หมุดคลิก = _กริดจุด([QgsPointXY(x['f']) for x in ข้อมูล] + [QgsPointXY(q) for q in (other_markers or [])], 0.02)

        def _ผลหัก(r):
            try:
                return self._donut_difference(r[0], r[1], (og0,))
            except Exception:
                return None

        def นับเปลือย(r, d=None):
            d = _ผลหัก(r) if d is None else d
            if d is None or d.isEmpty():
                return 0
            เห็น = _กริดจุด([], 0.002)
            n_ = 0
            for v in d.vertices():
                q = QgsPointXY(v.x(), v.y())
                if _มุมเดิม.มี(q, TOL_V) or เห็น.มี(q, TOL_V):
                    continue                                         # มุมเดิม · จุดปิดวง/ซ้ำ
                เห็น.เพิ่ม(q)
                if not _หมุดคลิก.มี(q, 0.01):
                    n_ += 1
            return n_

        def คะแนน(r, นับ_):
            """เรียงดีไปแย่: ของเสีย · มุมที่ย้าย · ระยะขยับรวม (ไม่มีพิกัดดิบ ⇒ หมุน/สะท้อนแผนที่ได้ผลเดียวกัน)"""
            return (นับ_, len(r[3]), round(sum(a.distance(b) for a, b in r[3]) + sum(d for d, _i in r[2]), 6))

        งาน = กันแย่ง(งาน)
        งานตั้งต้น = dict(งาน)                                       # ★ รอบ 5 — ไว้ดูว่า ⑤ ย้ายมุมไหนเพิ่ม (⑤ค)
        ผล = ลงมือ(งาน)
        นับ, ที่ = ตรวจ(ผล) if ย้ายได้ else (0, [])
        if นับ:                                                      # ⑤
            import time as _time
            t0 = _time.monotonic()
            # งบตายตัวตามขนาดแปลง (ผลไม่ขึ้นกับความเร็วเครื่อง) · เวลาเป็นแค่เพดานกันเหนียว
            งบ = max(8, min(40, int(60000 / max(1, len(allv)))))

            def พลิก(ง, k):
                ลอง = dict(ง)
                ลอง[k] = 'แทรก' if ง[k] == 'ย้าย' else 'ย้าย'
                if ลอง[k] == 'ย้าย':
                    for kk in list(ลอง):
                        if kk != k and ลอง[kk] == 'ย้าย' and ข้อมูล[kk]['vp'].distance(ข้อมูล[k]['vp']) <= TOL_V:
                            ลอง[kk] = 'แทรก'
                return ลอง
            def _ห่างเสีย(k):
                x = ข้อมูล[k]
                try:
                    return min((q.distance(QgsGeometry.fromPointXY(p)) for q in ที่ for p in (x['f'], x['vp'])),
                               default=float("inf"))
                except Exception:
                    return float("inf")
            # ⑤ก ดวงที่ใกล้มุม (≤ 10 ซม.) และอยู่ใกล้จุดเสีย ≤ 1 ม. ย้ายหมด — หน้าแปลงโค้ง: มุมโค้งคือหมุดที่วาดเยื้อง
            #   ★ รอบ 5 — เดิมย้าย "ทุกดวง" ⇒ จุดบนเส้นตรงที่อยู่ไกลจุดเสีย 12 ม. ถูกย้าย + หมุดของมันถูกลบ (ขัดกติกา ②)
            #     ⇒ เฉพาะดวงที่อยู่ใกล้จุดเสีย ≤ 1 ม. · ⑤ค ถอยการย้ายที่ไม่จำเป็นกลับอีกชั้น
            #     (ไม่ใช้เกณฑ์มุมเลี้ยว: วงกลม 2,000 มุมเลี้ยวมุมละ 0.18° — ตัดทิ้งแล้วเศษตามแนวโค้งไม่ถูกแก้ 50 ก้อน)
            ลอง = กันแย่ง({k: ('ย้าย' if (k in ย้ายได้ and _ห่างเสีย(k) <= 1.0) else a) for k, a in งาน.items()})
            if ลอง != งาน:
                งบ -= 1
                ผล2 = ลงมือ(ลอง)
                นับ2, ที่2 = ตรวจ(ผล2)
                if นับ2 < นับ:
                    งาน, ผล, นับ, ที่ = ลอง, ผล2, นับ2, ที่2
            # ⑤ข สลับทีละดวง — ลองทุกดวงที่อยู่ใกล้จุดเสียในรอบเดียวกัน แล้วเลือกตัวที่ดีสุด (ไม่ใช่ตัวแรกที่ดีขึ้น)
            รอบ = 0
            while นับ and รอบ < 4 and งบ > 0 and _time.monotonic() - t0 < 3.0:
                รอบ += 1

                def ห่างจุดเสีย(k):
                    x = ข้อมูล[k]
                    try:
                        return min((q.distance(QgsGeometry.fromPointXY(p)) for q in ที่ for p in (x['f'], x['vp'])),
                                   default=float("inf"))
                    except Exception:
                        return float("inf")
                ผู้สมัคร = sorted(((round(ห่างจุดเสีย(k), 6),) + คีย์หมุด(k), k) for k in ย้ายได้)
                ใกล้ = [k for key, k in ผู้สมัคร if key[0] <= 1.0]
                คิว = ใกล้ or [k for _key, k in ผู้สมัคร]
                ดีสุด = None
                for k in คิว:
                    if งบ <= 0 or _time.monotonic() - t0 >= 3.0:
                        break
                    ลอง = พลิก(งาน, k)
                    if ลอง == งาน:
                        continue
                    งบ -= 1
                    ผล2 = ลงมือ(ลอง)
                    นับ2, ที่2 = ตรวจ(ผล2)
                    key = คะแนน(ผล2, นับ2) + คีย์หมุด(k)
                    if ดีสุด is None or key < ดีสุด[0]:
                        ดีสุด = (key, ลอง, ผล2, นับ2, ที่2)
                if ดีสุด is None or ดีสุด[3] >= นับ:
                    break
                _k, งาน, ผล, นับ, ที่ = ดีสุด
            # ⑤ค ★ รอบ 5 — ถอยการย้ายมุมที่ ⑤ เพิ่มเข้ามาแต่ไม่จำเป็น (ถอยแล้วของเสียไม่เพิ่ม ⇒ ถอย)
            #   กติกา ②: มุมที่ไม่ใช่มุมจริง (จุดบนเส้นตรง/เส้นโค้งถี่) ต้องอยู่ต่อพร้อมหมุดของมัน ถ้าไม่จำเป็นต้องย้าย
            # ★ รอบ 6 (ผู้ตรวจ A B2 · B7 · S1)
            #   · ถอยแล้วมี "มุมใหม่ที่ไม่มีหมุดให้ยืม" เพิ่ม ⇒ ไม่ถอย (เดิมนับแค่หนาม/เศษ ⇒ มุมเปลือยโผล่ 3-4% ของหน้าโค้ง
            #     ที่หมุดเยื้อง 7-9 ซม. ทั้งที่รุ่นก่อนสะอาด)
            #   · ลองถอยทีละกลุ่ม: ทั้งหมดก่อน ไม่ผ่านค่อยแบ่งครึ่ง (ส่วนใหญ่จบในครั้งเดียว · เดิมทีละดวง 12 ครั้ง ~3.6 วิ)
            #   · งบเป็นจำนวนครั้งล้วน ⇒ ผลไม่ขึ้นกับความเร็วเครื่อง (เดิมเพดาน 4 วิ นับรวมกับ ⑤: เครื่องเร็วถอย 7 เครื่องช้าถอย 3)
            คิวถอย = sorted((k for k in ย้ายได้ if งาน.get(k) == 'ย้าย' and งานตั้งต้น.get(k) != 'ย้าย'), key=คีย์หมุด)
            if คิวถอย:
                เปลือย = นับเปลือย(ผล)
                งบถอย = 12
                กองถอย = [คิวถอย]
                while กองถอย and งบถอย > 0:
                    กลุ่ม = กองถอย.pop(0)
                    ลอง = dict(งาน)
                    for k in กลุ่ม:
                        ลอง[k] = 'แทรก'
                    งบถอย -= 1
                    ผล2 = ลงมือ(ลอง)
                    นับ2, ที่2 = ตรวจ(ผล2)
                    if นับ2 <= นับ:
                        เปลือย2 = นับเปลือย(ผล2)
                        if เปลือย2 <= เปลือย:
                            งาน, ผล, นับ, ที่, เปลือย = ลอง, ผล2, นับ2, ที่2, เปลือย2
                            continue
                    if len(กลุ่ม) > 1:
                        กองถอย[0:0] = [กลุ่ม[:len(กลุ่ม) // 2], กลุ่ม[len(กลุ่ม) // 2:]]
        # ⑤ง ★ รอบ 6 (ผู้ตรวจ A B2) — หมุด "รอยต่อ" (แนวกรอบแยกออกจากขอบแปลงที่หมุดนี้ · หมุดข้างหนึ่งไม่ติดขอบ)
        #   ที่ถูก "แทรก" ทั้งที่มุมใกล้ ๆ (≤ 10 ซม.) อยู่ในกรอบ (ถูกหักทิ้งอยู่แล้ว) ⇒ ขอบแปลงจากมุมนั้นไปมุมถัดไปตัดแนวกรอบ
        #   = มุมใหม่ที่ไม่มีหมุดให้ยืม (Monte Carlo หน้าโค้งหมุดเยื้อง 7-9 ซม.: รุ่นก่อนสะอาด รุ่นนี้เปลือย 3-4%)
        #   ⇒ ลองย้ายมุมนั้นไปที่หมุด เก็บเมื่อมุมเปลือยลดลงและของเสียไม่เพิ่ม — มุมนี้หายไปกับส่วนที่หักอยู่แล้ว ไม่ขัดกติกา ②
        #   ทำแม้ ⑤ ไม่ได้ทำงาน (④ ดึงเลนส์จนของเสียเป็น 0 แต่มุมเปลือยยังอยู่)
        รอยต่อ = []
        for k in ย้ายได้:
            if งาน.get(k) != 'แทรก' or (ติดขอบ(ข้อมูล[k - 1]) and ติดขอบ(ข้อมูล[(k + 1) % n])):
                continue
            try:
                if _ในกรอบ0(ข้อมูล[k]['vp']):
                    รอยต่อ.append(k)
            except Exception:
                continue
        # ★ รอบ 7 (ผู้ตรวจ A N2) — ย้ายมุมรอยต่อแล้ว "ขอบจากมุมข้างเคียงนอกกรอบ" หมุนตามไปหาหมุด
        #   (มุมรอยต่อหายไปกับส่วนที่หักก็จริง แต่ขอบที่ต่อจากมันไม่หาย) ⇒ ด้านยาว 60-120 ม. ยื่นทับข้างเคียง 2-5 ตร.ม.
        #   ⇒ รับเฉพาะเมื่อแปลงคงเหลือเบี่ยงจาก "กรอบที่วาด" เพิ่มไม่เกิน 0.25 ตร.ม. (หน้าโค้งมุมถี่: ≤ 0.17 ตร.ม. ·
        #     เจ้าของงานรับ +0.25 ตร.ม. แลกกับมุมตรงหมุดพอดี 25 ก.ย.) · เกินนั้นคงมุมเปลือยไว้ (กล่องเตือนให้เติมหมุดเอง)
        if รอยต่อ:
            _d0 = _ผลหัก(ผล)
            เปลือย = นับเปลือย(ผล, _d0)
            _อุดม, เบี่ยง = None, 0.0
            if เปลือย:
                try:
                    _อุดม = og0.difference(frame)
                    เบี่ยง = _d0.symDifference(_อุดม).area()
                except Exception:
                    _อุดม = None
            for k in sorted(รอยต่อ, key=คีย์หมุด):
                if not เปลือย or _อุดม is None:
                    break
                ลอง = dict(งาน)
                ลอง[k] = 'ย้าย'
                ลอง = กันแย่ง(ลอง)
                if ลอง == งาน:
                    continue
                ผล2 = ลงมือ(ลอง)
                นับ2, ที่2 = ตรวจ(ผล2)
                if นับ2 > นับ:
                    continue
                _d2 = _ผลหัก(ผล2)
                เปลือย2 = นับเปลือย(ผล2, _d2)
                if เปลือย2 >= เปลือย:
                    continue
                try:
                    เบี่ยง2 = _d2.symDifference(_อุดม).area()
                except Exception:
                    continue
                if เบี่ยง2 - เบี่ยง > 0.25:
                    continue
                งาน, ผล, นับ, ที่, เปลือย, เบี่ยง = ลอง, ผล2, นับ2, ที่2, เปลือย2, เบี่ยง2
        return ผล

    def _donut_execute_inner(self, poly_lyr, outer, inner, title, ต่อได้):
        """หักรูปออกจากแปลง แล้วเขียนรูปใหม่ + หมุดลงบัฟเฟอร์ (Undo ทีเดียวได้ทั้งหมด) · คืน True = ทำแล้ว
        inner = [(fid, geom)] · ★ 2.3.6 โหมดกรอบ = fid เป็น None ทุกตัว (กรอบจากหมุดที่คลิก)

        ด่านที่ใส่ไว้ (ทุกข้อคือเคสที่ทำพังได้จริง)
          ① แปลงรวมต้องไม่อยู่ในรายการที่จะหักออก (ไม่งั้นเหลือรูปว่าง)
          ② ต้องมีส่วนทับกันจริง — ไม่ทับเลย = คลิกผิด / กรอบอยู่นอกแปลง
          ③ 🔴 **ห้ามเหลือรูปว่าง หรือเศษรูป < 0.01 ตร.ม.** — ของแบบนี้เคยทำให้เกิดแปลง geom=NULL
          ④ ผลลัพธ์ต้องเป็น "รูปแปลง" (Polygon) และถูกต้อง (`isGeosValid`) ไม่งั้นไม่เขียน
          ⑤ ถ้าผลลัพธ์แตกเป็นหลายก้อน **มากกว่าก่อนหัก** ต้องบอกในกล่องยืนยัน
          ⑥ L1 ต้องปลดล็อกก่อนถึงจะแตะได้
          ⑦ ★ 2.3.6 รูป + หมุดใหม่ + หมุดค้างที่ลบ **ครบทุกอย่างหรือไม่ทำเลย**
        🔑 หมุดที่ใช้ทำกรอบไม่ถูกแตะ · มุมใหม่ได้หมุดของตัวเอง · หมุดเดิมตรงมุมที่หักทิ้งถูกลบ (2.3.6)
        """
        ofid = outer.id()
        # ① แปลงรวมต้องไม่อยู่ในกองที่จะหักออก
        if any(f == ofid for f, _g in inner):
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "แปลงรวมที่คลิก เป็นใบเดียวกับแปลงที่เลือกจะหักออก — ยกเลิก")
            return False
        og0 = QgsGeometry(outer.geometry())          # รูปก่อนหัก — ใช้หา "มุมใหม่" และ "หมุดค้าง"
        if og0 is None or og0.isEmpty():
            self._ask(QtWidgets.QMessageBox.Warning, title, "แปลงรวมไม่มีรูป — ทำไม่ได้")
            return False
        ti = self._field_index(poly_lyr.fields(), 'type')
        if ti != -1 and not self._l1_unlocked():
            tv = outer.attribute(ti)
            if _is_l1(tv):                               # ★ 2.4.0 (DU-01) lock_rules · NULL-safe
                self._ask(QtWidgets.QMessageBox.Warning, title,
                          f"แปลงรวมเป็น {str(tv).strip()} — ถ้าต้องแก้จริงให้กด 🔓 ปลดล็อก L1 ก่อน")
                return False
        if not og0.isGeosValid():
            # ★ 2.3.7 (b12 · เจ้าของงานขอ 3 ต.ค.) — เดิมปฏิเสธ ⇒ เสนอซ่อมแบบเดียวกับตอนเลือกแปลง (รูปเสียหลังเลือกแปลงแล้ว)
            #   ซ่อม = ขั้น ↺ ของตัวเอง แล้วหักต่อด้วยรูปที่ซ่อม · ไม่ซ่อม/ซ่อมไม่ได้ ⇒ ไม่หัก (กรอบที่คลิกไว้ยังอยู่)
            _ชั้น = self._tool_layers_ok(poly_lyr, title)
            _ซ่อมได้ = self._donut_repair_offer(poly_lyr, _ชั้น[1] if _ชั้น else None, outer, title)
            if _ซ่อมได้ is None:
                return False
            outer, _ผลซ่อม = _ซ่อมได้
            self.iface.messageBar().pushMessage(title, _ผลซ่อม[0], level=_ผลซ่อม[1], duration=15)
            og0 = QgsGeometry(outer.geometry())
        โหมดกรอบ = all(f is None for f, _g in inner)       # ★ 2.3.6 — หักด้วยกรอบจากหมุด
        og = QgsGeometry(og0)
        ขยับ, ย้ายมุม, ดึง = [], [], 0
        กรอบวาด = None                                # ★ audit รอบ 4 — กรอบตามหมุดที่คลิก (ก่อนปรับ) ใช้วัดยื่น/หด
        if โหมดกรอบ and len(inner) == 1 and inner[0][1] is not None:
            กรอบวาด = QgsGeometry(inner[0][1])
            og, กรอบใหม่, ขยับ, ย้ายมุม, ดึง = self._donut_fit_frame(
                og0, inner[0][1], other_markers=self._donut_markers_near(poly_lyr, inner[0][1], pad=0.10))
            inner = [(None, กรอบใหม่)]

        # รวมแปลงย่อยเป็นก้อนเดียวก่อน แล้วค่อยหักครั้งเดียว (ลดโอกาสเศษรูปจากการหักทีละใบ)
        รวมใน = None
        for _fid, g in inner:
            รวมใน = QgsGeometry(g) if รวมใน is None else รวมใน.combine(g)
        if รวมใน is None or รวมใน.isEmpty():
            self._ask(QtWidgets.QMessageBox.Warning, title, "แปลงที่เลือกจะหักออกไม่มีรูป — ยกเลิก")
            return False
        # ② ต้องทับ **รูปเดิม** จริง (★ audit รอบ 2 — เดิมตรวจกับรูปที่ดันขอบแล้ว ⇒ กรอบที่อยู่นอกแปลง
        #    ทั้งกรอบ (หมุดนอกขอบ 0.3 ม.) ผ่านด่านได้ แล้วแปลงกลับ "โต" ไปทับแปลงข้างเคียง)
        if not og0.intersects(รวมใน) or og0.intersection(รวมใน).area() <= 0:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "กรอบไม่ได้ทับแปลงนี้เลย — ไม่มีอะไรให้หัก" if โหมดกรอบ else
                      "แปลงที่เลือกจะหักออก ไม่ได้อยู่ในแปลงรวมเลย — คลิกผิดใบหรือเปล่า?")
            return False

        ใหม่ = self._donut_difference(og, รวมใน, (og0,))
        # ③ ห้ามเหลือรูปว่าง — หรือเศษรูปจากทศนิยม (audit: กรอบเท่าขอบแปลง + หมุด 1 ดวงบนขอบ
        #    เหลือสามเหลี่ยม 1.9e-9 ตร.ม. แล้วผ่านด่าน "ว่าง" ไปได้ 59 ใน 200 ตำแหน่ง)
        if ใหม่ is None or ใหม่.isEmpty() or ใหม่.area() < 0.01:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "หักแล้วแปลงรวมจะไม่เหลือรูปเลย (หรือเหลือแค่เศษไม่ถึง 0.01 ตร.ม.) — ไม่ทำให้\n"
                      "ถ้าตั้งใจจะลบทั้งแปลง ให้ใช้ปุ่ม 🗑 ลบแปลง แทน")
            return False
        # ④ ต้องเป็นรูปแปลง และถูกต้อง
        #    audit 25 ก.ย.: ผลลัพธ์เป็น GeometryCollection (รูป + เส้น) ได้ และ isGeosValid ผ่าน
        #    ⇒ เข้าบัฟเฟอร์ของชั้น MULTIPOLYGON แล้วบันทึกไม่ได้ทั้งบัฟเฟอร์
        if not ใหม่.isGeosValid():
            ซ่อม = ใหม่.makeValid()
            if ซ่อม is None or ซ่อม.isEmpty() or not ซ่อม.isGeosValid():
                self._ask(QtWidgets.QMessageBox.Warning, title,
                          "รูปที่ได้หลังหักไม่ถูกต้องทางเรขาคณิต — ไม่เขียนให้ (กันข้อมูลเสีย)")
                return False
            ใหม่ = ซ่อม
        if ใหม่.type() != QgsWkbTypes.PolygonGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "ผลที่ได้หลังหักไม่ใช่รูปแปลงล้วน (มีเส้น/จุดปน) — ไม่เขียนให้ (กันบันทึกไม่ผ่านทั้งบัฟเฟอร์)")
            return False
        # ★ audit รอบ 2 — ด่าน ③ ตรวจแค่ "ทั้งรูป" ⇒ เศษก้อนเล็กแนบมากับผลลัพธ์ได้ (0.0012-0.2 ตร.ม.)
        #   เศษแบบนี้ไม่มีใครตั้งใจสร้าง = หมุดเยื้องมุม/ขอบ ⇒ ไม่เขียน บอกให้ตรวจหมุด
        _เล็ก = [q.area() for q in (ใหม่.asGeometryCollection() if ใหม่.isMultipart() else [ใหม่])
                 if q.area() < 0.01]
        if _เล็ก:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "หักแล้วมีเศษก้อนเล็ก %d ก้อน (เล็กสุด %.4f ตร.ม.) — ไม่เขียนให้\n"
                      "มักเกิดจากหมุดที่คลิกเยื้องมุม/ขอบแปลง · ตรวจหมุดแล้ววาดกรอบใหม่" % (len(_เล็ก), min(_เล็ก)))
            return False
        # ★ audit รอบ 3 — ด่านข้างบนดูแค่ "ก้อน < 0.01 ตร.ม." ⇒ เข็ม 0.01-0.3 ตร.ม. (มุม 0.03-0.2°) และลิ่มแหลม
        #   ที่ติดกับแปลงคงเหลือ หลุดลงฐาน (สุ่ม ~2,000 ครั้ง + คู่แปลงจริง) ⇒ หนาม/เศษบางที่ "เกิดใหม่" ไม่เขียน
        _หนาม = self._donut_needles(ใหม่, og0)
        if _หนาม:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "หักแล้วจะเกิดหนามแหลม/เศษบาง %d จุด — ไม่เขียนให้\n%s\n\n"
                      "มักเกิดจากหมุดที่คลิกเยื้องมุม/ขอบแปลงเกินระยะที่ปรับให้ (มุม 10 ซม. · ขอบ: นอก 50 ซม. / ใน 10 ซม.)\n"
                      "หรือแนวกรอบวิ่งเกือบขนานกับขอบแปลง — ตรวจหมุด/ขอบแปลงตรงจุดนั้น แล้ววาดกรอบใหม่"
                      % (len(_หนาม), "\n".join("· " + _t for _p, _t in _หนาม[:4]) + (" …" if len(_หนาม) > 4 else "")))
            return False
        # ★ 2.3.6 (เจ้าของงานสั่ง 25 ก.ย. 69) — "ถ้าตีกรอบผ่ากลางแปลง ให้ทำเป็น multi polygon"
        #   แปลงคงเหลือขาดเป็นหลายก้อน = เก็บเป็นแปลงเดียวแบบหลายส่วน (ไม่แยกแปลง · ไม่ทิ้งก้อนไหน)
        #   ชั้นแปลงในฐานเป็น MULTIPOLYGON ⇒ แปลงเป็นชนิด multi ให้ชัดตั้งแต่ในบัฟเฟอร์
        #   ชั้นที่เก็บได้ก้อนเดียว (Polygon) ⇒ ไม่เขียน (ฐานจะปฏิเสธตอนบันทึก แล้วบันทึกไม่ผ่านทั้งบัฟเฟอร์)
        if QgsWkbTypes.isMultiType(poly_lyr.wkbType()):
            ใหม่.convertToMultiType()
        elif ใหม่.isMultipart() and self._donut_parts(ใหม่) > 1:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "หักแล้วแปลงคงเหลือแยกเป็นหลายก้อน แต่ชั้นนี้เก็บรูปได้ก้อนเดียว (Polygon) — ไม่เขียนให้")
            return False

        a0, a1 = og0.area(), ใหม่.area()
        # ★ audit รอบ 2 — การดันขอบไปถึงหมุดทำให้ "ด้านทั้งด้าน" เอียงไปหามุมถัดไป ⇒ พื้นที่ ≈ ½·ระยะ·ความยาวด้าน
        #   (หมุดนอกขอบ 0.45 ม. บนด้านยาว 100 ม. = ยื่นทับแปลงข้างเคียง 20.25 ตร.ม.) ⇒ ต้องบอกให้เห็นก่อนยืนยัน
        # ★ audit รอบ 4 — หด วัดเทียบ **กรอบตามที่วาด** (เดิมเทียบกรอบที่ ④ ขยายแล้ว ⇒ เนื้อที่ที่ตัดเพิ่มนอกกรอบที่วาด
        #   ไม่ถูกนับเลย: ผู้ตรวจรอบ 4 วัดได้ 0.60-2.45 ตร.ม. + รูถูกรวม + แปลงแยกก้อน โดยกล่องไม่บอก)
        try:
            ยื่น = ใหม่.difference(og0).area()
            หด = og0.difference(QgsGeometry.unaryUnion([ใหม่, กรอบวาด if กรอบวาด is not None else รวมใน])).area()
        except Exception:
            ยื่น = หด = 0.0
        ดึง_ตรม, รูรวม = 0.0, 0
        if กรอบวาด is not None:
            try:
                if ดึง:
                    ดึง_ตรม = og0.intersection(รวมใน.difference(กรอบวาด)).area()
                รูรวม = self._donut_merged_holes(og0, ใหม่, กรอบวาด)
            except Exception:
                pass
        ก้อน0 = self._donut_parts(og0)
        ก้อน = self._donut_parts(ใหม่)
        # นับรูภายใน เพื่อบอกผู้ใช้ว่าผลออกมาเป็น "โดนัท" หรือ "แปลงคงเหลือ"
        # ★ รอบ 5 — นับเฉพาะรูที่เกิดใหม่ (เดิมนับรูเดิมของแปลงด้วย ⇒ กล่องบอก "ส่วนที่ทับกลายเป็นรู" ทั้งที่ไม่ใช่)
        # ★ รอบ 6 (ผู้ตรวจ A B4) — เทียบ "รูปของรู" ไม่ใช่ลบจำนวน: กรอบกลางใบครอบรูเดิมทั้งรู (รูโต 16 → 100 ตร.ม.)
        #   รอบ 5 ได้ 1 − 1 = 0 แล้วกล่อง/แถบไม่บอกเรื่องรูเลย ⇒ รูที่ไม่ตรงรูเดิมเป๊ะ = รูที่เกิดจากการหัก
        try:
            รู = self._donut_new_holes(og0, ใหม่, กรอบวาด if กรอบวาด is not None else รวมใน)
        except Exception:
            รู = 0
        # ★ รอบ 5 — คอคอดแคบที่เกิดใหม่ (< 5 ซม.) ⇒ เตือนในกล่อง (ไม่ปฏิเสธ — กรอบที่วาดผ่านใกล้ปลายรอยบาก/ขอบรูเอง)
        # ★ รอบ 6 (ผู้ตรวจ A B3) — เทียบ "ตำแหน่ง" ไม่ใช่จำนวนรวม: คอคอดเดิมถูกหักทิ้งไปพร้อมกับที่คอคอดใหม่เกิด
        #   ⇒ 1 − 1 = 0 แล้วไม่เตือน (สุ่มรูสองรู: ไม่ถูกเตือน 152/300) ⇒ คอคอดใหม่ = ห่างคอคอดเดิมทุกจุด > 10 ซม.
        # ★ รอบ 7 (ผู้ตรวจ A N5) — ผนังบาง (ระหว่างวง) เป็น "ช่วง" ⇒ ของเดิมเฉพาะเมื่อเป็นผนังเดิมจริง (Hausdorff ≤ 10 ซม.)
        #   ไม่ใช่แค่ "อยู่ใกล้ช่วงเดิม" (ผนังใหม่บนวงรูเดียวกันข้าง ๆ ผนังเดิมถูกกลืน — Monte Carlo รูสองรู ไม่เตือน 146 ครั้ง)
        #   คอคอดแบบก้อนแตก (จุด) ⇒ ห่างคอคอดเดิมไม่เกิน 10 ซม. = ของเดิม (แบบรอบ 6)
        try:
            _คอ0 = self._donut_neck_points(og0)

            def _คอเดิม(q):
                for o in _คอ0:
                    try:
                        if q.type() == QgsWkbTypes.LineGeometry:
                            if o.type() == QgsWkbTypes.LineGeometry and q.hausdorffDistance(o) <= 0.10:
                                return True
                        elif q.distance(o) <= 0.10:
                            return True
                    except Exception:
                        continue
                return False
            คอคอด = sum(1 for q in self._donut_neck_points(ใหม่) if not _คอเดิม(q))
        except Exception:
            คอคอด = max(0, self._donut_necks(ใหม่) - self._donut_necks(og0))
        # 🔑 21 ก.ย. เจ้าของงานยืนยัน: ทั้งสองเคสเป็น **งานเดียวกัน** คือ "ลบส่วนที่ทับออก"
        #    ส่วนที่ทับอยู่กลางใบก็กลายเป็นรูไปเอง — ไม่ต้องแยกเป็นสองโหมด
        ชนิด = "แปลงคงเหลือ"
        # ★ 2.3.6 (25 ก.ย. 69 เจ้าของงานสั่ง) — **ทุกมุมใหม่ของแปลงคงเหลือ สร้างหมุดของแปลงคงเหลือให้**
        #   โดยยืมชื่อจากหมุดที่อยู่ตำแหน่งเดียวกัน (โหมดกรอบ = หมุดที่คลิก)
        #   🔑 มุมใหม่ที่ไม่มีหมุดให้ยืม (จุดที่แนวกรอบตัดขอบตรงที่ไม่มีหมุด)
        #      **ไม่สร้างเอง** — บอกจำนวน (กติกา 7 ก.ย.: ไม่มีแหล่งชื่อ = ห้ามเดา)
        _เปลือยแผน = []                      # ★ 2.3.7 (DI-35) มุมใหม่ที่ไม่มีหมุดให้ยืม (กล่องนับแล้ว)
        แผนหมุด, ไม่มีให้ยืม, point_lyr, แผนได้ = self._donut_marker_plan(poly_lyr, outer, og0, ใหม่, inner, ย้ายมุม,
                                                                     เปลือย_out=_เปลือยแผน)
        if not แผนได้:
            # audit 25 ก.ย. (F11) — เดิมตรวจชั้นหมุดไม่ได้แล้วคืนแผนว่าง = หักต่อทั้งที่มุมเปลือย (fail-open)
            self._ask(QtWidgets.QMessageBox.Warning, title, "ตรวจชั้นหมุดไม่ได้ — ยกเลิก (ไม่แตะรูปแปลง)")
            return False
        # ★ 2.3.6 (เจ้าของงานสั่ง 25 ก.ย. "ลบออก") — หมุดเดิมของแปลงนี้ตรงมุมที่ถูกหักทิ้ง
        _ค้างล็อก = []                       # ★ 2.4.0 (review DU-01) หมุดค้างที่ล็อก (Type L1)
        ค้าง, ค้าง_ชร, ค้าง_ตรวจได้, ค้าง_ย้าย = (self._donut_orphans(poly_lyr, point_lyr, outer, og0, ใหม่, ย้ายมุม,
                                                                     ล็อก_out=_ค้างล็อก)
                                                   if โหมดกรอบ else ([], 0, True, 0))
        # ★ 2.4.0 (review DU-01) — มุมที่หักทิ้งมีหมุดล็อกของแปลงนี้ (Type L1 บนแปลงที่ไม่ใช่ L1): ลบไม่ได้ และเก็บไว้ก็หลุดมุม
        #   ⇒ ไม่หัก (ยังไม่ได้แตะอะไร) · เดิมด่านดูแค่ Type ของแปลงรวม ⇒ ผู้ช่วยผู้ดูแลลบหมุด L1 ได้ทั้งที่ปลดล็อก L1 ไม่ได้
        if _ค้างล็อก and not self._l1_unlocked():
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      f"มุมที่จะถูกหักทิ้งมีหมุด L1 ของแปลงนี้ {len(_ค้างล็อก):,} ดวง (ชั้นอ้างอิงพิกัดหลัก) ซึ่งถูกล็อก "
                      "— ลบไม่ได้\n" + self._l1_hint("หักตรงนี้ไม่ได้"))
            return False
        # ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค. 69) — ปลั๊กอินเลิกเขียน ALT_NAME ⇒ หมุดใหม่ของมุมใหม่เก็บได้ "ชื่อเดียว"
        #   มุมที่ยืมได้หลายชื่อ: วันที่ใหม่สุด (SURV_DATE/ISSUE_DATE) ตัดสินในแผนแล้ว · ตัดสินไม่ได้ ⇒ popup ให้เลือกตรงนี้
        #   กด Cancel = ไม่หัก (ยังไม่ได้แตะอะไร)
        แผนหมุด = self._donut_plan_names(แผนหมุด, title, ค้าง)
        if แผนหมุด is None:
            return False
        # ★ รอบ 9 — หมุดค้างที่มุมของมันมีหมุดของแปลงนี้อยู่แล้ว ⇒ ชื่อไปที่ดวงนั้น (เดิมหายเงียบ ๆ)
        # ★ 2.3.7 (b12) — ผู้รับกับหมุดค้างชื่อต่างกัน ⇒ วันที่ใหม่สุด · ตัดสินไม่ได้ ⇒ popup (เดิมต่อ ALT_NAME ของผู้รับ)
        #   ชื่อของหมุดค้างที่แผนหมุดยืมแต่ไม่ได้เลือก และไม่มีผู้รับ ⇒ เข้ากอง "จะหาย" (★ รอบ 9d ข — ตอนนี้ใช้กับทุกชั้น)
        _หายแผน = []
        _หายล็อก = []                         # ★ 2.4.0 (review DU-01-followup) ชื่อที่ยกให้หมุดล็อกไม่ได้
        _ผู้รับ = (self._donut_heirs(poly_lyr, point_lyr, outer, og0, ใหม่, ค้าง, ย้ายมุม, แผนหมุด, หาย_out=_หายแผน,
                                     ล็อก_out=_หายล็อก)
                   if ค้าง else {})
        _ยก = (self._donut_heir_plan(point_lyr, _ผู้รับ, _หายแผน, title, หายล็อก=_หายล็อก)
               if _ผู้รับ is not None else None)
        if _ยก is False:
            return False                      # กด Cancel ใน popup เลือกชื่อ = ยกเลิกทั้งงาน (ยังไม่ได้แตะอะไร)
        if _ยก is None:
            self._ask(QtWidgets.QMessageBox.Warning, title, "ตรวจชั้นหมุดไม่ได้ — ยกเลิก (ไม่แตะรูปแปลง)")
            return False
        ยกชื่อ, ชื่อหาย, เหตุหาย = _ยก          # ★ รอบ 9b — เหตุผลเดียวกันทั้งกล่องและแถบผลลัพธ์ (ผู้ตรวจ C4)
        _n_หาย = len(ชื่อหาย) + sum(1 for _f, _o, _n in ยกชื่อ if _o)     # ★ 2.3.7 (b12) + ชื่อเดิมของผู้รับที่ถูกตั้งชื่อใหม่
        # ★ 2.3.7 (b12) — ประวัติ ALT_NAME ของหมุดค้างที่จะลบ (อ่านอย่างเดียว) หายไปพร้อมหมุด ⇒ บอกในกล่องยืนยัน
        _ประวัติค้าง = self._alt_names(point_lyr, ค้าง)

        # ★ 2.3.7 (review DI-35) — จำลองสภาพหลังหัก (อ่านอย่างเดียว · ไม่แตะการหัก) ⇒ บรรทัด "⚠️ หลังหัก" ถ้ากติกา 1 มุม : 1 หมุดแย่ลง
        #   ในส่วนที่กล่องยังไม่ได้บอก (มุมเปลือยที่ไม่ได้นับ · หมุดหลุดมุม · หมุดของแปลงนี้ค้างนอกแปลงคงเหลือ)
        _เหล็ก = self._donut_iron_after(poly_lyr, point_lyr, outer, og0, ใหม่,
                                       กรอบวาด if กรอบวาด is not None else รวมใน, ค้าง, แผนหมุด, _เปลือยแผน)
        _หัว = (f"หักกรอบจากหมุด {getattr(self, '_donut_frame_n', 0) or '?'} ดวง ออกจากแปลง fid {ofid}\n\n"
                if โหมดกรอบ else f"หัก {len(inner):,} แปลงออกจากแปลง fid {ofid}\n\n")
        ข้อความ = (_หัว +
                   f"แปลงนี้จะเหลือเฉพาะส่วนที่ไม่ทับ\n"                  # ★ 2.3.7 (review UX-29)
                   f"เนื้อที่รูป: {a0:,.1f} → {a1:,.1f} ตร.ม. ("
                   + (f"ลดลง {a0 - a1:,.1f}" if a1 <= a0 else f"เพิ่มขึ้น {a1 - a0:,.1f}") + ")\n"
                   + (f"ดันขอบแปลงให้ผ่านหมุดที่คลิก {len(ขยับ):,} ดวง (ห่างขอบเดิมสูงสุด "
                      f"{max(d for d, _i in ขยับ) * 100:,.1f} ซม.) — มุมใหม่อยู่ตรงหมุดพอดี\n" if ขยับ else "")
                   # ★ audit รอบ 3 — มุมที่ถูกย้ายต้องเห็นแยก (เดิมรวมอยู่ใน "ดันขอบ" แล้วหมุดของมุมนั้นหายไปเงียบ ๆ)
                   + (f"ย้ายมุมเดิมของแปลงไปที่หมุดที่คลิก {len(ย้ายมุม):,} มุม (ห่างมุมเดิมสูงสุด "
                      f"{max(a.distance(b) for a, b in ย้ายมุม) * 100:,.1f} ซม.)\n" if ย้ายมุม else "")
                   + (f"ขยายกรอบให้ผ่านมุมแปลงที่ห่างแนวกรอบไม่เกิน 5 ซม. {ดึง:,} มุม (กันเศษบางระหว่างกรอบกับขอบแปลง)"
                      f" — ตัดส่วนนอกกรอบที่วาดเพิ่ม {ดึง_ตรม:,.2f} ตร.ม.\n" if ดึง else "")
                   + (f"⚠️ รูเดิมของแปลง {รูรวม:,} รูถูกรวมเข้ากับส่วนที่หัก (ขอบรูอยู่ใกล้แนวกรอบ) — "
                      "รูปแปลงนอกกรอบที่วาดเปลี่ยน ตรวจก่อน\n" if รูรวม else "")
                   + (f"{'⚠️ ' if ยื่น > 1 else ''}แปลงยื่นออกนอกขอบเดิม {ยื่น:,.2f} ตร.ม."
                      + (" — อาจทับแปลงข้างเคียง ตรวจก่อน" if ยื่น > 1 else "") + "\n" if ยื่น >= 0.01 else "")
                   + (f"{'⚠️ ' if หด > 1 else ''}ขอบแปลงถูกดันเข้า/ตัดเกินกรอบที่วาด {หด:,.2f} ตร.ม."
                      + (" — จะเกิดช่องว่างกับแปลงข้างเคียง ตรวจก่อน" if หด > 1 else "") + "\n" if หด >= 0.01 else "")
                   + (f"ส่วนที่ทับอยู่กลางใบกลายเป็นรู {รู} รู\n" if รู else "")
                   + (f"⚠️ แปลงคงเหลือมีคอคอดแคบกว่า 5 ซม. เกิดใหม่ {คอคอด:,} จุด (แนวกรอบผ่านใกล้ปลายรอยบาก/ขอบรู) — ตรวจก่อน\n"
                      if คอคอด else "")
                   + (f"\nกรอบผ่ากลางแปลง ⇒ แปลงคงเหลือแยกเป็น {ก้อน} ก้อน (ก่อนหัก {ก้อน0}) · "
                      "เก็บเป็นแปลงเดียวแบบหลายส่วน (multipolygon)\n" if ก้อน > ก้อน0 else "")
                   + (f"\nหมุดของแปลงคงเหลือ: สร้างให้ {len(แผนหมุด):,} มุม (ยืมชื่อจากหมุดที่คลิก)\n"
                      if แผนหมุด else "")
                   + (f"⚠️ มุมใหม่อีก {ไม่มีให้ยืม:,} มุมไม่มีหมุดให้ยืมชื่อ (แนวกรอบตัดขอบตรงที่ไม่มีหมุด) — ตรวจแล้วเติมเอง\n"
                      if ไม่มีให้ยืม else "")
                   + (f"หมุดเดิมของแปลงนี้ที่ไม่มีมุมให้เกาะแล้ว จะถูกลบ {len(ค้าง):,} ดวง ("
                      + ", ".join(x for x in (
                          f"ตรงมุมที่ถูกหักทิ้ง {len(ค้าง) - ค้าง_ย้าย:,} ดวง" if len(ค้าง) > ค้าง_ย้าย else "",
                          f"ตรงมุมที่ถูกย้ายไปที่หมุด {ค้าง_ย้าย:,} ดวง" if ค้าง_ย้าย else "",
                          f"เป็น ชร {ค้าง_ชร:,} ดวง" if ค้าง_ชร else "") if x) + ")\n" if ค้าง else "")
                   + self._donut_heir_text(ยกชื่อ)
                   + (f"⚠️ ชื่อ {' | '.join(ชื่อหาย)} จะหายไปกับหมุดค้างที่ลบ — {เหตุหาย[0]}\n" if ชื่อหาย else "")
                   + (f"ประวัติชื่อ (ALT_NAME) ของหมุดค้างที่ลบ — หายไปพร้อมหมุด: {' | '.join(_ประวัติค้าง[:10])}"
                      + (f" … (+{len(_ประวัติค้าง) - 10:,} ชื่อ)" if len(_ประวัติค้าง) > 10 else "") + "\n"
                      if _ประวัติค้าง else "")
                   + _เหล็ก                                    # ★ 2.3.7 (DI-35)
                   + ("⚠️ ตรวจหมุดเดิมของแปลงนี้ไม่ได้ (คีย์ UTM ว่าง/มีแปลงคีย์ซ้ำ) — ไม่ลบหมุดค้าง ต้องตรวจเอง\n"
                      if not ค้าง_ตรวจได้ else "")
                   + ("\nส่วนในกรอบจะว่างไว้ (ไม่สร้างแปลงใหม่)\nยืนยันไหม?" if โหมดกรอบ else
                      "\nแปลงที่หักออกยังอยู่เหมือนเดิม ไม่ถูกแตะ\nยืนยันไหม?"))
        # ★ audit รอบ 2 — ปุ่มตั้งต้น "ไม่": Enter ปิดกรอบแล้ว ถ้ากด Enter ซ้ำ (เผลอ/ปุ่มค้าง)
        #   กล่องนี้เคยยืนยันการหักให้เองทันทีโดยไม่ได้อ่านคำเตือน
        if self._ask(QtWidgets.QMessageBox.Question, title, ข้อความ,
                     QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                     QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return False

        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(poly_lyr, title=title, what="ยังไม่ได้แบ่งหัก/แยก"):
            return False
        # 🔴 21 ก.ย. เจ้าของงานเจอ: เดิมคืน selection ของแปลงเต็มไว้หลังทำเสร็จ
        #    ⇒ พอไปเลือกแปลงในรอบถัดไป แปลงเต็มของรอบก่อนยังไฮไลต์ค้างอยู่ สับสน
        #    เครื่องมือนี้ทำงานด้วย "การคลิก" ไม่ได้ใช้ selection ⇒ ไม่ต้องคืนอะไรเลย
        # ★ 2.3.6 — มีหมุดต้องสร้าง/ลบ ⇒ ชั้นหมุดต้องเปิดแก้ได้ **ก่อน** แตะรูป (ทั้งหมดหรือไม่ทำเลย)
        #   ไม่งั้นได้รูปใหม่ที่มุมเปลือย = อาการเดิมที่ตั้งใจแก้
        มีหมุด = (bool(แผนหมุด) or bool(ค้าง) or bool(ยกชื่อ)) and point_lyr is not None
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if มีหมุด and not self._ensure_editing(point_lyr, title=title, what="ยกเลิก (ไม่แตะรูปแปลง)"):
            return False
        lyrs = [poly_lyr] + ([point_lyr] if มีหมุด else [])
        self._op_begin(lyrs)
        poly_lyr.beginEditCommand("Donut / split remainder")
        if มีหมุด:
            point_lyr.beginEditCommand("Donut / markers for new corners")
        n_mk = n_del = 0
        try:
            if not poly_lyr.changeGeometry(ofid, ใหม่):
                raise RuntimeError("เขียนรูปใหม่ไม่สำเร็จ (provider ปฏิเสธ)")
            if มีหมุด:
                n_mk, n_mk_fail = self._donut_add_markers(poly_lyr, point_lyr, outer, แผนหมุด)
                # ★ audit 25 ก.ย. (F6) — หมุดเข้าไม่ครบ = ยกเลิกทั้งหมด (เดิมรูปถูกหักไปแล้วแต่มุมเปลือย)
                if n_mk_fail:
                    raise RuntimeError(f"หมุดใหม่เข้าไม่ได้ {n_mk_fail:,} ดวง")
                # ★ รอบ 9 — ตั้งชื่อก่อนลบ ในคำสั่งเดียวกัน (ล้ม = ย้อนทั้งหมด ไม่มีทาง "ลบแล้วแต่ชื่อไม่ถูกยก")
                # ★ 2.3.7 (b12) — BND_NAME เท่านั้น (ปลั๊กอินไม่เขียน ALT_NAME)
                _nfi = _fld_idx(point_lyr.fields(), self._addnode_name_field(point_lyr) or "")
                for _f, _n, _ชื่อใหม่ in ยกชื่อ:
                    if not point_lyr.changeAttributeValue(_f, _nfi, _ชื่อใหม่):
                        raise RuntimeError(f"ตั้งชื่อให้หมุด gid {_f} ไม่ได้")
                for mfid in ค้าง:
                    if not point_lyr.deleteFeature(mfid):
                        raise RuntimeError(f"ลบหมุดค้างไม่ได้ (fid {mfid})")
                    n_del += 1
            poly_lyr.endEditCommand()
            if มีหมุด:
                point_lyr.endEditCommand()
        except Exception as e:
            poly_lyr.destroyEditCommand()
            if มีหมุด:
                point_lyr.destroyEditCommand()
            self._op_commit()
            # ★ 2.3.7 (review ER-06 · b12) — เดิมแปะข้อความ exception ดิบ ("ไม่ได้หัก — {e}") ⇒ เหตุภาษาไทย: ข้อความไทยของเราเอง
            #   ใช้ตามเดิม · ข้อความดิบของ Python/QGIS ⇒ "เกิดข้อผิดพลาดที่ไม่คาดคิด" + traceback ลง Log แท็บ MLEP · ล้มจริง = ระดับ 2
            self._fail(title, f"ไม่ได้หัก — {_reason_text(e)} · รูปแปลงและหมุดคืนสภาพเดิมแล้ว", "ลองใหม่อีกครั้ง",
                       level=2, duration=0)
            return False
        self._op_commit()
        # ★ 2.3.7 (known-2.3.6 ข้อ 10 e) — Move_Log: trigger ของฐานเขียนแถวของงานนี้ (geom แปลง · หมุดที่เพิ่ม/ลบ) โดย op = NULL
        #   ⇒ ย้อนดูแล้วแยกไม่ออกว่าเป็น 🍩 · `SET LOCAL mlep.op` ใช้ไม่ได้ (executeSql เป็นคนละคอนเนกชันกับที่ชั้นข้อมูล commit)
        #   ⇒ เข้าคิวแถวสรุป 1 แถวต่อ 🍩 (action 'donut') เขียนโดย _flush_type_log หลังบันทึกชั้นแปลงสำเร็จจริงเท่านั้น
        #   ↺ Undo / ยกเลิกการแก้ไขของชั้นแปลง ⇒ คิวถูกทิ้งตาม lid (กลไกเดียวกับเปลี่ยน Type / 📝 rekeyed) · ล้มที่นี่ไม่กระทบงานที่ทำแล้ว
        try:
            _pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            _tf = self._resolve_field(poly_lyr, {'type'})
            self._pending_type_log.append({
                'lid': poly_lyr.id(), 'ux': self._ux_mark(poly_lyr),            # ★ 2.3.7 (audit F8) ผูกกับคำสั่งแก้ไข
                # ★ 2.3.7 b17 (audit R2-D2) — รูปก่อน/หลังหัก (ย้อนด้วย Undo ของ QGIS = รูปกลับเป็นรูปก่อนหักทุกไบต์)
                'fx': ('geom', (), self._geom_sig(og0), self._geom_sig(poly_lyr.getFeature(ofid).geometry())),
                'gid': ofid, 'utm': _txt(outer[_pu]) if _pu else "",
                'old': None, 'new': _txt(outer[_tf]) if _tf else "", 'n_mk': n_mk, 'action': 'donut',
                'op': ((f"แบ่งหัก/แยก กรอบจากหมุด {getattr(self, '_donut_frame_n', 0) or '?'} ดวง" if โหมดกรอบ
                        else f"แบ่งหัก/แยก {len(inner):,} แปลง")
                       + f" · เนื้อที่ {a0:.2f} -> {a1:.2f} ตร.ม."
                       + (f" · {ก้อน} ก้อน" if ก้อน > ก้อน0 else "")
                       + f" · หมุดใหม่ {n_mk} · ลบหมุดค้าง {n_del}"
                       + (f" · ยกชื่อ {len(ยกชื่อ)}" if ยกชื่อ else "")
                       + (f" · ชื่อหาย {_n_หาย}" if _n_หาย else "")
                       + (f" · มุมไม่มีหมุด {ไม่มีให้ยืม}" if ไม่มีให้ยืม else "")
                       + f" · MLEP {self.version}")})
        except Exception as e:
            QgsMessageLog.logMessage("🍩 เข้าคิว Move_Log ไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
        self._donut_inner = []
        self._donut_clear_bands()
        try:
            poly_lyr.removeSelection()      # ★ อย่าทิ้งไฮไลต์ของรอบก่อนไว้ให้รอบถัดไป
        except Exception:
            pass
        if not ต่อได้:
            self._donut_stage = None
        self.iface.messageBar().pushMessage(
            title, f"เหลือเป็น{ชนิด}แล้ว · เนื้อที่ {a0:,.1f} → {a1:,.1f} ตร.ม."
                   + (f" · มีรู {รู} รู" if รู else "")
                   + (f" · แยกเป็น {ก้อน} ก้อน (multipolygon)" if ก้อน > ก้อน0 else "")
                   + (f" · สร้างหมุดให้ {n_mk:,} มุม" if n_mk else "")
                   + (f" · ลบหมุดค้าง {n_del:,} ดวง" if n_del else "")
                   + (f" · ยกชื่อหมุดค้างให้หมุดตรงมุม {len(ยกชื่อ):,} ดวง" if ยกชื่อ else "")
                   + (f" · ⚠️ ชื่อหาย {_n_หาย:,} ชื่อ" + (f" ({เหตุหาย[1]})" if เหตุหาย[1] else "") if _n_หาย else "")
                   + (f" · ⚠️ มุมใหม่ {ไม่มีให้ยืม:,} มุมไม่มีหมุดให้ยืม (เติมเอง)" if ไม่มีให้ยืม else "")
                   + (" · ⚠️ หลังหักผิดกติกาหมุด 1 มม. (รายละเอียดในกล่องยืนยัน)" if _เหล็ก else "")    # ★ 2.3.7 (DI-35)
                   + " • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล",
            level=(1 if ไม่มีให้ยืม or not ค้าง_ตรวจได้ or _n_หาย or _เหล็ก else 0), duration=12)
        return True

    @staticmethod
    def _donut_necks(g, w=0.05):
        """★ รอบ 5 — จำนวน "คอคอด" แคบกว่า w ม. ในรูป g: กัดรูปเข้า w/2 แล้วนับว่าก้อนแตกเพิ่มกี่ก้อน (ทีละก้อน)
        ใช้เทียบก่อน/หลังหัก (คอคอดที่มีอยู่แล้วในรูปเดิมไม่นับ)"""
        n = 0
        try:
            parts = g.asGeometryCollection() if g.isMultipart() else [g]
        except Exception:
            return 0
        def _รู(geom):
            try:
                return sum((q.constGet().numInteriorRings() if hasattr(q.constGet(), 'numInteriorRings') else 0)
                           for q in (geom.asGeometryCollection() if geom.isMultipart() else [geom]))
            except Exception:
                return 0
        for part in parts:
            try:
                e = part.buffer(-w / 2.0, 2)
                if e is None or e.isEmpty():
                    continue
                n += max(0, (len(e.asGeometryCollection()) if e.isMultipart() else 1) - 1)
                # ★ รอบ 5 — แถบแคบระหว่าง "รู" กับขอบนอก (หรือระหว่างรูสองรู) ไม่ทำให้รูปแยกก้อน
                #   แต่กัดแล้วรูทะลุออกขอบ ⇒ จำนวนรูลดลง = มีแถบแคบกว่า w (ผู้ตรวจรอบ 5: รูห่างแนวกรอบ 4 ซม. ไม่ถูกเตือน)
                n += max(0, _รู(part) - _รู(e))
            except Exception:
                continue
        return n

    @staticmethod
    def _donut_neck_points(g, w=0.05):
        """★ รอบ 6 (ผู้ตรวจ A B3) — "ตำแหน่ง" ของคอคอดแคบกว่า w ม. ในรูป g (ไว้เทียบก่อน/หลังหักตามตำแหน่ง) · คืน [QgsGeometry]
        ① ก้อนแตก: กัดเข้า w/2 แล้วก้อนแตกเป็น k ชิ้น ⇒ คอคอด k−1 จุด = กลางเส้นสั้นสุดระหว่างชิ้น (เชื่อมแบบต้นไม้ที่สั้นสุด)
        ② ผนังบาง: รูห่างขอบนอก/รูอื่น < w (กัดแล้วรูทะลุ — ไม่ทำให้ก้อนแตก) ⇒ กลางเส้นสั้นสุดระหว่างสองวงนั้น"""
        out = []

        def _กลาง(a, b):
            ln = a.shortestLine(b).asPolyline()
            return QgsPointXY((ln[0].x() + ln[-1].x()) / 2.0, (ln[0].y() + ln[-1].y()) / 2.0)
        for part in (g.asGeometryCollection() if g.isMultipart() else [g]):
            try:
                e = part.buffer(-w / 2.0, 2)
                ชิ้น = ((e.asGeometryCollection() if e.isMultipart() else [e])
                        if e is not None and not e.isEmpty() else [])
                if len(ชิ้น) > 30:
                    out += [q.pointOnSurface() for q in ชิ้น[1:]]   # หยัก/ฟันเลื่อยถี่ — ไม่ไล่ทุกคู่
                elif len(ชิ้น) > 1:
                    ใน, ระยะ = {0}, {}
                    while len(ใน) < len(ชิ้น):
                        ดี = None
                        for i in sorted(ใน):
                            for j in range(len(ชิ้น)):
                                if j in ใน:
                                    continue
                                if (i, j) not in ระยะ:
                                    ระยะ[(i, j)] = ชิ้น[i].distance(ชิ้น[j])
                                if ดี is None or ระยะ[(i, j)] < ดี[0]:
                                    ดี = (ระยะ[(i, j)], i, j)
                        out.append(QgsGeometry.fromPointXY(_กลาง(ชิ้น[ดี[1]], ชิ้น[ดี[2]])))
                        ใน.add(ดี[2])
                pg = part.constGet()
                nr = pg.numInteriorRings() if hasattr(pg, 'numInteriorRings') else 0
                if nr:
                    วง = [QgsGeometry(pg.exteriorRing().clone())] + [QgsGeometry(pg.interiorRing(i).clone())
                                                                     for i in range(nr)]
                    for i in range(1, len(วง)):
                        for j in range(i):
                            if วง[i].distance(วง[j]) < w:
                                # ★ รอบ 7 (ผู้ตรวจ A N5) — ใช้ "ช่วง" ของวงที่ห่างวงอีกฝั่ง < w (ผนังขนานเป๊ะ: จุดกลางเส้นสั้นสุด
                                #   สลับไปปลายอีกข้างทุกครั้งที่ GEOS เรียงวงใหม่ ⇒ ทุกการหักขึ้น "คอคอดเกิดใหม่" หลอก)
                                try:
                                    ช่วง = วง[i].intersection(วง[j].buffer(w, 4))
                                except Exception:
                                    ช่วง = None
                                out.append(ช่วง if ช่วง is not None and not ช่วง.isEmpty()
                                           else QgsGeometry.fromPointXY(_กลาง(วง[i], วง[j])))
            except Exception:
                continue
        return out

    @staticmethod
    def _donut_new_holes(og0, ใหม่, กรอบ=None, tol=1e-4):
        """★ รอบ 6 (ผู้ตรวจ A B4) — จำนวนรูของรูปหลังหักที่ไม่ใช่รูเดิม (รูเดิม = เนื้อที่และรูปต่างกัน ≤ tol ตร.ม.)
        ★ รอบ 7 (ผู้ตรวจ A N4) — และต้อง "ทับกรอบที่วาด" (กรอบ) เกิน tol ด้วย: รูเดิมที่ถูกขยับมุมตามกติกา ② (กรอบไม่ทับรู)
          ไม่ใช่ "ส่วนที่ทับกลายเป็นรู" (เดิมนับ ⇒ กล่องบอกกลายเป็นรู 1 รูผิด ๆ)"""
        def รู(g):
            out = []
            for part in (g.asGeometryCollection() if g.isMultipart() else [g]):
                pg = part.constGet()
                for i in range(pg.numInteriorRings() if hasattr(pg, 'numInteriorRings') else 0):
                    r = pg.interiorRing(i)
                    out.append(QgsGeometry.fromPolygonXY([[QgsPointXY(r.xAt(j), r.yAt(j)) for j in range(r.numPoints())]]))
            return out
        เดิม = [(h, h.area()) for h in รู(og0)]
        n = 0
        for h in รู(ใหม่):
            a = h.area()
            if any(abs(a - a0) <= tol and h.symDifference(h0).area() <= tol for h0, a0 in เดิม):
                continue
            if กรอบ is not None:
                try:
                    if h.intersection(กรอบ).area() <= tol:
                        continue
                except Exception:
                    pass
            n += 1
        return n

    @staticmethod
    def _donut_merged_holes(og0, ใหม่, กรอบวาด):
        """★ audit รอบ 4 — จำนวนรูเดิมที่อยู่ห่างกรอบตามที่วาด (> 1 ซม.) แต่หลังหักไม่เป็นรูแยกของตัวเองแล้ว
        = ถูกรวมเข้ากับส่วนที่หัก (④ ดึงขอบรูเข้ากรอบ / ย้ายมุมของรู) — ผู้ใช้ไม่ได้ตั้งใจแตะรูนี้ ต้องบอก"""
        def รู(g):
            out = []
            for part in (g.asGeometryCollection() if g.isMultipart() else [g]):
                pg = part.constGet()
                for i in range(pg.numInteriorRings() if hasattr(pg, 'numInteriorRings') else 0):
                    r = pg.interiorRing(i)
                    out.append(QgsGeometry.fromPolygonXY([[QgsPointXY(r.xAt(j), r.yAt(j)) for j in range(r.numPoints())]]))
            return out
        n = 0
        ใหม่_รู = รู(ใหม่)
        for h in รู(og0):
            if h.distance(กรอบวาด) <= 0.01:
                continue                      # กรอบที่วาดแตะ/ทับรูนี้เอง = ตั้งใจ
            c = h.pointOnSurface()
            if not any(h2.contains(c) and h2.intersection(กรอบวาด).area() <= 1e-6 for h2 in ใหม่_รู):
                n += 1
        return n

    def _donut_marker_plan(self, poly_lyr, outer, og, ใหม่, inner, ย้ายมุม=(), เปลือย_out=None):
        """★ 2.3.6 — วางแผนหมุดของ "มุมใหม่" ในแปลงคงเหลือ

        มุมใหม่ = มุมของรูปหลังหักที่ไม่ตรงกับมุมของรูปเดิม (≤ 1 มม.) · og = รูป **ก่อน** หัก/ก่อนดันขอบ
        ชื่อ    = จากหมุดที่อยู่ ≤ 1 ซม. จากมุมนั้น (โหมดกรอบ = หมุดทุกดวง · โหมดเดิม = หมุดของแปลงที่หักออก)
                  ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค.) — "ชื่อเดียว" (ปลั๊กอินไม่เขียน ALT_NAME แล้ว · เดิมชื่อที่เหลือ + ALT_NAME
                  ของหมุดต้นทางไป ALT_NAME) · ชื่อต่างกัน ⇒ ชื่อของหมุดที่วันที่ใหม่สุด (SURV_DATE/ISSUE_DATE) · ตัดสินไม่ได้ ⇒
                  ชื่อตั้งต้น (≤ 1 มม. ก่อน · ชื่อจริงก่อน ชร · ใกล้สุด) + ธง "ถาม" ให้ผู้เรียกเปิด popup (_donut_plan_names)
        ข้าม     = มุมที่แปลงคงเหลือมีหมุดของตัวเองอยู่แล้ว **≤ 1 มม.** (กติกาเหล็ก)
                  ★ audit 25 ก.ย. — เดิมใช้ 1 ซม. ⇒ มุมที่ห่างหมุดของตัวเอง 3 มม. ถูกนับว่า "มีแล้ว"
                    ทั้งที่ผิดกติกาเหล็ก แล้วไม่มีใครรู้
        ★ audit รอบ 4 (30 ก.ย.) — เดิมเทียบทุกมุมใหม่ × ทุกมุมเดิม (แปลง 2,000 มุม = 4 ล้านคู่ ~0.7 วิ) และถามชั้นหมุด
          มุมละ 1-2 ครั้ง ⇒ ตารางแฮชช่องละ 1 มม./1 ซม. + ถามชั้นหมุด **ครั้งเดียว** ด้วยกรอบของทุกมุม (แบบ `_bare_nodes`)
          ทางเร็วล้มด้วยเหตุใดก็ตาม ⇒ ถอยไปถามทีละมุมแบบเดิม ⇒ ผลเหมือนเดิมเสมอ
        คืน (แผน, ไม่มีให้ยืม, point_lyr, ตรวจได้) · แผน = [(xy ในพิกัดชั้นหมุด, ชื่อ, ข้อมูลชื่อ)]
        ข้อมูลชื่อ = dict(ผู้สมัคร=[_name_cand …], ถาม=ตัดสินไม่ได้, ตั้งต้น=ชื่อตั้งต้น)
        ตรวจได้ = False ⇒ ผู้เรียกต้องยกเลิก (fail-closed)
        """
        _chk = self._tool_layers_ok(poly_lyr, "แบ่งหัก/แยก")
        if _chk is None:
            return [], 0, None, False
        _, point_lyr = _chk
        TOL_V, TOL_M = 0.001, 0.01
        เดิม = _กริดจุด([QgsPointXY(v.x(), v.y()) for v in og.vertices()], 0.002)
        มุมใหม่ = _กริดจุด([], 0.002)
        for v in ใหม่.vertices():
            q = QgsPointXY(v.x(), v.y())
            if เดิม.มี(q, TOL_V) or มุมใหม่.มี(q, TOL_V):
                continue                      # มุมเดิม · หรือจุดปิดวง/ซ้ำ
            มุมใหม่.เพิ่ม(q)
        มุมใหม่ = มุมใหม่.pts
        if not มุมใหม่:
            return [], 0, point_lyr, True
        uf_poly = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        uf_pt = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        name_field = self._addnode_name_field(point_lyr)
        โหมดกรอบ = all(f is None for f, _g in inner)       # ★ 2.3.6 — กรอบจากหมุด: ยืมชื่อจากหมุดที่คลิก
        utm_ใน = set()
        if uf_poly and uf_pt and not โหมดกรอบ:
            _it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids([f for f, _g in inner]))
            try:
                for f in _it:
                    u = _norm_utm(f[uf_poly])
                    if u and not u.startswith("\x00"):
                        utm_ใน.add(u)
            finally:
                _it.close()
        to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), QgsProject.instance())
                 if poly_lyr.crs() != point_lyr.crs() else None)
        utm_fields = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO", "UTM"]
        utm_เอง = _norm_utm(outer[uf_poly]) if uf_poly else None

        # ── ทางเร็ว: ถามชั้นหมุดครั้งเดียว ──────────────────────────────────────────────
        จุดถาม = [to_pt.transform(q) if to_pt else QgsPointXY(q) for q in มุมใหม่]
        เก่า_pt = [(to_pt.transform(a) if to_pt else QgsPointXY(a), QgsPointXY(b)) for a, b in ย้ายมุม]
        คลัง = None                           # [(จุด, ชื่อ, (SURV_DATE, ISSUE_DATE), UTM ปกติ, ตรงคีย์ระวางของแปลงนี้, fid)]
        try:
            key = [f for f in utm_fields
                   if _fld_idx(point_lyr.fields(), f) >= 0 and _fld_idx(outer.fields(), f) >= 0]
            want = [str(outer[k] or "") for k in key]
            ทุกจุด = จุดถาม + [a for a, _b in เก่า_pt]
            xs, ys = [p.x() for p in ทุกจุด], [p.y() for p in ทุกจุด]
            rect = QgsRectangle(min(xs) - TOL_M, min(ys) - TOL_M, max(xs) + TOL_M, max(ys) + TOL_M)
            คลัง = []
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    คลัง.append((QgsPointXY(g.asPoint()),
                                 "" if name_field is None else _txt(f[name_field]),
                                 self._mk_dates(f),       # ★ 2.3.7 (b12) — วันที่ตัดสินชื่อ (เดิมช่องนี้ = ALT_NAME)
                                 _norm_utm(f[uf_pt]) if uf_pt else None,
                                 bool(key) and [str(f[k] or "") for k in key] == want,
                                 f.id()))
            finally:
                _it.close()
            คลัง_g = _กริดจุด([r[0] for r in คลัง], TOL_M)
        except Exception as e:
            คลัง = None
            QgsMessageLog.logMessage("_donut_marker_plan: ทางเร็วล้ม ถามทีละมุมแบบเดิม — %s" % e, "MLEP", Qgis.Warning)

        def หมุดในรัศมี(xy):
            """[(จุด, ชื่อ, วันที่, UTM, ตรงคีย์, fid)] ของหมุดที่ห่าง xy ≤ 1 ซม. (ลำดับเดียวกับที่ชั้นส่งมา)"""
            if คลัง is not None:
                return [คลัง[i] for i in คลัง_g.ทั้งหมด(xy, TOL_M)]
            out = []
            rect = QgsRectangle(xy.x() - TOL_M, xy.y() - TOL_M, xy.x() + TOL_M, xy.y() + TOL_M)
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or g.asPoint().distance(xy) > TOL_M:
                        continue
                    out.append((QgsPointXY(g.asPoint()), "" if name_field is None else _txt(f[name_field]),
                                self._mk_dates(f), _norm_utm(f[uf_pt]) if uf_pt else None, None, f.id()))
            finally:
                _it.close()
            return out

        แผน, ไม่มีให้ยืม = [], 0
        for q, xy in zip(มุมใหม่, จุดถาม):
            if คลัง is not None:
                if any(r[4] and r[0].distance(xy) <= TOL_V for r in หมุดในรัศมี(xy)):
                    continue                  # แปลงคงเหลือมีหมุดของตัวเองตรงนี้แล้ว (เกณฑ์เดียวกับ _marker_exists_here)
            elif self._marker_exists_here(point_lyr, outer, xy, utm_fields, tol=TOL_V):
                continue                      # แปลงคงเหลือมีหมุดของตัวเองตรงนี้แล้ว
            พบ = []                           # [(ระยะ, ชื่อ, วันที่, fid)]
            if uf_pt and (utm_ใน or โหมดกรอบ):
                for r in หมุดในรัศมี(xy):
                    if not โหมดกรอบ and r[3] not in utm_ใน:
                        continue
                    พบ.append((round(r[0].distance(xy), 4), r[1], r[2], r[5]))
            # ★ audit รอบ 2 — มุมที่ "ย้ายมุมเดิมมาที่หมุด": หมุดเดิมของมุมนั้น (ห่าง 1-10 ซม.) จะถูกลบเป็นหมุดค้าง
            #   ⇒ ยืมชื่อของมันมาต่อท้ายด้วย ประวัติชื่อไม่หาย (ตรงกับกติกาหมุดซ้อน 7 ก.ย.)
            for (_เก่า, _ใหม่), (_o, _x) in zip(ย้ายมุม, เก่า_pt):
                if _ใหม่.distance(q) > TOL_V or not uf_pt:
                    continue
                for r in หมุดในรัศมี(_o):
                    # ★ audit รอบ 3 (F7) — เฉพาะหมุดของแปลงนี้ (หมุดของแปลงข้างเคียงตรงมุมเดิมไม่ได้ถูกลบ)
                    if utm_เอง is None or r[3] != utm_เอง:
                        continue
                    พบ.append((round(_ใหม่.distance(_เก่า) + r[0].distance(_o), 4), r[1], r[2], r[5]))
            if not พบ:
                ไม่มีให้ยืม += 1
                if เปลือย_out is not None:          # ★ 2.3.7 (DI-35) — มุมที่กล่องนับแล้ว (บรรทัด "หลังหัก" ไม่นับซ้ำ)
                    เปลือย_out.append(QgsPointXY(q))
                continue
            # ★ audit รอบ 2 — ≤ 1 มม. คือ "มุมเดียวกัน" (กติกาเหล็ก) ⇒ ในกลุ่มนี้ชื่อจริงก่อน ชร แล้วค่อยใกล้สุด
            #   (เดิมเรียงระยะก่อน ⇒ ชร ที่ 0 มม. ชนะชื่อจริงที่ 0.3 มม. ขัดกติกาหมุดซ้อน 7 ก.ย.) = ชื่อตั้งต้น
            พบ.sort(key=lambda r: (r[0] > 0.001, _is_chor(r[1]), r[0]))
            # ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค.) — หมุดใหม่เก็บได้ชื่อเดียว (ไม่ต่อ ALT_NAME) · ชื่อต่างกัน ⇒ วันที่ใหม่สุด
            #   ตัดสินไม่ได้ ⇒ ชื่อตั้งต้น + ถาม=True (ผู้เรียกเปิด popup ก่อนกล่องยืนยัน)
            ผู้สมัคร = [self._name_cand(None, r[1], "   ·   ห่างมุม %.1f มม." % (r[0] * 1000), dates=r[2], fid=r[3])
                        for r in พบ if r[1]]
            ตั้งต้น = ผู้สมัคร[0]["nm"] if ผู้สมัคร else ""
            ชื่อ, ถาม = ตั้งต้น, False
            if len({_name_key(c["nm"]) for c in ผู้สมัคร}) > 1:
                ชนะ = _newest_name(ผู้สมัคร)
                ชื่อ, ถาม = (ชนะ, False) if ชนะ is not None else (ตั้งต้น, True)
            แผน.append((xy, ชื่อ, dict(ผู้สมัคร=ผู้สมัคร, ถาม=ถาม, ตั้งต้น=ตั้งต้น)))
        return แผน, ไม่มีให้ยืม, point_lyr, True

    def _donut_plan_names(self, แผน, title, ค้าง=()):
        """★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค. 69) — มุมใหม่ที่ยืมชื่อได้หลายชื่อและวันที่ตัดสินไม่ได้ (ธง "ถาม" จาก
        _donut_marker_plan) ⇒ popup ทีละมุม (QInputDialog.getItem: ชื่อ · SURV_DATE · ISSUE_DATE · gid · ระยะ)
        เลือกไว้ให้ก่อน = ชื่อตั้งต้นของแผน · คืนแผนที่ใส่ชื่อที่เลือกแล้ว · กด Cancel ⇒ None (ผู้เรียกยกเลิกทั้งงาน ไม่แตะอะไร)"""
        ถาม = [k for k, e in enumerate(แผน) if isinstance(e[2], dict) and e[2].get("ถาม")]
        out = list(แผน)
        ค้าง_s = set(ค้าง or ())
        for n, k in enumerate(ถาม, 1):
            xy, ชื่อ, info = out[k]
            ผู้สมัคร = [dict(c, note=(c.get("note") or "")
                             + ("   ·   หมุดเดิมของแปลงนี้ที่จะลบ" if c.get("fid") in ค้าง_s else ""))
                        for c in info.get("ผู้สมัคร", [])]
            r = self._name_choice(
                ผู้สมัคร, info.get("ตั้งต้น", ชื่อ), f"{title} — เลือกชื่อหมุด (มุมใหม่ {n}/{len(ถาม)})",
                f"มุมใหม่ของแปลงคงเหลือที่ {xy.x():,.3f}, {xy.y():,.3f} จะได้หมุดใหม่ 1 ดวง แต่หมุดตรงนั้นมีหลายชื่อ\n"
                "และวันที่ (SURV_DATE / ISSUE_DATE) ตัดสินไม่ได้ ⇒ เลือกชื่อให้หมุดใหม่ของมุมนี้\n"
                "(หมุดเดิมที่ยังอยู่ไม่ถูกแตะ · ชื่อของหมุดเดิมของแปลงนี้ที่จะลบซึ่งไม่ได้เลือกจะหาย — กล่องยืนยันบอกอีกครั้ง)\n"
                "Cancel = ยกเลิก ไม่หัก", เสมอ=False)
            if r is None:
                return None
            out[k] = (xy, r, dict(info, ถาม=False))
        return out

    def _donut_orphans(self, poly_lyr, point_lyr, outer, og0, ใหม่, ย้ายมุม=(), ล็อก_out=None):
        """★ 2.3.6 (เจ้าของงานสั่ง 25 ก.ย. "ลบออก") — หมุดของแปลงนี้ที่เคยอยู่บนมุมเดิม แต่มุมนั้นถูกหักทิ้ง
        (เคสจริง 20265: 89-1 · 89-2 · 89-5) — ปล่อยไว้ = เว็บขึ้นธง "หมุดไม่เกาะ node"
        ตัดสินจาก **มุมเดิมของหมุดดวงนั้น** (มุมเดิมที่ใกล้สุด ≤ 1 ซม.):
          · มุมนั้นยังอยู่ในแปลงคงเหลือ ⇒ ไม่แตะ (แม้หมุดจะเยื้องมุมอยู่ไม่กี่ มม. — ไม่งั้นมุมนั้นเปลือย)
          · มุมนั้นถูกหักทิ้ง และหมุดไม่ได้อยู่บนมุมใหม่ (≤ 1 มม.) ⇒ ลบ
            (หมุดที่เยื้องมุมใหม่ 3 มม. ก็ลบ — มุมใหม่ได้หมุดของตัวเองแล้ว ถ้าเก็บไว้จะกลายเป็นหมุดซ้อน)
        ไม่แตะหมุดที่เดิมก็ไม่ได้อยู่บนมุม (ไม่ใช่ผลของการหักครั้งนี้)
        ★ audit รอบ 4 — เดิมเทียบทุกหมุด × ทุกมุม (แปลง 2,000 มุม = 8 ล้านคู่ ~2.3 วิ) ⇒ ตารางแฮช (ผลเท่าเดิมเป๊ะ)
        คืน (fids, จำนวนที่เป็น ชร, ตรวจได้ไหม, จำนวนที่อยู่ตรงมุมที่ถูกย้าย) · ตรวจไม่ได้ (คีย์ UTM ว่าง/มีแปลงคีย์ซ้ำ/
        ถามชั้นไม่ได้) = ไม่ลบอะไรเลย (fail-closed — ลบตาม UTM ตอนมีแปลงแฝดจะไปโดนหมุดของแปลงแฝด)
        ★ 2.4.0 (review DU-01) — หมุดค้างที่ล็อก (Type L1 · _parcel_markers["locked"]) ไม่อยู่ในรายการลบเด็ดขาด
          ล็อก_out (ลิสต์) = fid ของหมุดค้างที่ล็อก ⇒ ผู้เรียก (🍩) ปฏิเสธทั้งงาน (ลบไม่ได้ + เก็บไว้ก็หลุดมุม)"""
        TOL, TOL_V = 0.01, 0.001
        if point_lyr is None:
            return [], 0, False, 0
        info = self._parcel_markers(poly_lyr, point_lyr, outer)
        if info is None or int(info.get("n_twin", 0) or 0) > 1:
            return [], 0, False, 0
        ids = list(info.get("mk_ids") or [])
        if not ids:
            return [], 0, True, 0
        _ล็อก = info.get("locked") or {}                   # ★ 2.4.0 (review DU-01) ปลดล็อก L1 อยู่ = {}
        to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance())
                   if point_lyr.crs() != poly_lyr.crs() else None)
        เดิม = _กริดจุด([QgsPointXY(v.x(), v.y()) for v in og0.vertices()], TOL)
        ยังอยู่ = _กริดจุด([QgsPointXY(v.x(), v.y()) for v in ใหม่.vertices()], 0.002)
        name_field = self._addnode_name_field(point_lyr)
        out, n_chor, n_moved = [], 0, 0
        try:
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(ids))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    p = g.asPoint()
                    q = to_poly.transform(p) if to_poly else QgsPointXY(p)
                    h = เดิม.ใกล้สุด(q, TOL)
                    if h is None:
                        continue                  # เดิมก็ไม่ได้อยู่บนมุม — ไม่ใช่เรื่องของการหักครั้งนี้
                    ใกล้ = h[1]
                    if ยังอยู่.มี(ใกล้, TOL_V):
                        continue                  # มุมเดิมของมันยังอยู่ — ไม่แตะ
                    if ยังอยู่.มี(q, TOL_V):
                        continue                  # อยู่บนมุมใหม่พอดี — ใช้เป็นหมุดของมุมนั้นต่อ
                    if f.id() in _ล็อก:           # ★ 2.4.0 (review DU-01) หมุดล็อก — ห้ามลบ
                        if ล็อก_out is not None:
                            ล็อก_out.append(f.id())
                        continue
                    out.append(f.id())
                    if name_field is not None and _is_chor(_txt(f[name_field])):
                        n_chor += 1
                    # ★ 2.3.7 (known-2.3.6 ข้อ 10 a) — นับว่า "ตรงมุมที่ถูกย้ายไปที่หมุด" เฉพาะเมื่อปลายทาง b ยังเป็นมุมของรูปใหม่
                    #   มุมที่ย้ายไปที่หมุดแล้วกรอบหักทิ้ง = มุมที่ถูกหักทิ้งจริง (หมุดถูกลบไปกับมุมนั้น) — เดิมกล่องเรียกว่า "ย้ายไปที่หมุด"
                    if any(ใกล้.distance(a) <= TOL_V and ยังอยู่.มี(QgsPointXY(b), TOL_V) for a, b in ย้ายมุม):
                        n_moved += 1
            finally:
                _it.close()
        except Exception:
            return [], 0, False, 0
        return out, n_chor, True, n_moved

    def _donut_heirs(self, poly_lyr, point_lyr, outer, og0, ใหม่, ค้าง, ย้ายมุม=(), แผน=(), หาย_out=None, ล็อก_out=None):
        """★ รอบ 9 (1 ต.ค. ตรวจเอกสารส่งต่อ) — หมุดค้าง (ผลจาก _donut_orphans) ที่ "มุมของมัน" มีหมุดของแปลงนี้อยู่แล้ว
        ≤ 1 มม. ⇒ ชื่อต้องยกให้หมุดดวงนั้น ไม่งั้นหายเงียบ ๆ (ขัดกติกาหมุดซ้อน 7 ก.ย.)
          มุมของมัน = มุมเดิมของมันถูกย้าย (② / ⑤ / ⑤ง) ⇒ ตำแหน่งใหม่ · ไม่งั้น มุมใหม่ (ไม่ตรงมุมเดิม ≤ 1 มม.) ที่ใกล้สุด ≤ 1 ซม.
          เคสที่เจอ: คลิกหมุดซ้อนของแปลงนี้เองที่ห่างมุม 1 มม.-10 ซม. ⇒ มุมย้ายไปที่หมุดนั้น แผนหมุดไม่สร้างหมุดใหม่
          (มีหมุดของตัวเองแล้ว) แต่หมุดเดิมที่มุมถูกลบเป็นหมุดค้าง ⇒ เดิมชื่อหาย
          ไม่ยกซ้ำ: มุมที่แผนหมุดสร้างหมุดใหม่ให้ (ยืมชื่อหมุดค้างตรงนั้นไปแล้ว) · มุมที่ถูกหักทิ้งจริง = ลบพร้อมชื่อ (คำสั่ง 25 ก.ย.)
          ผู้รับ = หมุด UTM เดียวกับแปลงนี้ (ไม่ใช่หมุดค้าง) ห่างมุมนั้น ≤ 1 มม. · หลายดวง (หมุดซ้อนเดิม) ⇒ ดวงไม่มีชื่อก่อน (★ 2.3.7)
            แล้วชื่อจริงก่อน ชร แล้วใกล้สุด
          ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค. 69) — ปลั๊กอินเลิกเขียน ALT_NAME ⇒ ไม่เก็บ "ประวัติ ALT" ของหมุดค้างอีก (ข้อ 9c ด้านล่าง
            เหลือแค่ชื่อหลัก) · ผู้รับ + หมุดค้างของมุมเดียวกัน = หมุดซ้อน ⇒ ชื่อที่เก็บตัดสินที่ _donut_heir_plan (วันที่ใหม่สุด/popup)
            · "แผนยืมแล้ว" = ชื่อของหมุดค้างเป็นชื่อที่แผนหมุดเลือกให้หมุดใหม่ (หลัง popup) — ไม่ใช่ ⇒ ไปที่ผู้รับ · ไม่มีผู้รับ ⇒ หาย_out
              (ข้อ 9d ข เดิมใช้เฉพาะชั้นที่ไม่มีคอลัมน์ ALT_NAME — ตอนนี้ใช้กับทุกชั้น)
          ★ รอบ 9b (ผู้ตรวจ C1) — ชื่อที่ยกให้ผู้รับแต่ละดวง เรียงแบบลบ Node: ชื่อจริง → ชร → ไม่มีชื่อ → ใกล้มุม → fid
            (ชื่อหลักก่อน ประวัติ ALT_NAME ตามหลัง) — เดิมตามลำดับแถวที่ชั้นส่งมา ⇒ ผู้รับไม่มีชื่ออาจได้ ชร เป็นชื่อหลักทั้งที่มีชื่อจริง
          ★ รอบ 9b (ผู้ตรวจ C2) — อ่านชั้นเฉพาะหมุดค้าง (ตาม fid) + กรอบ ±1 ซม. รอบมุมเป้าหมาย (เดิมเรียก _parcel_markers ซ้ำ
            = กวาดทั้งแปลง + UTM ทั้งชั้นอีกรอบ · แปลงถนน/คลองแนวทแยงคลุมหมุดเป็นแสนดวง — เหตุผลเดียวกับ ★ รอบ 8)
        ★ รอบ 9c — แยก "ชื่อหลักของหมุดค้าง" กับ "ประวัติ ALT" ออกจากกัน: ผู้รับไม่มีชื่อได้ชื่อหลักจากกองแรกเท่านั้น
          (เดิมหมุดค้างไม่มีชื่อที่ถือ ALT 'old-a' ⇒ ผู้รับได้ 'old-a' เป็นชื่อหลัก — แผนหมุดและลบ Node ไม่เคยทำแบบนี้)
        ★ รอบ 9d (ผู้ตรวจรอบ 9b):
          (ก) ผู้รับต้องอยู่บนมุมของรูปใหม่ ≤ 1 มม. · มุมที่ถูกย้ายไปที่หมุดแล้วกรอบหักทิ้ง = มุมที่ถูกหักทิ้งจริง (ลบพร้อมชื่อ
              ตามคำสั่ง 25 ก.ย.) — 9b เขียนใหม่เพื่อความเร็วแล้วด่านนี้ของรอบ 9 หลุดไป ⇒ ชื่อของมุมที่หักทิ้งไปลงหมุดลอย
              นอกแปลง (บางทีเป็นชื่อหลัก) ทั้งที่กล่องบอกว่า "อยู่ตรงมุมนั้นแล้ว"
          (ข) ชั้นหมุดไม่มีคอลัมน์ ALT_NAME: หมุดใหม่ของแผนเก็บได้แค่ชื่อหลัก (_donut_add_markers ทิ้งชื่ออื่น) ⇒ "แผนยืมแล้ว"
              ข้ามได้เฉพาะเมื่อชื่อของหมุดค้างเป็นชื่อหลักของแผนที่ยืมมัน ไม่งั้นยกให้ผู้รับ · ไม่มีผู้รับ ⇒ ชื่อเข้า หาย_out
              (กล่อง/แถบเตือนก่อน) — เดิมหายเงียบ ๆ · ชื่อที่แผนยืมจากหมุดที่ไม่ถูกลบ (หมุดที่คลิก ฯลฯ) ไม่นับว่าหาย
              (หมุดดวงนั้นยังถือชื่ออยู่)
          (ค) คีย์ UTM ว่าง/NULL ⇒ None (_norm_utm คืนค่าแทนที่ขึ้นต้นด้วยอักขระ NUL ซึ่งเป็นจริงเสมอ ⇒ ด่านเดิมไม่เคยทำงาน)
          (จ) "แผนยืมแล้ว" ตรงตามที่แผนยืมจริง: ห่างจุดในแผน ≤ 1 ซม. · หรือห่างตำแหน่งเดิม a ของมุมที่ย้าย ≤ 1 ซม. และแผน
              มีจุดที่ปลายทาง b (_donut_marker_plan ยืมหมุดของแปลงนี้รอบ a ให้หมุดใหม่ที่ b) — เดิมดูแค่ "มุมของมัน" มีจุดใน
              แผนไหม ⇒ มุมตัดเฉียง 2 มุมห่างกัน < 1 ซม. ที่ย้ายทั้งคู่: ชื่อเดียวอยู่ 2 ดวง
        หาย_out (ถ้าส่งลิสต์มา) = ชื่อที่จะหายเพราะแผนเก็บไม่ได้และไม่มีผู้รับ (ข้อ ข) — ฟังก์ชันเติมให้
        ★ 2.4.0 (review DU-01-followup) — หมุดล็อก (_marker_locked: Type ของตัวหมุดเป็น L1) ไม่เป็นผู้รับ เว้นแต่ปลดล็อก L1
          (เดิมผู้รับถูกตั้งชื่อใหม่ = เขียน BND_NAME ทับหมุด L1 ทั้งที่ปุ่มแก้ชื่อหมุดปฏิเสธ · ผู้ช่วยผู้ดูแลก็ทำได้)
          มุมนั้นมีแต่หมุดล็อก ⇒ ไม่มีผู้รับ · ชื่อของหมุดค้างที่ไม่ตรงกับชื่อของหมุดล็อกตรงมุมนั้น = จะหาย ⇒ ล็อก_out
          (ลิสต์ · ไม่ส่งมา = เข้า หาย_out) ให้กล่องยืนยันบอกเหตุ · ฝั่ง UTM ของกติกาไม่ต้องสแกน: ผู้รับ UTM เท่าแปลงนี้
          (แปลง L1 / มีแฝด ⇒ 🍩 ปฏิเสธหรือไม่มีหมุดค้างตั้งแต่ต้น — เหตุผลเดียวกับ _parcel_markers["locked"])
        คืน {fid ผู้รับ: [ผู้สมัครชื่อของหมุดค้าง (dict ของ _name_cand + ระยะ) เรียง ชื่อจริง → ชร → ไม่มีชื่อ → ใกล้มุม → fid]}
        · ตรวจไม่ได้ ⇒ None (ผู้เรียกยกเลิก)
        แยกจาก _donut_orphans (ไม่แตะผลของมัน) ⇒ สคริปต์/เทสที่เรียก _donut_orphans ตรง ๆ ได้ผลเหมือนเดิม"""
        TOL, TOL_V = 0.01, 0.001
        if not ค้าง or point_lyr is None:
            return {}
        try:
            uf_poly = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            uf_pt = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            utm_เอง = _norm_utm(outer[uf_poly]) if uf_poly else None
            # ★ รอบ 9d (ค) — คีย์ว่าง/NULL = ไม่ใช่ของใคร (กติกา 2.3.5) ⇒ ตรวจไม่ได้ (เดิม `not utm_เอง` ไม่เคยจริง)
            if not uf_pt or not utm_เอง or utm_เอง.startswith("\x00"):
                return None
            _ต่าง = point_lyr.crs() != poly_lyr.crs()
            to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance())
                       if _ต่าง else None)
            to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), QgsProject.instance())
                     if _ต่าง else None)
            เดิม = _กริดจุด([QgsPointXY(v.x(), v.y()) for v in og0.vertices()], TOL)
            เป็นใหม่ = _กริดจุด([QgsPointXY(v.x(), v.y()) for v in ใหม่.vertices()
                                if not เดิม.มี(QgsPointXY(v.x(), v.y()), TOL_V)], TOL)
            # ★ รอบ 9b (ผู้ตรวจ A · C5) — แผนหมุดอยู่ในพิกัดชั้นหมุด ⇒ เทียบในพิกัดชั้นหมุด (แปลงทางเดียวกับที่แผนใช้ ⇒ ตรงกันเป๊ะ
            #   แม้ datum ต่างกัน — ไปกลับ Indian 1975 ↔ WGS 84 คลาด 1.2 มม. เกินเกณฑ์ 1 มม.)
            ตามแผน = _กริดจุด([QgsPointXY(xy) for xy, _n, _a in แผน], TOL)
            # ★ รอบ 9d (ก) — มุมทุกมุมของรูปใหม่ (มุมของหมุดค้าง + ตัวผู้รับ ต้องอยู่บนรูปใหม่)
            ยังอยู่ = _กริดจุด([QgsPointXY(v.x(), v.y()) for v in ใหม่.vertices()], 0.002)
            # ★ รอบ 9d (จ) — มุมที่ถูกย้าย a → b ในพิกัดชั้นหมุด (แปลงทางเดียวกับแผนหมุด)
            ย้าย_pt = [(to_pt.transform(a) if to_pt else QgsPointXY(a), to_pt.transform(b) if to_pt else QgsPointXY(b))
                      for a, b in ย้ายมุม]
            name_field = self._addnode_name_field(point_lyr)
            ค้าง_s = set(ค้าง)
            _ti = self._field_index(point_lyr.fields(), 'type')      # ★ 2.4.0 (review DU-01-followup) Type ของหมุด
            _ปลด = self._l1_unlocked()
            # ① หมุดค้าง ⇒ "มุมของมัน"
            งาน = []                          # [(มุม ในพิกัดชั้นแปลง, ระยะถึงมุม, fid หมุดค้าง, ชื่อ, วันที่, ค้างแผน)]
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(ค้าง)))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    p = g.asPoint()
                    q = to_poly.transform(p) if to_poly else QgsPointXY(p)
                    ชื่อ_ค = _txt(f[name_field]) if name_field is not None else ""
                    # ★ รอบ 9b (ผู้ตรวจ A · C5) — แผนหมุด (โหมดกรอบ) ยืมชื่อหมุดค้างไปแล้ว ⇒ ไม่ยกให้ผู้รับอีก (เดิมชื่อเดียวอยู่ 2 ดวง)
                    # ★ รอบ 9d (จ) — "ยืมแล้ว" ตามที่แผนยืมจริง: ห่างจุดในแผน ≤ 1 ซม. · หรือห่างตำแหน่งเดิม a ของมุมที่ย้าย ≤ 1 ซม.
                    #   และแผนมีจุดที่ปลายทาง b (เดิมดูว่า "มุมของมัน" มีจุดในแผนไหม ⇒ มุมตัดเฉียงยกซ้ำ · บางเคสยกไม่ได้เลย)
                    ยืม = set(ตามแผน.ทั้งหมด(QgsPointXY(p), TOL))
                    for a_pt, b_pt in ย้าย_pt:
                        if QgsPointXY(p).distance(a_pt) <= TOL:
                            ยืม.update(ตามแผน.ทั้งหมด(b_pt, TOL_V))
                    ค้างแผน = False
                    if ยืม:
                        # ★ รอบ 9d (ข) · ★ 2.3.7 (b12) — หมุดใหม่ของแผนเก็บได้แค่ชื่อเดียว (ไม่มี ALT_NAME แล้วทุกชั้น) ⇒ ข้ามได้
                        #   เฉพาะเมื่อชื่อของหมุดค้างเป็นชื่อที่แผนเลือก (ชร ทุกแบบนับเป็นชื่อเดียวกัน)
                        if not ชื่อ_ค or any(_name_key(แผน[i][1]) == _name_key(ชื่อ_ค) for i in ยืม):
                            continue
                        ค้างแผน = True        # แผนไม่ได้เลือกชื่อนี้ ⇒ ไปที่ผู้รับถ้ามี · ไม่มี ⇒ บอกว่าจะหาย
                    h = เดิม.ใกล้สุด(q, TOL)
                    if h is None:
                        continue
                    ใกล้ = QgsPointXY(h[1])
                    มุม = next((QgsPointXY(b) for a, b in ย้ายมุม if ใกล้.distance(a) <= TOL_V), None)
                    if มุม is None:
                        h2 = เป็นใหม่.ใกล้สุด(q, TOL)
                        มุม = QgsPointXY(h2[1]) if h2 is not None else None
                    # ★ รอบ 9d (ก) — มุมของมันต้องยังเป็นมุมของรูปใหม่ (ย้ายไปที่หมุดแล้วกรอบหักทิ้ง = หักทิ้งจริง ⇒ ลบพร้อมชื่อ)
                    if มุม is None or not ยังอยู่.มี(มุม, TOL_V):
                        if ค้างแผน and หาย_out is not None and ชื่อ_ค not in หาย_out:
                            หาย_out.append(ชื่อ_ค)
                        continue
                    งาน.append((มุม, q.distance(มุม), f.id(), ชื่อ_ค, self._mk_dates(f), ค้างแผน))
            finally:
                _it.close()
            # ② ผู้รับ — ถามชั้นเฉพาะกรอบ ±1 ซม. รอบมุมนั้น (ตัดสินระยะในพิกัดชั้นแปลง)
            ต่อดวง, จำ = {}, {}
            ล็อกที่มุม = {}                   # ★ 2.4.0 (review DU-01-followup) key มุม -> {ชื่อ (_name_key) ของหมุดล็อกตรงมุมนั้น}
            for มุม, ระยะ, fid_ค, ชื่อ, วันที่, ค้างแผน in งาน:
                key = (round(มุม.x(), 4), round(มุม.y(), 4))
                if key not in จำ:
                    r_poly = QgsRectangle(มุม.x() - TOL, มุม.y() - TOL, มุม.x() + TOL, มุม.y() + TOL)
                    r_pt = to_pt.transformBoundingBox(r_poly) if to_pt else r_poly
                    cand, cand_ล็อก = [], set()
                    _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r_pt))
                    try:
                        for f in _it:
                            if f.id() in ค้าง_s:
                                continue
                            g = f.geometry()
                            if g is None or g.isEmpty() or _norm_utm(f[uf_pt]) != utm_เอง:
                                continue
                            q = to_poly.transform(g.asPoint()) if to_poly else QgsPointXY(g.asPoint())
                            # ★ รอบ 9d (ก) — ผู้รับต้องอยู่บนมุมของรูปใหม่จริง ≤ 1 มม. (ด่านของรอบ 9 ที่ 9b ทำหลุด)
                            if q.distance(มุม) > TOL_V or not ยังอยู่.มี(q, TOL_V):
                                continue
                            # ★ 2.4.0 (review DU-01-followup) — หมุดล็อกไม่รับชื่อ (ห้ามเขียน BND_NAME ทับ) เว้นแต่ปลดล็อก L1
                            if not _ปลด and self._marker_locked(f, {}, uf_pt, _ti)[0]:
                                cand_ล็อก.add(_name_key(_txt(f[name_field])) if name_field is not None else "")
                                continue
                            cand.append((f.id(), q, _txt(f[name_field]) if name_field is not None else ""))
                    finally:
                        _it.close()
                    # ★ 2.3.7 (known-2.3.6 ข้อ 10 b) — ดวงไม่มีชื่อบนมุมเดียวกัน (≤ 1 มม.) มาก่อน: ได้ชื่อของหมุดค้างโดยไม่มีชื่อไหนหาย
                    #   ไม่มีดวงไม่มีชื่อ ⇒ ชื่อจริงก่อน ชร แล้วใกล้สุด แล้ว fid (ชื่อที่เก็บตัดสินที่ _donut_heir_plan)
                    จำ[key] = (min(cand, key=lambda r: (bool(r[2]), _is_chor(r[2]), r[1].distance(มุม), r[0]))[0]
                               if cand else None)
                    ล็อกที่มุม[key] = cand_ล็อก
                if จำ[key] is not None:
                    ต่อดวง.setdefault(จำ[key], []).append((ระยะ, fid_ค, ชื่อ, วันที่))
                elif ล็อกที่มุม[key]:
                    # ★ 2.4.0 (review DU-01-followup) — มุมนี้มีแต่หมุดล็อก ⇒ ไม่ยกชื่อ · ชื่อที่หมุดล็อกถืออยู่แล้วไม่นับว่าหาย
                    if ชื่อ and _name_key(ชื่อ) not in ล็อกที่มุม[key]:
                        _ไป = ล็อก_out if ล็อก_out is not None else หาย_out
                        if _ไป is not None and ชื่อ not in _ไป:
                            _ไป.append(ชื่อ)
                elif ค้างแผน and หาย_out is not None and ชื่อ not in หาย_out:
                    หาย_out.append(ชื่อ)          # ★ รอบ 9d (ข) — แผนเก็บไม่ได้ + ไม่มีผู้รับ ⇒ บอกว่าจะหาย
            # ③ เรียงแบบลบ Node — ชื่อจริง → ชร → ไม่มีชื่อ → ใกล้มุม → fid (★ รอบ 9b C1) · ★ 2.3.7 (b12) ผู้สมัครชื่อพร้อมวันที่
            ผู้รับ = {}
            for fid in sorted(ต่อดวง):
                ls = sorted(ต่อดวง[fid], key=lambda r: (not r[2], _is_chor(r[2]), r[0], r[1]))
                ผู้รับ[fid] = [dict(self._name_cand(None, r[2], "   ·   หมุดค้างที่จะลบ (ห่างมุม %.1f มม.)" % (r[0] * 1000),
                                                   dates=r[3], fid=r[1]), ระยะ=r[0]) for r in ls]
            return ผู้รับ
        except Exception as e:
            QgsMessageLog.logMessage("_donut_heirs: ตรวจไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            return None

    def _donut_iron_after(self, poly_lyr, point_lyr, outer, og0, ใหม่, กรอบ, ค้าง, แผน, นับแล้ว=(), ซ่อม=False):
        """★ 2.3.7 (review DI-35) — การหักทำให้แปลงคงเหลือผิดกติกา 1 มุม : 1 หมุด ได้โดยไม่มีอะไรบอก (ผู้ตรวจ Monte Carlo: มุมเปลือย
        ที่กล่องไม่ได้นับ 6/14,660 ครั้ง · หมุดที่คลิกห่างมุมเดิม > 1 ซม. แล้วมุมนั้นถูกหักทิ้ง ค้างนอกแปลงเงียบ ๆ)
        ⇒ จำลองสภาพหลังหัก (อ่านอย่างเดียว · แนวเดียวกับ _delnode_iron_after) แล้วเทียบก่อน/หลังเฉพาะในกรอบของงาน
          (กรอบที่วาด/แปลงที่หักออก + มุมที่เปลี่ยน ขยาย 10 ซม. · ของนอกกรอบไม่เปลี่ยน):
          · มุมที่ไม่มีหมุดของแปลงนี้ ≤ 1 มม. ที่เกิดใหม่ — ไม่นับมุมที่กล่องบอกแล้ว (นับแล้ว = มุมใหม่ที่ "ไม่มีหมุดให้ยืมชื่อ")
          · หมุดของแปลงนี้ที่ไม่อยู่บนมุม ≤ 1 มม. ที่เกิดใหม่
          · หมุดของแปลงนี้ที่ค้างนอกแปลงคงเหลือ: เดิมอยู่บน/ใน/ชิดแปลง (≤ 1 ซม.) หลังหักห่างแปลงเกิน 1 มม. และไกลขึ้นกว่าเดิม
        หมุดหลังหัก = หมุดเดิม − หมุดค้างที่จะลบ + หมุดใหม่ตามแผน · มุมของแปลงแฝด (UTM เดียวกัน) ในกรอบนับเป็นมุมด้วย
        ★ 2.3.7 (b12) — ซ่อม=True: ใช้ตรวจหลังซ่อมรูป (ใหม่ = รูปที่ซ่อม · ไม่มีหมุดค้าง/แผน) ถ้อยคำ "หลังซ่อม" + แนะนำ Add Node/Move Node
        คืน "" = ไม่มีอะไรแย่ลง (หรือคีย์ว่าง — กล่องบอกแล้วว่าตรวจหมุดเดิมไม่ได้) · ตรวจไม่ได้ ⇒ บรรทัดบอกให้ตรวจเอง (ไม่เงียบ)"""
        TOL_V, PAD, ชิด = 0.001, 0.10, 0.01
        try:
            if point_lyr is None:
                return ""
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if not pu or not tu:
                return ""
            utm = _norm_utm(outer[pu])
            if utm.startswith("\x00"):
                return ""
            _ต่าง = point_lyr.crs() != poly_lyr.crs()
            to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance()) if _ต่าง else None)
            to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), QgsProject.instance()) if _ต่าง else None)
            V0ทั้งหมด = [QgsPointXY(v.x(), v.y()) for v in og0.vertices()]
            V1ทั้งหมด = [QgsPointXY(v.x(), v.y()) for v in ใหม่.vertices()]
            _g0, _g1 = _กริดจุด(V0ทั้งหมด, 0.002), _กริดจุด(V1ทั้งหมด, 0.002)
            ขอบเขต = ([v for v in V1ทั้งหมด if not _g0.มี(v, 1e-6)] + [v for v in V0ทั้งหมด if not _g1.มี(v, 1e-6)])
            if กรอบ is not None and not กรอบ.isEmpty():
                _b = กรอบ.boundingBox()
                ขอบเขต += [QgsPointXY(_b.xMinimum(), _b.yMinimum()), QgsPointXY(_b.xMaximum(), _b.yMaximum())]
            if not ขอบเขต:
                return ""
            x0 = min(p.x() for p in ขอบเขต) - PAD
            x1 = max(p.x() for p in ขอบเขต) + PAD
            y0 = min(p.y() for p in ขอบเขต) - PAD
            y1 = max(p.y() for p in ขอบเขต) + PAD
            r_poly = QgsRectangle(x0, y0, x1, y1)
            r_pt = to_pt.transformBoundingBox(r_poly) if to_pt else r_poly

            def ใน(v):
                return x0 <= v.x() <= x1 and y0 <= v.y() <= y1
            หมุด = []                     # [(fid, จุดในพิกัดชั้นแปลง)] หมุดของแปลงนี้ในกรอบ (ก่อนหัก)
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r_pt))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or _norm_utm(f[tu]) != utm:
                        continue
                    try:
                        q = g.asPoint()
                    except Exception:
                        continue
                    หมุด.append((f.id(), to_poly.transform(q) if to_poly else QgsPointXY(q)))
            finally:
                _it.close()
            แฝด = []
            _it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r_poly))
            try:
                for f in _it:
                    if f.id() == outer.id() or _norm_utm(f[pu]) != utm:
                        continue
                    gg = f.geometry()
                    if gg is not None and not gg.isEmpty():
                        แฝด.extend(QgsPointXY(v.x(), v.y()) for v in gg.vertices() if ใน(v))
            finally:
                _it.close()
            _ลบ = set(ค้าง or ())
            M0 = list(หมุด)
            M1 = [(i, m) for i, m in หมุด if i not in _ลบ] + [
                (None, to_poly.transform(QgsPointXY(xy)) if to_poly else QgsPointXY(xy)) for xy, _n, _a in (แผน or ())]
            V0 = [v for v in V0ทั้งหมด if ใน(v)] + แฝด
            V1 = [v for v in V1ทั้งหมด if ใน(v)] + แฝด

            def เปลือย(V, M):
                gm = _กริดจุด([m for _i, m in M], 0.002)
                out = _กริดจุด([], 0.002)
                for v in V:
                    if not gm.มี(v, TOL_V) and not out.มี(v, 1e-6):
                        out.เพิ่ม(v)
                return out.pts

            def หลุด(M, V):
                gv = _กริดจุด(V, 0.002)
                return {i for i, m in M if i is not None and not gv.มี(m, TOL_V)}
            _เดิม = _กริดจุด(เปลือย(V0, M0) + [QgsPointXY(q) for q in (นับแล้ว or ())], 0.002)
            ใหม่เปลือย = [v for v in เปลือย(V1, M1) if not _เดิม.มี(v, 1e-6)]
            # หมุดค้างนอกแปลงคงเหลือ: เดิมอยู่บน/ใน/ชิดแปลง ≤ 1 ซม. · หลังหักห่าง > 1 มม. และไกลขึ้นกว่าเดิม (หมุดที่ไม่ถูกลบเท่านั้น)
            นอก = []
            for i, m in หมุด:
                if i in _ลบ:
                    continue
                gp = QgsGeometry.fromPointXY(m)
                d0, d1 = og0.distance(gp), ใหม่.distance(gp)
                if d0 <= ชิด and d1 > TOL_V and d1 > d0 + TOL_V:
                    นอก.append(i)
            ใหม่หลุด = sorted(หลุด(M1, V1) - หลุด(M0, V0) - set(นอก))
            if not ใหม่เปลือย and not ใหม่หลุด and not นอก:
                return ""

            def _gid(ls):
                ls = sorted(ls)
                return ", ".join(str(i) for i in ls[:6]) + (" …" if len(ls) > 6 else "")
            ส่วน = []
            if ใหม่เปลือย:
                ส่วน.append(f"มุมที่ไม่มีหมุดของแปลงภายใน 1 มม. เพิ่ม {len(ใหม่เปลือย):,} มุม"
                            + (" (นอกเหนือจากมุมใหม่ที่ไม่มีหมุดให้ยืมข้างบน)" if นับแล้ว else ""))
            if ใหม่หลุด:
                ส่วน.append(f"หมุดที่ไม่อยู่บนมุมภายใน 1 มม. เพิ่ม {len(ใหม่หลุด):,} ดวง (gid {_gid(ใหม่หลุด)})")
            if นอก:
                ส่วน.append(f"หมุดของแปลงนี้ค้างนอก{'แปลง' if ซ่อม else 'แปลงคงเหลือ'} {len(นอก):,} ดวง (gid {_gid(นอก)})")
            if ซ่อม:
                return ("⚠️ หลังซ่อม: " + " · ".join(ส่วน)
                        + " — ผิดกติกาหมุด 1 มม. (การซ่อมไม่แตะหมุด) แก้ต่อด้วย Add Node / Move Node · ↺ ย้อนการซ่อมได้\n")
            return ("⚠️ หลังหัก: " + " · ".join(ส่วน)
                    + " — ผิดกติกาหมุด 1 มม. ตรวจ/แก้เองหลังหัก · ↺ ย้อนได้\n")
        except Exception as e:
            QgsMessageLog.logMessage("_donut_iron_after: ตรวจไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            return ("⚠️ ตรวจกติกาหมุด 1 มม. หลังซ่อมไม่ได้ — ตรวจเองหลังซ่อม\n" if ซ่อม
                    else "⚠️ ตรวจกติกาหมุด 1 มม. หลังหักไม่ได้ — ตรวจเองหลังหัก\n")

    @staticmethod
    def _donut_heir_text(ยกชื่อ, สูงสุด=5):
        """★ รอบ 9b (ผู้ตรวจ C3) — บรรทัดกล่องยืนยันของการตั้งชื่อผู้รับ ทีละดวง: gid + ชื่อเดิม · ชื่อที่ตั้งให้
        ★ 2.3.7 (b12) — ไม่มีส่วน "ต่อ ALT_NAME" แล้ว (ปลั๊กอินไม่เขียน ALT_NAME) · ยกชื่อ = [(fid, ชื่อเดิม, ชื่อใหม่)]"""
        if not ยกชื่อ:
            return ""
        แถว = [f"  · gid {_f} {_n or '(ไม่มีชื่อ)'}: ตั้งชื่อ \"{ชื่อใหม่}\""
                + (f" — ⚠️ ชื่อเดิม \"{_n}\" จะหายไป" if _n else "") for _f, _n, ชื่อใหม่ in ยกชื่อ[:สูงสุด]]
        if len(ยกชื่อ) > สูงสุด:
            แถว.append(f"  · … อีก {len(ยกชื่อ) - สูงสุด:,} ดวง")
        return "ชื่อของหมุดค้างที่ลบ ยกให้หมุดของแปลงนี้ที่อยู่ตรงมุมนั้นแล้ว:\n" + "\n".join(แถว) + "\n"

    def _donut_heir_plan(self, point_lyr, ผู้รับ, หายก่อน=(), title="แบ่งหัก/แยก", หายล็อก=()):
        """★ รอบ 9 — แผนตั้งชื่อผู้รับ (ผลจาก _donut_heirs) · ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค. 69) เขียนใหม่ — ไม่ต่อ ALT_NAME
        ผู้รับ + หมุดค้างของมุมเดียวกัน = หมุดซ้อน ⇒ เก็บได้ "ชื่อเดียว" (BND_NAME ของผู้รับ):
          · ชื่อเดียว (ชร ทุกแบบนับเป็นชื่อเดียว) · หรือผู้รับไม่มีชื่อ + หมุดค้างชื่อเดียว ⇒ ชื่อนั้น (ไม่มีอะไรหาย)
          · ชื่อต่างกัน ⇒ ชื่อของหมุดที่วันที่ใหม่สุด (ค่าที่ใหม่กว่าระหว่าง SURV_DATE กับ ISSUE_DATE) · ตัดสินไม่ได้ ⇒ popup
            (เลือกไว้ให้ก่อน = ชื่อจริงก่อน ชร: ชื่อจริงของผู้รับ → ชื่อจริงของหมุดค้างที่ใกล้สุด → ชร)
          · ชื่อของหมุดค้างที่ไม่ได้เลือก (รวม ชร) ⇒ กอง "จะหาย" · ชื่อเดิมของผู้รับที่ถูกเปลี่ยน ⇒ บรรทัดตั้งชื่อบอกว่าหาย
          · บัญชีแก้ BND_NAME ไม่ได้ (ฐานบอกชัด) ⇒ ไม่ถาม ผู้รับคงชื่อเดิม · ชื่อของหมุดค้างเข้ากอง "จะหาย" พร้อมเหตุ
        หายก่อน = ชื่อของหมุดค้างที่แผนหมุดยืมแต่ไม่ได้เลือก และไม่มีผู้รับ (หาย_out ของ _donut_heirs) ⇒ รวมในกอง "จะหาย"
        ★ 2.4.0 (review DU-01-followup) หายล็อก = ชื่อของหมุดค้างที่มุมของมันมีแต่หมุดล็อก L1 (ล็อก_out ของ _donut_heirs)
          ⇒ รวมในกอง "จะหาย" พร้อมเหตุของมันเอง (ยกชื่อให้หมุดล็อกไม่ได้)
        เรียงตาม fid ผู้รับ (ข้อความกล่อง/ลำดับเขียนไม่ขึ้นกับลำดับแถวที่ชั้นส่งมา — ★ รอบ 9b)
        คืน ([(fid, ชื่อเดิม, ชื่อใหม่)], [ชื่อที่จะหาย], (เหตุยาว, เหตุสั้น)) · อ่านชั้นไม่ได้ ⇒ None · กด Cancel ⇒ False"""
        if (not ผู้รับ and not หายก่อน and not หายล็อก) or point_lyr is None:
            return [], [], ("", "")
        เหตุ_เลือก = ("ไม่ได้เลือกเก็บ (มุมหนึ่งเก็บชื่อได้ชื่อเดียว · จดไว้ก่อนถ้าต้องใช้)", "ไม่ได้เลือกเก็บ")
        เหตุ_สิทธิ์ = ("บัญชีนี้แก้ชื่อหมุด (BND_NAME) ไม่ได้ — ตั้งชื่อให้หมุดตรงมุมไม่ได้ (จดชื่อไว้ก่อน)", "บัญชีแก้ชื่อหมุดไม่ได้")
        try:
            nf = self._addnode_name_field(point_lyr)
            ชื่อ_ได้ = nf is not None and self._col_ok(point_lyr, nf)       # ★ 2.3.7 DI-13 — ยืนยันไม่ได้ = แก้ไม่ได้
            แก้, หาย, เหตุ = [], [], []

            def _หาย(x, why):
                if x and _name_key(x) not in {_name_key(y) for y in หาย}:
                    หาย.append(x)
                    if why not in เหตุ:
                        เหตุ.append(why)
            for x in dict.fromkeys(หายก่อน):
                _หาย(x, เหตุ_เลือก)
            if หายล็อก:                       # ★ 2.4.0 (review DU-01-followup)
                เหตุ_ล็อก = ("หมุดตรงมุมนั้นเป็นหมุด L1 (ชั้นอ้างอิงพิกัดหลัก) ซึ่งถูกล็อก — "
                            + self._l1_hint("ยกชื่อให้ไม่ได้") + " (จดชื่อไว้ก่อน)", "หมุดตรงมุมเป็นหมุด L1 ที่ล็อก")
                for x in dict.fromkeys(หายล็อก):
                    _หาย(x, เหตุ_ล็อก)
            รายการ = []
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(ผู้รับ or [])))
            try:
                for f in (_it if ผู้รับ else []):
                    ชื่อ = _txt(f[nf]) if nf is not None else ""
                    g = f.geometry()
                    รายการ.append((f.id(), ชื่อ, self._name_cand(f, ชื่อ, "   ·   หมุดของแปลงนี้ตรงมุม (เก็บไว้)"),
                                   QgsPointXY(g.asPoint()) if g is not None and not g.isEmpty() else None))
            finally:
                _it.close()
            รายการ.sort(key=lambda r: r[0])
            for fid, ชื่อ, ตัวเอง, xy in รายการ:
                ls = [c for c in ผู้รับ.get(fid, []) if c.get("nm")]
                if not ls:
                    continue                      # หมุดค้างไม่มีชื่อ ⇒ ไม่มีชื่อให้เก็บ
                if not ชื่อ_ได้:
                    for c in ls:
                        if _name_key(c["nm"]) != _name_key(ชื่อ):
                            _หาย(c["nm"], เหตุ_สิทธิ์)
                    continue
                ผู้สมัคร = ([ตัวเอง] if ชื่อ else []) + ls
                # ตั้งต้น = กติกาหมุดซ้อน 7 ก.ย. (แบบลบ Node): ชื่อจริงก่อน ชร — ชื่อจริงของผู้รับก่อน แล้วชื่อจริงของหมุดค้าง (ใกล้ก่อน)
                #   (เดิมผู้รับคงชื่อตัวเองเสมอแม้เป็น ชร เพราะชื่อจริงไปอยู่ใน ALT_NAME — ตอนนี้ไม่มีที่เก็บแล้ว)
                ตั้งต้น = next((c["nm"] for c in ผู้สมัคร if not _is_chor(c["nm"])), ผู้สมัคร[0]["nm"])
                if len({_name_key(c["nm"]) for c in ผู้สมัคร}) <= 1:
                    เลือก = ตั้งต้น
                else:
                    เลือก = self._name_choice(
                        ผู้สมัคร, ตั้งต้น, f"{title} — เลือกชื่อหมุด",
                        (f"หมุดของแปลงนี้ตรงมุม {xy.x():,.3f}, {xy.y():,.3f} (gid {fid})" if xy is not None
                         else f"หมุดของแปลงนี้ gid {fid}")
                        + " กับหมุดค้างที่จะลบ (มุมเดิมของมันถูกย้าย/หักมาที่นี่) ชื่อไม่ตรงกัน\n"
                        "และวันที่ (SURV_DATE / ISSUE_DATE) ตัดสินไม่ได้ ⇒ เลือกชื่อที่จะเก็บไว้กับหมุดตรงมุมนี้\n"
                        "(ชื่ออื่นหายไปกับหมุดค้าง — กล่องยืนยันบอกอีกครั้ง)\nCancel = ยกเลิก ไม่หัก", เสมอ=False)
                    if เลือก is None:
                        return False
                if _name_key(เลือก) != _name_key(ชื่อ):
                    แก้.append((fid, ชื่อ, เลือก))     # ชื่อเดิมของผู้รับ (ถ้ามี) หาย — บรรทัดตั้งชื่อในกล่องบอกก่อน (ชร ห้ามหายเงียบ)
                for c in ls:
                    if _name_key(c["nm"]) != _name_key(เลือก):
                        _หาย(c["nm"], เหตุ_เลือก)
            return แก้, หาย, ((" · ".join(x[0] for x in เหตุ), " · ".join(x[1] for x in เหตุ)) if หาย else ("", ""))
        except Exception as e:
            QgsMessageLog.logMessage("_donut_heir_plan: อ่านชั้นหมุดไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            return None

    def _donut_add_markers(self, poly_lyr, point_lyr, outer, แผน):
        """★ 2.3.6 — ใส่หมุดของแปลงคงเหลือตามแผน (ระวาง/Type จากแปลงคงเหลือ · ชื่อยืมจากหมุดที่คลิก)
        `EDIT_SRC='donut'` (ใคร/เมื่อไหร่ ให้ trigger `tag_added_point()` เขียนเหมือน Add Node) · คืน (สำเร็จ, ล้ม)
        ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค.) — ชื่อเดียวตามแผน · ไม่เขียน ALT_NAME (สงวนไว้ให้ pipeline)"""
        flds = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO", "UTM"]
        name_field = self._addnode_name_field(point_lyr)
        _si = _fld_idx(point_lyr.fields(), "EDIT_SRC")
        # ★ rc2 (audit A2-03) — Type ผ่าน _marker_type_from_parcel (ปรับรูปแบบ · แปลง CT-RTK ⇒ ไม่ตั้ง) แบบเดียวกับ Add Node
        _tpi, _tqi = _fld_idx(point_lyr.fields(), "Type"), _fld_idx(poly_lyr.fields(), "Type")
        _mt = _marker_type_from_parcel(outer.attribute(_tqi)) if (_tpi >= 0 and _tqi >= 0) else None
        n = fail = 0
        for xy, ชื่อ, *_ in แผน:
            nf = QgsFeature(point_lyr.fields())
            nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(xy)))
            for fld in flds:
                pi = _fld_idx(point_lyr.fields(), fld)
                qi = _fld_idx(poly_lyr.fields(), fld)
                if pi >= 0 and qi >= 0:
                    nf.setAttribute(pi, outer.attribute(qi))
            if _mt:
                nf.setAttribute(_tpi, _mt)
            if name_field is not None and ชื่อ:
                nf.setAttribute(point_lyr.fields().indexOf(name_field), ชื่อ)
            if _si >= 0:
                nf.setAttribute(_si, "donut")
            if point_lyr.addFeature(nf):
                n += 1
            else:
                fail += 1
        return n, fail
