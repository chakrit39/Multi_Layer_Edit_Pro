# -*- coding: utf-8 -*-
"""ล็อกแปลงอ้างอิง L1 (L1-RTK / L1-TS) และหมุดของแปลงเหล่านั้น

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import time
from qgis.PyQt import QtWidgets
from qgis.core import Qgis, QgsExpression, QgsFeatureRequest, QgsMessageLog, QgsRectangle
from ..core.util import _is_l1, _LockScanError, _norm_utm, _scrub, _txt, _UTM_FIELD_NAMES
from ..lock_rules import L1_TYPES, marker_lock_type


class LocksMixin:
    """ล็อกแปลงอ้างอิง L1 (L1-RTK / L1-TS) และหมุดของแปลงเหล่านั้น"""

    def _is_point_on_rtk_node(self, poly_lyr, point_xy):
        """ตรวจสอบว่าพิกัด point_xy อยู่บน Node ของแปลงประเภท L1-RTK หรือไม่"""
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        if type_idx == -1:
            return False

        # สี่เหลี่ยมตรงๆ (เลี่ยง buffer() ที่สร้าง geometry วงกลมทิ้ง)
        search_rect = QgsRectangle(point_xy.x() - 0.05, point_xy.y() - 0.05,
                                   point_xy.x() + 0.05, point_xy.y() + 0.05)
        # ดึง geometry มาในคิวรีเดียว (เดิม query แบบ NoGeometry แล้วค่อย getFeature ซ้ำต่อ candidate)
        req = QgsFeatureRequest().setFilterRect(search_rect).setSubsetOfAttributes([type_idx])
        _fit3291 = poly_lyr.getFeatures(req)
        try:
            for feat in _fit3291:
                val = feat.attribute(type_idx)
                if val is not None and str(val).strip().upper() == "L1-RTK":
                    geom = feat.geometry()
                    if geom and not geom.isNull():
                        _cp, vertex_idx, _pi, _ni, sqr_dist = geom.closestVertex(point_xy)
                        if sqr_dist < 0.0025:  # 0.05 ** 2
                            return True
        finally:
            _fit3291.close()
        return False

    def _locked_utm_map(self, poly_lyr):
        """ดึงค่า UTM ของแปลงล็อก (L1-RTK/L1-TS) ทั้งเลเยอร์ใน "คิวรีเดียว" -> dict {utm: type}
        filter ฝั่ง server + NoGeometry — แทนการยิง query เทียบ UTM ต่อหมุด/ต่อค่า
        (บน PostgreSQL เดิมคือ 1 round-trip ต่อค่า UTM ที่ไม่ซ้ำ → เหลือ 1 ครั้งต่อ operation)
        ถ้า UTM เดียวกันมีทั้ง L1-RTK และ L1-TS จะเก็บ L1-RTK (เข้มกว่า)

        CACHE ต่อ edit-session: คิวรีนี้ดึงแปลงล็อก "ทั้งอำเภอ" (ปทุม 90,691 / คลองหลวง 69,284 แถว) และถูกเรียกใหม่
        ทุก gesture — ทุกครั้งที่ลากกล่อง Move Node, ทุก commit Move/Rotate/Scale, ทุก commit Align — บน PostgreSQL
        คือ scan ตารางใหญ่ + ส่งข้ามเน็ตซ้ำๆ. ตาราง UTM ล็อกจะเปลี่ยนได้ก็ต่อเมื่อคอลัมน์ Type/UTM เปลี่ยน ซึ่ง
        พนักงานไม่มีสิทธิ์แก้ (GRANT UPDATE เฉพาะ geom/SCORE/REMARK/cluster_id) -> ดึงครั้งเดียวแล้วใช้ต่อ
        ★ rc2 (audit A4-10 + ผู้ตรวจทานพบเพิ่ม) — เดิม docstring บอก "ล้าง cache เมื่อ commit/rollback/เปิดแก้ใหม่" ซึ่งไม่จริง
          (edits.py ตั้งใจไม่ล้าง — แก้ค้าง ~1 วิหลังทุก Save เมื่อ 4 ส.ค.) · ที่ล้างจริง: คอลัมน์เปลี่ยน (on_fields) · บันทึกงานที่แก้
          Type/UTM ของแปลง หรือเพิ่มแปลง L1 (ทุกทาง รวมตาราง attribute ของผู้ดูแล — on_commit) · 🏷/📝 · ทิ้งงานที่มีคิว Type ·
          ปิดแผง (_clear_caches) · ฝั่งฐานถูกแก้โดยคนอื่น/งานฐานระหว่างวัน: อายุเกิน _LOCK_TTL_S ⇒ อ่านใหม่เบื้องหลัง (_locked_refresh_bg
          · QgsTask · ไม่ค้างหน้าจอ) ระหว่างนั้นใช้ตารางเดิม"""
        _lid = poly_lyr.id() if poly_lyr else None
        # ★ 1 ก.ย. 69 — ต้องเทียบ "ตัววัตถุ" ด้วย ไม่ใช่แค่ layer id
        #   เปิดโปรเจกต์เดิมซ้ำในเซสชันเดียว QGIS ให้ layer id เดิมแต่เป็นวัตถุใหม่
        #   (โรคเดียวกับที่แก้ใน _watch_layer_editing เมื่อ 31 ส.ค.)
        #   ถ้าเทียบแค่ id -> cache แปลงล็อก L1 ของรอบก่อนถูกใช้ต่อแบบเงียบ ๆ
        #   เช่นแอดมินเพิ่งปรับ L1 -> L2-TS ระหว่างวัน ปลั๊กอินจะยังล็อกแปลงนั้นอยู่ทั้งเซสชัน
        # ★ 2.3.7 (review LC-02) — เดิม id() ของ wrapper (ไม่คงที่ ⇒ wrapper ใหม่ของเลเยอร์เดิม = สแกน L1 ~1 วิ ซ้ำ)
        #   ⇒ เครื่องหมายบนวัตถุ C++ เอง: เลเยอร์เดิม = ค่าเดิมเสมอ · วัตถุใหม่ (เปิดโปรเจกต์เดิมซ้ำ) = ค่าใหม่
        _obj = self._layer_token(poly_lyr) if poly_lyr else None
        _c = getattr(self, "_locked_cache", None)
        if _c is not None and _c.get("lid") == _lid and _c.get("obj") == _obj:
            # ★ 2.3.7 (review ER-05) — ผลว่างบน PostGIS จำไว้แค่ 60 วินาที (อาจเป็นสแกนที่ล้มแบบไม่บอก)
            if _c["map"] or _c.get("until") is None or time.monotonic() < _c["until"]:
                try:
                    self._locked_refresh_bg(poly_lyr, _c)      # ★ rc2 (audit A4-10) อายุเกิน ⇒ อ่านใหม่เบื้องหลัง
                except Exception:
                    pass
                return _c["map"]
        utm_field = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        type_field = self._resolve_field(poly_lyr, {'type'})
        if not utm_field or not type_field:
            return {}
        fields = poly_lyr.fields()
        u_idx = fields.indexFromName(utm_field)
        t_idx = fields.indexFromName(type_field)
        expr = (f"upper(trim({QgsExpression.quotedColumnRef(type_field)})) "
                f"IN ({','.join(QgsExpression.quotedValue(t) for t in L1_TYPES)})")   # ★ 2.4.0 (DU-01) จาก lock_rules
        req = (QgsFeatureRequest().setFilterExpression(expr)
               .setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([u_idx, t_idx]))
        locked = {}
        # ★ 2.3.7 (review PF-01) — provider PostGIS ล้มกลางทาง "ไม่ raise" แต่คืนแถวน้อยลง/ไม่คืนเลย + เขียน log
        #   เดิมได้ map ว่างแล้ว cache ทั้ง session ⇒ ผู้เรียกทุกตัวถือว่า "ไม่มีแปลงล็อก" ⇒ Score/ย้ายหมุด L1 ได้เงียบ ๆ
        #   ⇒ ฟัง log ของ provider ระหว่างสแกน + ตรวจตัวอ่าน · ล้ม = ไม่ cache + โยน _LockScanError ให้ผู้เรียกหยุด
        _errs = []

        def _on_log(message, tag, level):
            try:
                if str(tag) in ("PostGIS", "PostgreSQL") and int(level) >= int(Qgis.Warning):
                    _errs.append(str(message))
            except Exception:
                pass
        _mlog = None
        try:
            from qgis.core import QgsApplication
            _mlog = QgsApplication.messageLog()
            _mlog.messageReceived.connect(_on_log)
        except Exception:
            _mlog = None
        _bz = self._busy("l1-scan").begin()     # ★ 2.3.7 (review PF-03) สแกนแปลง L1 ทั้งสาขา (~1 วิ บน PostGIS)
        try:
            _it = poly_lyr.getFeatures(req)
            try:
                if hasattr(_it, "isValid") and not _it.isValid():
                    raise RuntimeError("ตัวอ่านข้อมูลใช้ไม่ได้ (iterator invalid)")
                for f in _it:
                    u, t = f.attribute(u_idx), f.attribute(t_idx)
                    if not _txt(u) or not _txt(t):
                        continue
                    key = _norm_utm(u)
                    t_str = _txt(t).upper()
                    if t_str == "L1-RTK" or key not in locked:
                        locked[key] = t_str
            finally:
                _it.close()
        except Exception as e:
            _errs.append(str(e))
        finally:
            _bz.end()
            if _mlog is not None:
                try:
                    _mlog.messageReceived.disconnect(_on_log)
                except Exception:
                    pass
        if _errs:
            try:
                QgsMessageLog.logMessage("_locked_utm_map: สแกนแปลง L1 ไม่สำเร็จ — " + _scrub(_errs[0])[:300],
                                         "MLEP", Qgis.Warning)
            except Exception:
                pass
            raise _LockScanError(_errs[0])
        _until = None
        if not locked:
            try:
                if poly_lyr.dataProvider().name() == "postgres":
                    _until = time.monotonic() + 60.0
            except Exception:
                pass
        self._locked_cache = {"lid": _lid, "obj": _obj, "map": locked, "until": _until,   # ใช้ซ้ำทั้ง session
                              "t0": time.monotonic()}             # ★ rc2 (audit A4-10) อายุของตาราง (_LOCK_TTL_S)
        self._watch_layer_editing(poly_lyr)                 # ให้แน่ใจว่ามี signal มาล้าง cache
        return locked

    def _locked_refresh_bg(self, poly_lyr, c):
        """★ rc2 (audit A4-10) — ตาราง UTM ล็อกอายุเกิน _LOCK_TTL_S ⇒ อ่านใหม่ใน QgsTask (เธรดของ QGIS · QgsVectorLayerFeatureSource
        สร้างบนเธรดหลัก ใช้อ่านจากเธรดอื่นได้ตามแบบของ QGIS) แล้วสลับตารางเมื่อเสร็จ — ไม่สแกนบนเธรดหลัก (กันค้าง ~1 วิ แบบก่อน 4 ส.ค.)
        ไม่ทำ: กำลังอ่านอยู่ · buffer มีงานที่เปลี่ยนตาราง (Type/UTM · ลบ/เพิ่มแปลง — ตารางที่อ่านผ่าน buffer ไม่ควรค้างทั้งวัน)
        ผลถูกทิ้งเมื่อ: ล้ม/ยกเลิก · ตารางเดิมถูกล้าง/แทนระหว่างอ่าน · ได้แถวน้อยกว่า 90% ของเดิม (อาจเป็นการอ่านที่ขาดกลางทาง
        ซึ่งทำให้ล็อกหาย = ทางไม่ปลอดภัย) — ทิ้งแล้วลองใหม่เมื่อครบอายุอีกรอบ"""
        t0 = c.get("t0")
        if t0 is None or time.monotonic() - t0 < float(self._LOCK_TTL_S):
            return
        if getattr(self, "_locked_bg_task", None) is not None or not getattr(self, "_alive", True):
            return
        eb = poly_lyr.editBuffer() if poly_lyr.isEditable() else None
        fields = poly_lyr.fields()
        utm_field = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        type_field = self._resolve_field(poly_lyr, {'type'})
        if not utm_field or not type_field:
            return
        u_idx, t_idx = fields.indexFromName(utm_field), fields.indexFromName(type_field)
        if eb is not None and (eb.deletedFeatureIds() or eb.addedFeatures()
                               or any({u_idx, t_idx} & set(a) for a in eb.changedAttributeValues().values())):
            return
        from qgis.core import QgsApplication, QgsTask, QgsVectorLayerFeatureSource
        expr = (f"upper(trim({QgsExpression.quotedColumnRef(type_field)})) "
                f"IN ({','.join(QgsExpression.quotedValue(t) for t in L1_TYPES)})")
        req = (QgsFeatureRequest().setFilterExpression(expr)
               .setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([u_idx, t_idx]))
        src = QgsVectorLayerFeatureSource(poly_lyr)
        n_old = len(c.get("map") or {})

        def _run(task):
            out = {}
            it = src.getFeatures(req)
            try:
                for f in it:
                    if task.isCanceled():
                        return None
                    u, t = f.attribute(u_idx), f.attribute(t_idx)
                    if not _txt(u) or not _txt(t):
                        continue
                    key = _norm_utm(u)
                    t_str = _txt(t).upper()
                    if t_str == "L1-RTK" or key not in out:
                        out[key] = t_str
            finally:
                it.close()
            return out

        def _done(exc, result=None):
            self._locked_bg_task = None
            c["t0"] = time.monotonic()                  # ล้ม/ทิ้งผล ⇒ ลองใหม่เมื่อครบอายุอีกรอบ (ไม่ถี่)
            if not getattr(self, "_alive", True):
                return
            if exc is not None or result is None:
                try:
                    QgsMessageLog.logMessage("อ่านรายการแปลง L1 ใหม่เบื้องหลังไม่สำเร็จ — ใช้ตารางเดิมต่อ"
                                             + (": " + _scrub(exc)[:200] if exc is not None else ""), "MLEP", Qgis.Info)
                except Exception:
                    pass
                return
            if getattr(self, "_locked_cache", None) is not c:
                return                                  # ตารางถูกล้าง/แทนระหว่างอ่าน ⇒ ของใหม่กว่าอยู่แล้ว
            if n_old and len(result) < 0.9 * n_old:
                try:
                    QgsMessageLog.logMessage("อ่านรายการแปลง L1 ใหม่ได้ %d แถว (เดิม %d) — น้อยผิดปกติ ใช้ตารางเดิมต่อ"
                                             % (len(result), n_old), "MLEP", Qgis.Warning)
                except Exception:
                    pass
                return
            self._locked_cache = dict(c, map=result, t0=time.monotonic(), until=None)

        try:
            _fl = QgsTask.CanCancel | getattr(QgsTask, "Hidden", 0)
        except Exception:
            _fl = QgsTask.CanCancel
        task = QgsTask.fromFunction("MLEP: อ่านรายการแปลง L1", _run, on_finished=_done, flags=_fl)
        self._locked_bg_task = task
        QgsApplication.taskManager().addTask(task)

    def _locked_map_or_block(self, poly_lyr, title):
        """★ 2.3.7 (review PF-01) — ตาราง UTM ของแปลง L1 แบบ fail-closed สำหรับผู้เรียกทุกตัว
        สแกนไม่สำเร็จ ⇒ แจ้ง + คืน None (ผู้เรียกต้องหยุดงาน) · ปลดล็อก L1 อยู่ ⇒ คืน {} (ไม่บังคับล็อกอยู่แล้ว ไม่ต้องสแกน)"""
        if self._l1_unlocked():
            return {}
        try:
            return self._locked_utm_map(poly_lyr)
        except _LockScanError:
            try:
                self.iface.messageBar().pushMessage(
                    title, "ตรวจสถานะล็อกแปลง L1 ไม่ได้ (อ่านฐานข้อมูลไม่สำเร็จ) — ยังไม่ได้ทำอะไร ลองใหม่อีกครั้ง",
                    level=2, duration=10)
            except Exception:
                pass
            return None

    def _l1_unlocked(self):
        """★ 2.4.0 (review DU-01) — ผู้ดูแลกดปลดล็อก L1 อยู่ไหม = ทางเดียวที่ข้ามกติกาล็อก L1"""
        return bool(getattr(self, "_admin_unlock_l1", False))

    def _marker_locked(self, point_f, locked_map, utm_field=None, type_idx=None):
        """★ 2.4.0 (review DU-01) — ตัวตัดสิน "หมุดนี้ล็อก L1 ไหม" ตัวเดียวของปลั๊กอิน -> (ล็อกไหม, ชนิด L1 | None)
        ล็อก = Type ของตัวหมุดเองเป็น L1-RTK/L1-TS **หรือ** UTM ของหมุดตรงกับแปลง L1 (lock_rules.marker_lock_type)
        เดิมสองกติกา: Move/Score/Move Node/Align ดูแค่ UTM · แก้ชื่อ/ลบ/สลับ/ไฮไลต์หมุดซ้อน ดูแค่ Type ของหมุด
        ⇒ หมุด Type L1 ที่ UTM ว่าง/ไม่ตรงแปลง L1 ใด ยังถูกย้ายและใส่ Score ได้
        ทางข้ามมีทางเดียว: ผู้ดูแลกดปลดล็อก L1 (_l1_unlocked)
        locked_map = {utm: type} จาก _locked_utm_map / _locked_map_or_block (prefetch คิวรีเดียวต่อ operation) · {} = ดูแค่ Type
        utm_field / type_idx = ชื่อฟิลด์ UTM / index ฟิลด์ Type ของชั้นหมุดที่ resolve แล้ว (ผู้เรียกที่วนหลายหมุดส่งมา ไม่ต้องหาใหม่ทุกดวง)
        ⚠️ ฟีเจอร์ที่อ่านแบบ setSubsetOfAttributes ต้องขอคอลัมน์ Type ของชั้นหมุดมาด้วย (ไม่งั้นได้ NULL = ไม่ล็อกฝั่ง Type)"""
        if self._l1_unlocked():
            return False, None
        flds = None
        if type_idx is None or (locked_map and not utm_field):
            try:
                flds = point_f.fields()               # อ่าน fields() เฉพาะตอนผู้เรียกไม่ได้ resolve มาให้
            except Exception:
                flds = None
        if type_idx is None:
            type_idx = self._field_index(flds, 'type') if flds is not None else -1
        own = None
        if type_idx is not None and type_idx >= 0:
            try:
                own = point_f.attribute(type_idx)
            except Exception:
                own = None
        key = None
        if locked_map:
            # OPT (2026-08-07): ผู้เรียกที่วนหลายหมุดส่งชื่อฟิลด์ที่ resolve แล้วมาได้ (utm_field)
            uf = utm_field
            if not uf and flds is not None:
                uf = next((f.name() for f in flds if f.name().lower() in _UTM_FIELD_NAMES), None)
            if uf:
                try:
                    key = _norm_utm(point_f[uf])      # UTM ว่าง/NULL ⇒ ค่าตัวแทนที่ไม่ตรงกับแปลงใด
                except Exception:
                    key = None
        t = marker_lock_type(own, key, locked_map)
        return (True, t) if t else (False, None)

    def _is_point_feature_locked(self, point_f, locked_map, utm_field=None):
        """ตรวจสอบว่าหมุดนี้เชื่อมโยงกับแปลงที่ถูกล็อก (L1-RTK/L1-TS) ผ่านฟิลด์ UTM
        locked_map: dict {utm: type} จาก _locked_utm_map (prefetch คิวรีเดียวต่อ operation)
        ★ 2.4.0 (review DU-01) — คงชื่อไว้ให้โค้ดเดิม: ส่งต่อให้ _marker_locked (กติกาเดียว: Type ของหมุด หรือ UTM ตรงแปลง L1
          · ปลดล็อก L1 อยู่ = ไม่ล็อก) · ในปลั๊กอินไม่มีผู้เรียกแล้ว"""
        return self._marker_locked(point_f, locked_map, utm_field)

    def _l1_owner_names(self, poly_layer, utm_types, title):
        """★ 2.3.7 (review UX-06) — ชื่อแปลง L1 เจ้าของหมุด (ตาม UTM) สำหรับข้อความปฏิเสธ · คิวรีเดียว
        utm_types = {utm ที่ normalise แล้ว: ชนิด} · หาแปลงไม่เจอ ⇒ บอกด้วย UTM แทน"""
        keys = sorted(k for k in utm_types if _txt(k) and not str(k).startswith("\x00"))
        labels, found = [], set()
        uf = self._resolve_field(poly_layer, _UTM_FIELD_NAMES)
        if uf and keys:
            try:
                fl = poly_layer.fields()
                cols = self._sheet_cols(poly_layer)
                ui, ti = fl.indexOf(uf), self._field_index(fl, 'type')
                expr = (f"{QgsExpression.quotedColumnRef(uf)} IN "
                        f"({','.join(QgsExpression.quotedValue(k) for k in keys)})")
                req = (QgsFeatureRequest().setFilterExpression(expr).setFlags(QgsFeatureRequest.NoGeometry)
                       .setSubsetOfAttributes(sorted({i for i in cols + [ui, ti] if i != -1})))
                it = poly_layer.getFeatures(req)
                try:
                    for f in it:
                        k = _norm_utm(f.attribute(ui))
                        if k not in utm_types or (ti != -1 and not _is_l1(f.attribute(ti))):
                            continue
                        found.add(k)
                        labels.append(f"{self._sheet_of(f, cols, k)} ({utm_types[k]})")
                finally:
                    it.close()
            except Exception:
                pass
        labels += [f"UTM {k} ({utm_types[k]})" for k in keys if k not in found]
        return self._name_list(title, labels)

    def _l1_hint(self, ทำไม่ได้):
        """★ 2.3.7 (review UX-13) — ท้ายข้อความปฏิเสธแปลง/หมุด L1 ที่พนักงานทั่วไปเห็นได้
        พนักงานทั่วไปเข้าโหมดผู้ช่วย/ผู้ดูแลไม่ได้ และกติกาของเราเองคือไม่บอกว่ามีโหมดหรือวิธีเข้า (toggle_admin_mode เงียบ)
        ⇒ ถ้อยคำกลาง "<ทำไม่ได้> (แจ้งผู้ดูแล)" · อยู่ในโหมดแล้ว (`_admin_on` = ธงในเครื่อง ไม่ถามฐาน) ⇒ คงคำแนะนำที่ทำได้จริง
        (ผู้ดูแลกดปลดล็อกเองได้ · ผู้ช่วยผู้ดูแลปลดล็อกไม่ได้ — ปุ่มอยู่ในกล่อง ADMIN)"""
        if getattr(self, "_admin_on", False):
            if self._is_admin():
                return "%s จนกว่าจะกด 🔓 ปลดล็อก L1" % ทำไม่ได้
            return "%s (ปลดล็อก L1 ได้เฉพาะผู้ดูแล — แจ้งผู้ดูแล)" % ทำไม่ได้
        return "%s (แจ้งผู้ดูแล)" % ทำไม่ได้

    def _parcel_locked_block(self, info, title, ทำไม่ได้, fids=None):
        """★ 2.4.0 (review DU-01) — ด่านหมุดล็อกของเครื่องมือระดับแปลง (🗑 ลบแปลง · 🏷 เปลี่ยน Type · 🍩 · 📝 แก้ข้อมูลแปลง)
        เดิมด่านดูแค่ Type ของแปลง ⇒ หมุด Type L1 บนแปลง L2 ถูกลบ/ถูกเขียน Type ใหม่ได้ทั้งที่ L1 ยังล็อก
        (ขัดกติกา lock_rules: ทางข้ามมีทางเดียวคือผู้ดูแลกดปลดล็อก L1)
        info = ผลของ _parcel_markers · fids = นับเฉพาะหมุดชุดนี้ (None = ทุกดวงของแปลง)
        -> True = ปฏิเสธแล้ว (แจ้งแล้ว ผู้เรียกหยุด) · False = ผ่าน"""
        if self._l1_unlocked() or not info:
            return False
        lk = info.get("locked") or {}
        if fids is not None:
            _s = set(fids)
            lk = {k: v for k, v in lk.items() if k in _s}
        if not lk:
            return False
        tps = " / ".join(t for t in L1_TYPES if t in set(lk.values()))
        self._ask(QtWidgets.QMessageBox.Warning, title,
                  f"หมุดของแปลงนี้ {len(lk):,} ดวงเป็นหมุด {tps} (ชั้นอ้างอิงพิกัดหลัก) ซึ่งถูกล็อก\n"
                  + self._l1_hint(ทำไม่ได้))
        return True
