# -*- coding: utf-8 -*-
"""Align — ดึงหมุดเข้ามุมแปลง (เลือกกล่อง ไฮไลต์ และจัดแนว)

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import math
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import (Qgis, QgsCoordinateTransform, QgsFeatureRequest, QgsGeometry, QgsMessageLog,
                       QgsPointLocator, QgsPointXY, QgsProject, QgsRectangle, QgsSpatialIndex, QgsWkbTypes)
from qgis.gui import QgsRubberBand, QgsVertexMarker
from ..core.util import _log_exc, _norm_utm, _txt, _UTM_FIELD_NAMES
from ..lock_rules import L1_TYPES
from ..map_tools import BoxSelectTool
from ..ui.qt_helpers import _EmitClickTool


class AlignMixin:
    """Align — ดึงหมุดเข้ามุมแปลง (เลือกกล่อง ไฮไลต์ และจัดแนว)"""

    def start_align_tool(self):
        if not self._pair_key_ok("Align Points"):
            return
        self.cancel_transform()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            self._ask(QtWidgets.QMessageBox.Warning, "Align", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        # ★ ต้องมีชั้นแปลงด้วย (2026-08-06): เดิมบังคับแค่ชั้นหมุด -> ถ้าชั้นแปลงว่าง Align จะ
        #   "ย้ายหมุดอย่างเดียว" (PASS 2) โดยไม่เชื่อมมุมแปลง (PASS 3 ถูกข้าม) = แปลงกับหมุดหลุดคู่กัน
        #   และด่านล็อก L1 ซึ่งอิงชั้นแปลง ก็ถูกข้ามไปด้วย = ลากหมุดอ้างอิงได้
        _poly_chk = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not _poly_chk:
            self._ask(QtWidgets.QMessageBox.Warning, "Align",
                      "กรุณาเลือกเลเยอร์แปลง (Polygon) ด้วย\n"
                      "Align ต้องใช้ชั้นแปลงเพื่อเชื่อมมุมแปลงตามหมุด และเพื่อตรวจการล็อกแปลงอ้างอิง L1")
            return
        # ★ 2.3.7 (review DI-03) — ชั้นแปลง/หมุดคนละระบบพิกัด = ดึงมุมตามหมุดให้ตรงกันไม่ได้ ⇒ ไม่เริ่ม
        if not self._pair_crs_ok("Align Points", _poly_chk, point_lyr):
            return
        # ★ 2.3.7 (review DI-10) — ผูกคู่ชั้นตอนกดปุ่ม (ตรวจทุกกล่อง/ทุกคลิก/ตอนลงมือ)
        self._align_lids = (_poly_chk.id(), point_lyr.id())
        self.mode = 'align_box'
        self.canvas = self.iface.mapCanvas()
        self._align_max_par = None          # อ่าน QSettings ใหม่รอบนี้ (เผื่อผู้ใช้เพิ่งแก้ค่า)
        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.setup_snapping()   # ★ 2 ก.ย. 69 — เหตุผลเดียวกับ Add Node
        self.temp_tool = BoxSelectTool(self.iface.mapCanvas(), self._align_add_box,
                                       self.finish_align_selection, self._align_cancel)
        self._align_tool = self.temp_tool      # ★ 2.3.7 (LC-04) เครื่องมือของ Align ตัวปัจจุบัน (ดู _map_tool_changed)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", "ลากกล่องครอบหมุด (ครอบหลายรอบได้ • Ctrl+ลาก = เอาออก) แล้วคลิกขวาเพื่อเลือกเสร็จ")
        self._crs_info("Align", point_lyr)                    # ★ 2.3.7 (b9) แผนที่คนละระบบพิกัดกับชั้น = บอกเบา ๆ ครั้งเดียว

    def _align_add_box(self, rect_map, remove):
        # ★ 2.3.7 (review DI-10) — คู่ชั้นต้องเป็นคู่เดียวกับตอนกดปุ่ม Align
        _pair = self._bound_pair_now("_align_lids", "Align Points")
        if _pair is None:
            return
        point_lyr = _pair[1]
        if not point_lyr:
            return
        proj = QgsProject.instance()
        rect_lyr = rect_map
        # ★ 2.3.7 (review DI-03) — กรอบที่ลากอยู่ในพิกัดของแผนที่ (แคนวาส) · แปลงไม่ได้ = ไม่เลือก
        #   (เดิมใช้กรอบดิบต่อ = เลือกผิดที่/ไม่ได้อะไรเงียบ ๆ)
        _mc = self._map_crs()
        if _mc is not None and point_lyr.crs().isValid() and point_lyr.crs() != _mc:
            try:
                rect_lyr = QgsCoordinateTransform(_mc, point_lyr.crs(), proj).transformBoundingBox(rect_map)
            except Exception:
                self.iface.messageBar().pushMessage(
                    "Align", "แปลงกรอบที่ลากเป็นพิกัดของชั้นหมุดไม่ได้ — ไม่ได้เลือกเพิ่ม (ตรวจระบบพิกัดของโปรเจกต์)",
                    level=2, duration=6)       # ★ 2.3.7 b19 (doc-verify E9) — ทางเดียวกับจุดคลิกของ Align (แดงอยู่แล้ว)
                return
        ids = set(getattr(self, "_align_picked_ids", set()))
        req = QgsFeatureRequest().setFilterRect(rect_lyr).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            ids.discard(f.id()) if remove else ids.add(f.id())
        # ★ เพดานจำนวนหมุด (2026-08-06) — เท่ากับ Move Node ที่จำกัด 800 ไว้ตั้งแต่ 1.9.5 "กันเครื่องค้าง"
        #   เดิม Align ไม่มีเพดาน: ครอบกว้าง ๆ ที = สร้าง QgsVertexMarker เท่าจำนวนหมุด + วนงานหนักทุก pass
        if not remove and len(ids) > self.ALIGN_MAX_PICK:
            self.iface.messageBar().pushMessage(
                "Align", f"เลือกได้สูงสุด {self.ALIGN_MAX_PICK:,} จุด (กล่องนี้ทำให้เกิน {len(ids):,}) "
                         "— ยกเลิกกล่องล่าสุด ลองครอบให้แคบลง", level=1, duration=8)     # ★ 2.3.7 UX-35 แดง→เหลือง (เท่า Move Node)
            return
        self._align_picked_ids = ids
        self._align_refresh_highlight()
        self.iface.messageBar().pushInfo("Align", f"เลือกหมุด {len(ids)} จุด (คลิกขวา = เสร็จ)")

    def _align_refresh_highlight(self):
        self._align_clear_highlight()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        ids = getattr(self, "_align_picked_ids", None)
        if not point_lyr or not ids:
            return
        proj = QgsProject.instance()
        xform = None
        _mc = self._map_crs()              # ★ 2.3.7 (DI-03) ระบบพิกัดของแผนที่จริง (แคนวาส)
        if _mc is not None and point_lyr.crs().isValid() and point_lyr.crs() != _mc:
            try:
                xform = QgsCoordinateTransform(point_lyr.crs(), _mc, proj)
            except Exception:
                xform = None
        self._align_markers = []
        req = QgsFeatureRequest().setFilterFids(list(ids)).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            xy = f.geometry().asPoint()
            if xform is not None:
                try:
                    xy = xform.transform(xy)
                except Exception:
                    pass
            mk = QgsVertexMarker(self.iface.mapCanvas())
            mk.setCenter(QgsPointXY(xy))
            mk.setColor(QtGui.QColor(0, 120, 255))
            mk.setIconType(QgsVertexMarker.ICON_BOX)
            mk.setPenWidth(3)
            mk.setIconSize(10)
            self._align_markers.append(mk)

    def _align_clear_highlight(self):
        for mk in getattr(self, "_align_markers", []):
            try:
                self.iface.mapCanvas().scene().removeItem(mk)
            except Exception:
                pass
        self._align_markers = []

    def _align_cancel(self):
        """ยกเลิกโหมด Align (Esc) แล้วรีเซ็ต
        ★ 2.3.7 (review UX-01) — เดิมล้างทั้งแถบข้อความ (clearWidgets) รวมคำเตือนที่ตั้งใจให้ค้างของงานอื่น
          (เช่น '⚠️ มุมแปลงไม่มีหมุด' หลังบันทึก) ⇒ ไม่ล้างแล้ว (คำแนะนำของ Align หมดเวลาเองใน ~5 วินาที)"""
        self.cancel_transform()

    def finish_align_selection(self):
        """คลิกขวา = จบการเลือกหมุด -> เข้าโหมดลากเส้น 2 จุด (หมุดที่เลือกจะวิ่งไปหาเส้นที่ลาก
        หมุด/มุมที่ไม่ได้เลือกอยู่กับที่ -> แปลงยังต่อกับของเดิม)"""
        if not getattr(self, "_align_picked_ids", None):
            self.iface.messageBar().pushMessage("Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน", level=1, duration=6)
            return
        # ★ 2.3.7 (review DI-10) — คู่ชั้นต้องเป็นคู่เดียวกับตอนกดปุ่ม Align
        if self._bound_pair_now("_align_lids", "Align Points") is None:
            return
        self.mode = 'align_point_driven'
        self.src_pts = []
        self.setup_snapping()
        # ★ 2.3.7 (review UX-02 / LC-04) — เดิมเป็น QgsMapToolEmitPoint เปล่า: ข้อความบอก "Esc = ยกเลิก" แต่ไม่มีใครรับ Esc
        #   และคลิกขวา = ยกเลิกทั้งหมด (หมุดที่เลือกด้วยกล่องหาย) ขัดกับขั้น ① ที่คลิกขวา = เสร็จ
        #   ⇒ Esc = ยกเลิก Align · คลิกขวา/Backspace = ล้างจุดของเส้น (ยังไม่มีจุด = กลับไปเลือกหมุดต่อ)
        self.temp_tool = _EmitClickTool(self.canvas, self._align_key)
        self._align_tool = self.temp_tool
        self.temp_tool.canvasClicked.connect(self.handle_align_click)
        self.temp_tool.canvasMoveEvent = self.handle_align_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", f"เลือกหมุด {len(self._align_picked_ids)} จุด → คลิก 2 จุดสร้างเส้นแนว "
                     "(คลิกขวา = ล้างเส้น/กลับไปเลือกหมุด · Esc = ยกเลิก)")

    def _align_key(self, what):
        """★ 2.3.7 (review UX-02) — คีย์ของ Align ขั้น ②: Esc = ยกเลิก Align · Backspace/Delete = ล้างจุดของเส้น"""
        if what == "esc":
            self._align_cancel()
        else:
            self._align_clear_line()

    def _align_clear_line(self):
        """ล้างเฉพาะจุดของเส้นที่คลิกค้าง (หมุดที่เลือกด้วยกล่องยังอยู่) · ★ 2.3.7 (LC-04) รวมสี่เหลี่ยม snap ที่ค้าง"""
        self.src_pts = []
        self.clear_markers()
        self.clear_rubber_band()
        _si = getattr(self, "snap_indicator", None)
        if _si is not None:
            try:
                _si.setMatch(QgsPointLocator.Match())
            except Exception:
                pass

    def _align_back_to_box(self):
        """★ 2.3.7 (review UX-02) — กลับไปขั้น ① (ลากกล่องเลือกเพิ่ม/เอาออก) โดยไม่ทิ้งหมุดที่เลือกไว้"""
        self._align_clear_line()
        if self._bound_pair_now("_align_lids", "Align Points") is None:
            return
        self.mode = 'align_box'
        tool = BoxSelectTool(self.iface.mapCanvas(), self._align_add_box,
                             self.finish_align_selection, self._align_cancel)
        tool.setProperty("_mlep_tool", True)       # ป้ายเครื่องมือของ MLEP (LC-03c)
        self.temp_tool = tool
        self._align_tool = tool
        self.iface.mapCanvas().setMapTool(tool)
        self.iface.messageBar().pushInfo(
            "Align", f"กลับไปเลือกหมุด (เลือกไว้ {len(getattr(self, '_align_picked_ids', None) or ())} จุด) — "
                     "ลากกล่องเพิ่ม • Ctrl+ลาก = เอาออก • คลิกขวา = เลือกเสร็จ • Esc = ยกเลิก")

    def handle_align_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือ Align (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
        # แก้จาก self.snapping_utils เป็น self.snap_utils
        if not hasattr(self, 'snap_utils'):
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # Logic สำหรับวาด Rubber Band เส้นยางยืด (ถ้ามี)
        if hasattr(self, 'rubber_band') and self.rubber_band and len(self.src_pts) == 1:
            curr_pt = match.point() if match.isValid() else event.mapPoint()
            self.rubber_band.removeLastPoint()
            self.rubber_band.addPoint(curr_pt)
            
    def handle_align_click(self, point, button):
        """จัดการการคลิกจุด P1 และ P2 สำหรับสร้างแนวเส้น (รองรับที่ว่าง)"""
        if button == QtCore.Qt.RightButton:
            # ★ 2.3.7 (review UX-02) — เดิมคลิกขวา = cancel_transform (หมุดที่เลือกด้วยกล่องหายหมด)
            #   ⇒ มีจุดของเส้นค้าง = ล้างเฉพาะเส้น · ยังไม่มีจุด = กลับไปขั้น ① โดยไม่ทิ้งหมุดที่เลือก · ยกเลิกทั้งหมด = Esc
            if self.src_pts:
                self._align_clear_line()
                self.iface.messageBar().pushInfo(
                    "Align", "ล้างจุดของเส้นแล้ว — คลิก 2 จุดใหม่ (คลิกขวาอีกครั้ง = กลับไปเลือกหมุด · Esc = ยกเลิก)")
            else:
                self._align_back_to_box()
            return
        # ★ 2.3.7 (review DI-10) — คู่ชั้นต้องเป็นคู่เดียวกับตอนกดปุ่ม Align
        _pair = self._bound_pair_now("_align_lids", "Align Points")
        if _pair is None or _pair[1] is None:
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        # 2. ถ้า Snap ไม่ติด ให้ใช้พิกัดที่คลิกจริง (point)
        pt = match.point() if match.isValid() else point
        # ★ 2.3.7 (review DI-03) — จุดบนแผนที่ → พิกัดของชั้นหมุด "ตอนคลิก" (เส้นแนวคำนวณกับพิกัดหมุดตรง ๆ)
        try:
            lp = self._map_to_layer(pt, _pair[1])
        except Exception:
            self._align_clear_line()
            self.iface.messageBar().pushMessage(
                "Align", "แปลงพิกัดจุดที่คลิกเป็นระบบพิกัดของชั้นหมุดไม่ได้ — ยังไม่ได้แก้อะไร "
                         "(ตรวจระบบพิกัดของโปรเจกต์/ชั้น)", level=2, duration=10)
            return
        # ★ 2.3.7 (review DI-24 / UX-02) — จุดที่ 2 ทับ/ชิดจุดที่ 1 ⇒ ไม่รับจุดนี้ ให้คลิกใหม่ (เดิมเงียบ)
        _bad = self._check_control_points('align', list(self.src_pts) + [lp], _pair[1])
        if _bad:
            self.iface.messageBar().pushMessage("Align", _bad, level=1, duration=6)
            return
        
        self.src_pts.append(lp)                # ★ 2.3.7 (DI-03) พิกัดของชั้นหมุด (เดิม = พิกัดแผนที่)
        
        # วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        m.setPenWidth(5)
        self.markers.append(m)
        
        if len(self.src_pts) == 1:
            self.clear_rubber_band()
            self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            self.rubber_band.setColor(QtGui.QColor(255, 0, 0))
            self.rubber_band.setWidth(2)
            self.rubber_band.addPoint(pt)
            self.rubber_band.addPoint(pt)

        if len(self.src_pts) == 2:
            # ★ 2.3.7 (review AR-02-D) — ล้มด้วย exception ก่อนเข้า try ของตัวทำงาน (อ่าน QSettings/prefetch/สแกน)
            #   เดิม src_pts ค้าง 2 จุด ⇒ ทุกคลิกเงียบจนกว่าจะคลิกขวา ⇒ รีเซ็ตทุกทางออก + ลง Log
            _b0 = self._op_baseline
            try:
                self.execute_point_node_alignment()
            except Exception:
                import traceback
                QgsMessageLog.logMessage("Align ล้ม: " + traceback.format_exc(), "MLEP", Qgis.Critical)
                self.iface.messageBar().pushMessage(
                    "Align", "ทำงานไม่สำเร็จ (หยุดกลางคัน) — ถ้ามีส่วนที่เขียนไปแล้ว กด ↺ ย้อนกลับได้ "
                             "· รายละเอียดอยู่ในแผง Log Messages แท็บ MLEP", level=2, duration=0)
            finally:
                if self._op_baseline is not None and self._op_baseline is not _b0:
                    self._op_commit()
                # ทำความสะอาดหน้าจอหลังเสร็จงาน (★ 2.3.7 LC-04 รวมสี่เหลี่ยม snap ที่ค้าง)
                self._align_clear_line()
            
    def _prefetch_align_polys(self, poly_lyr, target_points, pad):
        """ดึงแปลงรอบหมุดที่เลือกทั้งหมดใน "คิวรีเดียว" + สร้าง spatial index ในหน่วยความจำ
        -> {'index': QgsSpatialIndex, 'geoms': {fid: QgsGeometry}, 'types': {fid: TYPE upper}}
        (เดิม _side_edge_dir และ weld PASS 3 ยิง query ต่อหมุด — บน PostgreSQL = N round-trips)"""
        rect = None
        for pt_f in target_points:
            g = pt_f.geometry()
            if g is None or g.isNull():
                continue
            p = g.asPoint()
            r = QgsRectangle(p.x() - pad, p.y() - pad, p.x() + pad, p.y() + pad)
            if rect is None:
                rect = QgsRectangle(r)
            else:
                rect.combineExtentWith(r)
        cache = {'index': QgsSpatialIndex(), 'geoms': {}, 'types': {}, 'utm': {}, 'rect': None}
        if rect is None:
            return cache
        cache['rect'] = QgsRectangle(rect)
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        # ★ ดึง UTM มาด้วย (2026-08-06) — PASS 3 ต้องใช้หา "หมุดของแปลงเพื่อนบ้าน" ที่ต้องย้ายตามมุม
        _uf = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        utm_idx = poly_lyr.fields().indexOf(_uf) if _uf else -1
        req = QgsFeatureRequest().setFilterRect(rect)
        req.setSubsetOfAttributes([i for i in (type_idx, utm_idx) if i != -1])
        for f in poly_lyr.getFeatures(req):
            g = f.geometry()
            if g is None or g.isNull():
                continue
            cache['geoms'][f.id()] = QgsGeometry(g)
            if type_idx != -1:
                v = f.attribute(type_idx)
                cache['types'][f.id()] = "" if v is None else str(v).strip().upper()
            if utm_idx != -1:
                u = f.attribute(utm_idx)
                cache['utm'][f.id()] = "" if u is None else _norm_utm(u)
            cache['index'].addFeature(f)
        return cache

    def _align_marker_index(self, point_lyr, rect, locked=None, lock_map=None):
        """คิวรีเดียว: หมุดในกรอบ -> ตารางช่องละ 1 มม. {(ix, iy, utm): [(fid, x, y), ...]}  (ใช้หาหมุดคู่ของมุมที่ถูก weld)
        ★ 2.3.7 (audit F5) — เดิมคีย์ = (x, y ปัดเป็น มม., utm) แล้วหาด้วยคีย์ตรงเป๊ะ ⇒ หมุดที่ห่างมุม ≤ 1 มม. (ถูกกติกา) แต่ปัดคนละช่อง
          (มุม 10.0006 · หมุด 10.0004) ไม่ถูกลากตาม = มุมเปลือย + หมุดลอย ⇒ เก็บพิกัดจริง แล้วหาด้วยระยะ (_align_markers_near)
        ★ 2.4.0 (review DU-01) — locked = set ที่จะเติม fid ของหมุดที่ล็อก (_marker_locked กับ lock_map) · อ่าน Type ในคิวรีเดียวกัน"""
        idx = {}
        if point_lyr is None or rect is None:
            return idx
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        if not tu:
            return idx
        ti = point_lyr.fields().indexOf(tu)
        ty = self._field_index(point_lyr.fields(), 'type') if locked is not None else -1
        r = QgsRectangle(rect)
        r.grow(1.0)
        req = QgsFeatureRequest().setFilterRect(r)
        if ti >= 0:
            req.setSubsetOfAttributes([i for i in (ti, ty) if i >= 0])
        for f in point_lyr.getFeatures(req):
            if locked is not None and self._marker_locked(f, lock_map or {}, tu, ty)[0]:
                locked.add(f.id())
            g = f.geometry()
            if g is None or g.isNull():
                continue
            try:
                p = g.asPoint()
            except Exception:
                continue
            u = _norm_utm(f.attribute(ti)) if ti >= 0 else ""
            _t = self._WELD_MK_TOL
            idx.setdefault((math.floor(p.x() / _t), math.floor(p.y() / _t), u), []).append((f.id(), p.x(), p.y()))
        return idx

    def _align_drop_locked_corners(self, auto, ask, poly_cache, mk_idx, mk_lock, moved, skipped):
        """★ 2.4.0 (review DU-01) — ตัดมุมที่จะเชื่อม (weld) ซึ่งมีหมุดล็อกของแปลงนั้นนั่งอยู่ (≤ 1 มม. · UTM เดียวกับแปลง) ออก
        auto [(pid, vi, npt)] · ask [(pid, vi, npt, d)] จาก _align_weld_candidates · mk_lock = fid หมุดที่ล็อก (_align_marker_index)
        moved = fid หมุดที่ PASS 2 จะย้าย · skipped = set ที่เก็บ (pid, vi) ที่ตัดออก
        -> (auto, ask, จำนวนมุมที่ตัดไม่ได้) · ตัดไม่ได้ = มุมนั้นมีหมุดที่เลือกจะย้ายนั่งอยู่ด้วย (ตัดแล้วหมุดหลุดมุม) ⇒ ผู้เรียกต้องยกเลิกทั้งงาน"""
        ตัด, ชน = set(), set()
        for e in list(auto) + list(ask):
            pid, vi = e[0], e[1]
            if (pid, vi) in ตัด or (pid, vi) in ชน:
                continue
            g0 = poly_cache['geoms'].get(pid)
            u = poly_cache.get('utm', {}).get(pid, "")
            if g0 is None or not u:
                continue
            try:
                v0 = g0.vertexAt(vi)
            except Exception:
                continue
            near = self._align_markers_near(mk_idx, v0.x(), v0.y(), u)
            if any(m in mk_lock for m in near):
                (ชน if any(m in moved for m in near) else ตัด).add((pid, vi))
        if ชน:
            return auto, ask, len(ชน)
        if ตัด:
            skipped.update(ตัด)
            auto = [e for e in auto if (e[0], e[1]) not in ตัด]
            ask = [e for e in ask if (e[0], e[1]) not in ตัด]
        return auto, ask, 0

    def _align_markers_near(self, idx, x, y, u, tol=None):
        """★ 2.3.7 (audit F5) — fid ของหมุด UTM u ที่ห่าง (x, y) ไม่เกิน tol (ปริยาย 1 มม.) จากตารางของ _align_marker_index
        ช่องละ 1 มม. ⇒ ตรวจช่องตัวเอง ±1 ครบทุกตัวที่อยู่ในระยะ"""
        _t = self._WELD_MK_TOL
        tol = _t if tol is None else tol
        cx, cy = math.floor(x / _t), math.floor(y / _t)
        out = []
        for ix in (cx - 1, cx, cx + 1):
            for iy in (cy - 1, cy, cy + 1):
                for _fid, mx, my in idx.get((ix, iy, u), ()):
                    if math.hypot(mx - x, my - y) <= tol + 1e-9:
                        out.append(_fid)
        return out

    @staticmethod
    def _align_rings(poly_cache, xy, EPS=0.05):
        """★ 2.4.5 rc5 — [(วง, เลขจุดยอด)] ของทุกวง (ทุกก้อน · วงใน) ในแคชแปลงที่มีจุดยอดตรง xy (≤ EPS) · ใช้ร่วมกัน
        ทั้ง _side_edge_dir และ _align_chain_dir
        · ตัดจุดยอดซ้ำติดกัน (ขอบยาว 0) + จุดปิดวง — ผลตรวจ Windows rc4 ⚪2: วง …A, B, B, มุมล่าง ทำให้ตัวแก้ของ rc4 ไม่ทำงาน
        · เรียงตาม fid ⇒ ผลไม่ขึ้นกับลำดับที่ดัชนีคืนแปลงมา (ผลตรวจ rc4 🟡1 ส่วนหนึ่ง)"""
        out = []
        if not poly_cache or not poly_cache.get('geoms'):
            return out
        rect = QgsRectangle(xy.x() - 1.0, xy.y() - 1.0, xy.x() + 1.0, xy.y() + 1.0)
        for fid in sorted(poly_cache['index'].intersects(rect)):
            g = poly_cache['geoms'].get(fid)
            if g is None:
                continue
            try:
                # ★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค. "ให้รองรับ multi polygon ด้วย") — ทุกก้อน ทุกวง (รวมวงใน/รู)
                rings = ([ring for poly in g.asMultiPolygon() for ring in poly if ring] if g.isMultipart()
                         else [ring for ring in g.asPolygon() if ring])
            except Exception:
                continue
            for ring in rings:
                r = []
                for q in ring:
                    if not r or abs(q.x() - r[-1].x()) > 1e-6 or abs(q.y() - r[-1].y()) > 1e-6:
                        r.append(q)
                while len(r) > 1 and abs(r[0].x() - r[-1].x()) <= 1e-6 and abs(r[0].y() - r[-1].y()) <= 1e-6:
                    r.pop()
                if len(r) < 3:
                    continue
                # ★ 2.4.5 rc8 (ผลตรวจ Windows rc7 🟡1) — จุดยอดที่ "ใกล้ที่สุด" ในรัศมี (rc5–rc7 ใช้จุดแรกที่เจอ)
                #   จุดยอดติดกัน < 5 ซม. ที่มีหมุดของตัวเองทั้งคู่ (หมุดซ้อน/หมุดชิด) ⇒ หมุดดวงที่สองถูกนับเป็นจุดยอดของดวงแรก
                #   ⇒ ด่านทั้งแถวของ rc7 เห็นดวงนี้ซ้ำที่ตำแหน่งดวงแรก ⇒ วางทับดวงแรก + กล่อง "หมุดทับกัน" (2.4.4–rc6 ทำถูก)
                vi, best = -1, None
                for i, v in enumerate(r):
                    ex, ey = abs(v.x() - xy.x()), abs(v.y() - xy.y())
                    if ex <= EPS and ey <= EPS and (best is None or ex * ex + ey * ey < best):
                        vi, best = i, ex * ex + ey * ey
                if vi >= 0:
                    out.append((r, vi))
        return out

    def _align_sd(self, q, poly_cache, dx, dy, picked_xy):
        """★ 2.4.5 rc8 (ผลตรวจ Windows rc7 ⚪C) — _side_edge_dir ที่จำผลไว้ใน poly_cache ของรอบนี้ (สร้างใหม่ทุกรอบ Align)
        ด่านทั้งแถวของ rc7 ถามทิศของหมุดกลางทุกดวงทุกครั้งที่คิดหมุดหนึ่ง ⇒ (จำนวนหมุดกลาง)² ครั้ง × จุดยอดของวง
        (ถนนใหญ่ 10,000 จุด หมุดกลาง 80 ดวง: 1.4 → 29 วิ · 150 ดวง 2.9 → 95 วิ QGIS ค้าง) ⇒ จำแล้วเหลือดวงละครั้ง"""
        memo = poly_cache.setdefault('_sd_memo', {})
        k = (round(q.x(), 6), round(q.y(), 6), dx, dy)
        if k not in memo:
            memo[k] = self._side_edge_dir(q, poly_cache, dx, dy, picked_xy)
        return memo[k]

    def _side_edge_dir(self, old_xy, poly_cache, line_dx, line_dy, picked_xy=None):
        """ทิศของขอบแปลงที่ vertex old_xy โดยเลือกขอบที่ไม่ขนานกับเส้นเป้าหมาย -> (ux,uy) หรือ None
        ค้นจาก poly_cache ที่ prefetch ไว้ (ไม่ยิง query ต่อหมุดแล้ว)
        ★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค. พร้อมรูป: "…ด้านที่ตั้งฉากกับเส้นอ้างอิงมากที่สุด โดยไม่เอาด้านที่มีหมุดที่เลือกครอบ 2 ฝั่ง")
          picked_xy = [(x, y)] ตำแหน่งหมุดที่เลือกทั้งหมด ⇒ ขอบที่ปลายอีกข้างเป็นหมุดที่เลือกด้วย (เช่นขอบหน้าแปลงที่เลือกหมุดครบ
          ทั้งสองมุม) ไม่นำมาเป็นแนววิ่ง — ขอบนั้นถูกย้ายทั้งเส้นอยู่แล้ว · หมุดต้องวิ่งตามขอบข้างที่ต่อไปมุมที่ไม่ได้เลือก"""
        if not poly_cache or not poly_cache['geoms']:
            return None
        lmag = math.hypot(line_dx, line_dy)
        if lmag == 0:
            return None
        lux, luy = line_dx / lmag, line_dy / lmag
        EPS = 0.05

        def _picked(q):
            """ปลายอีกข้างของขอบเป็นหมุดที่เลือก (≤ 5 ซม. · เกณฑ์เดียวกับจับมุม)"""
            if not picked_xy:
                return False
            return any(abs(q.x() - px) <= EPS and abs(q.y() - py) <= EPS for px, py in picked_xy)

        def _unit(a, b):
            ex, ey = b.x() - a.x(), b.y() - a.y()
            em = math.hypot(ex, ey)
            return (ex / em, ey / em) if em > 1e-9 else None
        found = self._align_rings(poly_cache, old_xy, EPS)
        # ★ 2.4.5 rc5 (ผลตรวจ Windows rc4 ⚪3) — ทิศขอบไปหมุดที่เลือก "จากทุกวงที่ใช้จุดนี้" ก่อนคัดขอบ
        #   rc4 คิดทีละวง ⇒ วงของแปลงข้างเคียงที่ร่วมแค่ B–มุมล่าง (ไม่มี A ในวง) ยังเสนอขอบที่ต่อตรงกับแถวให้วิ่งตามได้
        runs = []
        for ring, vi in found:
            v, n = ring[vi], len(ring)
            for nb in (ring[(vi - 1) % n], ring[(vi + 1) % n]):
                if _picked(nb):
                    d = _unit(v, nb)
                    if d:
                        runs.append(d)                # ทิศขอบไปหมุดที่เลือก (แถวที่ถูกย้าย)
        best = None  # (parallelness, ux, uy)
        for ring, vi in found:
            v, n = ring[vi], len(ring)
            for nb in (ring[(vi - 1) % n], ring[(vi + 1) % n]):
                if _picked(nb):
                    continue                          # ★ 2.3.9 ขอบที่หมุดที่เลือกครอบสองฝั่ง — ไม่ใช่แนววิ่ง
                d = _unit(v, nb)
                if d is None:
                    continue
                ux, uy = d
                if any(abs(ux * rx + uy * ry) >= self.ALIGN_RUN_STRAIGHT for rx, ry in runs):
                    # ★ 2.4.5 rc4 (เจ้าของงานส่งรูป 24 ต.ค. 69: เลือกมุมบน + หมุดกลางขอบข้าง ⇒ หมุดล่างวิ่งไปชนหมุดบน)
                    #   ขอบนี้ต่อตรงกับขอบไปหมุดที่เลือก (เบน ≤ ~26°) = เส้นเดียวกับแถวที่ถูกย้าย ไม่ใช่ขอบข้าง —
                    #   วิ่งตามมันคือไถลไปตามแนวแถวเอง (ชน/ข้ามหมุดอีกตัวในแถว · เลยมุมถัดไปจนแปลงพับ) ⇒ ไม่นับ
                    #   (ผู้เรียกใช้ทิศที่มุมปลายอีกข้างของแถววิ่งจริง — _align_chain_dir — หาไม่ได้ = ฉายตั้งฉาก)
                    #   ใช้ |cos| ⇒ ขอบหนามแหลมที่ย้อนกลับเกือบทับแถว (⚪4) ก็ไม่นับ — วิ่งตามมันก็ไถลตามแนวแถวเหมือนกัน
                    continue
                par = abs(ux * lux + uy * luy)   # 1 = ขนานกับเส้นเป้าหมาย
                if best is None or par < best[0]:
                    best = (par, ux, uy)
        return (best[1], best[2]) if best else None

    def _align_new_point(self, old_xy, poly_cache, p1, dx, dy, projfn, picked_xy=None):
        """ย้ายมุมไป 'ตามแนวขอบข้าง' (ขอบที่ต่อไปหมุดที่ไม่ได้เลือก) จนชนเส้นแนว -> ขอบนั้นคงมุมเดิม
        ★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค.: "ให้หมุดที่วิ่งเข้าหาเส้นอ้างอิงตามแนวเส้นของแปลง ด้านที่ตั้งฉากกับเส้นอ้างอิงมากที่สุด")
          เดิมตามขอบเฉพาะขอบที่ทำมุมกับเส้นแนว > 60° (|cos| < 0.5) ไม่งั้นฉายตั้งฉาก ⇒ แปลงที่ขอบข้างเอียง 30–60°
          (พบบ่อยในแปลงรูปคางหมู) หมุดวิ่งตั้งฉากออกจากแนวขอบ = รูปบิด · ตอนนี้ตามขอบที่ตั้งฉากที่สุดเสมอ
          เว้นแต่ขอบนั้นเกือบขนานเส้น (|cos| ≥ 0.9 · เอียง < ~26°) ซึ่งจะไถลไกลเกินระยะตั้งฉาก 2.3 เท่า ⇒ ฉายตั้งฉาก (ปลอดภัย)"""
        perp = projfn(old_xy.x(), old_xy.y())
        lmag = math.hypot(dx, dy)
        if not poly_cache or lmag == 0:
            return perp
        sd = self._align_sd(old_xy, poly_cache, dx, dy, picked_xy)   # ทิศขอบที่ตั้งฉากกับเส้นแนวที่สุด (ไม่นับขอบที่หมุดที่เลือกครอบ 2 ฝั่ง) · ★ rc8 จำผล
        row = []
        if sd is None and picked_xy:
            # ★ 2.3.9 (เจ้าของงานส่งรูป 11 ต.ค.: หมุดกลางขอบหน้าที่เลือกพร้อมมุมทั้งสอง "ให้วิ่งเข้าหาตามนั้น")
            #   ขอบทั้งสองข้างของหมุดนี้ถูกหมุดที่เลือกครอบ ⇒ ไม่มีขอบให้วิ่งตาม ⇒ ใช้ทิศของ "ขอบข้าง" ที่ปลายแถวหมุดที่เลือก
            #   ★ 2.4.5 rc4 — หรือขอบที่เหลือต่อตรงกับแถว (หมุดปลายแถวบนขอบตรง · รูปของเจ้าของงาน 24 ต.ค.) ⇒ ขนานกับขอบข้างที่ปลายอีกข้าง
            #   (ไล่ตามวงไปทั้งสองทางจนเจอมุมที่ต่อไปหมุดที่ไม่ได้เลือก) · สองข้างไม่ขนานกัน ⇒ ทิศเฉลี่ยตามระยะจากปลายแต่ละข้าง
            sd = self._align_chain_dir(old_xy, poly_cache, picked_xy, line=(dx, dy), row_out=row)   # ★ rc5 (🟡1) ส่งทิศเส้นอ้างอิง
        if sd is None and not row:
            return perp
        new = self._align_follow(old_xy, sd, p1, dx, dy, projfn) if sd is not None else perp
        if row:
            # ★ 2.4.5 rc6 (ผลตรวจ Windows rc5 🟡1 · เส้นเอียง 2.4.4 ทำแปลงไขว้ T20) — หมุดกลางแถวต้องอยู่ระหว่างมุมปลายแถวทั้งสองบนเส้น
            #   ทิศเฉลี่ยใช้ได้ดีเมื่อมุมปลายแถววิ่งตามขอบข้าง แต่ถ้ามุมปลายหนึ่งฉายตั้งฉาก (ขอบข้างเกือบขนานเส้น) ทิศเฉลี่ยพาหมุดกลาง
            #   เลยมุมนั้นไป (ลำดับหมุดบนขอบสลับ = แปลงไขว้/หนาม) ⇒ เลยมุม = วางตามสัดส่วนเดิมตามแนวแถวระหว่างตำแหน่งใหม่ของมุมทั้งสอง
            #   ผลที่อยู่ในแถวอยู่แล้ว (เกือบทุกกรณี) ไม่เปลี่ยน
            # ★ 2.4.5 rc7 (ผลตรวจ Windows rc6 🟡1 · เจ้าของงาน "แก้ 🟡 ใหม่เป็น rc7 ก่อน") — ตัดสิน "ทั้งแถว" แทนทีละดวง
            #   rc6 ตัดสินทีละดวง ⇒ แถวที่มีหมุดกลาง ≥ 2 ดวง ดวงที่เลยมุมถูกดึงกลับไปอยู่ก่อนดวงที่ไม่เลย = ลำดับสลับ (หนามแบน) เงียบ
            #   ⇒ คาดตำแหน่งของหมุดกลางทุกดวงในแถวด้วยทางเดียวกับที่แต่ละดวงจะไป · ดวงใดเลยมุมปลายแถว หรือลำดับตามแนวแถวไม่เรียง
            #   ⇒ ทุกดวงในแถววางตามสัดส่วนเดิม (ตัดสินเหมือนกันทุกดวงเพราะแถวและข้อมูลเดียวกัน)
            #   หมุดกลางที่มีขอบข้างของตัวเอง (เช่นจุดแยกรูปตัว T ของแปลงข้างเคียง) วิ่งตามขอบนั้น — ไม่นับในแถวนี้
            (ea, ua), (eb, ub), t, mids = row[0]
            na = self._align_follow(ea, ua, p1, dx, dy, projfn)   # ตำแหน่งใหม่ของมุมปลายแถว (ทางเดียวกับที่หมุดของมุมนั้นจะไป)
            nb = self._align_follow(eb, ub, p1, dx, dy, projfn)
            ex, ey = nb.x() - na.x(), nb.y() - na.y()
            ll = ex * ex + ey * ey
            if ll > 1e-12:
                fs = []
                for q, tq, uq, me in mids:
                    if me:
                        pq = new
                    elif self._align_sd(q, poly_cache, dx, dy, picked_xy) is not None:   # ★ rc8 จำผล (⚪C)
                        continue
                    else:
                        pq = self._align_follow(q, uq, p1, dx, dy, projfn) if uq is not None else projfn(q.x(), q.y())
                    fs.append((tq, ((pq.x() - na.x()) * ex + (pq.y() - na.y()) * ey) / ll))
                fs.sort()
                if not (all(0.0 < f < 1.0 for _t, f in fs) and all(a[1] < b[1] for a, b in zip(fs, fs[1:]))):
                    new = QgsPointXY(na.x() + t * ex, na.y() + t * ey)
        return new

    def _align_par_limit(self):
        """เกณฑ์ |cos| ระหว่างทิศวิ่งกับเส้นแนว — ถึงเกณฑ์ (เกือบขนาน) ⇒ ฉายตั้งฉากแทนวิ่งตามทิศ
        OPT (2026-08-07): เดิมสร้าง QSettings + อ่าน ini ใหม่ทุกหมุด -> อ่านครั้งเดียวต่อ operation
          (ค่าที่ผู้ใช้ตั้งเองใน QSettings ยังมีผล · ไม่ได้ตั้ง = ค่าปริยายใหม่ของ 2.3.9)"""
        max_par = getattr(self, '_align_max_par', None)
        if max_par is None:
            try:
                max_par = QtCore.QSettings().value("MultiLayerEditPro/Align/EdgeFollowMaxPar",
                                                   self.ALIGN_EDGE_MAX_PAR, float)
            except Exception:
                max_par = self.ALIGN_EDGE_MAX_PAR
            self._align_max_par = max_par
        return max_par

    def _align_follow(self, old_xy, sd, p1, dx, dy, projfn):
        """ย้าย old_xy ตามทิศ sd จนชนเส้นแนว (p1 + s·(dx, dy)) · ทิศเกือบขนานเส้นแนว ⇒ ฉายตั้งฉาก
        ★ 2.4.5 rc6 — แยกจากท้าย _align_new_point (คิดเหมือนเดิมทุกประการ) เพื่อคิดตำแหน่งใหม่ของมุมปลายแถวด้วยทางเดียวกัน"""
        perp = projfn(old_xy.x(), old_xy.y())
        lmag = math.hypot(dx, dy)
        ux, uy = sd
        lux, luy = dx / lmag, dy / lmag
        par = abs(ux * lux + uy * luy)   # 1 = ขนานเส้นแนว, 0 = ตั้งฉาก
        # ★ 2.3.9 — ตามขอบเสมอเว้นแต่ขอบเกือบขนานเส้น (par ≥ 0.9) · เดิม 0.5 (ต้องตั้งฉาก > 60°)
        if par >= self._align_par_limit():
            return perp
        den = dx * uy - dy * ux
        if abs(den) < 1e-9:
            return perp
        s = ((old_xy.x() - p1.x()) * uy - (old_xy.y() - p1.y()) * ux) / den
        return QgsPointXY(p1.x() + s * dx, p1.y() + s * dy)

    def _align_chain_dir(self, old_xy, poly_cache, picked_xy, EPS=0.05, line=None, row_out=None):
        """★ 2.3.9 — ทิศวิ่งของหมุดที่อยู่ "กลางแถว" หมุดที่เลือกบนขอบเดียวกัน (ขอบทั้งสองข้างของมันถูกหมุดที่เลือกครอบ)
        ไล่ตามวงของแปลงจากมุมนี้ไปทั้งสองทางจนถึงปลายแถว (มุมที่เลือกซึ่งเพื่อนอีกข้างไม่ได้เลือก) แล้วใช้ทิศของขอบข้างที่ปลายทั้งสอง
        เฉลี่ยถ่วงตามระยะตามแนวแถว · ขอบข้างขนานกัน ⇒ ทิศเดียวกับมุมทั้งสอง (ตามรูปของเจ้าของงาน)
        ★ 2.4.5 rc4 — หมุดปลายแถว (เพื่อนข้างเดียวถูกเลือก) ก็ใช้ได้ · มีขอบข้างทางเดียว ⇒ ทิศของขอบนั้น (วิ่งขนานกับมุมปลายแถว)
        ★ 2.4.5 rc5 (ผลตรวจ Windows rc4 🟡1) — line = (dx, dy) ทิศเส้นอ้างอิง ⇒ ที่ปลายแถวใช้ "ทิศที่มุมปลายแถววิ่งจริง"
          (_side_edge_dir ของมุมนั้น · คิดจากทุกแปลงที่ใช้มุม) แทนขอบของวงที่เจอก่อน — rc4 ใช้ขอบของวงแรกที่ดัชนีคืนมา ⇒ มีแปลงข้างเคียง
          ร่วมขอบแถว หมุดปลายแถวเอาทิศจากแปลงข้างเคียง (ผิดเงียบ 1.5 ม. · แปลงไขว้) ขึ้นกับลำดับแปลงในฐาน · วงนี้ไม่มีทาง ⇒ ลองวงอื่นต่อ
        ★ 2.4.5 rc6 (ผลตรวจ Windows rc5 🟡1) — ทิศของสองปลายหันให้อยู่ "ฝั่งเดียวกันของแนวแถว" ก่อนเฉลี่ย (แทน rc5 ที่กลับข้างเมื่อ
          สองทิศทำมุมเกิน 90° — ผิดกับแปลงที่ขอบข้างลู่/ถ่างมาก เช่นสามเหลี่ยมแบน รูปพัด ขอบตัดมุมที่ทางแยก) ⇒ แปลงเดียวที่ปลายแถวเป็นมุมนูน = 2.4.4
          (ปลายแถวเป็นมุมหักเข้า ⇒ อาจต่างจาก 2.4.4 แต่ใกล้สัดส่วนเดิมกว่า · ผลตรวจ Windows rc6 ⚪2)
          แปลงข้างเคียงที่ขอบข้างอยู่คนละฝั่งของแถว = rc5 · (ลอง "หันตามทางที่มุมเคลื่อน" แล้ว — พังเมื่อเส้นตัดผ่านแถว สองปลายเคลื่อนสวนกัน)
          row_out = list ⇒ ใส่ ((มุมปลาย a, ทิศ), (มุมปลาย b, ทิศ), สัดส่วนตามแนวแถวจากปลาย a,
          ★ rc7 [(หมุดกลาง, สัดส่วน, ทิศเฉลี่ย, เป็นดวงนี้)] ทุกดวงในแถว) ให้ผู้เรียกตรวจว่าหมุดกลางไม่เลยมุมปลายแถว/ลำดับไม่สลับ
        หาไม่ได้ (ทั้งวงถูกเลือก / ปลายแถวไม่มีขอบข้างทั้งสองทาง / ทิศหักล้างกัน) = None ⇒ ผู้เรียกฉายตั้งฉาก"""
        if not poly_cache or not poly_cache.get('geoms') or not picked_xy:
            return None

        def _picked(q):
            return any(abs(q.x() - px) <= EPS and abs(q.y() - py) <= EPS for px, py in picked_xy)
        for ring, vi in self._align_rings(poly_cache, old_xy, EPS):
            n = len(ring)
            # ★ 2.4.5 rc4 — รับหมุด "ปลายแถว" ด้วย (เพื่อนข้างเดียวถูกเลือก · ขอบอีกข้างต่อตรงกับแถวจน _side_edge_dir ไม่นับ)
            if not (_picked(ring[(vi - 1) % n]) or _picked(ring[(vi + 1) % n])):
                continue

            def _walk(step):
                """เดินจาก vi ไปทาง step จนถึงปลายแถว -> (ทิศขอบข้าง (ux,uy), ระยะตามแนวแถว, มุมปลายแถว,
                [(หมุดกลางที่เดินผ่าน, ระยะจาก vi)]) หรือ None"""
                i, dist, path = vi, 0.0, []
                for _k in range(n):
                    j = (i + step) % n
                    if j == vi:
                        return None                      # ทั้งวงถูกเลือก
                    dist += math.hypot(ring[j].x() - ring[i].x(), ring[j].y() - ring[i].y())
                    nxt = ring[(j + step) % n]
                    if not _picked(nxt):
                        if line is not None:
                            # ★ rc5 (🟡1) ทิศที่มุมปลายแถววิ่งจริง (ทุกแปลง · ตัดขอบที่หมุดที่เลือกครอบ/ขอบต่อตรงกับแถวแล้ว)
                            d = self._align_sd(ring[j], poly_cache, line[0], line[1], picked_xy)   # ★ rc8 จำผล (⚪C)
                            return (d, dist, ring[j], path) if d is not None else None
                        ex, ey = nxt.x() - ring[j].x(), nxt.y() - ring[j].y()
                        em = math.hypot(ex, ey)
                        if em <= 1e-9:
                            return None
                        rx, ry = ring[i].x() - ring[j].x(), ring[i].y() - ring[j].y()
                        rm = math.hypot(rx, ry)
                        if rm > 1e-9 and abs(ex * rx + ey * ry) / (em * rm) >= self.ALIGN_RUN_STRAIGHT:
                            return None                  # ★ rc4 ปลายแถวต่อตรง ⇒ ไม่มีขอบข้างทางนี้
                        return ((ex / em, ey / em), dist, ring[j], path)
                    path.append((ring[j], dist))         # ★ rc7 หมุดกลางดวงอื่นในแถวเดียวกัน
                    i = j
                return None
            sides = [w for w in (_walk(-1) if _picked(ring[(vi - 1) % n]) else None,
                                 _walk(+1) if _picked(ring[(vi + 1) % n]) else None) if w is not None]
            if not sides:
                continue                                 # ★ rc5 วงนี้ไม่มีทาง ⇒ ลองวงอื่น (rc4 จบที่วงแรก)
            if len(sides) == 1:
                return sides[0][0]                       # ★ rc4 ปลายแถว / ปลายอีกข้างไม่มีขอบข้าง ⇒ ขนานกับขอบข้างที่มี
            (ua, da, ea, pa), (ub, db, eb, pb) = sides
            t = da / (da + db) if (da + db) > 0 else 0.5         # 0 = ชิดปลาย a · 1 = ชิดปลาย b
            ua0, ub0 = ua, ub                                   # ทิศของมุมปลายแถวเอง (คิดตำแหน่งใหม่ของมุม — เครื่องหมายไม่มีผล)
            # ★ rc6 — หันให้ขอบข้างทั้งสองปลายอยู่ฝั่งเดียวกันของแนวแถว (เครื่องหมาย cross กับทิศจากปลาย a ไปปลาย b)
            #   แปลงเดียว (ปลายแถวเป็นมุมนูน): ขอบข้างทั้งสองออกไปฝั่งเนื้อแปลง ⇒ ไม่กลับ = 2.4.4 · มุมหนึ่งได้ขอบจากแปลงข้างเคียงอีกฝั่ง ⇒ กลับ
            #   ทิศเกือบขนานแนวแถว (|sin| ≤ 0.05 · แถวหักมุม) บอกฝั่งไม่ได้ ⇒ ใช้เกณฑ์เดิมของ rc5 (dot < 0 ⇒ กลับ)
            rx, ry = eb.x() - ea.x(), eb.y() - ea.y()
            rm = math.hypot(rx, ry)
            ca, cb = rx * ua[1] - ry * ua[0], rx * ub[1] - ry * ub[0]
            if rm > 1e-9 and min(abs(ca), abs(cb)) > 0.05 * rm:
                if ca * cb < 0:
                    ub = (-ub[0], -ub[1])
            elif ua[0] * ub[0] + ua[1] * ub[1] < 0:
                ub = (-ub[0], -ub[1])

            def _mix(tq):
                """ทิศเฉลี่ยของหมุดกลางที่สัดส่วน tq ตามแนวแถว"""
                ux, uy = (1 - tq) * ua[0] + tq * ub[0], (1 - tq) * ua[1] + tq * ub[1]
                m = math.hypot(ux, uy)
                return (ux / m, uy / m) if m > 1e-6 else None
            if row_out is not None:
                # ★ rc7 — หมุดกลางทุกดวงของแถว (เรียงจากปลาย a · ดวงนี้ติดธง True) ให้ผู้เรียกตัดสินทั้งแถว
                tot = da + db
                mids = ([(q, (da - dq) / tot if tot > 0 else 0.5, False) for q, dq in reversed(pa)] + [(ring[vi], t, True)]
                        + [(q, (da + dq) / tot if tot > 0 else 0.5, False) for q, dq in pb])
                row_out.append(((ea, ua0), (eb, ub0), t, [(q, tq, _mix(tq), me) for q, tq, me in mids]))
            return _mix(t)
        return None

    @staticmethod
    def _align_vertices_near(geom, xy, tol, coincide_tol=None):
        """★ 2.3.9 — [(เลข vertex, ระยะ)] ของมุมที่จะดึงตามหมุดที่ xy (ไม่นับจุดปิดวง)
        เลข vertex = ลำดับเดียวกับ vertexAt/moveVertex (นับจุดปิดวงด้วย) · ย้ายจุดแรกของวง = จุดปิดวงตามเอง (วัดแล้ว QGIS 3.40)
        ★ rc3 (ผลตรวจ Windows 🟡1) — มุมที่ใกล้สุด (≤ tol) 1 มุมเหมือน closestVertex ของ 2.3.8 + มุมของ "ก้อน/วงอื่น"
          เฉพาะที่ซ้อนตำแหน่ง (≤ coincide_tol · ไม่ระบุ = tol) · วงเดียวกันไม่เอามุมที่สอง
          rc1–rc2 เอาทุกมุมในระยะ tol ⇒ แปลงที่มีมุม E ห่างมุม A 20 ซม. ถูกถาม "รวมไหม" ตอบ Yes แล้ว E ยุบไปทับ A"""
        out = []
        try:
            pts = []
            for v in geom.vertices():
                pts.append((v.x(), v.y()))
            ids = []
            for i in range(len(pts)):
                ok, vid = geom.vertexIdFromVertexNr(i)
                ids.append((vid.part, vid.ring, vid.vertex) if ok else None)
            ใกล้สุดของวง = {}                      # (ก้อน, วง) -> (เลข vertex, ระยะ) มุมที่ใกล้ xy ที่สุดในวงนั้น
            for i, (x, y) in enumerate(pts):
                cur = ids[i]
                if cur is None:
                    continue
                nxt = ids[i + 1] if i + 1 < len(ids) else None
                if cur[2] > 0 and (nxt is None or nxt[:2] != cur[:2]):
                    continue                      # จุดปิดวง (ซ้ำกับจุดแรกของวง)
                d = math.hypot(x - xy.x(), y - xy.y())
                if d <= tol and (cur[:2] not in ใกล้สุดของวง or d < ใกล้สุดของวง[cur[:2]][1]):
                    ใกล้สุดของวง[cur[:2]] = (i, d)
            if ใกล้สุดของวง:
                หลัก = min(ใกล้สุดของวง.values(), key=lambda t: t[1])
                ct = tol if coincide_tol is None else coincide_tol
                out = [หลัก] + sorted(t for t in ใกล้สุดของวง.values() if t is not หลัก and t[1] <= ct)
        except Exception:
            _cp, vidx, _pi, _ni, sqr = geom.closestVertex(xy)
            if vidx >= 0 and sqr is not None and math.sqrt(sqr) <= tol:
                out = [(vidx, math.sqrt(sqr))]
        return out

    def _align_weld_candidates(self, moves, poly_cache, auto_tol, ask_tol, locked=None, skipped=None):
        """มุมแปลงที่จะถูกดึงตามหมุด (weld · junction-aware) คิดจาก geometry ก่อนแก้ใน poly_cache
        → (auto [(pid, vi, npt)], ask [(pid, vi, npt, d)])
        ★ 2.3.7 (review DI-37) — ย้ายมาจาก PASS 3 เพื่อคิด "ก่อน" เปิดคำสั่งแก้ไข (ตรวจแผน/จำลองเนื้อที่ได้)
          ผลเหมือนเดิมทุกประการ: ใช้ snapshot เดียวกัน และไม่ขึ้นกับการเขียนหมุดใน PASS 2
        ★ 2.3.7 (audit F6) — locked = ตาราง UTM ของแปลง L1 (_locked_map_or_block) · skipped = set ที่เก็บ (pid, vidx) ที่ข้าม"""
        _ล็อก = locked if (locked and not self._l1_unlocked()) else {}
        cand = {}      # (poly_id, vidx) -> (new_pt, dist)
        seen = set()
        for pt_id, old_xy, new_pt in moves:
            key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
            if key in seen:
                continue
            seen.add(key)
            search_rect = QgsRectangle(old_xy.x() - ask_tol, old_xy.y() - ask_tol,
                                       old_xy.x() + ask_tol, old_xy.y() + ask_tol)
            for pid in poly_cache['index'].intersects(search_rect):
                if (poly_cache['types'].get(pid, "") in L1_TYPES      # ★ 2.4.0 (DU-01) lock_rules
                        and not self._l1_unlocked()):   # ★ admin: weld node L1 ได้
                    continue                      # ข้ามแปลงอ้างอิงที่ล็อก (เงียบ)
                geom = poly_cache['geoms'].get(pid)
                if geom is None or geom.isNull():
                    continue
                # ★ 2.3.9 (MultiPolygon) — มุมใกล้สุด + มุมของก้อน/วงอื่นที่ซ้อนตำแหน่ง (≤ auto_tol) ไม่ใช่แค่ closestVertex ตัวเดียว
                #   เดิมแปลงหลายก้อนที่มุมของสองก้อนซ้อนตำแหน่งเดียวกัน (เช่นผลซ่อมแบ่งหัก) ขยับได้ก้อนเดียว ⇒ อีกก้อนค้าง = แปลงแยก/รูรั่ว
                #   ★ rc3 (🟡1) — ไม่ดึงมุมที่สองของวงเดียวกัน (มุมใกล้ ≤30 ซม. ของแปลงเดียวกันเคยถูกถามแล้วยุบ)
                for vidx, d in self._align_vertices_near(geom, old_xy, ask_tol, auto_tol):
                    # ★ 2.3.7 (audit F6) — แปลงที่ไม่ใช่ L1 แต่ UTM ตรงกับแปลง L1 (คีย์แฝด): หมุดของ UTM นี้ = หมุดของแปลง L1 ด้วย (ล็อก)
                    #   เดิมดูแค่ Type ⇒ ดึงมุมแปลงนี้แล้วลากหมุดล็อกตามไป (ข้ามล็อก L1 · ผู้ตรวจ p06 b) ⇒ ข้ามทั้งมุม
                    #   (มุมกับหมุดของมันอยู่ที่เดิมคู่กัน — กติกาเหล็กไม่เสีย) แล้วนับไว้บอกในข้อความสรุปท้ายงาน
                    if _ล็อก and poly_cache.get('utm', {}).get(pid, "") in _ล็อก:
                        if skipped is not None:
                            skipped.add((pid, vidx))
                        continue
                    vk = (pid, vidx)
                    if vk not in cand or d < cand[vk][1]:   # เก็บหมุดที่ใกล้ node นี้สุด
                        cand[vk] = (new_pt, d)
        auto = [(pid, vi, npt) for (pid, vi), (npt, d) in cand.items() if d <= auto_tol]
        ask = [(pid, vi, npt, d) for (pid, vi), (npt, d) in cand.items() if auto_tol < d <= ask_tol]
        return auto, ask

    @staticmethod
    def _align_new_spikes(g0, g1, cos_lim=0.9995):
        """★ 2.4.5 rc7 — จำนวนจุดยอดของ g1 ที่ขอบสองข้างย้อนทับกัน (มุมใน < ~1.8° · ทิศไปจุดก่อนหน้ากับจุดถัดไปเกือบทางเดียวกัน)
        ซึ่งจุดเดียวกันใน g0 ไม่เป็น · g1 = สำเนา g0 ที่ขยับจุดยอด (จำนวน/ลำดับเท่าเดิม) · ข้ามขอบยาว 0 (ใช้จุดก่อนหน้า/ถัดไปที่ไม่ซ้อนกัน)"""
        def _rings(g):
            return ([ring for poly in g.asMultiPolygon() for ring in poly] if g.isMultipart()
                    else [ring for ring in g.asPolygon()])

        def _spike(pts, i):
            n, q = len(pts), pts[i]
            nb = []
            for step in (-1, 1):
                for k in range(1, n):
                    r = pts[(i + step * k) % n]
                    if abs(r.x() - q.x()) > 1e-6 or abs(r.y() - q.y()) > 1e-6:
                        nb.append((r.x() - q.x(), r.y() - q.y()))
                        break
            if len(nb) < 2:
                return False
            (ux, uy), (vx, vy) = nb
            return (ux * vx + uy * vy) / (math.hypot(ux, uy) * math.hypot(vx, vy)) >= cos_lim
        r0, r1 = _rings(g0), _rings(g1)
        if len(r0) != len(r1):
            return 0
        out = 0
        for a, b in zip(r0, r1):
            if len(a) != len(b) or len(b) < 4:
                continue
            pa, pb = a[:-1], b[:-1]                      # ตัดจุดปิดวง
            out += sum(1 for i in range(len(pb)) if _spike(pb, i) and not _spike(pa, i))
        return out

    def _align_plan_ok(self, moves, target_points, point_lyr, poly_lyr, poly_cache, weld):
        """★ 2.3.7 (review DI-37) — ตรวจ "แผน" ของ Align ก่อนแตะชั้นใด ๆ แล้วถามเมื่อผิดปกติ (ปุ่มตั้งต้น = No)
        เดิมไม่มีด่านเลย: สี่เหลี่ยม 10×20 เลือกหมุดครบ 4 มุมแล้วลากเส้น y=1 ⇒ แปลงเหลือ 0 ตร.ม. หมุดซ้อน 2+2 ไม่มีกล่องใด ๆ
        ① หมุดของแปลงเดียวกัน (UTM เดียวกัน) ≥ 2 ตำแหน่งเดิม ไปรวมที่จุดเดียว = ขอบหาย/แปลงยุบ
        ② จำลองการดึงมุมแปลง (weld) บนสำเนา geometry — เนื้อที่เหลือ < 1 ตร.ม. หรือหายเกินครึ่ง
           (weld = รวมมุมที่จะถาม "รวมไหม" ด้วย — คิดแบบเผื่อกรณีแย่สุด)
        ③ ★ 2.4.5 rc5 — จำลองแล้วรูปแปลงที่เดิมถูกต้องกลายเป็นไขว้ตัวเอง/พับ (GEOS invalid · ผลตรวจ Windows rc4 ⚪1/⚪5)
        ④ ★ 2.4.5 rc7 — ขอบติดกันย้อนทับกันเองที่เดิมไม่เป็น (หนามแบน · GEOS ยังนับว่าถูกต้อง · ผลตรวจ Windows rc6 🟡1)
        (★ 2.3.7 b13 — เจ้าของงานตัดสิน 3 ต.ค. 69: เลิกถามเพราะ "ระยะขยับไกล" (เดิมข้อ ③ เกินเพดาน _addnode_max_dist
         2 ม. ของพนักงาน) — แปลง L2-RO ที่หยาบต้องขยับไกลเป็นปกติ · ระยะไกลสุดยังบอกในกล่องเมื่อถามเพราะข้อ ①/②)
        ระหว่างถาม แสดงตำแหน่งใหม่ของหมุด (+ แปลงที่ยุบ) เป็นสีส้มบนแผนที่ แล้วเอาออกทันทีหลังตอบ
        คืน True = ทำต่อ · False = ผู้ใช้เลือกไม่ทำ"""
        if not moves:
            return True
        utm_f = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        utm_of = {}
        if utm_f:
            for f in target_points:
                try:
                    v = _txt(f[utm_f])
                except Exception:
                    v = ""
                if v:
                    utm_of[f.id()] = _norm_utm(v)
        groups = {}
        for pt_id, old_xy, new_pt in moves:
            u = utm_of.get(pt_id)
            if not u:
                continue
            groups.setdefault((u, round(new_pt.x(), 3), round(new_pt.y(), 3)), set()).add(
                (round(old_xy.x(), 3), round(old_xy.y(), 3)))
        n_coll = sum(len(v) for v in groups.values() if len(v) >= 2)
        maxd = max((math.hypot(n.x() - o.x(), n.y() - o.y()) for _i, o, n in moves), default=0.0)
        geoms = (poly_cache or {}).get('geoms', {}) if poly_cache else {}
        sim = {}
        for pid, vi, npt in weld:
            g0 = geoms.get(pid)
            if g0 is None:
                continue
            g = sim.get(pid)
            if g is None:
                g = QgsGeometry(g0)
            try:
                v0 = g0.vertexAt(vi)
                maxd = max(maxd, math.hypot(v0.x() - npt.x(), v0.y() - npt.y()))
            except Exception:
                pass
            g.moveVertex(npt.x(), npt.y(), vi)
            sim[pid] = g
        shrunk = []
        for pid, g in sim.items():
            try:
                a0, a1 = geoms[pid].area(), g.area()
            except Exception:
                continue
            if a1 < 1.0 or (a0 > 0 and a1 < 0.5 * a0):
                shrunk.append((pid, a0, a1))
        # ★ 2.4.5 rc5 (ผลตรวจ Windows rc4 ⚪1/⚪5) — แปลงที่รูปเดิมถูกต้องแต่รูปใหม่ไขว้ตัวเอง/พับ (GEOS invalid) ⇒ ถามก่อนเหมือนแปลงยุบ
        #   เดิมจับแค่แปลงยุบ/เนื้อที่หายเกินครึ่ง ⇒ หมุดไถลเลยมุมจนรูปแปลงไขว้ (มีมาตั้งแต่ 2.4.4) ผ่านไปเงียบ ๆ แล้ว 💾 ลงฐานได้
        _shr = {t[0] for t in shrunk}
        bent = []
        for pid, g in sim.items():
            if pid in _shr:
                continue
            try:
                if geoms[pid].isGeosValid() and not g.isGeosValid():
                    bent.append(pid)
            except Exception:
                continue
        # ★ 2.4.5 rc7 (ผลตรวจ Windows rc6 🟡1 ข้อเสนอ ข) — ขอบติดกันพับย้อนทับกันเอง (มุมแคบ < ~1.8° ที่เดิมไม่เป็น)
        #   เช่น ลำดับหมุดบนแนวเส้นสลับ ⇒ หนามแบน · มุมปลายแถววิ่งตามขอบข้างเลยมุมข้างไป ⇒ แปลงเหลือลิ่มบาง (2.4.4–rc6 ผ่านเงียบ)
        #   GEOS ยังนับว่ารูปถูกต้อง ⇒ ข้อ ③ ไม่จับ · จับได้ทุกสาเหตุ
        _bnt = set(bent)
        spiked = []
        for pid, g in sim.items():
            if pid in _shr or pid in _bnt:
                continue
            try:
                if self._align_new_spikes(geoms[pid], g):
                    spiked.append(pid)
            except Exception:
                continue
        if not (n_coll or shrunk or bent or spiked):  # ★ 2.3.7 b13 (DI-37) — ไม่ถามเพราะระยะแล้ว (เดิม far = maxd > _addnode_max_dist())
            return True
        lines = []
        if n_coll:
            lines.append(f"• หมุดของแปลงเดียวกัน {n_coll} จุด จะไปทับกันที่ตำแหน่งเดียว (ขอบแปลงหาย/แปลงยุบ)")
        if shrunk:
            ex = min(shrunk, key=lambda t: t[2])
            lines.append(f"• พบ {len(shrunk)} แปลง ที่เนื้อที่จะหายเกินครึ่งหรือเหลือไม่ถึง 1 ตร.ม. "
                         f"(เช่น {ex[1]:,.2f} → {ex[2]:,.2f} ตร.ม.)")
        if bent:
            lines.append(f"• พบ {len(bent)} แปลง ที่รูปจะไขว้ตัวเองหรือพับ (รูปแปลงไม่ถูกต้อง — ขอบตัดกันเอง)")
        if spiked:
            lines.append(f"• พบ {len(spiked)} แปลง ที่ขอบจะพับย้อนทับกันเอง (มุมแปลงแคบไม่ถึง 2° — เป็นหนามแบน/ลิ่มบาง)")
        msg = ("ตรวจผลก่อนลงมือ พบสิ่งที่ผิดปกติ:\n\n" + "\n".join(lines)
               + f"\n\nหมุดที่จะขยับ {len(moves)} จุด · ระยะขยับไกลสุด {maxd:,.2f} ม."
               + "\n(ตำแหน่งใหม่แสดงเป็นสีส้มบนแผนที่)\n\nยืนยันทำต่อไหม?\n"
               + "• Yes = ทำต่อ (ยังไม่ลงฐาน · กด ↺ ย้อนกลับได้)\n"
               + "• No = ยกเลิก ไม่แก้อะไร (หมุดที่เลือกยังอยู่ คลิกเส้นใหม่ได้เลย)")
        canvas = self.iface.mapCanvas()
        bands = []
        try:
            try:
                rb = QgsRubberBand(canvas, QgsWkbTypes.PointGeometry)
                rb.setColor(QtGui.QColor(255, 140, 0))
                rb.setIcon(QgsRubberBand.ICON_CIRCLE)
                rb.setIconSize(10)
                rb.setWidth(2)
                bands.append(rb)
                rb.setToGeometry(QgsGeometry.fromMultiPointXY([n for _i, _o, n in moves]), point_lyr)
                for pid in ([t[0] for t in shrunk] + bent + spiked)[:50]:
                    rb2 = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
                    rb2.setColor(QtGui.QColor(255, 140, 0))
                    rb2.setFillColor(QtGui.QColor(255, 140, 0, 60))
                    rb2.setWidth(2)
                    bands.append(rb2)
                    rb2.setToGeometry(sim[pid], poly_lyr)
            except Exception:
                pass
            ans = self._ask(QtWidgets.QMessageBox.Warning, "Align — ตรวจก่อนลงมือ", msg,
                            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                            QtWidgets.QMessageBox.No)
        finally:
            for b in bands:
                try:
                    b.hide()
                    canvas.scene().removeItem(b)
                except Exception:
                    pass
        return ans == QtWidgets.QMessageBox.Yes

    def execute_point_node_alignment(self):
        # ★ 2.3.7 (review DI-10) — คู่ชั้นต้องเป็นคู่เดียวกับตอนกดปุ่ม Align (เดิมอ่านคอมโบใหม่ตอนลงมือ
        #   ⇒ คอมโบชั้นแปลงว่าง = ข้ามทั้งด่านล็อก L1 และการเชื่อมมุม)
        _pair = self._bound_pair_now("_align_lids", "Align Points")
        if _pair is None:
            return
        poly_lyr, point_lyr = _pair
        if not point_lyr:
            return
        # ★ 2.3.7 (review DI-03) — จุดของเส้นเป็นพิกัดของชั้นหมุดแล้ว (แปลงตอนคลิก) · ชั้นแปลงต้องระบบเดียวกัน
        if not self._pair_crs_ok("Align Points", poly_lyr, point_lyr):
            return

        p1, p2 = self.src_pts[0], self.src_pts[1]
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag_sq = dx**2 + dy**2
        # ★ 2.3.7 (review DI-24 / UX-02) — สองจุดของเส้นทับ/ชิดกันเกินไป: เดิม return เงียบ ⇒ บอกเหตุ + ให้คลิกใหม่
        _bad = self._check_control_points('align', [p1, p2], point_lyr)
        if _bad or mag_sq == 0:
            self.iface.messageBar().pushMessage("Align", _bad or "จุดที่ 1 กับ 2 ทับกัน — คลิกใหม่", level=1, duration=6)
            self.src_pts = []
            return

        def get_projected_pt(old_x, old_y):
            u = ((old_x - p1.x()) * dx + (old_y - p1.y()) * dy) / mag_sq
            return QgsPointXY(p1.x() + u * dx, p1.y() + u * dy)

        # ===== หมุดที่จะ align = หมุดที่เลือกด้วยกล่อง (box-select) =====
        picked = getattr(self, "_align_picked_ids", None)
        if picked:
            target_points = list(point_lyr.getFeatures(
                QgsFeatureRequest().setFilterFids(list(picked))))
        else:
            target_points = list(point_lyr.selectedFeatures())   # fallback: หมุดที่ select ไว้

        if not target_points:
            # ★ 2.3.7 (review UX-02) — เดิมบอก "ลากกล่องครอบหมุดก่อน" ทั้งที่เครื่องมือกล่องหายไปแล้ว
            #   (หมุดที่เลือกไว้ถูกลบ/ถูกย้อนกลับระหว่างขั้น ②) ⇒ บอกตามจริง แล้วเริ่มขั้น ① ให้ใหม่
            self.iface.messageBar().pushMessage(
                "Align", "หมุดที่เลือกไว้ไม่มีอยู่แล้ว (ถูกลบหรือถูกย้อนกลับ) — เริ่มเลือกหมุดใหม่: ลากกล่องครอบหมุด",
                level=1, duration=8)
            self.start_align_tool()
            return

        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in (point_lyr, poly_lyr) if lyr}

        # weld node แปลงแบบ junction-aware (วัดระยะจาก "หมุดที่เลือก" -> node แปลง)
        #   ≤ AUTO_TOL      : ร่วมมุมแน่ -> รวมเข้าหมุดอัตโนมัติ (junction หลายแปลงรวมเป็นจุดเดียว)
        #   AUTO_TOL-ASK_TOL: น่าจะร่วมมุมแต่ไม่ snap -> เก็บไว้ถาม (popup ครั้งเดียว)
        #   > ASK_TOL       : คนละมุม/แปลงไม่เกี่ยว -> ไม่แตะ
        # (ค่า default จากการวัด data จริง: 74% ของมุมร่วม snap ≤2มม. • ปรับเป็น setting ได้ภายหลัง)
        s = QtCore.QSettings()
        AUTO_TOL = s.value("MultiLayerEditPro/Align/AutoMergeTol", 0.03, float)
        ASK_TOL = s.value("MultiLayerEditPro/Align/AskTol", 0.30, float)

        # ===== Prefetch ครั้งเดียว: แปลงรอบหมุดทั้งหมด + ตาราง UTM ล็อก =====
        # (เดิม _side_edge_dir + weld PASS 3 + เช็คล็อก ยิง query ต่อหมุด — บน PostgreSQL = N round-trips)
        poly_cache = (self._prefetch_align_polys(poly_lyr, target_points, max(1.0, ASK_TOL))
                      if poly_lyr else None)
        locked_map = self._locked_map_or_block(poly_lyr, "Align Points") if poly_lyr else {}   # ★ 2.3.7 (PF-01)
        if locked_map is None:
            return

        # ★ 2.3.7 (review DI-37) — เปิดคำสั่งแก้ไขหลัง "คำนวณ + ตรวจแผน + ถาม" ครบแล้วเท่านั้น (ย้ายลงไปหลัง PASS 1)
        #   เดิม _op_begin + beginEditCommand อยู่ตรงนี้ แล้ว PASS 2 เขียนทันที — ไม่มีจังหวะตรวจ/ถามก่อนแตะชั้น
        _opened = False
        _n_pt_w = _n_vx_w = _welded_mk = 0     # ★ 2.3.7 (review DI-28) นับการเขียนจริงต่อชั้น
        _skip_l1 = {}                          # ★ 2.3.7 (review UX-01 ข้อ 6) {ชนิดแปลง: จำนวนหมุดที่ข้ามเพราะล็อก}
        _skip_twin = set()                     # ★ 2.3.7 (audit F6) มุม (pid, vidx) ของแปลงที่ UTM ตรงกับแปลง L1 — ไม่ดึง
        _skip_mk_l1 = set()                    # ★ 2.4.0 (DU-01) มุม (pid, vidx) ที่มีหมุดล็อก (เช่นหมุด Type L1) ของแปลงนั้น — ไม่ดึง
        _ล็อก_utm = locked_map if (locked_map and not self._l1_unlocked()) else {}     # ★ F6 ด่านซ้ำตอนลากหมุด
        _ok_done = False
        try:
            # ===== PASS 1: คำนวณตำแหน่งใหม่ของทุกหมุดจาก geometry "เดิม" (ก่อนแก้ไขใดๆ) =====
            moves = []   # [(pt_id, old_xy, new_pt)]
            calc_cache = {}  # Cache เพื่อให้หมุดที่ซ้อนกัน (ห่างไม่เกินมิลลิเมตร) ได้ค่า new_pt เดียวกัน
            # ★ 2.3.9 — ตำแหน่งหมุดที่เลือกทั้งหมด (ใช้ตัดขอบที่หมุดที่เลือกครอบสองฝั่งออกจากแนววิ่ง · ดู _side_edge_dir)
            _picked_xy = []
            for _f in target_points:
                try:
                    _q = _f.geometry().asPoint()
                    _picked_xy.append((_q.x(), _q.y()))
                except Exception:
                    pass
            # ★ 2.4.0 (review DU-01) — กติกาเดียว (_marker_locked): Type ของหมุดเอง หรือ UTM ตรงแปลง L1
            #   เดิมตรวจเฉพาะ UTM และข้ามทั้งด่านเมื่อชั้นไม่มีแปลง L1 ⇒ หมุด Type L1 ที่ UTM ว่าง/ไม่ตรงแปลง L1 ถูก Align ย้าย
            _a_uf = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            _a_ti = self._field_index(point_lyr.fields(), 'type')
            for pt_f in target_points:
                old_xy = pt_f.geometry().asPoint()
                # ข้ามถ้าหมุดล็อก (หมุด L1 หรือหมุดของแปลงที่ล็อก)
                is_locked, type_str = self._marker_locked(pt_f, locked_map, _a_uf, _a_ti)
                if is_locked:   # ★ admin: ให้ Align ย้ายหมุด L1 ได้ (ปลดล็อกแล้ว _marker_locked คืนไม่ล็อก)
                    # ★ 2.3.7 (review UX-01 ข้อ 6 · ER-06) — นับไว้ แล้วสรุปเป็นข้อความเดียวท้ายงาน
                    #   เดิมแถบแดง 1 แถบต่อหมุด (เลือก 200 ดวง = 200 แถบ) และบอกด้วย fid
                    _skip_l1[type_str or "L1"] = _skip_l1.get(type_str or "L1", 0) + 1
                    continue

                key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
                if key in calc_cache:
                    new_pt = calc_cache[key]
                else:
                    # ย้ายตามแนวขอบข้าง (คงมุมขอบที่ต่อหมุดที่ไม่ได้เลือก) -> ถ้าทำไม่ได้ฉายตั้งฉาก
                    new_pt = self._align_new_point(old_xy, poly_cache, p1, dx, dy, get_projected_pt, _picked_xy)
                    calc_cache[key] = new_pt
                    
                moves.append((pt_f.id(), old_xy, new_pt))

            # ===== ★ 2.3.7 (review DI-37) ตรวจแผนก่อนแตะชั้น: หมุดแปลงเดียวกันไปรวมจุดเดียว · แปลงยุบ (ไม่ถามเรื่องระยะ — b13) =====
            _weld_auto, _weld_ask = (self._align_weld_candidates(moves, poly_cache, AUTO_TOL, ASK_TOL,
                                                                 locked=locked_map, skipped=_skip_twin)   # ★ F6
                                     if (poly_lyr and poly_cache) else ([], []))
            # ★ 2.3.7 (review ER-03) — ดัชนีหมุดรอบมุมที่จะเชื่อม อ่าน "ก่อน" เปิดคำสั่งแก้ไข (อ่านอย่างเดียว · ผลเท่าอ่านหลัง PASS 2:
            #   หมุดที่ PASS 2 ย้ายถูกข้ามด้วย _already อยู่แล้ว) · อ่านไม่ได้ทั้งที่มีมุมต้องเชื่อม ⇒ ไม่ทำทั้งงาน (fail-closed)
            #   เดิม _mk_idx = {} แล้ว weld ต่อ ⇒ มุมของแปลงข้างเคียงถูกลากไปแต่หมุดของมันไม่ตาม = มุมเปลือย + หมุดลอย (กติกาเหล็ก)
            #   (ข้ามแค่ PASS 3 ไม่ได้: PASS 3 ลากมุมของแปลงที่หมุดถูกเลือกด้วย — ข้ามแล้วมุมแปลงไม่ตามหมุดที่ย้าย)
            # ★ 2.4.0 (review DU-01) — อ่านก่อนตรวจแผน (คิวรีเดิม ย้ายขึ้นมา) พร้อมจดหมุดที่ล็อก (_marker_locked) รอบมุมที่จะเชื่อม
            #   มุมที่มีหมุดล็อกของแปลงนั้นนั่งอยู่ ⇒ ไม่ดึงทั้งมุม (มุมกับหมุดอยู่ที่เดิมคู่กัน แบบมุมแฝด F6)
            #   เดิมดึงมุมแล้วลากหมุด Type L1 ที่ UTM ไม่ตรงแปลง L1 ตามไปด้วย
            _mk_idx, _mk_lock = {}, set()
            if poly_lyr and poly_cache and (_weld_auto or _weld_ask):
                try:
                    _mk_idx = self._align_marker_index(point_lyr, poly_cache.get('rect'),
                                                       locked=_mk_lock, lock_map=locked_map)
                except Exception:
                    _log_exc("Align: อ่านหมุดรอบมุมที่ต้องเชื่อมไม่ได้ — ยกเลิก ยังไม่ได้แก้อะไร", Qgis.Critical)
                    self.iface.messageBar().pushMessage(
                        "Align", "อ่านหมุดรอบมุมแปลงที่ต้องเชื่อมไม่ได้ — ยกเลิก ยังไม่ได้ย้ายอะไร (กันมุมแปลงข้างเคียง"
                                 "ถูกลากไปโดยหมุดไม่ตาม) · คลิกเส้นใหม่เพื่อลองอีกครั้ง · " + self._LOG_HINT,
                        level=2, duration=0)
                    return                 # ยังไม่เปิดคำสั่งแก้ไข ⇒ ไม่มีอะไรต้องย้อน · หมุดที่เลือกยังอยู่
            if _mk_lock:
                _weld_auto, _weld_ask, _ชน = self._align_drop_locked_corners(
                    _weld_auto, _weld_ask, poly_cache, _mk_idx, _mk_lock, {m for m, _o, _n in moves}, _skip_mk_l1)
                if _ชน:
                    self.iface.messageBar().pushMessage(
                        "Align", f"หมุดที่เลือกบางดวงนั่งอยู่บนมุมเดียวกับหมุด L1 ({_ชน:,} มุม) — ย้ายหมุดแล้วมุมแปลงตามไปไม่ได้ "
                                 "(หมุด L1 ห้ามขยับ) · ยกเลิก ยังไม่ได้ย้ายอะไร — เลือกหมุดใหม่โดยไม่รวมมุมนั้น",
                        level=1, duration=10)
                    return                 # ยังไม่เปิดคำสั่งแก้ไข ⇒ ไม่มีอะไรต้องย้อน · หมุดที่เลือกยังอยู่
            if not self._align_plan_ok(moves, target_points, point_lyr, poly_lyr, poly_cache,
                                       _weld_auto + [(a, b, c) for a, b, c, _d in _weld_ask]):
                return                     # No = ไม่แตะชั้นใดเลย · หมุดที่เลือกยังอยู่ คลิกเส้นใหม่ได้
            # ★ 2.4.0 (review DI-15) — เปิดโหมดแก้ไขทั้งชั้นหมุดและชั้นแปลงก่อนเปิดคำสั่ง (เดิมไม่ดูผล ⇒ ชั้นแปลงเปิดไม่ได้
            #   = หมุดย้ายแต่มุมแปลงไม่ตาม เงียบ ๆ · ผิดกติกาเหล็ก) · เปิดไม่ได้ = ไม่แตะชั้นใดเลย
            if not self._ensure_editing(point_lyr, poly_lyr, title="Align", what="ยังไม่ได้ย้ายอะไร"):
                return                     # ยังไม่เปิดคำสั่งแก้ไข ⇒ ไม่มีอะไรต้องย้อน · หมุดที่เลือกยังอยู่
            self._op_begin([point_lyr, poly_lyr])   # เริ่มนับ undo-step ต่อเลเยอร์
            point_lyr.beginEditCommand("Align Points to Line")
            if poly_lyr:
                poly_lyr.beginEditCommand("Align Nodes to Line")
            _opened = True

            # ===== PASS 2: ขยับหมุดทั้งหมด =====
            for pt_id, old_xy, new_pt in moves:
                # ★ 2.3.7 (review DI-28) — เดิมไม่ดูผล: หมุดไม่ขยับแต่มุมแปลงถูกดึงตาม = หลุดคู่ ⇒ ล้ม = ย้อนทั้งชุด
                if not point_lyr.changeGeometry(pt_id, QgsGeometry.fromPointXY(new_pt)):
                    raise RuntimeError(f"ย้ายหมุด {pt_id} ไม่สำเร็จ")
                _n_pt_w += 1

            # ===== PASS 3: weld node ของ polygon (junction-aware) =====
            # ใช้ spatial index จาก poly_cache ที่ prefetch ไว้ (เดิมยิง query ต่อหมุด)
            if poly_lyr and poly_cache:
                # รวบรวมผู้สมัคร: node แปลง -> (จุดปลายทาง, ระยะถึงหมุดที่ใกล้สุด)
                # ★ 2.3.7 (review DI-37) คิดไว้แล้วก่อนเปิดคำสั่งแก้ไข (_align_weld_candidates · snapshot เดียวกัน ผลเดิม)
                auto, ask = _weld_auto, _weld_ask

                # ★ หมุดของ "แปลงเพื่อนบ้าน" ต้องตามมุมไปด้วย (2026-08-06)
                #   เดิม weld ลากมุมของแปลง B ไปที่ตำแหน่งใหม่ของหมุดแปลง A แต่ไม่ขยับหมุดของ B เอง
                #   -> มุม B ไม่มีหมุดทับ + หมุด B ค้างอยู่จุดเก่า = ผิดกติกาเหล็กสองด้านพร้อมกัน
                # (_mk_idx อ่านไว้แล้วก่อนเปิดคำสั่งแก้ไข — ★ 2.3.7 ER-03)
                _already = {pt_id for pt_id, _o, _n in moves}      # หมุดที่ PASS 2 ย้ายไปแล้ว
                _welded_mk = 0

                def _drag_pair_markers(pid, vi, npt):
                    """ย้ายหมุด "ของแปลง pid" ที่นั่งอยู่บนมุมเดิม vi ไปที่ npt ด้วย"""
                    nonlocal _welded_mk
                    g0 = poly_cache['geoms'].get(pid)          # snapshot ก่อนแก้ -> ได้พิกัดมุมเดิม
                    u = poly_cache.get('utm', {}).get(pid, "")
                    if g0 is None or not u:
                        return
                    try:
                        v0 = g0.vertexAt(vi)
                    except Exception:
                        return
                    if u in _ล็อก_utm:
                        return                                  # ★ 2.3.7 (audit F6) หมุดของ UTM ที่ล็อก (แฝดกับแปลง L1) ห้ามลาก
                    for mid in self._align_markers_near(_mk_idx, v0.x(), v0.y(), u):   # ★ 2.3.7 (audit F5) ระยะ ≤ 1 มม.
                        if mid in _already:
                            continue                            # ถูกย้ายไปแล้วใน PASS 2
                        if point_lyr.changeGeometry(mid, QgsGeometry.fromPointXY(npt)):
                            _already.add(mid)
                            _welded_mk += 1

                # 3a: รวมอัตโนมัติ (≤ AUTO_TOL) — junction หลายแปลงไปจุดเดียว ปิด gap
                for pid, vi, npt in auto:
                    # ★ ลากหมุดคู่เฉพาะเมื่อมุมถูกย้ายสำเร็จจริง (ไม่งั้นหมุดวิ่งไปแต่มุมอยู่ที่เดิม)
                    if poly_lyr.moveVertex(npt.x(), npt.y(), pid, vi):
                        _n_vx_w += 1               # ★ 2.3.7 (DI-28)
                        _drag_pair_markers(pid, vi, npt)

                # 3b: มุมที่ใกล้แต่ไม่ snap -> popup ถามครั้งเดียว ว่าจะรวมให้ไหม
                if ask:
                    ds = [d for *_, d in ask]
                    msg = (f"พบ {len(ask)} มุมแปลงที่อยู่ใกล้หมุดแต่ไม่ snap "
                           f"(เหลื่อม {min(ds)*100:.1f}–{max(ds)*100:.1f} ซม.)\n\n"
                           "ต้องการ 'รวม' มุมเหล่านี้เข้ากับหมุดด้วยไหม?\n"
                           "• Yes = รวมให้ (ปิด gap ที่มุมร่วม)\n"
                           "• No = ปล่อยไว้ (ขยับเฉพาะมุมที่ snap สนิท)")
                    ans = self._ask(
                        QtWidgets.QMessageBox.Question, "พบมุมแปลงไม่ snap", msg,
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                        QtWidgets.QMessageBox.No)
                    if ans == QtWidgets.QMessageBox.Yes:
                        for pid, vi, npt, _d in ask:
                            if poly_lyr.moveVertex(npt.x(), npt.y(), pid, vi):
                                _n_vx_w += 1       # ★ 2.3.7 (DI-28)
                                _drag_pair_markers(pid, vi, npt)

                # (★ 2.3.7 UX-01 ข้อ 6 — จำนวนหมุดของแปลงข้างเคียงที่ตามมุมไป รวมในข้อความสรุปท้ายงาน)

            # ปิด Command ทั้งสองเลเยอร์ — ★ 2.3.7 (review DI-28) ชั้นที่ไม่ได้เขียนอะไรเลย = ทิ้งคำสั่ง
            #   (เดิม endEditCommand เสมอ ⇒ undo step เปล่า ชั้นกลายเป็น "มีการแก้ไข" และ ↺ ไปย้อนงานผี)
            #   หมุดที่ถูกลากตามมุม (_welded_mk) นับเป็นการเขียนชั้นหมุดด้วย
            if _n_pt_w + _welded_mk:
                point_lyr.endEditCommand()
            else:
                point_lyr.destroyEditCommand()
            if poly_lyr:
                if _n_vx_w:
                    poly_lyr.endEditCommand()
                else:
                    poly_lyr.destroyEditCommand()
            self._op_commit()   # ปิด operation -> เก็บประวัติ undo
            _ok_done = True

        except Exception:
            if _opened:                    # ★ 2.3.7 (DI-37) ยังไม่เปิดคำสั่งแก้ไข = ไม่มีอะไรต้องย้อน
                point_lyr.destroyEditCommand()
                if poly_lyr: poly_lyr.destroyEditCommand()
                self._op_commit()   # เคลียร์ baseline
            # ★ 2.3.7 (review ER-06) — ข้อความไทยบอกผลจริง + traceback ลง Log แท็บ MLEP
            #   (เดิมหัวข้อ 'Align Error' + ข้อความ exception ดิบ · Log มีแค่ข้อความเดียวไม่มี traceback)
            self._fail("Align", ("ย้ายหมุดไม่สำเร็จ — ยกเลิกทั้งชุดแล้ว (หมุดและมุมแปลงกลับเหมือนก่อนกด)" if _opened
                                 else "ย้ายหมุดไม่สำเร็จ — ยังไม่ได้แก้อะไร"), "ลองใหม่อีกครั้ง")
        # ★ 2.3.7 (review UX-01 ข้อ 6) — สรุปข้อความเดียว: หมุดของแปลงข้างเคียงที่ตามมุม · หมุดของแปลงล็อกที่ข้าม
        _sum = []
        if _ok_done and _welded_mk:
            _sum.append(f"ย้ายหมุดของแปลงข้างเคียงตามมุมที่เชื่อมด้วย {_welded_mk} จุด (กันมุมไม่มีหมุด/หมุดลอย)")
        if _ok_done and _skip_l1:
            _sum.append("ข้ามหมุด L1 / หมุดของแปลงที่ล็อก " + " · ".join(f"{t} {n:,} ดวง" for t, n in sorted(_skip_l1.items()))
                        + " — ไม่ได้ย้าย")
        if _ok_done and _skip_twin:            # ★ 2.3.7 (audit F6)
            _sum.append(f"ข้ามมุมของแปลงที่ใช้ UTM เดียวกับแปลงล็อก L1 {len(_skip_twin):,} มุม (มุมและหมุดอยู่ที่เดิม) — ไม่ได้ย้าย")
        if _ok_done and _skip_mk_l1:           # ★ 2.4.0 (review DU-01)
            _sum.append(f"ข้ามมุมแปลงที่มีหมุด L1 {len(_skip_mk_l1):,} มุม (มุมและหมุดอยู่ที่เดิม) — ไม่ได้ย้าย")
        if _sum:
            self.iface.messageBar().pushMessage("Align", " · ".join(_sum),
                                                level=1 if (_skip_l1 or _skip_twin or _skip_mk_l1) else 0,
                                                duration=8)

        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.canvas.refresh()
        self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)
