# -*- coding: utf-8 -*-
"""ชุดที่เลือก: แปลงที่เลือก → หมุดคู่ (process_selection)

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.core import QgsExpression, QgsFeatureRequest, QgsProject
from ..core.util import _UTM_FIELD_NAMES


class SelectionMixin:
    """ชุดที่เลือก: แปลงที่เลือก → หมุดคู่ (process_selection)"""

    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        # ★ 2.4.0 (review PF-05) — คืนเฉพาะชั้นที่ selection เปลี่ยนไปจริง + ไม่สั่ง canvas.refresh() ท้ายฟังก์ชันแล้ว
        #   เดิม selectByIds ชุดเดิมซ้ำ (ยิง selectionChanged ⇒ repaint) + refresh ทั้งแผนที่ทุกครั้ง 100 ms หลังจบงาน
        #   ⇒ ชั้นแปลง/หมุดที่อยู่ในโหมดแก้ไข (ไม่มี render cache) ถูกวาดใหม่ทั้งจอรอบที่ 2 ต่อ operation
        #   ภาพหลังแก้ไม่หาย: QGIS 3.40 สั่ง repaint ชั้นเองทุกครั้งที่ endEditCommand/แก้ค่า/แก้รูป/undo
        #   (ทดสอบแล้วทั้ง memory · PostgreSQL รวมงานที่แก้แค่ attribute: หมายเหตุ/NAME/AUDIT/cluster_id/SCORE)
        #   ส่วน selection ที่หายจริง selectByIds ยัง repaint ชั้นนั้นให้เอง (ไฮไลต์กลับมาเหมือนเดิม)
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                try:
                    if set(lyr.selectedFeatureIds()) == set(ids):
                        continue
                except Exception:
                    pass
                lyr.selectByIds(ids)

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def process_selection(self, mode, hint=None):
        """hint = เครื่องมือที่เรียก (★ rc1 F8 · §5.1 DI-01: "modify_node" ⇒ แถบ "ไม่มีค่า UTM" บอกว่าลากกรอบที่มุมยังได้หมุดบนมุม)"""
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        selected_ids = poly_layer.selectedFeatureIds()
        if not selected_ids: return

        # ★ ข้ามงานซ้ำเมื่อ "สิ่งที่เลือกไม่เปลี่ยน" (2026-08-06) — วัดจริง 104-171 ms ต่อครั้ง
        #   ถูกเรียกตอน "เริ่ม" ทุกเครื่องมือ (Move/Rotate/Scale/Transform/Score/Cluster/Move Node)
        #   ทำงานซ้ำบนกลุ่มเดิมจึงจ่ายค่านี้ซ้ำโดยไม่ได้อะไรเพิ่ม · ผลลัพธ์เหมือนเดิมทุกประการ จึงข้ามได้ปลอดภัย
        _key = None
        try:
            # ★ ต้องเทียบ "ตัวตน" ของหมุดที่เลือก ไม่ใช่จำนวน (2026-08-06 release gate)
            #   ถ้าใช้จำนวน: เปลี่ยนชุดหมุดเป็นชุดใหม่ที่ 'จำนวนเท่ากัน' จะถูกมองว่าเหมือนเดิม -> ไม่แก้ให้
            _key = (poly_layer.id(), point_layer.id() if point_layer else None,
                    mode, frozenset(selected_ids),
                    frozenset(point_layer.selectedFeatureIds()) if point_layer else None,
                    self._procsel_fp(poly_layer, point_layer))      # ★ 2.3.7 (DI-06) รุ่นของข้อมูล
            if getattr(self, "_procsel_key", None) == _key:
                return
        except Exception:
            _key = None
        
        fields = poly_layer.fields()
        target_names = (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])
        target = None
        target_idx = -1
        for i, field in enumerate(fields):
            if field.name().lower() in target_names:
                target = field.name()
                target_idx = i
                break
        if target_idx == -1:
            # ★ 2.3.7 (review DI-06) — ชั้นแปลงไม่มีคอลัมน์คีย์: เดิม return เงียบ ⇒ หมุดที่เลือกค้าง (ของกลุ่มก่อน)
            #   ถูก Score/Cluster/ขยับตามไปด้วย ⇒ ล้างฝั่งหมุด + บอก
            self._procsel_no_key(point_layer, "ชั้นแปลงไม่มีคอลัมน์ " + ("Cluster ID" if mode == 'cluster' else "UTM"))
            return
        
        # Optimize: ดึงเฉพาะข้อมูล Attribute ของฟิลด์ที่กำหนดโดยไม่ดึงพิกัดเพื่อประหยัดหน่วยความจำ
        req = QgsFeatureRequest().setFilterFids(selected_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([target_idx])
        vals = set()
        for f in poly_layer.getFeatures(req):
            val = f.attribute(target_idx)
            # ★ NULL จาก provider ไม่ใช่ Python None เสมอไป (PyQt5 ส่งเป็น QVariant ว่าง) (2026-08-06)
            #   เดิมเช็คแค่ `is not None` -> ค่า NULL ลอดเข้าไปเป็นสตริง 'NULL' ในลิสต์ IN(...)
            #   ทำให้ได้เงื่อนไขที่ไม่มีวันตรงกับใคร (และรบกวนการเลือกทั้งชุด)
            if val is None:
                continue
            _sv = str(val).strip()
            if not _sv or _sv.upper() in ("NULL", "NONE", "NAN"):
                continue
            # quotedValue escape ค่าให้ถูกต้อง (เดิมต่อ string เอง -> ค่าที่มี ' ทำ expression พัง)
            vals.add(QgsExpression.quotedValue(_sv))

        if vals:
            _in_list = ",".join(sorted(vals))      # OPT: sort+join ครั้งเดียว ใช้ทั้งสองเลเยอร์
            expr = f'{QgsExpression.quotedColumnRef(target)} IN ({_in_list})'
            with self._busy("select-utm"):          # ★ 2.3.7 (review PF-03)
                poly_layer.selectByExpression(expr)
            if point_layer:
                # ★ ชั้นหมุดอาจใช้ชื่อ field ต่างจากชั้นแปลง (utm vs utm_code)
                #   เดิมยิง expression ของชั้นแปลงใส่ตรง ๆ -> field ไม่ตรง = selection หมุดถูกล้างเงียบ
                #   เลือกชื่อเดียวกับฝั่งแปลงก่อน (กันเคสชั้นหมุดมีหลาย field เข้าข่าย
                #   เช่นมีทั้ง utm_id (เลขรัน) กับ utm (รหัสระวาง) แล้วสุ่มได้ตัวผิดตามลำดับ schema)
                _cand = (_UTM_FIELD_NAMES if mode != 'cluster'
                         else {'cluster_id', 'clusterid', 'id_cluster'})
                _ptf = next((fl.name() for fl in point_layer.fields()
                             if fl.name().lower() == target.lower()), None) \
                       or self._resolve_field(point_layer, _cand)
                if _ptf:
                    with self._busy("select-utm-pt"):   # ★ 2.3.7 (review PF-03)
                        point_layer.selectByExpression(
                            f'{QgsExpression.quotedColumnRef(_ptf)} IN ({_in_list})')
                else:
                    # หา field ไม่ได้ -> ล้าง selection ฝั่งหมุด (พฤติกรรมเดิมก่อน 1.9.5)
                    # ห้ามปล่อยค้าง: Score/Cluster เขียนใส่ "ทุกหมุดที่ถูกเลือกอยู่" —
                    # selection เก่าที่ไม่เกี่ยวจะโดนเขียนทับเงียบ ๆ
                    point_layer.removeSelection()
                    # ★ 2.3.7 rc3 (เจ้าของงานตัดสิน 5 ต.ค. 69) — โหมด ClusterID: ชั้นหมุดในฐานจริงไม่มีคอลัมน์ cluster id เลย
                    #   ⇒ แถบเหลืองนี้ขึ้นทุกครั้งที่กด (DI-06 ไม่จำผลแล้ว · 2.3.6 ขึ้นแค่ครั้งแรก) ทั้งที่เป็นเรื่องปกติ ⇒ เงียบ
                    #   ยังล้างหมุดที่เลือกและไม่จำผลเหมือนเดิม · โหมด UTM (เครื่องมืออื่น / คีย์ลัด by_utm) ยังเตือนเหมือนเดิม
                    if mode != 'cluster':
                        self.iface.messageBar().pushMessage(
                            "MLEP", f"ชั้นหมุด '{point_layer.name()}' ไม่มีคอลัมน์ UTM/Cluster "
                                    "ที่รู้จัก — ไม่ได้เลือกหมุดให้", level=1, duration=6)
                    _key = None     # ★ 2.3.7 (DI-06) ไม่จำผลนี้ — เดิมกดครั้งที่ 2 เป็นต้นไปเงียบสนิท
            self.iface.mapCanvas().refresh()
            # จำสถานะปลายทางไว้ (รวมจำนวนหมุดที่เพิ่งเลือก) -> รอบหน้าที่เหมือนเดิมจะข้ามทั้งก้อน
            if _key is not None:
                try:
                    # เก็บ "สถานะหลังขยาย selection แล้ว" (ทั้งสองชั้น) — รอบหน้าที่เข้ามาด้วยสถานะนี้
                    # จะข้ามได้ถูกต้อง · เก็บจากค่าปัจจุบันจริง ไม่ reuse ค่าก่อนขยาย
                    self._procsel_key = (poly_layer.id(),
                                         point_layer.id() if point_layer else None, mode,
                                         frozenset(poly_layer.selectedFeatureIds()),
                                         frozenset(point_layer.selectedFeatureIds()) if point_layer else None,
                                         self._procsel_fp(poly_layer, point_layer))
                except Exception:
                    self._procsel_key = None
        else:
            # ★ 2.3.7 (review DI-06) — แปลงที่เลือกไม่มีค่าคีย์สักแปลง (NULL/ว่าง): เดิมไม่ทำอะไร ⇒ หมุดของกลุ่มก่อน
            #   ที่ค้างอยู่ถูก Score/Cluster/ขยับไปด้วยเงียบ ๆ ⇒ ล้างฝั่งหมุด + บอก
            #   (Move/Rotate/Scale/Transform จะถูกด่าน "หมุดไม่ถูกเลือกสักตัว" หยุดต่อ · Score ที่เลือกแต่หมุดไม่ผ่านทางนี้)
            self._procsel_no_key(point_layer, "แปลงที่เลือกไม่มีค่า " + ("Cluster ID" if mode == 'cluster' else "UTM"),
                                 hint=hint)

    def _procsel_no_key(self, point_layer, why, hint=None):
        """★ 2.3.7 (review DI-06) — จับคู่หมุดไม่ได้ ⇒ ไม่ปล่อย selection ฝั่งหมุดค้าง (ของกลุ่มก่อน) + บอก · ไม่จำผล"""
        self._procsel_key = None
        if point_layer is not None:
            try:
                if point_layer.selectedFeatureCount():
                    point_layer.removeSelection()
            except Exception:
                pass
        # ★ rc1 (F8 · §5.1 DI-01) — Move Node: ลากกรอบที่มุมของแปลงที่ไม่มี UTM ยังได้หมุดบนมุมนั้น (DI-01) ⇒ เดิมแถบนี้ทำให้เข้าใจผิด
        _h = (" (ลากกรอบครอบมุมของแปลงนี้ จะได้หมุดที่อยู่บนมุมนั้นไปด้วยตามปกติ)"
              if hint == "modify_node" and "UTM" in why else "")
        self.iface.messageBar().pushMessage("MLEP", f"{why} — ไม่ได้เลือกหมุดให้{_h}", level=1, duration=6)

    def _procsel_fp(self, *layers):
        """★ 2.3.7 (review DI-06) — "รุ่นของข้อมูล" ของชั้นแปลง/หมุด สำหรับคีย์ cache ของ process_selection
        เดิมคีย์มีแค่ selection ⇒ Add Node / ลบ Node / 🍩 / ↺ Undo / บันทึก ที่เพิ่ม-ลบ-คืนหมุดโดย selection ไม่เปลี่ยน
        ⇒ ข้ามงาน แล้วใช้ชุดหมุดเดิม (หมุดใหม่ไม่ถูกเลือก = ไม่ขยับตามแปลง)
        ทุกการแก้ไขผ่าน undo stack ของชั้น ⇒ ใช้ตำแหน่ง/ขนาด stack + ตัวคำสั่งบนสุด + จำนวนครั้งที่บันทึก
        (ไม่ต้องไปล้าง cache ในทุกฟังก์ชันที่แก้ข้อมูล) · อ่านไม่ได้ = ค่าที่ไม่มีวันตรง (ไม่ข้ามงาน)"""
        out = []
        for lyr in layers:
            if lyr is None:
                out.append(None)
                continue
            try:
                st = lyr.undoStack()
                i = st.index() if st is not None else -1
                n = st.count() if st is not None else -1
                top = None
                if st is not None and i > 0:
                    from qgis.PyQt import sip as _sip
                    c = st.command(i - 1)
                    top = _sip.unwrapinstance(c) if c is not None else None
                out.append((lyr.isEditable(), i, n, top, self._commit_seq.get(lyr.id(), 0)))
            except Exception:
                out.append(object())
        return tuple(out)
