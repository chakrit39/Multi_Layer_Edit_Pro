# -*- coding: utf-8 -*-
"""สัญญาณโปรเจกต์/แคนวาส: เปลี่ยน-อ่าน-เขียนโปรเจกต์, ชั้นถูกลบ, เครื่องมือแผนที่เปลี่ยน, เตือนงานค้างไม่บันทึก

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import os
import time
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import Qgis, QgsMessageLog, QgsPointLocator, QgsProject
from ..core.util import _log_exc, _log_msg_once
from ..ui.qt_helpers import _OWN_PROP


class ProjectHooksMixin:
    """สัญญาณโปรเจกต์/แคนวาส: เปลี่ยน-อ่าน-เขียนโปรเจกต์, ชั้นถูกลบ, เครื่องมือแผนที่เปลี่ยน, เตือนงานค้างไม่บันทึก"""

    def _own_tok(self):
        """★ 2.3.7 (audit LIFE-04) — token ของ instance นี้ = ค่าป้าย _mlep_owner บนของที่สร้างบนหน้าต่างหลัก"""
        t = getattr(self, "_own_token", None)
        if not t:
            t = self._own_token = "mlep-%x" % id(self)
        return t

    def _tag_own(self, obj):
        """★ 2.3.7 (audit LIFE-04) — ติดป้ายของ MLEP (ให้ _mlep_debris_clear หาเจอถ้า instance นี้ตายโดยไม่ได้ unload)"""
        try:
            obj.setProperty(_OWN_PROP, self._own_tok())
        except Exception:
            pass

    def _on_project_reset(self, *_a):
        """โปรเจกต์กำลังถูกล้าง/เปลี่ยน — เก็บชั้นชั่วคราวและล้าง cache

        ★★ 2 ก.ย. 69 (จาก audit) — เดิมเก็บแค่ชั้นกับ cache ยังเหลือของโปรเจกต์เก่าอีก 2 อย่าง
          ① ค่า snapping ที่ "ยืม" ไว้ — เป็นของโปรเจกต์เก่า ถ้าไม่ปล่อย เดี๋ยว
             _line_snap_return จะเอาไปทับโปรเจกต์ใหม่ (ปิด snap ให้อำเภอใหม่ทั้งที่ไม่เกี่ยวกัน)
             🔴 ต้อง "ทิ้ง" เฉย ๆ ห้ามเรียก _line_snap_return เพราะนั่นจะไปเขียนค่าลง
                โปรเจกต์ที่กำลังถูกล้างอยู่พอดี
          ② เส้นที่วาดไว้ของอำเภอเดิม — เป็นพิกัดของพื้นที่เดิม ถ้าไม่ล้าง คลิกแรก
             ในโปรเจกต์ใหม่จะยัดมันกลับเข้าไปเป็นชั้นของอำเภอใหม่ทันที
        """
        # ★ 2.3.0 — ด่าน `_alive` ให้เหมือนสล็อตของ QTimer
        #   QgsProject.instance() เป็น singleton ที่อยู่ยาวกว่าปลั๊กอิน และปลั๊กอิน
        #   อัปเดตตัวเองกลางเซสชันได้ ⇒ instance เก่าที่ตายแล้วต้องไม่ไปแตะของ instance ใหม่
        #   (unload() ถอด signal ทั้งสี่อยู่แล้ว — ข้อนี้เป็นเกราะชั้นสองสำหรับจังหวะที่ถอดไม่ทัน)
        if not getattr(self, "_alive", True):
            return
        # ★ 2.3.7 (review DI-09) — โหมดผู้ช่วย/ผู้ดูแล (ลบ Node = ลบทั้งหมด) + ปลดล็อก L1 เดิมติดข้ามไปอำเภอใหม่เงียบ ๆ
        #   ⇒ ออกจากโหมดทุกครั้งที่เปลี่ยน/โหลดโปรเจกต์ (เข้าใหม่ด้วยคีย์ลัด = ถามสิทธิ์กับคอนเนกชันใหม่)
        if getattr(self, "_admin_on", False) or getattr(self, "_admin_unlock_l1", False):
            try:
                self._set_admin_mode(False)
                self.iface.messageBar().pushMessage(
                    "MLEP", "ออกจากโหมดพิเศษแล้ว เพราะเปลี่ยน/โหลดโปรเจกต์ใหม่", level=0, duration=6)
            except Exception:
                pass
        self._line_snap_borrowed = False
        self._line_wrote_snap = None
        # ★★ 2 ก.ย. 69 — ต้องลืมรายชื่อชั้นของ "อำเภอเดิม" ด้วย
        #   ไม่งั้นชั้นของอำเภอใหม่ทุกชั้นจะถูกนับว่า "เพิ่งโผล่มาใหม่" แล้วถูกปิด snap ให้เงียบ ๆ
        #   รวมทั้งชั้นอ้างอิงที่หน่วยงานตั้ง snap ไว้ในไฟล์โปรเจกต์กลางของอำเภอนั้น
        self._snap_known_lids = None
        # 🔴🔴 2 ก.ย. 69 — ห้ามเรียก _line_layer_drop() ตรงนี้เด็ดขาด
        #   removeMapLayer() ระหว่างสัญญาณ aboutToBeCleared ทำให้ **QGIS ดับทั้งตัว**
        #   (SIGSEGV · วัดเองแล้ว exit 139 core dumped · try/except ดักไม่ได้)
        #   backtrace ฝั่ง C++: QgsMapLayer::~QgsMapLayer() -> QgsProject::pathResolver()
        #                       -> QgsArchive::dir()  ตอนคลังของโปรเจกต์กำลังถูกรื้อพอดี
        #   ลำดับที่ทำให้เกิด: วาดเส้น -> File > Open อำเภออื่น (พนักงานสลับอำเภอทุกวัน)
        #
        #   และไม่จำเป็นต้องลบแล้วด้วย เพราะ:
        #     · การล้างโปรเจกต์ทำลายเลเยอร์ให้เองอยู่แล้ว
        #     · ชั้นนี้ไม่ถูกเขียนลงไฟล์ (_on_project_write ถอดออกก่อน QGIS เขียน)
        #     · ไม่เด้งกล่องเตือน scratch layer (customProperty skipMemoryLayersCheck)
        #   ⇒ แค่ "ลืม id" ก็พอ ครั้งหน้าที่ต้องใช้ _line_layer_get จะสร้างใหม่ให้เอง
        #   (โรคเดียวกับที่เจอใน readProject ซึ่งแก้ด้วยการเลื่อนออกไปด้วย QTimer —
        #    ทางนี้เลื่อนไม่ได้ เพราะต้องเสร็จก่อนโปรเจกต์ถูกล้าง จึงใช้วิธี 'ไม่ต้องลบ')
        self._line_layer_id = None
        self._line_pt_layer_id = None      # ★ 2.3.6 — ชั้นจุดที่กรอกพิกัด: ลืม id เหมือนกัน (ห้ามลบตรงนี้)
        # ★★ 2 ก.ย. 69 — จำ "ไฟล์โปรเจกต์เดิม" ไว้ แล้วค่อยตัดสินตอนโปรเจกต์ใหม่โหลดเสร็จ
        #   ว่าจะทิ้งเส้นที่วัดไว้ไหม  🔴 ห้ามทิ้งตรงนี้เลยทันที เพราะสัญญาณนี้ยิงกับ
        #   **ทุก** การล้างโปรเจกต์ รวมทั้ง Project > Revert และการเปิดไฟล์เดิมซ้ำ
        #   ⇒ พนักงานกด Revert เพื่อทิ้งการแก้ "รูปแปลง" แล้วงานวัดระยะที่สะสมมาทั้งวัน
        #     หายไปด้วยโดยไม่ถามและกู้คืนไม่ได้ (รุ่น 2.1.0 ไม่เคยทำแบบนั้น)
        #   ทิ้งเฉพาะตอน "เปลี่ยนไปคนละไฟล์" เท่านั้น = เปลี่ยนอำเภอจริง ๆ
        # 🔴 ห้ามอ่าน fileName() ตรงนี้เพื่อเทียบว่า "เปลี่ยนอำเภอไหม"
        #   วัดแล้ว 2 ก.ย. 69: QGIS ตั้ง fileName() เป็น **พาธใหม่** ตั้งแต่ก่อนยิง
        #   aboutToBeCleared ⇒ ตอนนี้อ่านได้ค่าเดียวกับของใหม่เสมอ เทียบไม่ได้เลย
        #   ตัวตัดสินจริงอยู่ที่ _line_after_project_load ซึ่งเทียบกับพาธที่จำไว้
        #   "ตอนโปรเจกต์ก่อนหน้าโหลดเสร็จ" ต่างหาก
        self._line_switching = True
        # 🔴 3 ก.ย. 69 (แก้บั๊ก 8.2b) — ห้ามตั้ง QTimer ไปเรียก _line_after_project_load ตรงนี้
        # เพราะถ้าโปรเจกต์มี bad layers หน้าต่าง Handle Bad Layers จะรัน nested event loop
        # แล้ว QTimer จะไปทำงานระหว่างที่ QgsProject::read() ยังไม่จบ (ทำให้ addMapLayer แครช)
        # ปล่อยให้ _on_project_read เป็นคนเรียกเองเมื่อโหลดเสร็จจริง
        # ส่วนกรณี New Project (ไม่มี read) คืนค่า _line_switching ไว้เลย
        try:
            if not QgsProject.instance().fileName():
                self._line_switching = False
        except Exception:
            pass
        # ★ 2.3.7 (review DI-19) — File > New / Project > Close: สัญญาณนี้ยิงตอน fileName() ยังเป็นพาธเก่า แล้วไม่มี
        #   readProject ตามมา ⇒ ธงค้าง True ⇒ หยุดจำพาธ (Save As) แล้วต่อมาทิ้งเส้นวัดเงียบ ๆ
        #   ⇒ ตรวจซ้ำหลังการล้างจบ (รอบ event loop ถัดไป): ยังไม่มีชื่อไฟล์ = ไม่ได้กำลังเปิดไฟล์อื่น ⇒ ปลดธง
        #   (เปิดไฟล์ = ตอนนั้นมีชื่อไฟล์ใหม่แล้ว ⇒ _line_after_project_load ตัดสินเหมือนเดิม) · แค่สลับธง ไม่แตะชั้น
        try:
            QtCore.QTimer.singleShot(0, self._line_switch_settle)
        except Exception:
            pass
        # 🔴 4 ก.ย. 69 (2.2.4) — รอบ 2.2.2 ลบบรรทัด `try:` ของก้อนนี้ทิ้งโดยไม่ตั้งใจ
        #   (ตรวจทีละรุ่นด้วย ast แล้ว: 2.2.0 และ 2.2.1 มี try ครบ 2 ก้อนเหมือนกันเป๊ะ
        #    หายไปใน 2.2.2 และยังหายอยู่ใน 2.2.3 — อย่าโทษ 2.2.1 ผิด)
        #   ทำให้ `_clear_caches()` ไปอยู่ "ใน except" (จึงไม่เคยทำงานในทางปกติ)
        #   และเหลือ `except Exception` ตายอยู่อีกก้อน (ชนิดเดียวกัน ไม่มีวันถึง)
        #   ของเดิม 2.2.0 เป็นสอง try แยกกัน — คืนให้เหมือนเดิม
        try:
            self._clear_caches()
        except Exception:
            pass
        # ★ 2.4.0 (review DI-03) — ตัวแปลงพิกัดจุดคลิกเป็นของโปรเจกต์เดิม (datum transformation ของไฟล์นั้น) ⇒ ทิ้ง
        #   เดิมเก็บข้ามโปรเจกต์ไม่เคยล้าง ⇒ อำเภอถัดไปที่ตั้งวิธีแปลงต่างกันได้จุดคลิกตามวิธีของไฟล์เก่า
        self._m2l_cache_drop()
        # ★ 2.4.0 (review UX-09) — จุดที่ต้องแก้เป็นของโปรเจกต์เดิม ⇒ ล้างเครื่องหมาย + แถบ + รายการจุด (+ ผลที่รอทำหลังบันทึก)
        try:
            self._pair_hl_batch = None
            self._pair_hl_reset()
        except Exception:
            pass
        # ★ 2.3.7 (review LC-07) — ทุกเลเยอร์ของโปรเจกต์เดิมกำลังถูกทำลาย ⇒ ประวัติ ↺ Undo / คิวล็อกที่ชี้มันใช้ต่อไม่ได้
        #   เดิม Ctrl+Z ทุกครั้งเด้งกล่อง "ถูกปิดแก้ไข/บันทึกไปแล้ว" ซ้ำไม่จบ · คิวล็อก Type ค้าง = reload หลังอัปเดตไม่ได้ทั้งเซสชัน
        try:
            self._forget_ops_of(None)
        except Exception:
            pass
        # ★ 2.3.7 (review LC-05) — QGIS คงเครื่องมือเดิมไว้ตอน File > Open/Revert ⇒ เครื่องมือของปลั๊กอินถือเลเยอร์ที่กำลังถูกลบ
        #   ⇒ hover ทุก 80 มิลลิวินาที/คลิก = error ซ้ำ ๆ · ถอดตอนนี้ (เลเยอร์ยังมีชีวิต) · เครื่องมือวาดเส้นอยู่ต่อได้ (ตั้งใจ)
        try:
            self._drop_plugin_tool(keep_draw=True)
        except Exception:
            pass

    def _forget_ops_of(self, lids, notify=False):
        """ทิ้งประวัติ ↺ Undo / คิวล็อกเปลี่ยน Type ที่อ้างเลเยอร์ใน lids (None = ทั้งหมด) — ★ 2.3.7 (review LC-07)
        op ที่แตะเลเยอร์ที่หายไปย้อนครบไม่ได้แล้ว (ย้อนครึ่งเดียว = แปลง/หมุดไม่ตรงกัน) และ op ที่เก่ากว่ามันก็ย้อนไม่ได้
        (ย้อนเป็นชั้น ๆ ต้องย้อนตัวใหม่กว่าก่อน) ⇒ ทิ้งตั้งแต่ตัวใหม่สุดที่แตะเลเยอร์นั้นลงไปทั้งหมด · คืนจำนวน op ที่ทิ้ง"""
        hist = getattr(self, "op_history", None)
        if hist is None:
            return 0
        cut = len(hist) if lids is None else 0
        if lids is not None:
            from qgis.PyQt import sip as _sip
            for i, op in enumerate(hist):
                for e in op:
                    lyr = e[0] if e else None
                    if lyr is None:
                        continue
                    try:
                        if _sip.isdeleted(lyr) or lyr.id() in lids:
                            cut = i + 1
                            break
                    except Exception:
                        cut = i + 1
                        break
        if cut:
            del hist[:cut]
        base = getattr(self, "_op_baseline", None)
        if lids is None or (base and any(k in lids for k in base)):
            self._op_baseline = None
        ee = getattr(self, "_edit_end", None)
        if isinstance(ee, dict):
            for k in list(ee):
                if lids is None or k in lids:
                    ee.pop(k, None)
        if lids is None:
            self._pending_pair_warn = None
            self.last_layers = []
        q = list(getattr(self, "_pending_type_log", None) or [])
        keep = [e for e in q if lids is not None and e.get("lid") not in lids]
        if len(keep) != len(q):
            self._pending_type_log = keep
            try:
                QgsMessageLog.logMessage(
                    "ทิ้งคิวล็อกเปลี่ยน Type %d รายการที่ยังไม่ได้บันทึก (ชั้นของมันถูกปิด/เปลี่ยนโปรเจกต์)" % (len(q) - len(keep)),
                    "MLEP", Qgis.Warning)
            except Exception:
                pass
        if cut and notify:
            try:
                self.iface.messageBar().pushMessage(
                    "Undo", "ล้างประวัติ ↺ Undo ของปลั๊กอิน %d รายการ เพราะชั้นที่ใช้ถูกถอดออกจากโปรเจกต์" % cut,
                    level=0, duration=8)
            except Exception:
                pass
        return cut

    def _on_layers_will_be_removed(self, ids=None, *_a):
        """ชั้นกำลังถูกถอดออก (ยังไม่ถูกทำลาย) ⇒ ทิ้งประวัติ ↺ Undo/คิวล็อกที่อ้างชั้นนั้น — ★ 2.3.7 (review LC-07)"""
        if not getattr(self, "_alive", True):
            return
        if getattr(self, "_line_in_save", False) or getattr(self, "_line_own_swap", False):
            return                      # ชั้นชั่วคราวของเราเอง (ไม่เคยอยู่ในประวัติ Undo)
        try:
            lids = {(x.id() if hasattr(x, "id") else str(x)) for x in (ids or [])}
        except Exception:
            return
        if not lids:
            return
        self._forget_ops_of(lids, notify=True)
        # ★ 2.3.7 (review LC-05) — ชั้นที่เครื่องมือของปลั๊กอินถืออยู่กำลังถูกถอด (ลบออกจากสารบัญ) ⇒ ถอดเครื่องมือตอนนี้
        #   (ชั้นยังไม่ถูกทำลาย) ไม่งั้น hover/คลิกทุกครั้ง error ซ้ำ ๆ จนกว่าจะเปลี่ยนเครื่องมือ
        def _held(t):
            held = set()
            for _a in ("poly_lyr", "point_lyr", "_layer", "layer"):
                _L = getattr(t, _a, None)
                try:
                    if _L is not None and callable(getattr(_L, "id", None)):
                        held.add(_L.id())
                except Exception:
                    pass
            return held
        try:
            cv = self.iface.mapCanvas()
            cur = cv.mapTool() if cv is not None else None
            if self._is_plugin_tool(cur):
                if _held(cur) & lids:
                    self._drop_plugin_tool(keep_draw=True)
            # ★ 2.3.7 (b9 · บั๊กที่เจอตอนรวมแพตช์) — เครื่องมือที่ "พักไว้" ไม่ได้อยู่บนแคนวาสก็ถือชั้นได้: เครื่องมือเดิมที่หน้าต่าง
            #   📐 วาดเส้นจะคืนให้ (_line_prev_tool เช่นกรอบ 🍩) และ temp_tool ⇒ ถือชั้นที่กำลังถูกถอด = ลืมไป
            #   (_line_restore_tool คืนเครื่องมือมาตรฐานแทน) ไม่งั้นคืนมาแล้ว error ทุกครั้งที่ขยับเมาส์/คลิก
            prev = getattr(self, "_line_prev_tool", None)
            if prev is not None and prev is not cur and _held(prev) & lids:
                self._line_prev_tool = None
                self._line_prev_ours = False
            tt = getattr(self, "temp_tool", None)
            if tt is not None and tt is not cur and _held(tt) & lids:
                self.temp_tool = None
        except Exception:
            _log_exc("_on_layers_will_be_removed: ถอด/ลืมเครื่องมือที่ถือชั้นที่ถูกถอดไม่สำเร็จ")

    # ---------- กันชั้นเส้นหลุดลงไฟล์โปรเจกต์ตอนกด Save ----------
    #
    # ★ ลำดับจริงของ QgsProject.write() (วัดเอง 2 ก.ย. 69 บน QGIS 3.44.7):
    #     เขียน <layer-tree-group> ลง doc -> **emit writeProject(doc)** -> เขียน <maplayer> ทีละชั้น -> เซฟไฟล์
    #   ⇒ ตอนสัญญาณยิง ใน doc ยัง "ไม่มี" <maplayer> เลยแม้แต่ตัวเดียว (ลบไม่ได้)
    #     แต่ <layer-tree-layer> มีแล้ว (ลบได้)
    #   ⇒ จึงต้องทำสองอย่างคู่กัน: ลบร่องรอยใน doc + ถอนชั้นออกจากโปรเจกต์จริง
    #     (ถอนแล้ว QGIS จะไม่เขียน <maplayer> ของมันในขั้นถัดไป)
    #
    # ★ ทำไมถึง "ทิ้งแล้วสร้างใหม่" ไม่ใช่ takeMapLayer แล้วเอาวัตถุเดิมกลับ:
    #   ชั้นนี้เป็นแค่ "ภาพสะท้อน" ของ _line_item.lines ซึ่งเป็นแหล่งความจริง
    #   สร้างใหม่จึงได้ของเหมือนเดิมเป๊ะ และถ้าจังหวะไหนพลาด ก็แค่ชั้นหายไปชั่วคราว
    #   แล้วคลิกถัดไปสร้างคืนให้เอง — ไม่มีทางทำให้ "เส้นที่พนักงานวัดไว้" หาย
    #   (ทางถือวัตถุไว้เองต้องจัดการ ownership ข้ามฝั่ง C++ กลางคันบันทึกไฟล์ เสี่ยงกว่ามาก)
    #
    # ผลที่วัดได้: บันทึก 3 รอบติดกัน ไฟล์สะอาดทุกรอบ (ไม่มีทั้ง maplayer และ layer-tree-layer)
    #             ชั้นยังอยู่ในโปรเจกต์ที่เปิดค้าง และโปรเจกต์ไม่ถูกทำให้ "มีการแก้ไข"
    @staticmethod
    def _strip_layer_from_doc(doc, lid):
        """ลบร่องรอยของ layer id ออกจาก QDomDocument ที่ QGIS กำลังจะเขียนลงไฟล์
        ★ 2.4.0 (review ER-09) — ทุกขั้นที่ล้มเขียน Log แท็บ MLEP (ครั้งเดียวต่อชนิด) · ผู้เรียกตรวจ doc ซ้ำว่ายังมี id เหลือไหม"""
        n = 0
        for tag in ("layer-tree-layer", "layer-setting", "maplayer", "item"):
            try:
                els = doc.elementsByTagName(tag)
            except Exception:
                _log_exc("_strip_layer_from_doc: ค้น <%s> ใน doc ไม่สำเร็จ — ร่องรอยชั้นชั่วคราวอาจติดลงไฟล์โปรเจกต์" % tag,
                         once_key="ER-09:strip-find")                       # ★ 2.4.0 (review ER-09)
                continue
            kill = []
            for i in range(els.count()):
                e = els.at(i).toElement()
                try:
                    if (e.attribute("id") == lid
                            or e.attribute("layerid") == lid
                            or e.firstChildElement("id").text() == lid
                            or (tag == "item" and e.text().strip() == lid)):
                        kill.append(e)
                except Exception:
                    _log_exc("_strip_layer_from_doc: อ่าน <%s> ใน doc ไม่สำเร็จ (ข้ามตัวนั้น)" % tag,
                             once_key="ER-09:strip-read")                   # ★ 2.4.0 (review ER-09)
                    continue
            for e in kill:
                try:
                    par = e.parentNode()
                    if not par.isNull():
                        par.removeChild(e)
                        n += 1
                except Exception:
                    _log_exc("_strip_layer_from_doc: ลบ <%s> ของชั้นชั่วคราวออกจาก doc ไม่สำเร็จ" % tag,
                             once_key="ER-09:strip-remove")                 # ★ 2.4.0 (review ER-09)
        # ★★ 3 ก.ย. 69 — บล็อก <legend> แบบเก่ายังเก็บชื่อชั้นไว้ ไฟล์อำเภอจึง "เปลี่ยน"
        #   ทั้งที่ไม่มี <maplayer>/<layer-tree-layer> แล้ว (ผู้ตรวจ diff ทั้งไฟล์เจอ)
        #   โครงสร้าง: <legend><legendlayer name="..."><filegroup><legendlayerfile layerid="...">
        #   ⇒ หาจาก legendlayerfile/layerid แล้วไล่ขึ้นไปลบ <legendlayer> ทั้งก้อน
        #   (QGIS ไม่ได้ใช้บล็อกนี้อ่านชั้นแล้ว ชั้นผีจึงไม่กลับมา แต่ต้องไม่ทิ้งร่องรอยไว้)
        try:
            els = doc.elementsByTagName("legendlayerfile")
            kill = []
            for i in range(els.count()):
                e = els.at(i).toElement()
                if e.attribute("layerid") != lid:
                    continue
                node = e.parentNode()
                while not node.isNull():
                    el = node.toElement()
                    if not el.isNull() and el.tagName() == "legendlayer":
                        kill.append(el)
                        break
                    node = node.parentNode()
            for e in kill:
                par = e.parentNode()
                if not par.isNull():
                    par.removeChild(e)
                    n += 1
        except Exception:
            _log_exc("_strip_layer_from_doc: ลบบล็อก <legend> ของชั้นชั่วคราวออกจาก doc ไม่สำเร็จ",
                     once_key="ER-09:strip-legend")                         # ★ 2.4.0 (review ER-09)
        return n

    def _restore_borrowed_snap_in_doc(self, doc):
        """คืนค่าแม่เหล็กที่ "ยืม" มา ลงในเอกสารที่ QGIS กำลังจะเขียน

        🔴 3 ก.ย. 69 (ผู้ตรวจ diff ทั้งไฟล์แล้วเจอ) — ตอน QGIS เขียนไฟล์ ปลั๊กอินยังยืม
          แม่เหล็กอยู่ (คืนตอนปิดหน้าต่างวาดเส้น ซึ่งยังไม่ถึง) ⇒ ค่า enabled="1" ที่เรายืม
          ถูกเขียนฝังลงไฟล์กลางของอำเภอ ทั้งที่หน่วยงานตั้งไว้ "ปิด"
          พนักงานคนถัดไปที่เปิดไฟล์นั้นจะได้แม่เหล็กเปิดโดยไม่มีใครสั่ง
          เรายืมเฉพาะตอนที่ผู้ใช้ปิดไว้เท่านั้น (ดู _line_snap_borrow) ⇒ คืนเป็น "0" ได้เสมอ
          แก้ที่เอกสาร ไม่แตะค่าที่ใช้งานอยู่จริง เพื่อไม่ให้การวาดเส้นสะดุดกลางคัน
        """
        if doc is None or not getattr(self, "_line_snap_borrowed", False):
            return None
        els = doc.elementsByTagName("snapping-settings")
        n = 0                       # ★ 2.4.0 (review ER-09) — คืนจำนวนที่แก้ ให้ _on_project_write รู้ว่าไม่เจอ element (0)
        for i in range(els.count()):
            e = els.at(i).toElement()
            if not e.isNull():
                e.setAttribute("enabled", "0")
                n += 1
        return n

    def _on_project_write(self, doc=None, *_a):
        """QGIS กำลังจะเขียนไฟล์โปรเจกต์ -> เอาชั้นเส้นออกก่อน"""
        # ★ 2.3.0 — ด่าน `_alive` ให้เหมือนสล็อตของ QTimer
        #   QgsProject.instance() เป็น singleton ที่อยู่ยาวกว่าปลั๊กอิน และปลั๊กอิน
        #   อัปเดตตัวเองกลางเซสชันได้ ⇒ instance เก่าที่ตายแล้วต้องไม่ไปแตะของ instance ใหม่
        #   (unload() ถอด signal ทั้งสี่อยู่แล้ว — ข้อนี้เป็นเกราะชั้นสองสำหรับจังหวะที่ถอดไม่ทัน)
        if not getattr(self, "_alive", True):
            return
        # ★ 2.4.0 (review ER-09) — ของชั่วคราวที่ "อาจติดลงไฟล์รอบนี้" (ขั้นไหนล้ม/ตรวจซ้ำแล้วยังเหลือ) ⇒ แถบเตือนตัวเดียวท้ายสุด
        ค้าง = []
        # ★ ต้องทำก่อนด่าน "ไม่มีชั้นเส้น" ข้างล่าง เพราะการยืมแม่เหล็กเกิดขึ้นตั้งแต่
        #   เปิดหน้าต่างวาดเส้น ก่อนจะมีเส้น/มีชั้นเสียอีก
        try:
            _n_snap = self._restore_borrowed_snap_in_doc(doc)
            # ★ 2.4.0 (review ER-09) — ยืมอยู่แต่ไม่เจอ <snapping-settings> ใน doc (ลำดับเขียน/ชื่อ element วัดไว้แค่ 3.40/3.44)
            #   ⇒ ค่า "เปิดแม่เหล็ก" ที่ยืมมาลงไฟล์ไปตรง ๆ
            if _n_snap == 0:
                _log_msg_once("ER-09:write-snap0", "_on_project_write: ยืมแม่เหล็กอยู่แต่ไม่พบ <snapping-settings> ใน doc — "
                              "ค่าแม่เหล็กที่เปิดไว้ชั่วคราวอาจถูกบันทึกลงไฟล์โปรเจกต์", Qgis.Critical)
                ค้าง.append("ค่าแม่เหล็ก snap ที่เปิดไว้ชั่วคราว")
        except Exception:
            _log_exc("_on_project_write: คืนค่าแม่เหล็กที่ยืมใน doc ไม่สำเร็จ — ค่าแม่เหล็กที่เปิดไว้ชั่วคราวอาจถูกบันทึกลงไฟล์โปรเจกต์",
                     once_key="ER-09:write-snap")                           # ★ 2.4.0 (review ER-09)
            ค้าง.append("ค่าแม่เหล็ก snap ที่เปิดไว้ชั่วคราว")
        try:
            # ★ 2.3.6 — ถอดทั้งชั้นเส้นและชั้นจุดที่กรอกพิกัด
            #   🔑 มีแต่จุด (ยังไม่ได้วาดเส้น) ก็ต้องถอด — ถ้าเช็คแค่ชั้นเส้นแบบเดิม
            #      ชั้นจุดจะหลุดลงไฟล์ .qgz ของสาขาไปกับการกด Ctrl+S
            lids = [x for x in (getattr(self, "_line_layer_id", None),
                                getattr(self, "_line_pt_layer_id", None)) if x]
            if not lids:
                return
            # ★ 2 ก.ย. 69 — ยกธง "กำลังสลับชั้นของตัวเองอยู่"
            #   การถอด/ใส่ชั้นคืนจะยิง layersRemoved/layersAdded ซึ่งไปปลุก
            #   _project_layers_changed -> _preview_clear() + refresh_layers()
            #   ⇒ พนักงานที่กด Move คลิกแรกแล้วกด Ctrl+S ติดมือ จะเห็น "เงาแปลง" หายจากจอ
            #     แล้วต้องคลิกจุดปลายทางแบบมองไม่เห็นว่าแปลงจะไปตกตรงไหน
            #   ชั้นที่เปลี่ยนเป็นของเราเองล้วน ๆ จึงไม่มีเหตุต้องล้างเงาของผู้ใช้
            self._line_in_save = True
            # กันธงค้าง + ★★ ตาข่ายรองสร้างชั้นคืน (2 ก.ย. 69 — ผู้ตรวจจับได้)
            #   ทางสร้างคืนทางเดียวคือสัญญาณ projectSaved ซึ่ง QGIS ยิง "เฉพาะตอนเขียนสำเร็จ"
            #   ⇒ ถ้าเขียนล้มระหว่าง writeProject กับ projectSaved ชั้นเส้นหายถาวร
            #      แนวอ้างอิงเลิกเป็นเป้า snap เงียบ ๆ · คลิกตกไปใช้พิกัดดิบจากเมาส์
            #      แล้วเขียนลง PostGIS โดยไม่มีคำเตือน · กดเครื่องมือซ้ำก็ไม่ฟื้น
            #   🔴 เกิดกับ .qgz ของอำเภอจริงด้วย (ไม่ใช่แค่ .qgs อย่างที่เคยเข้าใจ):
            #      ถ้าล้มตอนเขียน .qgs ชั่วคราวข้างใน (ดิสก์/โควตาเต็ม · %TEMP% เขียนไม่ได้)
            #      จะได้ writeProject=1 projectSaved=0 เหมือนกัน
            #   ตัวจับเวลานี้ทำงานหลังการบันทึกจบทุกกรณี ไม่ว่าสำเร็จหรือล้ม
            try:
                QtCore.QTimer.singleShot(0, self._line_clear_save_flag)
                QtCore.QTimer.singleShot(0, self._line_restore_after_write)
            except Exception:
                _log_exc("_on_project_write: ตั้งเวลาสร้างชั้นเส้น/จุดวัดระยะคืนหลังบันทึกไม่สำเร็จ",
                         once_key="ER-09:write-timer")                      # ★ 2.4.0 (review ER-09)
            if doc is not None:
                prj = QgsProject.instance()
                for lid in lids:
                    n = self._strip_layer_from_doc(doc, lid)
                    # ★ 2.4.0 (review ER-09) — เดิมทิ้งจำนวนที่ลบได้ · ชั้นอยู่ในโปรเจกต์แต่ไม่เจอร่องรอยเลย = ชื่อ element อาจเปลี่ยน
                    if n == 0 and prj.mapLayer(lid) is not None:
                        _log_msg_once("ER-09:strip-zero", "_on_project_write: ไม่พบร่องรอยของชั้นชั่วคราว %s ใน doc "
                                      "(ลบได้ 0 จุด · ชื่อ element ในไฟล์โปรเจกต์ของ QGIS รุ่นนี้อาจต่างจากที่วัดไว้)" % lid)
                # ★ 2.4.0 (review ER-09) — ตรวจซ้ำทั้ง doc ว่าไม่เหลือ id ของชั้นชั่วคราว (ครอบ element ที่ตัวลบไม่รู้จักด้วย)
                try:
                    _xml = doc.toString(-1)
                    _เหลือ = [lid for lid in lids if lid in _xml]
                except Exception:
                    _log_exc("_on_project_write: ตรวจ doc ซ้ำหลังตัดชั้นชั่วคราวไม่สำเร็จ", once_key="ER-09:write-verify")
                    _เหลือ = []
                if _เหลือ:
                    QgsMessageLog.logMessage("_on_project_write: ตัดแล้วยังพบ id ของชั้นชั่วคราวใน doc (%s) — "
                                             "ไฟล์โปรเจกต์อาจมีร่องรอยชั้นเส้น/จุดวัดระยะ" % ", ".join(_เหลือ),
                                             "MLEP", Qgis.Critical)
                    ค้าง.append("ชั้นเส้น/จุดวัดระยะ")
            self._line_layer_drop()
            # ★ 2.4.0 (review ER-09) — ถอดไม่ออก (_line_drop_one ลง Log แล้ว) ⇒ QGIS จะเขียน <maplayer> ของชั้นนั้นลงไฟล์
            try:
                if any(QgsProject.instance().mapLayer(lid) is not None for lid in lids) \
                        and "ชั้นเส้น/จุดวัดระยะ" not in ค้าง:
                    ค้าง.append("ชั้นเส้น/จุดวัดระยะ")
            except Exception:
                _log_exc("_on_project_write: ตรวจว่าถอดชั้นชั่วคราวออกแล้วไม่สำเร็จ", once_key="ER-09:write-dropcheck")
        except Exception:
            self._line_in_save = False
            _log_exc("_on_project_write: ตัดชั้นเส้น/จุดวัดระยะออกก่อนบันทึกไม่สำเร็จ — อาจติดลงไฟล์โปรเจกต์",
                     once_key="ER-09:write")                                # ★ 2.4.0 (review ER-09)
            if "ชั้นเส้น/จุดวัดระยะ" not in ค้าง:
                ค้าง.append("ชั้นเส้น/จุดวัดระยะ")
        finally:
            if ค้าง:
                self._qgz_leftover_warn(
                    "บันทึกโปรเจกต์: เอาของชั่วคราวของหน้าต่างวาดเส้นออกจากไฟล์ไม่ครบ (%s) — ไฟล์โปรเจกต์ที่บันทึกรอบนี้"
                    "อาจมีของนี้ติดไปด้วย · ปิดหน้าต่างวาดเส้น (เส้นที่วัดไว้ไม่หาย) แล้วบันทึกโปรเจกต์อีกครั้ง"
                    % " · ".join(ค้าง))

    # ★ 2.4.0 (review ER-09) — กลไกกันไฟล์ .qgz กลางของสาขาให้สะอาด (ตัดชั้นเส้น/จุดวัดระยะ · คืนแม่เหล็กที่ยืม · กวาดชั้นผี ·
    #   ปลดธง "มีการแก้ไข") เดิมกลืน error เงียบราว 24 จุด ⇒ ไฟล์กลางอาจถูกบันทึกพร้อมของชั่วคราวของปลั๊กอินโดยไม่มีใครรู้
    #   และไม่มีร่องรอยให้ไล่ ⇒ ทุกจุดเขียน Log แท็บ MLEP (Warning · ครั้งเดียวต่อชนิดของความล้ม) · จุดที่ล้มแล้ว
    #   "ไฟล์ที่บันทึกอาจมีของค้าง" ขึ้นแถบเตือนตัวเดียวผ่านเมธอดนี้ (ไม่บล็อก · ตัวใหม่แทนตัวเก่า) · วิธีทำความสะอาดเหมือนเดิม
    def _qgz_leftover_warn(self, text):
        try:
            self._push_once("_qgz_leftover_bar", "MLEP", "%s · %s" % (text, self._LOG_HINT), level=1, duration=15)
        except Exception:
            _log_exc("_qgz_leftover_warn: ขึ้นแถบเตือนไม่สำเร็จ", once_key="ER-09:bar")

    def _on_project_saved(self, *_a):
        """เขียนไฟล์เสร็จแล้ว -> สร้างชั้นเส้นคืนถ้าหน้าต่างวาดเส้นยังเปิดอยู่

        _line_sync_layer มีด่าน _line_window_open อยู่แล้ว ⇒ ถ้าหน้าต่างปิดไปแล้ว
        จะไม่สร้างคืน ซึ่งเป็นพฤติกรรมที่ถูก
        """
        # ★ 2.3.0 — ด่าน `_alive` ให้เหมือนสล็อตของ QTimer
        #   QgsProject.instance() เป็น singleton ที่อยู่ยาวกว่าปลั๊กอิน และปลั๊กอิน
        #   อัปเดตตัวเองกลางเซสชันได้ ⇒ instance เก่าที่ตายแล้วต้องไม่ไปแตะของ instance ใหม่
        #   (unload() ถอด signal ทั้งสี่อยู่แล้ว — ข้อนี้เป็นเกราะชั้นสองสำหรับจังหวะที่ถอดไม่ทัน)
        if not getattr(self, "_alive", True):
            return
        try:
            self._line_sync_layer()
        except Exception:
            _log_exc("_on_project_saved: สร้างชั้นเส้น/จุดวัดระยะคืนหลังบันทึกโปรเจกต์ไม่สำเร็จ",
                     once_key="ER-09:saved-sync")                           # ★ 2.4.0 (review ER-09)
        finally:
            self._line_in_save = False
        # ★ 2 ก.ย. 69 — หลังบันทึก (โดยเฉพาะ Save As) พาธของโปรเจกต์อาจเปลี่ยนไปแล้ว
        #   ต้องจำพาธล่าสุดไว้ ไม่งั้น Revert ครั้งถัดไปจะเทียบกับพาธเก่าแล้วเข้าใจผิดว่า
        #   "เปลี่ยนอำเภอ" แล้วทิ้งงานวัดระยะของพนักงานทิ้งโดยไม่ถาม
        #   🔴 ต้องจำเฉพาะเมื่อ "บันทึกสำเร็จจริง" — projectSaved ยิงแม้การเขียนล้มเหลว
        #      (แชร์ล่ม / ไดรฟ์ที่แมปหลุด / พิมพ์โฟลเดอร์ผิด) และ QGIS ตั้ง fileName เป็นพาธที่ล้ม
        #      ถ้าจำพาธที่ล้มไว้ พอเปิดไฟล์อำเภอเดิมกลับมาจะถูกมองว่า "เปลี่ยนอำเภอ"
        #      แล้วลบงานวัดระยะทั้งวันทิ้งโดยไม่ถาม
        #      🔴 ต้องเลื่อนออกไปตรวจ — `.qgz` ถูกเขียนเป็นไฟล์ชั่วคราวแล้วค่อยย้ายเข้าที่
        #         ตอน projectSaved ยิง ไฟล์ปลายทาง "ยังไม่มีอยู่จริง" (วัดแล้ว 2 ก.ย. 69)
        #         ถ้าเช็ค os.path.exists ตรงนี้จะได้ False เสมอ แม้บันทึกสำเร็จ
        try:
            QtCore.QTimer.singleShot(0, self._line_remember_project_path)
        except Exception:
            _log_exc("_on_project_saved: ตั้งเวลาจำพาธโปรเจกต์ไม่สำเร็จ", once_key="ER-09:saved-timer")  # ★ 2.4.0 (ER-09)

    def _on_new_project(self, *_a):
        """★ 2.3.7 (review DI-19) — File > New เสร็จแล้ว (iface.newProjectCreated) ⇒ ไม่ได้กำลังสลับไปไฟล์ไหน"""
        if not getattr(self, "_alive", True):
            return
        self._line_switching = False

    def _on_project_read(self, *_a):
        """เปิดโปรเจกต์เสร็จแล้ว -> ตั้งเวลาไปกวาดชั้นผี

        🔴🔴 ต้อง "เลื่อนออกไป" ห้ามลบเลเยอร์ในสัญญาณนี้ตรง ๆ
          วัดแล้ว 2 ก.ย. 69: ลบเลเยอร์ระหว่างที่สัญญาณ readProject ยังทำงานอยู่
          ทำให้ QGIS พังตอน write() ครั้งถัดไปด้วย "double free or corruption"
          (ทดสอบ 3 ทาง: ไม่กวาด = เขียนได้แต่ผีสะสม · กวาดในสัญญาณ = พัง ·
           กวาดแบบเลื่อนด้วย QTimer = ทำงานถูกและไฟล์สะอาด)
          เหตุเพราะฝั่ง QGIS ยังถือ reference ของเลเยอร์อยู่จนกว่าจะจบขั้นตอนอ่าน
        """
        # ★ 2.3.0 — ด่าน `_alive` ให้เหมือนสล็อตของ QTimer
        #   QgsProject.instance() เป็น singleton ที่อยู่ยาวกว่าปลั๊กอิน และปลั๊กอิน
        #   อัปเดตตัวเองกลางเซสชันได้ ⇒ instance เก่าที่ตายแล้วต้องไม่ไปแตะของ instance ใหม่
        #   (unload() ถอด signal ทั้งสี่อยู่แล้ว — ข้อนี้เป็นเกราะชั้นสองสำหรับจังหวะที่ถอดไม่ทัน)
        if not getattr(self, "_alive", True):
            return
        try:
            QtCore.QTimer.singleShot(0, self._line_sweep_ghosts)
            QtCore.QTimer.singleShot(0, self._line_after_project_load)
        except Exception:
            # ★ 2.4.0 (review ER-09) — ไม่ได้กวาด = ชั้นชั่วคราวที่ติดมากับไฟล์ค้างในโปรเจกต์ บันทึกเมื่อไรก็ลงไฟล์อีก
            _log_exc("_on_project_read: ตั้งเวลากวาดชั้นชั่วคราวที่ติดมากับไฟล์ไม่สำเร็จ", once_key="ER-09:read-timer")
            self._qgz_ghost_warn()
        # ★ 2.3.7 (review LC-12) — ป้าย rule ของ @owner_name เป็นของไฟล์ (setLabel ถูกเซฟลง .qgz) ⇒ เปิดไฟล์สาขาอื่นทั้งที่หน้าต่าง MLEP
        #   เปิดค้าง สารบัญโชว์ชื่อคนที่เซฟไฟล์กลางล่าสุด ขณะที่ตัวกรอง (ตัวแปร global) ไฮไลต์แปลงของคนปัจจุบัน ⇒ ซิงก์ทุกครั้งที่เปิดโปรเจกต์
        #   เลื่อนด้วย QTimer เหมือนงานอื่นของสัญญาณนี้ (ห้ามแตะเลเยอร์ระหว่าง readProject)
        # ★ 2.3.7 (review DI-02) — โหลดเสร็จแล้ว ⇒ เลิกรวบการสร้างคอมโบ (ตัวจับเวลา _layers_settle ที่ตั้งไว้ระหว่างโหลดจะรีเฟรชครั้งเดียว)
        self._layers_loading = False
        try:
            QtCore.QTimer.singleShot(0, self._owner_labels_after_read)
        except Exception:
            pass
        # ★ 2.3.7 (review LC-05) — จำรายชื่อชั้นของโปรเจกต์ที่เพิ่งเปิดไว้เลย (อ่านอย่างเดียว · ไม่ใช่ทางที่ทำ QGIS ดับ)
        #   เดิมเป็น None จนกว่าจะกดเครื่องมือ ⇒ เครื่องมือที่ arm ข้ามโปรเจกต์มา (วาดเส้น) + มีชั้นถูกเพิ่มทีหลัง
        #   ⇒ _reapply_snap_limit ถือว่าทุกชั้นของสาขาใหม่ "เพิ่งโผล่" แล้วปิด snap ให้หมดเงียบ ๆ (ติดลงไฟล์ตอนบันทึก)
        try:
            self._snap_known_lids = set(QgsProject.instance().mapLayers().keys())
        except Exception:
            _log_exc("_on_project_read: จำรายชื่อชั้นของโปรเจกต์ไม่สำเร็จ (ใช้กำหนดชั้นที่ snap ได้)",
                     once_key="ER-09:read-snap-known")      # ★ rc1 (F8 · §5.1 ER-09) เดิม except: pass เงียบ
        # ★ 2.4.0 (review DI-11) — เฝ้าชั้นทำงานของโปรเจกต์ที่เพิ่งเปิดให้ด่าน L1 (ไม่ต้องรอเปิดแผง · เลื่อนด้วย QTimer เหมือนงานอื่นของสัญญาณนี้)
        self._l1_arm_soon()

    @staticmethod
    def _same_project_file(a, b):
        r"""ไฟล์โปรเจกต์เดียวกันหรือไม่ — ต้องทนการสะกดพาธคนละแบบ

        พนักงานใช้ Windows: ไฟล์เดียวกันเปิดได้หลายทาง
          ไดรฟ์ที่แมป Z:\... กับ UNC \\<เครื่องแชร์ไฟล์>\... · ตัวพิมพ์ใหญ่เล็ก ·
          พาธที่มี ".." · Recent Projects เทียบกับลากไฟล์จาก Explorer
        ถ้าเทียบสตริงดิบ จะนับเป็น "คนละอำเภอ" แล้วลบงานวัดระยะทิ้งโดยไม่ถาม
        """
        if a == b:
            return True
        if not a or not b:
            return False
        try:
            na = os.path.normcase(os.path.realpath(a))
            nb = os.path.normcase(os.path.realpath(b))
            return na == nb
        except Exception:
            return False

    def _qgz_ghost_warn(self):
        """★ 2.4.0 (review ER-09) — กวาดชั้นชั่วคราวที่ติดมากับไฟล์ไม่สำเร็จ ⇒ บอกพนักงานให้ลบเองก่อนบันทึก (แถบเตือนตัวเดียว)"""
        self._qgz_leftover_warn(
            "เปิดโปรเจกต์: เอาชั้นชั่วคราวของหน้าต่างวาดเส้นที่ติดมากับไฟล์ออกไม่สำเร็จ — ถ้าบันทึกโปรเจกต์ ชั้นนี้จะติดลงไฟล์อีก"
            " · ลบชั้น '%s' / '%s' ออกจากแผงชั้นเองก่อนบันทึก" % (self.LINE_LAYER_NAME, self.LINE_PT_LAYER_NAME))

    def _tool_reap_later(self, tool):
        """★ rc2 (audit A2-04) — ลบเครื่องมือแผนที่ตัวเก่าของปลั๊กอิน "รอบ event loop ถัดไป" ถ้าไม่มีใครใช้แล้ว
        ไม่ลบเมื่อ: ยังเป็นเครื่องมือของแผนที่ใด ๆ อยู่ (เช่น 📐 คืนเครื่องมือเดิมให้แล้วตั้ง temp_tool=None) · ยังถูกอ้างจาก
        แอตทริบิวต์ใดของปลั๊กอิน (_line_prev_tool ที่ 📐 พักไว้ · _xform_tool · _align_tool · temp_tool ฯลฯ) · ถูกลบไปแล้ว
        ตัดสินตอนจะลบจริง (หลัง setMapTool ของเครื่องมือใหม่) ⇒ ตัวที่ถูกเก็บไว้ใช้ต่อไม่โดนลบ"""
        from qgis.PyQt import sip as _sip

        def _go(ref=tool):
            try:
                if ref is None or _sip.isdeleted(ref):
                    return
                if any(v is ref for v in list(vars(self).values())):
                    return
                try:
                    _cs = list(self.iface.mapCanvases() or [])
                except Exception:
                    _cs = []
                _c0 = self.iface.mapCanvas()
                if _c0 is not None and not any(c is _c0 for c in _cs):
                    _cs.append(_c0)
                if any(c is not None and c.mapTool() is ref for c in _cs):
                    return
                ref.deleteLater()
            except Exception:
                pass
        QtCore.QTimer.singleShot(0, _go)

    def _map_tool_changed(self, new_tool=None, *_a):
        """เปลี่ยนเครื่องมือ -> เก็บกวาดเงา + หมุดของรอบที่ค้างไว้

        เทียบกับ "เจ้าของเงา" (_preview_tool ที่บันทึกตอน arm) ไม่ใช่ self.temp_tool ปัจจุบัน:
        ทุก start_* ตั้ง self.temp_tool = ตัวใหม่ "ก่อน" setMapTool เสมอ ถ้าเทียบกับ temp_tool
        จังหวะ setMapTool จะ early-return ทุกครั้งที่สลับข้ามเครื่องมือของปลั๊กอินเอง
        (เช่น กด Move คลิกแรกแล้วไปกด Move Node ต่อ) -> เงารอบก่อนค้างจอ
        เทียบกับเจ้าของเงาแทน = เก็บกวาดตอน setMapTool ตรงๆ ไม่ต้องพึ่งจังหวะที่ Python
        คืนหน่วยความจำเครื่องมือตัวเก่า (ซึ่งเป็นกลไกที่มองไม่เห็นจากโค้ดและพึ่งพาไม่ได้)
        เทียบด้วย is (ไม่ใช่ ==) และไม่แตะ oldTool เลย — oldTool อาจกำลังถูกทำลายอยู่
        รับ *_a เพราะ signal นี้มีทั้งแบบ 1 และ 2 อาร์กิวเมนต์ตามรุ่น QGIS

        กัน instance เก่าค้าง: signal นี้ผูกกับ canvas ซึ่งอายุยืนกว่าตัวปลั๊กอิน ถ้า unload
        ของ instance ก่อนหน้าไม่ได้ทำงาน (เช่น reload ปลั๊กอินกลางคันตอนแก้โค้ด) slot จะยัง
        ถูกเรียกบน object เก่าที่โครงไม่ครบ -> ใช้ getattr + try กันพ่น error ทุกครั้งที่
        สลับเครื่องมือ (งานในนี้เป็นแค่การเก็บกวาด ล้มเหลวอย่างมากคือเงาค้าง ไม่กระทบข้อมูล)"""
        # ★ 31 ส.ค. 69 — ผู้ใช้กดเครื่องมืออื่นทับ = ออกจากโหมดวาดเส้นโดยปริยาย
        #   ต้องอัปเดตปุ่มในแผงและคืน snapping ที่ยืมไว้ ไม่งั้นปุ่มจะค้างว่า "หยุดวาด"
        #   ทั้งที่ไม่ได้อยู่ในโหมดวาดแล้ว
        # ★ 1 ก.ย. 69 — ต้องอยู่ "เหนือ" early-return ของ _preview_tool ข้างล่าง
        #   เดิมวางไว้ล่าง แล้วถูกข้ามทุกครั้งที่เครื่องมือใหม่เป็นเจ้าของเงา
        #   (Move / Move Node / Align ฯลฯ ล้วนตั้ง _preview_tool ก่อน setMapTool)
        #   -> ปุ่มค้างว่า "หยุดวาด" ทั้งที่ออกจากโหมดวาดไปแล้ว (เทส sim18 ข้อ 1d จับได้)
        try:
            from ..map_tools import DrawLineTool
            if getattr(self, "_line_dock", None) is not None \
                    and not isinstance(new_tool, DrawLineTool):
                self._line_snap_return()
                self._line_sync_toggle(False)
        except Exception:
            _log_exc("_map_tool_changed: คืนแม่เหล็กที่ยืม/ปุ่มวาดเส้นเมื่อเปลี่ยนเครื่องมือไม่สำเร็จ",
                     once_key="ER-09:tool-snap-return")     # ★ rc1 (F8 · §5.1 ER-09) เดิม except: pass เงียบ
        # ★ 2.4.0 (review UX-09) — เปลี่ยนเครื่องมือ ⇒ เก็บเครื่องหมาย "จุดที่ต้องแก้" (แถบยังอยู่ ◀ ▶ แสดงใหม่ได้)
        try:
            self._pair_hl_clear_marks()
        except Exception:
            pass
        # ★ 2.3.1 — ไฮไลต์ส้มของ 🍩 แบ่งหัก/แยก ต้องหายเมื่อเลิกใช้เครื่องมือนั้น
        #   🔴 เจ้าของงานเจอจริง: กด Esc ตอนเลือกแปลง -> ไฮไลต์ค้างจอ
        #   เงื่อนไข: เครื่องมือใหม่ไม่ใช่ตัวที่เรา arm ไว้ = ออกจากงานแบ่งหัก/แยกแล้ว
        try:
            from ..map_tools import PolygonPickTool, DonutFrameTool, DrawLineTool as _DLT0
            # 🔴🔴 21 ก.ย. บั๊กที่เจ้าของงานเจอ: `actionSelect().trigger()` ที่เรียก "ก่อนลงมือ"
            #    ทำให้ signal นี้ยิง แล้วโค้ดข้างล่างล้าง `_donut_inner` ทิ้ง
            #    ⇒ `_donut_execute` (รุ่น ≤ 2.3.5) เห็นรายการว่าง แล้ว return เงียบ ๆ = กดแล้วไม่มีอะไรเกิด
            #    ⇒ ระหว่างลงมือต้องห้ามเก็บกวาด (`_donut_busy`)
            # ★ rc2 S_close (review R3-02a) — 📐 วาดเส้น = "พัก" งาน 🍩 (แบบ Align · A1-08): ไม่ล้างแปลงที่เลือก/หมุดที่คลิกทำกรอบ
            #   เดิมล้าง _donut_outer แต่ _line_restore_tool คืน DonutFrameTool ⇒ ปิดกรอบแล้วเงียบ (ไม่หัก ไม่มีข้อความ)
            #   ออกจากโหมดวาดไปเครื่องมืออื่นแทน ⇒ เครื่องมือใหม่ไม่ใช่ DrawLineTool ⇒ เก็บกวาดตามเดิม
            _กำลังแบ่ง = (getattr(self, '_donut_busy', False)
                          or (getattr(self, '_donut_stage', None) is not None
                              and ((isinstance(new_tool, (PolygonPickTool, DonutFrameTool))
                                    and new_tool is getattr(self, 'temp_tool', None))
                                   or isinstance(new_tool, _DLT0)
                                   or (new_tool is None and getattr(self, '_line_unparking', False)))))
            # 🔑 เงื่อนไขต้องเป็น "ออกจากเครื่องมือนี้แล้ว" ไม่ใช่ "มีไฮไลต์ค้างอยู่"
            #    ไม่งั้นพอไม่มีไฮไลต์ เครื่องมือจะค้างรอคลิกต่อทั้งที่ผู้ใช้ไปจับปุ่มอื่นแล้ว
            if not _กำลังแบ่ง and (getattr(self, '_donut_bands', None)
                                   or getattr(self, '_donut_stage', None) is not None):
                try:
                    self._donut_pop_hint()
                except Exception:
                    pass
                self._donut_clear_bands()
                self._donut_stage = None
                self._donut_inner = []
                self._donut_outer = None
        except Exception:
            pass
        # ★ 2.3.7 (review LC-04 / UX-20) — ของบนแคนวาสของ Align (ไฮไลต์หมุดสีฟ้าสูงสุด 800 จุด · เส้นนำสีแดง
        #   · สี่เหลี่ยม snap) และข้อความขั้นตอนของเครื่องมือขยับแปลง ต้องหายเมื่อออกจากเครื่องมือ
        #   เดิมเก็บแค่เงา+หมุดคลิก ⇒ ค้างจอข้ามไป Move รอบถัดไปและข้ามการ reload
        #   ต้องอยู่ "เหนือ" early-return ของ _preview_tool ข้างล่าง · 📐 วาดเส้น = พักชั่วคราว (กลับมาทำต่อได้) ไม่ทิ้งที่เลือก
        try:
            from ..map_tools import DrawLineTool as _DLT
            _พัก = isinstance(new_tool, _DLT) or (new_tool is None and getattr(self, '_line_unparking', False))
            if not _พัก and (new_tool is None or new_tool is not getattr(self, "_xform_tool", None)):
                self._xform_hint_pop()
            if getattr(self, "mode", "") in ('align_box', 'align_point_driven') \
                    and (new_tool is None or new_tool is not getattr(self, "_align_tool", None)):
                self.clear_rubber_band()
                _si = getattr(self, "snap_indicator", None)
                if _si is not None:
                    _si.setMatch(QgsPointLocator.Match())
                if not _พัก:
                    self._align_clear_highlight()
                    self._align_picked_ids = set()
        except Exception:
            pass
        if new_tool is not None and new_tool is getattr(self, "_preview_tool", None):
            return
        try:
            self._preview_clear()
            self.clear_markers()
        except Exception:
            pass
        # ★ 2.3.7 (review LC-06) — เครื่องมือใหม่ไม่ใช่เจ้าของงานที่คลิกค้างไว้ (เงา/มาร์กเกอร์ถูกล้างไปแล้วข้างบน)
        #   ⇒ ทิ้งจุดที่คลิกค้างด้วย ไม่งั้นพอคืนเครื่องมือ Move/Align (เช่นออกจากโหมดวาดเส้น) คลิกถัดไปจะทำงานต่อ
        #   จากจุดของรอบก่อนที่มองไม่เห็นแล้ว · ปลอดภัย: ทุกเครื่องมือที่ใช้ src_pts ล้างเองก่อน setMapTool
        #   และเติมจากคลิกของตัวเองเท่านั้น (execute_tool อ่านเก็บไว้ในตัวแปรท้องถิ่นก่อนเปลี่ยนเครื่องมือ)
        self.src_pts = []

    def _is_plugin_tool(self, tool):
        """เครื่องมือบนแคนวาสเป็นของ MLEP ไหม: ตัวปัจจุบัน · มีป้าย _mlep_tool · หรือคลาสมาจากแพ็กเกจนี้ (★ 2.3.7 LC-03c)"""
        if tool is None:
            return False
        if tool is getattr(self, "temp_tool", None):
            return True
        try:
            if tool.property("_mlep_tool"):
                return True
        except Exception:
            pass
        try:
            return (type(tool).__module__ or "").split(".")[0] == __name__.split(".")[0]
        except Exception:
            return False

    def _clear_snap_indicator(self):
        """ล้างตัวบอก snap บนจอ (ไม่ทำลายตัวมัน — handle_* ใช้ None เป็นสัญญาณ 'ไม่ได้อยู่ในเครื่องมือ')"""
        si = getattr(self, "snap_indicator", None)
        if si is not None:
            si.setMatch(QgsPointLocator.Match())

    def _drop_plugin_tool(self, keep_draw=False):
        """ถอดเครื่องมือของปลั๊กอินที่ค้างบนแคนวาส + ล้างของบนจอ (ไม่แตะ selection) แล้วคืนเครื่องมือมาตรฐาน · คืน True ถ้าถอด

        ★ 2.3.7 (review LC-03c / LC-05) — ใช้ทั้งตอน unload และตอนเปลี่ยน/ล้างโปรเจกต์ (keep_draw=True: เครื่องมือวาดเส้น
          ตั้งใจให้อยู่ข้ามการ Revert จึงไม่ถอด) · เครื่องมือถือเลเยอร์ของโปรเจกต์เดิม ⇒ ค้างไว้ = hover/คลิกทุกครั้ง error ซ้ำ ๆ
        ★ 2 ก.ย. 69 — ถอนแล้วต้องคืนเครื่องมือมาตรฐานให้ด้วย ไม่งั้นแคนวาส "ไม่มีเครื่องมือเลย"
          พนักงานคลิกแผนที่แล้วเงียบสนิท = รายงานว่า 'QGIS ค้าง'"""
        canvas = self.iface.mapCanvas()
        cur = canvas.mapTool() if canvas is not None else None
        if not self._is_plugin_tool(cur):
            return False
        if keep_draw:
            from ..map_tools import DrawLineTool
            if isinstance(cur, DrawLineTool):
                return False
        self.src_pts = []
        for _fn in (self.clear_markers, self.clear_rubber_band, self._preview_clear,
                    self._align_clear_highlight, self._clear_snap_indicator):
            try:
                _fn()
            except Exception:
                pass
        self._align_picked_ids = set()
        try:
            canvas.unsetMapTool(cur)
        except Exception:
            pass
        if getattr(self, "temp_tool", None) is cur:
            self.temp_tool = None
        for _name in ("actionPan", "actionSelect"):
            try:
                _act = getattr(self.iface, _name, None)
                if _act is not None:
                    _act().trigger()
                    break
            except Exception:
                continue
        return True

    def _start_unsaved_watch(self):
        """ตัวเตือนเบา ๆ: ถ้ามีงานค้างใน edit buffer นานเกิน UNSAVED_NAG_MIN นาที ให้เตือนบนแถบข้อความ
        ★ ไม่ใช่ autosave และไม่บล็อกอะไรทั้งสิ้น (เช็คแค่ธง isModified ในหน่วยความจำ ไม่แตะฐานข้อมูล)
        ที่มา: 5 ส.ค. 69 พนักงานแก้งานสะสม ~20 นาทีโดยไม่บันทึก แล้ว QGIS ค้างจนต้องปิดโปรแกรม
              -> งานทั้งก้อนหาย เพราะยังไม่เคยถูกส่งถึงฐานข้อมูลเลย"""
        if self._nag_timer is not None:
            return
        try:
            t = QtCore.QTimer(self.dlg or self.iface.mainWindow())
            t.setInterval(60000)                     # เช็คนาทีละครั้ง (ถูกมาก)
            t.timeout.connect(self._unsaved_tick)
            t.start()
            self._nag_timer = t
        except Exception:
            self._nag_timer = None

    def _unsaved_tick(self):
        try:
            lyrs = [QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                    QgsProject.instance().mapLayer(self.point_cb.currentData())]
            # ★ 2.3.7 (review UX-23) — รวมชั้นที่ปลั๊กอินเคยแก้ (ประวัติ ↺ / op ที่กำลังทำ) ด้วย: สลับคอมโบไปคู่อื่นแล้ว
            #   งานค้างของคู่เดิมเคยหลุดจากการเตือน · ชั้นที่ถูกถอดออกไปแล้ว (C++ ตาย) ข้ามไป
            for _op in self.op_history:
                lyrs += [_e[0] for _e in _op]
            if self._op_baseline:
                lyrs += [_v[0] for _v in self._op_baseline.values()]
            dirty = False
            # ★ rc2 (audit A5-08) — จำชั้นที่ค้างไว้ด้วย: ปุ่ม "💾 บันทึกเลย" บันทึกได้แค่คู่ในคอมโบ (ด่านจับคู่ผูกกับคู่นั้น)
            #   ⇒ ชั้นที่ค้างอยู่นอกคู่ในคอมโบ (สลับคอมโบไปคู่อื่นแล้ว) ต้องบอกชื่อ ไม่ใช่ให้กดปุ่มที่ไม่บันทึกงานนั้น
            _combo_ids = set()
            for _l in lyrs[:2]:
                try:
                    if _l is not None:
                        _combo_ids.add(_l.id())
                except Exception:
                    pass
            _combo_dirty, _outside = False, []
            for l in lyrs:
                try:
                    if l is not None and l.isEditable() and l.isModified():
                        dirty = True
                        if l.id() in _combo_ids:
                            _combo_dirty = True
                        elif l.name() not in _outside:
                            _outside.append(l.name())
                except Exception:
                    continue
            now = time.monotonic()
            if not dirty:
                self._unsaved_since = None
                return
            if self._unsaved_since is None:
                self._unsaved_since = now
                self._unsaved_last_nag = now
                return
            mins = (now - self._unsaved_since) / 60.0
            if mins >= self.UNSAVED_NAG_MIN and (now - self._unsaved_last_nag) / 60.0 >= self.UNSAVED_NAG_MIN:
                self._unsaved_last_nag = now
                # ★ 2.3.7 (review UX-23) — มีปุ่ม "💾 บันทึกเลย" (บันทึกผ่าน 💾 ปกติ ด่านครบ) · เดิมต้องไปหาปุ่มเอง
                if not _outside:
                    self._push_with_button(
                        "ยังไม่ได้บันทึก",
                        f"มีงานค้างยังไม่บันทึกมาแล้วประมาณ {int(mins)} นาที — แนะนำกด 💾 บันทึก "
                        "(ถ้าโปรแกรมปิดกะทันหัน งานที่ยังไม่บันทึกจะหายทั้งหมด)",
                        1, 12, "💾 บันทึกเลย", self._unsaved_save_now)
                    return
                # ★ rc2 (audit A5-08) — งานค้างอยู่ในชั้นนอกคู่ที่เลือก ⇒ บอกชื่อชั้น + วิธีบันทึก · ปุ่มบันทึกเฉพาะเมื่อคู่ในคอมโบมีงานค้างด้วย
                #   (เดิมปุ่มบันทึกแค่คู่ในคอมโบ ⇒ งานที่เตือนไม่ถูกบันทึก แล้วเตือนซ้ำใน 10 นาที)
                _nm = ", ".join("'%s'" % n for n in _outside[:3]) + (" …" if len(_outside) > 3 else "")
                _txt_o = (f"มีงานค้างยังไม่บันทึกมาแล้วประมาณ {int(mins)} นาที ในชั้น {_nm} ซึ่งไม่ใช่คู่ที่เลือกอยู่ในกล่องด้านบน — "
                          "เลือกคู่ชั้นนั้นแล้วกด 💾 บันทึก (ถ้าโปรแกรมปิดกะทันหัน งานที่ยังไม่บันทึกจะหายทั้งหมด)")
                if _combo_dirty:
                    self._push_with_button("ยังไม่ได้บันทึก", _txt_o + " · ปุ่มนี้บันทึกเฉพาะคู่ที่เลือกอยู่",
                                           1, 12, "💾 บันทึกคู่ที่เลือก", self._unsaved_save_now)
                else:
                    self.iface.messageBar().pushMessage("ยังไม่ได้บันทึก", _txt_o, level=1, duration=12)
        except Exception:
            pass

    def _unsaved_save_now(self):
        """★ 2.3.7 (review UX-23) ปุ่ม "💾 บันทึกเลย" บนคำเตือนงานค้าง — บันทึกคู่ในคอมโบผ่าน 💾 ปกติ"""
        if not getattr(self, "_alive", True):
            return
        try:
            if QtWidgets.QApplication.activeModalWidget() is not None:
                return                          # มีกล่องเปิดอยู่ ⇒ ไม่ซ้อนกล่อง
        except Exception:
            pass
        self.save_all_changes()

    def _clear_caches(self):
        """ล้าง cache ที่สะสมระหว่างใช้งาน — เรียกตอนปิดหน้าต่างหลัก

        ★ 1 ก.ย. 69 (เจ้าของงานถามเอง) เหตุผลคือ "ความถูกต้อง" ไม่ใช่ "หน่วยความจำ"
          cache แปลงล็อก L1 ถูกออกแบบให้ใช้ซ้ำทั้ง session โดยตั้งใจ (แก้อาการค้าง ~1 วิ
          หลัง Save ทุกครั้ง เมื่อ 4 ส.ค.) แต่การปิดหน้าต่างเป็นจังหวะที่พนักงานมักจะไป
          สลับ/โหลดโปรเจกต์ต่อ -> ล้างตรงนี้ปลอดภัยและแทบไม่มีต้นทุน
          (ต้นทุนเกิดตอนเปิดใช้เครื่องมือครั้งถัดไปเท่านั้น)

        🔴 ห้ามล้าง _signal_layers — มันกันการต่อ signal ซ้ำ ถ้าล้างจะต่อซ้อนกันหลายเส้น
        """
        self._locked_cache = None          # ตาราง UTM ของแปลงล็อก L1-RTK/L1-TS
        self._procsel_key = None           # คีย์จับคู่แปลง-หมุดของรอบก่อน
        for name in ("_field_cache", "_perm_cache", "_perm_down"):     # ★ rc2 (A5-01) + ช่วงพักถามสิทธิ์
            c = getattr(self, name, None)
            if isinstance(c, dict):
                c.clear()

    def _check_transaction_mode(self, l1_only=False):
        """เตือน (ครั้งเดียวต่อ session) ถ้าโปรเจกต์เปิด Automatic transaction groups
        — เลเยอร์ PostgreSQL ที่ใช้ connection เดียวกันจะแชร์ edit session ทำให้การนับ
        undo ต่อเลเยอร์ของปลั๊กอิน (_op_begin/_op_commit) ไม่ตรงกับความเป็นจริง
        ★ 2.4.0 (review DI-11) — อ่าน transactionMode() (autoTransaction() จริงเฉพาะ Automatic · เลิกใช้ใน 3.40)
          Buffered transaction groups: ปุ่มบันทึกของ QGIS บันทึกทั้งกลุ่มผ่าน QgsProject::commitChanges โดยไม่ยิง
          beforeCommitChanges ⇒ ด่านล็อก L1 ของปุ่มบันทึก QGIS ไม่ทำงาน (💾 ของปลั๊กอินยังถาม) ⇒ เตือนค้างจนกดปิด
          ครั้งเดียวต่อไฟล์โปรเจกต์ · เรียกตอนเปิดแผง และหลังเปิดโปรเจกต์/เพิ่มชั้น (_l1_arm_all ส่ง l1_only=True
          = ไม่ขึ้นคำเตือน Automatic ก่อนเปิดแผงแบบเดิม) · ด่านของปุ่ม QGIS ทำงานได้ในโหมดปิด (Disabled) และ Automatic"""
        try:
            _m = QgsProject.instance().transactionMode()
            buffered = _m == Qgis.TransactionMode.BufferedGroups
            on = _m == Qgis.TransactionMode.AutomaticGroups
        except Exception:
            buffered = False
            try:
                on = bool(QgsProject.instance().autoTransaction())
            except Exception:
                on = False
        if buffered:
            try:
                _key = QgsProject.instance().fileName() or "-"
            except Exception:
                _key = "-"
            if getattr(self, "_txn_buf_warned", None) != _key:
                self._txn_buf_warned = _key
                self.iface.messageBar().pushMessage(
                    "MLEP", "โปรเจกต์นี้ตั้ง Buffered transaction groups — ปุ่มบันทึกของ QGIS บันทึกทุกชั้นพร้อมกันโดยไม่ผ่าน"
                            "ด่านตรวจการแก้แปลง/หมุด L1 ของปลั๊กอิน (และระบบ Undo ของปลั๊กอินอาจนับไม่ตรง) · "
                            "ให้บันทึกด้วย 💾 ของปลั๊กอินซึ่งถามก่อนเสมอ หรือปิดที่ Project Properties → Data Sources",
                    level=1, duration=0)
            return
        if l1_only or getattr(self, "_txn_warned", False):
            return
        if on:
            self._txn_warned = True
            self.iface.messageBar().pushMessage(
                "MLEP", "โปรเจกต์นี้เปิด Automatic transaction groups — ระบบ Undo ของปลั๊กอิน"
                        "อาจนับไม่ตรงสำหรับเลเยอร์ PostgreSQL ที่ใช้ connection เดียวกัน "
                        "แนะนำปิดที่ Project Properties → Data Sources",
                level=1, duration=15)
