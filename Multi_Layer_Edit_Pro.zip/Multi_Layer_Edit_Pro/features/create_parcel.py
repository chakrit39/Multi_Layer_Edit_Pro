# -*- coding: utf-8 -*-
"""สร้างแปลงใหม่

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import re
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsExpression, QgsFeature,
                       QgsFeatureRequest, QgsGeometry, QgsPointXY, QgsProject, QgsRectangle, QgsWkbTypes)
from ..core.util import (_branch_office_of, _ep_hist_key, _ep_normalize, _EP_SCALES, _fld_idx, _is_chor, _log_exc,
                         _marker_type_from_parcel, _norm_utm, _probe_xy_24047, _public_landno, _rngw, _txt,
                         _UTM_FIELD_NAMES)
from ..map_tools import CreateParcelTool
from ..services.workers import ParcelLookupWorker


class CreateParcelMixin:
    """สร้างแปลงใหม่"""

    def _cp_types(self):
        """Type ที่ชั้นตอนนี้เลือกได้: ผู้ดูแล = ทุกชนิด · ผู้ช่วยผู้ดูแล = เฉพาะ L2 (คำตัดสิน 11 ต.ค.)"""
        return [t for t in self._CP_TYPES_ALL if self._is_admin() or not t.startswith("L1")]

    def start_create_parcel(self):
        title = self._CP_TITLE
        ready = self._mod_ready(title)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        if not self._pair_cols_ok(poly_lyr, point_lyr, title):
            return
        # สิทธิ์ฐาน: เพิ่มแปลง (INSERT ชั้นแปลง) — ผู้ช่วยผู้ดูแลต้องได้สิทธิ์จากผู้ดูแลฐานข้อมูลก่อน · เพิ่มหมุด (INSERT ชั้นหมุด)
        for lyr, what in ((poly_lyr, "แปลง"), (point_lyr, "หมุด")):
            if self._can_table_priv(lyr, "INSERT") is False:
                self._ask(QtWidgets.QMessageBox.Warning, title,
                          f"บัญชีที่ใช้อยู่ยังไม่มีสิทธิ์เพิ่ม{what}ในชั้น '{lyr.name()}' (INSERT)\n\n"
                          "แจ้งผู้ดูแลฐานข้อมูลให้เพิ่มสิทธิ์ก่อน — ถ้าฝืนสร้าง จะไปล้มตอนกดบันทึก")
                return
        self.cancel_transform()
        self._cp_lids = (poly_lyr.id(), point_lyr.id())
        self._cp_arm(poly_lyr, point_lyr)

    def _cp_arm(self, poly_lyr, point_lyr):
        """ติดตั้งเครื่องมือคลิกจุดตัวใหม่ (เริ่มรูปใหม่)"""
        canvas = self.iface.mapCanvas()
        self.temp_tool = CreateParcelTool(canvas, self, poly_lyr, point_lyr, self._cp_frame_done)
        canvas.setMapTool(self.temp_tool)
        self.temp_tool._hint()

    def _cp_geom(self, poly_lyr, point_lyr, pts):
        """จุดที่คลิก (CRS ชั้นหมุด) -> (รูปแปลงใน CRS ชั้นแปลง, None) หรือ (None, เหตุ)"""
        try:
            to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance())
                       if point_lyr.crs() != poly_lyr.crs() else None)
            ring = [to_poly.transform(QgsPointXY(p)) if to_poly else QgsPointXY(p) for p in pts]
        except Exception:
            return None, "แปลงพิกัดจุดที่คลิกไปเป็นระบบของชั้นแปลงไม่ได้"
        if len(ring) < 3:
            return None, "รูปแปลงต้องมีอย่างน้อย 3 จุด"
        g = QgsGeometry.fromPolygonXY([ring + [ring[0]]])
        if g is None or g.isEmpty():
            return None, "สร้างรูปจากจุดที่คลิกไม่ได้"
        if g.convexHull().area() <= 0:
            return None, "จุดที่คลิกเรียงอยู่แนวเดียวกัน — ไม่เป็นรูปแปลง"
        if not g.isGeosValid():
            return None, "รูปตัดกันเอง (ลำดับจุดไขว้กัน) — กด Backspace ถอยแล้วคลิกใหม่ตามแนวรอบแปลง"
        if self._geom_area_m2(poly_lyr, g) < 1.0:
            return None, "รูปเล็กกว่า 1 ตร.ม. — ตรวจจุดที่คลิก"
        if QgsWkbTypes.isMultiType(poly_lyr.wkbType()):
            g.convertToMultiType()
        return g, None

    def _cp_overlaps(self, poly_lyr, geom):
        """แปลงเดิมที่รูปใหม่ทับ (> 0.5 ตร.ม.) -> [(fid, Type, UTM, ทับ ตร.ม., % ของรูปใหม่)] เรียงมากไปน้อย"""
        out = []
        try:
            a0 = max(geom.area(), 1e-9)
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            _it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or not g.intersects(geom):
                        continue
                    it = g.intersection(geom).area()
                    if it > 0.5:
                        out.append((f.id(), self._poly_type_str(poly_lyr, f), _txt(f[pu]) if pu else "",
                                    it, 100.0 * it / a0))
            finally:
                _it.close()
        except Exception:
            _log_exc("สร้างรูปแปลง: ตรวจแปลงที่ทับไม่ได้")
        return sorted(out, key=lambda r: -r[3])

    def _cp_guess_key(self, poly_lyr, geom):
        """ระวาง/มาตราส่วนที่น่าจะใช่ (เติมไว้ในกล่อง) = ค่าที่พบบ่อยสุดของแปลงที่ทับ/ติดกับรูปใหม่ (รัศมี 5 ม.) · เลขที่ดินว่าง"""
        from collections import Counter
        cnt = Counter()
        try:
            r = geom.boundingBox()
            r.grow(5.0)
            idx = {k: _fld_idx(poly_lyr.fields(), k) for k in self._EP_KEYS}
            if min(idx.values()) < 0:
                return {}
            _it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r).setLimit(200))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or g.distance(geom) > 5.0:
                        continue
                    cnt[tuple(_txt(f[idx[k]]) for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"))] += 1
            finally:
                _it.close()
        except Exception:
            return {}
        if not cnt:
            return {}
        k = cnt.most_common(1)[0][0]
        return dict(zip(("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"), k))

    def _cp_used_landno_le0(self, poly_lyr, point_lyr, head, own=None):
        """เลขที่ดิน ≤ 0 ที่มีแปลงหรือหมุดใช้อยู่แล้วบนระวาง head (ระวาง 4 ท่อน + มาตราส่วน) -> set ของสตริง
        ★ 2.4.3 rc3 (ผลตรวจ Windows rc2 🟡1) — นับทั้งบัฟเฟอร์ (งานที่ยังไม่ 💾) และค่าในฐาน (dataProvider ไม่ผ่านบัฟเฟอร์)
          เลขที่งานค้างลบ/แก้คีย์ไปแล้วแต่ฐานยังมี ⇒ ไม่แจกซ้ำ · เดิม 💾 ล้มด้วย unique index คีย์ที่สาธารณะของฐาน
          (QGIS บันทึกการแก้ค่าก่อนการลบ ⇒ ไม่ลงอะไรเลย · ข้อความเป็น error ของ PostGIS)
        own = ★ rc4 (ผลตรวจ Windows rc3 ⚪1) แปลงที่ 📝 กำลังแก้ ⇒ ค่าในฐานของแปลงนี้ (และหมุดคีย์เดิมของมัน) ไม่นับ —
              เดิมแก้คีย์ค้างแล้วพิมพ์เลขที่สาธารณะเดิมของตัวเองกลับถูกบล็อก (แถวในฐานที่ถือเลขนั้นคือแปลงนี้เอง · 💾 ผ่านได้)"""
        used = set()
        own_fid, own_utm = None, ""
        if own is not None and poly_lyr is not None:
            try:
                fu0 = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
                if fu0 and own.id() >= 0:
                    _it0 = poly_lyr.dataProvider().getFeatures(QgsFeatureRequest(own.id()))
                    try:
                        for _pf in _it0:
                            own_fid, own_utm = own.id(), _txt(_pf[fu0])
                            break
                    finally:
                        _it0.close()                 # ★ 2.2.8 กติกา: ปิด QgsFeatureIterator เสมอ (sim35)
            except Exception:
                own_fid, own_utm = None, ""
        for lyr in (poly_lyr, point_lyr):
            if lyr is None:
                continue                        # ★ 2.4.3 rc2 — กล่อง 📝 ที่หาชั้นหมุดไม่ได้ (นับเฉพาะแปลง · ก่อนเขียนนับใหม่ครบทั้งคู่)
            fu = self._resolve_field(lyr, _UTM_FIELD_NAMES)
            if not fu:
                continue
            ex = '"%s" = %s OR "%s" LIKE %s' % (fu, QgsExpression.quotedValue(head + "0"), fu,
                                               QgsExpression.quotedValue(head + "-%"))
            srcs = [lyr]
            if lyr.isEditable() and lyr.dataProvider() is not None:
                srcs.append(lyr.dataProvider())
            for src in srcs:
                _db = src is not lyr
                _it = src.getFeatures(QgsFeatureRequest().setFilterExpression(ex).setNoAttributes()
                                      .setSubsetOfAttributes([fu], src.fields()).setFlags(QgsFeatureRequest.NoGeometry))
                try:
                    for f in _it:
                        u = _txt(f[fu])
                        if _db and own_fid is not None and ((lyr is poly_lyr and f.id() == own_fid)
                                                            or (lyr is point_lyr and own_utm and u == own_utm)):
                            continue
                        if u.startswith(head) and re.fullmatch(r"0|-[0-9]+", u[len(head):] or "x"):
                            used.add(u[len(head):])
                finally:
                    _it.close()
        return used

    def _cp_free_public_landno(self, poly_lyr, point_lyr, head, used=None, own=None):
        """★ 2.4.3 rc2 (ใช้ร่วม ➕ `_cp_check` / 📝 `_ep_public_landno`) — เลขที่ดินสาธารณะตัวแรกที่ว่างบนระวาง head:
        0 ถ้าว่าง ไม่งั้น -1, -2, … ตัวแรกที่ไม่มีแปลง/หมุดใช้ (คำสั่ง 24 ก.ย.) -> (เลข int, หมายเหตุ) · used = ผล `_cp_used_landno_le0` ที่มีแล้ว"""
        if used is None:
            used = self._cp_used_landno_le0(poly_lyr, point_lyr, head, own=own)
        n = 0
        while str(n) in used:
            n -= 1
        return n, ("เลขที่ดิน 0 = ที่สาธารณะ ⇒ ใช้เลข %s (%s)" % (n, "ระวางนี้ยังไม่มีที่สาธารณะ" if n == 0 else
                                                                "เลข 0" + "".join(", %d" % k for k in range(-1, n, -1))
                                                                + " มีแปลง/หมุดใช้แล้ว"))

    def _cp_check(self, poly_lyr, point_lyr, vals):
        """ตรวจค่าจากกล่อง -> (ค่าที่ใช้จริง, [ข้อผิด], [หมายเหตุ]) · ใช้ทั้งในกล่อง (เปิด/ปิดปุ่ม OK) และก่อนเขียน (ด่านซ้ำ)
        vals = {UTMMAP1..4, UTMSCALE, LANDNO, Type, DOC_TYPE, NAME, REGIS, AREA}
        🔑 เลขที่ดิน 0 = ที่สาธารณะ ⇒ คิดเลขให้เองไม่ให้ซ้ำ: 0 ถ้าระวางนั้นยังว่าง ไม่งั้น -1, -2, … ตัวแรกที่ไม่มีแปลง/หมุดใช้
           (เจ้าของงานสั่ง 24 ก.ย. — "ที่สาธารณะ ที่เลขที่ดิน <=0 คิด key ให้มันเองเลยจะได้ไม่ซ้ำ · เวลาใช้ปลั๊กอินก็จะได้ไม่มีปัญหา")"""
        v, err = _ep_normalize(vals.get("UTMMAP1"), vals.get("UTMMAP2"), vals.get("UTMMAP3"), vals.get("UTMMAP4"),
                               vals.get("UTMSCALE"), vals.get("LANDNO"))
        notes = []
        tp = _txt(vals.get("Type"))
        if tp not in self._cp_types():
            err.append("เลือกประเภทแปลง (Type)" if not tp else
                       f"Type {tp} — ชั้นของคุณสร้างได้เฉพาะ " + " · ".join(self._cp_types()))
        doc = _txt(vals.get("DOC_TYPE"))
        if doc and doc not in self._CP_DOC_CODES:
            err.append(f"ชนิดเอกสาร '{doc}' ไม่อยู่ในรายการรหัสของฐาน")
        regis = _txt(vals.get("REGIS"))
        if regis not in self._CP_REGIS:
            err.append(f"สถานะทะเบียน '{regis}' ไม่รู้จัก")
        if err:
            return v, err, notes
        head = v["UTMMAP1"] + v["UTMMAP2"] + v["UTMMAP3"] + v["UTMMAP4"] + v["UTMSCALE"]
        if v["LANDNO"] == "0":
            n, _note = self._cp_free_public_landno(poly_lyr, point_lyr, head)
            v["LANDNO"], v["UTM"] = str(n), head + str(n)
            notes.append(_note)
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        twins = self._utm_twin_fids(poly_lyr, pu, v["UTM"], _norm_utm(v["UTM"])) if pu else []
        if twins:
            err.append("คีย์ %s มีแปลงอยู่แล้ว (gid %s) — ตรวจเลขที่ดิน/ระวาง" % (v["UTM"], ", ".join(str(x) for x in twins[:5])))
        else:
            fu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if fu:
                ex = '"%s" = %s' % (fu, QgsExpression.quotedValue(v["UTM"]))
                n_mk = sum(1 for _f in point_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(ex).setNoAttributes()))
                if n_mk:
                    err.append("มีหมุดคีย์ %s อยู่แล้ว %d ดวง (แต่ไม่มีแปลง) — ตรวจ/ลบหมุดค้างก่อน" % (v["UTM"], n_mk))
        out = dict(v)
        out.update({"Type": tp, "DOC_TYPE": doc or None, "NAME": _txt(vals.get("NAME")) or None,
                    "REGIS": regis or None, "AREA": vals.get("AREA")})
        if out["DOC_TYPE"] is None and v["LANDNO"].startswith("-") or (out["DOC_TYPE"] is None and v["LANDNO"] == "0"):
            out["DOC_TYPE"] = "ที่สาธารณประโยชน์"           # เลขที่ดิน ≤ 0 = ที่สาธารณประโยชน์ (คำตัดสิน DOC_TYPE 8 ต.ค.)
        if out["DOC_TYPE"] is None and _fld_idx(poly_lyr.fields(), "DOC_TYPE") >= 0:
            # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "Doc_type ด้วย" · คำตัดสิน: บังคับเลือก) — ว่าง = หลบด่านโฉนดได้ (สร้างโฉนดโดยไม่บอกชนิด)
            #   ที่สาธารณะ (เลขที่ดิน ≤ 0) ได้ชนิดอัตโนมัติด้านบนแล้ว · ชั้นที่ไม่มีคอลัมน์ DOC_TYPE ไม่บังคับ
            err.append("เลือกชนิดเอกสารสิทธิ์")
        return out, err, notes

    def _cp_frame_done(self, pts, kinds):
        """ปิดรูปแล้ว -> ตรวจรูป → กล่องกรอกคีย์/ทะเบียน/Type/ชนิดเอกสาร/ผู้รับผิดชอบ → เขียนลงบัฟเฟอร์
        คืน True = สร้างแล้ว (ติดตั้งเครื่องมือตัวใหม่ให้สร้างรูปต่อ) · False = ยังไม่สร้าง (จุดที่คลิกยังอยู่ แก้ต่อได้)"""
        title = self._CP_TITLE
        ready = self._mod_ready(title)
        if not ready:
            if not self._is_mod():
                self.iface.messageBar().pushMessage(
                    title, "ยกเลิก — ไม่ได้อยู่ในโหมดผู้ดูแล/ผู้ช่วยผู้ดูแลแล้ว (เปิดโหมดแล้วกดปุ่มใหม่)", level=1, duration=8)
            self.iface.actionSelect().trigger()
            return False
        poly_lyr, point_lyr = ready
        if getattr(self, "_cp_lids", None) != (poly_lyr.id(), point_lyr.id()):
            self.iface.actionSelect().trigger()
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม — ยกเลิก\nกดปุ่ม ➕ สร้างรูปแปลง ใหม่อีกครั้ง")
            return False
        geom, why = self._cp_geom(poly_lyr, point_lyr, pts)
        if geom is None:
            self._ask(QtWidgets.QMessageBox.Warning, title, why + "\n\n(จุดที่คลิกไว้ยังอยู่ — ถอย/แก้ต่อได้)")
            return False
        area = self._geom_area_m2(poly_lyr, geom)
        overlaps = self._cp_overlaps(poly_lyr, geom)
        vals = self._cp_dialog(poly_lyr, point_lyr, geom, area, overlaps, len(pts))
        if vals is None:
            return False
        if not self._cp_apply(poly_lyr, point_lyr, geom, pts, vals):
            return False
        self._cp_arm(poly_lyr, point_lyr)       # สร้างรูปต่อได้เลย (เครื่องมือตัวใหม่ · รูปเดิมไม่ค้าง)
        return True

    def _cp_dialog(self, poly_lyr, point_lyr, geom, area, overlaps, n_pts):
        """กล่องกรอก: คีย์ (ระวาง 4 ท่อน · มาตราส่วน · เลขที่ดิน) + 🔍 ค้นทะเบียน + Type + ชนิดเอกสาร + ผู้รับผิดชอบ + สถานะทะเบียน
        -> dict (ผล _cp_check) หรือ None (ยกเลิก)"""
        import html as _html
        title = self._CP_TITLE
        guess = self._cp_guess_key(poly_lyr, geom)
        d = QtWidgets.QDialog(self.iface.mainWindow())
        d.setWindowTitle("➕ " + title)
        lay = QtWidgets.QVBoxLayout(d)
        info = [f"รูปใหม่ {n_pts} มุม · เนื้อที่ {area:,.2f} ตร.ม. ({_rngw(area)} ไร่-งาน-วา)"]
        if overlaps:
            l1 = [o for o in overlaps if (o[1] or "").upper().startswith("L1")]
            info.append(("<span style='color:#b71c1c'>" if l1 else "<span style='color:#e65100'>")
                        + f"ทับแปลงเดิม {len(overlaps)} แปลง: "
                        + " · ".join(_html.escape(f"gid {o[0]} {o[1] or '-'} ทับ {o[3]:,.1f} ตร.ม. ({o[4]:.0f}%)")
                                     for o in overlaps[:4]) + (" …" if len(overlaps) > 4 else "")
                        + ("<br><b>มีแปลง L1 อยู่ใต้รูปใหม่</b>" if l1 else "") + "</span>")
        lb = QtWidgets.QLabel("<br>".join(info))
        lb.setWordWrap(True)
        lay.addWidget(lb)
        form = QtWidgets.QFormLayout()
        eds = {}
        for k, mx in (("UTMMAP1", 4), ("UTMMAP2", 3), ("UTMMAP3", 4), ("UTMMAP4", 2)):
            ed = QtWidgets.QLineEdit(guess.get(k, ""))
            ed.setMaxLength(mx)
            eds[k] = ed
            form.addRow(k, ed)
        cb_sc = QtWidgets.QComboBox()
        cb_sc.addItems(list(_EP_SCALES))
        if guess.get("UTMSCALE") in _EP_SCALES:
            cb_sc.setCurrentIndex(_EP_SCALES.index(guess["UTMSCALE"]))
        form.addRow("UTMSCALE", cb_sc)
        ed_ln = QtWidgets.QLineEdit("")
        ed_ln.setMaxLength(7)
        ed_ln.setPlaceholderText("เลขที่ดิน (0 = ที่สาธารณะ — คิดเลขให้เอง)")
        form.addRow("LANDNO", ed_ln)
        btn_lk = QtWidgets.QPushButton("🔍 ค้นทะเบียนจากระบบกรม")
        lk_lbl = QtWidgets.QLabel("ยังไม่ได้ค้น — กดปุ่มเพื่อดึงเนื้อที่/สถานะทะเบียน "
                                  "(ไม่บังคับ ยกเว้นโฉนดที่ดิน — ต้องค้นและได้เนื้อที่ทะเบียนก่อนจึงจะสร้างได้)")
        lk_lbl.setWordWrap(True)
        # ★ rc2 (audit A3-07) — ข้อความผลค้นมีค่าจากระบบกรม (เลขโฉนด/หน้าสำรวจ/เนื้อที่) ⇒ แสดงเป็นข้อความล้วน
        #   (QLabel ปริยาย AutoText ⇒ บรรทัดแรกที่มีแท็กถูกตีความเป็น HTML รวม <img src=file:…>)
        lk_lbl.setTextFormat(QtCore.Qt.PlainText)
        form.addRow(btn_lk, lk_lbl)
        cb_tp = QtWidgets.QComboBox()
        cb_tp.addItem("— เลือก —", "")
        for t in self._cp_types():
            cb_tp.addItem(t, t)
        form.addRow("ประเภทแปลง (Type)", cb_tp)
        cb_doc = QtWidgets.QComboBox()
        cb_doc.addItem("— เลือก —", "")      # ★ 2.4.3 (คำตัดสิน 21 ต.ค.: บังคับเลือก 1 ใน 13 ค่า · เดิม "(ว่าง)" สร้างได้ ⇒ หลบด่านโฉนด)
        for c in self._CP_DOC_CODES:
            cb_doc.addItem(c, c)
        di = _fld_idx(poly_lyr.fields(), "DOC_TYPE")
        if di < 0:
            cb_doc.setEnabled(False)
            cb_doc.setToolTip("ชั้นแปลงนี้ไม่มีคอลัมน์ DOC_TYPE")
        form.addRow("ชนิดเอกสารสิทธิ์", cb_doc)
        cb_nm = QtWidgets.QComboBox()
        cb_nm.setEditable(True)
        cb_nm.addItem("")
        ni = _fld_idx(poly_lyr.fields(), "NAME")
        if ni >= 0:
            try:
                names = sorted({_txt(x) for x in poly_lyr.uniqueValues(ni, 5000) if _txt(x)})
            except Exception:
                names = []
            cb_nm.addItems(names)
        else:
            cb_nm.setEnabled(False)
        cb_nm.lineEdit().setPlaceholderText("ไม่มอบหมาย")
        form.addRow("ผู้รับผิดชอบ (มอบหมาย)", cb_nm)
        cb_rg = QtWidgets.QComboBox()
        for r in self._CP_REGIS:
            cb_rg.addItem(r or "(ว่าง)", r)
        # ★ 2.4.4 (เจ้าของงาน 23 ต.ค. 69 "ไม่จำเป็นต้องใส่ Regis ถ้าเลือกโฉนดมันต้องหาให้เอง" · "เอกสารอื่นๆปล่อย regis ว่างไว้ก่อน" ·
        #   ที่สาธารณะ = 'ไม่มีทะเบียน') — REGIS ตั้งเองแล้วล็อก: ผล 🔍 ของคีย์นี้ · เลขที่ดิน ≤ 0 = 'ไม่มีทะเบียน' · ไม่ได้ค้น/ไม่พบ = ว่าง
        cb_rg.setEnabled(False)
        cb_rg.setToolTip("ตั้งให้เองตามผลค้นทะเบียน (🔍) — ที่สาธารณะ = ไม่มีทะเบียน · ยังไม่ได้ค้น/ไม่พบ = ว่าง")
        form.addRow("สถานะทะเบียน (REGIS)", cb_rg)
        lay.addLayout(form)
        prev = QtWidgets.QLabel()
        prev.setWordWrap(True)
        lay.addWidget(prev)
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        bb.button(QtWidgets.QDialogButtonBox.Ok).setText("สร้างรูปแปลง")
        lay.addWidget(bb)
        # ★ 2.4.3 ด่านโฉนด: deed_utm = คีย์ที่ค้นแล้วผ่าน _ep_deed_block (ได้เนื้อที่ทะเบียน) · deed_why = เหตุที่ไม่ผ่าน ·
        #   doc_lock = ผลทะเบียน (ยืนยันแปลงได้) บอกว่าเป็นโฉนด ⇒ ล็อกช่องชนิดเอกสาร (คำตัดสิน 21 ต.ค. กันเปลี่ยนชนิดหลบด่าน)
        st = {"area": None, "lk_utm": None, "res": None, "busy": False,
              "deed_utm": None, "deed_why": None, "doc_lock": False, "gate": "", "regis": None}

        def _vals():
            # ★ 2.4.3 — ชนิดเอกสารอ่านตามว่ามีคอลัมน์ (เดิมดู isEnabled — ช่องที่ถูกล็อกตามผลทะเบียนจะกลายเป็นว่าง)
            return {"UTMMAP1": eds["UTMMAP1"].text(), "UTMMAP2": eds["UTMMAP2"].text(),
                    "UTMMAP3": eds["UTMMAP3"].text(), "UTMMAP4": eds["UTMMAP4"].text(),
                    "UTMSCALE": cb_sc.currentText(), "LANDNO": ed_ln.text(),
                    "Type": cb_tp.currentData(), "DOC_TYPE": cb_doc.currentData() if di >= 0 else "",
                    "NAME": cb_nm.currentText() if cb_nm.isEnabled() else "",
                    "REGIS": "",                # ★ 2.4.4 ไม่รับจากกล่อง — _upd ตั้งตามผลค้นของคีย์นี้
                    "AREA": st["area"]}

        _memo = {}

        def _upd(*_a):
            # ★ rc2 (audit A3-05) — _cp_check ถามฐาน (คีย์ซ้ำแปลง LIKE · นับหมุดคีย์เดียวกัน · เลขที่สาธารณะ) ทุกครั้งที่ถูกเรียก
            #   และ _upd ผูกกับทุกช่อง ⇒ พิมพ์ชื่อผู้รับผิดชอบ 10 ตัวอักษร = คิวรีชุดเดิม 10 รอบ บนเธรดหลัก
            #   ⇒ จำผลตามค่าที่มีผลกับการตรวจ (คีย์ · Type · ชนิดเอกสาร · REGIS) · ช่องชื่อ/เนื้อที่เปลี่ยน = ใช้ผลเดิม
            #   (ข้อมูลในฐานเปลี่ยนระหว่างกล่องเปิด ⇒ _cp_apply ตรวจซ้ำก่อนเขียนอยู่แล้ว)
            v = _vals()
            _k = tuple(_txt(v.get(x)) for x in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO",
                                                 "Type", "DOC_TYPE", "REGIS"))
            if _k not in _memo:
                if len(_memo) > 64:
                    _memo.clear()
                _memo[_k] = self._cp_check(poly_lyr, point_lyr, v)
            out, err, notes = _memo[_k]
            out = dict(out)
            if not err:
                out["NAME"] = _txt(v.get("NAME")) or None
                out["AREA"] = v.get("AREA")
            st["out"], st["err"] = out, err
            if st["lk_utm"] is not None and out.get("UTM") != st["lk_utm"]:
                st["area"], st["lk_utm"] = None, None          # คีย์เปลี่ยนหลังค้น ⇒ เนื้อที่ทะเบียนที่ได้ไม่ใช่ของคีย์นี้แล้ว
                st["regis"] = None                             # ★ 2.4.4 REGIS ก็เป็นของคีย์เดิม
                st["deed_utm"], st["deed_why"] = None, None    # ★ 2.4.3 ผลด่านโฉนดเป็นของคีย์เดิม
                if st["doc_lock"]:                             # ★ 2.4.3 ล็อกชนิดเอกสารผูกกับผลของคีย์เดิม ⇒ ปลด
                    st["doc_lock"] = False
                    cb_doc.setEnabled(di >= 0)
                    cb_doc.setToolTip("" if di >= 0 else "ชั้นแปลงนี้ไม่มีคอลัมน์ DOC_TYPE")
                lk_lbl.setText("คีย์เปลี่ยนหลังค้น — กดค้นใหม่ถ้าต้องการเนื้อที่/สถานะทะเบียน")
            # ★ 2.4.4 REGIS (ช่องล็อก) — ที่สาธารณะ = 'ไม่มีทะเบียน' · ผลค้นของคีย์นี้ · ไม่ได้ค้น/ไม่พบ = ว่าง
            _rg = ("ไม่มีทะเบียน" if _public_landno(out.get("LANDNO"))
                   else (st["regis"] or "") if (st["lk_utm"] is not None and st["lk_utm"] == out.get("UTM")) else "")
            if not err:
                out["REGIS"] = _rg or None
            _ri = cb_rg.findData(_rg)
            if _ri >= 0 and _ri != cb_rg.currentIndex():
                cb_rg.blockSignals(True)
                cb_rg.setCurrentIndex(_ri)
                cb_rg.blockSignals(False)
            # ★ 2.4.3 ด่านโฉนดที่ดิน (เจ้าของงาน 21 ต.ค. 69) — โฉนดต้องค้นทะเบียน + ได้เนื้อที่ของคีย์นี้ก่อน ปุ่มสร้างจึงเปิด
            #   (ไม่ใส่ใน _cp_check เพราะผลถูกจำด้วยคีย์ที่ไม่รวมเนื้อที่ · _cp_apply ตรวจซ้ำก่อนเขียนด้วย _deed_utm)
            gate = ""
            if not err and _txt(out.get("DOC_TYPE")) == self._DEED and _public_landno(out.get("LANDNO")):
                # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪8) — เดิมบอกให้กด 🔍 แต่ 🔍 ตอบ "ที่สาธารณะ — ไม่มีทะเบียนให้ค้น"
                gate = "เลขที่ดิน ≤ 0 = ที่สาธารณะ — เป็นโฉนดที่ดินไม่ได้ · เลือกชนิดเอกสารให้ตรง (เช่น ที่สาธารณประโยชน์)"
            elif not err and _txt(out.get("DOC_TYPE")) == self._DEED:
                if st["busy"]:
                    gate = "โฉนดที่ดิน — รอผลค้นทะเบียนก่อน"
                elif st["lk_utm"] != out.get("UTM"):
                    gate = "โฉนดที่ดิน — กด 🔍 ค้นทะเบียน (ต้องได้เนื้อที่ทะเบียนก่อนจึงจะสร้างได้)"
                elif st["deed_utm"] != out.get("UTM"):
                    gate = "โฉนดที่ดิน — สร้างไม่ได้: " + (st["deed_why"] or "ไม่ได้เนื้อที่ทะเบียน")
            st["gate"] = gate
            txt = []
            if not err:
                txt.append(f"UTM: <b>{_html.escape(out['UTM'])}</b>")
            txt += [_html.escape(n) for n in notes]
            if err:
                txt.append("<span style='color:#b71c1c'>" + "<br>".join(_html.escape(e) for e in err) + "</span>")
            if gate:
                txt.append("<span style='color:#b71c1c'>" + _html.escape(gate) + "</span>")
            if st["doc_lock"]:
                txt.append("ชนิดเอกสารล็อกตามผลทะเบียน (โฉนดที่ดิน) — เปลี่ยนคีย์แล้วค้นใหม่ถ้าไม่ใช่แปลงนี้")
            if st["area"]:
                txt.append(f"AREA (เนื้อที่ทะเบียน) = {st['area']:,.2f} ตร.ม.")
            prev.setText("<br>".join(txt))
            bb.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(not err and not gate)
            # ★ 2.4.2 rc5 (ผลตรวจ Windows rc4 ข้อพบ 1) — กำลังค้นอยู่ ⇒ ปุ่มค้นปิดไว้จนงานนั้นจบ (rc4 เปลี่ยนช่องใดก็เปิดคืน ⇒ ค้นซ้อน 2 งาน)
            btn_lk.setEnabled(not st["busy"]
                              and not [e for e in err if not e.startswith("เลือกประเภท") and not e.startswith("Type ")
                                       and not e.startswith("เลือกชนิดเอกสาร")])     # ★ 2.4.3 ผลทะเบียนเติมชนิดเอกสารให้

        def _lookup():
            if st["busy"]:
                return
            # ★ 2.4.3 ชนิดเอกสารยังไม่เลือกก็ค้นได้ (ตรวจแค่คีย์ · ผลทะเบียนเติม/ล็อกชนิดเอกสารให้)
            out, err, _n = self._cp_check(poly_lyr, point_lyr, dict(_vals(), Type=(self._cp_types() or [""])[0],
                                                                    DOC_TYPE=_vals().get("DOC_TYPE") or self._CP_DOC_CODES[-1]))
            if err:
                return
            if out["LANDNO"].startswith("-") or out["LANDNO"] == "0":
                lk_lbl.setText("ที่สาธารณะ — ไม่มีทะเบียนให้ค้น")
                return
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            try:
                c = geom.centroid().asPoint()
                if poly_lyr.crs() != dst:
                    c = QgsCoordinateTransform(poly_lyr.crs(), dst, QgsProject.instance()).transform(c)
                near = (c.x(), c.y())
            except Exception:
                near = None
            attrs = {"m1": out["UTMMAP1"], "m2": out["UTMMAP2"], "m3": out["UTMMAP3"], "m4": out["UTMMAP4"],
                     "scale": out["UTMSCALE"], "landno": out["LANDNO"], "near_xy": near,
                     "probe_xy": _probe_xy_24047(geom, poly_lyr.crs()),
                     "office_seq": _branch_office_of(poly_lyr)}                 # ★ 2.3.10 ล็อกสาขา
            st["busy"] = True
            btn_lk.setEnabled(False)
            lk_lbl.setText("กำลังค้นจากระบบกรม…")
            _upd()                                    # ★ 2.4.3 โฉนด: ปุ่มสร้างปิดระหว่างค้น (ค้นซ้ำหลังเคยได้เนื้อที่ก็ปิด)
            # ★ 2.4.2 rc4 (เจ้าของงาน 21 ต.ค. 69 "ปุ่มไหนที่เกี่ยวข้องกับทะเบียน ถ้าหาใน arcgis ไม่เจอ ให้ไปหาใน LIS เพิ่ม") — แบบ 🔍/📝
            w = ParcelLookupWorker(attrs, zone=47, lis_more=True)
            if not hasattr(self, "_net_workers"):
                self._net_workers = []
            self._net_workers.append(w)

            def _drop(_w=w):
                try:
                    self._net_workers.remove(_w)
                except Exception:
                    pass
                try:
                    _w.deleteLater()
                except Exception:
                    pass

            def _abandon():
                st["busy"] = False
                try:
                    lk_lbl.setText("ยกเลิกการค้นทะเบียน iLands แล้ว — กดค้นใหม่ได้")
                    _upd()
                except RuntimeError:
                    pass                                      # กล่องถูกปิดไปก่อน

            def _end(res, e, _utm=out["UTM"]):
                # ★ 2.4.3 (ผลตรวจ Windows rc5 N3c) — คีย์ในกล่องเปลี่ยนระหว่างค้น ⇒ เลิกตั้งแต่ตรงนี้ ไม่เด้งกล่องเข้าสู่ระบบของคีย์เดิม
                #   (เดิมเทียบคีย์หลังทางเข้าสู่ระบบ ⇒ ถามรหัสเปล่า ๆ แล้วทิ้งผล)
                if _txt((st.get("out") or {}).get("UTM")) != _txt(_utm):
                    if not (isinstance(res, dict) and res.get("lis") == "login"):
                        self._dol_log_lis_trace(res)
                    st["busy"] = False
                    try:
                        lk_lbl.setText("คีย์เปลี่ยนระหว่างค้น — ผลที่ได้เป็นของคีย์เดิม (ไม่ได้ใช้) · กดค้นใหม่")
                        _upd()
                    except RuntimeError:
                        pass                                  # กล่องถูกปิดไปก่อนผลมา
                    return
                if e is None and isinstance(res, dict) and res.get("lis") == "login" and _ep_hist_key(res):
                    # ★ 2.4.3 rc5 (ผลตรวจ Windows rc4 🟡1) — คีย์ชั้นประวัติ: ผลทะเบียนใช้กับ ➕ ไม่ได้อยู่แล้ว ⇒ ไม่เด้งกล่องเข้าสู่ระบบ
                    res = dict(res, lis="hist")
                if e is None and isinstance(res, dict) and res.get("lis") == "login":
                    # ★ 2.4.2 rc4 — ต้องค้นทะเบียน iLands แต่ยังไม่เข้าสู่ระบบ ⇒ กล่องเข้าสู่ระบบ แล้วค้นต่อ (ยกเลิก = ผลจากแผนที่)
                    try:
                        lk_lbl.setText("ต้องค้นต่อในทะเบียน iLands — เข้าสู่ระบบในกล่องที่เด้ง…")
                    except RuntimeError:
                        return                                # กล่องถูกปิดไปก่อนผลมา
                    self._dol_lis_continue(res, attrs, lambda r: _end(r, None), on_abandon=_abandon)
                    return
                self._dol_log_lis_trace(res)              # ★ 2.4.2 rc4 (ผลตรวจ Windows rc3 ข้อพบ 7)
                st["busy"] = False
                try:
                    ar = self._ep_area_result(res, e)
                except Exception:
                    ar = {"area": None, "regis": None, "note": "อ่านผลจากระบบกรมไม่ได้"}
                try:
                    # ★ 2.4.2 rc5 (ผลตรวจ Windows rc4 ข้อพบ 1) — คีย์ในกล่องเปลี่ยนระหว่างค้น ⇒ ผลนี้เป็นของคีย์เดิม: ไม่ใช้ (ไม่ตั้ง REGIS/ชนิดเอกสาร/เนื้อที่)
                    if _txt((st.get("out") or {}).get("UTM")) != _txt(_utm):
                        lk_lbl.setText("คีย์เปลี่ยนระหว่างค้น — ผลที่ได้เป็นของคีย์เดิม (ไม่ได้ใช้) · กดค้นใหม่")
                        _upd()
                        return
                    lk_lbl.setText(ar["note"].replace("กดปุ่มนี้ซ้ำภายหลังเพื่อดึงใหม่", "กดค้นใหม่ภายหลังได้")
                                   .replace("คงเนื้อที่ทะเบียนเดิม — ", ""))
                    st["area"], st["lk_utm"] = ar.get("area"), _utm
                    # ★ 2.4.3 ด่านโฉนด — ผลของคีย์นี้ผ่านไหม (ได้เนื้อที่ทะเบียน · ไม่ใช่แค่ชั้นประวัติ)
                    st["deed_why"] = self._ep_deed_block(res, ar)
                    st["deed_utm"] = _utm if st["deed_why"] is None else None
                    st["regis"] = ar.get("regis")             # ★ 2.4.4 REGIS ตามผลของคีย์นี้ — _upd ตั้งช่อง (ล็อก) ให้
                    # ★ 2.4.3 (ผลตรวจ Windows rc4 ⚪4) — เติมชนิดเอกสารเฉพาะผลที่ยืนยันเป็นแปลงนี้ได้
                    #   (เดิมดูแค่ verified ⇒ ผลทะเบียนคร่อมสาขาที่ "ยืนยันไม่ได้ว่าเป็นแปลงนี้" ก็เติมโฉนดให้)
                    _sure = (isinstance(res, dict) and bool(res.get("verified")) and not res.get("cross_office")
                             and (ar.get("area") is not None or bool(ar.get("regis")))
                             # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪5) แผนที่มีเลขนี้หลายแปลง + ชั้นไม่ล็อกสาขา ⇒ ไม่เติม/ล็อกชนิดเอกสาร
                             and not ((res.get("match_count") or 1) > 1 and not res.get("branch_office")))
                    pt_ = _txt(res.get("parcel_type")) if _sure else ""
                    if pt_ and di >= 0:
                        i = cb_doc.findData(pt_)
                        if i >= 0 and (pt_ == self._DEED or not cb_doc.currentData()):
                            cb_doc.setCurrentIndex(i)
                            if pt_ == self._DEED:
                                # ★ 2.4.3 คำตัดสิน 21 ต.ค. — ทะเบียนบอกว่าเป็นโฉนด ⇒ ล็อกช่องชนิดเอกสาร (กันเปลี่ยนเป็นชนิดอื่นเพื่อหลบด่าน)
                                st["doc_lock"] = True
                                cb_doc.setEnabled(False)
                                cb_doc.setToolTip("ล็อกตามผลทะเบียน: แปลงนี้เป็นโฉนดที่ดิน")
                    _upd()
                except RuntimeError:
                    pass                                      # กล่องถูกปิดไปก่อนผลมา
            w.finished.connect(_drop)
            w.done.connect(lambda res: _end(res, None))
            w.fail.connect(lambda msg: _end(None, msg))
            w.start()

        for wdg in list(eds.values()) + [ed_ln]:
            wdg.textChanged.connect(_upd)
        for c in (cb_sc, cb_tp, cb_doc):          # ★ 2.4.4 cb_rg ล็อก (_upd ตั้งให้เอง)
            c.currentIndexChanged.connect(_upd)
        cb_nm.editTextChanged.connect(_upd)
        btn_lk.clicked.connect(_lookup)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        _upd()
        self._modal_busy = True
        try:
            ok = d.exec_() == QtWidgets.QDialog.Accepted
        finally:
            self._modal_busy = False
            d.deleteLater()
        if not ok or st.get("err") or st.get("gate"):
            return None
        out = dict(st["out"])
        out["AREA"] = st["area"] if st["lk_utm"] == out.get("UTM") else None
        out["_deed_utm"] = st["deed_utm"]             # ★ 2.4.3 ด่านโฉนด: _cp_apply ตรวจซ้ำก่อนเขียน (คีย์ที่ค้นแล้วผ่าน)
        l1 = [o for o in overlaps if (o[1] or "").upper().startswith("L1")]
        if l1 and self._ask(QtWidgets.QMessageBox.Warning, title,
                            f"รูปใหม่ทับแปลง L1 {len(l1)} แปลง (ชั้นอ้างอิงพิกัดหลัก) — สร้างทับจริงหรือไม่?",
                            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                            QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return None
        return out

    def _cp_names_at(self, point_lyr, xy, tol=0.01):
        """ชื่อหมุดที่ตำแหน่งนี้ (≤ 1 ซม.) — ชื่อจริงก่อน ชร · ไม่มี = ''  (มุมที่คลิกหมุด = ยืมชื่อหมุดนั้น)"""
        nf = self._addnode_name_field(point_lyr)
        if nf is None:
            return ""
        names = []
        rect = QgsRectangle(xy.x() - tol, xy.y() - tol, xy.x() + tol, xy.y() + tol)
        _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect))
        try:
            for f in _it:
                g = f.geometry()
                if g is None or g.isEmpty() or g.asPoint().distance(xy) > tol:
                    continue
                nm = _txt(f[nf])
                if nm and nm not in names:
                    names.append(nm)
        finally:
            _it.close()
        names.sort(key=lambda n: _is_chor(n))
        return names[0] if names else ""

    def _cp_apply(self, poly_lyr, point_lyr, geom, pts, vals):
        """เขียนแปลงใหม่ + หมุดทุกมุม ลงบัฟเฟอร์ในคำสั่งเดียว (↺ Undo คืนทั้งคู่) · ล้มที่ใด = ทิ้งทั้งชุด"""
        title = self._CP_TITLE
        if not self._is_mod():
            return False
        _in = dict(vals)
        if re.fullmatch(r"-[0-9]+", _txt(_in.get("LANDNO"))):
            _in["LANDNO"] = "0"     # เลขที่สาธารณะที่กล่องคิดไว้ ⇒ ส่ง 0 ให้คิดใหม่ (_ep_normalize ไม่รับเลขติดลบ · ข้อมูลอาจเปลี่ยนระหว่างกล่องเปิด)
        out, err, _n = self._cp_check(poly_lyr, point_lyr, _in)           # ด่านซ้ำก่อนเขียน (ข้อมูลอาจเปลี่ยนระหว่างกล่องเปิด)
        if err:
            self._ask(QtWidgets.QMessageBox.Warning, title, "สร้างไม่ได้:\n" + "\n".join(err))
            return False
        out["AREA"] = vals.get("AREA")
        if _public_landno(out.get("LANDNO")):
            out["REGIS"] = "ไม่มีทะเบียน"      # ★ 2.4.4 ที่สาธารณะ (เลขที่ดิน ≤ 0) ไม่มีทะเบียนเสมอ (เจ้าของงาน 23 ต.ค. 69) · ทางเรียกตรงด้วย
        # ★ 2.4.3 ด่านโฉนดที่ดิน (ด่านสุดท้ายก่อนเขียน · ทางเรียกตรง) — ต้องมีเนื้อที่ทะเบียนจากการค้นที่ผ่านด่านของคีย์นี้
        if _txt(out.get("DOC_TYPE")) == self._DEED and not (out.get("AREA") and _txt(vals.get("_deed_utm")) == _txt(out.get("UTM"))):
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "สร้างไม่ได้:\nโฉนดที่ดินต้องค้นทะเบียนและได้เนื้อที่ทะเบียนของคีย์นี้ก่อน (🔍 ค้นทะเบียนในกล่องสร้างรูปแปลง)")
            return False
        nm_f = self._addnode_name_field(point_lyr)
        pf, mf = poly_lyr.fields(), point_lyr.fields()
        nf = QgsFeature(pf)
        nf.setGeometry(geom)
        for k in self._EP_KEYS + ("UTM", "Type", "REGIS", "DOC_TYPE", "NAME"):
            i = _fld_idx(pf, k)
            if i >= 0 and out.get(k) not in (None, ""):
                nf.setAttribute(i, out[k])
        ga = self._geom_area_m2(poly_lyr, geom)
        if out.get("AREA"):
            i = _fld_idx(pf, "AREA")
            if i >= 0:
                nf.setAttribute(i, float(round(out["AREA"], 2)))
            i = _fld_idx(pf, "DIFF_AREA")
            if i >= 0 and out["AREA"] > 0:
                nf.setAttribute(i, round((ga - out["AREA"]) / out["AREA"] * 100.0, 2))   # สูตรเดียวกับ trigger (ร้อยละ)
        i = _fld_idx(pf, "UPDATED_BY")
        if i >= 0:
            try:
                from qgis.core import QgsDataSourceUri
                u = QgsDataSourceUri(poly_lyr.dataProvider().dataSourceUri()).username()
            except Exception:
                u = ""
            if u:
                nf.setAttribute(i, u)
        i = _fld_idx(pf, "DATE_STAMP")
        if i >= 0:
            import datetime as _dt
            nf.setAttribute(i, _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        marks = []
        for p in pts:
            m = QgsFeature(mf)
            m.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(p)))
            for k in self._EP_KEYS + ("UTM", "Type", "REGIS"):
                j = _fld_idx(mf, k)
                # ★ rc2 (audit A2-03) — Type ของหมุดผ่าน _marker_type_from_parcel ที่เดียวกับ Add Node / 🍩 (CT-RTK ⇒ ไม่ตั้ง)
                _v = _marker_type_from_parcel(out.get(k)) if k == "Type" else out.get(k)
                if j >= 0 and _v not in (None, ""):
                    m.setAttribute(j, _v)
            nm = self._cp_names_at(point_lyr, QgsPointXY(p))
            if nm and nm_f is not None:
                m.setAttribute(mf.indexOf(nm_f), nm)
            j = _fld_idx(mf, "EDIT_SRC")
            if j >= 0:
                m.setAttribute(j, self._CP_EDIT_SRC)
            marks.append((m, nm))
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(poly_lyr, point_lyr, title=title, what="ยังไม่ได้สร้างรูปแปลง"):
            return False
        self._op_begin([poly_lyr, point_lyr])
        poly_lyr.beginEditCommand("Create Parcel")
        point_lyr.beginEditCommand("Create Parcel Markers")
        ok = False
        try:
            ok = poly_lyr.addFeature(nf)
            for m, _nm in marks:
                ok = ok and point_lyr.addFeature(m)
        except Exception:
            _log_exc("สร้างรูปแปลง: เขียนลงบัฟเฟอร์ไม่สำเร็จ")
            ok = False
        if ok:
            poly_lyr.endEditCommand()
            point_lyr.endEditCommand()
        else:
            poly_lyr.destroyEditCommand()
            point_lyr.destroyEditCommand()
        self._op_commit()
        if not ok:
            self.iface.messageBar().pushMessage(title, "สร้างรูปแปลงไม่สำเร็จ — ยกเลิกทั้งหมดแล้ว (ไม่มีแปลง/หมุดค้าง) · " + self._LOG_HINT,
                                                level=2, duration=10)
            return False
        self.iface.mapCanvas().refresh()
        n_blank = sum(1 for _m, nm in marks if not nm)
        self.iface.messageBar().pushMessage(
            title, f"สร้างแปลง {out['UTM']} ({out['Type']}) + หมุด {len(marks)} ดวง"
                   + (f" (ไม่มีชื่อ {n_blank} ดวง — ตั้งชื่อทีหลังด้วย Add Node/แก้ชื่อหมุด)" if n_blank else "")
                   + " • กด 💾 บันทึก เพื่อลงฐาน • คลิกสร้างรูปต่อได้เลย",
            level=0, duration=10)
        return True
