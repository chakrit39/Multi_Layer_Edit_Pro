# -*- coding: utf-8 -*-
"""สร้างแปลงใหม่

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import re
import unicodedata
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import (Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsExpression, QgsFeature, QgsMessageLog,
                       QgsFeatureRequest, QgsGeometry, QgsPointXY, QgsProject, QgsRectangle, QgsWkbTypes)
from ..core.util import (_AIR_SCALES, _branch_office_of, _dol_area_diff, _ep_normalize, _EP_SCALES, _fld_idx, _is_chor, _log_exc,
                         _marker_type_from_parcel, _nm_for_login, _norm_utm, _probe_xy_24047, _public_landno, _REG_COLS, _reg_txt, _rngw,
                         _txt, _UTM_FIELD_NAMES)
from ..map_tools import CreateParcelTool
from ..services.workers import _FnWorker, ParcelLookupWorker


class CreateParcelMixin:
    """สร้างแปลงใหม่"""

    def _cp_types(self):
        """Type ที่ชั้นตอนนี้เลือกได้: ผู้ดูแล = ทุกชนิด · ผู้ช่วยผู้ดูแล = เฉพาะ L2 (คำตัดสิน 11 ต.ค.)"""
        return [t for t in self._CP_TYPES_ALL if self._is_admin() or not t.startswith("L1")]

    def start_create_parcel(self):
        title = self._CP_TITLE
        ready = self._mod_ready(title)
        if not ready:
            return
        poly_lyr, point_lyr = ready
        if not self._pair_cols_ok(poly_lyr, point_lyr, title):
            return
        # สิทธิ์ฐาน: เพิ่มแปลง (INSERT ชั้นแปลง) — ผู้ช่วยผู้ดูแลต้องได้สิทธิ์จากผู้ดูแลฐานข้อมูลก่อน · เพิ่มหมุด (INSERT ชั้นหมุด)
        for lyr, what in ((poly_lyr, "แปลง"), (point_lyr, "หมุด")):
            if self._can_table_priv(lyr, "INSERT") is False:
                self._ask(QtWidgets.QMessageBox.Warning, title,
                          f"บัญชีที่ใช้อยู่ยังไม่มีสิทธิ์เพิ่ม{what}ในชั้น '{lyr.name()}' (INSERT)\n\n"
                          "แจ้งผู้ดูแลฐานข้อมูลให้เพิ่มสิทธิ์ก่อน — ถ้าฝืนสร้าง จะไปล้มตอนกดบันทึก")
                return
        self.cancel_transform()
        self._cp_lids = (poly_lyr.id(), point_lyr.id())
        self._cp_arm(poly_lyr, point_lyr)

    def _cp_arm(self, poly_lyr, point_lyr):
        """ติดตั้งเครื่องมือคลิกจุดตัวใหม่ (เริ่มรูปใหม่)"""
        canvas = self.iface.mapCanvas()
        self.temp_tool = CreateParcelTool(canvas, self, poly_lyr, point_lyr, self._cp_frame_done)
        canvas.setMapTool(self.temp_tool)
        self.temp_tool._hint()

    def _cp_geom(self, poly_lyr, point_lyr, pts):
        """จุดที่คลิก (CRS ชั้นหมุด) -> (รูปแปลงใน CRS ชั้นแปลง, None) หรือ (None, เหตุ)"""
        try:
            to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance())
                       if point_lyr.crs() != poly_lyr.crs() else None)
            ring = [to_poly.transform(QgsPointXY(p)) if to_poly else QgsPointXY(p) for p in pts]
        except Exception:
            return None, "แปลงพิกัดจุดที่คลิกไปเป็นระบบของชั้นแปลงไม่ได้"
        if len(ring) < 3:
            return None, "รูปแปลงต้องมีอย่างน้อย 3 จุด"
        g = QgsGeometry.fromPolygonXY([ring + [ring[0]]])
        if g is None or g.isEmpty():
            return None, "สร้างรูปจากจุดที่คลิกไม่ได้"
        if g.convexHull().area() <= 0:
            return None, "จุดที่คลิกเรียงอยู่แนวเดียวกัน — ไม่เป็นรูปแปลง"
        if not g.isGeosValid():
            return None, "รูปตัดกันเอง (ลำดับจุดไขว้กัน) — กด Backspace ถอยแล้วคลิกใหม่ตามแนวรอบแปลง"
        if self._geom_area_m2(poly_lyr, g) < 1.0:
            return None, "รูปเล็กกว่า 1 ตร.ม. — ตรวจจุดที่คลิก"
        if QgsWkbTypes.isMultiType(poly_lyr.wkbType()):
            g.convertToMultiType()
        return g, None

    def _cp_overlaps(self, poly_lyr, geom):
        """แปลงเดิมที่รูปใหม่ทับ (> 0.5 ตร.ม.) -> [(fid, Type, UTM, ทับ ตร.ม., % ของรูปใหม่)] เรียงมากไปน้อย"""
        out = []
        try:
            a0 = max(geom.area(), 1e-9)
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            _it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(geom.boundingBox()))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or not g.intersects(geom):
                        continue
                    it = g.intersection(geom).area()
                    if it > 0.5:
                        out.append((f.id(), self._poly_type_str(poly_lyr, f), _txt(f[pu]) if pu else "",
                                    it, 100.0 * it / a0))
            finally:
                _it.close()
        except Exception:
            _log_exc("สร้างรูปแปลง: ตรวจแปลงที่ทับไม่ได้")
        return sorted(out, key=lambda r: -r[3])

    def _cp_guess_key(self, poly_lyr, geom):
        """ระวาง/มาตราส่วนที่น่าจะใช่ (เติมไว้ในกล่อง) = ค่าที่พบบ่อยสุดของแปลงที่ทับ/ติดกับรูปใหม่ (รัศมี 5 ม.) · เลขที่ดินว่าง"""
        from collections import Counter
        cnt = Counter()
        try:
            r = geom.boundingBox()
            r.grow(5.0)
            idx = {k: _fld_idx(poly_lyr.fields(), k) for k in self._EP_KEYS}
            if min(idx.values()) < 0:
                return {}
            _it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r).setLimit(200))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or g.distance(geom) > 5.0:
                        continue
                    _t = tuple(_txt(f[idx[k]]) for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"))
                    # ★ 2.4.8 เฉพาะระวาง UTM (ระวางของแปลงที่ตั้งคีย์ให้อัตโนมัติ · _key_lock_sync) — คีย์ระวางรูปถ่ายของ น.ส.3 ก
                    #   (UTMMAP3 ว่าง) / คีย์จัดรูปไม่ได้ ไม่ใช่ระวาง UTM · ★ 2.4.8 rc3 (ผลตรวจ Windows 2.4.8 rc2 🟡1 agent B) นับระวางที่จัดรูปแล้ว —
                    #   เดิมนับค่าดิบที่ทุกช่องมีค่า ⇒ 1:4000 ที่ UTMMAP4 ว่าง/NULL ไม่ถูกนับ ⇒ เดาเป็นระวางของแปลงเสียงข้างน้อยแล้วล็อก (2.4.7 เติมให้
                    #   แก้ได้) · คีย์ดิบครบที่จัดรูปไม่ได้ (UTMMAP4 00 ของ 1:1000 · UTMMAP2 0 — ฐานจริง 104 แปลง) ⇒ เดิมล็อกระวางที่ใช้ไม่ได้
                    _v, _e = _ep_normalize(_t[0], _t[1], _t[2], _t[3], _t[4], "0", public_neg=True)
                    if not _e:
                        cnt[tuple(_v[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"))] += 1
            finally:
                _it.close()
        except Exception:
            return {}
        if not cnt:
            return {}
        k = cnt.most_common(1)[0][0]
        return dict(zip(("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"), k))

    def _cp_used_landno_le0(self, poly_lyr, point_lyr, head, own=None):
        """เลขที่ดิน ≤ 0 ที่มีแปลงหรือหมุดใช้อยู่แล้วบนระวาง head (ระวาง 4 ท่อน + มาตราส่วน) -> set ของสตริง
        ★ 2.4.3 rc3 (ผลตรวจ Windows rc2 🟡1) — นับทั้งบัฟเฟอร์ (งานที่ยังไม่ 💾) และค่าในฐาน (dataProvider ไม่ผ่านบัฟเฟอร์)
          เลขที่งานค้างลบ/แก้คีย์ไปแล้วแต่ฐานยังมี ⇒ ไม่แจกซ้ำ · เดิม 💾 ล้มด้วย unique index คีย์ที่สาธารณะของฐาน
          (QGIS บันทึกการแก้ค่าก่อนการลบ ⇒ ไม่ลงอะไรเลย · ข้อความเป็น error ของ PostGIS)
        own = ★ rc4 (ผลตรวจ Windows rc3 ⚪1) แปลงที่ 📝 กำลังแก้ ⇒ ค่าในฐานของแปลงนี้ (และหมุดคีย์เดิมของมัน) ไม่นับ —
              เดิมแก้คีย์ค้างแล้วพิมพ์เลขที่สาธารณะเดิมของตัวเองกลับถูกบล็อก (แถวในฐานที่ถือเลขนั้นคือแปลงนี้เอง · 💾 ผ่านได้)"""
        used = set()
        own_fid, own_utm = None, ""
        if own is not None and poly_lyr is not None:
            try:
                fu0 = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
                if fu0 and own.id() >= 0:
                    _it0 = poly_lyr.dataProvider().getFeatures(QgsFeatureRequest(own.id()))
                    try:
                        for _pf in _it0:
                            own_fid, own_utm = own.id(), _txt(_pf[fu0])
                            break
                    finally:
                        _it0.close()                 # ★ 2.2.8 กติกา: ปิด QgsFeatureIterator เสมอ (sim35)
            except Exception:
                own_fid, own_utm = None, ""
        for lyr in (poly_lyr, point_lyr):
            if lyr is None:
                continue                        # ★ 2.4.3 rc2 — กล่อง 📝 ที่หาชั้นหมุดไม่ได้ (นับเฉพาะแปลง · ก่อนเขียนนับใหม่ครบทั้งคู่)
            fu = self._resolve_field(lyr, _UTM_FIELD_NAMES)
            if not fu:
                continue
            ex = '"%s" = %s OR "%s" LIKE %s' % (fu, QgsExpression.quotedValue(head + "0"), fu,
                                               QgsExpression.quotedValue(head + "-%"))
            srcs = [lyr]
            if lyr.isEditable() and lyr.dataProvider() is not None:
                srcs.append(lyr.dataProvider())
            for src in srcs:
                _db = src is not lyr
                _it = src.getFeatures(QgsFeatureRequest().setFilterExpression(ex).setNoAttributes()
                                      .setSubsetOfAttributes([fu], src.fields()).setFlags(QgsFeatureRequest.NoGeometry))
                try:
                    for f in _it:
                        u = _txt(f[fu])
                        if _db and own_fid is not None and ((lyr is poly_lyr and f.id() == own_fid)
                                                            or (lyr is point_lyr and own_utm and u == own_utm)):
                            continue
                        if u.startswith(head) and re.fullmatch(r"0|-[0-9]+", u[len(head):] or "x"):
                            used.add(u[len(head):])
                finally:
                    _it.close()
        return used

    def _pub_key_refresh(self, lid):
        """★ 2.4.11 (เจ้าของงาน 29 ต.ค. 69 "หาวิธีแก้ไม่ให้เกิดขึ้นอีก" · เคสปทุม 5036 I 6048-00 1:4000: พนักงาน 2 คนทำระวางเดียวกัน —
        เลข −21 ที่ปลั๊กอินแจกตอนสร้างถูกอีกคนบันทึกไปก่อน (09:52) ⇒ บันทึก 10:56 ด้วยปุ่มของ QGIS: ชั้นหมุดลงก่อน แล้วแปลงชนด่าน unique
        `<สาขา>_POLYGON_pub_utm_uq` ⇒ บันทึกบางส่วน · ต่อมากด Discard ⇒ แปลงหาย หมุดค้าง 47 ตัว)
        ก่อนชั้นใดของคู่ลงฐาน (beforeCommitChanges ทั้งชั้นแปลงและชั้นหมุด — ปุ่ม 💾 ของปลั๊กอินหรือของ QGIS): แปลงในงาน (เพิ่มใหม่/แก้ UTM)
        ที่คีย์เป็นเลข ≤ 0 แต่ฐานมีแปลงอื่นใช้คีย์นั้นแล้ว ⇒ เปลี่ยนเป็นเลขว่างถัดไป (นับฐาน + งานค้าง ทั้งแปลงและหมุด — _cp_used_landno_le0)
        ให้ทั้งแปลงและหมุดในงานเดียวกันที่ใช้คีย์เดิม (เพิ่มใหม่/แก้ค่า) · หมุดในฐานของแปลงอื่นไม่แตะ · แจ้งแถบข้อความ + กล่อง + Log
        -> [(คีย์เดิม, คีย์ใหม่, จำนวนหมุดที่เปลี่ยน)]"""
        try:
            poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
            point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        except Exception:
            return []
        if poly_lyr is None or lid not in (poly_lyr.id(), point_lyr.id() if point_lyr is not None else None):
            return []
        buf = poly_lyr.editBuffer() if poly_lyr.isEditable() else None
        if buf is None or poly_lyr.dataProvider() is None:
            return []
        fu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        pf = poly_lyr.fields()
        iu, iln = (pf.indexOf(fu) if fu else -1), _fld_idx(pf, "LANDNO")
        if iu < 0 or iln < 0:
            return []
        cand = list(buf.addedFeatures().keys()) + [fid for fid, ch in buf.changedAttributeValues().items() if iu in ch]
        mbuf = point_lyr.editBuffer() if (point_lyr is not None and point_lyr.isEditable()) else None
        mu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES) if mbuf is not None else None
        mf = point_lyr.fields() if mbuf is not None else None
        imu, imln = ((mf.indexOf(mu) if mu else -1), _fld_idx(mf, "LANDNO")) if mbuf is not None else (-1, -1)
        out, used_by = [], {}
        for fid in dict.fromkeys(cand):
            f = poly_lyr.getFeature(fid)
            if not f.isValid():
                continue
            u, ln = _txt(f[iu]), _txt(f[iln])
            if not (re.fullmatch(r"0|-[0-9]+", ln) and u.endswith(ln) and len(u) > len(ln)):
                continue
            _it = poly_lyr.dataProvider().getFeatures(QgsFeatureRequest().setFilterExpression(
                '"%s" = %s' % (fu, QgsExpression.quotedValue(u))).setNoAttributes().setFlags(QgsFeatureRequest.NoGeometry))
            try:
                clash = [g.id() for g in _it if g.id() != fid]
            finally:
                _it.close()                          # ★ กติกา sim35: ปิด QgsFeatureIterator เสมอ
            if not clash:
                continue
            head = u[:len(u) - len(ln)]
            used = used_by.get(head)
            if used is None:
                used = used_by[head] = self._cp_used_landno_le0(poly_lyr, point_lyr, head)
            n, _w = self._cp_free_public_landno(poly_lyr, point_lyr, head, used=used)
            nl, nu = str(n), head + str(n)
            used.add(nl)
            poly_lyr.changeAttributeValue(fid, iln, int(nl) if pf.at(iln).isNumeric() else nl)
            poly_lyr.changeAttributeValue(fid, iu, nu)
            nmk = 0
            if imu >= 0:
                mids = list(mbuf.addedFeatures().keys()) + [k for k, ch in mbuf.changedAttributeValues().items() if imu in ch]
                for mid in dict.fromkeys(mids):
                    m = point_lyr.getFeature(mid)
                    if m.isValid() and _txt(m[imu]) == u:
                        point_lyr.changeAttributeValue(mid, imu, nu)
                        if imln >= 0:
                            point_lyr.changeAttributeValue(mid, imln, int(nl) if mf.at(imln).isNumeric() else nl)
                        nmk += 1
            out.append((u, nu, nmk))
        if out:
            lines = [f"• {a} → {b} (หมุดในงานนี้ {k} ตัวเปลี่ยนตาม)" for a, b, k in out]
            try:
                QgsMessageLog.logMessage("2.4.11 เลขที่สาธารณะชนกับแปลงที่บันทึกไปก่อน — เปลี่ยนก่อนลงฐาน: " + " / ".join(lines),
                                         "MLEP", Qgis.Warning)
                self.iface.messageBar().pushMessage(
                    "เปลี่ยนเลขที่ดินสาธารณะที่ชนกัน", "มีแปลงอื่นบันทึกเลขนี้ไปก่อน — เปลี่ยนให้แล้วก่อนบันทึก: "
                    + " · ".join(f"{a} → {b}" for a, b, _k in out), level=1, duration=15)
                text = ("แปลงในงานนี้ใช้เลขที่ดินสาธารณะที่มีแปลงอื่นบันทึกลงฐานไปก่อนแล้ว (เช่น พนักงานอีกคนทำระวางเดียวกัน)\n"
                        "ปลั๊กอินเปลี่ยนเป็นเลขว่างถัดไปให้ทั้งแปลงและหมุดของงานนี้ก่อนบันทึก (ไม่ชนกับแปลงของคนอื่น):\n"
                        + "\n".join(lines))
                QtCore.QTimer.singleShot(0, lambda: self._ask_when_free(QtWidgets.QMessageBox.Information,
                                                                       "เปลี่ยนเลขที่ดินสาธารณะที่ชนกัน", text))
            except Exception:
                _log_exc("แจ้งเปลี่ยนเลขที่สาธารณะที่ชน (2.4.11)")
        return out

    def _cp_free_public_landno(self, poly_lyr, point_lyr, head, used=None, own=None, what=None):
        """★ 2.4.3 rc2 (ใช้ร่วม ➕ `_cp_check` / 📝 `_ep_public_landno`) — เลขที่ดินสาธารณะตัวแรกที่ว่างบนระวาง head:
        0 ถ้าว่าง ไม่งั้น -1, -2, … ตัวแรกที่ไม่มีแปลง/หมุดใช้ (คำสั่ง 24 ก.ย.) -> (เลข int, หมายเหตุ) · used = ผล `_cp_used_landno_le0` ที่มีแล้ว
        ★ 2.4.7 what = ชนิดเอกสารกลุ่ม ข (_DOC_NOKEY) ⇒ หมายเหตุบอกว่าคิดเลขให้เพราะไม่มีระวาง UTM (None = ที่สาธารณะ แบบเดิม)"""
        if used is None:
            used = self._cp_used_landno_le0(poly_lyr, point_lyr, head, own=own)
        n = 0
        while str(n) in used:
            n -= 1
        why = (("ระวางนี้ยังไม่มีเลข ≤ 0" if what else "ระวางนี้ยังไม่มีที่สาธารณะ") if n == 0 else
               "เลข 0" + "".join(", %d" % k for k in range(-1, n, -1)) + " มีแปลง/หมุดใช้แล้ว")
        return n, "%s ⇒ ใช้เลข %s (%s)" % ("เลขที่ดิน 0 = คิดเลขให้เอง (%s ไม่มีระวาง UTM)" % what if what else
                                            "เลขที่ดิน 0 = ที่สาธารณะ", n, why)

    @staticmethod
    def _pn_clean(raw):
        """★ 2.4.5 rc3 (ผลตรวจ Windows rc2 ⚪2) ชื่อที่วาง/พิมพ์มา -> ข้อความบรรทัดเดียว: ตัดอักขระควบคุม/มองไม่เห็น (หมวด Cc/Cf
        เช่น U+200B · U+FEFF · soft hyphen) · ขึ้นบรรทัด/แท็บ/ช่องว่างทุกชนิดยุบเป็นช่องว่างเดียว · ตัดหัวท้าย (สระ/วรรณยุกต์ไทย Mn ไม่แตะ)"""
        s = "".join(" " if ch.isspace() else ch for ch in _txt(raw)
                    if ch.isspace() or unicodedata.category(ch) not in ("Cc", "Cf"))
        return " ".join(s.split())

    def _pn_open(self, doc):
        """ช่อง parcel_name เปิดเฉพาะชนิดเอกสารสาธารณะ (_PN_SUGGEST) — ★ 2.4.7 (เจ้าของงาน 26 ต.ค. 69 16:21 "parcel_name จะใช้แค่แปลงสาธารณะ
        เวลาแก้ไขและสร้างรูปแปลง") กลับเป็นแบบ 2.4.5 · เอกสารเอกชนใช้ช่องทะเบียน (PARCEL_NO/MOO/TAMBOL…) แทน
        (2.4.6 เปิดทุกชนิดยกเว้นโฉนดที่ดิน) · ★ 2.4.7 17:2x–17:3x ท.ค. + อื่นๆ ใส่ชื่อได้ด้วย (_PN_SUGGEST มีสองชนิดนี้แบบไม่มีรายการคงที่)"""
        return _txt(doc) in self._PN_SUGGEST

    def _pn_have_by_doc(self, poly_lyr):
        """★ 2.4.6 rc2 (ผลตรวจ Windows rc1 🟡1) ชื่อที่มีในชั้นแยกตามชนิดเอกสารสาธารณะ (_PN_SUGGEST) -> {ชนิด: [ชื่อ]}
        rc1 อ่าน uniqueValues(parcel_name) ทั้งชั้น ⇒ ชื่อแปลงเอกชนที่ 2.4.6 เปิดให้ใส่ (เช่น "น.ส.3 เลขที่ 45") ปนรายการแนะนำของ
        ชนิดสาธารณะ — ขัดคำสั่ง "dropdown ที่เป็นสาธารณะ ให้ขึ้นแค่doc type ที่เป็นสาธารณะ" ⇒ แนะนำเฉพาะชื่อของชนิดเดียวกัน ·
        ไม่มีคอลัมน์/อ่านไม่ได้ = {} (รายการแนะนำชุดคงที่อย่างเดียว)"""
        fl = poly_lyr.fields()
        pi, di = _fld_idx(fl, self._PN_FIELD), _fld_idx(fl, "DOC_TYPE")
        if pi < 0 or di < 0:
            return {}
        docs = ", ".join(QgsExpression.quotedValue(d) for d in self._PN_SUGGEST)
        ex = "%s IN (%s) AND %s IS NOT NULL" % (QgsExpression.quotedColumnRef(fl.at(di).name()), docs,
                                                 QgsExpression.quotedColumnRef(fl.at(pi).name()))
        out = {}
        try:
            it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(ex).setFlags(QgsFeatureRequest.NoGeometry)
                                      .setSubsetOfAttributes([di, pi]).setLimit(20000))
            try:
                for f in it:
                    d, n = _txt(f.attribute(di)), _txt(f.attribute(pi))
                    if d in self._PN_SUGGEST and n:
                        out.setdefault(d, set()).add(n)
            finally:
                it.close()
        except Exception:
            _log_exc("อ่านชื่อทางสาธารณะที่มีในชั้นไม่สำเร็จ")
            return {}
        return {d: sorted(v) for d, v in out.items()}

    def _pn_label(self, doc):
        """ชื่อแถวของช่อง parcel_name — ★ 2.4.7 ช่องเปิดเฉพาะชนิดสาธารณะ + ท.ค./อื่นๆ ⇒ "ชื่อทางสาธารณะ" (เท่า 2.4.5) ·
        ท.ค./อื่นๆ (_DOC_LIKE_PUB) = "ชื่อแปลง" (2.4.6 ชนิดอื่น = "ชื่อแปลง")"""
        return "ชื่อแปลง" if _txt(doc) in self._DOC_LIKE_PUB else "ชื่อทางสาธารณะ"

    def _key_mode_sync(self, st, eds, cb_sc, form, doc_eff, lk_lbl=None):
        """★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 17:16 · 18:1x) ช่องคีย์ของ ➕/📝 ตามชนิดเอกสาร — น.ส.3 ก (_DOC_AIR) = คีย์ระวางรูปถ่ายทางอากาศ:
        UTMMAP3 ปิด/ว่าง · UTMMAP4 = แผ่นที่ 3 หลัก · มาตราส่วน _AIR_SCALES (5000 ตั้งต้น) · 🔍 ค้นหน้า น.ส.3 ก (★ ขั้น D · ป้าย air) ·
        ชนิดอื่น = ระวาง UTM เดิม · ค่าที่พิมพ์ไว้ของแต่ละแบบจำไว้ใน st['keep'] ⇒ สลับกลับได้ค่าเดิม (ไม่ตัดแผ่นที่ 3 หลักเหลือ 2 หลักเงียบ) ·
        เรียกครั้งแรก (st['air'] ยังไม่มี) แบบ UTM ⇒ ไม่แตะช่อง (ค่าเดาจากระบบกรม/ค่าเดิมของแปลงคงอยู่) -> True = สลับแบบแล้ว"""
        air = _txt(doc_eff) == self._DOC_AIR
        prev = st.get("air")
        if prev == air:
            return False
        st["air"] = air
        if prev is None and not air:
            return False
        keep = st.setdefault("keep", {})
        if prev is not None:
            keep[prev] = (eds["UTMMAP3"].text(), eds["UTMMAP4"].text(), cb_sc.currentText())
        cur = (eds["UTMMAP3"].text(), eds["UTMMAP4"].text(), cb_sc.currentText())
        m3, m4, sc = keep.get(air, cur if prev is None else ("", "", None))
        ws = (eds["UTMMAP3"], eds["UTMMAP4"], cb_sc)
        for w in ws:
            w.blockSignals(True)
        try:
            eds["UTMMAP3"].setText("" if air else m3)
            eds["UTMMAP3"].setEnabled(not air)
            eds["UTMMAP3"].setPlaceholderText("ไม่ใช้ (ระวางรูปถ่าย)" if air else "")
            eds["UTMMAP4"].setMaxLength(3 if air else 2)
            eds["UTMMAP4"].setText(m4 if len(m4) <= (3 if air else 2) else "")
            eds["UTMMAP4"].setPlaceholderText("แผ่นที่ 3 หลัก เช่น 001" if air else "")
            scales = _AIR_SCALES if air else _EP_SCALES
            cb_sc.clear()
            cb_sc.addItems(list(scales))
            cb_sc.setCurrentIndex(scales.index(sc) if sc in scales else 0)
            for w, lab in ((eds["UTMMAP4"], "UTMMAP4 (แผ่นที่)" if air else "UTMMAP4"),
                           (cb_sc, "UTMSCALE (ระวางรูปถ่าย)" if air else "UTMSCALE")):
                fl = form.labelForField(w)
                if fl is not None:
                    fl.setText(lab)
        finally:
            for w in ws:
                w.blockSignals(False)
        if lk_lbl is not None:
            if air:
                st["lk_txt"] = lk_lbl.text()
                lk_lbl.setText("ยังไม่ได้ค้น — กด 🔍 ค้นทะเบียน น.ส.3 ก ด้วยคีย์ระวางรูปถ่าย (ต้องเข้าสู่ระบบ iLands · ไม่บังคับ)")
            elif st.get("lk_txt") is not None:
                lk_lbl.setText(st.pop("lk_txt"))
        return True

    def _key_auto_doc(self, doc):
        """★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 22:5x "ปุ่มสร้างและแก้ไข ตอนนี้ถ้าชนิดเอกสารไหนที่ไม่ใช้เลข UTM ตั้งให้กรอกไม่ได้ดีไหม ให้ระบบเลือกให้
        อัตโนมัติ ให้โชว์แต่กรอกไม่ได้ เหมือน parcel name") — ชนิดที่คีย์ไม่ใช่เลขของทะเบียน: กลุ่ม ข (_DOC_NOKEY) + ชนิดสาธารณะ/ท.ค./อื่นๆ
        (_PN_SUGGEST) ⇒ คีย์ = ระวางที่รูปตั้งอยู่ + เลขที่ดิน ≤ 0 ที่ปลั๊กอินคิดให้ · น.ส.3 ก (คีย์ระวางรูปถ่าย) · ตราจอง · โฉนด · น.ส.ล. = พิมพ์ได้"""
        d = _txt(doc)
        return d in self._DOC_NOKEY or d in self._PN_SUGGEST

    _KEY_AUTO_TIP = "ชนิดเอกสารนี้ไม่ใช้เลขของทะเบียน — ปลั๊กอินตั้งคีย์ให้ (ระวางที่รูปตั้งอยู่ · เลขที่ดิน ≤ 0 ตัวที่ว่าง)"

    def _key_lock_sync(self, st, eds, cb_sc, ed_ln, lock, auto=None):
        """★ 2.4.8 ช่องคีย์ของ ➕/📝 ตามชนิดเอกสาร (_key_auto_doc) — แสดงค่าแต่พิมพ์ไม่ได้ (แบบช่อง parcel_name) -> True = เปลี่ยนช่องแล้ว
        lock: จำค่าที่พิมพ์ไว้ (st['keep_ul']) แล้วใส่ค่าของระบบ auto = {UTMMAP1..4, UTMSCALE, LANDNO} — ระวางครบ ⇒ ใส่ + ปิดช่องระวาง ·
          ไม่ครบ (ไม่มีแปลงข้างเคียงให้เดา) ⇒ ช่องระวางเปิดให้พิมพ์ (ค่าที่พิมพ์คงไว้) · ช่องเลขที่ดินปิดเสมอ · LANDNO '0' ⇒ st['kauto']
          (ผู้เรียกส่ง 0 ให้ตัวคิดเลข ≤ 0 แทนค่าในช่อง แล้วแสดงเลขที่ได้) · auto เปลี่ยน (เช่น 📝 สลับชนิดในกลุ่มนี้) ⇒ ใส่ค่าใหม่
        unlock: คืนค่าที่พิมพ์ไว้ก่อนล็อก + เปิดช่อง · ผู้เรียกต้องปลดก่อน _key_mode_sync และล็อกหลัง (ค่าที่จำของแต่ละแบบไม่ปนกัน)"""
        sheet = [eds[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4")] + [cb_sc]
        ws = sheet + [ed_ln]
        if not lock:
            if not st.get("klock"):
                return False
            keep = st.pop("keep_ul", None)
            for w in ws:
                w.blockSignals(True)
            try:
                if keep:
                    # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 ⚪B1) ระวางถูกใส่ให้ (ksheet) ⇒ คืนค่าที่พิมพ์ไว้ก่อนล็อก · ไม่มีแปลงข้างเคียง (ช่องระวางเปิด
                    #   ให้พิมพ์ระหว่างล็อก) ⇒ คงระวางที่พิมพ์ — เดิมคืนค่าก่อนล็อกเสมอ ⇒ ระวางที่พิมพ์ตอนเป็นชนิดคีย์อัตโนมัติหาย (2.4.7 ค่ายังอยู่)
                    if st.get("ksheet"):
                        for k, t in zip(("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4"), keep[:4]):
                            eds[k].setText(t)
                        i = cb_sc.findText(keep[4])
                        if i >= 0:
                            cb_sc.setCurrentIndex(i)
                    ed_ln.setText(keep[5])
                for w in ws:
                    w.setEnabled(True)
                    w.setToolTip("")
            finally:
                for w in ws:
                    w.blockSignals(False)
            st["klock"], st["kauto"] = False, False
            st.pop("kapplied", None)
            return True
        a = {k: _txt(v) for k, v in (auto or {}).items()}
        a["LANDNO"] = a.get("LANDNO") or "0"
        if st.get("klock") and st.get("kapplied") == a:
            return False
        if not st.get("klock"):
            st["keep_ul"] = tuple(eds[k].text() for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4")) + (cb_sc.currentText(), ed_ln.text())
        full = all(a.get(k) for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE"))
        for w in ws:
            w.blockSignals(True)
        try:
            if full:
                for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4"):
                    eds[k].setText(a[k])
                i = cb_sc.findText(a["UTMSCALE"])
                if i < 0:
                    cb_sc.addItem(a["UTMSCALE"])
                    i = cb_sc.findText(a["UTMSCALE"])
                cb_sc.setCurrentIndex(i)
            for w in sheet:
                w.setEnabled(not full)
                w.setToolTip(self._KEY_AUTO_TIP if full else "ไม่มีแปลงข้างเคียงให้เดาระวาง (หรือคีย์ของแปลงข้างเคียงใช้ไม่ได้) — พิมพ์ระวางที่รูปตั้งอยู่ (เลขที่ดินคิดให้เอง)")
            ed_ln.setText(a["LANDNO"])
            ed_ln.setEnabled(False)
            ed_ln.setToolTip(self._KEY_AUTO_TIP)
        finally:
            for w in ws:
                w.blockSignals(False)
        st["klock"], st["kauto"], st["ksheet"] = True, a["LANDNO"] == "0", full
        st["kapplied"] = a
        return True

    def _dq_widgets(self, vals=None, office=None):
        """★ 2.4.8 ขั้น E (เจ้าของงาน 26 ต.ค. 69 17:37 · 20:10) แถวค้นทะเบียนของเอกสารกลุ่ม ข (_DOC_NOKEY: ทะเบียนไม่มีระวาง UTM):
        เลขที่เอกสาร · หมู่ · (อำเภอ) · ตำบล (ไม่บังคับ) -> {'lbl', 'w', 'no', 'moo', 'am', 'tb', 'sig'} · ผู้เรียกซ่อน/แสดงตามชนิดเอกสาร ·
        ความยาวช่องไม่ชนกับช่องคีย์ (เทสหาช่องคีย์ด้วยความยาว 2/3/4/7) · vals = ค่าตั้งต้น (📝 = คอลัมน์ทะเบียนของแปลง) ·
        ★ 2.4.8 (เจ้าของงาน 22:0x "อันไหนที่ต้องกรอกตำบล อำเภอ ทำเป็น dropdown ได้ไหม" · "แล้วบางสาขาที่มีหลายอำเภอละ") office = สำนักงาน
        ของชั้น มีรายชื่อ (core/tambons.py) ⇒ อำเภอ (แสดงเมื่อสำนักงานมีหลายอำเภอ) + ตำบล (ตามอำเภอที่เลือก) เป็นกล่องเลือกอย่างเดียว
        (ไม่พิมพ์ — เทสทีมนอกหาช่องผู้รับผิดชอบจาก "กล่องพิมพ์ได้ตัวแรก") · ค่าเดิมนอกรายการ (📝) ต่อท้ายให้เห็น · ไม่มีรายชื่อ = ช่องพิมพ์
        ตำบลแบบเดิม · sig = สัญญาณที่ผู้เรียกต่อกับการคำนวณกล่องใหม่"""
        from ..core.tambons import amphoes_of, tambons_of
        vals = vals or {}
        no, moo = (QtWidgets.QLineEdit(_txt(vals.get(k))) for k in ("no", "moo"))
        for e, mx, ph in ((no, 12, "เลขที่เอกสาร"), (moo, 5, "หมู่")):
            e.setMaxLength(mx)
            e.setPlaceholderText(ph)
        ams = amphoes_of(office)
        am = QtWidgets.QComboBox()
        am.addItem("— อำเภอ —", "")
        for a in ams:
            am.addItem(a, a)
        if _txt(vals.get("am")) in ams:
            am.setCurrentIndex(am.findData(_txt(vals.get("am"))))
        if len(ams) <= 1:
            am.hide()                                 # อำเภอเดียว/ไม่มีรายชื่อ ⇒ ไม่ต้องเลือก (ไม่กรองด้วยอำเภอ)
        if ams:
            tb = QtWidgets.QComboBox()
            tb.setToolTip("ตำบล (ไม่บังคับ) — รายชื่อตามบัญชีทะเบียนของสำนักงานนี้")
            _tb0, _am0 = _txt(vals.get("tb")), _txt(vals.get("am"))

            def _fill(*_a):
                # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.8 rc1 🟡 agent A🟡3) อำเภอที่ใช้กรอง = ที่เลือกในกล่องที่แสดงอยู่ (สำนักงานอำเภอเดียว ⇒
                #   กล่องอำเภอซ่อน = ไม่กรอง) · ตำบลเดิมนอกรายการ (📝) ต่อท้ายเมื่อยังอยู่อำเภอเดิม/ไม่ได้เลือกอำเภอ — เดิมเช็ก currentData
                #   ของกล่องที่ซ่อนอยู่ (แปลงมี AMPHUR เช่น คลองหลวง ⇒ ถูกเลือกไว้ทั้งที่ซ่อน) ⇒ ตำบลเดิมหาย กลับเป็น "— ตำบล —" ·
                #   เลือกอำเภออื่นแล้วกลับมาอำเภอเดิม ⇒ ตำบลเดิมกลับมา · ★ 2.4.8 rc3 (ผลตรวจ Windows 2.4.8 rc2 ⚪2) ดูจำนวนอำเภอแทน isHidden() —
                #   ตอนเติมครั้งแรกกล่องยังไม่มี parent ⇒ isHidden() = True ⇒ รายชื่อตำบลตอนเปิดกล่องไม่กรองตามอำเภอที่แสดง (454 หนองเสือ 27 แทน 19)
                amv = _txt(am.currentData()) if len(ams) > 1 else ""
                cur = _txt(tb.currentData()) if tb.count() else _tb0
                if not cur and amv and amv == _am0:
                    cur = _tb0
                tb.blockSignals(True)
                tb.clear()
                tb.addItem("— ตำบล (ไม่บังคับ) —", "")
                for t in tambons_of(office, amv):
                    tb.addItem(t, t)
                if cur and tb.findData(cur) < 0 and (not amv or amv == _am0) and cur == _tb0:
                    tb.addItem(cur, cur)                 # ค่าเดิมนอกรายการ (📝) ⇒ คงไว้
                tb.setCurrentIndex(max(0, tb.findData(cur)))
                tb.blockSignals(False)
            _fill()
            am.currentIndexChanged.connect(_fill)       # ต่อก่อนผู้เรียก ⇒ รายการตำบลเปลี่ยนก่อนคำนวณกล่อง
            sig_tb = tb.currentIndexChanged
        else:
            tb = QtWidgets.QLineEdit(_txt(vals.get("tb")))
            tb.setMaxLength(60)
            tb.setPlaceholderText("ตำบล (ไม่บังคับ)")
            sig_tb = tb.textChanged
        w = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(no, 3)
        h.addWidget(moo, 1)
        h.addWidget(am, 2)
        h.addWidget(tb, 3)
        # ★ 2.4.12 (เจ้าของงาน 29 ต.ค. 69 "ของโฉนดที่ดิน … ใส่เลขหน้าสำรวจได้ กรณีที่เค้าอยากใส่") — ช่องหน้าสำรวจ (ไม่บังคับ) ซ่อนไว้
        #   ผู้เรียกเปิดเฉพาะโฉนดโหมดค้นด้วยเลขที่ · ใส่ ⇒ กรองฉบับที่หน้าสำรวจตรง (เลขโฉนดในสำนักงานเดียวซ้ำได้)
        sv = QtWidgets.QLineEdit(_txt(vals.get("sv")))
        sv.setMaxLength(10)
        sv.setPlaceholderText("หน้าสำรวจ (ไม่บังคับ)")
        sv.hide()
        h.addWidget(sv, 2)
        lbl = QtWidgets.QLabel("เลขที่เอกสาร · หมู่ · อำเภอ · ตำบล" if len(ams) > 1 else "เลขที่เอกสาร · หมู่ · ตำบล")
        lbl.setToolTip("ทะเบียนของชนิดนี้ไม่มีระวาง UTM — ค้นด้วยเลขที่เอกสาร (+ หมู่ · อำเภอ · ตำบล ช่วยเลือกฉบับ)")
        return {"lbl": lbl, "lbl0": lbl.text(), "w": w, "no": no, "moo": moo, "am": am, "tb": tb, "sv": sv,
                "sig": [no.textChanged, moo.textChanged, sig_tb, am.currentIndexChanged, sv.textChanged]}

    def _lk_doc_moved(self, a, b):
        """★ 2.4.8 (ผลตรวจอิสระ ข้อ 2) ชนิดเอกสารเปลี่ยนหลัง/ระหว่างค้น แล้วผลค้นใช้ต่อไม่ได้ไหม — ผลจากหน้าทะเบียนเฉพาะชนิด
        (น.ส.3 ก · กลุ่ม ข · ตราจอง) เป็นของชนิดนั้นเท่านั้น ⇒ เปลี่ยนเข้า/ออกชนิดกลุ่มนี้ = ทิ้งผล (เช่น ค้นเป็นโฉนดตราจองแล้วเปลี่ยนเป็นตราจองฯ) ·
        โฉนด/น.ส.ล./ชนิดอื่นใช้ผลจากแผนที่กรมของคีย์เดียวกัน ⇒ สลับไปมาได้ตามเดิม (กติกา 2.4.5: REGIS/เนื้อที่ตามชนิดตอนนี้) ·
        ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪C) ท.ค./อื่นๆ ไม่มีทะเบียน ⇒ เปลี่ยนเข้า = ทิ้งผลของชนิดเดิม (เดิมกล่องยังโชว์
        REGIS/เนื้อที่ของผลนั้นเป็นค่าที่จะเขียน)"""
        a, b = _txt(a), _txt(b)
        if a == b:
            return False
        own = {self._DOC_AIR} | set(self._DOC_NOKEY) | set(self._DOC_UTMDOC) | set(self._DOC_LIKE_PUB)
        return a in own or b in own

    @staticmethod
    def _lk_hint_sync(st, lk_lbl, text, idle, force=False):
        """★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪B) ป้ายข้างปุ่ม 🔍 ตามชนิด/คีย์ตอนนี้ — text = ข้อความของกรณีที่ปุ่มค้นไม่ได้/ค้นต่างแบบ
        (ท.ค./อื่นๆ · ที่สาธารณะ · กลุ่ม ข) · None = ข้อความตั้งต้นของกล่อง (idle) · force = ทับข้อความอื่นได้ (ชนิดที่ไม่มีทะเบียนให้ค้น —
        ผลค้นถูกทิ้งไปแล้ว) · ไม่ force ⇒ เปลี่ยนเฉพาะเมื่อป้ายยังเป็นข้อความที่ตั้งจากที่นี่/ข้อความตั้งต้น (ไม่ทับผลค้น · ข้อความแบบระวางรูปถ่าย
        ของ _key_mode_sync) · เดิมป้ายบอก "ยังไม่ได้ค้น — กดปุ่ม… (ไม่ได้ค้น โปรแกรมค้นให้หลังกด OK)" ทั้งที่ปุ่มปิด/ไม่ถามระบบกรม"""
        want = text or idle
        cur = lk_lbl.text()
        if cur != want and (force or cur == st.get("lk_auto") or cur == idle):
            lk_lbl.setText(want)
        if lk_lbl.text() == want:
            st["lk_auto"] = want

    @staticmethod
    def _key_byno_sync(st, eds, cb_sc, ed_ln, byno, air):
        """★ 2.4.10 (เจ้าของงาน 29 ต.ค. 69 "ถ้าเลือกเลขที่เอกสารให้กรอกระวางไม่ได้") โหมดค้นด้วยเลขที่ ⇒ ช่องคีย์ของ ➕/📝 พิมพ์ไม่ได้
        (แสดงค่า · คีย์ตามทะเบียนเติมให้หลังค้น) · ออกจากโหมด ⇒ เปิดคืนครั้งเดียว (UTMMAP3 ของระวางรูปถ่ายคงปิด) · ผู้เรียกเรียกหลัง
        _key_mode_sync และก่อนล็อกคีย์อัตโนมัติ (ชนิดในโหมดนี้ไม่ใช่ชนิดคีย์อัตโนมัติ ⇒ ไม่ชนกัน)"""
        ws = [eds[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4")] + [cb_sc, ed_ln]
        if byno:
            for w in ws:
                w.setEnabled(False)
            st["kbyno"] = True
        elif st.pop("kbyno", False):
            for w in ws:
                w.setEnabled(not (air and w is eds["UTMMAP3"]))

    @staticmethod
    def _byno_hint(doc):
        """★ 2.4.10 ป้ายข้างปุ่ม 🔍 ตอนเลือกค้นด้วยเลขที่ (ยังไม่ได้ค้น)"""
        return (f"ยังไม่ได้ค้น — ใส่เลขที่{doc or 'เอกสาร'} (อำเภอ/ตำบลช่วยกรองเมื่อเลขซ้ำ) แล้วกด 🔍 · "
                "ระวาง/มาตราส่วน/เลขที่ดินเติมตามทะเบียน (ต้องเข้าสู่ระบบ iLands)")

    @staticmethod
    def _cp_fill_key(eds, cb_sc, ed_ln, key):
        """★ 2.4.10 คีย์ตามทะเบียน (ค้นด้วยเลขที่) -> ช่องคีย์ของกล่อง ➕/📝 · มาตราส่วนที่ไม่มีในรายการ ⇒ ต่อท้าย ·
        ปิดสัญญาณระหว่างเติม (ผู้เรียกคิดกล่องใหม่ครั้งเดียว)"""
        ws = [w for w in list(eds.values()) + [cb_sc, ed_ln] if w is not None]
        for w in ws:
            w.blockSignals(True)
        try:
            for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4"):
                if eds.get(k) is not None:
                    eds[k].setText(_txt(key.get(k)))
            sc = _txt(key.get("UTMSCALE"))
            i = cb_sc.findText(sc)
            if i < 0 and sc:
                cb_sc.addItem(sc)
                i = cb_sc.count() - 1
            if i >= 0:
                cb_sc.setCurrentIndex(i)
            ed_ln.setText(_txt(key.get("LANDNO")))
        finally:
            for w in ws:
                w.blockSignals(False)

    @staticmethod
    def _dq_fill_row(dq, row):
        """★ 2.4.9 (แผน 2.4.9 ข้อ 2.5) แถวค้นกลุ่ม ข ตามฉบับที่เลือกจากกล่องเลือกฉบับ — หมู่ · อำเภอ (กล่องที่แสดงอยู่ · อยู่ในรายการ) ·
        ตำบล (กล่องเลือก: ไม่อยู่ในรายการ ⇒ ต่อท้าย · ช่องพิมพ์: ใส่ตรง) · เลขที่คงเดิม · ค่าว่างในฉบับ ⇒ ไม่แตะช่องนั้น"""
        moo, am, tb = _txt(row.get("moo")), _txt(row.get("amphur")), _txt(row.get("tambol"))
        if moo:
            dq["moo"].setText(moo)
        _sv = _txt(row.get("survey_no"))                  # ★ 2.4.12 โฉนดโหมดเลขที่ ⇒ หน้าสำรวจของฉบับที่เลือก
        if _sv and dq.get("sv") is not None and not dq["sv"].isHidden():
            dq["sv"].setText(_sv)
        a = dq.get("am")
        if am and isinstance(a, QtWidgets.QComboBox) and not a.isHidden() and a.findData(am) >= 0:
            a.setCurrentIndex(a.findData(am))          # ต่อ _fill ไว้ ⇒ รายชื่อตำบลตามอำเภอนี้ก่อนตั้งตำบล
        t = dq["tb"]
        if tb and isinstance(t, QtWidgets.QComboBox):
            if t.findData(tb) < 0:
                t.addItem(tb, tb)
            t.setCurrentIndex(t.findData(tb))
        elif tb:
            t.setText(tb)

    @staticmethod
    def _dq_vals(dq):
        tb, am = dq["tb"], dq.get("am")
        return {"no": _txt(dq["no"].text()), "moo": _txt(dq["moo"].text()),
                "tb": _txt(tb.currentData()) if isinstance(tb, QtWidgets.QComboBox) else _txt(tb.text()),
                "am": _txt(am.currentData()) if (am is not None and not am.isHidden()) else "",       # ★ 2.4.8 อำเภอ
                "sv": _txt(dq["sv"].text()) if (dq.get("sv") is not None and not dq["sv"].isHidden()) else ""}   # ★ 2.4.12

    _CHOOSE_AREA_MAX = 10      # ★ 2.4.9 กล่องเลือกฉบับดึงเนื้อที่ทะเบียนให้ไม่เกินกี่ฉบับแรก (ทีละฉบับ ~0.3–0.6 วิ · วัด 27 ต.ค. 69)

    def _doc_choose(self, rows, doc, parent=None, shape_m2=None):
        """★ 2.4.8 ขั้น E (เจ้าของงาน 26 ต.ค. 69 20:10 "E2 กลุ่ม ข + กล่องเลือกฉบับ") — ทะเบียนมีเลขนี้หลายฉบับ ⇒ กล่องเลือก
        (เลขที่ · หมู่ · ตำบล · อำเภอ · ไม่มีชื่อบุคคล) -> แถวที่เลือก หรือ None (ยกเลิก) · ★ ขั้น E3 ใช้กับ น.ส.3 ก คีย์เดียวกันหลายฉบับด้วย
        ★ 2.4.9 + เนื้อที่ทะเบียน/DIFF (shape_m2 = เนื้อที่รูป ตร.ม.) ดึงเบื้องหลังทีละฉบับหลังกล่องเปิด + ปุ่มเปิดภาพลักษณ์รายฉบับ"""
        dlg = QtWidgets.QDialog(parent or self.iface.mainWindow())
        dlg.setWindowTitle(f"เลือกเอกสาร — {doc} พบ {len(rows)} ฉบับ")
        lay = QtWidgets.QVBoxLayout(dlg)
        _hd = QtWidgets.QLabel("ทะเบียนมีเลขนี้หลายฉบับ — เลือกฉบับที่ตรงกับเอกสารในมือ (ดูหมู่/ตำบล · เนื้อที่ทะเบียนและ DIFF เทียบกับรูปนี้ · "
                               "🔍 เปิดภาพลักษณ์ของฉบับนั้น) · ★ ตัวหนา = เนื้อที่ทะเบียนใกล้รูปที่สุด")
        _hd.setWordWrap(True)
        lay.addWidget(_hd)
        from .. import dol_api as _da
        tbl = QtWidgets.QTableWidget(len(rows), 7, dlg)
        # ★ 2.4.10 ค้นด้วยเลขที่ของชนิดที่มีระวาง (น.ส.ล./น.ส.3 ก/โฉนด · แถวมี 'key') ⇒ คอลัมน์ 2 = ระวาง · เลขที่ดิน (คีย์ที่จะเติม) แทนหมู่
        _kd = any(isinstance(r.get("key"), dict) for r in rows)
        tbl.setHorizontalHeaderLabels(["เลขที่", "ระวาง · ที่ดิน" if _kd else "หมู่", "ตำบล", "อำเภอ", "เนื้อที่ทะเบียน", "DIFF", "ภาพลักษณ์"])
        diffs, touched, _auto = {}, [False], [False]     # ★ 2.4.10 ข้อ 2.5
        nmax = self._CHOOSE_AREA_MAX

        def _cell(i, j, txt, tip=""):
            it = QtWidgets.QTableWidgetItem(txt)
            it.setFlags(it.flags() & ~QtCore.Qt.ItemIsEditable)
            if j in (4, 5):
                it.setTextAlignment(int(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter))
            if tip:
                it.setToolTip(tip)
            tbl.setItem(i, j, it)
        for i, r in enumerate(rows):
            for j, k in enumerate(("parcel_no", "moo", "tambol", "amphur")):
                _cell(i, j, _txt(r.get(k)) or "-")
            if _txt(r.get("survey_no")):                 # ★ 2.4.12 โฉนดเลขซ้ำ ⇒ เห็นหน้าสำรวจของแต่ละฉบับ
                _cell(i, 0, f"{_txt(r.get('parcel_no')) or '-'} · สำรวจ {_txt(r.get('survey_no'))}")
            if _kd:
                _rw = " · ".join(x for x in (_txt(r.get("rawang")), _txt(r.get("land_no"))) if x)
                _cell(i, 1, _rw or "-", "" if isinstance(r.get("key"), dict) else "ทะเบียนไม่บอกคีย์ระวางของฉบับนี้")
            if i < nmax:
                _cell(i, 4, "กำลังดึง…")
                _cell(i, 5, "")
            else:
                _skip = f"ดึงเนื้อที่ทะเบียนให้ {nmax} ฉบับแรก — ฉบับนี้ดูเนื้อที่จากภาพลักษณ์"
                _cell(i, 4, "-", _skip)
                _cell(i, 5, "-", _skip)
            # ★ 2.4.9 (แผน 2.4.9 ข้อ 2.5 · เจ้าของงาน 27 ต.ค. 69 "ขวาสุดให้เปิดภาพลักษณ์แต่ละรายการได้") — ลำดับที่เอกสารสิทธิของแถว +
            #   plateType ตามชนิด (doc_url_for) · เปิดในเบราว์เซอร์ กล่องยังเปิดอยู่ (เทียบหลายฉบับได้)
            _u = _da.doc_url_for(doc, r.get("parcel_seq"))
            _b = QtWidgets.QPushButton("🔍 เปิด")
            _b.setEnabled(bool(_u))
            _b.setToolTip("เปิดภาพลักษณ์ของฉบับนี้ในเบราว์เซอร์" if _u else "ฉบับนี้ไม่มีลำดับที่เอกสารสิทธิ — เปิดภาพไม่ได้")
            _b.clicked.connect(lambda _c=False, _uu=_u: QtGui.QDesktopServices.openUrl(QtCore.QUrl(_uu)))
            tbl.setCellWidget(i, 6, _b)
        tbl.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        tbl.setSelectionMode(QtWidgets.QAbstractItemView.SingleSelection)
        tbl.verticalHeader().setVisible(False)
        tbl.resizeColumnsToContents()
        tbl.selectRow(0)
        tbl.currentCellChanged.connect(lambda *_a: None if _auto[0] else touched.__setitem__(0, True))   # ★ 2.4.10 ผู้ใช้เลือกเอง
        lay.addWidget(tbl)
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        bb.button(QtWidgets.QDialogButtonBox.Ok).setText("เลือกฉบับนี้")
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        tbl.doubleClicked.connect(lambda *_a: dlg.accept())
        lay.addWidget(bb)
        # ★ 2.4.9 (แผน 2.4.9 ข้อ 2.5 · เจ้าของงาน 27 ต.ค. 69 "ทำใส่คอลัมน์เนื้อที่และ DIFF ใน 2.4.9 เลย แบบที่ดึงให้ด้วย") — เนื้อที่ทะเบียน
        #   ดึงเบื้องหลังทีละฉบับเมื่อกล่องเปิดแล้ว (choice_area · หน้ารายละเอียด 1 คำขอ/ฉบับ · คิวเดียวกับทางทะเบียน ⇒ กดเลือกระหว่างดึงได้)
        #   · ปิดกล่องแล้วไม่ดึงต่อ · ดึงไม่ได้ ⇒ '-' + เหตุในคำแนะนำ · ข้อผิดพลาดของทางทะเบียน ⇒ หยุด (ฉบับที่เหลือได้เหตุเดียวกัน)
        alive, todo = [True], list(range(min(len(rows), nmax)))

        def _mark_best():
            # ★ 2.4.10 (แผน 2.4.9 ข้อ 2.5 "เน้น/เรียงแถวที่ DIFF ใกล้ 0") ดึงครบแล้ว ⇒ แถวที่ DIFF ใกล้ 0 ที่สุด = ตัวหนา + ★ ·
            #   ไม่เรียงแถวใหม่ (แถวไม่ย้ายใต้เมาส์) · ผู้ใช้ยังไม่ได้เลือกแถวเอง ⇒ เลือกแถวนั้นให้ · ต่างเกิน ±10% ⇒ คำแนะนำเตือน
            if not diffs:
                return
            b = min(diffs, key=lambda k: (abs(diffs[k]), k))
            f = QtGui.QFont(tbl.font())
            f.setBold(True)
            for j in range(6):
                it = tbl.item(b, j)
                if it is not None:
                    it.setFont(f)
            it = tbl.item(b, 5)
            if it is not None:
                it.setText(it.text() + " ★")
                it.setToolTip("เนื้อที่ทะเบียนใกล้รูปที่สุด" + ("" if abs(diffs[b]) <= 10 else " — แต่ยังต่างเกิน ±10% (ตรวจภาพลักษณ์ก่อน)"))
            if not touched[0]:
                _auto[0] = True
                try:
                    tbl.selectRow(b)
                finally:
                    _auto[0] = False

        def _put(i, res, err):
            if not alive[0]:
                return
            try:
                m2 = (res or {}).get("area_m2") if err is None else None
                if m2:
                    d = _dol_area_diff(shape_m2, m2)
                    _cell(i, 4, f"{m2:,.2f}", f"{_txt(res.get('area'))} ไร่-งาน-วา")
                    _cell(i, 5, f"{d:+.2f}%" if d is not None else "-", "" if d is not None else "ไม่รู้เนื้อที่รูป — เทียบไม่ได้")
                    if d is not None:
                        diffs[i] = d
                else:
                    why = str(err) if err is not None else (_txt((res or {}).get("why")) or "ไม่ได้เนื้อที่ทะเบียน")
                    for k in [i] + (todo if err is not None else []):
                        _cell(k, 4, "-", why)
                        _cell(k, 5, "-", why)
                    if err is not None:
                        del todo[:]
                if not todo:
                    _mark_best()                      # ★ 2.4.10 ข้อ 2.5 ดึงครบ/หยุดแล้ว
            except RuntimeError:
                alive[0] = False                      # กล่องถูกปิด/ลบไปแล้ว
                return
            _next()

        def _next():
            if not alive[0] or not todo:
                return
            i = todo.pop(0)
            w = _FnWorker(lambda _r=rows[i]: _da.choice_area(doc, _r))
            if not hasattr(self, "_net_workers"):
                self._net_workers = []
            self._net_workers.append(w)               # กัน GC เก็บ worker ระหว่างรัน (ปิดกล่องก่อนผลมาได้)

            def _drop(_w=w):
                try:
                    self._net_workers.remove(_w)
                except Exception:
                    pass
                try:
                    _w.deleteLater()
                except Exception:
                    pass
            w.finished.connect(_drop)
            w.done.connect(lambda res, _i=i: _put(_i, res, None))
            w.fail.connect(lambda e, _i=i: _put(_i, None, e))
            w.start()
        QtCore.QTimer.singleShot(0, _next)            # เริ่มเมื่อกล่องเปิดแล้ว (exec_) — กล่องขึ้นทันที ไม่รอทะเบียน
        self._modal_busy = True
        try:
            ok = dlg.exec_() == QtWidgets.QDialog.Accepted
            i = tbl.currentRow()
        finally:
            alive[0] = False
            self._modal_busy = False
            dlg.deleteLater()
        return rows[i] if ok and 0 <= i < len(rows) else None

    def _pn_value(self, doc, raw):
        """★ 2.4.5 rc2 ชื่อทางสาธารณะ (parcel_name) ที่จะเขียน -> (ค่า หรือ None, ข้อผิด หรือ '')
        ชนิดเอกสารที่เปิดช่อง (_pn_open: ชนิดสาธารณะ) ⇒ ล้างด้วย _pn_clean (ว่าง = None · ยาวเกิน _PN_MAX = ข้อผิด) ·
        ชนิดอื่น ⇒ None"""
        if not self._pn_open(doc):
            return None, ""
        s = self._pn_clean(raw)
        if len(s) > self._PN_MAX:
            return None, f"{self._pn_label(doc)}ยาวเกิน {self._PN_MAX} ตัวอักษร ({len(s)})"
        return (s or None), ""

    def _cp_check(self, poly_lyr, point_lyr, vals):
        """ตรวจค่าจากกล่อง -> (ค่าที่ใช้จริง, [ข้อผิด], [หมายเหตุ]) · ใช้ทั้งในกล่อง (เปิด/ปิดปุ่ม OK) และก่อนเขียน (ด่านซ้ำ)
        vals = {UTMMAP1..4, UTMSCALE, LANDNO, Type, DOC_TYPE, NAME, REGIS, AREA, parcel_name}
        🔑 เลขที่ดิน 0 = ที่สาธารณะ ⇒ คิดเลขให้เองไม่ให้ซ้ำ: 0 ถ้าระวางนั้นยังว่าง ไม่งั้น -1, -2, … ตัวแรกที่ไม่มีแปลง/หมุดใช้
           (เจ้าของงานสั่ง 24 ก.ย. — "ที่สาธารณะ ที่เลขที่ดิน <=0 คิด key ให้มันเองเลยจะได้ไม่ซ้ำ · เวลาใช้ปลั๊กอินก็จะได้ไม่มีปัญหา")"""
        v, err = _ep_normalize(vals.get("UTMMAP1"), vals.get("UTMMAP2"), vals.get("UTMMAP3"), vals.get("UTMMAP4"),
                               vals.get("UTMSCALE"), vals.get("LANDNO"),
                               airphoto=_txt(vals.get("DOC_TYPE")) == self._DOC_AIR)      # ★ 2.4.8 น.ส.3 ก = คีย์ระวางรูปถ่าย
        _kerr = bool(err)
        notes = []
        tp = _txt(vals.get("Type"))
        if tp not in self._cp_types():
            err.append("เลือกประเภทแปลง (Type)" if not tp else
                       f"Type {tp} — ชั้นของคุณสร้างได้เฉพาะ " + " · ".join(self._cp_types()))
        doc = _txt(vals.get("DOC_TYPE"))
        if doc and doc not in self._CP_DOC_CODES:
            err.append(f"ชนิดเอกสาร '{doc}' ไม่อยู่ในรายการรหัสของฐาน")
        elif doc in self._DOC_NOKEY and re.fullmatch(r"[1-9][0-9]*", _txt(v.get("LANDNO"))):
            # ★ 2.4.7 คีย์กลุ่ม ข (เจ้าของงาน 26 ต.ค. 69 ทาง ค) — ทะเบียนชนิดนี้ไม่มีเลขที่ดินบนระวาง UTM ⇒ เลขบวกใส่ไม่ได้
            err.append(f"{doc} ไม่มีเลขที่ดินบนระวาง UTM — ใส่เลขที่ดิน 0 แล้วปลั๊กอินจะคิดเลขที่ว่างให้เอง (0, -1, -2, …)")
        regis = _txt(vals.get("REGIS"))
        if regis not in self._CP_REGIS:
            err.append(f"สถานะทะเบียน '{regis}' ไม่รู้จัก")
        # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 4) คีย์ใช้ได้แต่ยังไม่เลือก Type ฯลฯ ⇒ ยังคิดเลข ≤ 0 + ตรวจคีย์ซ้ำต่อ — เดิมคืนก่อน ⇒ UTM ในกล่อง (…0)
        #   ไม่ตรงกับที่ 🔍 ใช้ (ใส่ Type ให้เองแล้วได้ …-1) ⇒ ผลค้นกลุ่ม ข ถูกทิ้งเป็น "คีย์เปลี่ยนระหว่างค้น"
        if _kerr:
            return v, err, notes
        head = v["UTMMAP1"] + v["UTMMAP2"] + v["UTMMAP3"] + v["UTMMAP4"] + v["UTMSCALE"]
        if v["LANDNO"] == "0":
            n, _note = self._cp_free_public_landno(poly_lyr, point_lyr, head, what=doc if doc in self._DOC_NOKEY else None)
            v["LANDNO"], v["UTM"] = str(n), head + str(n)
            notes.append(_note)
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        twins = self._utm_twin_fids(poly_lyr, pu, v["UTM"], _norm_utm(v["UTM"])) if pu else []
        if twins:
            err.append("คีย์ %s มีแปลงอยู่แล้ว (gid %s) — ตรวจเลขที่ดิน/ระวาง" % (v["UTM"], ", ".join(str(x) for x in twins[:5])))
        else:
            fu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if fu:
                ex = '"%s" = %s' % (fu, QgsExpression.quotedValue(v["UTM"]))
                n_mk = sum(1 for _f in point_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(ex).setNoAttributes()))
                if n_mk:
                    err.append("มีหมุดคีย์ %s อยู่แล้ว %d ดวง (แต่ไม่มีแปลง) — ตรวจ/ลบหมุดค้างก่อน" % (v["UTM"], n_mk))
        out = dict(v)
        out.update({"Type": tp, "DOC_TYPE": doc or None, "NAME": _txt(vals.get("NAME")) or None,
                    "REGIS": regis or None, "AREA": vals.get("AREA")})
        if out["DOC_TYPE"] is None and v["LANDNO"].startswith("-") or (out["DOC_TYPE"] is None and v["LANDNO"] == "0"):
            out["DOC_TYPE"] = "ที่สาธารณประโยชน์"           # เลขที่ดิน ≤ 0 = ที่สาธารณประโยชน์ (คำตัดสิน DOC_TYPE 8 ต.ค.)
        if out["DOC_TYPE"] is None and _fld_idx(poly_lyr.fields(), "DOC_TYPE") >= 0:
            # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "Doc_type ด้วย" · คำตัดสิน: บังคับเลือก) — ว่าง = หลบด่านโฉนดได้ (สร้างโฉนดโดยไม่บอกชนิด)
            #   ที่สาธารณะ (เลขที่ดิน ≤ 0) ได้ชนิดอัตโนมัติด้านบนแล้ว · ชั้นที่ไม่มีคอลัมน์ DOC_TYPE ไม่บังคับ
            err.append("เลือกชนิดเอกสารสิทธิ์")
        # ★ 2.4.5 rc2 parcel_name — ตามชนิดเอกสารที่ใช้จริง (ที่สาธารณะที่ได้ชนิดอัตโนมัติด้านบนก็เปิดช่อง) · ชนิดอื่น = ว่าง
        out["parcel_name"], _pe = self._pn_value(out["DOC_TYPE"], vals.get("parcel_name"))
        if _pe:
            err.append(_pe)
        return out, err, notes

    def _cp_frame_done(self, pts, kinds):
        """ปิดรูปแล้ว -> ตรวจรูป → กล่องกรอกคีย์/ทะเบียน/Type/ชนิดเอกสาร/ผู้รับผิดชอบ → เขียนลงบัฟเฟอร์
        คืน True = สร้างแล้ว (ติดตั้งเครื่องมือตัวใหม่ให้สร้างรูปต่อ) · False = ยังไม่สร้าง (จุดที่คลิกยังอยู่ แก้ต่อได้)"""
        title = self._CP_TITLE
        ready = self._mod_ready(title)
        if not ready:
            if not self._is_mod():
                self.iface.messageBar().pushMessage(
                    title, "ยกเลิก — ไม่ได้อยู่ในโหมดผู้ดูแล/ผู้ช่วยผู้ดูแลแล้ว (เปิดโหมดแล้วกดปุ่มใหม่)", level=1, duration=8)
            self.iface.actionSelect().trigger()
            return False
        poly_lyr, point_lyr = ready
        if getattr(self, "_cp_lids", None) != (poly_lyr.id(), point_lyr.id()):
            self.iface.actionSelect().trigger()
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม — ยกเลิก\nกดปุ่ม ➕ สร้างรูปแปลง ใหม่อีกครั้ง")
            return False
        geom, why = self._cp_geom(poly_lyr, point_lyr, pts)
        if geom is None:
            self._ask(QtWidgets.QMessageBox.Warning, title, why + "\n\n(จุดที่คลิกไว้ยังอยู่ — ถอย/แก้ต่อได้)")
            return False
        area = self._geom_area_m2(poly_lyr, geom)
        overlaps = self._cp_overlaps(poly_lyr, geom)
        vals = self._cp_dialog(poly_lyr, point_lyr, geom, area, overlaps, len(pts))
        if vals is None:
            return False
        if not self._cp_apply(poly_lyr, point_lyr, geom, pts, vals):
            return False
        self._cp_arm(poly_lyr, point_lyr)       # สร้างรูปต่อได้เลย (เครื่องมือตัวใหม่ · รูปเดิมไม่ค้าง)
        return True

    def _cp_dialog(self, poly_lyr, point_lyr, geom, area, overlaps, n_pts):
        """กล่องกรอก: คีย์ (ระวาง 4 ท่อน · มาตราส่วน · เลขที่ดิน) + 🔍 ค้นทะเบียน + Type + ชนิดเอกสาร + ผู้รับผิดชอบ + สถานะทะเบียน
        -> dict (ผล _cp_check) หรือ None (ยกเลิก)"""
        import html as _html
        title = self._CP_TITLE
        guess = self._cp_guess_key(poly_lyr, geom)
        d = QtWidgets.QDialog(self.iface.mainWindow())
        d.setWindowTitle("➕ " + title)
        lay = QtWidgets.QVBoxLayout(d)
        info = [f"รูปใหม่ {n_pts} มุม · เนื้อที่ {area:,.2f} ตร.ม. ({_rngw(area)} ไร่-งาน-วา)"]
        if overlaps:
            l1 = [o for o in overlaps if (o[1] or "").upper().startswith("L1")]
            info.append(("<span style='color:#b71c1c'>" if l1 else "<span style='color:#e65100'>")
                        + f"ทับแปลงเดิม {len(overlaps)} แปลง: "
                        + " · ".join(_html.escape(f"gid {o[0]} {o[1] or '-'} ทับ {o[3]:,.1f} ตร.ม. ({o[4]:.0f}%)")
                                     for o in overlaps[:4]) + (" …" if len(overlaps) > 4 else "")
                        + ("<br><b>มีแปลง L1 อยู่ใต้รูปใหม่</b>" if l1 else "") + "</span>")
        lb = QtWidgets.QLabel("<br>".join(info))
        lb.setWordWrap(True)
        lay.addWidget(lb)
        form = QtWidgets.QFormLayout()
        eds = {}
        for k, mx in (("UTMMAP1", 4), ("UTMMAP2", 3), ("UTMMAP3", 4), ("UTMMAP4", 2)):
            ed = QtWidgets.QLineEdit(guess.get(k, ""))
            ed.setMaxLength(mx)
            eds[k] = ed
            form.addRow(k, ed)
        cb_sc = QtWidgets.QComboBox()
        cb_sc.addItems(list(_EP_SCALES))
        if guess.get("UTMSCALE") in _EP_SCALES:
            cb_sc.setCurrentIndex(_EP_SCALES.index(guess["UTMSCALE"]))
        form.addRow("UTMSCALE", cb_sc)
        ed_ln = QtWidgets.QLineEdit("")
        ed_ln.setMaxLength(7)
        ed_ln.setPlaceholderText("เลขที่ดิน (0 = คิดเลขให้เอง: ที่สาธารณะ · น.ส.3 ฯลฯ)")      # ★ 2.4.7 คีย์กลุ่ม ข
        form.addRow("LANDNO", ed_ln)
        # ★ 2.4.10 (แผน 2.4.9 ข้อ 9) น.ส.ล./น.ส.3 ก เลือกค้นทะเบียนด้วยคีย์ หรือเลขที่เอกสาร (แถวค้นแบบ น.ส.3) · ผลเติมคีย์ตามทะเบียน
        by_lbl, cb_by = QtWidgets.QLabel("ค้นทะเบียนด้วย"), QtWidgets.QComboBox()
        cb_by.addItem("คีย์ (ระวาง · เลขที่ดิน)", "key")
        cb_by.addItem("เลขที่เอกสาร", "no")     # ★ 2.4.10 (เจ้าของงาน 29 ต.ค. 69 "เปลี่ยนเป็น เลขที่เอกสาร")
        form.addRow(by_lbl, cb_by)
        dq = self._dq_widgets(office=_branch_office_of(poly_lyr))    # ★ 2.4.8 ขั้น E กลุ่ม ข: เลขที่ · หมู่ · (อำเภอ) · ตำบล (เฉพาะ น.ส.3 · ใบจอง · ส.ค.1)
        form.addRow(dq["lbl"], dq["w"])
        btn_lk = QtWidgets.QPushButton("🔍 ค้นทะเบียนจากระบบกรม")
        lk_idle = ("ยังไม่ได้ค้น — กดปุ่มเพื่อดึงเนื้อที่/สถานะทะเบียน "
                   "(ไม่บังคับ ยกเว้นโฉนดที่ดิน — ต้องค้นและได้เนื้อที่ทะเบียนก่อนจึงจะสร้างได้)")
        lk_lbl = QtWidgets.QLabel(lk_idle)
        lk_lbl.setWordWrap(True)
        # ★ rc2 (audit A3-07) — ข้อความผลค้นมีค่าจากระบบกรม (เลขโฉนด/หน้าสำรวจ/เนื้อที่) ⇒ แสดงเป็นข้อความล้วน
        #   (QLabel ปริยาย AutoText ⇒ บรรทัดแรกที่มีแท็กถูกตีความเป็น HTML รวม <img src=file:…>)
        lk_lbl.setTextFormat(QtCore.Qt.PlainText)
        form.addRow(btn_lk, lk_lbl)
        cb_tp = QtWidgets.QComboBox()
        cb_tp.addItem("— เลือก —", "")
        for t in self._cp_types():
            cb_tp.addItem(t, t)
        form.addRow("ประเภทแปลง (Type)", cb_tp)
        cb_doc = QtWidgets.QComboBox()
        cb_doc.addItem("— เลือก —", "")      # ★ 2.4.3 (คำตัดสิน 21 ต.ค.: บังคับเลือก 1 ใน 13 ค่า · เดิม "(ว่าง)" สร้างได้ ⇒ หลบด่านโฉนด)
        for c in self._CP_DOC_CODES:
            cb_doc.addItem(self._DOC_LABEL.get(c, c), c)      # ★ 2.4.10 ข้อความ (ค่า = รหัสในฐาน)
        di = _fld_idx(poly_lyr.fields(), "DOC_TYPE")
        if di < 0:
            cb_doc.setEnabled(False)
            cb_doc.setToolTip("ชั้นแปลงนี้ไม่มีคอลัมน์ DOC_TYPE")
        # ★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 21:4x "ในปุ่มสร้าง ย้ายชนิดเอกสารมาข้างบนสุด") — ชนิดเอกสารกำหนดแบบคีย์ · แถวค้นกลุ่ม ข ·
        #   ปุ่ม 🔍 · ช่องชื่อ ⇒ แถวแรกของฟอร์ม · วิดเจ็ตสร้างลำดับเดิม (เทสทีมนอกหาช่องจากลำดับลูก) · ลำดับ Tab ตั้งหลังใส่ฟอร์มลงกล่อง
        form.insertRow(0, "ชนิดเอกสารสิทธิ์", cb_doc)
        cb_nm = QtWidgets.QComboBox()
        cb_nm.setEditable(True)
        cb_nm.addItem("")
        ni = _fld_idx(poly_lyr.fields(), "NAME")
        if ni >= 0:
            try:
                names = sorted({_txt(x) for x in poly_lyr.uniqueValues(ni, 5000) if _txt(x)})
            except Exception:
                names = []
            cb_nm.addItems(names)
            # ★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 22:2x "ปุ่มสร้าง ถ้าเป็นสิทธิ์ staff หรือ mod อยากให้เด้งชื่อคนทำเป็นชื่อเริ่มต้น ในช่องมอบหมาย")
            #   ไม่ใช่ผู้ดูแล ⇒ ช่องมอบหมายตั้งเป็นชื่อผู้รับผิดชอบของบัญชีที่ใช้อยู่ (_nm_for_login · ไม่ตรง/กำกวม = ว่าง ห้ามเดา) · แก้/ล้างเองได้ ·
            #   ผู้ดูแล (มอบหมายให้คนอื่น) = ว่างแบบเดิม
            if not self._is_admin():
                _me = _nm_for_login(self._db_login_name(poly_lyr), names)
                if _me:
                    cb_nm.setCurrentIndex(max(0, cb_nm.findText(_me)))
        else:
            cb_nm.setEnabled(False)
        cb_nm.lineEdit().setPlaceholderText("ไม่มอบหมาย")
        form.addRow("ผู้รับผิดชอบ (มอบหมาย)", cb_nm)
        # ★ 2.4.5 rc2 (เจ้าของงาน 23–24 ต.ค. 69) parcel_name ชื่อทางสาธารณะ — เปิดเฉพาะชนิดเอกสารใน _PN_SUGGEST (_pn_sync) ·
        #   (สร้างต่อจากช่องผู้รับผิดชอบ — เทสทีมนอกหาช่องผู้รับผิดชอบด้วย 'กล่องพิมพ์ได้ตัวแรก') ·
        #   ไม่บังคับ · รายการแนะนำตามชนิด + ชื่อที่มีในชั้นแล้ว (แบบช่องผู้รับผิดชอบ) · พิมพ์ต่อได้ ≤ 100 ตัวอักษร · ชั้นที่ไม่มีคอลัมน์ = ปิด
        pni = _fld_idx(poly_lyr.fields(), self._PN_FIELD)
        cb_pn = QtWidgets.QComboBox()
        cb_pn.setEditable(True)
        cb_pn.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        cb_pn.lineEdit().setMaxLength(self._PN_MAX)
        pn_have = {}                                  # ★ 2.4.6 rc2 (🟡1) {ชนิดสาธารณะ: ชื่อที่มีในชั้นของชนิดนั้น}
        if pni >= 0:
            pn_have = self._pn_have_by_doc(poly_lyr)
        else:
            cb_pn.setToolTip("ชั้นแปลงนี้ยังไม่มีคอลัมน์ parcel_name")
        pn_lbl = QtWidgets.QLabel("ชื่อทางสาธารณะ")          # ★ 2.4.6 ชื่อแถวตามชนิดเอกสาร (_pn_label)
        form.addRow(pn_lbl, cb_pn)
        cb_rg = QtWidgets.QComboBox()
        for r in self._CP_REGIS:
            cb_rg.addItem(r or "(ว่าง)", r)
        # ★ 2.4.4 (เจ้าของงาน 23 ต.ค. 69 "ไม่จำเป็นต้องใส่ Regis ถ้าเลือกโฉนดมันต้องหาให้เอง" · "เอกสารอื่นๆปล่อย regis ว่างไว้ก่อน" ·
        #   ที่สาธารณะ = 'ไม่มีทะเบียน') — REGIS ตั้งเองแล้วล็อก: ผล 🔍 ของคีย์นี้ · เลขที่ดิน ≤ 0 = 'ไม่มีทะเบียน' · ไม่ได้ค้น/ไม่พบ = ว่าง
        cb_rg.setEnabled(False)
        cb_rg.setToolTip("ตั้งให้เองตามผลค้นทะเบียน (🔍) — ที่สาธารณะ = ไม่มีทะเบียน · ยังไม่ได้ค้น/ไม่พบ = ว่าง")
        form.addRow("สถานะทะเบียน (REGIS)", cb_rg)
        lay.addLayout(form)
        # ★ 2.4.8 ลำดับ Tab ตามแถวบนจอ (ชนิดเอกสารก่อน ⇒ เคอร์เซอร์เริ่มที่ช่องนี้) · ต้องตั้งหลังวิดเจ็ตอยู่ในกล่องแล้ว
        _tab = ([cb_doc] + [eds[k] for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4")]
                + [cb_sc, ed_ln, dq["no"], dq["moo"], dq["am"], dq["tb"], dq["sv"], cb_by, btn_lk, cb_tp, cb_nm, cb_pn, cb_rg])   # ★ 2.4.10 cb_by · 2.4.12 sv
        for _a, _b in zip(_tab, _tab[1:]):
            QtWidgets.QWidget.setTabOrder(_a, _b)
        prev = QtWidgets.QLabel()
        prev.setWordWrap(True)
        lay.addWidget(prev)
        # ★ 2.4.9 (เจ้าของงาน 27 ต.ค. 69 ภาพ ➕ คีย์ชั้นประวัติ "ทำไมเป็นแบบนี้") ข้อความยาวตัดบรรทัดทำให้กล่องสูงขึ้น แล้วข้อความสั้นลง
        #   กล่องไม่หด ⇒ ที่ว่างเดิมถูกเฉลี่ยรอบป้ายข้อความ (ช่องโหว่กลางกล่อง) · ให้ที่ว่างไปรวมเหนือปุ่มแทน
        lay.addStretch(1)
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        bb.button(QtWidgets.QDialogButtonBox.Ok).setText("สร้างรูปแปลง")
        lay.addWidget(bb)
        # ★ 2.4.3 ด่านโฉนด: deed_utm = คีย์ที่ค้นแล้วผ่าน _ep_deed_block (ได้เนื้อที่ทะเบียน) · deed_why = เหตุที่ไม่ผ่าน ·
        #   doc_lock = ผลทะเบียน (ยืนยันแปลงได้) บอกว่าเป็นโฉนด ⇒ ล็อกช่องชนิดเอกสาร (คำตัดสิน 21 ต.ค. กันเปลี่ยนชนิดหลบด่าน)
        # ★ 2.4.6 hist_utm/hist_note = คีย์ชั้นประวัติที่ทะเบียน iLands ยืนยัน (ผ่านด่านโฉนด · ถามยืนยันพร้อมคำเตือนหลังกดสร้าง)
        # ★ 2.4.8 reg/reg_utm = ค่าคอลัมน์ทะเบียน 7 ตัวจากผลค้นที่ยืนยันแปลงได้ (_reg_vals) + คีย์ของผลนั้น
        st = {"area": None, "lk_utm": None, "res": None, "busy": False,
              "deed_utm": None, "deed_why": None, "doc_lock": False, "gate": "", "regis": None, "pn_doc": "",
              "hist_utm": None, "hist_note": None, "reg": {}, "reg_utm": None, "reg_kd": False, "lk_q": None,     # ★ 2.4.8 ขั้น E lk_q = (ชนิด, ค่าค้น)
              "lk_doc": None}             # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 2) ชนิดเอกสารของผลค้นนี้ (เปลี่ยนภายหลัง ⇒ ทิ้งผล)
        _has_reg = any(_fld_idx(poly_lyr.fields(), k) >= 0 for k in _REG_COLS)

        def _vals():
            # ★ 2.4.3 — ชนิดเอกสารอ่านตามว่ามีคอลัมน์ (เดิมดู isEnabled — ช่องที่ถูกล็อกตามผลทะเบียนจะกลายเป็นว่าง)
            return {"UTMMAP1": eds["UTMMAP1"].text(), "UTMMAP2": eds["UTMMAP2"].text(),
                    "UTMMAP3": eds["UTMMAP3"].text(), "UTMMAP4": eds["UTMMAP4"].text(),
                    # ★ 2.4.8 ชนิดที่ปลั๊กอินตั้งคีย์ให้ (_key_lock_sync) ⇒ 0 = ให้ _cp_check คิดเลข ≤ 0 ที่ว่าง (ช่องแสดงเลขที่ได้)
                    "UTMSCALE": cb_sc.currentText(), "LANDNO": "0" if st.get("kauto") else ed_ln.text(),
                    "Type": cb_tp.currentData(), "DOC_TYPE": cb_doc.currentData() if di >= 0 else "",
                    "NAME": cb_nm.currentText() if cb_nm.isEnabled() else "",
                    "parcel_name": cb_pn.currentText() if cb_pn.isEnabled() else "",     # ★ 2.4.5 rc2
                    "REGIS": "",                # ★ 2.4.4 ไม่รับจากกล่อง — _upd ตั้งตามผลค้นของคีย์นี้
                    "AREA": st["area"]}

        _memo = {}

        def _pn_sync(doc_eff):
            # ★ 2.4.5 rc2 ช่องชื่อทางสาธารณะตามชนิดเอกสารที่ใช้จริง — เปิด/ปิด + รายการแนะนำของชนิดนั้น (ข้อความที่พิมพ์ไว้คงอยู่ ·
            #   ช่องปิด = ไม่เขียน) · st["pn_doc"] = ชนิดของรายการตอนนี้ (None = ช่องปิด) ⇒ เปลี่ยนเฉพาะเมื่อชนิดเปลี่ยน
            # ★ 2.4.7 เปิดเฉพาะชนิดสาธารณะ (_pn_open · เท่า 2.4.5) · รายการแนะนำ + ชื่อที่มีในชั้นของชนิดนั้น (2.4.6 rc2 _pn_have_by_doc)
            on = pni >= 0 and self._pn_open(doc_eff)
            _k = doc_eff if on else ("ปิด", bool(_txt(doc_eff)))     # (ตรวจอิสระ ⚪6) ยังไม่เลือกชนิด/ชนิดที่ปิดช่อง ⇒ ข้อความจางต่างกัน
            if st["pn_doc"] == _k:
                return
            t = cb_pn.currentText()
            cb_pn.blockSignals(True)
            try:
                cb_pn.clear()
                if on:
                    sug = list(self._PN_SUGGEST[_txt(doc_eff)])
                    cb_pn.addItem("")
                    cb_pn.addItems(sug + [x for x in pn_have.get(_txt(doc_eff), []) if x not in sug])
                cb_pn.setEditText(t)
            finally:
                cb_pn.blockSignals(False)
            cb_pn.setEnabled(on)
            st["pn_doc"] = _k
            pn_lbl.setText(self._pn_label(doc_eff))
            cb_pn.lineEdit().setPlaceholderText(
                ("ไม่บังคับ — ชื่อเรียกของแปลง" if _txt(doc_eff) in self._DOC_LIKE_PUB else
                 "ไม่บังคับ — เลือกแล้วพิมพ์ต่อได้ เช่น ลำรางสาธารณะบ้านหนองแค") if on else
                "ชั้นแปลงนี้ยังไม่มีคอลัมน์ parcel_name" if pni < 0 else
                "เฉพาะทางสาธารณประโยชน์ (ทางน้ำ/ทางบก) · ที่สาธารณประโยชน์ · ท.ค. · อื่นๆ" if _txt(doc_eff) else "เลือกชนิดเอกสารก่อน")

        def _upd(*_a):
            # ★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 22:5x) ชนิดที่ไม่ใช้เลขของทะเบียน ⇒ ช่องคีย์แสดงค่าของระบบ (ระวางของแปลงข้างเคียง + เลข ≤ 0) พิมพ์ไม่ได้ ·
            #   ปลดก่อน / ล็อกหลัง _key_mode_sync (ค่าที่จำของแบบระวางรูปถ่ายกับแบบ UTM ไม่ปนกัน)
            _dsel = _txt(cb_doc.currentData())
            _klock = self._key_auto_doc(_dsel)
            if not _klock:
                self._key_lock_sync(st, eds, cb_sc, ed_ln, False)
            self._key_mode_sync(st, eds, cb_sc, form, _dsel, lk_lbl)       # ★ 2.4.8 น.ส.3 ก = คีย์ระวางรูปถ่าย
            # ★ 2.4.10 (เจ้าของงาน 29 ต.ค. 69 "ถ้าเลือกเลขที่เอกสารให้กรอกระวางไม่ได้") โหมดเลขที่ ⇒ ช่องคีย์ปิด (คีย์มาจากทะเบียน)
            self._key_byno_sync(st, eds, cb_sc, ed_ln, _dsel in self._DOC_BYNO and cb_by.currentData() == "no", _dsel == self._DOC_AIR)
            if _klock:
                self._key_lock_sync(st, eds, cb_sc, ed_ln, True, dict(guess, LANDNO="0"))
            # ★ rc2 (audit A3-05) — _cp_check ถามฐาน (คีย์ซ้ำแปลง LIKE · นับหมุดคีย์เดียวกัน · เลขที่สาธารณะ) ทุกครั้งที่ถูกเรียก
            #   และ _upd ผูกกับทุกช่อง ⇒ พิมพ์ชื่อผู้รับผิดชอบ 10 ตัวอักษร = คิวรีชุดเดิม 10 รอบ บนเธรดหลัก
            #   ⇒ จำผลตามค่าที่มีผลกับการตรวจ (คีย์ · Type · ชนิดเอกสาร · REGIS) · ช่องชื่อ/เนื้อที่เปลี่ยน = ใช้ผลเดิม
            #   (ข้อมูลในฐานเปลี่ยนระหว่างกล่องเปิด ⇒ _cp_apply ตรวจซ้ำก่อนเขียนอยู่แล้ว)
            v = _vals()
            _k = tuple(_txt(v.get(x)) for x in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO",
                                                 "Type", "DOC_TYPE", "REGIS"))
            if _k not in _memo:
                if len(_memo) > 64:
                    _memo.clear()
                _memo[_k] = self._cp_check(poly_lyr, point_lyr, v)
            out, err, notes = _memo[_k]
            out = dict(out)
            if st.get("kauto") and _txt(out.get("LANDNO")) and _txt(out.get("LANDNO")) != ed_ln.text():
                ed_ln.blockSignals(True)                     # ★ 2.4.8 แสดงเลข ≤ 0 ที่คิดได้ (ช่องปิด · ค่าที่ส่งตรวจยังเป็น 0)
                ed_ln.setText(_txt(out.get("LANDNO")))
                ed_ln.blockSignals(False)
            # ★ 2.4.5 rc2 (ผลตรวจ Windows rc1 ⚪1) — _cp_check คืนก่อน (ยังไม่เลือก Type) ⇒ out ไม่มี DOC_TYPE ⇒ อ่านจากช่อง
            _dt = _txt(out.get("DOC_TYPE")) or _txt(v.get("DOC_TYPE"))
            # ★ 2.4.8 ขั้น E กลุ่ม ข — แถวค้นด้วยเลขที่เอกสาร แสดงเฉพาะชนิดนี้ · _q = (ชนิด, ค่าค้น) ไว้เทียบกับค่าที่ค้นไปแล้ว
            _byon = _dt in self._DOC_BYNO                  # ★ 2.4.10 ตัวเลือกค้นด้วยเลขที่ (น.ส.ล./น.ส.3 ก)
            by_lbl.setVisible(_byon)
            cb_by.setVisible(_byon)
            _byno = _byon and cb_by.currentData() == "no"
            _dqon = _dt in self._DOC_NOKEY or _byno
            dq["lbl"].setVisible(_dqon)
            dq["w"].setVisible(_dqon)
            dq["moo"].setVisible(not _byno)              # ★ 2.4.10 ค้นด้วยเลขที่ (น.ส.ล./น.ส.3 ก/โฉนด) ไม่ใช้หมู่
            _svon = _byno and _dt == self._DEED          # ★ 2.4.12 โฉนด: หน้าสำรวจ (ไม่บังคับ)
            dq["sv"].setVisible(_svon)
            dq["lbl"].setText((dq["lbl0"].replace(" · หมู่", "") + (" · หน้าสำรวจ" if _svon else "")) if _byno else dq["lbl0"])
            _q = (_dt, self._dq_vals(dq)) if _dqon else None
            # ★ 2.4.5 rc2 parcel_name — ช่องว่าง + เลขที่ดิน ≤ 0 = ที่สาธารณประโยชน์ (แบบ _cp_check) ก่อนเลือก Type ก็เปิดช่อง
            _pn_sync(_dt or ("ที่สาธารณประโยชน์" if _public_landno(out.get("LANDNO")) else ""))
            if not err:
                out["NAME"] = _txt(v.get("NAME")) or None
                out["AREA"] = v.get("AREA")
                # ผลของ _cp_check ถูกจำด้วยคีย์ที่ไม่รวมชื่อ (แบบ NAME) ⇒ คิดชื่อทางสาธารณะจากช่องตอนนี้เสมอ
                out["parcel_name"] = self._pn_value(out.get("DOC_TYPE"), cb_pn.currentText() if cb_pn.isEnabled() else "")[0]
            st["out"], st["err"] = out, err
            _qch = st.get("lk_q") is not None and _q != st["lk_q"]           # ★ 2.4.8 ขั้น E ชนิด/เลขที่/หมู่/ตำบลที่ค้นเปลี่ยน
            _kchg = st["lk_utm"] is not None and out.get("UTM") != st["lk_utm"]
            # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 2) ชนิดเอกสารเปลี่ยนหลังค้น (คีย์เดิม) ⇒ ผลเป็นของหน้าทะเบียน/ชนิดเดิม (เช่น โฉนดตราจอง → ตราจองฯ) ⇒ ทิ้ง
            #   ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪C) ท.ค./อื่นๆ ไม่มีทะเบียน ⇒ ผลค้นของชนิดใดก็ทิ้ง (ไม่ต้องรู้ชนิดของผล)
            _dch = st["lk_utm"] is not None and ((st.get("lk_doc") is not None and self._lk_doc_moved(st["lk_doc"], v.get("DOC_TYPE")))
                                                 or _txt(v.get("DOC_TYPE")) in self._DOC_LIKE_PUB)
            if st["lk_utm"] is not None and (_kchg or _qch or _dch):
                st["lk_q"] = st["lk_doc"] = None
                st["area"], st["lk_utm"] = None, None          # คีย์เปลี่ยนหลังค้น ⇒ เนื้อที่ทะเบียนที่ได้ไม่ใช่ของคีย์นี้แล้ว
                st["regis"] = None                             # ★ 2.4.4 REGIS ก็เป็นของคีย์เดิม
                st["deed_utm"], st["deed_why"] = None, None    # ★ 2.4.3 ผลด่านโฉนดเป็นของคีย์เดิม
                st["hist_utm"], st["hist_note"] = None, None   # ★ 2.4.6 ผลยืนยันคีย์ชั้นประวัติก็เป็นของคีย์เดิม
                st["reg"], st["reg_utm"] = {}, None            # ★ 2.4.8 ค่าทะเบียนก็เป็นของคีย์เดิม
                st["reg_kd"] = False                           # ★ 2.4.10
                if st["doc_lock"]:                             # ★ 2.4.3 ล็อกชนิดเอกสารผูกกับผลของคีย์เดิม ⇒ ปลด
                    st["doc_lock"] = False
                    cb_doc.setEnabled(di >= 0)
                    cb_doc.setToolTip("" if di >= 0 else "ชั้นแปลงนี้ไม่มีคอลัมน์ DOC_TYPE")
                lk_lbl.setText("คีย์เปลี่ยนหลังค้น — กดค้นใหม่ถ้าต้องการเนื้อที่/สถานะทะเบียน" if _kchg else
                               "ชนิดเอกสารเปลี่ยนหลังค้น — กดค้นใหม่ถ้าต้องการเนื้อที่/สถานะทะเบียน" if _dch else
                               "เลขที่/หมู่/ตำบลที่ค้นเปลี่ยนหลังค้น — กดค้นใหม่ถ้าต้องการเนื้อที่/สถานะทะเบียน")
            # ★ 2.4.4 REGIS (ช่องล็อก) — ที่สาธารณะ = 'ไม่มีทะเบียน' · ผลค้นของคีย์นี้ · ไม่ได้ค้น/ไม่พบ = ว่าง
            # ★ 2.4.5 (ผลตรวจ Windows 2.4.4 rc1 🟡2 · เจ้าของงาน 23 ต.ค. 69 "เอกสารอื่นว่างเสมอ") — ผลค้นใช้กับโฉนดที่ดินเท่านั้น
            #   (ทางค้นทะเบียน iLands ของปลั๊กอินค้นได้เฉพาะโฉนด ⇒ ไม่มีทะเบียน/รอจดของเอกสารอื่นมาจากแผนที่อย่างเดียว) · เอกสารอื่น = ว่าง
            #   ★ 2.4.7 ท.ค./อื่นๆ = 'ไม่มีทะเบียน' เสมอแบบที่สาธารณะ (เจ้าของงาน 26 ต.ค. 69 17:2x–17:3x) · เลข ≤ 0 ของเอกสารกลุ่ม ข
            #   (_DOC_NOKEY · เลขที่ปลั๊กอินตั้งให้ ไม่ใช่ที่สาธารณะ) ⇒ ว่าง (เอกสารอื่นว่างเสมอ) · ตรงกับ _cp_apply
            _rg = ("ไม่มีทะเบียน" if (_public_landno(out.get("LANDNO")) and _dt not in self._DOC_NOKEY) or _dt in self._DOC_LIKE_PUB
                   else (st["regis"] or "") if (_dt == self._DEED and st["lk_utm"] is not None
                                                and st["lk_utm"] == out.get("UTM"))
                   # ★ 2.4.8 ขั้น D น.ส.3 ก — ทะเบียนยืนยันได้ฉบับเดียว (ค่าทะเบียนของคีย์นี้) ⇒ มีทะเบียน · ไม่พบ/หลายฉบับ = ว่าง (แบบเอกสารอื่น)
                   else "มีทะเบียน" if ((_dt == self._DOC_AIR or _dt in self._DOC_NOKEY or _dt in self._DOC_UTMDOC   # ★ ขั้น E/E1
                                         or (_dt == "น.ส.ล." and st["reg_kd"]))   # ★ 2.4.10 เฉพาะผลค้นด้วยเลขที่ (หน้า QNSL ยืนยันชนิด) · ค้นด้วยคีย์ = ว่างแบบ 2.4.5
                                         and st["reg"] and st["reg_utm"] == out.get("UTM")) else "")
            if not err:
                out["REGIS"] = _rg or None
            _ri = cb_rg.findData(_rg)
            if _ri >= 0 and _ri != cb_rg.currentIndex():
                cb_rg.blockSignals(True)
                cb_rg.setCurrentIndex(_ri)
                cb_rg.blockSignals(False)
            # ★ 2.4.3 ด่านโฉนดที่ดิน (เจ้าของงาน 21 ต.ค. 69) — โฉนดต้องค้นทะเบียน + ได้เนื้อที่ของคีย์นี้ก่อน ปุ่มสร้างจึงเปิด
            #   (ไม่ใส่ใน _cp_check เพราะผลถูกจำด้วยคีย์ที่ไม่รวมเนื้อที่ · _cp_apply ตรวจซ้ำก่อนเขียนด้วย _deed_utm)
            gate = ""
            if not err and _txt(out.get("DOC_TYPE")) == self._DEED and _public_landno(out.get("LANDNO")):
                # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪8) — เดิมบอกให้กด 🔍 แต่ 🔍 ตอบ "ที่สาธารณะ — ไม่มีทะเบียนให้ค้น"
                gate = "เลขที่ดิน ≤ 0 = ที่สาธารณะ — เป็นโฉนดที่ดินไม่ได้ · เลือกชนิดเอกสารให้ตรง (เช่น ที่สาธารณประโยชน์)"
            elif not err and _txt(out.get("DOC_TYPE")) == self._DEED:
                if st["busy"]:
                    gate = "โฉนดที่ดิน — รอผลค้นทะเบียนก่อน"
                elif st["lk_utm"] != out.get("UTM"):
                    gate = "โฉนดที่ดิน — กด 🔍 ค้นทะเบียน (ต้องได้เนื้อที่ทะเบียนก่อนจึงจะสร้างได้)"
                elif st["deed_utm"] != out.get("UTM"):
                    gate = "โฉนดที่ดิน — สร้างไม่ได้: " + (st["deed_why"] or "ไม่ได้เนื้อที่ทะเบียน")
            st["gate"] = gate
            txt = []
            if not err:
                txt.append(f"UTM: <b>{_html.escape(out['UTM'])}</b>")
            txt += [_html.escape(n) for n in notes]
            if st.get("klock"):                         # ★ 2.4.8 ช่องคีย์ที่ปลั๊กอินตั้งให้
                txt.append(_html.escape(f"🔒 คีย์ของ {_dsel} ตั้งให้อัตโนมัติ (ช่องคีย์แก้ไม่ได้) — ระวาง"
                                        + ("ของแปลงข้างเคียง" if st.get("ksheet") else "ที่พิมพ์ (ไม่มีแปลงข้างเคียงให้เดา)")
                                        + " · เลขที่ดิน ≤ 0 ตัวที่ว่าง"))
            if err:
                txt.append("<span style='color:#b71c1c'>" + "<br>".join(_html.escape(e) for e in err) + "</span>")
            if gate:
                txt.append("<span style='color:#b71c1c'>" + _html.escape(gate) + "</span>")
            if st["doc_lock"]:
                txt.append("ชนิดเอกสารล็อกตามผลทะเบียน (โฉนดที่ดิน) — เปลี่ยนคีย์แล้วค้นใหม่ถ้าไม่ใช่แปลงนี้")
            if st["area"] and _dt not in self._DOC_LIKE_PUB:      # ★ 2.4.8 rc2 ⚪C ท.ค./อื่นๆ ไม่เขียน AREA (_cp_apply) ⇒ ไม่แสดง
                # ★ 2.4.6 (เจ้าของงาน 26 ต.ค. 69 "คิดค่า diff แสดงให้เห็น ทำทั้งในปุ่มแก้ไขข้อมูลและสร้างรูปแปลง") — สูตรเดียวกับค่าที่เขียน
                _d = _dol_area_diff(area, st["area"])
                txt.append(f"AREA (เนื้อที่ทะเบียน) = {st['area']:,.2f} ตร.ม. · DIFF_AREA = "
                           + (f"{_d:+.2f}%" if _d is not None else "-") + f" (รูป {area:,.2f} ตร.ม.)")
            if not err and st["hist_utm"] is not None and st["hist_utm"] == out.get("UTM"):
                txt.append("<span style='color:#e65100'>⚠️ คีย์ชั้นประวัติของแผนที่กรม — ทะเบียน iLands ยืนยันว่าโฉนดยังใช้อยู่ "
                           "· กดสร้างแล้วจะถามยืนยันอีกครั้ง</span>")
            if not err and out.get("parcel_name"):                                   # ★ 2.4.5 rc2
                txt.append(f"{_html.escape(self._pn_label(out.get('DOC_TYPE')))}: <b>{_html.escape(out['parcel_name'])}</b>")
            if not err and _has_reg and st["reg"] and st["reg_utm"] == out.get("UTM"):
                txt.append(_html.escape(_reg_txt(st["reg"])))                         # ★ 2.4.8 ค่าทะเบียนที่จะเขียน
            prev.setText("<br>".join(txt))
            bb.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(not err and not gate)
            # ★ 2.4.2 rc5 (ผลตรวจ Windows rc4 ข้อพบ 1) — กำลังค้นอยู่ ⇒ ปุ่มค้นปิดไว้จนงานนั้นจบ (rc4 เปลี่ยนช่องใดก็เปิดคืน ⇒ ค้นซ้อน 2 งาน)
            _lp = _dt in self._DOC_LIKE_PUB                                    # ★ 2.4.7 rc2 🟡2 ท.ค./อื่นๆ ไม่มีทะเบียนให้ค้น
            _non = _dqon and not _q[1]["no"]                                   # ★ 2.4.8 ขั้น E กลุ่ม ข ต้องมีเลขที่เอกสาร
            _on = (not st["busy"] and not _lp and not _non                     # ★ 2.4.8 ขั้น D น.ส.3 ก ค้นได้
                   and (_byno or not [e for e in err if not e.startswith("เลือกประเภท") and not e.startswith("Type ")
                                      and not e.startswith("เลือกชนิดเอกสาร")]))   # ★ 2.4.3 · ★ 2.4.10 โหมดเลขที่ไม่ต้องมีคีย์
            btn_lk.setEnabled(_on)
            # ★ 2.4.8 rc2 (ผลตรวจ Windows 2.4.7 rc2 ⚪B) ปุ่มที่ปิดบอกเหตุ · ป้ายของ ท.ค./อื่นๆ บอกค่าที่จะเขียน (ไม่ใช่ "กดปุ่มเพื่อดึง…")
            btn_lk.setToolTip("" if _on else "กำลังค้นจากระบบกรม…" if st["busy"] else
                              f"{_dt} ไม่มีทะเบียนให้ค้น (แบบที่สาธารณะ)" if _lp else
                              (f"{_dt} — ใส่เลขที่เอกสารก่อน" + ("" if _byno else " (ทะเบียนชนิดนี้ไม่มีระวาง UTM)")) if _non else
                              "กรอกคีย์ให้ครบ/แก้ข้อผิดในกล่องก่อน")
            self._lk_hint_sync(st, lk_lbl, f"{_dt} — ไม่มีทะเบียนให้ค้น (แบบที่สาธารณะ) · REGIS = ไม่มีทะเบียน · AREA ว่าง"
                               if _lp else self._byno_hint(_dt) if _byno else None, lk_idle,
                               force=_lp or (_byno and lk_lbl.text().startswith("ยังไม่ได้ค้น")))      # ★ 2.4.10 แทนป้ายของโหมดคีย์

        def _lookup():
            if st["busy"]:
                return
            # ★ 2.4.3 ชนิดเอกสารยังไม่เลือกก็ค้นได้ (ตรวจแค่คีย์ · ผลทะเบียนเติม/ล็อกชนิดเอกสารให้)
            out, err, _n = self._cp_check(poly_lyr, point_lyr, dict(_vals(), Type=(self._cp_types() or [""])[0],
                                                                    DOC_TYPE=_vals().get("DOC_TYPE") or self._CP_DOC_CODES[-1]))
            _byno = _txt(_vals().get("DOC_TYPE")) in self._DOC_BYNO and cb_by.currentData() == "no"      # ★ 2.4.10
            if err and not _byno:
                return
            if _txt(_vals().get("DOC_TYPE")) in self._DOC_LIKE_PUB:      # ★ 2.4.7 rc2 🟡2 (ทางเรียกตรง · ปุ่มปิดอยู่แล้ว)
                lk_lbl.setText(f"{_txt(_vals().get('DOC_TYPE'))} — ไม่มีทะเบียนให้ค้นด้วยคีย์ (แบบที่สาธารณะ)")
                return
            _d = _txt(_vals().get("DOC_TYPE"))
            _q = (_d, self._dq_vals(dq)) if (_d in self._DOC_NOKEY or _byno) else None     # ★ 2.4.8 ขั้น E · ★ 2.4.10 โหมดเลขที่
            if _q is not None and not _q[1]["no"]:
                lk_lbl.setText(f"{_d} — ใส่เลขที่เอกสาร (+ หมู่ · ตำบล) แล้วกด 🔍 (ทะเบียนชนิดนี้ไม่มีระวาง UTM)")
                return
            if _q is None and (out["LANDNO"].startswith("-") or out["LANDNO"] == "0"):
                lk_lbl.setText("ที่สาธารณะ — ไม่มีทะเบียนให้ค้น")
                return
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            try:
                c = geom.centroid().asPoint()
                if poly_lyr.crs() != dst:
                    c = QgsCoordinateTransform(poly_lyr.crs(), dst, QgsProject.instance()).transform(c)
                near = (c.x(), c.y())
            except Exception:
                near = None
            attrs = {"m1": out.get("UTMMAP1"), "m2": out.get("UTMMAP2"), "m3": out.get("UTMMAP3"), "m4": out.get("UTMMAP4"),
                     "scale": out.get("UTMSCALE"), "landno": out.get("LANDNO"), "near_xy": near,       # ★ 2.4.10 โหมดเลขที่: คีย์ยังว่างได้
                     "probe_xy": _probe_xy_24047(geom, poly_lyr.crs()),
                     "office_seq": _branch_office_of(poly_lyr),                 # ★ 2.3.10 ล็อกสาขา
                     "air": bool(st.get("air"))}                                # ★ 2.4.8 ขั้น D น.ส.3 ก ⇒ หน้า QNS3K
            if _byno:                                 # ★ 2.4.10 น.ส.ล./น.ส.3 ก ด้วยเลขที่ ⇒ หน้า QNSL/QNS3K · ผลบอกคีย์ตามทะเบียน
                attrs.update(keydoc=True, doc=_d, no=_q[1]["no"], tambol=_q[1]["tb"], amphur=_q[1]["am"], survey=_q[1].get("sv", ""),
                             seq="", row={})
            elif _q is not None:                      # ★ 2.4.8 ขั้น E ⇒ หน้าค้นของชนิดนั้นด้วยเลขที่ (+ หมู่ · ตำบล)
                attrs.update(docsearch=True, doc=_d, no=_q[1]["no"], moo=_q[1]["moo"], tambol=_q[1]["tb"], amphur=_q[1]["am"],
                             seq="", row={})
            elif _d in self._DOC_UTMDOC:              # ★ 2.4.8 ขั้น E1 โฉนดตราจอง/ตราจองฯ ⇒ หน้าของชนิดนั้นด้วยคีย์ UTM
                attrs.update(utmdoc=True, doc=_d)
            st["busy"] = True
            btn_lk.setEnabled(False)
            lk_lbl.setText("กำลังค้นจากระบบกรม…")
            _upd()                                    # ★ 2.4.3 โฉนด: ปุ่มสร้างปิดระหว่างค้น (ค้นซ้ำหลังเคยได้เนื้อที่ก็ปิด)
            # ★ 2.4.2 rc4 (เจ้าของงาน 21 ต.ค. 69 "ปุ่มไหนที่เกี่ยวข้องกับทะเบียน ถ้าหาใน arcgis ไม่เจอ ให้ไปหาใน LIS เพิ่ม") — แบบ 🔍/📝
            w = ParcelLookupWorker(attrs, zone=47, lis_more=True)
            if not hasattr(self, "_net_workers"):
                self._net_workers = []
            self._net_workers.append(w)

            def _drop(_w=w):
                try:
                    self._net_workers.remove(_w)
                except Exception:
                    pass
                try:
                    _w.deleteLater()
                except Exception:
                    pass

            def _abandon():
                st["busy"] = False
                try:
                    lk_lbl.setText("ยกเลิกการค้นทะเบียน iLands แล้ว — กดค้นใหม่ได้")
                    _upd()
                except RuntimeError:
                    pass                                      # กล่องถูกปิดไปก่อน

            _GONE = object()

            def _qnow():
                # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 3) กล่องถูกปิด/ลบก่อนผลมา ⇒ ค่าที่ไม่มีวันตรง (ทิ้งผล · ไม่โยน RuntimeError ออกจาก slot)
                try:
                    _dn = _txt(_vals().get("DOC_TYPE"))
                    return ((_dn, self._dq_vals(dq)) if (_dn in self._DOC_NOKEY
                                                          or (_dn in self._DOC_BYNO and cb_by.currentData() == "no")) else None)
                except RuntimeError:
                    return _GONE

            def _dnow():
                try:
                    return _txt(_vals().get("DOC_TYPE"))
                except RuntimeError:
                    return _GONE

            def _end(res, e, _utm=out.get("UTM"), _q0=_q, _d0=_d):
                # ★ 2.4.3 (ผลตรวจ Windows rc5 N3c) — คีย์ในกล่องเปลี่ยนระหว่างค้น ⇒ เลิกตั้งแต่ตรงนี้ ไม่เด้งกล่องเข้าสู่ระบบของคีย์เดิม
                #   (เดิมเทียบคีย์หลังทางเข้าสู่ระบบ ⇒ ถามรหัสเปล่า ๆ แล้วทิ้งผล) · ★ 2.4.8 ขั้น E ชนิด/เลขที่/หมู่/ตำบลที่ค้นเปลี่ยน = แบบเดียวกัน
                _dn = _dnow()                             # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 2) ชนิดเอกสารเปลี่ยนระหว่างค้น
                _dmv = _dn is _GONE or self._lk_doc_moved(_d0, _dn)
                _kd = bool(attrs.get("keydoc"))          # ★ 2.4.10 ค้นด้วยเลขที่: คีย์ในช่องยังไม่ใช่คีย์ที่ค้น ⇒ ไม่เทียบ UTM
                if (not _kd and _txt((st.get("out") or {}).get("UTM")) != _txt(_utm)) or (_q0 is not None and _qnow() != _q0) or _dmv:
                    if not (isinstance(res, dict) and res.get("lis") == "login"):
                        self._dol_log_lis_trace(res)
                    st["busy"] = False
                    try:
                        lk_lbl.setText("ชนิดเอกสารเปลี่ยนระหว่างค้น — ผลที่ได้เป็นของชนิดเดิม (ไม่ได้ใช้) · กดค้นใหม่" if _dmv else
                                       "คีย์เปลี่ยนระหว่างค้น — ผลที่ได้เป็นของคีย์เดิม (ไม่ได้ใช้) · กดค้นใหม่")
                        _upd()
                    except RuntimeError:
                        pass                                  # กล่องถูกปิดไปก่อนผลมา
                    return
                # ★ 2.4.6 คีย์ชั้นประวัติ ⇒ เด้งกล่องเข้าสู่ระบบเหมือนกรณีอื่น (2.4.3 rc5 ข้าม 'hist' เพราะผลทะเบียนใช้ไม่ได้ ·
                #   ตอนนี้ทะเบียนยืนยันได้ว่าโฉนดยังใช้อยู่ — _ep_hist_deed)
                if e is None and isinstance(res, dict) and res.get("lis") == "login":
                    # ★ 2.4.2 rc4 — ต้องค้นทะเบียน iLands แต่ยังไม่เข้าสู่ระบบ ⇒ กล่องเข้าสู่ระบบ แล้วค้นต่อ (ยกเลิก = ผลจากแผนที่)
                    try:
                        lk_lbl.setText("ต้องค้นต่อในทะเบียน iLands — เข้าสู่ระบบในกล่องที่เด้ง…")
                    except RuntimeError:
                        return                                # กล่องถูกปิดไปก่อนผลมา
                    self._dol_lis_continue(res, attrs, lambda r: _end(r, None), on_abandon=_abandon)
                    return
                self._dol_log_lis_trace(res)              # ★ 2.4.2 rc4 (ผลตรวจ Windows rc3 ข้อพบ 7)
                if e is None and isinstance(res, dict) and res.get("choices"):
                    # ★ 2.4.8 ขั้น E ทะเบียนมีเลขนี้หลายฉบับ ⇒ กล่องเลือก (ไม่มีชื่อบุคคล) แล้วเปิดหน้ารายละเอียดของฉบับที่เลือก (1 คำขอ)
                    try:
                        row = self._doc_choose(res["choices"], _txt(res.get("parcel_type")) or _d, parent=d, shape_m2=area)
                    except RuntimeError:
                        return                                # กล่องถูกปิดไปก่อนผลมา
                    if row is None:
                        st["busy"] = False
                        try:
                            lk_lbl.setText(f"ทะเบียนมีเลขนี้ {len(res['choices'])} ฉบับ — ไม่ได้เลือก · ใส่หมู่/ตำบลให้ตรงแล้วค้นใหม่ได้")
                            _upd()
                        except RuntimeError:
                            pass
                        return
                    # ★ 2.4.9 (แผน 2.4.9 ข้อ 2.5 · เจ้าของงาน 27 ต.ค. 69 "ตอนกดเลือกฉบับนี้ มันไม่เติมข้อมูลให้") แถวค้นกลุ่ม ข ตามฉบับที่เลือก
                    #   (หมู่ · อำเภอ · ตำบล) ⇒ ค่าค้นของผลฉบับนี้ = ค่าใหม่ (เดิมแถวค้นว่างตามที่พิมพ์ · เติมเองภายหลัง ⇒ ผลถูกทิ้ง)
                    if _q0 is not None:
                        self._dq_fill_row(dq, row)
                    _qn = _qnow() if _q0 is not None else None
                    w2 = ParcelLookupWorker(dict(attrs, seq=_txt(row.get("parcel_seq")), row=dict(row)), zone=47, lis_more=True)
                    self._net_workers.append(w2)
                    w2.finished.connect(lambda _w=w2: _drop(_w))
                    w2.done.connect(lambda r2, _q=_qn: _end(r2, None, _q0=_q))
                    w2.fail.connect(lambda m2, _q=_qn: _end(None, m2, _q0=_q))
                    try:
                        lk_lbl.setText("กำลังเปิดฉบับที่เลือกจากทะเบียน…")
                    except RuntimeError:
                        return
                    w2.start()
                    return
                if e is None and isinstance(res, dict) and res.get("keydoc") and res.get("verified") and isinstance(res.get("key"), dict):
                    # ★ 2.4.10 ค้นด้วยเลขที่ ⇒ เติมคีย์ตามทะเบียนลงช่อง (คงโหมดเลขที่ · ช่องคีย์ปิด — เจ้าของงาน 29 ต.ค. 69 "ถ้าเลือกเลขที่เอกสารให้กรอกระวางไม่ได้")
                    try:
                        self._cp_fill_key(eds, cb_sc, ed_ln, res["key"])
                        _upd()
                    except RuntimeError:
                        return                                # กล่องถูกปิดไปก่อนผลมา
                    _utm = _txt((st.get("out") or {}).get("UTM"))     # คงโหมดเลขที่ · ผลผูกกับเลขที่ที่ค้น (_q0) — สลับเป็นโหมดคีย์ = ทิ้งผล
                st["busy"] = False
                try:
                    self._ep_mark_in_layer(poly_lyr, res)                   # ★ 2.4.6 เลขแนะนำที่มีแปลงในชั้นแล้ว
                    ar = self._ep_area_result(res, e, shape_m2=area)        # ★ 2.4.6 คีย์ชั้นประวัติ: เทียบเนื้อที่ทะเบียนกับรูป
                except Exception:
                    ar = {"area": None, "regis": None, "note": "อ่านผลจากระบบกรมไม่ได้"}
                try:
                    # ★ 2.4.2 rc5 (ผลตรวจ Windows rc4 ข้อพบ 1) — คีย์ในกล่องเปลี่ยนระหว่างค้น ⇒ ผลนี้เป็นของคีย์เดิม: ไม่ใช้ (ไม่ตั้ง REGIS/ชนิดเอกสาร/เนื้อที่)
                    _dn = _dnow()
                    _dmv = _dn is _GONE or self._lk_doc_moved(_d0, _dn)
                    if _txt((st.get("out") or {}).get("UTM")) != _txt(_utm) or (_q0 is not None and _qnow() != _q0) or _dmv:
                        lk_lbl.setText("ชนิดเอกสารเปลี่ยนระหว่างค้น — ผลที่ได้เป็นของชนิดเดิม (ไม่ได้ใช้) · กดค้นใหม่" if _dmv else
                                       "คีย์เปลี่ยนระหว่างค้น — ผลที่ได้เป็นของคีย์เดิม (ไม่ได้ใช้) · กดค้นใหม่")
                        _upd()
                        return
                    # ★ 2.4.5 — ช่อง REGIS แสดงค่าที่ใช้จริงแล้ว (เอกสารอื่นว่างเสมอ) ⇒ ตัดวลี "ตั้ง REGIS = '…'" ของหมายเหตุ (มาจาก 📝 ที่ตั้งตามผลค้น)
                    lk_lbl.setText(re.sub(r"ตั้ง REGIS = '[^']*' · ", "", ar["note"])
                                   .replace("กดปุ่มนี้ซ้ำภายหลังเพื่อดึงใหม่", "กดค้นใหม่ภายหลังได้")
                                   .replace("คงเนื้อที่ทะเบียนเดิม — ", ""))
                    st["area"], st["lk_utm"] = ar.get("area"), _utm
                    # ★ 2.4.3 ด่านโฉนด — ผลของคีย์นี้ผ่านไหม (ได้เนื้อที่ทะเบียน · ไม่ใช่แค่ชั้นประวัติ)
                    st["deed_why"] = self._ep_deed_block(res, ar)
                    st["deed_utm"] = _utm if st["deed_why"] is None else None
                    st["hist_utm"], st["hist_note"] = (_utm, ar.get("note") or "") if ar.get("hist_ok") else (None, None)
                    st["regis"] = ar.get("regis")             # ★ 2.4.4 REGIS ตามผลของคีย์นี้ — _upd ตั้งช่อง (ล็อก) ให้
                    st["reg"], st["reg_utm"] = ar.get("reg") or {}, _utm      # ★ 2.4.8 คอลัมน์ทะเบียน 7 ตัว (ผลที่ยืนยันแปลงได้)
                    st["reg_kd"] = bool(isinstance(res, dict) and res.get("keydoc"))   # ★ 2.4.10 ผลค้นด้วยเลขที่ (น.ส.ล. ⇒ มีทะเบียน)
                    st["lk_q"] = _q0                          # ★ 2.4.8 ขั้น E ค่าค้นของผลนี้ (เปลี่ยนภายหลัง ⇒ ทิ้งผล)
                    st["lk_doc"] = _d0                        # ★ 2.4.8 (ผลตรวจอิสระ ข้อ 2) ชนิดเอกสารของผลนี้
                    # ★ 2.4.3 (ผลตรวจ Windows rc4 ⚪4) — เติมชนิดเอกสารเฉพาะผลที่ยืนยันเป็นแปลงนี้ได้
                    #   (เดิมดูแค่ verified ⇒ ผลทะเบียนคร่อมสาขาที่ "ยืนยันไม่ได้ว่าเป็นแปลงนี้" ก็เติมโฉนดให้)
                    _sure = (isinstance(res, dict) and bool(res.get("verified")) and not res.get("cross_office")
                             and (ar.get("area") is not None or bool(ar.get("regis")))
                             # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 ⚪5) แผนที่มีเลขนี้หลายแปลง + ชั้นไม่ล็อกสาขา ⇒ ไม่เติม/ล็อกชนิดเอกสาร
                             and not ((res.get("match_count") or 1) > 1 and not res.get("branch_office")))
                    pt_ = _txt(res.get("parcel_type")) if _sure else ""
                    if pt_ and di >= 0:
                        i = cb_doc.findData(pt_)
                        if i >= 0 and (pt_ == self._DEED or not cb_doc.currentData()):
                            st["lk_doc"] = pt_                # ชนิดที่ผลทะเบียนเติมให้ = ชนิดของผลนี้ (ไม่นับว่าเปลี่ยนหลังค้น)
                            cb_doc.setCurrentIndex(i)
                            if pt_ == self._DEED:
                                # ★ 2.4.3 คำตัดสิน 21 ต.ค. — ทะเบียนบอกว่าเป็นโฉนด ⇒ ล็อกช่องชนิดเอกสาร (กันเปลี่ยนเป็นชนิดอื่นเพื่อหลบด่าน)
                                st["doc_lock"] = True
                                cb_doc.setEnabled(False)
                                cb_doc.setToolTip("ล็อกตามผลทะเบียน: แปลงนี้เป็นโฉนดที่ดิน")
                    _upd()
                except RuntimeError:
                    pass                                      # กล่องถูกปิดไปก่อนผลมา
            w.finished.connect(_drop)
            w.done.connect(lambda res: _end(res, None))
            w.fail.connect(lambda msg: _end(None, msg))
            w.start()

        for wdg in list(eds.values()) + [ed_ln]:
            wdg.textChanged.connect(_upd)
        for _sg in dq["sig"]:                         # ★ 2.4.8 ขั้น E แถวค้นกลุ่ม ข (เลขที่ · หมู่ · อำเภอ · ตำบล)
            _sg.connect(_upd)
        cb_by.currentIndexChanged.connect(_upd)      # ★ 2.4.10
        for c in (cb_sc, cb_tp, cb_doc):          # ★ 2.4.4 cb_rg ล็อก (_upd ตั้งให้เอง)
            c.currentIndexChanged.connect(_upd)
        cb_nm.editTextChanged.connect(_upd)
        cb_pn.editTextChanged.connect(_upd)          # ★ 2.4.5 rc2
        btn_lk.clicked.connect(_lookup)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        _upd()
        self._modal_busy = True
        try:
            ok = d.exec_() == QtWidgets.QDialog.Accepted
        finally:
            self._modal_busy = False
            d.deleteLater()
        if not ok or st.get("err") or st.get("gate"):
            return None
        out = dict(st["out"])
        out["AREA"] = st["area"] if st["lk_utm"] == out.get("UTM") else None
        out["_deed_utm"] = st["deed_utm"]             # ★ 2.4.3 ด่านโฉนด: _cp_apply ตรวจซ้ำก่อนเขียน (คีย์ที่ค้นแล้วผ่าน)
        out["_reg"], out["_reg_utm"] = (st["reg"], st["reg_utm"]) if st["reg_utm"] == out.get("UTM") else ({}, None)   # ★ 2.4.8
        out["_reg_kd"] = bool(st["reg_kd"] and st["reg_utm"] == out.get("UTM"))                                       # ★ 2.4.10
        # ★ 2.4.6 คีย์ชั้นประวัติที่ทะเบียน iLands ยืนยัน ⇒ ถามยืนยันพร้อมคำเตือน (ปุ่มตั้งต้น No)
        if st["hist_utm"] is not None and st["hist_utm"] == out.get("UTM") and \
                self._ask(QtWidgets.QMessageBox.Warning, title,
                          "🔴 " + _txt(st["hist_note"]).replace("⚠️ ", "", 1)
                          + "\n\nสร้างรูปแปลงด้วยคีย์นี้ (ใช้เนื้อที่ทะเบียนจาก iLands) จริงหรือไม่?",
                          QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                          QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return None
        l1 = [o for o in overlaps if (o[1] or "").upper().startswith("L1")]
        if l1 and self._ask(QtWidgets.QMessageBox.Warning, title,
                            f"รูปใหม่ทับแปลง L1 {len(l1)} แปลง (ชั้นอ้างอิงพิกัดหลัก) — สร้างทับจริงหรือไม่?",
                            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                            QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return None
        return out

    def _cp_names_at(self, point_lyr, xy, tol=0.01):
        """ชื่อหมุดที่ตำแหน่งนี้ (≤ 1 ซม.) — ชื่อจริงก่อน ชร · ไม่มี = ''  (มุมที่คลิกหมุด = ยืมชื่อหมุดนั้น)"""
        nf = self._addnode_name_field(point_lyr)
        if nf is None:
            return ""
        names = []
        rect = QgsRectangle(xy.x() - tol, xy.y() - tol, xy.x() + tol, xy.y() + tol)
        _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect))
        try:
            for f in _it:
                g = f.geometry()
                if g is None or g.isEmpty() or g.asPoint().distance(xy) > tol:
                    continue
                nm = _txt(f[nf])
                if nm and nm not in names:
                    names.append(nm)
        finally:
            _it.close()
        names.sort(key=lambda n: _is_chor(n))
        return names[0] if names else ""

    def _cp_apply(self, poly_lyr, point_lyr, geom, pts, vals):
        """เขียนแปลงใหม่ + หมุดทุกมุม ลงบัฟเฟอร์ในคำสั่งเดียว (↺ Undo คืนทั้งคู่) · ล้มที่ใด = ทิ้งทั้งชุด"""
        title = self._CP_TITLE
        if not self._is_mod():
            return False
        _in = dict(vals)
        if re.fullmatch(r"-[0-9]+", _txt(_in.get("LANDNO"))):
            _in["LANDNO"] = "0"     # เลขที่สาธารณะที่กล่องคิดไว้ ⇒ ส่ง 0 ให้คิดใหม่ (_ep_normalize ไม่รับเลขติดลบ · ข้อมูลอาจเปลี่ยนระหว่างกล่องเปิด)
        out, err, _n = self._cp_check(poly_lyr, point_lyr, _in)           # ด่านซ้ำก่อนเขียน (ข้อมูลอาจเปลี่ยนระหว่างกล่องเปิด)
        if err:
            self._ask(QtWidgets.QMessageBox.Warning, title, "สร้างไม่ได้:\n" + "\n".join(err))
            return False
        out["AREA"] = vals.get("AREA")
        if _txt(out.get("DOC_TYPE")) in self._DOC_LIKE_PUB:
            out["AREA"] = None                 # ★ 2.4.7 rc2 🟡2 ท.ค./อื่นๆ ไม่มีทะเบียน ⇒ ไม่มีเนื้อที่ทะเบียน (ผลค้นที่ค้างจากชนิดอื่นไม่ใช้)
        if (_public_landno(out.get("LANDNO")) and _txt(out.get("DOC_TYPE")) not in self._DOC_NOKEY) \
                or _txt(out.get("DOC_TYPE")) in self._DOC_LIKE_PUB:
            out["REGIS"] = "ไม่มีทะเบียน"      # ★ 2.4.4 ที่สาธารณะ (เลขที่ดิน ≤ 0) ไม่มีทะเบียนเสมอ (เจ้าของงาน 23 ต.ค. 69) · ทางเรียกตรงด้วย
            #   ★ 2.4.7 ท.ค./อื่นๆ เลขใดก็ 'ไม่มีทะเบียน' (เจ้าของงาน 26 ต.ค. 69 17:2x "ทค ให้ไม่มีทะเบียนและใส่เหมือนที่สาธารณะ" · 17:3x "อื่นๆ เหมือนสาธารณะ")
            #   ★ 2.4.7 เอกสารกลุ่ม ข (เลข ≤ 0 ที่คิดให้) ไม่ใช่ที่สาธารณะ ⇒ ตกไปทาง "เอกสารอื่นว่างเสมอ" ด้านล่าง
        elif _txt(out.get("DOC_TYPE")) == self._DEED:
            out["REGIS"] = "มีทะเบียน"        # ★ 2.4.5 (ผลตรวจ Windows 2.4.4 rc1 ⚪2) — เขียนได้เฉพาะเมื่อผ่านด่านโฉนดด้านล่าง (ได้เนื้อที่ทะเบียนของคีย์นี้)
        elif vals.get("_reg") and ((_txt(out.get("DOC_TYPE")) in (self._DOC_AIR,) + self._DOC_UTMDOC     # ★ ขั้น E1 ตราจอง
                                    and _txt(vals.get("_reg_utm")) == _txt(out.get("UTM")))
                                   or (_txt(out.get("DOC_TYPE")) == "น.ส.ล." and vals.get("_reg_kd")      # ★ 2.4.10 ค้นด้วยเลขที่
                                       and _txt(vals.get("_reg_utm")) == _txt(out.get("UTM")))
                                   or _txt(out.get("DOC_TYPE")) in self._DOC_NOKEY):
            out["REGIS"] = "มีทะเบียน"        # ★ 2.4.8 ขั้น D น.ส.3 ก / ขั้น E กลุ่ม ข ที่ทะเบียนยืนยันได้ฉบับเดียว
        else:
            out["REGIS"] = None                # ★ 2.4.5 เอกสารอื่นว่างเสมอ (เจ้าของงาน 23 ต.ค. 69) · ทางเรียกตรงด้วย
        # ★ 2.4.3 ด่านโฉนดที่ดิน (ด่านสุดท้ายก่อนเขียน · ทางเรียกตรง) — ต้องมีเนื้อที่ทะเบียนจากการค้นที่ผ่านด่านของคีย์นี้
        if _txt(out.get("DOC_TYPE")) == self._DEED and not (out.get("AREA") and _txt(vals.get("_deed_utm")) == _txt(out.get("UTM"))):
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "สร้างไม่ได้:\nโฉนดที่ดินต้องค้นทะเบียนและได้เนื้อที่ทะเบียนของคีย์นี้ก่อน (🔍 ค้นทะเบียนในกล่องสร้างรูปแปลง)")
            return False
        nm_f = self._addnode_name_field(point_lyr)
        pf, mf = poly_lyr.fields(), point_lyr.fields()
        nf = QgsFeature(pf)
        nf.setGeometry(geom)
        for k in self._EP_KEYS + ("UTM", "Type", "REGIS", "DOC_TYPE", "NAME", self._PN_FIELD):     # ★ 2.4.5 rc2 parcel_name
            i = _fld_idx(pf, k)
            if i >= 0 and out.get(k) not in (None, ""):
                nf.setAttribute(i, out[k])
        _reg = vals.get("_reg") or {}
        if _reg and (_txt(vals.get("_reg_utm")) == _txt(out.get("UTM")) or _txt(out.get("DOC_TYPE")) in self._DOC_NOKEY):
            # ★ 2.4.8 คอลัมน์ทะเบียน 7 ตัว (แผน 2.4.7 ข้อ 5) — ผลค้นที่ยืนยันแปลงของคีย์นี้ (คีย์ที่คิดใหม่ในด่านซ้ำต้องตรงกับคีย์ที่ค้น) ·
            #   ★ ขั้น E กลุ่ม ข ระบุฉบับด้วยเลขที่ (ไม่ใช่คีย์) ⇒ เลขที่ดิน ≤ 0 ที่คิดใหม่ในด่านซ้ำต่างจากตอนค้นได้
            for k in _REG_COLS:
                i = _fld_idx(pf, k)
                if i >= 0 and _reg.get(k) not in (None, ""):
                    nf.setAttribute(i, _reg[k])
            # ★ 2.4.9 (เจ้าของงาน 27 ต.ค. 69 "ถ้าเจอสาธารณประโยชน์ ในชื่อให้ใส่ใน parcel name") โฉนดที่ผู้ถือกรรมสิทธิ์เป็นสาธารณประโยชน์
            #   ⇒ parcel_name = ชื่อผู้ถือ (ช่อง parcel_name ของกล่องปิดสำหรับโฉนด ⇒ ค่ามาจากผลทะเบียนอย่างเดียว)
            i = _fld_idx(pf, self._PN_FIELD)
            if i >= 0 and _reg.get("parcel_name") and _txt(out.get("DOC_TYPE")) == self._DEED:
                nf.setAttribute(i, self._pn_clean(_reg["parcel_name"])[:self._PN_MAX])
        ga = self._geom_area_m2(poly_lyr, geom)
        if out.get("AREA"):
            i = _fld_idx(pf, "AREA")
            if i >= 0:
                nf.setAttribute(i, float(round(out["AREA"], 2)))
            i = _fld_idx(pf, "DIFF_AREA")
            if i >= 0 and out["AREA"] > 0:
                nf.setAttribute(i, round((ga - out["AREA"]) / out["AREA"] * 100.0, 2))   # สูตรเดียวกับ trigger (ร้อยละ)
        i = _fld_idx(pf, "UPDATED_BY")
        if i >= 0:
            try:
                from qgis.core import QgsDataSourceUri
                u = QgsDataSourceUri(poly_lyr.dataProvider().dataSourceUri()).username()
            except Exception:
                u = ""
            if u:
                nf.setAttribute(i, u)
        i = _fld_idx(pf, "DATE_STAMP")
        if i >= 0:
            import datetime as _dt
            nf.setAttribute(i, _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        marks = []
        for p in pts:
            m = QgsFeature(mf)
            m.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(p)))
            # ★ 2.4.8 rc2 (เจ้าของงาน 27 ต.ค. 69 ~01:20 "ปล่อยไว้ก่อน … แต่ปลั๊กอินเราต้องไม่เขียนเพิ่ม") หมุดไม่ใส่ REGIS แล้ว (เดิมคัดลอกจากแปลง)
            #   — REGIS/AREA ของหมุดไม่มีผู้อ่าน (ปลั๊กอิน · เว็บ · view/trigger ของฐาน) และไม่ตรงแปลงอยู่แล้ว ~372k ดวง ⇒ สถานะทะเบียนอยู่ที่แปลงเท่านั้น
            for k in self._EP_KEYS + ("UTM", "Type"):
                j = _fld_idx(mf, k)
                # ★ rc2 (audit A2-03) — Type ของหมุดผ่าน _marker_type_from_parcel ที่เดียวกับ Add Node / 🍩 (CT-RTK ⇒ ไม่ตั้ง)
                _v = _marker_type_from_parcel(out.get(k)) if k == "Type" else out.get(k)
                if j >= 0 and _v not in (None, ""):
                    m.setAttribute(j, _v)
            nm = self._cp_names_at(point_lyr, QgsPointXY(p))
            if nm and nm_f is not None:
                m.setAttribute(mf.indexOf(nm_f), nm)
            j = _fld_idx(mf, "EDIT_SRC")
            if j >= 0:
                m.setAttribute(j, self._CP_EDIT_SRC)
            marks.append((m, nm))
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(poly_lyr, point_lyr, title=title, what="ยังไม่ได้สร้างรูปแปลง"):
            return False
        self._op_begin([poly_lyr, point_lyr])
        poly_lyr.beginEditCommand("Create Parcel")
        point_lyr.beginEditCommand("Create Parcel Markers")
        ok = False
        try:
            ok = poly_lyr.addFeature(nf)
            for m, _nm in marks:
                ok = ok and point_lyr.addFeature(m)
        except Exception:
            _log_exc("สร้างรูปแปลง: เขียนลงบัฟเฟอร์ไม่สำเร็จ")
            ok = False
        if ok:
            poly_lyr.endEditCommand()
            point_lyr.endEditCommand()
        else:
            poly_lyr.destroyEditCommand()
            point_lyr.destroyEditCommand()
        self._op_commit()
        if not ok:
            self.iface.messageBar().pushMessage(title, "สร้างรูปแปลงไม่สำเร็จ — ยกเลิกทั้งหมดแล้ว (ไม่มีแปลง/หมุดค้าง) · " + self._LOG_HINT,
                                                level=2, duration=10)
            return False
        self.iface.mapCanvas().refresh()
        n_blank = sum(1 for _m, nm in marks if not nm)
        self.iface.messageBar().pushMessage(
            title, f"สร้างแปลง {out['UTM']} ({out['Type']}) + หมุด {len(marks)} ดวง"
                   + (f" (ไม่มีชื่อ {n_blank} ดวง — ตั้งชื่อทีหลังด้วย Add Node/แก้ชื่อหมุด)" if n_blank else "")
                   + " • กด 💾 บันทึก เพื่อลงฐาน • คลิกสร้างรูปต่อได้เลย",
            level=0, duration=10)
        return True
