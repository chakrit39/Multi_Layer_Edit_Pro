# -*- coding: utf-8 -*-
"""Add / Rename / Delete / Swap Node

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import math
from qgis.PyQt import QtWidgets
from qgis.core import (Qgis, QgsCoordinateTransform, QgsFeature, QgsFeatureRequest, QgsGeometry, QgsMessageLog,
                       QgsPointXY, QgsProject, QgsRectangle, QgsWkbTypes)
from ..core.util import (_DATE_COLS, _date_txt, _date_val, _fld_idx, _is_chor, _log_exc, _marker_type_from_parcel,
                         _name_key, _newest_name, _norm_utm, _txt, _UTM_FIELD_NAMES)
from ..lock_rules import L1_TYPES
from ..map_tools import AddNodeTool, DeleteNodeTool, RenameNodeTool, SwapNodeTool


class NodesMixin:
    """Add / Rename / Delete / Swap Node"""
                                  # (กันคลิกหมุดไกลแล้วรูปแปลงบิดตาม · 2 ม. = ผ่อนให้แปลง L2-RO ที่หยาบ)
                                  # ★ 2.3.1 (21 ก.ย. 69) เจ้าของงานสั่ง: **ผู้ช่วยผู้ดูแลขึ้นไปไม่ติดเพดานนี้**
                                  #   เพดานมีไว้กันพนักงานคลิกพลาดแล้วรูปแปลงบิด — คนที่แก้ของยาก ๆ
                                  #   (mod/admin) ต้องแทรกมุมไกลกว่านั้นได้จริง ดู `_addnode_max_dist()`

    def _addnode_max_dist(self):
        """เพดานระยะของ Add Node ตามชั้นสิทธิ์ — None = ไม่จำกัด

        🔑 ต้องอ่านจาก `_tier_now()` ไม่ใช่จากปุ่มโหมด: ชั้นจริงมาจาก role ในฐานข้อมูล
        🔴 ปลดเพดานเฉพาะ **ผู้ช่วยผู้ดูแล (mod) ขึ้นไป** · พนักงานทั่วไปยังคง 2 ม. เหมือนเดิม
        """
        return None if self._is_mod() else self.ADDNODE_MAX_DIST

    # ============ Add Node: เพิ่ม node ให้แปลง + เพิ่มหมุด (ระวางจากแปลง, ชื่อจากหมุดเดิม) ============
    def start_add_node(self):
        if not self._pair_key_ok("Add Node"):
            return
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_lyr or poly_lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, "Add Node", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        if not point_lyr or point_lyr.geometryType() != QgsWkbTypes.PointGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, "Add Node", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        self.cancel_transform()
        # ★ 2 ก.ย. 69 — ต้องตั้ง snapping เหมือนเครื่องมืออื่น
        #   แถบข้อความของเครื่องมือนี้เขียนเองว่า "คลิกที่หมุด (snap ให้อัตโนมัติ)"
        #   และถ้าไม่ตั้ง การยืมแม่เหล็กของหน้าต่างวาดเส้นจะถูกคืน (= ปิดแม่เหล็ก) ตอนสลับมาที่นี่
        self.setup_snapping()
        self.temp_tool = AddNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.temp_tool._push(                                           # ★ 2.3.7 (UX-01) ข้อความของเครื่องมือ
            f"คลิกเลือกแปลงใน '{poly_lyr.name()}' (เลือก 1 แปลง • คลิกแปลงอื่น = เปลี่ยน) "
            "แล้วคลิกที่หมุด (snap ให้อัตโนมัติ) เพื่อเพิ่ม node • คลิกขวา/Esc = ยกเลิก", title="Add Node")

    def _addnode_names_at(self, point_lyr, name_field, xy, coinc=0.05):
        """ชื่อ (ไม่ว่าง · ไม่ซ้ำ · ตามลำดับที่เจอ) ของหมุดทุกดวงที่ตำแหน่งเดียวกับ xy (≤ coinc ม.) — สูตรเดียวกับที่ Add Node ใช้ยืมชื่อ"""
        names = []
        if name_field is None:
            return names
        rect = QgsRectangle(xy.x() - coinc, xy.y() - coinc, xy.x() + coinc, xy.y() + coinc)
        _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect))
        try:
            for f in _it:
                nm = _txt(f[name_field])
                if nm and nm not in names:
                    names.append(nm)
        finally:
            _it.close()
        return names

    def _addnode_name_unnamed(self, poly_lyr, point_lyr, name_field, unnamed, ins_xy, pf_of):
        """★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค.) — Add Node ตรงจุดที่แปลงมี node + หมุดของตัวเองอยู่แล้ว **แต่หมุดชื่อว่าง**
        ⇒ เด้งให้เลือกชื่อจากหมุดอื่นที่ snap อยู่ตรงนั้น (≤5 ซม.) · ไม่มีชื่อให้เลือก ⇒ พิมพ์เอง (คำตัดสิน 11 ต.ค.) · ยกเลิก = ไม่เปลี่ยน
        เขียนแบบ ✏️ แก้ชื่อหมุด (พนักงานตั้งชื่อหมุดที่ชื่อว่างได้อยู่แล้ว · 2.2.9) — ไม่แทรกมุม ไม่สร้างหมุดใหม่
        unnamed = [(fid แปลง, gid หมุด)] · คืน True ถ้าตั้งชื่อได้อย่างน้อย 1 ดวง"""
        if not self._need_column_or_warn(point_lyr, name_field, "Add Node"):
            return False
        names = self._addnode_names_at(point_lyr, name_field, ins_xy)
        n = len(unnamed)
        head = ("มุมนี้มี node และหมุดของแปลงอยู่แล้ว แต่หมุด" + (f" {n} ดวง" if n > 1 else "") + "ยังไม่มีชื่อ")
        if names:
            chosen, ok = QtWidgets.QInputDialog.getItem(
                self.iface.mainWindow(), "ตั้งชื่อหมุด",
                head + "\n\nเลือกชื่อจากหมุดอื่นที่อยู่ตรงนี้:", names, 0, False)
        else:
            chosen, ok = QtWidgets.QInputDialog.getText(
                self.iface.mainWindow(), "ตั้งชื่อหมุด",
                head + "\n\nตรงนี้ไม่มีหมุดอื่นที่มีชื่อให้เลือก — พิมพ์ชื่อหมุดแล้วกด OK\n(ยกเลิก = ไม่เปลี่ยน)")
        if not ok:
            return False
        chosen = (chosen or "").strip()
        if not chosen:
            self.iface.messageBar().pushMessage("Add Node", "ไม่ได้ใส่ชื่อ — ไม่มีอะไรเปลี่ยน", level=0, duration=5)
            return False
        if not _is_chor(chosen):
            _ซ้ำ = []
            for fid, mid in unnamed:
                pf = pf_of.get(fid)
                if pf is not None:
                    _ซ้ำ += [g for g in self._marker_name_dups(poly_lyr, point_lyr, pf, chosen, mid) if g not in _ซ้ำ]
            if _ซ้ำ and self._ask(
                    QtWidgets.QMessageBox.Warning, "ตั้งชื่อหมุด",
                    f"ชื่อ '{chosen}' ซ้ำกับหมุดอื่นของแปลงเดียวกัน (gid {', '.join(str(i) for i in _ซ้ำ[:6])}"
                    + (" …" if len(_ซ้ำ) > 6 else "") + ")\n\n"
                    "หมุดในแปลงเดียวกันไม่ควรชื่อซ้ำกัน — ตั้งชื่อซ้ำจริงหรือไม่?",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                return False
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(point_lyr, title="Add Node", what="ยังไม่ได้ตั้งชื่อหมุด"):
            return False
        idx = point_lyr.fields().indexOf(name_field)
        self._op_begin([point_lyr])
        point_lyr.beginEditCommand("Name Marker")
        n_ok = 0
        try:
            for fid, mid in unnamed:
                f = point_lyr.getFeature(mid)
                if not f.isValid() or _txt(f[name_field]):
                    continue                   # มีคนตั้งชื่อไปแล้วระหว่างทาง ⇒ ไม่ทับ
                if point_lyr.changeAttributeValue(mid, idx, chosen, f[name_field]):
                    n_ok += 1
        except Exception:
            _log_exc("Add Node: ตั้งชื่อหมุดชื่อว่างไม่สำเร็จ")
            n_ok = 0
        finally:
            if n_ok:
                point_lyr.endEditCommand()
            else:
                point_lyr.destroyEditCommand()
            self._op_commit()
        if not n_ok:
            self.iface.messageBar().pushMessage("Add Node", "ตั้งชื่อหมุดไม่สำเร็จ — ไม่มีอะไรเปลี่ยน", level=2, duration=8)
            return False
        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushMessage(
            "Add Node", f"ตั้งชื่อหมุด '{chosen}' ให้หมุดชื่อว่าง {n_ok} ดวง (ไม่ได้เพิ่ม node) • กด 💾 บันทึก เพื่อยืนยัน",
            level=0, duration=8)
        return True

    @staticmethod
    def _addnode_mark_xy(ins_xy, cv, has_vertex, to_pt):
        """★ 2.3.7 (review DU-02-D1) — จุดวางหมุดใหม่ (CRS ชั้นหมุด): มีมุมอยู่แล้ว ⇒ **บนมุมเดิมเป๊ะ** (cv[0])
        เดิมวางที่จุด snap ⇒ snap ติดหมุดแปลงข้างเคียงที่ห่างมุม 1 มม.–1 ซม. = หมุดใหม่เยื้องมุม แล้วด่านก่อนบันทึกเตือน
        ทั้ง 'มุมไม่มีหมุด' และ 'หมุดไม่อยู่บนมุม' (กด Add Node ซ้ำก็แก้ไม่ได้ — ถูกข้ามว่ามีหมุดแล้ว)
        ไม่มีมุม (แทรกมุมใหม่ที่จุด snap) ⇒ จุด snap เหมือนเดิม"""
        if has_vertex and cv is not None and cv[0] is not None:
            try:
                return to_pt.transform(cv[0]) if to_pt is not None else QgsPointXY(cv[0])
            except Exception:
                pass
        return QgsPointXY(ins_xy)

    def _addnode_own_stray(self, point_lyr, poly_feat, xy, utm_fields, to_poly, r):
        """★ 2.3.7 (review DI-07) — ระยะ (ม.) ถึงหมุด **ของแปลงนี้เอง** ที่ใกล้ xy ที่สุดในรัศมี r ซึ่ง **ไม่ได้อยู่บนมุมใด
        ของแปลงนี้** (= น่าจะเป็นหมุดของมุมนี้ที่เยื้องไป) · ไม่มี/ตรวจไม่ได้ = None · เทียบระวางแบบ `_marker_exists_here`"""
        try:
            key = [f for f in utm_fields
                   if _fld_idx(point_lyr.fields(), f) >= 0 and _fld_idx(poly_feat.fields(), f) >= 0]
            if not key:
                return None
            geom = poly_feat.geometry()
            want = [str(poly_feat[k] or "") for k in key]
            best = None
            rect = QgsRectangle(xy.x() - r, xy.y() - r, xy.x() + r, xy.y() + r)
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    m = g.asPoint()
                    d = m.distance(xy)
                    # ★ 2.4.0 (review DU-02) — ค่าคงที่ชุดเดียว (_MK_WELD_TOL) แทน 0.01 / 0.0001 ที่พิมพ์มือ
                    if d <= self._MK_WELD_TOL or d > r:          # ≤ 1 ซม. = หมุดของมุมนี้เอง (_marker_exists_here)
                        continue
                    if [str(f[k] or "") for k in key] != want:
                        continue
                    mp = to_poly.transform(m) if to_poly is not None else QgsPointXY(m)
                    cvm = geom.closestVertex(mp)
                    if cvm[4] is not None and cvm[4] <= self._MK_WELD_TOL ** 2:  # อยู่บนมุมอื่นของแปลงนี้แล้ว (≤ 1 ซม.)
                        continue
                    if best is None or d < best:
                        best = d
            finally:
                _it.close()
            return best
        except Exception:
            return None

    def _addnode_plan(self, poly_lyr, point_lyr, fids, pf_of, ins_xy, ins_poly, utm_fields):
        """★ 2.3.7 (review UX-44 · DI-07 · DU-02-D1) — ตรวจรายแปลงแบบ **อ่านอย่างเดียว** ก่อนถามชื่อ/เปิดแก้ไข
        เพรดิเคตชุดเดียวกับลูปใน `_addnode_execute` (ด่านในลูปยังเป็นตัวตัดสินจริง)
        คืน {fid: {"why": None | "l1" | "far" | "exists", "tp", "far", "cap",
                   "node": จะแทรกมุมใหม่, "mark": จะสร้างหมุดใหม่, "warn": ข้อความให้ยืนยัน (DI-07) หรือ None}}"""
        proj = QgsProject.instance()
        _diff = poly_lyr.crs() != point_lyr.crs()
        to_pt = QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), proj) if _diff else None
        to_poly = QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj) if _diff else None
        near = self.ADDNODE_NEAR_CORNER
        many = sum(1 for f in fids if pf_of.get(f) is not None) > 1
        out = {}
        for fid in fids:
            pf = pf_of.get(fid)
            if pf is None or not pf.isValid():
                continue
            e = out[fid] = {"why": None, "tp": None, "far": None, "cap": None,
                            "node": False, "mark": False, "warn": None}
            tp = self._poly_type_str(poly_lyr, pf)
            if tp in L1_TYPES and not self._l1_unlocked():          # ★ 2.4.0 (DU-01) lock_rules
                e["why"], e["tp"] = "l1", tp
                continue
            geom = pf.geometry()
            cv = geom.closestVertex(ins_poly)
            has_vertex = cv[4] is not None and cv[4] < self._MK_WELD_TOL ** 2   # < 1 ซม. (เกณฑ์เดียวกับลูป · ★ 2.4.0 DU-02 ค่าคงที่)
            pre = ("แปลง %s: " % fid) if many else ""
            if not has_vertex:
                seg = geom.closestSegmentWithContext(ins_poly)
                _cap = self._addnode_max_dist()
                if _cap is not None and seg[0] is not None and seg[0] > (_cap ** 2):
                    e["why"], e["far"], e["cap"] = "far", math.sqrt(seg[0]), _cap
                    continue
                e["node"] = True
                # (ก) มุมเดิมอยู่ห่าง 1 ซม.–0.5 ม. ⇒ น่าจะคลิกพลาดมุมเดิม (จะได้มุมเกิน/หนามแหลมข้างมุมจริง)
                if cv[4] is not None and cv[4] <= near * near:
                    e["warn"] = (pre + "จุดที่คลิกห่างมุมเดิมของแปลง %.1f ซม. — แทรกมุมใหม่ตรงนี้จริงไหม?\n"
                                 "(ถ้าจะย้ายมุมเดิมมาตรงนี้ ให้ใช้ Move Node แทน)" % (math.sqrt(cv[4]) * 100))
                # (ค) ★ rc2 (audit A1-02) — ผู้ช่วย/ผู้ดูแล (ไม่มีเพดาน) ซูมออก (> ADDNODE_FAR_MUPP ม./px) แล้วจุดห่างขอบเกินเพดาน
                #   ของพนักงาน ⇒ ถามก่อน (เดิมคลิกหมุดของแปลงอื่นที่ห่าง 15 ม. ตอนซูมออก = แปลงยื่นออกไป 15 ม. ไม่มีกล่องถาม
                #   มุมมีหมุดครบ ด่านก่อนบันทึกไม่จับ) · ซูมเข้าทำงานตามปกติ (ไม่กวนงานที่ตั้งใจแทรกมุมไกล)
                elif _cap is None and seg[0] is not None and seg[0] > self.ADDNODE_MAX_DIST ** 2:
                    try:
                        from ..map_tools import _canvas_is_metres
                        _cv = self.iface.mapCanvas()
                        _zoomed_out = _canvas_is_metres(_cv) and _cv.mapUnitsPerPixel() > self.ADDNODE_FAR_MUPP
                    except Exception:
                        _zoomed_out = False
                    if _zoomed_out:
                        e["warn"] = (pre + "จุดที่คลิกห่างขอบแปลง %.2f ม. — รูปแปลงจะยื่นออกไปถึงจุดนี้\n"
                                     "(ตอนซูมออก คลิกพลาดไปโดนหมุด/มุมของแปลงอื่นได้ง่าย) แทรกมุมใหม่ตรงนี้จริงไหม?"
                                     % math.sqrt(seg[0]))
            mk_xy = self._addnode_mark_xy(ins_xy, cv, has_vertex, to_pt)
            if self._marker_exists_here(point_lyr, pf, mk_xy, utm_fields):
                if not e["node"]:
                    e["why"] = "exists"
                    # ★ 2.4.0 (review DU-02) — หมุดของมุมนี้เยื้อง 1 มม.–1 ซม. (ด่านก่อนบันทึกเตือนว่ามุมไม่มีหมุด)
                    #   ⇒ บอกให้ใช้ Move Node แทนการบอกว่า "มีหมุดอยู่แล้ว" เฉย ๆ (คิวรีเพิ่มเฉพาะสาขานี้ · 1 คลิก)
                    e["offset"] = not self._marker_exists_here(point_lyr, pf, mk_xy, utm_fields,
                                                               tol=self._MK_AT_CORNER_TOL)
                    # ★ 2.3.9 — หมุดของมุมนี้มีแล้วแต่ชื่อว่าง ⇒ Add Node เสนอตั้งชื่อจากหมุดที่ snap อยู่ตรงนั้น
                    _lk_out = []
                    e["unnamed"] = self._own_unnamed_markers_here(
                        point_lyr, pf, mk_xy, utm_fields, self._addnode_name_field(point_lyr),
                        poly_lyr=poly_lyr, ล็อก_out=_lk_out)            # ★ 2.4.0 (DU-01) ไม่เสนอหมุดล็อก
                    e["unnamed_locked"] = len(_lk_out)                  # ★ 2.4.0 (review DU-01) บอกเหตุในแถบสรุป
                continue
            e["mark"] = True
            if has_vertex:
                # (ข) มุมนี้ยังไม่มีหมุด แต่แปลงมีหมุดของตัวเองเยื้องอยู่ใกล้ ๆ (ไม่อยู่บนมุมใด) ⇒ ควรย้ายหมุดนั้นแทน
                d = self._addnode_own_stray(point_lyr, pf, mk_xy, utm_fields, to_poly, near)
                if d is not None:
                    e["warn"] = (pre + "แปลงนี้มีหมุดของตัวเองห่างมุมนี้ %.1f ซม. (หมุดนั้นไม่ได้อยู่บนมุมใดของแปลง)\n"
                                 "ถ้าเป็นหมุดของมุมนี้ที่เยื้องไป ให้ใช้ Move Node (หรือ Align) ย้ายหมุดมาที่มุมแทน\n"
                                 "สร้างหมุดใหม่ที่มุมนี้จริงไหม?" % (d * 100))
        return out

    def _addnode_report_skips(self, plan, poly_lyr=None):
        """★ 2.3.7 (review UX-44) — ไม่มีแปลงไหนจะได้มุม/หมุดใหม่: แจ้งเหตุด้วยข้อความเดิม (ไม่ถามชื่อ · ไม่เปิดแก้ไข)
        ★ 2.3.7 (review ER-06) — บอกแปลงด้วยระวาง/เลขที่ดิน (_feat_label) แทน fid เมื่อรู้ชั้น"""
        bar = self.iface.messageBar()
        n_ex = 0
        n_off = 0                    # ★ 2.4.0 (review DU-02) ในนั้นเป็นหมุดเยื้องมุม (1 มม.–1 ซม.) กี่จุด
        n_lk = 0                     # ★ 2.4.0 (review DU-01) ในนั้นเป็นหมุดล็อก L1 ที่ชื่อว่าง (ตั้งชื่อไม่ได้) กี่จุด
        for fid, e in plan.items():
            _lab = self._feat_label(poly_lyr, fid) if poly_lyr is not None else f"แปลง {fid}"
            if e["why"] == "l1":
                bar.pushMessage("Add Node", f"ข้าม {_lab}: เป็น {e['tp']} (พิกัดอ้างอิง ห้ามเพิ่ม node)",
                                level=1, duration=6)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            elif e["why"] == "far":
                bar.pushMessage("Add Node", f"ข้าม {_lab}: จุดที่คลิกห่างจากขอบแปลงนี้ {e['far']:.2f} ม. "
                                            f"(เกิน {e['cap']:.0f} ม.)", level=1, duration=8)
            elif e["why"] == "exists":
                # ★ 2.4.0 (review DU-01-followup) — หมุดชื่อว่างที่ถูกตัดเพราะล็อก นับแยก "แทน" "มีหมุดอยู่แล้ว"
                #   (เดิมนับทั้งสองกอง ⇒ แถบยังขึ้น "ข้าม 1 จุดที่มีหมุดอยู่แล้ว" ซึ่งไม่ใช่เหตุที่ตั้งชื่อไม่ได้)
                if e.get("unnamed_locked"):
                    n_lk += 1
                    continue
                n_ex += 1
                n_off += 1 if e.get("offset") else 0
        if n_ex or n_lk or not plan:
            bar.pushMessage("Add Node", "เพิ่ม node 0 แปลง + หมุด 0 จุด"
                                        + (f" • ข้าม {n_ex} จุดที่มีหมุดอยู่แล้ว" if n_ex else "")
                                        + (f" • {n_off} จุดเป็นหมุดเยื้องมุม (ไม่เกิน 1 ซม.) — ใช้ Move Node "
                                           "ลากหมุดไปวางที่มุม" if n_off else "")
                                        # ★ 2.4.0 (review DU-01) — หมุดชื่อว่างที่ล็อก: เดิมขึ้นแค่ "มีหมุดอยู่แล้ว" ไม่บอกว่าตั้งชื่อไม่ได้เพราะล็อก
                                        + (f" • {n_lk} จุดเป็นหมุด L1 (พิกัดอ้างอิง) ที่ยังไม่มีชื่อ — "
                                           + self._l1_hint("ตั้งชื่อหมุดไม่ได้") if n_lk else ""),
                            level=1 if (n_off or n_lk) else 0, duration=8)

    def _tool_ready(self, title):
        """เหมือน `_admin_ready` แต่ **ไม่บังคับโหมดผู้ดูแล**

        ★ 2.2.9 — ✏️ แก้ชื่อหมุด และ 🗑 ลบ node ย้ายออกจากกล่อง ADMIN มาให้พนักงานทั่วไปใช้
          (โดยมีข้อจำกัดของตัวเอง ดู `_rename_node_execute` / `_delete_node_execute`)
          จึงต้องมีด่านที่ตรวจ "เลเยอร์พร้อมไหม" อย่างเดียว แยกจากด่านสิทธิ์
        """
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_lyr or poly_lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, title, "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return None
        if not point_lyr or point_lyr.geometryType() != QgsWkbTypes.PointGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, title, "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return None
        return poly_lyr, point_lyr

    def _admin_find_marker(self, poly_lyr, point_lyr, poly_feat, xy, tol=0.05):
        """หา "หมุดของแปลงนี้" ที่พิกัด xy (UTM ตรงกับแปลง) — มุมร่วมมีหลายหมุดซ้อน
        การเลือกแปลงก่อนจึงเป็นตัวชี้ว่าจะจัดการหมุดของแปลงไหน"""
        # ★ 2.2.4 — ต้องล้างธงตั้งแต่บรรทัดแรก ไม่ใช่หลังหา candidates
        #   ไม่งั้นถ้าครั้งก่อนผู้ใช้กด Cancel แล้วครั้งนี้ออกทางด่านข้างล่าง (หาคอลัมน์ UTM ไม่เจอ)
        #   ธงเก่าจะยังเป็น True ⇒ ผู้เรียกนึกว่าผู้ใช้กดยกเลิก แล้วเงียบทั้งที่ควรเตือน
        self._admin_pick_cancelled = False
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        if not pu or not tu:
            return None
        # ★ 31 ส.ค. 69 — เดิมคืน "ตัวแรกที่ provider ส่งมา" ซึ่งไม่มีลำดับที่รับประกัน
        # ★ 3 ก.ย. 69 (v2.2.3) — ถ้าเจอหลายหมุดซ้อนกัน ให้เด้ง Popup ให้ผู้ใช้เลือก
        # ★ 2.2.9 — ใช้ตัวสร้างชุดเดียวกับด่านนับ "หมุดซ้อน" (ห้ามมีสองชุดที่เห็นไม่ตรงกัน)
        candidates = self._marker_candidates(poly_lyr, point_lyr, poly_feat, xy, tol)
        if not candidates:
            return None

        if len(candidates) == 1:
            return candidates[0]['feature']

        # ★★ 3 ก.ย. 69 (2.2.4) — เด้งกล่องเลือก "เฉพาะตอนที่ตัดสินแทนผู้ใช้ไม่ได้จริง ๆ"
        #   2.2.3 เด้งทุกครั้งที่มีหมุดเข้าเกณฑ์ >1 ตัว (กรอบ 5 ซม.) ซึ่งกว้างกว่าที่ตั้งใจไว้เอง
        #   (เจตนาตามรายงาน 2.2.3 คือกรณี "ซ้อนทับกันอยู่ในพิกัดเดียวกัน")
        #   ผลข้างเคียงที่วัดได้: sim16 ค้าง เพราะเคสที่มีตัวใกล้ชัดเจนก็ยังเด้งถาม
        #   ⇒ ถ้ามีตัวที่ใกล้กว่าตัวรองอย่างมีนัย (>_ADMIN_PICK_TIE) ให้คืนตัวนั้นเงียบ ๆ
        #     เหมือน 2.2.0 · เด้งถามเฉพาะตอนที่ระยะ "เสมอกัน" = เลือกเองแล้วมีสิทธิ์ผิดตัว
        scored = []
        for c in candidates:
            try:
                g = c['feature'].geometry()
                d = g.asPoint().distance(xy) if (g is not None and not g.isEmpty()) else None
            except Exception:
                d = None
            scored.append((d, c))
        withd = sorted([t for t in scored if t[0] is not None], key=lambda t: t[0])
        nod   = [t for t in scored if t[0] is None]
        if len(withd) == 1 and not nod:
            return withd[0][1]['feature']
        if withd and (len(withd) == 1 or (withd[1][0] - withd[0][0]) > self._ADMIN_PICK_TIE):
            # ตัวที่ใกล้สุดชนะขาด -> ไม่ต้องรบกวนผู้ใช้ (และไม่มีทางเลือกผิดตัว)
            if not nod:
                return withd[0][1]['feature']

        # ระยะเสมอกัน (หรืออ่านพิกัดไม่ได้) -> ให้ผู้ใช้ชี้เอง
        order = [c for _d, c in withd] + [c for _d, c in nod]
        from ..map_tools import NodeSelectionDialog
        self._modal_busy = True
        dlg, sel = None, []
        try:
            dlg = NodeSelectionDialog(order, self.iface.mainWindow(), multi_select=False)
            ok = dlg.exec_()
            if ok:
                sel = dlg.get_selected()        # อ่านผลก่อนลบกล่อง
        finally:
            self._modal_busy = False
            try:
                dlg.deleteLater()               # ★ 2.3.7 (review LC-11) — เดิมกล่องค้างเป็นลูกของหน้าต่างหลักทุกครั้ง
            except Exception:
                pass
        if ok:
            if sel:
                return sel[0]['feature']
        # ★ กด Cancel ไม่ใช่ "ไม่มีหมุด" — ผู้เรียกต้องเงียบ ไม่ใช่ขึ้นว่าระวางไม่ตรงกัน
        self._admin_pick_cancelled = True
        return None

    def _marker_other_corner(self, poly_lyr, point_lyr, pf, xy, mk):
        """★ rc2 (audit A2 · ข้อที่ผู้ตรวจทานพบเพิ่ม) — แก้ชื่อหมุด / สลับหมุด: จุดที่คลิกอยู่บน "มุม" ของแปลงที่เลือก (≤ 1 มม.)
        แต่หมุดที่ `_admin_find_marker` (กรอบ ±5 ซม.) ได้มา อยู่ใกล้ "มุมอื่น" ของแปลงนี้มากกว่ามุมที่คลิก
        = มุมที่คลิกไม่มีหมุดของแปลงนี้ (หมุดที่เห็นตรงนั้นเป็นของแปลงข้างเคียง) และหมุดที่ได้เป็นของมุมข้าง ๆ
        เดิมเครื่องมือแก้ชื่อ/สลับหมุดของมุมข้าง ๆ ไปเงียบ ๆ (กล่องบอกแค่ gid/ชื่อ) · แบบเดียวกับ A2-01 ของลบ Node
        คืน None = ใช้ได้ (หรือตัดสินไม่ได้ ⇒ คงพฤติกรรมเดิม) · คืนระยะ (ม.) จากหมุดถึงมุมที่คลิก = เป็นหมุดของมุมอื่น"""
        try:
            g = pf.geometry()
            if g is None or g.isEmpty() or mk is None or not mk.hasGeometry():
                return None
            proj = QgsProject.instance()
            to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj)
                       if poly_lyr.crs() != point_lyr.crs() else None)
            q = to_poly.transform(QgsPointXY(xy)) if to_poly else QgsPointXY(xy)
            m = QgsPointXY(mk.geometry().asPoint())
            m = to_poly.transform(m) if to_poly else m
            cv = g.closestVertex(q)
            if cv[1] < 0 or cv[4] is None or cv[4] > self._DUP_TOL ** 2:
                return None                                  # คลิกไม่ได้อยู่บนมุมของแปลงนี้ ⇒ ไม่ตัดสิน
            c = QgsPointXY(cv[0])
            d_c = m.distance(c)
            if d_c <= self._DUP_TOL:
                return None
            d_o = min((m.distance(QgsPointXY(v.x(), v.y())) for v in g.vertices()
                       if QgsPointXY(v.x(), v.y()).distance(c) > self._DUP_TOL), default=None)
            return d_c if (d_o is not None and d_o < d_c) else None
        except Exception:
            return None

    def _rename_node_execute(self, poly_lyr, fid, snap_xy):
        """แก้ชื่อ (BND_NAME) ของหมุด "ของแปลงที่เลือก" ณ จุดที่คลิก

        ★ 2.2.9 — เจ้าของงานสั่ง: "ให้แก้ไขได้เฉพาะแปลงที่ชื่อหมุดว่าง
          ยกเว้นสิทธิ์ mlep_admin ที่แก้ไขได้หมด" (เกณฑ์แอดมิน = ต้องเปิดโหมดผู้ดูแลก่อน)
        """
        ready = self._tool_ready("แก้ชื่อหมุด")
        if not ready:
            return False
        _chk = self._tool_layers_ok(poly_lyr, "แก้ชื่อหมุด")   # กันสลับคอมโบหลัง arm
        if _chk is None:
            return False
        poly_lyr, point_lyr = _chk
        pf = poly_lyr.getFeature(fid)
        if not pf.isValid():
            return False
        # ★ 2.2.9 — ด่าน L1 ชั้นใน (ไม่พึ่งธงของเครื่องมือฝั่งหน้าจออย่างเดียว)
        #   เจ้าของงานยืนยัน 18 ก.ย.: แตะ L1 ได้ต่อเมื่อ **เปิดโหมดผู้ดูแล และ กดปลดล็อก** เท่านั้น
        if not self._pair_cols_ok(poly_lyr, point_lyr, "แก้ชื่อหมุด"):    # ★ 2.3.7 (review AR-06-D) — ด่านชั้นใน
            return False
        _tp = self._poly_type_str(poly_lyr, pf)
        if _tp in L1_TYPES and not self._l1_unlocked():     # ★ 2.4.0 (DU-01) lock_rules
            self.iface.messageBar().pushMessage(
                "แก้ชื่อหมุด", "แปลงนี้เป็น %s (พิกัดอ้างอิง) — %s"
                % (_tp, self._l1_hint("แก้ชื่อหมุดไม่ได้")),            # ★ 2.3.7 (review UX-13) — ไม่บอกโหมดซ่อน
                level=1, duration=7)                 # ★ 2.3.7 (audit C-02) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            return False
        mk = self._admin_find_marker(poly_lyr, point_lyr, pf, snap_xy)
        if mk is None:
            if getattr(self, "_admin_pick_cancelled", False):
                return False          # ★ 2.2.4 ผู้ใช้กดยกเลิกเอง -> เงียบ ไม่ใช่ความผิดของข้อมูล
            if getattr(self, "_marker_lock_scan_failed", False):
                return False          # ★ 2.4.0 (review DU-01) สแกนล็อกไม่สำเร็จ — แจ้งเหตุจริงบนแถบแล้ว
            self.iface.messageBar().pushMessage(
                "แก้ชื่อหมุด",
                ("หมุดตรงนี้เป็นหมุดของแปลง L1 (พิกัดอ้างอิง) — " + self._l1_hint("แก้ชื่อไม่ได้")   # ★ 2.3.7 UX-13
                 if getattr(self, "_marker_l1_filtered", 0) else
                 "ตรงนี้ไม่มีหมุด 'ของแปลงที่เลือก' (ระวางไม่ตรงกัน)"), level=1, duration=6)
            return False
        # ★ rc2 (audit A2 · ผู้ตรวจทานพบเพิ่ม) — หมุดที่ได้เป็นของมุมอื่น (คลิกมุมที่ไม่มีหมุดของแปลงนี้) ⇒ ไม่แก้ชื่อหมุดของมุมข้าง ๆ
        _d = self._marker_other_corner(poly_lyr, point_lyr, pf, snap_xy, mk)
        if _d is not None:
            self.iface.messageBar().pushMessage(
                "แก้ชื่อหมุด",
                "มุมที่คลิกไม่มีหมุดของแปลงที่เลือก — หมุดของแปลงนี้ที่ใกล้ที่สุดอยู่บนมุมข้าง ๆ (ห่าง %.1f ซม.) "
                "ไม่ได้แก้ชื่อให้ · ถ้าจะแก้ชื่อดวงนั้น ให้คลิกที่หมุดดวงนั้นโดยตรง" % (_d * 100), level=1, duration=9)
            return False
        nf = self._addnode_name_field(point_lyr)
        if nf is None:
            self.iface.messageBar().pushMessage(
                "แก้ชื่อหมุด", "ชั้นหมุดไม่มีคอลัมน์ชื่อ (BND_NAME)", level=1, duration=6)    # ★ 2.3.7 (audit C-02)
            return False
        old = _txt(mk[nf])          # ★ 2.3.5 NULL = ว่าง (ดู _txt)
        # ★ 2.2.9 — ด่านสิทธิ์: แก้ได้เฉพาะหมุดที่ "ยังไม่มีชื่อ"
        #   ★ 2.3.0 — แบบเต็ม (แก้ชื่อเดิมได้) เลื่อนลงมาที่ชั้น **ผู้ช่วยผู้ดูแล** ไม่ต้องเป็นผู้ดูแลเต็ม
        #   ★ 2.3.4 — แปลง LandsMaps (L2-LM) ยกเว้นให้: พนักงานแก้ชื่อเดิมได้เลย
        if old.strip() and not self._is_mod() and not self._is_landsmaps(poly_lyr, pf):
            self.iface.messageBar().pushMessage(
                "แก้ชื่อหมุด",
                "หมุดนี้มีชื่อ '%s' อยู่แล้ว — แก้ได้เฉพาะหมุดที่ยังไม่มีชื่อ "
                "(ชื่อเดิมต้องให้ผู้ช่วยผู้ดูแล/ผู้ดูแลแก้ให้)" % old,      # ★ 2.3.7 (review UX-13) — ไม่บอกโหมดซ่อน/วิธีเข้า
                level=1, duration=8)
            return False
        new, ok = QtWidgets.QInputDialog.getText(
            self.iface.mainWindow(), "แก้ชื่อหมุด",
            f"ระวาง/UTM: {pf[self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)]}\n"
            f"หมุด gid {mk.id()} — ชื่อเดิม: {old or '(ว่าง)'}\n\nชื่อใหม่:", text=old)
        if not ok:
            return False
        new = new.strip()
        if new == old:
            return False
        # ★ 2.3.7 (review DI-49) — ชื่อซ้ำกับหมุดอื่นของแปลงเดียวกัน ⇒ ถามก่อน (ปุ่มตั้งต้น = ไม่)
        #   เดิมรับเงียบ ๆ ⇒ แปลงเดียวมีหมุดชื่อ 'SQ-2' สองดวง · ชร (ชำรุด) ซ้ำได้ — เป็นสถานะของหมุด ไม่ใช่ชื่อเฉพาะ
        if new and not _is_chor(new):
            _ซ้ำ = self._marker_name_dups(poly_lyr, point_lyr, pf, new, mk.id())
            if _ซ้ำ and self._ask(
                    QtWidgets.QMessageBox.Warning, "แก้ชื่อหมุด",
                    f"ชื่อ '{new}' ซ้ำกับหมุดอื่นของแปลงนี้ (gid {', '.join(str(i) for i in _ซ้ำ[:6])}"
                    + (" …" if len(_ซ้ำ) > 6 else "") + ")\n\n"
                    "หมุดในแปลงเดียวกันไม่ควรชื่อซ้ำกัน — ตั้งชื่อซ้ำจริงหรือไม่?",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                return False
        # ★ 2.3.7 (review DI-49 · กติกา ชร ห้ามหาย) — เปลี่ยน/ลบชื่อ ชร ⇒ ถามก่อน (ปุ่มตั้งต้น = ไม่)
        #   แก้ชื่อหมุดไม่เก็บชื่อเดิมไว้ที่ไหน (★ b12 เจ้าของงานตัดสิน 3 ต.ค.: ปลั๊กอินไม่เขียน ALT_NAME) ⇒ ชร หายจากหมุดนี้ — คนแก้ต้องรู้ก่อน
        if _is_chor(old) and not _is_chor(new):
            if self._ask(
                    QtWidgets.QMessageBox.Warning, "แก้ชื่อหมุด",
                    f"หมุด gid {mk.id()} ชื่อ '{old}' (หมุดชำรุด)\n\n"
                    f"ถ้าเปลี่ยนเป็น '{new or '(ว่าง)'}' ชื่อ ชร จะหายจากหมุดนี้ (ไม่มีที่เก็บชื่อเดิม — จดไว้ก่อนถ้าต้องใช้)\n\n"
                    "เปลี่ยนชื่อจริงหรือไม่?",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                return False
        # ★ rc2 (audit A2-05 · DI-15 ส่วนที่เหลือ) — _ensure_editing (ตรวจ isEditable ซ้ำ + Log Warning) แทน startEditing() ดิบ
        if not self._ensure_editing(point_lyr, title="แก้ชื่อหมุด", what="ยังไม่ได้แก้ชื่อหมุด"):
            return False
        self._op_begin([point_lyr])
        point_lyr.beginEditCommand("Rename Marker")
        okv = False
        try:
            # ★ 2.3.7 (review DI-49) — ลบชื่อ = NULL (แบบ Add Node) ไม่ใช่ '' · ค่าเดิมส่งค่าจริงของหมุด (NULL คงเป็น NULL)
            # ★ 2.3.7 (review DI-28) — เช็คผลการเขียน: ล้ม ⇒ ทิ้งคำสั่ง (ไม่ดัน undo step เปล่า) + แจ้ง แทนข้อความสำเร็จ
            okv = bool(point_lyr.changeAttributeValue(
                mk.id(), point_lyr.fields().indexOf(nf), new if new else None, mk[nf]))
        except Exception:
            okv = False
        finally:
            if okv:
                point_lyr.endEditCommand()
            else:
                point_lyr.destroyEditCommand()
        self._op_commit()
        if not okv:
            self.iface.messageBar().pushMessage(
                "แก้ชื่อหมุด", "เขียนชื่อหมุดไม่สำเร็จ — ไม่มีอะไรเปลี่ยน", level=2, duration=8)
            return False
        # การเปลี่ยนชื่อถูกบันทึกลง <D>_Move_Log โดย trigger log_move (action='renamed') ตอนกดบันทึก
        self.iface.messageBar().pushMessage(
            "แก้ชื่อหมุด", f"เปลี่ยน '{old or '(ว่าง)'}' -> '{new or '(ว่าง)'}' แล้ว • กด 💾 บันทึก เพื่อยืนยัน",
            level=0, duration=6)
        return True

    def _delete_stacked_marker(self, point_lyr, cands, poly_lyr=None, pf=None, corner=None):
        """★ 2.2.9 — ลบ "หมุดซ้อน" ทีละดวง (ไม่แตะมุมแปลง)

        เจ้าของงานสั่ง: "ถ้ามีหมุดซ้อนกันให้เด้ง popup เลือกว่าจะลบหมุดไหน"
        🔑 ตรงนี้ปลอดภัยกับกติกาเหล็ก: มุมแปลงยังอยู่ และยังเหลือหมุดอีกอย่างน้อย 1 ดวงบนมุมนั้น
        """
        from ..map_tools import NodeSelectionDialog
        # ★ 2.3.7 (audit F4 · เจ้าของงานสั่ง "ลบ Node ⇒ popup บอกวันที่ + ผู้ใช้เลือกเอง") — b12 ใส่วันที่ให้ทางของผู้ช่วย/ผู้ดูแลแล้ว
        #   แต่ทางลัดหมุดซ้อนของพนักงาน (กล่องนี้) ยังไม่บอก ⇒ ทุกแถวบอก SURV_DATE · ISSUE_DATE ('-' = ว่าง) · ลำดับ/ตัวเลือกเดิม
        #   (ผู้ใช้เลือกเองว่าจะลบดวงไหน) · ชั้นที่ไม่มีคอลัมน์วันที่เลย ⇒ ไม่แสดง (ไม่มีข้อมูลให้บอก)
        _มีวันที่ = any(_fld_idx(point_lyr.fields(), _c) >= 0 for _c in _DATE_COLS)
        for c in cands:
            try:
                c['s'], c['i'] = self._mk_dates(c['feature'])
            except Exception:
                c['s'], c['i'] = None, None
            if _มีวันที่:
                c['dates'] = f"SURV_DATE {_date_txt(c['s'])} · ISSUE_DATE {_date_txt(c['i'])}"
        self._modal_busy = True
        dlg, sel = None, []
        try:
            dlg = NodeSelectionDialog(cands, self.iface.mainWindow(), multi_select=False)
            ok = dlg.exec_()
            if ok:
                sel = dlg.get_selected()        # อ่านผลก่อนลบกล่อง
        finally:
            self._modal_busy = False
            try:
                dlg.deleteLater()               # ★ 2.3.7 (review LC-11)
            except Exception:
                pass
        if not ok:
            return False
        if not sel:
            return False
        mk = sel[0]['feature']
        # ★ 2.3.7 (review DI-32 · เจ้าของงานตัดสิน 2 ต.ค.) — ชื่อที่จะหายไปกับหมุดที่ลบ ต้องบอกก่อนยืนยัน (ชื่อหลัก · ชร · ประวัติ ALT_NAME)
        #   เดิมกล่องไม่บอก ALT_NAME/ชร เลย · "หาย" = หมุดที่เหลือในกองไม่มีชื่อนั้น ทั้งชื่อหลักและ ALT_NAME (ชร นับเป็นชื่อเดียวกันทุกแบบ)
        #   ไม่ย้ายชื่อให้ — ★ b12 (เจ้าของงานตัดสิน 3 ต.ค.): ทางพนักงาน "เตือนอย่างเดียว" · ปลั๊กอินไม่เขียน ALT_NAME (อ่านมาแสดงได้)
        #   บอกให้จด/เลือกลบอีกดวงแทน
        _ai = _fld_idx(point_lyr.fields(), "ALT_NAME")

        def _alt(f):
            return [x.strip() for x in _txt(f[_ai]).split("|") if x.strip()] if _ai >= 0 else []
        _มีอยู่ = set()
        for c in cands:
            if c['id'] != mk.id():
                _มีอยู่.update(x for x in [_txt(c.get('nm'))] + _alt(c['feature']) if x)
        _มี_ชร = any(_is_chor(x) for x in _มีอยู่)
        _nm = _txt(sel[0].get('nm'))
        _หาย = [_nm] if _nm and _nm not in _มีอยู่ and not (_is_chor(_nm) and _มี_ชร) else []
        _หาย_alt = [x for x in _alt(mk) if x != _nm and x not in _มีอยู่ and not (_is_chor(x) and _มี_ชร)]
        _เตือน = ""
        if _หาย and _is_chor(_nm):
            _เตือน += f"\n⚠️ หมุดที่ลบชื่อ '{_nm}' (หมุดชำรุด) แต่หมุดที่เหลือบนมุมนี้ไม่มีชื่อ ชร ⇒ ชร จะหายไปกับหมุดที่ลบ"
        elif _หาย:
            _เตือน += f"\n⚠️ ชื่อ '{_nm}' ไม่มีในหมุดที่เหลือบนมุมนี้ ⇒ จะหายไปกับหมุดที่ลบ"
        if _หาย_alt:
            _เตือน += "\n⚠️ ประวัติชื่อ (ALT_NAME) ของหมุดที่ลบ: " + " | ".join(_หาย_alt) + " — จะหายไปด้วย"
        if _เตือน:
            _เตือน += "\n   (หมุดที่เหลือไม่ได้รับชื่อเหล่านี้ — จดไว้ก่อน หรือเลือกลบอีกดวงแทน)"
        # ★ 2.3.7 (review DI-32) — จำลองหลังลบ (กติกาหมุด 1 มม.): มุมที่ไม่มีหมุดของแปลง / หมุดหลุดมุม ที่เกิดใหม่ ⇒ เตือนก่อนยืนยัน
        _เหล็ก = ""
        if poly_lyr is not None and pf is not None and corner is not None:
            try:
                _g0 = QgsGeometry(pf.geometry())
                _mp = QgsPointXY(mk.geometry().asPoint())
                if poly_lyr.crs() != point_lyr.crs():
                    _mp = QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance()).transform(_mp)
                _แตะ = [QgsPointXY(corner), _mp]
                _เหล็ก = self._delnode_iron_after(poly_lyr, point_lyr, pf, _g0, _g0,
                                                  self._twin_vertices(poly_lyr, pf, pf.id(), _แตะ), _แตะ, [mk.id()])
            except Exception:
                _เหล็ก = "\n⚠️ ตรวจกติกาหมุด 1 มม. หลังลบไม่ได้ — ตรวจเองหลังลบ"
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ยืนยันลบหมุดซ้อน",
            "จุดนี้มีหมุดของแปลงนี้ซ้อนกัน %d ดวง%s\n\n"
            "จะลบ: gid %s ชื่อ %s%s%s\n\n"
            "มุมแปลงไม่ถูกแตะ และยังเหลือหมุดอีก %d ดวงบนมุมนี้"
            % (len(cands), " (ห่างมุมแปลงไม่เกิน 1 มม. ต่อแกน)" if corner is not None else "",
               mk.id(), (sel[0].get('name') or '(ไม่มีชื่อ)')
               + (f" ({sel[0]['dates']})" if sel[0].get('dates') else ""),        # ★ 2.3.7 (audit F4)
               _เตือน, _เหล็ก, len(cands) - 1),
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        if not self._ensure_editing(point_lyr, title="ลบ Node", what="ยังไม่ได้ลบหมุด"):    # ★ 2.4.0 (review DI-15) เดิมไม่ดูผล
            return False
        self._op_begin([point_lyr])
        point_lyr.beginEditCommand("Delete Stacked Marker")
        okv = False
        try:
            okv = bool(point_lyr.deleteFeature(mk.id()))
        finally:
            if okv:
                point_lyr.endEditCommand()
            else:
                point_lyr.destroyEditCommand()
        self._op_commit()
        if not okv:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ลบหมุดไม่สำเร็จ — ย้อนกลับให้แล้ว "
                "(พนักงานทั่วไปอาจไม่มีสิทธิ์ DELETE บนชั้นหมุด)", level=2, duration=10)
            return False
        _n_หาย = len(_หาย) + len(_หาย_alt)
        self.iface.messageBar().pushMessage(
            "ลบ Node", "ลบหมุดซ้อน 1 ดวงแล้ว"
                       + (" · ⚠️ ชื่อหาย %d ชื่อ" % _n_หาย if _n_หาย else "")
                       + (" · ⚠️ ตรวจกติกาหมุด 1 มม. ตรงนี้ (ดูคำเตือนก่อนยืนยัน)" if _เหล็ก else "")
                       + " • กด 💾 บันทึก เพื่อยืนยัน",
            level=(1 if _n_หาย or _เหล็ก else 0), duration=6)
        return True

    def _delete_dup_vertex(self, poly_lyr, fid, dups, point_lyr=None, clicked=None, relax=False):
        """★ 2.2.9 — ลบ "node ซ้อน" ออก 1 มุม (ไม่แตะหมุด)

        เจ้าของงานสั่ง: "ถ้าเป็น node ให้เด้งเตือนว่าพบ node ซ้อนกัน จะลบเลือก 1 node"
        🔑 สองมุมทับกันสนิท ⇒ ลบตัวหนึ่งออก **รูปแปลงไม่เปลี่ยน** และหมุดยังเกาะมุมที่เหลืออยู่
        ★ 2.3.7 (review DI-31 · เจ้าของงานตัดสิน 2 ต.ค. "แก้รุ่นต่อไป") — เดิมลบตัวเลขมากสุดของกองเสมอ แล้วบอกว่ารูป/เนื้อที่ไม่เปลี่ยน
          ทั้งที่ (ก) มุมที่ทับกันแต่ไม่ติดกันในวง (เส้นขอบผ่านจุดเดียวกัน 2 รอบ) ลบแล้วเนื้อที่เปลี่ยนจริง (ทดสอบ 100 → 105/150 ตร.ม.)
          (ข) มุมเกือบซ้อน (เยื้อง < 1 มม.) ลบแล้วเนื้อที่เปลี่ยนเป็นเศษ ตร.ม. (ชั้นส่งงาน V3 0.01-0.205 ตร.ม.)
          ⇒ · มุมซ้อนธรรมดา = มุมที่ "ติดกันในวง" กับมุมที่คลิก (clicked = เลขจาก closestVertex)
            · เทียบเนื้อที่ก่อน/หลังบนสำเนา — เปลี่ยน ≥ 0.0001 ตร.ม. ⇒ ทางพนักงานไม่ลบ บอกเนื้อที่จริง (ต้องให้ผู้ช่วยผู้ดูแล/ผู้ดูแลลบ)
              แปลง L2-LM (`relax` — พนักงานลบมุมจริงได้อยู่แล้ว) ⇒ ลบได้ แต่กล่องบอกเนื้อที่จริงแทนคำว่า "ไม่เปลี่ยน"
            · มุมที่ลบ = มุมที่ไม่มีหมุดของแปลงนี้ (≤ 1 มม.) ⇒ หมุดยังอยู่บนมุมที่เหลือ (⑦ ข้อ 4 "เลือกมุมตามหมุด" ที่เลื่อนมา)
            · "รูปแปลงและเนื้อที่ไม่เปลี่ยน" เฉพาะมุมที่ทับกันเป๊ะ · เยื้อง ⇒ บอกระยะที่มุมขยับ
        """
        # ★ 18 ก.ย. — ด่านชั้นในของตัวช่วยเอง (ผู้ตรวจ Windows ชี้จุดนี้)
        #   `_delete_node_execute` เช็ค len(_dups) > 1 อยู่แล้ว แต่ถ้ามีใครเรียกตัวนี้ตรง ๆ
        #   (เช่นชุดทดสอบ หรือโค้ดในอนาคต) แล้วส่งลิสต์ที่มีตัวเดียวมา มันจะลบมุมนั้นทิ้งเลย
        #   = ลบมุมธรรมดาทั้งที่ไม่ใช่ของซ้อน ⇒ รูปแปลงเปลี่ยน
        #   🔑 ฟังก์ชันที่ "ลบของ" ต้องตรวจเงื่อนไขของตัวเองเสมอ ไม่ฝากไว้กับผู้เรียก
        if not dups or len(dups) < 2:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ตรงนี้ไม่ใช่มุมซ้อน (มีมุมเดียวในวงนี้) — ไม่ลบให้",
                level=1, duration=7)
            return False
        TOL_A = 0.0001          # ตร.ม. — "เนื้อที่เปลี่ยน" (เจ้าของงานตัดสิน 2 ต.ค.)
        try:
            _pf = poly_lyr.getFeature(fid)
            _g0 = QgsGeometry(_pf.geometry())
            # ① เลขในวงของมุมที่คลิกและของทุกตัวในกอง — จุดปิดวง (n-1) = มุมแรก (0)
            #    (closestVertex คืนเลขของจุดปิดวงได้ เช่นคลิกมุมแรกของวง ⇒ ได้ n-1 ไม่ใช่ 0)
            _v0 = dups[0] if clicked is None else clicked
            _ok0, _vid0 = _g0.vertexIdFromVertexNr(_v0)
            if not _ok0:
                raise ValueError("vertexIdFromVertexNr(%s)" % _v0)
            _n = _g0.constGet().vertexCount(_vid0.part, _vid0.ring)
            _m = _n - 1                      # จำนวนมุมจริงของวง (ไม่นับจุดปิดวง)

            def _ใน(k):
                ok, vid = _g0.vertexIdFromVertexNr(k)
                if not ok or (vid.part, vid.ring) != (_vid0.part, _vid0.ring):
                    return None
                return 0 if vid.vertex in (0, _n - 1) else vid.vertex
            _ทั่ว = {}
            for k in dups:
                if _ใน(k) is not None:
                    _ทั่ว.setdefault(_ใน(k), k)
            _l0 = _ใน(_v0)
            _v0 = _ทั่ว.get(_l0, _v0)
            # ② มุมซ้อนธรรมดา = ติดกันในวงกับมุมที่คลิก · ไม่ติดกัน = เส้นขอบผ่านจุดเดียวกันมากกว่า 1 รอบ (ลบแล้วรูปเปลี่ยน)
            _ติด = [_ทั่ว[l] for l in sorted(_ทั่ว) if l != _l0 and (l - _l0) % _m in (1, _m - 1)]
            ธรรมดา = bool(_ติด)
            กอง = sorted([_v0] + _ติด) if ธรรมดา else sorted(set(_ทั่ว.values()))
            _จุด = {k: QgsPointXY(_g0.vertexAt(k)) for k in กอง}
            # ③ มุมที่ลบ: มุมที่ไม่มีหมุดของแปลงนี้ภายใน 1 มม. (หมุดอยู่บนมุมที่เหลือ) · ไม่งั้นแบบเดิม = เลขมากสุดของกอง
            nr, _ตามหมุด = max(กอง), False
            _มีหมุด = (self._dup_vertex_marked(poly_lyr, point_lyr, _pf, [_จุด[k] for k in กอง])
                       if point_lyr is not None else None)
            if _มีหมุด:
                _ว่าง = [k for k, b in zip(กอง, _มีหมุด) if not b]
                if _ว่าง and len(_ว่าง) < len(กอง):
                    nr, _ตามหมุด = max(_ว่าง), True
            _g1 = QgsGeometry(_g0)
            if not _g1.deleteVertex(nr):
                raise ValueError("deleteVertex(%s)" % nr)
            a0, a1 = _g0.area(), _g1.area()
            ระยะ = min(_จุด[nr].distance(_จุด[k]) for k in กอง if k != nr)
        except Exception as e:
            QgsMessageLog.logMessage("_delete_dup_vertex: ตรวจมุมซ้อนไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ตรวจมุมซ้อนตรงนี้ไม่ได้ — ไม่ลบให้", level=2, duration=8)
            return False
        dA = abs(a1 - a0)
        _ทศ = 2 if dA >= 0.01 else 4          # เศษ ตร.ม. ⇒ ทศนิยม 4 (ไม่งั้นขึ้น "199.99 → 199.99" เหมือนไม่เปลี่ยน)
        _เนื้อที่ = f"เนื้อที่ {a0:,.{_ทศ}f} → {a1:,.{_ทศ}f} ตร.ม. (เปลี่ยน {dA:,.4f} ตร.ม.)"
        # ④ ทางพนักงาน: ไม่ใช่มุมซ้อนธรรมดา หรือเนื้อที่เปลี่ยน ⇒ ไม่ลบ + บอกเนื้อที่จริง (เดิมลบแล้วบอกว่าไม่เปลี่ยน)
        #   แปลง L2-LM ลบมุมจริงได้อยู่แล้ว ⇒ ไปกล่องยืนยันที่บอกเนื้อที่จริง
        if not relax and (not ธรรมดา or dA >= TOL_A):
            self.iface.messageBar().pushMessage(
                "ลบ Node",
                ("มุมที่ทับกันตรงนี้ไม่ได้อยู่ติดกันในวง (เส้นขอบผ่านจุดนี้มากกว่า 1 รอบ)" if not ธรรมดา
                 else "มุมซ้อนตรงนี้ไม่ได้ทับกันสนิท")
                + " — ลบแล้ว" + _เนื้อที่ + " · ไม่ใช่มุมซ้อนธรรมดา ไม่ลบให้ (ต้องให้ผู้ช่วยผู้ดูแล/ผู้ดูแลลบให้)",
                level=1, duration=12)
            return False
        # ★ รอบ 9d (ฌ · ผู้ตรวจรอบ 9b B ข้อ 2) + 9e — จำลองสภาพหลังลบแล้วเตือนก่อนยืนยัน (กติกาหมุด 1 มม. · นับมุมของแปลงแฝดด้วย)
        #   กองนี้จัดด้วยกรอบ ±1 มม. ต่อแกน (ห่างกันได้ถึง 1.41 มม.) — ถ้อยคำเดิม "ทับกันสนิทภายใน 1 มม." ไม่ตรง
        _เหล็ก = ""
        if point_lyr is not None:
            try:
                _แตะ = [QgsPointXY(_g0.vertexAt(k)) for k in dups]
                _เหล็ก = self._delnode_iron_after(poly_lyr, point_lyr, _pf, _g0, _g1,
                                                  self._twin_vertices(poly_lyr, _pf, fid, _แตะ), _แตะ, [])
            except Exception:
                _เหล็ก = "\n⚠️ ตรวจกติกาหมุด 1 มม. หลังลบไม่ได้ — ตรวจเองหลังลบ"
        # ★ 2.3.7 (review DI-31) — "รูปแปลงและเนื้อที่ไม่เปลี่ยน" เฉพาะเมื่อจริง (มุมทับกันเป๊ะ) · เยื้อง ⇒ บอกระยะ · L2-LM ⇒ เนื้อที่จริง
        if dA < TOL_A and ระยะ <= 1e-6:
            _ผล = "รูปแปลงและเนื้อที่ไม่เปลี่ยน"
        elif dA < TOL_A:
            _ผล = "มุมที่ลบห่างมุมที่เหลือ %.1f มม. · เนื้อที่เปลี่ยนไม่ถึง 0.0001 ตร.ม." % (ระยะ * 1000)
        else:
            _ผล = "⚠️ " + _เนื้อที่
        ans = self._ask(
            QtWidgets.QMessageBox.Warning, "พบ node ซ้อนกัน",
            "มุมแปลงตรงนี้ซ้อนกันอยู่ %d มุม (ห่างจากมุมที่คลิกไม่เกิน 1 มม. ต่อแกน)%s\n\n"
            "จะลบออก 1 มุม%s — %s · หมุดไม่ถูกแตะ%s\n"
            "ดำเนินการต่อ?" % (len(dups), "" if ธรรมดา else " — ไม่ได้อยู่ติดกันในวง (เส้นขอบผ่านจุดนี้มากกว่า 1 รอบ)",
                               " (มุมที่ไม่มีหมุด — หมุดยังอยู่บนมุมที่เหลือ)" if _ตามหมุด else "", _ผล, _เหล็ก),
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        if not self._ensure_editing(poly_lyr, title="ลบ Node", what="ยังไม่ได้ลบมุม"):      # ★ 2.4.0 (review DI-15) เดิมไม่ดูผล
            return False
        self._op_begin([poly_lyr])
        poly_lyr.beginEditCommand("Delete Duplicate Node")
        okv = False
        try:
            _r = poly_lyr.deleteVertex(fid, nr)
            # deleteVertex คืน enum (Success == 0) ไม่ใช่ bool — เช็คแบบ truthiness จะกลับด้าน
            okv = _r if isinstance(_r, bool) else (int(_r) == 0)
        finally:
            if okv:
                poly_lyr.endEditCommand()
            else:
                poly_lyr.destroyEditCommand()
        self._op_commit()
        if not okv:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ลบมุมซ้อนไม่สำเร็จ — ย้อนกลับให้แล้ว", level=2, duration=8)
            return False
        self.iface.messageBar().pushMessage(
            "ลบ Node", "ลบมุมที่ซ้อนกันออก 1 มุมแล้ว"
                       + ((" · ⚠️ เนื้อที่เปลี่ยน %s ตร.ม." % format(dA, ",.4f")) if dA >= TOL_A else "")   # ★ 2.3.7 DI-31 (L2-LM)
                       + (" · ⚠️ ตรวจกติกาหมุด 1 มม. ตรงนี้ (ดูคำเตือนก่อนยืนยัน)" if _เหล็ก else "")
                       + " • กด 💾 บันทึก เพื่อยืนยัน",
            level=(1 if _เหล็ก or dA >= TOL_A else 0), duration=6)
        return True

    def _delete_node_execute(self, poly_lyr, fid, snap_xy):
        """ลบ node ของแปลงที่เลือก + หมุดของแปลงนั้นพร้อมกัน (ตรงข้าม Add Node)

        ★ 2.2.9 — รวมงาน "ลบหมุด" เข้ามาที่ปุ่มนี้ตามที่เจ้าของงานสั่ง
          พนักงานทั่วไป: ลบได้เฉพาะ **ของซ้อน** (หมุดซ้อน -> เลือกดวง · node ซ้อน -> เตือนแล้วลบ 1)
          โหมดผู้ดูแล : ลบได้ทั้งหมดเหมือนเดิม (มุมแปลง + หมุดของแปลงนั้น)
        ★ 2.3.6 (เจ้าของงานสั่ง 25 ก.ย. 69) — โหมดผู้ดูแล/ผู้ช่วย: *"ไม่ว่าจะเจอหมุดซ้อนหรือ node ซ้อน ต้องลบทั้งหมด"*
          ⇒ ลบ **ทุกมุมที่ซ้อนกันตรงนั้น** + **หมุดของแปลงนั้นทุกดวงตรงนั้น** ในคำสั่งเดียว (`_delete_node_all`)
        """
        ready = self._tool_ready("ลบ Node")
        if not ready:
            return False
        _chk = self._tool_layers_ok(poly_lyr, "ลบ Node")       # กันสลับคอมโบหลัง arm
        if _chk is None:
            return False
        poly_lyr, point_lyr = _chk
        pf = poly_lyr.getFeature(fid)
        if not pf.isValid():
            return False
        # ★ 2.2.9 — ด่าน L1 ชั้นใน (ไม่พึ่งธงของเครื่องมือฝั่งหน้าจออย่างเดียว)
        #   เจ้าของงานยืนยัน 18 ก.ย.: แตะ L1 ได้ต่อเมื่อ **เปิดโหมดผู้ดูแล และ กดปลดล็อก** เท่านั้น
        if not self._pair_cols_ok(poly_lyr, point_lyr, "ลบ Node"):        # ★ 2.3.7 (review AR-06-D) — ไม่ตกไปทางลบเต็ม
            return False
        _tp = self._poly_type_str(poly_lyr, pf)
        if _tp in L1_TYPES and not self._l1_unlocked():     # ★ 2.4.0 (DU-01) lock_rules
            self.iface.messageBar().pushMessage(
                "ลบ Node", "แปลงนี้เป็น %s (พิกัดอ้างอิง) — %s"
                % (_tp, self._l1_hint("ลบ Node ไม่ได้")),               # ★ 2.3.7 (review UX-13) — ไม่บอกโหมดซ่อน
                level=1, duration=7)                 # ★ 2.3.7 (audit C-02) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            return False
        geom = pf.geometry()
        proj = QgsProject.instance()
        to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj)
                   if poly_lyr.crs() != point_lyr.crs() else None)
        xy_poly = to_poly.transform(snap_xy) if to_poly else QgsPointXY(snap_xy)
        cv = geom.closestVertex(xy_poly)      # (point, vidx, prev, next, sqrDist)
        if cv[1] < 0 or cv[4] is None or cv[4] > 0.0025:      # เกิน 5 ซม.
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ตรงนี้ไม่มีมุมของแปลงที่เลือก (คลิกให้ตรงมุมแปลง)", level=1, duration=6)
            return False
        # ★ 2.2.9 — ด่านสิทธิ์: ชั้นพนักงาน => แตะได้เฉพาะ "ของซ้อน"
        #   ★ 2.3.0 — แบบเต็ม (ลบมุมแปลงจริง) เลื่อนลงมาที่ชั้น **ผู้ช่วยผู้ดูแล**
        #   ★ 2.3.4 — แปลง LandsMaps (L2-LM) ยกเว้นให้: พนักงานลบหมุด/มุมแปลงได้เลย
        # 🔴 แก้ตาม audit 23 ก.ย. 69 — เดิมรวบเป็น `_admin` ตัวเดียว **ผิด**
        #   `_admin` ไม่ได้คุมแค่ "สิทธิ์" แต่คุม **ทางลัดที่ปลอดภัยกว่า** อีก 2 เส้น:
        #     · หมุดซ้อน  -> `_delete_stacked_marker` = ลบเฉพาะหมุด **ไม่แตะรูปแปลง**
        #     · มุมซ้อน   -> `_delete_dup_vertex`     = ลบมุมซ้อน **ไม่แตะหมุด**
        #   พอ L2-LM ทำให้เป็น True ทั้งสองทางถูกข้าม ⇒ คลิกเดิมกลายเป็นลบเต็มรูปแบบ
        #   (วัดได้: หมุดซ้อนบน L2-RO มุม 5->5 · บน L2-LM มุม 5->4 = เนื้อที่เปลี่ยน + node กำพร้า)
        #   ⇒ ทางลัดปลอดภัยต้องเดินก่อนเสมอ สำหรับ **พนักงาน (รวมแปลง L2-LM)** · ผ่อนเฉพาะขั้น "ลบเต็มรูปแบบ" ตอนท้าย
        # ★ 2.4.0 (review DI-14) — แก้คอมเมนต์ให้ตรงโค้ด: เดิมเขียนว่า "ทุกชั้นสิทธิ์" แต่ทางลัดสองเส้นข้างล่างอยู่ใต้ `not _mod`
        #   ⇒ โหมดผู้ช่วยผู้ดูแล/ผู้ดูแล (`_is_mod()` จริงทั้งคู่) **ไม่ได้** เดินทางลัด — มุมที่มีของซ้อนส่งไป `_delete_node_all`
        #   (ลบทั้งหมดที่จุดนี้ ตามคำสั่ง 25 ก.ย.) · พนักงานลบได้เฉพาะ "ของซ้อน" ผ่านทางลัด ยกเว้นแปลง L2-LM
        #   ที่ผ่อนให้ลบเต็มรูปแบบได้ตอนท้าย (หลังทางลัด · `_relax`)   ★ rc1 (F8 · §5.1 DI-14) เดิมเขียนว่า "เท่านั้น" ไม่จริงกับ L2-LM
        #   เจ้าของงานตัดสินคงพฤติกรรมเดิม: "คงเดิม เพราะจะลบได้ต้องกดเปิดโหมด" — ผู้ใช้ต้องตั้งใจเปิดโหมดเองก่อนจึงลบแบบเต็มได้
        _mod = self._is_mod()
        _relax = self._is_landsmaps(poly_lyr, pf)
        _admin = _mod or _relax
        # ★ ต้องนับมุด "เฉพาะวง (ring) ที่คลิก" ไม่ใช่ทั้ง geometry (2026-08-06)
        #   แปลงที่มีรู/multipart: ทั้งก้อนอาจ 10 มุม แต่วงที่คลิกเหลือ 3 -> QGIS จะลบ "ทั้งวง" ทิ้ง
        #   (คืนค่า Success ปกติ) ขณะที่เราลบหมุดแค่ตัวเดียว = รูหาย เนื้อที่เปลี่ยน หมุดกำพร้าค้าง
        # ★ 2.3.7 (review DI-50) — นับได้ก่อนทุกทาง และ **นับไม่ได้ = ไม่ทำ** (fail-closed)
        #   เดิมถอยไปนับ "ทั้งก้อน" (เขียนว่า อนุรักษ์) ซึ่งกลับเป็นทางที่ปลอดภัยน้อยสุด: แปลงมีรู/หลายก้อนได้จำนวนเกินจริง
        #   ⇒ ด่าน "วงเหลือ 3 มุม" ผ่านทั้งที่วงนั้นเหลือ 3 มุม ⇒ QGIS ลบทั้งวง · และ _delete_node_all ใช้ค่าเดียวกันต่อ
        nvtx = None
        _ring = 0                               # ★ 2.4.2 rc6 — วงที่คลิก (0 = วงนอก · >0 = รู)
        try:
            _ok, _vid = geom.vertexIdFromVertexNr(cv[1])
            if _ok:
                nvtx = geom.constGet().vertexCount(_vid.part, _vid.ring)
                _ring = _vid.ring
        except Exception:
            nvtx = None
        if not nvtx:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ตรวจจำนวนมุมของวงนี้ไม่ได้ — ไม่ลบให้", level=2, duration=8)
            return False
        # ★ 2.3.7 (review DI-32 · เจ้าของงานตัดสิน 2 ต.ค.) — ทางลัด "หมุดซ้อน" ของพนักงาน: เฉพาะหมุดของแปลงนี้ที่ห่าง **มุมที่คลิก**
        #   ไม่เกิน 1 มม. ต่อแกน (เกณฑ์เดียวกับไฮไลต์ `_stacked_points`) — เดิมใช้กรอบ ±5 ซม. รอบจุด snap ⇒ หมุดของ **อีกมุม**
        #   ที่ห่าง 1 มม.-5 ซม. ถูกนับเป็นหมุดซ้อน ลบแล้วมุมนั้นเปลือย ทั้งที่กล่องบอก "ยังเหลือหมุดอีก 1 ดวงบนมุมนี้"
        #   (ชั้นส่งงานธัญบุรีมีหมุดคีย์เดียวกันห่างกัน 1 มม.-5 ซม. 285 คู่) · ผู้ช่วย/ผู้ดูแลยังใช้กรอบ ±5 ซม. (ลบทั้งหมดที่จุดนี้ 25 ก.ย.)
        #   🔑 เรียกก่อน `_mks` — `_marker_candidates` ตั้ง `_marker_l1_filtered` ใหม่ทุกครั้ง ด่านหมุด L1 ข้างล่างต้องเห็นค่าของกรอบ ±5 ซม.
        _กอง = []
        if not _mod:
            try:
                _มุม = QgsPointXY(cv[0])
                if to_poly is not None:
                    _มุม = QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), proj).transform(_มุม)
                _กอง = self._marker_candidates(poly_lyr, point_lyr, pf, _มุม, tol=self._DUP_TOL)
            except Exception:
                _กอง = []                       # หาไม่ได้ = ไม่ใช้ทางลัด (ตกไปด่านปกติ)
            if getattr(self, "_marker_lock_scan_failed", False):
                return False                    # ★ 2.4.0 (review DU-01) สแกนล็อกไม่สำเร็จ (แจ้งแล้ว) — ไม่สแกนซ้ำ ไม่ทำอะไร
        _mks = self._marker_candidates(poly_lyr, point_lyr, pf, snap_xy)
        if getattr(self, "_marker_lock_scan_failed", False):
            return False                        # ★ 2.4.0 (review DU-01) เหมือนข้างบน (โหมดผู้ช่วย/ผู้ดูแล)
        _dups = self._dup_vertex_nrs(geom, cv[0])
        if not _mod and len(_กอง) > 1:          # ทางลัดหมุดซ้อน — ปลอดภัยกว่า (ไม่แตะมุมแปลง)
            # หมุดซ้อน -> ให้เลือกดวงที่จะลบ (ไม่แตะมุมแปลง จึงไม่ต้องผ่านด่าน "วงเหลือ 3 มุม")
            return self._delete_stacked_marker(point_lyr, _กอง, poly_lyr=poly_lyr, pf=pf, corner=QgsPointXY(cv[0]))
        # ★ audit รอบ 3 — โหมดผู้ช่วย/ผู้ดูแลตรงมุมที่มีของซ้อน: ส่งต่อให้ _delete_node_all (เก็บกวาดให้เหลือ 1)
        #   เดิมด่านนี้ปฏิเสธก่อน ⇒ ผู้ช่วยลบหมุดซ้อนบนมุมสามเหลี่ยมไม่ได้ ทั้งที่พนักงานทั่วไปลบได้
        if nvtx <= 4 and not (_mod and (len(_mks) > 1 or len(_dups) > 1)):
            # ★ 2.4.2 rc6 (เจ้าของงานสั่ง 21 ต.ค. 69 "ลบหมุดในรูที่จะน้อยกว่าสามหมุด ให้เด้งว่าจะลบรูใช่ไหม")
            #   มุมของ "รู" (วงใน) ที่เหลือ 3 มุม ⇒ ถามลบทั้งรู (`_delete_hole_ring`) แทนการปฏิเสธ · วงนอกยังปฏิเสธเหมือนเดิม
            if _ring > 0:
                return self._delete_hole_ring(poly_lyr, point_lyr, fid, pf, cv, xy_poly, _admin)
            # สามเหลี่ยม (3 มุม + ปิดวง) -> ลบแล้วไม่เป็นรูปปิด
            self.iface.messageBar().pushMessage(
                "ลบ Node", "วงของแปลงตรงนี้เหลือ 3 มุม — ลบอีกไม่ได้ (รูปแปลงจะไม่สมบูรณ์)",
                level=1, duration=8)                 # ★ 2.3.7 (audit C-02) ปฏิเสธ ⇒ เหลือง
            return False
        if not _mod:
            if len(_dups) > 1:                  # ทางลัดมุมซ้อน — ปลอดภัยกว่า (ไม่แตะหมุด) · เฉพาะนอกโหมดผู้ช่วย/ผู้ดูแล
                # ★ 2.4.0 (review DI-14) — เดิมคอมเมนต์เขียน "ใช้ได้ทุกชั้นสิทธิ์" ไม่ตรงโค้ด: อยู่ใต้ `not _mod`
                #   ⇒ โหมดผู้ช่วย/ผู้ดูแลไปทาง `_delete_node_all` แทน (เจ้าของงานตัดสินคงเดิม — ลบเต็มต้องตั้งใจเปิดโหมด)
                # ★ รอบ 9d (ฌ) — ตรวจกติกา 1 มม. · ★ 2.3.7 (review DI-31) — มุมที่คลิก (ติดกันในวง) + L2-LM ลบได้แต่บอกเนื้อที่จริง
                return self._delete_dup_vertex(poly_lyr, fid, _dups, point_lyr, clicked=cv[1], relax=_relax)
        # ★★ 2.3.5 รอบ 2 — ถ้ามีหมุด L1 ถูกกรองออกตรงจุดนี้ **ต้องปฏิเสธทั้งการกระทำ** (ผู้ตรวจ Windows ข้อ 4.1)
        #   ไม่งั้นจะลบมุมแปลงไปแล้วหมุดค้าง = หมุดกำพร้า · และกล่องยืนยันจะเขียนว่า
        #   "หมุดที่จะลบด้วย: ไม่มี" ซึ่งอ่านแล้วเหมือนกรณีปกติ ⇒ ผู้ใช้ไม่รู้ว่ากำลังจะทำอะไรผิด
        # ★ 2.3.6 — ย้ายด่านนี้ลงมา **หลัง** ทางลัดสองเส้นข้างบน (ผู้ตรวจ Windows รอบ 2 ข้อ 5)
        #   ทางลัดหมุดซ้อน (ไม่แตะรูป · หมุดที่เหลือถูกกรอง L1 ออกแล้ว) และทางลัดมุมซ้อน (ไม่แตะหมุดเลย)
        #   ไม่มีทางทำหมุดกำพร้า ⇒ ไม่ควรถูกปฏิเสธ · ด่านนี้คุมเฉพาะขั้น "ลบมุม + หมุด พร้อมกัน" เท่านั้น
        #   (มุมที่มีแต่หมุด L1: `_mks` ว่าง + `_dups` = 1 ⇒ ทางลัดไม่ทำงาน ⇒ ตกมาโดนด่านนี้พอดี)
        if getattr(self, "_marker_l1_filtered", 0):
            self.iface.messageBar().pushMessage(
                "ลบ Node",
                "ตรงนี้มีหมุดของแปลง L1 (พิกัดอ้างอิง) อยู่ %d ดวง — %s"
                % (self._marker_l1_filtered, self._l1_hint("ลบไม่ได้")), level=1, duration=9)   # ★ 2.3.7 UX-13 · C-02 เหลือง
            return False
        if not _admin:
            self.iface.messageBar().pushMessage(
                "ลบ Node",
                "ตรงนี้ไม่มีของซ้อน — ลบได้เฉพาะ 'หมุดซ้อน' หรือ 'node ซ้อน' เท่านั้น "
                "(ลบมุมแปลงจริงต้องให้ผู้ช่วยผู้ดูแล/ผู้ดูแลลบให้)",      # ★ 2.3.7 (review UX-13) — ไม่บอกโหมดซ่อน/วิธีเข้า
                level=1, duration=9)
            return False
        # ★ 2.3.6 (เจ้าของงานสั่ง 25 ก.ย. 69) — โหมดผู้ดูแล/ผู้ช่วย: เจอหมุดซ้อนหรือ node ซ้อน **ลบทั้งหมด**
        #   เดิมลบมุม 1 มุม + หมุด 1 ดวง ⇒ มุมซ้อนอีกตัวยังอยู่ (รูปไม่เปลี่ยน) แต่หมุดหาย = มุมเปลือย
        #   หรือหมุดซ้อนอีกดวงค้าง = หมุดกำพร้า (audit 25 ก.ย. เจอทั้งสองแบบ)
        # ★ rc2 (audit A2-01) — พนักงานบนแปลง L2-LM (`_relax`) ไปทางเดียวกับผู้ช่วย/ผู้ดูแล (`_delete_node_all`)
        #   เดิมทางนี้หาหมุดด้วย `_admin_find_marker(snap_xy)` (หมุดของแปลงนี้ที่ใกล้จุดคลิกที่สุดในกรอบ ±5 ซม.)
        #   ไม่ดูว่าหมุดเป็นของมุมไหน และไม่ดูแปลงแฝด (UTM เดียวกัน) ⇒ คลิกมุมเปลือยข้างมุมที่มีหมุด (ห่าง 3 ซม.) ลบหมุดของมุมข้าง ๆ
        #   · ลบมุมร่วมของแปลงแฝดแล้วหมุดดวงเดียวที่แฝดยังใช้หายไปด้วย ⇒ มุมเปลือยเงียบ ๆ · ไม่มีบรรทัดเตือนกติกา 1 มม.
        #   `_delete_node_all` มีครบ: เลือกหมุดตามมุมที่ลบ · เก็บหมุดที่แฝดยังใช้ · `_delnode_iron_after` · เนื้อที่ก่อน/หลัง
        #   ทางลัดของซ้อน (ไม่แตะรูป/ไม่แตะหมุด) ด้านบนยังเดินก่อนสำหรับพนักงานเหมือนเดิม
        return self._delete_node_all(poly_lyr, point_lyr, fid, pf, cv, xy_poly, _mks, _dups, nvtx, hole=_ring > 0)

    def _delnode_iron_after(self, poly_lyr, point_lyr, pf, g0, g_after, แฝด, จุดแตะ, ids):
        """★ รอบ 9d (ฌ · ผู้ตรวจรอบ 9b B ข้อ 2-3) — ลบ Node "ลบทั้งหมดที่จุดนี้" เก็บมุมเลขน้อยสุดของกองเสมอ และเลือกหมุด
        ที่เก็บจากระยะถึงมุมที่เหลือมุมเดียว ⇒ บางผัง (มุมเกือบซ้อนที่หมุดอยู่บนมุมที่ถูกลบ · มุมของอีกก้อน/รู/แปลงแฝดห่าง
        ไม่ถึง 1 มม.) ผลออกมาผิดกติกาเหล็ก 1 มม. โดยไม่มีคำเตือน (มีมาก่อนรอบ 9 · การเลือกตามความครอบคลุมเลื่อนไปรุ่นหน้า)
        ⇒ จำลองสภาพหลังลบ (อ่านอย่างเดียว) เทียบก่อน/หลัง: มุมที่ไม่มีหมุดของแปลง ≤ 1 มม. ที่เกิดใหม่ · หมุดที่ไม่อยู่บนมุม
        ≤ 1 มม. ที่เกิดใหม่ ⇒ คืนบรรทัดเตือนให้กล่องยืนยัน ("" = ไม่มีอะไรแย่ลง)
        ขอบเขต = กรอบของจุดที่แตะ (มุมที่ลบ + หมุดที่ลบ + มุมที่คลิก) ขยาย 1 ซม. · มุมของแปลงนี้ + แปลงที่ใช้ UTM เดียวกัน ·
        หมุด UTM เดียวกัน (รวมหมุด L1 ที่ไม่ถูกแตะ) · ของที่ขอบกรอบสถานะไม่เปลี่ยน ⇒ หักล้างกันเองในการเทียบ
        ตรวจไม่ได้ ⇒ บรรทัดบอกให้ตรวจเอง (ไม่เงียบ)"""
        TOL_V, PAD = 0.001, 0.01
        try:
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if not pu or not tu or not จุดแตะ:
                return ""
            utm = _norm_utm(pf[pu])
            if utm.startswith("\x00"):
                return ""                   # คีย์ว่าง = ไม่มีหมุดของแปลงนี้ให้นับ (ปุ่มนี้ไม่ลบหมุดคีย์ว่างอยู่แล้ว)
            _ต่าง = point_lyr.crs() != poly_lyr.crs()
            to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance()) if _ต่าง else None)
            to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), QgsProject.instance()) if _ต่าง else None)
            x0 = min(p.x() for p in จุดแตะ) - PAD
            x1 = max(p.x() for p in จุดแตะ) + PAD
            y0 = min(p.y() for p in จุดแตะ) - PAD
            y1 = max(p.y() for p in จุดแตะ) + PAD
            r_poly = QgsRectangle(x0, y0, x1, y1)
            r_pt = to_pt.transformBoundingBox(r_poly) if to_pt else r_poly

            def ใน(v):
                return x0 <= v.x() <= x1 and y0 <= v.y() <= y1
            หมุด = []
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r_pt))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or _norm_utm(f[tu]) != utm:
                        continue
                    p = g.asPoint()
                    หมุด.append((f.id(), to_poly.transform(p) if to_poly else QgsPointXY(p)))
            finally:
                _it.close()
            แฝด_ใน = [QgsPointXY(v) for v in แฝด if ใน(v)]
            V0 = [QgsPointXY(v.x(), v.y()) for v in g0.vertices() if ใน(v)] + แฝด_ใน
            V1 = [QgsPointXY(v.x(), v.y()) for v in g_after.vertices() if ใน(v)] + แฝด_ใน
            _ลบ = set(ids)
            M1 = [(i, m) for i, m in หมุด if i not in _ลบ]

            def เปลือย(V, M):
                out = []
                for v in V:
                    if not any(v.distance(m) <= TOL_V for _i, m in M) and not any(v.distance(o) <= 1e-6 for o in out):
                        out.append(v)
                return out

            def หลุด(M, V):
                return {i for i, m in M if not any(m.distance(v) <= TOL_V for v in V)}
            เดิมเปลือย = เปลือย(V0, หมุด)
            ใหม่เปลือย = [v for v in เปลือย(V1, M1) if not any(v.distance(o) <= 1e-6 for o in เดิมเปลือย)]
            ใหม่หลุด = sorted(หลุด(M1, V1) - หลุด(หมุด, V0))
            if not ใหม่เปลือย and not ใหม่หลุด:
                return ""
            ส่วน = []
            if ใหม่เปลือย:
                ส่วน.append(f"มุมที่ไม่มีหมุดของแปลงภายใน 1 มม. เพิ่ม {len(ใหม่เปลือย):,} มุม")
            if ใหม่หลุด:
                ส่วน.append(f"หมุดที่ไม่อยู่บนมุมภายใน 1 มม. เพิ่ม {len(ใหม่หลุด):,} ดวง (gid "
                            + ", ".join(str(i) for i in ใหม่หลุด[:6]) + (" …" if len(ใหม่หลุด) > 6 else "") + ")")
            return ("\n⚠️ หลังลบ: " + " · ".join(ส่วน)
                    + " — ผิดกติกาหมุด 1 มม. (มุมซ้อน/มุมของอีกวงหรือแปลงแฝดอยู่ชิดกัน) ตรวจ/แก้เองหลังลบ · ↺ ย้อนได้")
        except Exception as e:
            QgsMessageLog.logMessage("_delnode_iron_after: ตรวจไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            return "\n⚠️ ตรวจกติกาหมุด 1 มม. หลังลบไม่ได้ — ตรวจเองหลังลบ"

    @staticmethod
    def _mk_dates(f):
        """★ 2.3.7 (b12) — (SURV_DATE, ISSUE_DATE) ของหมุด f เป็น datetime/None · ชั้นที่ไม่มีคอลัมน์ ⇒ None (= ไม่มีวันที่)"""
        out = []
        for col in _DATE_COLS:
            try:
                i = _fld_idx(f.fields(), col)
                out.append(_date_val(f.attribute(i)) if i >= 0 else None)
            except Exception:
                out.append(None)
        return tuple(out)

    def _name_cand(self, f, nm, note="", dates=None, fid=None):
        """★ 2.3.7 (b12) — ผู้สมัครชื่อ 1 ดวงสำหรับ _newest_name/_name_choice: dict(nm, fid, s, i, d, note)
        d = วันที่ของหมุด = ค่าที่ใหม่กว่าระหว่าง SURV_DATE กับ ISSUE_DATE (ไม่มีทั้งคู่ = None)
        dates = (SURV_DATE, ISSUE_DATE) ที่อ่านไว้แล้ว (ไม่ต้องมีตัวฟีเจอร์) · ไม่ส่ง ⇒ อ่านจาก f"""
        s, i = dates if dates is not None else (self._mk_dates(f) if f is not None else (None, None))
        มี = [x for x in (s, i) if x is not None]
        return dict(nm=_txt(nm), fid=(fid if fid is not None else (f.id() if f is not None else None)), s=s, i=i,
                    d=(max(มี) if มี else None), note=note)

    def _name_choice(self, ผู้สมัคร, ตั้งต้น, title, label, เสมอ=False):
        """★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค.) — เลือก "ชื่อเดียว" ที่จะเก็บไว้ จากหมุดซ้อนที่ชื่อต่างกัน
        ผู้สมัคร = [_name_cand(...)] (ดวงที่ไม่มีชื่อไม่นับ) · คืนชื่อที่เลือก · None = ผู้ใช้กด Cancel (ผู้เรียกต้องยกเลิกทั้งงาน)
          · ชื่อเดียว (ชร ทุกแบบนับเป็นชื่อเดียวกัน) ⇒ คืนชื่อนั้น ไม่ถาม
          · เสมอ=False (🍩) ⇒ วันที่ใหม่สุดตัดสิน · ตัดสินไม่ได้ (ไม่มีวันที่ · วันที่เท่ากันแต่ชื่อต่าง) ⇒ ถาม
          · เสมอ=True (ลบ Node เก็บกวาดหมุดซ้อน) ⇒ ถามทุกครั้ง
        popup = QInputDialog.getItem (ฮาร์เนสทดสอบดักได้) · 1 บรรทัดต่อหมุด: ชื่อ · SURV_DATE · ISSUE_DATE ('-' = ว่าง) · gid
        เลือกไว้ให้ก่อน = ชื่อของวันที่ใหม่สุด · ไม่มีวันที่/เท่ากัน ⇒ ตั้งต้น (กติกาเดิมของผู้เรียก)"""
        ผู้สมัคร = [c for c in ผู้สมัคร if _txt(c.get("nm"))]
        if not ผู้สมัคร:
            return _txt(ตั้งต้น)
        if len({_name_key(c["nm"]) for c in ผู้สมัคร}) <= 1:
            return ผู้สมัคร[0]["nm"]
        ชนะ = _newest_name(ผู้สมัคร)
        if ชนะ is not None and not เสมอ:
            return ชนะ
        เลือกก่อน = ชนะ if ชนะ is not None else _txt(ตั้งต้น)
        # เรียงรายการ: วันที่ใหม่ก่อน (ไม่มีวันที่ไว้ท้าย) แล้วตามลำดับที่ผู้เรียกส่งมา (sort คงลำดับเดิมของค่าที่เท่ากัน)
        #   (ไม่ใช้ datetime.timestamp() — วันที่ก่อน 1970 บน Windows โยน OSError)
        import datetime as _dt
        ลำดับ = list(range(len(ผู้สมัคร)))
        ลำดับ.sort(key=lambda k: ผู้สมัคร[k]["d"] or _dt.datetime.min, reverse=True)
        items, ชื่อของ = [], {}
        for k in ลำดับ:
            c = ผู้สมัคร[k]
            t = (f"{c['nm']}   ·   SURV_DATE {_date_txt(c['s'])}   ·   ISSUE_DATE {_date_txt(c['i'])}"
                 + (f"   ·   gid {c['fid']}" if c.get("fid") is not None else "") + (c.get("note") or ""))
            while t in ชื่อของ:                      # กันข้อความซ้ำ (getItem คืนเป็นข้อความ)
                t += " "
            items.append(t)
            ชื่อของ[t] = c["nm"]
        cur = next((k for k, t in enumerate(items) if _name_key(ชื่อของ[t]) == _name_key(เลือกก่อน)), 0)
        try:
            parent = self.iface.mainWindow()
        except Exception:
            parent = None
        t, ok = QtWidgets.QInputDialog.getItem(parent, title, label, items, cur, False)
        if not ok:
            return None
        if t in ชื่อของ:
            return ชื่อของ[t]
        t = _txt(t)
        return next((c["nm"] for c in ผู้สมัคร if c["nm"] == t), None)     # คืนชื่อตรง ๆ ก็รับ · อย่างอื่น = ยกเลิก

    def _delete_node_all(self, poly_lyr, point_lyr, fid, pf, cv, xy_poly, mks, dups, nvtx, hole=False):
        """★ 2.3.6 — โหมดผู้ดูแล/ผู้ช่วย (เจ้าของงานสั่ง 25 ก.ย.): ลบมุมแปลงตรงนี้ **ทุกตัวที่ซ้อนกัน (วงเดียวกัน)**
        + หมุดของแปลงนี้ **ทุกดวง** ตรงนี้ · ทั้งหมดหรือไม่ทำเลย · ↺ Undo ครั้งเดียวคืนทั้งหมด
        ★ audit รอบ 2 (เขียนใหม่):
          · หมุดที่จะลบ = หมุดของแปลงนี้ในกรอบ ±5 ซม. **ยกเว้น** ดวงที่ยังเป็นหมุดของมุมที่เหลืออยู่
            ทั้งมุมอื่นของแปลงนี้ (มุมห่าง 3 มม./4 ซม. · อีกก้อน/รูที่แตะจุดเดียวกัน) และของแปลงแฝด (UTM เดียวกัน)
            (รุ่นแรกลบหมุดทั้งกรอบ ⇒ มุมข้างเคียงที่ยังอยู่กลายเป็นมุมเปลือย)
          · ลบทุกตัวที่ซ้อนแล้ววงเหลือไม่ถึง 3 มุม ⇒ ลบแค่ส่วนที่ซ้อน ให้เหลือมุม 1 + หมุด 1 (แบบ 2.3.5)
          · กล่องยืนยันบอกเนื้อที่ก่อน → หลัง (จุดที่เส้นขอบวนผ่านสองรอบ ลบแล้วเนื้อที่เปลี่ยนมาก)
          · หาแปลงแฝดไม่ได้ ⇒ ไม่ทำ (fail-closed)
        ★ audit รอบ 3:
          · หมุดแต่ละดวงเป็นของ "มุมที่ใกล้ที่สุด" — ลบเฉพาะดวงที่ใกล้มุมที่ถูกลบมากกว่ามุมที่ยังอยู่
            (เดิมเก็บเฉพาะดวงที่ห่างมุมที่เหลือ ≤ 1 มม. ⇒ หมุดของมุมข้างเคียงที่เยื้อง 2 มม. ถูกลบ มุมนั้นเปลือย)
          · เหลือหมุด 1 ดวง: ชื่อจริงก่อน ชร · มีชื่อก่อนไม่มีชื่อ (เดิมหมุดไม่มีชื่อชนะเพราะเลข gid น้อยกว่า)
          · มุมของวง 3 มุมที่มีหมุดซ้อน: มุมลบไม่ได้ แต่เก็บกวาดหมุดให้เหลือ 1 ดวงได้
            (เดิมถูกปฏิเสธ ทั้งที่พนักงานทั่วไปลบหมุดซ้อนตรงนั้นได้)
        ★ audit รอบ 4 (30 ก.ย.) — เก็บกวาดเหลือหมุด 1 ดวงแล้ว **ชื่อของดวงที่ลบหายเงียบ ๆ** (ผู้ตรวจ: ชร 0 มม. + ชื่อจริง 3 มม.
          ⇒ เหลือ ชร ชื่อจริงหาย · ชื่อจริง 2 ดวงซ้อน ⇒ ดวงหนึ่งหาย พร้อม ALT_NAME ของมัน)
          ⇒ ตามกติกาหมุดซ้อน 7 ก.ย. (stack_dedup_db): ชื่อ + ALT_NAME ของดวงที่ลบ ต่อท้าย ALT_NAME ของดวงที่เก็บ คั่น " | "
            (ไม่ซ้ำ · ไม่ซ้ำกับชื่อของดวงที่เก็บ) ในคำสั่งแก้เดียวกัน = ทั้งหมดหรือไม่ทำเลย · Undo ครั้งเดียวคืนครบ
          · ดวงที่เก็บยังเป็นแบบเดิม: ห่าง ≤ 1 มม. ก่อน แล้วชื่อจริงก่อน ชร (ชื่อจริงที่ห่างเกิน 1 มม. ไม่แย่งที่ ชร ที่ทับมุมพอดี
            — เก็บดวงที่ทับมุม แล้วยกชื่อจริงไป ALT_NAME)
          · บัญชีที่แก้ ALT_NAME ไม่ได้ (ฐานบอกชัดว่าไม่มีสิทธิ์) / ชั้นไม่มีคอลัมน์ ALT_NAME ⇒ กล่องยืนยันบอกชื่อที่จะหายก่อนให้ตัดสิน
        ★ รอบ 9d (ผู้ตรวจรอบ 9b):
          (ช) สลับเก็บดวงที่ถือประวัติ (บัญชีแก้ ALT_NAME ไม่ได้): ห้ามสลับถ้าดวงแรกเป็นหมุดเดียวที่ครอบมุมอื่น (อีกก้อน/รู/แปลงแฝด)
              ≤ 1 มม. ที่ดวงใหม่ครอบไม่ถึง · กองที่ไม่มีดวงไหนอยู่บนมุม ⇒ สลับได้เมื่อดวงใหม่ไม่ไกลกว่าดวงแรก · ดวงแรกเป็น ชร
              ก็สลับได้ (ตั้งชื่อดวงที่เก็บตามดวงแรกเสมอ ⇒ ชร คงเป็นชื่อหลัก ประวัติไม่หาย)
          (ซ) ALT_NAME ที่จำกัดความยาว: ใส่ทีละชื่อเท่าที่ลง · ที่เหลือขึ้นคำเตือน "จะหาย" พร้อมเหตุความยาว (เดิมตัดกลางชื่อ)
          (ฌ) จำลองสภาพหลังลบรอบจุดนี้ ⇒ มุมเปลือย/หมุดหลุดมุมที่เกิดใหม่ (กติกา 1 มม.) ขึ้นบรรทัด "⚠️ หลังลบ" ในกล่องยืนยัน
        ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค. 69) — ปลั๊กอินเลิกเขียน ALT_NAME ⇒ ข้อ audit รอบ 4 / (ช) / (ซ) ที่ว่าด้วยการยกชื่อ
          ไป ALT_NAME เลิกใช้: กองที่เหลือหมุด 1 ดวงเก็บได้ "ชื่อเดียว" · ชื่อต่างกัน ⇒ popup ให้เลือกทุกครั้ง (ชื่อ + SURV_DATE +
          ISSUE_DATE · เลือกไว้ให้ก่อน = วันที่ใหม่สุด / ไม่มีวันที่ = กติกาเดิม) · ดวงที่ถือชื่อที่เลือกอยู่บนมุมได้ ⇒ เก็บดวงนั้น
          (ด่านระยะ + ครอบมุมเดิมของ (ช)) ไม่งั้นเปลี่ยนชื่อดวงแรก · ชื่อที่ไม่ได้เลือก (รวม ชร) + ALT_NAME ของดวงที่ลบ ⇒ กล่องบอกก่อน
          · Cancel ใน popup = ไม่ทำอะไรเลย
        ★ 2.4.2 rc6 (hole=True · มุมที่คลิกอยู่บนรู) — ลบแล้วรูเหลือไม่ถึง 3 มุม ⇒ ถามลบทั้งรู (`_delete_hole_ring`) แทนการปฏิเสธ ·
          รู 3 มุมที่มีหมุดซ้อน ⇒ เก็บกวาดหมุดซ้อนแบบเดิม + บอกในกล่องว่าลบทั้งรูได้ด้วยการคลิกอีกครั้ง · ไม่มีหมุดซ้อนให้เก็บกวาด
          (เช่นรูเล็กกว่า 5 ซม. ที่หมุดของมุมอื่นของรูเข้ากรอบ) ⇒ ถามลบทั้งรู"""
        TOL_V = 0.001
        g0 = QgsGeometry(pf.geometry())
        จุด = QgsPointXY(cv[0])
        vs = sorted(set(dups if len(dups) > 1 else [cv[1]]), reverse=True)     # ลบจากเลขมากไปน้อย
        เหลือซ้อน = False
        if nvtx - len(vs) < 4:
            if len(vs) > 1:
                vs = vs[:-1]                   # เก็บตัวเลขน้อยสุดไว้ 1 ตัว (ปลอดภัยกับจุดปิดวง)
                เหลือซ้อน = True
            elif len(mks) > 1:
                vs = []                        # ★ audit รอบ 3 — มุมลบไม่ได้ แต่หมุดซ้อนเก็บกวาดได้
                เหลือซ้อน = True
            if nvtx - len(vs) < 4:
                if hole:                       # ★ 2.4.2 rc6 — รู ⇒ ถามลบทั้งรู (มาถึงตรงนี้ = ผู้ช่วย/ผู้ดูแล/L2-LM แล้ว)
                    return self._delete_hole_ring(poly_lyr, point_lyr, fid, pf, cv, xy_poly, True)
                self.iface.messageBar().pushMessage(
                    "ลบ Node", "ลบแล้ววงของแปลงตรงนี้จะเหลือไม่ถึง 3 มุม — ลบไม่ได้", level=1, duration=8)  # ★ C-02
                return False
        # ★ รอบ 9b (ผู้ตรวจ B) — มุมซ้อนที่ห่างกันไม่ถึง 1 มม. (ไม่ทับกันเป๊ะ): มุมที่ "เหลืออยู่" คือเลขน้อยสุดในกอง ไม่ใช่มุมที่คลิก
        #   เดิมวัดถังหมุด ≤ 1 มม. จากมุมที่คลิก (ซึ่งอาจเป็นมุมที่ถูกลบ) ⇒ เก็บหมุดที่ห่างมุมที่เหลือ 1.4 มม. แล้วลบดวงที่ทับมุมพอดี
        #   = มุมเปลือย + หมุดไม่อยู่บนมุม โดยไม่มีคำเตือน ⇒ วัดจากมุมที่เหลือจริง
        มุมเก็บ = จุด
        if เหลือซ้อน and vs:
            _คง = sorted(set(dups) - set(vs))
            if _คง:
                try:
                    มุมเก็บ = QgsPointXY(g0.vertexAt(_คง[0]))
                except Exception:
                    มุมเก็บ = จุด
        ที่ลบ = []
        for nr in vs:
            try:
                ที่ลบ.append(QgsPointXY(g0.vertexAt(nr)))
            except Exception:
                ที่ลบ.append(QgsPointXY(จุด))
        g_after = QgsGeometry(g0)
        for nr in vs:
            if not g_after.deleteVertex(nr):
                self.iface.messageBar().pushMessage("ลบ Node", "คำนวณรูปหลังลบไม่ได้ — ไม่ทำ", level=2, duration=8)
                return False
        if g_after.isEmpty() or g_after.area() <= 0:
            # ★ 2.3.7 (audit C-02) — ปฏิเสธก่อนแตะชั้น ⇒ เหลือง · ข้อความนักพัฒนา (ต้นเหตุแปลง geom=NULL) ไปอยู่ใน Log ไม่ใช่แถบของพนักงาน
            QgsMessageLog.logMessage("ลบ Node: ไม่ทำ — ลบแล้วแปลง fid %s จะไม่เหลือรูป (กันต้นเหตุแปลง geom=NULL)" % fid,
                                     "MLEP", Qgis.Info)
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ลบแล้วแปลงจะไม่เหลือรูป — ไม่ทำ", level=1, duration=8)
            return False
        เหลือ = [QgsPointXY(v.x(), v.y()) for v in g_after.vertices()]
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        แฝด = []
        _raw = _txt(pf[pu]) if pu else ""
        if _raw:
            # ★ 2.3.7 (review DI-01 · ให้ตรงกับ 🍩 ข้อ 10 d) — แปลงแฝด = UTM เดียวกัน "หลัง normalise" (_utm_twin_fids)
            #   เดิมนิพจน์ = str(pf[pu]) ตรงทุกตัวอักษร ⇒ NULL แบบมีชนิดกลายเป็น 'NULL' · 'X ' ไม่นับเป็นแฝดของ 'X'
            #   ⇒ มุมของแปลงแฝดไม่ถูกนับ ⇒ หมุดที่แปลงแฝดใช้อยู่ถูกนับเป็นของมุมที่ลบ · คีย์ว่าง = ไม่มีแฝด (หมุดจับคู่ไม่ได้อยู่แล้ว)
            #   หาแล้วไม่เจอแปลงนี้เอง = ถามชั้นไม่สำเร็จ ⇒ ไม่ทำ (fail-closed แบบ _parcel_markers)
            try:
                _all = self._utm_twin_fids(poly_lyr, pu, _raw, _norm_utm(_raw))
                if fid not in _all:
                    raise RuntimeError("หาแปลงที่ใช้ UTM เดียวกันแล้วไม่เจอแปลงนี้เอง (fid %s)" % fid)
                _tw = [t for t in _all if t != fid]
                _it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(_tw)) if _tw else None
                try:
                    for f in (_it if _it is not None else []):
                        g = f.geometry()
                        if g is not None and not g.isEmpty():
                            แฝด.extend(QgsPointXY(v.x(), v.y()) for v in g.vertices())
                finally:
                    if _it is not None:
                        _it.close()
            except Exception:
                _log_exc("_delete_node_all: ตรวจแปลงที่ใช้ UTM เดียวกันไม่ได้ — ไม่ลบ")           # ★ 2.3.7 (ER-03)
                self.iface.messageBar().pushMessage(
                    "ลบ Node", "ตรวจแปลงที่ใช้ UTM เดียวกันไม่ได้ — ไม่ทำ (กันลบหมุดของแปลงอื่น)", level=2, duration=8)
                return False
        to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), QgsProject.instance())
                   if poly_lyr.crs() != point_lyr.crs() else None)

        def _xy(c):
            p = c['feature'].geometry().asPoint()
            return to_poly.transform(p) if to_poly else QgsPointXY(p)

        def ห่าง(p, pts):
            return min((p.distance(q) for q in pts), default=float("inf"))
        คงไว้ = None
        ชื่อใหม่ = None                                      # ★ รอบ 5 — ชื่อที่ตั้งให้ดวงที่เก็บ (None = ไม่เปลี่ยน)
        # ★ 2.3.7 (b12 · เจ้าของงานตัดสิน 3 ต.ค. 69) — ปลั๊กอินเลิกเขียน ALT_NAME (สงวนไว้ให้ชื่อที่ pipeline เก็บตอนตัดหมุดซ้ำ)
        #   เดิม (audit รอบ 4 – รอบ 9e) ยกชื่อของดวงที่ลบไปต่อท้าย ALT_NAME ของดวงที่เก็บ + สลับเก็บดวงที่ถือ ALT ตามสิทธิ์ ALT_NAME
        #   ⇒ ตอนนี้: กองนี้เหลือชื่อได้ "ชื่อเดียว" · ชื่อต่างกัน ⇒ popup ให้เลือกทุกครั้ง (ชื่อ + SURV_DATE + ISSUE_DATE)
        #   ชื่อที่ไม่ได้เลือกหาย — กล่องยืนยันบอกทุกชื่อก่อน (รวม ชร) · ALT_NAME ของดวงที่ลบหายไปกับดวงนั้น (บอกเช่นกัน)
        ชื่อหาย = []                                        # ชื่อหลักของดวงที่ลบที่ไม่ได้เลือก (ไม่ซ้ำ · ชร ทุกแบบ = ชื่อเดียว)
        ชื่อเดิมหาย = ""                                     # ชื่อเดิมของดวงที่เก็บ เมื่อถูกเปลี่ยนเป็นชื่อที่เลือก
        ประวัติหาย = []                                      # ALT_NAME ของดวงที่ลบ (อ่านอย่างเดียว)
        เหตุชื่อ = ""                                        # วงเล็บท้ายบรรทัดเปลี่ยนชื่อในกล่องยืนยัน
        แก้ชื่อไม่ได้ = ""                                   # ชื่อที่เลือกแต่ตั้งให้ไม่ได้ (บัญชีแก้ BND_NAME ไม่ได้)
        _เลือกเก็บดวง = False                                # เก็บดวงที่ถือชื่อที่เลือกไว้แทน (ไม่ต้องเปลี่ยนชื่อ)
        if เหลือซ้อน:
            # เหลือมุม 1 ⇒ หมุดที่ "เป็นของมุมนี้" (ใกล้มุมนี้กว่ามุมอื่น/มุมของแปลงแฝด) เก็บไว้ดวงเดียว:
            #   ห่าง ≤ 1 มม. ก่อน · ชื่อจริงก่อน ชร · มีชื่อก่อนไม่มีชื่อ · ใกล้กว่าก่อน · gid น้อยก่อน
            อื่น = [q for q in เหลือ if q.distance(มุมเก็บ) > TOL_V] + แฝด
            # ★ รอบ 9 (1 ต.ค. ตรวจเอกสารส่งต่อ) — เดิมคีย์เป็น (ชร, ไม่มีชื่อ) ⇒ ดวงไม่มีชื่อชนะ ชร ทั้งที่กติกาหมุดซ้อน
            #   7 ก.ย. (`_named` ใน stack_dedup_db) นับ ชร เป็น "มีชื่อ" · ตอนนี้ ชื่อจริง → ชร → ไม่มีชื่อ
            กอง = sorted([c for c in mks if _xy(c).distance(มุมเก็บ) < ห่าง(_xy(c), อื่น)],
                         key=lambda c: (_xy(c).distance(มุมเก็บ) > TOL_V, not c.get('nm'), _is_chor(c.get('nm')),
                                        _xy(c).distance(มุมเก็บ), c['id']))
            if len(กอง) > 1:
                _nf = self._addnode_name_field(point_lyr)
                _k0 = กอง[0]
                # ① ชื่อตั้งต้น = กติกาเดิม (★ รอบ 5/9): ดวงที่เก็บชื่อ ชร/ว่าง แต่ดวงที่ลบมีชื่อจริง ⇒ ชื่อจริงที่ใกล้มุมสุด
                #   ดวงที่เก็บไม่มีชื่อ + ดวงที่ลบมีแต่ ชร ⇒ ชร (มีชื่อก่อนไม่มีชื่อ)
                ตั้งต้น = _k0.get('nm') or ""
                if not ตั้งต้น or _is_chor(ตั้งต้น):
                    _จริง = [c for c in กอง[1:] if c.get('nm') and not _is_chor(c.get('nm'))]
                    if not _จริง and not ตั้งต้น:
                        _จริง = [c for c in กอง[1:] if _is_chor(c.get('nm'))]
                    if _จริง:
                        ตั้งต้น = min(_จริง, key=lambda c: (_xy(c).distance(มุมเก็บ), c['id'])).get('nm')
                        เหตุชื่อ = "(ชื่อจริงก่อน ชร)" if _is_chor(_k0.get('nm')) else "(มีชื่อก่อนไม่มีชื่อ)"
                # ② ชื่อต่างกัน ⇒ ให้เลือกทุกครั้ง · ตั้งไว้ให้ก่อน = วันที่ใหม่สุด (ไม่มีวันที่ = ①) · Cancel = ไม่ทำอะไรเลย
                ชื่อเลือก = ตั้งต้น
                ผู้สมัคร = [self._name_cand(c['feature'], c.get('nm'),
                                            "   ·   ห่างมุม %.1f มม." % (_xy(c).distance(มุมเก็บ) * 1000))
                            for c in กอง if c.get('nm')]
                if _nf is not None and len({_name_key(c['nm']) for c in ผู้สมัคร}) > 1:
                    _r = self._name_choice(
                        ผู้สมัคร, ตั้งต้น, "ลบ Node — เลือกชื่อหมุดที่จะเก็บไว้",
                        f"มุมนี้มีหมุดของแปลงนี้ซ้อนกัน {len(กอง)} ดวง และชื่อไม่ตรงกัน\n"
                        "เก็บหมุดไว้ 1 ดวง ⇒ เลือกชื่อที่จะเก็บไว้ (ชื่ออื่นหายไปกับหมุดที่ลบ — กล่องถัดไปบอกอีกครั้ง)\n"
                        "เลือกไว้ให้ก่อน = วันที่ (SURV_DATE / ISSUE_DATE) ใหม่สุด · ไม่มีวันที่ = ชื่อจริงก่อน ชร\n"
                        "Cancel = ยกเลิก ไม่ลบอะไร", เสมอ=True)
                    if _r is None:
                        return False                     # กด Cancel ใน popup = ยกเลิกทั้งงาน (ยังไม่ได้แตะอะไร)
                    ชื่อเลือก = _r
                    เหตุชื่อ = "(ชื่อที่เลือก)"
                # ③ ดวงที่ถือชื่อที่เลือกอยู่บนมุมได้ ⇒ เก็บดวงนั้นเลย (วันที่/ประวัติของชื่อนั้นอยู่ครบ · ไม่ต้องเปลี่ยนชื่อ)
                #   ใช้ด่านเดียวกับการสลับเดิม: ดวงแรกบนมุม ≤ 1 มม. ⇒ ดวงใหม่ต้อง ≤ 1 มม. · ดวงแรกไม่อยู่บนมุม ⇒ ไม่ไกลกว่า
                #   (★ รอบ 9d ช) · ดวงแรกอยู่บนมุมอื่นที่ยังอยู่ ⇒ ดวงใหม่ต้องอยู่บนมุมที่ยังอยู่ด้วย (★ รอบ 9e) ·
                #   มุมอื่นที่ดวงแรกครอบ ≤ 1 มม. ต้องยังมีหมุดครอบหลังสลับ (★ รอบ 9d ช ด่านความครอบคลุม) — ไม่ผ่าน ⇒ เปลี่ยนชื่อดวงแรกแทน
                if ชื่อเลือก and _name_key(_k0.get('nm')) != _name_key(ชื่อเลือก):
                    _d0 = _xy(_k0).distance(มุมเก็บ)
                    _รอบ = [v for v in เหลือ + แฝด if v.distance(มุมเก็บ) <= 0.05]
                    _k0_บนมุม = any(_xy(_k0).distance(v) <= TOL_V for v in _รอบ)
                    _u = next((c for c in กอง[1:] if _name_key(c.get('nm')) == _name_key(ชื่อเลือก)
                               and _xy(c).distance(มุมเก็บ) <= (TOL_V if _d0 <= TOL_V else _d0)
                               and (not _k0_บนมุม or any(_xy(c).distance(v) <= TOL_V for v in _รอบ))), None)
                    if _u is not None:
                        _รอด = [_xy(c) for c in mks if c is _u or not any(c is k for k in กอง)]
                        _ครอบครบ = all(any(v.distance(m) <= TOL_V for m in _รอด)
                                       for v in เหลือ + แฝด
                                       if v.distance(มุมเก็บ) <= 0.05 and v.distance(_xy(_k0)) <= TOL_V)
                        if _ครอบครบ:
                            กอง = [_u] + [c for c in กอง if c is not _u]
                            _เลือกเก็บดวง = True
                คงไว้ = กอง[0]
                if ชื่อเลือก and _name_key(คงไว้.get('nm')) != _name_key(ชื่อเลือก):
                    # พนักงาน/ผู้ช่วยมีสิทธิ์ UPDATE(BND_NAME) อยู่แล้ว (18 ก.ย.) · ยืนยันไม่ได้ (★ 2.3.7 DI-13) ⇒ ไม่เปลี่ยน + บอกในกล่อง
                    if self._col_ok(point_lyr, _nf):
                        ชื่อใหม่ = ชื่อเลือก
                        ชื่อเดิมหาย = คงไว้.get('nm') or ""
                    else:
                        แก้ชื่อไม่ได้ = ชื่อเลือก
                # ④ ชื่อที่จะหาย = ชื่อของดวงที่ลบที่ไม่ใช่ชื่อที่เหลือ (ชร ทุกแบบนับเป็นชื่อเดียวกัน)
                _เหลือ = _name_key(ชื่อใหม่ if ชื่อใหม่ else คงไว้.get('nm'))
                _เห็น = {_เหลือ, _name_key(ชื่อเดิมหาย)}
                for c in กอง[1:]:
                    k = _name_key(c.get('nm'))
                    if k and k not in _เห็น:
                        _เห็น.add(k)
                        ชื่อหาย.append(c.get('nm'))
                _ai = _fld_idx(point_lyr.fields(), "ALT_NAME")
                if _ai >= 0:                            # อ่านอย่างเดียว — บอกว่าประวัติของดวงที่ลบหายไปด้วย
                    _เห็น_a = {_เหลือ} | {_name_key(x) for x in _txt(คงไว้['feature'][_ai]).split("|") if x.strip()}
                    for c in กอง[1:]:
                        for x in _txt(c['feature'][_ai]).split("|"):
                            x = x.strip()
                            if x and _name_key(x) not in _เห็น_a:
                                _เห็น_a.add(_name_key(x))
                                ประวัติหาย.append(x)
            elif กอง:
                # ★ 2.3.7 b19 (doc-verify E4) — กองมีหมุดดวงเดียว = ดวงที่เก็บ (เดิมตั้ง คงไว้ เฉพาะกองหลายดวง
                #   ⇒ บรรทัด "(หมุดที่ยังเป็นของมุมอื่น…)" ขึ้นทั้งที่หมุดที่ไม่ลบคือดวงที่เก็บเอง · วง 3 มุมที่มีมุมซ้อน)
                คงไว้ = กอง[0]
            ลบ = กอง[1:]
        else:
            คง = เหลือ + แฝด
            ลบ = [c for c in mks
                  if ห่าง(_xy(c), คง) > TOL_V and ห่าง(_xy(c), ที่ลบ) < ห่าง(_xy(c), คง)]
        ids = [c['id'] for c in ลบ]
        if not vs and not ids and hole:
            # ★ 2.4.2 rc6 — รู 3 มุมที่ไม่มีหมุดซ้อนให้เก็บกวาด (หมุดในกรอบ ±5 ซม. เป็นของมุมอื่นของรูเล็ก) ⇒ ถามลบทั้งรู
            return self._delete_hole_ring(poly_lyr, point_lyr, fid, pf, cv, xy_poly, True)
        if not vs and not ids:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ตรงนี้ไม่มีอะไรให้ลบ — หมุดที่เห็นเป็นของมุมอื่น/แปลงที่ใช้ UTM เดียวกัน", level=1, duration=8)
            return False
        # ★ รอบ 9d (ฌ) — จำลองสภาพหลังลบ ⇒ มุมเปลือย/หมุดหลุดมุมที่เกิดใหม่ (กติกา 1 มม.) ขึ้นบรรทัดเตือนก่อนยืนยัน
        _เหล็ก = self._delnode_iron_after(poly_lyr, point_lyr, pf, g0, g_after, แฝด,
                                          [จุด] + list(ที่ลบ) + [_xy(c) for c in ลบ], ids)
        a0, a1 = g0.area(), g_after.area()
        # ★ 2.3.7 (review DI-51) — มุมนี้ใช้ร่วมกับแปลงข้างเคียงกี่แปลง (L1 กี่แปลง) — อ่านอย่างเดียว ไม่แก้แปลงข้างเคียง
        _ข้างเคียง = (self._neighbour_line(self._corner_neighbours(poly_lyr, pf, fid, ที่ลบ))
                      if vs and not เหลือซ้อน else "")
        # ★ rc2 (audit A2-01) — ชื่อว่างแสดง "(ไม่มีชื่อ)" แบบกล่องอื่น ('name' ของ _marker_candidates เป็น "ไม่มีชื่อ" ไม่มีวงเล็บ)
        _รายชื่อ = ", ".join("gid %s %s" % (c['id'], c.get('nm') or '(ไม่มีชื่อ)') for c in ลบ)
        if len(_รายชื่อ) > 300:
            _รายชื่อ = _รายชื่อ[:300] + " …"
        if not vs:
            _มุม = "วงของแปลงตรงนี้มี 3 มุม ⇒ ไม่ลบมุม เก็บกวาดเฉพาะหมุดซ้อน (เหลือหมุด 1 ดวง)\n"
            if hole:                           # ★ 2.4.2 rc6
                _มุม += "(มุมนี้อยู่บนรูของแปลง — ถ้าจะลบทั้งรู: เก็บกวาดหมุดซ้อนก่อน แล้วคลิกมุมนี้อีกครั้ง)\n"
        else:
            _มุม = ((f"วงของแปลงตรงนี้เหลือ 3 มุม ⇒ ลบเฉพาะส่วนที่ซ้อน (เหลือมุม 1 + หมุด 1)\n" if เหลือซ้อน else "")
                    + f"มุมแปลงที่จะลบ: {len(vs)} มุม" + (" (ซ้อนกันอยู่ตรงนี้)" if len(vs) > 1 or เหลือซ้อน else "")
                    + "\n")
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ยืนยันลบ Node (ลบทั้งหมดที่จุดนี้)",
            f"ระวาง/UTM: {(_txt(pf[pu]) or '(ว่าง)') if pu else '?'}\n"              # ★ 2.3.7 (review DI-01)
            f"พิกัด: {xy_poly.x():.3f}, {xy_poly.y():.3f}\n"
            + _มุม
            + (f"หมุดของแปลงนี้ที่จะลบ: {len(ids)} ดวง — {_รายชื่อ}" if ids else "หมุดของแปลงนี้ที่จะลบ: ไม่มี")
            # ★ 2.3.7 — ไม่นับดวงที่เก็บไว้ (กรณีเหลือหมุด 1 ดวง) เดิมขึ้นบรรทัดนี้ทุกครั้งทั้งที่ไม่มีหมุดของมุมอื่นจริง
            + ("\n(หมุดที่ยังเป็นของมุมอื่น/แปลงที่ใช้ UTM เดียวกัน ไม่ถูกลบ)"
               if any(c['id'] not in ids and (คงไว้ is None or c['id'] != คงไว้['id']) for c in mks) else "")
            # ★ 2.3.7 (b12) — เหลือหมุด 1 ดวง: ชื่อที่เก็บ · ชื่อที่หาย (รวม ชร) · ประวัติ ALT_NAME ของดวงที่ลบ — บอกก่อนยืนยันทุกชื่อ
            + (f"\nเก็บหมุด gid {คงไว้['id']} ชื่อ \"{คงไว้.get('nm')}\" ไว้ (ชื่อที่เลือก — ไม่ต้องเปลี่ยนชื่อ)"
               if _เลือกเก็บดวง and คงไว้ is not None else "")
            + (f"\nหมุดที่เหลือ gid {คงไว้['id']} เปลี่ยนชื่อเป็น \"{ชื่อใหม่}\" {เหตุชื่อ}".rstrip()
               + (f" — ⚠️ ชื่อเดิม \"{ชื่อเดิมหาย}\" จะหายไป" if ชื่อเดิมหาย else "") if ชื่อใหม่ else "")
            + (f"\n⚠️ ตั้งชื่อ \"{แก้ชื่อไม่ได้}\" ให้หมุดที่เหลือไม่ได้ — บัญชีนี้แก้ชื่อหมุด (BND_NAME) ไม่ได้ "
               f"⇒ หมุดที่เหลือคงชื่อ \"{คงไว้.get('nm') or '(ไม่มีชื่อ)'}\"" if แก้ชื่อไม่ได้ else "")
            + (f"\n⚠️ ชื่อ {' | '.join(ชื่อหาย)} จะหายไปกับหมุดที่ลบ — ไม่ได้เลือกเก็บ "
               "(มุมหนึ่งเก็บชื่อได้ชื่อเดียว · จดไว้ก่อนถ้าต้องใช้)" if ชื่อหาย else "")
            + (f"\n⚠️ ประวัติชื่อ (ALT_NAME) ของหมุดที่ลบ: {' | '.join(ประวัติหาย)} — จะหายไปด้วย" if ประวัติหาย else "")
            + (f"\nเนื้อที่รูป: {a0:,.2f} → {a1:,.2f} ตร.ม." if abs(a1 - a0) >= 0.01 else "")
            + _ข้างเคียง
            + _เหล็ก
            + "\n\nลบทั้งหมดที่จุดนี้?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        lyrs = ([poly_lyr] if vs else []) + ([point_lyr] if ids else [])
        # ★ 2.4.0 (review DI-15) — เปิดโหมดแก้ไขทุกชั้นก่อนเปิดคำสั่ง (เดิมไม่ดูผล) · เปิดไม่ได้ = ไม่แตะมุมและหมุด
        if not self._ensure_editing(*lyrs, title="ลบ Node", what="ยังไม่ได้ลบมุมแปลงและหมุด"):
            return False
        self._op_begin(lyrs)
        if vs:
            poly_lyr.beginEditCommand("Delete Node (all stacked)")
        if ids:
            point_lyr.beginEditCommand("Delete Markers (all stacked)")
        okv = True
        try:
            for nr in vs:
                _r = poly_lyr.deleteVertex(fid, nr)
                # deleteVertex คืน enum (Success == 0) ไม่ใช่ bool — เช็คแบบ truthiness จะกลับด้าน
                if not (_r if isinstance(_r, bool) else (int(_r) == 0)):
                    okv = False
                    break
            if okv and vs:
                _g2 = poly_lyr.getFeature(fid).geometry()
                if _g2 is None or _g2.isEmpty() or _g2.area() <= 0:
                    okv = False              # 🔴 ห้ามเหลือรูปว่าง (ต้นเหตุแปลง geom=NULL)
            if okv and ชื่อใหม่:
                # ★ รอบ 5 — ตั้งชื่อจริงให้ดวงที่เก็บ ในคำสั่งเดียวกัน (ล้ม = ย้อนทั้งหมด)
                if not point_lyr.changeAttributeValue(
                        คงไว้['id'], point_lyr.fields().indexOf(self._addnode_name_field(point_lyr)), ชื่อใหม่):
                    okv = False
            if okv:
                for i in ids:
                    if not point_lyr.deleteFeature(i):
                        okv = False
                        break
        except Exception:
            okv = False
        finally:
            if okv:
                if vs:
                    poly_lyr.endEditCommand()
                if ids:
                    point_lyr.endEditCommand()
            else:
                if vs:
                    poly_lyr.destroyEditCommand()
                if ids:
                    point_lyr.destroyEditCommand()
        self._op_commit()
        if not okv:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ลบไม่สำเร็จ — ย้อนกลับให้แล้ว (มุมแปลงและหมุดยังครบเหมือนเดิม)", level=2, duration=8)
            return False
        # ★ รอบ 9d (ฌ) · ★ 2.3.7 (b12) — แถบผลบอกชื่อที่หาย (รวมชื่อเดิมของดวงที่เปลี่ยนชื่อ) / จุดที่เตือนกติกา 1 มม. (ระดับเตือน)
        _n_หาย = len(ชื่อหาย) + (1 if ชื่อเดิมหาย else 0)
        _ต่อท้าย = (((" · ตั้งชื่อหมุดที่เหลือ \"%s\"" % ชื่อใหม่) if ชื่อใหม่ else "")
                    + ((" · ⚠️ ชื่อหาย %d ชื่อ" % _n_หาย) if _n_หาย else "")
                    + (" · ⚠️ ตรวจกติกาหมุด 1 มม. ตรงนี้ (ดูคำเตือนก่อนยืนยัน)" if _เหล็ก else ""))
        self.iface.messageBar().pushMessage(
            "ลบ Node", ("ลบหมุดซ้อน %d ดวงแล้ว (มุมแปลงไม่ถูกแตะ)%s • กด 💾 บันทึก เพื่อยืนยัน" if not vs else
                        "ลบมุมแปลง %d มุม + หมุด %d ดวง (%s)%s แล้ว • กด 💾 บันทึก เพื่อยืนยัน")
            % (((len(ids),) if not vs else (len(vs), len(ids), "เฉพาะส่วนที่ซ้อน" if เหลือซ้อน else "ทั้งหมดที่จุดนี้"))
               + (_ต่อท้าย,)),
            level=(1 if _n_หาย or _เหล็ก else 0), duration=8)
        return True

    def _delete_hole_ring(self, poly_lyr, point_lyr, fid, pf, cv, xy_poly, allowed):
        """★ 2.4.2 rc6 (เจ้าของงานสั่ง 21 ต.ค. 69 — "แก้บั๊กลบหมุดในรูที่จะน้อยกว่าสามหมุด ให้เด้งว่าจะลบรูใช่ไหม")
        มุมที่คลิกอยู่บน "รู" (วงในของแปลง) ที่ลบมุมแล้วจะเหลือไม่ถึง 3 มุม — เดิมปฏิเสธ ("วงของแปลงตรงนี้เหลือ 3 มุม — ลบอีกไม่ได้")
        ⇒ รูแบบนี้ลบด้วยปุ่มนี้ไม่ได้เลย · ตอนนี้ถาม "จะลบรูนี้ใช่ไหม" — Yes = ลบวงในนั้นทั้งวง + หมุดของแปลงนี้ที่มุมของรู
        ในคำสั่งเดียว (ทั้งหมดหรือไม่ทำเลย · ↺ Undo ครั้งเดียวคืนครบ) · No = ไม่ทำอะไร · วงนอก 3 มุมยังปฏิเสธเหมือนเดิม
          · สิทธิ์ = เท่าการลบมุมแปลงจริง (allowed: ผู้ช่วยผู้ดูแล/ผู้ดูแล · พนักงานบนแปลง L2-LM) ไม่งั้นบอกให้ผู้ช่วย/ผู้ดูแลลบให้
          · หมุดที่ลบ = หมุดของแปลงนี้ในกรอบ ±5 ซม. ของมุมของรู ที่ใกล้มุมของรูกว่ามุมที่ยังอยู่/มุมของแปลงแฝด
            (กติกาเดียวกับ `_delete_node_all`) ⇒ หมุดของแปลงในรู (UTM อื่น) ไม่ถูกแตะ
          · หมุด L1 ที่ล็อกอยู่ที่มุมของรู ⇒ ปฏิเสธทั้งการกระทำ (ไม่งั้นหมุดกำพร้า) · ตรวจแปลงแฝดไม่ได้ ⇒ ไม่ทำ (fail-closed)
          · ในรูมีส่วนอื่นของแปลงเดียวกัน (เกาะในรู) / รูปเดิมถูกต้องแต่หลังลบไม่ถูกต้อง ⇒ ปฏิเสธ (ลบรูแล้วรูปทับตัวเอง)
          · กล่องยืนยันบอกเนื้อที่ก่อน → หลัง · แปลงอื่นที่อยู่ในรู (ลบรูแล้วรูปแปลงนี้จะทับ — แปลงนั้นไม่ถูกแก้ตาม) · กติกาหมุด 1 มม."""
        TOL_V = 0.001
        if not allowed:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "มุมนี้อยู่บนรูของแปลงที่เหลือ 3 มุม — ลบมุมแล้วต้องลบทั้งรู "
                           "(ลบรู/มุมแปลงจริงต้องให้ผู้ช่วยผู้ดูแล/ผู้ดูแลลบให้)", level=1, duration=9)
            return False
        g0 = QgsGeometry(pf.geometry())
        try:
            _ok, _vid = g0.vertexIdFromVertexNr(cv[1])
            if not _ok or _vid.ring < 1:
                raise RuntimeError("มุมที่คลิกไม่ได้อยู่บนรู (vertex %s)" % cv[1])
            _polys = g0.asMultiPolygon() if g0.isMultipart() else [g0.asPolygon()]
            _วง = _polys[_vid.part][_vid.ring]
            วงรู = [QgsPointXY(q) for q in _วง[:-1]]                # ตัดจุดปิดวง
            g_after = QgsGeometry(g0)
            _ag = g_after.get()
            _pg = _ag.geometryN(_vid.part) if QgsWkbTypes.isMultiType(_ag.wkbType()) else _ag
            if not _pg.removeInteriorRing(_vid.ring - 1):
                raise RuntimeError("removeInteriorRing ล้ม")
            # จุดหายไปเท่าจุดของวงนั้นพอดี (รวมจุดปิดวง) — ไม่งั้นลบผิดวง/ผิดก้อน
            if (not วงรู or g_after.isEmpty() or g_after.area() <= 0
                    or sum(1 for _ in g_after.vertices()) != sum(1 for _ in g0.vertices()) - len(_วง)):
                raise RuntimeError("รูปหลังลบรูไม่ตรงที่คาด")
        except Exception:
            _log_exc("_delete_hole_ring: คำนวณรูปหลังลบรูไม่ได้ — ไม่ทำ")
            self.iface.messageBar().pushMessage("ลบ Node", "คำนวณรูปหลังลบรูไม่ได้ — ไม่ทำ", level=2, duration=8)
            return False
        # ★ ตรวจทาน rc6 — ในรูมีส่วนอื่นของแปลงเดียวกัน (เกาะในรู) ⇒ ลบรูแล้วรูปทับตัวเอง (geometry ไม่ถูกต้อง · เนื้อที่นับซ้ำ)
        #   ตรวจตรง (ส่วนอื่นทับรู ≥ 0.01 ตร.ม.) + ตาข่าย (รูปเดิมถูกต้อง แต่หลังลบรูไม่ถูกต้อง) · ตรวจไม่ได้ = ไม่ทำ
        try:
            _hg = QgsGeometry.fromPolygonXY([วงรู + [วงรู[0]]])
            _เกาะ = any(QgsGeometry.fromPolygonXY(pp).intersection(_hg).area() >= 0.01
                        for i, pp in enumerate(_polys) if i != _vid.part)
            _เสีย = g0.isGeosValid() and not g_after.isGeosValid()
        except Exception:
            _log_exc("_delete_hole_ring: ตรวจรูปหลังลบรูไม่ได้ — ไม่ทำ")
            self.iface.messageBar().pushMessage("ลบ Node", "ตรวจรูปหลังลบรูไม่ได้ — ไม่ทำ", level=2, duration=8)
            return False
        if _เกาะ or _เสีย:
            self.iface.messageBar().pushMessage(
                "ลบ Node", ("ลบรูนี้ไม่ได้ — ในรูมีส่วนอื่นของแปลงเดียวกัน (ลบรูแล้วรูปแปลงจะทับตัวเอง) · จัดการส่วนที่อยู่ในรูก่อน"
                            if _เกาะ else "ลบรูนี้ไม่ได้ — รูปแปลงหลังลบรูจะไม่ถูกต้อง · ไม่ทำ"), level=1, duration=9)
            return False
        _n_มุม = len({(round(q.x() / self._DUP_TOL), round(q.y() / self._DUP_TOL)) for q in วงรู})   # มุมซ้อนนับเป็นมุมเดียว
        proj = QgsProject.instance()
        _ต่าง = point_lyr.crs() != poly_lyr.crs()
        to_poly = QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj) if _ต่าง else None
        to_pt = QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), proj) if _ต่าง else None
        mks, _l1 = {}, 0
        for q in วงรู:
            for c in self._marker_candidates(poly_lyr, point_lyr, pf, to_pt.transform(q) if to_pt else QgsPointXY(q)):
                mks.setdefault(c['id'], c)
            if getattr(self, "_marker_lock_scan_failed", False):
                return False                    # สแกนล็อกไม่สำเร็จ (แจ้งบนแถบแล้ว) — แบบ _delete_node_execute
            _l1 += getattr(self, "_marker_l1_filtered", 0)
        if _l1:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "มุมของรูนี้มีหมุดของแปลง L1 (พิกัดอ้างอิง) — %s" % self._l1_hint("ลบรูไม่ได้"),
                level=1, duration=9)
            return False
        # แปลงแฝด = UTM เดียวกันหลัง normalise (`_utm_twin_fids`) แบบ `_delete_node_all` · ★ ตรวจทาน rc6 — หาแล้วไม่เจอแปลงนี้เอง
        #   = ถามชั้นไม่สำเร็จ ⇒ ไม่ทำ (fail-closed · เดิมใช้ `_twin_vertices` ที่ผลว่างเงียบ ๆ = "ไม่มีแฝด" ⇒ หมุดมุมร่วมถูกลบ)
        แฝด = []
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        _raw = _txt(pf[pu]) if pu else ""
        if _raw:
            try:
                _all = self._utm_twin_fids(poly_lyr, pu, _raw, _norm_utm(_raw))
                if fid not in _all:
                    raise RuntimeError("หาแปลงที่ใช้ UTM เดียวกันแล้วไม่เจอแปลงนี้เอง (fid %s)" % fid)
                _tw = [t for t in _all if t != fid]
                _it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(_tw)) if _tw else None
                try:
                    for f in (_it if _it is not None else []):
                        g = f.geometry()
                        if g is not None and not g.isEmpty():
                            แฝด.extend(QgsPointXY(v.x(), v.y()) for v in g.vertices())
                finally:
                    if _it is not None:
                        _it.close()
            except Exception:
                _log_exc("_delete_hole_ring: ตรวจแปลงที่ใช้ UTM เดียวกันไม่ได้ — ไม่ลบ")
                self.iface.messageBar().pushMessage(
                    "ลบ Node", "ตรวจแปลงที่ใช้ UTM เดียวกันไม่ได้ — ไม่ทำ (กันลบหมุดของแปลงอื่น)", level=2, duration=8)
                return False

        def _xy(c):
            p = c['feature'].geometry().asPoint()
            return to_poly.transform(p) if to_poly else QgsPointXY(p)

        def ห่าง(p, pts):
            return min((p.distance(q) for q in pts), default=float("inf"))
        คง = [QgsPointXY(v.x(), v.y()) for v in g_after.vertices()] + แฝด
        ลบ = sorted((c for c in mks.values()
                     if ห่าง(_xy(c), คง) > TOL_V and ห่าง(_xy(c), วงรู) < ห่าง(_xy(c), คง)), key=lambda c: c['id'])
        ids = [c['id'] for c in ลบ]
        # แปลงอื่นในรู (เช่นแปลงย่อยที่ 🍩 หักออก) — ลบรูแล้วรูปแปลงนี้ทับแปลงนั้น · อ่านอย่างเดียว · เกณฑ์เศษ 0.01 ตร.ม. แบบ 🍩
        _ในรู = ""
        try:
            n = n_l1 = 0
            ทับ = 0.0
            it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(_hg.boundingBox()))
            try:
                for f in it:
                    g = f.geometry()
                    if f.id() == fid or g is None or g.isEmpty():
                        continue
                    a = g.intersection(_hg).area()
                    if a >= 0.01:
                        n += 1
                        ทับ += a
                        if self._poly_type_str(poly_lyr, f) in L1_TYPES:
                            n_l1 += 1
            finally:
                it.close()
            if n:
                _ในรู = ("\n⚠️ ในรูนี้มีแปลงอื่น %d แปลง%s — ลบรูแล้วรูปแปลงนี้จะทับแปลงเหล่านั้นราว %s ตร.ม. "
                         "(แปลงนั้นไม่ถูกแก้ตาม)" % (n, (" (เป็นแปลง L1 %d แปลง)" % n_l1) if n_l1 else "", f"{ทับ:,.2f}"))
        except Exception as e:
            QgsMessageLog.logMessage("_delete_hole_ring: ตรวจแปลงในรูไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            _ในรู = "\n⚠️ ตรวจไม่ได้ว่าในรูนี้มีแปลงอื่นหรือไม่ — ตรวจเองก่อนยืนยัน"
        _เหล็ก = self._delnode_iron_after(poly_lyr, point_lyr, pf, g0, g_after, แฝด,
                                          list(วงรู) + [_xy(c) for c in ลบ], ids)
        a0, a1 = g0.area(), g_after.area()
        _รายชื่อ = ", ".join("gid %s %s" % (c['id'], c.get('nm') or '(ไม่มีชื่อ)') for c in ลบ)
        if len(_รายชื่อ) > 300:
            _รายชื่อ = _รายชื่อ[:300] + " …"
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ยืนยันลบรู (ลบ Node)",
            f"ระวาง/UTM: {(_txt(pf[pu]) or '(ว่าง)') if pu else '?'}\n"
            f"พิกัด: {xy_poly.x():.3f}, {xy_poly.y():.3f}\n"
            f"มุมนี้อยู่บนรูของแปลง (วงใน) ที่มี {_n_มุม} มุม — ลบมุมแล้วรูจะเหลือไม่ถึง 3 มุม (ไม่เป็นรูปปิด)\n"
            f"⇒ ลบทั้งรู: มุมของรู {_n_มุม} มุม\n"
            + (f"หมุดของแปลงนี้ที่จะลบ: {len(ids)} ดวง — {_รายชื่อ}" if ids else "หมุดของแปลงนี้ที่จะลบ: ไม่มี")
            + ("\n(หมุดที่ยังเป็นของมุมอื่น/แปลงที่ใช้ UTM เดียวกัน ไม่ถูกลบ)"
               if any(i not in ids for i in mks) else "")
            + f"\nเนื้อที่รูป: {a0:,.2f} → {a1:,.2f} ตร.ม. (เนื้อที่ของรูกลับเป็นของแปลงนี้)"
            + _ในรู
            + _เหล็ก
            + "\n\nจะลบรูนี้ใช่ไหม?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        lyrs = [poly_lyr] + ([point_lyr] if ids else [])
        if not self._ensure_editing(*lyrs, title="ลบ Node", what="ยังไม่ได้ลบรูและหมุด"):
            return False
        self._op_begin(lyrs)
        poly_lyr.beginEditCommand("Delete Hole")
        if ids:
            point_lyr.beginEditCommand("Delete Hole Markers")
        okv = True
        try:
            okv = bool(poly_lyr.changeGeometry(fid, g_after))
            if okv:
                _g2 = poly_lyr.getFeature(fid).geometry()
                if _g2 is None or _g2.isEmpty() or _g2.area() <= 0:
                    okv = False              # 🔴 ห้ามเหลือรูปว่าง (ต้นเหตุแปลง geom=NULL)
            if okv:
                for i in ids:
                    if not point_lyr.deleteFeature(i):
                        okv = False
                        break
        except Exception:
            okv = False
        finally:
            if okv:
                poly_lyr.endEditCommand()
                if ids:
                    point_lyr.endEditCommand()
            else:
                poly_lyr.destroyEditCommand()
                if ids:
                    point_lyr.destroyEditCommand()
        self._op_commit()
        if not okv:
            self.iface.messageBar().pushMessage(
                "ลบ Node", "ลบรูไม่สำเร็จ — ย้อนกลับให้แล้ว (รูปแปลงและหมุดยังครบเหมือนเดิม)", level=2, duration=8)
            return False
        self.iface.messageBar().pushMessage(
            "ลบ Node", "ลบรูแล้ว (มุมของรู %d มุม + หมุด %d ดวง)%s • กด 💾 บันทึก เพื่อยืนยัน"
            % (_n_มุม, len(ids), " · ⚠️ ตรวจกติกาหมุด 1 มม. ตรงนี้ (ดูคำเตือนก่อนยืนยัน)" if _เหล็ก else ""),
            level=(1 if _เหล็ก or _ในรู else 0), duration=8)
        return True

    def start_rename_node(self):
        # 🔴 2.2.9 — เดิมเป็น `_admin_ready` (คืน None เมื่อไม่ได้เปิดโหมดผู้ดูแล)
        #   ปุ่มจึง "กดแล้วไม่ขึ้นอะไร" หลังย้ายมาให้พนักงานทั่วไปใช้
        ready = self._tool_ready("แก้ชื่อหมุด")
        if not ready:
            return
        if not self._pair_key_ok("แก้ชื่อหมุด"):      # ★ 2.3.7 (review AR-06-D) — ชั้นไม่มี UTM ⇒ ไม่ติดเครื่องมือ
            return
        _nf = self._addnode_name_field(ready[1])
        if _nf is not None and not self._need_column_or_warn(ready[1], _nf, "แก้ชื่อหมุด"):   # ★ 2.3.7 (review DI-13)
            return
        poly_lyr, point_lyr = ready
        self.cancel_transform()
        self.setup_snapping()
        self.temp_tool = RenameNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "แก้ชื่อหมุด", "คลิกเลือกแปลง แล้วคลิกที่หมุดของแปลงนั้นเพื่อแก้ชื่อ • คลิกขวา/Esc = ออก")

    def start_delete_node(self):
        # 🔴 2.2.9 — เหตุผลเดียวกับ start_rename_node (ปุ่มเงียบเพราะด่านแอดมิน)
        ready = self._tool_ready("ลบ Node")
        if not ready:
            return
        if not self._pair_key_ok("ลบ Node"):          # ★ 2.3.7 (review AR-06-D) — ชั้นไม่มี UTM ⇒ ไม่ติดเครื่องมือ
            return
        poly_lyr, point_lyr = ready
        self.cancel_transform()
        self.setup_snapping()
        self.temp_tool = DeleteNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "ลบ Node", "คลิกเลือกแปลงก่อน (จะไฮไลต์ของซ้อนให้) แล้วคลิกที่จุดนั้นเพื่อลบ "
                       "• คลิกขวา/Esc = ออก")

    # ---------- สลับหมุด (พนักงานใช้ได้ — มาแทนปุ่ม By UTM เดิม) ----------
    def start_swap_node(self):
        """คลิกแปลง -> คลิกหมุด 2 จุดของแปลงนั้น -> สลับ BND_NAME กัน

        ★ 31 ส.ค. 69 — เคสชื่อหมุดสลับลำดับกันเจอบ่อยจนต้องมีปุ่มของตัวเอง
          เดิมต้องให้แอดมินกด ✏️ แก้ชื่อหมุด สองรอบ ซึ่งระหว่างรอบแรกกับรอบสอง
          จะมีจังหวะที่หมุดสองตัวชื่อซ้ำกัน (ตรวจไม่ผ่านถ้ามีด่านเช็คชื่อซ้ำภายหลัง)"""
        if not self._pair_key_ok("สลับหมุด"):
            return
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_lyr or poly_lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, "สลับหมุด",
                      "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        if not point_lyr or point_lyr.geometryType() != QgsWkbTypes.PointGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, "สลับหมุด",
                      "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        # ไม่มีคอลัมน์ชื่อ = ทำงานไม่ได้เลย บอกตั้งแต่ก่อนเข้าเครื่องมือ ดีกว่าให้คลิกไปแล้วค่อยรู้
        _nf = self._addnode_name_field(point_lyr)
        if _nf is None:
            self._ask(QtWidgets.QMessageBox.Warning, "สลับหมุด",
                      "ชั้นหมุดไม่มีคอลัมน์ชื่อ (BND_NAME) — สลับชื่อไม่ได้")
            return
        # ★ 31 ส.ค. 69 — สลับ "ตำแหน่ง" ไม่ใช่ "ชื่อ": พนักงานมี GRANT UPDATE เฉพาะ
        #   geom กับ SCORE ของชั้นหมุด เขียน BND_NAME ไม่ได้ (ตรวจจากฐานงานจริงแล้ว
        #   ทั้ง 5 อำเภอ) ถ้าไปแก้ชื่อจะล้มตอน commit พร้อมพางานอื่นตกไปด้วย
        #   สลับตำแหน่งได้ผลเหมือนกันทุกประการ (ชื่อไปอยู่จุดที่ถูก) และ trigger log_move
        #   บันทึกเป็น 'moved' พร้อม geom ก่อน/หลัง ย้อนกลับได้เต็ม
        # ★ 2.4.0 (review DI-13) — "เขียน BND_NAME ไม่ได้" ข้างบนเป็นสิทธิ์ของ 31 ส.ค. · ตั้งแต่ 18 ก.ย. พนักงานได้ UPDATE(BND_NAME)
        #   เพิ่มแล้ว (ดู _can_update_column_uncached) · เครื่องมือนี้ยังสลับ "ตำแหน่ง" เหมือนเดิม: ต้องการแค่ UPDATE(geom)
        #   (ถามฐานตรงนี้) ⇒ ใช้ได้ทุกบัญชีที่ย้ายหมุดได้ ไม่ขึ้นกับสิทธิ์คอลัมน์ชื่อ และ log_move ตามรอยได้ครบ
        if not self._need_column_or_warn(point_lyr, "geom", "สลับหมุด"):
            return
        self.cancel_transform()
        self.setup_snapping()   # ★ 2 ก.ย. 69 — เหตุผลเดียวกับ Add Node
        self.temp_tool = SwapNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "สลับหมุด",
            f"คลิกเลือกแปลงใน '{poly_lyr.name()}' แล้วคลิกหมุด 2 จุดของแปลงนั้นเพื่อสลับตำแหน่งกัน "
            "• คลิกขวา/Esc = ยกเลิก")

    def _swap_node_execute(self, poly_lyr, fid, snap_xy, tool):
        """คลิกหมุดครั้งที่ 1 = จำไว้ • ครั้งที่ 2 = ยืนยันแล้วสลับชื่อกัน"""
        _chk = self._tool_layers_ok(poly_lyr, "สลับหมุด")   # กันสลับคอมโบหลัง arm
        if _chk is None:
            tool.clear_first()
            return False
        poly_lyr, point_lyr = _chk
        pf = poly_lyr.getFeature(fid)
        if not pf.isValid():
            return False
        # ★ 2.3.7 (review DU-01-D ①) — ด่าน Type แปลงชั้นใน แบบเดียวกับ แก้ชื่อหมุด/ลบ Node (ไม่พึ่งธงของเครื่องมืออย่างเดียว)
        #   เครื่องมือกันแปลง L1 ตอนคลิกเลือกเท่านั้น ⇒ แปลงที่ถูกเปลี่ยน Type เป็น L1 หลังเลือก (ใน buffer) ยังสลับหมุดได้
        _tp = self._poly_type_str(poly_lyr, pf)
        if _tp in L1_TYPES and not self._l1_unlocked():     # ★ 2.4.0 (DU-01) lock_rules
            tool.clear_first()
            self.iface.messageBar().pushMessage(
                "สลับหมุด", "แปลงนี้เป็น %s (พิกัดอ้างอิง) — %s" % (_tp, self._l1_hint("สลับหมุดไม่ได้")),
                level=1, duration=7)                 # ★ 2.3.7 (audit C-02) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            return False
        mk = self._admin_find_marker(poly_lyr, point_lyr, pf, snap_xy)
        if mk is None:
            if getattr(self, "_admin_pick_cancelled", False):
                return False          # ★ 2.2.4 ผู้ใช้กดยกเลิกเอง -> เงียบ ไม่ใช่ความผิดของข้อมูล
            if getattr(self, "_marker_lock_scan_failed", False):
                return False          # ★ 2.4.0 (review DU-01) สแกนล็อกไม่สำเร็จ — แจ้งเหตุจริงบนแถบแล้ว
            self.iface.messageBar().pushMessage(
                "สลับหมุด",
                ("หมุดตรงนี้เป็นหมุดของแปลง L1 (พิกัดอ้างอิง) — " + self._l1_hint("สลับไม่ได้")   # ★ 2.3.7 UX-13
                 if getattr(self, "_marker_l1_filtered", 0) else
                 "ตรงนี้ไม่มีหมุด 'ของแปลงที่เลือก' (ระวางไม่ตรงกัน)"),
                level=1, duration=6)
            return False
        # ★ rc2 (audit A2 · ผู้ตรวจทานพบเพิ่ม) — หมุดที่ได้เป็นของมุมอื่น ⇒ ไม่สลับ (เหตุเดียวกับแก้ชื่อหมุด)
        _d = self._marker_other_corner(poly_lyr, point_lyr, pf, snap_xy, mk)
        if _d is not None:
            tool.clear_first()
            self.iface.messageBar().pushMessage(
                "สลับหมุด",
                "มุมที่คลิกไม่มีหมุดของแปลงที่เลือก — หมุดของแปลงนี้ที่ใกล้ที่สุดอยู่บนมุมข้าง ๆ (ห่าง %.1f ซม.) "
                "ไม่ได้สลับให้ · เริ่มใหม่โดยคลิกที่หมุดของแปลงนี้โดยตรง" % (_d * 100), level=1, duration=9)
            return False
        nf = self._addnode_name_field(point_lyr)
        if nf is None:
            self.iface.messageBar().pushMessage(
                "สลับหมุด", "ชั้นหมุดไม่มีคอลัมน์ชื่อ (BND_NAME)", level=1, duration=6)    # ★ 2.3.7 (audit C-02)
            return False
        cur_id = mk.id()
        cur_name = _txt(mk[nf])     # ★ 2.3.5 NULL = ว่าง

        # ---- คลิกที่ 1: จำไว้แล้วรอคลิกที่ 2 ----
        # ★ 31 ส.ค. 69 — เก็บ UTM ที่ใช้จับคู่ตอนคลิกแรกไว้ด้วย ถ้าค่าถูกแก้คั่นกลาง
        #   (แอดมินแก้ผ่านตารางแอตทริบิวต์) หมุดสองตัวจะมาจากคนละกลุ่ม UTM
        #   = สลับข้ามแปลง แล้วกติกาเหล็กพัง — เป็นช่องเดียวที่ทำให้เครื่องมือนี้ทำผิดกติกาได้
        pu0 = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        utm_now = _norm_utm(pf[pu0]) if pu0 else None
        first = getattr(tool, "first", None)
        if first is not None and len(first) > 2 and first[2] != utm_now:
            tool.clear_first()
            self.iface.messageBar().pushMessage(
                "สลับหมุด", "ระวาง/UTM ของแปลงเปลี่ยนไประหว่างเลือก — เริ่มใหม่",
                level=1, duration=6)
            return False
        if first is None:
            tool.first = (cur_id, cur_name, utm_now)
            xy = getattr(tool, "_last_map_xy", None)
            if xy is not None:
                tool.mark_first(xy)
            self.iface.messageBar().pushInfo(
                "สลับหมุด",
                f"เลือกหมุดที่ 1 แล้ว: '{cur_name or '(ว่าง)'}' — คลิกหมุดที่ 2 เพื่อสลับ "
                "(คลิกหมุดเดิมซ้ำ = ยกเลิก)")
            return False

        # ---- คลิกหมุดเดิมซ้ำ = ยกเลิกการเลือก ----
        if first[0] == cur_id:
            tool.clear_first()
            self.iface.messageBar().pushInfo("สลับหมุด", "ยกเลิกหมุดที่ 1 — เลือกใหม่ได้")
            return False

        # ---- คลิกที่ 2: ตรวจแล้วสลับ ----
        f1 = point_lyr.getFeature(first[0])
        if not f1.isValid():
            tool.clear_first()
            self.iface.messageBar().pushMessage(
                "สลับหมุด", "หมุดตัวที่ 1 หายไปแล้ว (ถูกลบ?) — เลือกใหม่", level=1, duration=6)
            return False
        old1 = _txt(f1[nf])         # ★ 2.3.5 NULL = ว่าง
        old2 = cur_name
        g1 = QgsGeometry(f1.geometry())
        g2 = QgsGeometry(mk.geometry())
        if g1.isEmpty() or g2.isEmpty():
            tool.clear_first()
            self.iface.messageBar().pushMessage(
                "สลับหมุด", "หมุดตัวใดตัวหนึ่งไม่มีพิกัด — สลับไม่ได้", level=1, duration=6)    # ★ 2.3.7 (audit C-02)
            return False
        p1, p2 = g1.asPoint(), g2.asPoint()
        if p1.distance(p2) <= 1e-6:
            tool.clear_first()
            self.iface.messageBar().pushMessage(
                "สลับหมุด", "หมุดสองตัวอยู่ตำแหน่งเดียวกัน — สลับแล้วไม่ต่างจากเดิม",
                level=1, duration=6)
            return False

        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ยืนยันสลับหมุด",
            f"ระวาง/UTM: {(_txt(pf[pu]) or '(ว่าง)') if pu else '-'}\n\n"            # ★ 2.3.7 (review DI-01)
            f"สลับ 'ตำแหน่ง' ของหมุดสองตัวนี้ (ชื่อหมุดไม่เปลี่ยน จะได้ไปอยู่จุดที่ถูก)\n\n"
            f"gid {f1.id()}  '{old1 or '(ว่าง)'}'\n"
            f"     {p1.x():,.3f}, {p1.y():,.3f}   ->   {p2.x():,.3f}, {p2.y():,.3f}\n"
            f"gid {mk.id()}  '{old2 or '(ว่าง)'}'\n"
            f"     {p2.x():,.3f}, {p2.y():,.3f}   ->   {p1.x():,.3f}, {p1.y():,.3f}\n\n"
            f"ระยะห่างกัน {p1.distance(p2):,.3f} ม.\n\nสลับ?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            # ★ 31 ส.ค. 69 — เดิมคืน False เฉย ๆ หมุดตัวที่ 1 ยังค้าง คลิกหมุดถัดไป
            #   จะเด้งกล่องยืนยันจับคู่กับตัวเก่าที่คิดว่ายกเลิกไปแล้ว
            tool.clear_first()
            self.iface.messageBar().pushInfo(
                "สลับหมุด", "ยกเลิกแล้ว — เลือกหมุดที่ 1 ใหม่ได้")
            return False

        if not self._ensure_editing(point_lyr, title="สลับหมุด", what="ยังไม่ได้สลับ"):     # ★ 2.4.0 (review DI-15) เดิมไม่ดูผล
            tool.clear_first()
            return False
        self._op_begin([point_lyr])
        point_lyr.beginEditCommand("Swap Markers")
        ok = True
        try:
            ok = bool(point_lyr.changeGeometry(f1.id(), g2)) and ok
            ok = bool(point_lyr.changeGeometry(mk.id(), g1)) and ok
        except Exception:
            ok = False
        finally:
            # ★ 2.3.7 (review DI-33) — สำเร็จ = endEditCommand · ไม่สำเร็จ = destroyEditCommand (ย้อน + ไม่ทิ้ง Redo)
            #   เดิม endEditCommand แล้ว undo() ⇒ เหลือขั้น Redo ที่เอาการสลับ "ข้างเดียว" กลับมาได้
            if ok:
                point_lyr.endEditCommand()
            else:
                point_lyr.destroyEditCommand()
        # ★ เขียนสำเร็จข้างเดียว = ชื่อซ้ำกันสองตัว ซึ่งแย่กว่าไม่ทำอะไรเลย -> ถอยทั้งคู่ (destroyEditCommand ด้านบน)
        if not ok:
            self._op_commit()
            tool.clear_first()
            self.iface.messageBar().pushMessage(
                "สลับหมุด", "ย้ายไม่สำเร็จ — ย้อนคืนทั้งคู่แล้ว (ไม่มีอะไรเปลี่ยน)",
                level=2, duration=8)
            return False
        self._op_commit()
        tool.clear_first()
        # บันทึกลง <D>_Move_Log โดย trigger log_move เป็น action='moved' สองแถว
        # เก็บ dx/dy/dist_m/geom_before/geom_after ครบ ย้อนกลับได้จากล็อก
        self.iface.messageBar().pushMessage(
            "สลับหมุด",
            f"สลับตำแหน่งแล้ว: '{old1 or '(ว่าง)'}' <-> '{old2 or '(ว่าง)'}' "
            f"(ห่างกัน {p1.distance(p2):,.2f} ม.) • กด 💾 บันทึก เพื่อยืนยัน",
            level=0, duration=6)
        return True

    @staticmethod
    def _alt_names(point_lyr, fids):
        """★ 2.3.7 (b12) — ชื่อใน ALT_NAME ของหมุด fids (อ่านอย่างเดียว · ไม่ซ้ำ · ตามลำดับ fid) — ชั้นไม่มีคอลัมน์/อ่านไม่ได้ ⇒ []"""
        out = []
        try:
            ai = _fld_idx(point_lyr.fields(), "ALT_NAME") if point_lyr is not None else -1
            if ai < 0 or not fids:
                return []
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(sorted(fids)))
            try:
                for f in _it:
                    for x in _txt(f[ai]).split("|"):
                        x = x.strip()
                        if x and x not in out:
                            out.append(x)
            finally:
                _it.close()
        except Exception:
            _log_exc("_alt_names: อ่าน ALT_NAME ของหมุดค้างไม่ได้", once_key="_alt_names")
            return []
        return out

    def _addnode_execute(self, poly_lyr, fids, ins_xy):
        """เพิ่ม node ให้ทุกแปลงที่เลือก + สร้างหมุดใหม่ (ระวางจากแปลง, ชื่อจากหมุดเดิม ณ จุด snap)
        ins_xy = พิกัดหมุดที่ snap ติด (CRS เลเยอร์หมุด). คืน True ถ้าสำเร็จ"""
        _chk = self._tool_layers_ok(poly_lyr, "Add Node")      # กันสลับคอมโบหลัง arm
        if _chk is None:
            return False
        _, point_lyr = _chk
        proj = QgsProject.instance()
        name_field = self._addnode_name_field(point_lyr)
        # จุดแทรก node ใน CRS ชั้นแปลง + ทางกลับไป CRS ชั้นหมุด (★ 2.3.7 DU-02-D1 วางหมุดบนมุมเดิม)
        to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj)
                   if poly_lyr.crs() != point_lyr.crs() else None)
        _to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), proj)
                  if poly_lyr.crs() != point_lyr.crs() else None)
        ins_poly = to_poly.transform(ins_xy) if to_poly else QgsPointXY(ins_xy)
        utm_fields = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO", "UTM"]
        # ★ 2.3.0 — ดึงแปลงที่เลือกทีเดียว แทน getFeature ทีละ fid ในลูป (N+1)
        #   ผู้ตรวจฝั่ง Windows วัดไว้: เลือก 80 แปลง -> คิวรีชั้นแปลง 80 ครั้ง
        #   🔑 ดึง **ก่อน** แก้ไข แล้ววนบนสำเนา — insertVertex แก้ทีละ fid ไม่กระทบสำเนาของ fid อื่น
        _pf_of = {}
        if fids:
            for _f in poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(fids))):
                _pf_of[_f.id()] = _f
        # ★ 2.3.7 (review UX-44 · DI-07) — ตรวจรายแปลงแบบอ่านอย่างเดียว **ก่อน** ถามชื่อ/เปิดแก้ไข
        #   เดิมถามชื่อก่อน แล้วค่อยรู้ว่าเป็น L1 / ไกลเกินเพดาน / มุมนี้มีหมุดของแปลงอยู่แล้ว = พิมพ์ชื่อทิ้งเปล่า
        #   และเปิดโหมดแก้ไขทั้งที่ไม่มีอะไรจะเขียน · ไม่มีแปลงไหนได้มุม/หมุดใหม่ ⇒ แจ้งเหตุแล้วจบ
        _plan = self._addnode_plan(poly_lyr, point_lyr, fids, _pf_of, ins_xy, ins_poly, utm_fields)
        # ★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค.) — มุมที่มี node + หมุดของแปลงแล้ว แต่หมุดชื่อว่าง ⇒ เด้งเลือกชื่อ (แทนการข้ามเงียบ)
        _unnamed = [(fid, mid) for fid, e in _plan.items() for mid in (e.get("unnamed") or ())]
        if not any(e["node"] or e["mark"] for e in _plan.values()):
            if _unnamed and name_field is not None:
                # ★ 2.4.0 (review DU-02) — หมุดชื่อว่างที่จะตั้งชื่อเยื้องมุม 1 มม.–1 ซม. ⇒ บอกให้ใช้ Move Node ด้วย
                #   (เดิมทางตั้งชื่อไม่ผ่าน _addnode_report_skips ⇒ คำแนะนำหาย · ตั้งชื่อแล้วด่านก่อนบันทึกยังเตือน)
                _n_off = sum(1 for e in _plan.values() if e.get("offset"))
                if _n_off:
                    self.iface.messageBar().pushMessage(
                        "Add Node", f"{_n_off} จุดเป็นหมุดเยื้องมุม (ไม่เกิน 1 ซม.) — ตั้งชื่อแล้วยังต้องใช้ Move Node "
                                    "ลากหมุดไปวางที่มุม", level=1, duration=10)
                # ★ rc1 (F8 · §5.1 DU-01 ต่อ) — ทางตั้งชื่อ return ก่อน _addnode_report_skips ⇒ หมุดล็อกชื่อว่างของแปลงอื่นที่เลือก
                #   ไม่ถูกรายงาน (ตั้งชื่อให้เฉพาะหมุดที่ไม่ล็อก แล้วเงียบ) ⇒ บอกด้วยถ้อยคำเดียวกับแถบสรุป
                _n_lk = sum(1 for e in _plan.values() if e.get("unnamed_locked"))
                if _n_lk:
                    self.iface.messageBar().pushMessage(
                        "Add Node", f"{_n_lk} จุดเป็นหมุด L1 (พิกัดอ้างอิง) ที่ยังไม่มีชื่อ — "
                                    + self._l1_hint("ตั้งชื่อหมุดไม่ได้"), level=1, duration=10)
                return self._addnode_name_unnamed(poly_lyr, point_lyr, name_field, _unnamed, ins_xy, _pf_of)
            self._addnode_report_skips(_plan, poly_lyr)
            return False
        # DI-07: คลิกห่างมุมเดิม 1 ซม.–0.5 ม. / มีหมุดของแปลงเองเยื้องอยู่ใกล้ ⇒ ถามก่อน (ปุ่มปริยาย = ไม่)
        _warn = [e["warn"] for e in _plan.values() if e["warn"]]
        if _warn and self._ask(QtWidgets.QMessageBox.Question, "Add Node", "\n\n".join(_warn),
                               QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                               QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return False
        _need_name = any(e["mark"] for e in _plan.values())   # ไม่มีแปลงไหนได้หมุดใหม่ = ไม่ต้องถามชื่อ

        # รวมชื่อจากหมุดที่ตำแหน่งเดียวกัน (coincident กับจุด snap ≤5ซม.) -> หลายชื่อให้ popup เลือก
        COINC = 0.05
        rect = QgsRectangle(ins_xy.x() - COINC, ins_xy.y() - COINC,
                            ins_xy.x() + COINC, ins_xy.y() + COINC)
        names = []
        if _need_name:
            # ★ 2.4.0 (review PF-07) — อ่านแค่ชื่อหมุด ⇒ ไม่ดึงรูป/คอลัมน์อื่น (การกรองกรอบยังใช้รูปฝั่ง provider/edit buffer ตามปกติ)
            _req_nm = QgsFeatureRequest().setFilterRect(rect).setFlags(QgsFeatureRequest.NoGeometry)
            if name_field is not None:
                _req_nm.setSubsetOfAttributes([name_field], point_lyr.fields())
            else:
                _req_nm.setNoAttributes()
            for f in point_lyr.getFeatures(_req_nm):
                nm = "" if name_field is None else _txt(f[name_field])   # ★ 2.3.5 NULL = ว่าง
                if nm and nm not in names:
                    names.append(nm)
        if not _need_name:
            chosen = ""
        elif len(names) == 1 and not _unnamed:
            chosen = names[0]
        elif names:
            chosen, ok = QtWidgets.QInputDialog.getItem(
                self.iface.mainWindow(), "เลือกชื่อหมุด",
                "ตำแหน่งนี้มีหลายหมุดหลายชื่อ — เลือกชื่อที่ต้องการ:", names, 0, False)
            if not ok:
                return False
        elif name_field is not None:
            # ★ 2.2.6 — จุดนี้ไม่มีหมุดที่มีชื่อให้ยืมเลย: **ถามก่อน** แทนการใส่ชื่อว่างเงียบ ๆ
            #   วัดจากฐานจริง 7 ก.ย. 69: หมุดที่พนักงานเพิ่มเอง 89,732 ดวง ไม่มีชื่อ 273 (0.30%)
            #   และ **98% ของนั้นเกิดตรงมุมที่เพื่อนบ้านก็ไม่มีชื่อ** ⇒ ความว่างแพร่ต่อกันเอง
            #   (เพื่อนบ้านพวกนั้นคือมุม GEN_KIND='no-marker' ที่สายผลิตก็หาชื่อไม่ได้)
            #   🔑 เจ้าของงานสั่ง 7 ก.ย.: **ต้องเว้นว่างแล้วกด OK ได้** เพราะบางหมุดไม่มีชื่อจริง ๆ
            #      ⇒ กล่องนี้เป็น "ตัวเตือน" ไม่ใช่ "ตัวบังคับ" · กด Cancel = ไม่เพิ่มอะไรเลย
            chosen, ok = QtWidgets.QInputDialog.getText(
                self.iface.mainWindow(), "ชื่อหมุด",
                "จุดนี้ยังไม่มีหมุดที่มีชื่อให้อ้างอิง\n\n"
                "พิมพ์ชื่อหมุดแล้วกด OK\n"
                "ถ้าหมุดนี้ไม่มีชื่อจริง ๆ ให้เว้นว่างไว้แล้วกด OK ได้เลย")
            if not ok:
                return False
            chosen = (chosen or "").strip()
        else:
            chosen = ""

        # ★ 2.4.0 (review DI-15) — เปิดโหมดแก้ไขทั้งสองชั้นก่อนเปิดคำสั่ง (เดิมไม่ดูผล) · เปิดไม่ได้ = ไม่แทรกมุม/ไม่สร้างหมุด
        if not self._ensure_editing(poly_lyr, point_lyr, title="Add Node", what="ยังไม่ได้เพิ่มมุมแปลงและหมุด"):
            return False
        self._op_begin([poly_lyr, point_lyr])   # เริ่มนับ undo-step ต่อเลเยอร์
        poly_lyr.beginEditCommand("Add Node")
        point_lyr.beginEditCommand("Add Marker")
        n_node = n_pt = n_skip = n_fail = n_rbfail = 0
        try:
            for fid in fids:
                pf = _pf_of.get(fid)
                if pf is None or not pf.isValid():
                    continue
                # กันชน: ห้ามเพิ่ม node ให้แปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
                tp = self._poly_type_str(poly_lyr, pf)
                if tp in L1_TYPES and not self._l1_unlocked():      # ★ 2.4.0 (DU-01) lock_rules
                    self.iface.messageBar().pushMessage(
                        "Add Node", f"ข้าม {self._feat_label(poly_lyr, pf)}: เป็น {tp} (พิกัดอ้างอิง ห้ามเพิ่ม node)",
                        level=1, duration=6)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                    continue
                geom = pf.geometry()
                # ถ้าแปลงมี vertex ตรงนั้นแล้ว ไม่ต้องแทรกซ้ำ (แต่ยังเพิ่มหมุด)
                cv = geom.closestVertex(ins_poly)
                has_vertex = cv[4] is not None and cv[4] < self._MK_WELD_TOL ** 2   # < 1 ซม. (★ 2.4.0 DU-02 ค่าคงที่ชุดเดียวกับ _addnode_plan)
                _ins_at = None            # index ของ vertex ที่เพิ่งแทรก (ไว้ย้อนถ้าหมุดเข้าไม่ได้)
                if not has_vertex:
                    seg = geom.closestSegmentWithContext(ins_poly)
                    # ★ เพดานระยะ (2026-08-06): เดิมไม่เช็ค seg[0] (ระยะยกกำลังสองถึงขอบแปลง)
                    #   -> คลิกหมุดที่อยู่ไกลจากแปลงที่เลือก ก็แทรกมุมให้ = รูปแปลงบิดไปหาหมุดนั้น
                    _cap = self._addnode_max_dist()      # None = ผู้ช่วยผู้ดูแลขึ้นไป ไม่จำกัด
                    if _cap is not None and seg[0] is not None and seg[0] > (_cap ** 2):
                        n_fail += 1
                        self.iface.messageBar().pushMessage(
                            "Add Node",
                            f"ข้าม {self._feat_label(poly_lyr, pf)}: จุดที่คลิกห่างจากขอบแปลงนี้ {math.sqrt(seg[0]):.2f} ม. "
                            f"(เกิน {_cap:.0f} ม.)",
                            level=1, duration=8)
                        continue
                    if poly_lyr.insertVertex(ins_poly.x(), ins_poly.y(), fid, seg[2]):
                        n_node += 1
                        _ins_at = seg[2]
                    else:
                        # ★ แทรกมุมไม่สำเร็จ -> ห้ามเพิ่มหมุด (2026-08-04)
                        #   เดิมไหลต่อไป addFeature เสมอ = ได้หมุดลอยที่ไม่มีมุมแปลงรองรับ (ผิดกติกาเหล็ก)
                        n_fail += 1
                        continue
                # ★ กันหมุดซ้ำ: ถ้าแปลงนี้มีหมุดของตัวเองอยู่ตรงนั้นแล้ว อย่าเพิ่มอีก
                #   (เดิม has_vertex กันแค่ไม่ให้แทรก vertex ซ้ำ แต่ยัง addFeature เสมอ
                #    -> คลิก Add Node ซ้ำจุดเดิม/คลิกแปลงที่มีหมุดครบแล้ว = ได้หมุดซ้อนกัน)
                # ★ 2.3.7 (review DU-02-D1) — มีมุมอยู่แล้ว ⇒ วางหมุดบน "มุมเดิมเป๊ะ" ไม่ใช่จุด snap (ดู _addnode_mark_xy)
                mk_xy = self._addnode_mark_xy(ins_xy, cv, has_vertex, _to_pt)
                # ★ 2.3.7 (UX-44) — ด่านล่วงหน้าบอกว่าแปลงนี้ไม่ได้หมุดใหม่ (จึงไม่ได้ถามชื่อ) ⇒ ไม่สร้าง
                if not _plan.get(fid, {}).get("mark") or \
                        self._marker_exists_here(point_lyr, pf, mk_xy, utm_fields):
                    n_skip += 1
                    continue
                # เพิ่มหมุดใหม่: ระวางจากแปลง + ชื่อที่เลือก
                nf = QgsFeature(point_lyr.fields())
                nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(mk_xy)))
                # 🔧 9 ก.ย. 69 — ชื่อคงที่ ⇒ ใช้ _fld_idx (ไม่งั้นชั้นตัวพิมพ์เล็กจะถูกข้ามเงียบ ๆ
                #   หมุดใหม่ได้ระวางว่าง -> กลายเป็นมุมเปลือย = ผิดกติกาเหล็กโดยไม่มีคำเตือน)
                for fld in utm_fields:
                    pi = _fld_idx(point_lyr.fields(), fld)
                    qi = _fld_idx(poly_lyr.fields(), fld)
                    if pi >= 0 and qi >= 0:
                        nf.setAttribute(pi, pf.attribute(qi))
                # ★ rc1 2.4.0 (F1 · DU01) — Type ของหมุดใหม่ = Type ของแปลง (แบบเดียวกับ ➕ สร้างแปลง / 🍩)
                #   เดิมคัดแค่ 7 ฟิลด์คีย์ ⇒ หมุดจาก Add Node ได้ Type ว่างทุกดวง (ฐานจริง ~216k ดวง) และหมุดบนแปลง L1
                #   (ผู้ดูแลที่ปลดล็อก) ได้ Type ว่าง = ข้อมูลไม่ตรงกัน · แปลง Type ว่าง ⇒ ไม่ตั้ง (คงพฤติกรรมเดิม)
                #   สิทธิ์: บทบาทพนักงานมี INSERT คอลัมน์ Type ของชั้นหมุด (ตรวจแล้ว 13 ต.ค. 69)
                #   ★ rc2 (audit A2-03) — ผ่าน _marker_type_from_parcel: ปรับรูปแบบ (' l2-ro ' ⇒ 'L2-RO') · แปลง CT-RTK ⇒ ไม่ตั้ง
                #     (กติกาเจ้าของงาน 13 ต.ค. — ชั้นหมุดต้องไม่มี CT-RTK)
                _tpi, _tqi = _fld_idx(point_lyr.fields(), "Type"), _fld_idx(poly_lyr.fields(), "Type")
                _mt = _marker_type_from_parcel(pf.attribute(_tqi)) if (_tpi >= 0 and _tqi >= 0) else None
                if _mt:
                    nf.setAttribute(_tpi, _mt)
                if name_field is not None and chosen:
                    nf.setAttribute(point_lyr.fields().indexOf(name_field), chosen)
                # provenance: ติดป้ายว่าหมุดนี้ "คนเพิ่ม" (addFeature() ไม่ผ่าน attribute form -> form default ไม่ยิง)
                # ตั้งแค่ EDIT_SRC เท่านั้น — "ใคร/เมื่อไหร่" ปล่อยให้ PG trigger tag_added_point() เขียนเอง:
                #   EDITED_BY = session_user  (PG role ของพนักงานจริง เช่น <ชื่อบัญชีของพนักงาน> — แม่นกว่า OS login
                #                              ของเครื่องที่อาจเป็นบัญชีกลาง เช่น บัญชีกลางของเครื่อง) ปลอมจาก client ไม่ได้
                #   EDITED_AT = now()         (เวลา server ไม่ใช่นาฬิกาเครื่อง client)
                # (indexOf: ไม่มีคอลัมน์ -> -1 -> ข้าม, ปลอดภัยกับเลเยอร์ที่ไม่มี provenance)
                _pidx = _fld_idx(point_lyr.fields(), "EDIT_SRC")
                if _pidx >= 0:
                    nf.setAttribute(_pidx, "added")
                if point_lyr.addFeature(nf):
                    n_pt += 1
                else:
                    # ★ หมุดเข้าไม่ได้ (สิทธิ์ INSERT ไม่พอ/provider ปฏิเสธ) -> ย้อนมุมที่เพิ่งแทรกออก
                    #   (2026-08-04) ไม่งั้นเหลือมุมเปลือยไม่มีหมุด = ผิดกติกาเหล็กอีกด้าน
                    n_fail += 1
                    if _ins_at is not None:
                        # ★ deleteVertex คืน enum Qgis.VectorEditResult (Success==0) และไม่ raise
                        #   -> ต้องเช็คผลจริง (แบบเดียวกับ _delete_node_execute) · ถ้าย้อนไม่สำเร็จ
                        #   = เหลือมุมเปลือย ให้แจ้งดัง ๆ ไม่ปล่อยเงียบ (2026-08-05)
                        _rv = poly_lyr.deleteVertex(fid, _ins_at)
                        if (_rv if isinstance(_rv, bool) else int(_rv) == 0):
                            n_node -= 1
                        else:
                            n_rbfail += 1                 # ★ 2.3.7 (UX-01) — สรุปท้ายต้องไม่บอกว่า "ย้อนให้แล้ว"
                            self.iface.messageBar().pushMessage(
                                "Add Node", f"{self._feat_label(poly_lyr, fid)}: หมุดเข้าไม่ได้และย้อนมุมที่แทรกไม่สำเร็จ "
                                            "— มุมนี้ยังไม่มีหมุด (กด Undo แล้วลองใหม่)",
                                level=2, duration=10)
            # ★ 2.3.9 — แปลงอื่นที่เลือกมีหมุดของมุมนี้แล้วแต่ชื่อว่าง ⇒ ตั้งชื่อเดียวกับหมุดใหม่ (คำสั่งเดียวกัน ย้อนพร้อมกัน)
            n_named = 0
            if _unnamed and chosen and name_field is not None:
                _ni = point_lyr.fields().indexOf(name_field)
                for _fid, _mid in _unnamed:
                    _f = point_lyr.getFeature(_mid)
                    if _f.isValid() and not _txt(_f[name_field]) and \
                            point_lyr.changeAttributeValue(_mid, _ni, chosen, _f[name_field]):
                        n_named += 1
            n_pt_eff = n_pt + n_named
            # ★ 2.3.7 (review DI-28) — ปิดคำสั่งเฉพาะชั้นที่เขียนสำเร็จจริง: QGIS push คำสั่งเปล่าลง undo stack
            #   (index +1 · ชั้นกลายเป็น "มีการแก้ไข") ⇒ ↺ Undo ไปย้อน "ความว่าง" แทนงานจริงก่อนหน้าแล้วแจ้งว่าสำเร็จ
            #   ⇒ ชั้นที่ไม่ได้เขียนอะไร (หรือแทรกแล้วย้อนออกหมด) = destroyEditCommand (stack เท่าเดิม · ไม่ค้างการแก้)
            if n_node > 0:
                poly_lyr.endEditCommand()
            else:
                poly_lyr.destroyEditCommand()
            if n_pt_eff > 0:
                point_lyr.endEditCommand()
            else:
                point_lyr.destroyEditCommand()
            self._op_commit()   # ปิด operation -> เก็บประวัติ undo (ชั้นที่ destroy ไปแล้ว delta=0 ไม่ถูกนับ)
        except Exception:
            _log_exc("Add Node: เพิ่ม node ไม่สำเร็จ — ยกเลิกทั้งหมดแล้ว", Qgis.Critical)     # ★ 2.3.7 (ER-03/ER-06)
            poly_lyr.destroyEditCommand()
            point_lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline
            # ★ 2.3.7 (review ER-06) — เดิมหัวข้อ 'Add Node Error' + ข้อความ exception ดิบ
            self.iface.messageBar().pushMessage(
                "Add Node", f"เพิ่ม node ไม่สำเร็จ — ยกเลิกทั้งหมดแล้ว (มุมแปลงและหมุดเหมือนก่อนคลิก) · {self._LOG_HINT}",
                level=2, duration=0)
            return False

        self.iface.mapCanvas().refresh()
        # ★ 2.3.7 (review UX-35) — สำเร็จ = ระดับข้อมูล (ฟ้า) ไม่ใช่เขียว "สำเร็จ" เพราะยังไม่ได้บันทึกลงฐาน
        # ★ 2.3.7 (review UX-01) — ย้อนมุมไม่สำเร็จ ต้องไม่บอกว่า "ย้อนกลับให้แล้ว" · คำแนะนำ "คลิกต่อ/คลิกขวา"
        #   ย้ายมาท้ายสรุปนี้ (เดิมเครื่องมือดัน "เพิ่มหมุดสำเร็จ" ทับสรุป แม้ข้ามหมุดหรือย้อนไม่สำเร็จ)
        self.iface.messageBar().pushMessage(
            "Add Node", f"เพิ่ม node {n_node} แปลง + หมุด {n_pt} จุด (ชื่อ '{chosen or '-'}')"
                        + (f" • ตั้งชื่อหมุดชื่อว่างของแปลงอื่น {n_named} ดวง" if n_named else "")
                        + (f" • ข้าม {n_skip - n_named} จุดที่มีหมุดอยู่แล้ว" if n_skip > n_named else "")
                        + (f" • ⚠️ ทำไม่สำเร็จ {n_fail} แปลง (ย้อนกลับให้แล้ว ไม่มีมุม/หมุดค้าง)"
                           if n_fail and not n_rbfail else "")
                        + (f" • ⚠️ ทำไม่สำเร็จ {n_fail} แปลง — ย้อนมุมที่แทรกไม่สำเร็จ {n_rbfail} มุม "
                           "(มุมนั้นยังไม่มีหมุด) กด ↺ Undo แล้วลองใหม่" if n_rbfail else "")
                        + " • คลิกจุดอื่นต่อได้เลย หรือคลิกขวาเพื่อเสร็จสิ้น",
            level=(2 if n_fail else 0), duration=(12 if n_fail else 8))
        # ★ คืนค่าตามงานที่ทำจริง (2026-08-06): มีเส้นทางที่ข้ามทุกแปลง (เกินเพดานระยะ/แทรกมุมไม่ได้)
        #   เดิมคืน True เสมอ -> เครื่องมือรายงานว่าสำเร็จทั้งที่ไม่มีอะไรเกิดขึ้น
        return (n_node > 0 or n_pt > 0 or n_named > 0)
