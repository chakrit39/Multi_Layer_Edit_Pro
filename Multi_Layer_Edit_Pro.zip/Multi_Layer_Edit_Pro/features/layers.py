# -*- coding: utf-8 -*-
"""คู่ชั้นแปลง-หมุด: คอมโบ, เลือกคู่อัตโนมัติ, snapping, CRS, ฟิลด์ และอ่าน/เขียนค่า attribute

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import math
import re
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import (Qgis, QgsCoordinateTransform, QgsDataSourceUri, QgsFeatureRequest, QgsMessageLog, QgsPointXY, QgsProject,
                       QgsSnappingConfig, QgsTolerance, QgsVectorLayer, QgsWkbTypes)
from qgis.gui import QgsSnapIndicator
from ..core.util import _fld_idx, _log_exc, _natkey, _sheet_label, _txt, _UTM_FIELD_NAMES


class LayersMixin:
    """คู่ชั้นแปลง-หมุด: คอมโบ, เลือกคู่อัตโนมัติ, snapping, CRS, ฟิลด์ และอ่าน/เขียนค่า attribute"""

    # ============ ตัวช่วยหา field (memoize ตาม layer.id) — ใช้ใน hover ที่เรียกถี่ ============
    def _resolve_field(self, layer, candidates):
        """คืนชื่อ field แรกที่ตรงกับ candidates (เทียบ lowercase) หรือ None — cache ตาม layer.id()
        ใช้กับ hot path เช่น _poly_type_str ที่ถูกเรียกทุก mouse-move
        (call site แบบครั้งเดียวต่อคลิกใช้ _field_index ได้ ไม่ต้องผ่าน cache นี้)"""
        ckey = (layer.id(), frozenset(candidates))
        if ckey in self._field_cache:
            return self._field_cache[ckey]
        name = next((f.name() for f in layer.fields()
                     if f.name().lower() in candidates), None)
        self._field_cache[ckey] = name
        return name

    def refresh_layers(self):
        # แปลง = เฉพาะเลเยอร์ Polygon, หมุด = เฉพาะเลเยอร์ Point
        prev = (self.poly_cb.currentData(), self.point_cb.currentData())
        # ★ 2.3.7 (review DI-02) — คอมโบว่างชั่วคราว (QGIS ล้างชั้นทั้งหมดก่อนอ่านไฟล์ = รีเฟรชรอบล้างทำคอมโบว่าง) ⇒ ใช้ชั้นที่เห็นล่าสุด
        #   ⇒ Revert/เปิดไฟล์เดิมซ้ำ (id เดิม) ช่องที่เลือกให้อัตโนมัติไว้กลับมาที่เดิม · คนละไฟล์ ⇒ id ไม่เจอ ไม่มีผล
        _last = getattr(self, "_last_sel", None) or (None, None)
        prev = tuple(a if a else b for a, b in zip(prev, _last))
        self._refreshing = True
        # ★ 2.3.7 (review DI-02) — สร้างคอมโบใหม่โดยปิดสัญญาณ (เดิมทุก clear/addItem/setCurrentIndex ยิง currentIndexChanged
        #   เข้า _on_layer_combo_changed หลายรอบต่อการรีเฟรช 1 ครั้ง) · งานที่สัญญาณเคยทำ เรียกเองครั้งเดียวข้างล่าง
        _blk = [cb.blockSignals(True) for cb in (self.poly_cb, self.point_cb)]
        try:
            self._refresh_layers_inner(prev)
        finally:
            for cb, b in zip((self.poly_cb, self.point_cb), _blk):
                cb.blockSignals(b)
            self._refreshing = False
        self._arm_pair_watch()
        _now = (self.poly_cb.currentData(), self.point_cb.currentData())
        self._last_sel = tuple(a if a else b for a, b in zip(_now, _last))
        if _now != prev:
            try:
                self._line_pt_update_hint()       # ป้ายระบบพิกัดของหน้าต่างวาดเส้น (เดิมได้จากสัญญาณ)
            except Exception:
                pass
        self._admin_unlock_follow_conn()          # ★ 2.4.0 (review DI-09) สัญญาณคอมโบถูกปิดไว้ข้างบน ⇒ ตรวจคอนเนกชันเอง

    def _refresh_layers_inner(self, prev):
        self.poly_cb.clear(); self.point_cb.clear()
        self._field_cache.clear()   # รายชื่อเลเยอร์เปลี่ยน -> ล้าง cache field กันชื่อค้าง
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                gt = lyr.geometryType()   # มีเฉพาะ vector layer (raster -> error -> ข้าม)
            except Exception:
                continue
            # ★ 2.3.6 (audit รอบ 2) — ชั้นชั่วคราวของหน้าต่างวาดเส้น ห้ามโผล่ในคอมโบชั้นทำงาน
            #   (ชั้นจุดที่กรอกพิกัดเป็นชั้นจุด ⇒ เคยโผล่ในคอมโบ "ชั้นหมุด" ให้เลือกผิดได้)
            if lyr.name() in (self.LINE_LAYER_NAME, self.LINE_PT_LAYER_NAME):
                try:
                    if lyr.dataProvider().name() == "memory":
                        continue
                except Exception:
                    continue
            if gt == QgsWkbTypes.PolygonGeometry:
                self.poly_cb.addItem(lyr.name(), lyr.id())
            elif gt == QgsWkbTypes.PointGeometry:
                self.point_cb.addItem(lyr.name(), lyr.id())
        # คงเลเยอร์ที่เลือกไว้เดิม (เดิม refresh แล้วเด้งกลับตัวแรกเสมอ)
        for cb, pid in zip((self.poly_cb, self.point_cb), prev):
            if pid:
                i = cb.findData(pid)
                if i >= 0:
                    cb.setCurrentIndex(i)
        # ★ 2.3.7 (review DI-02) — ช่องที่ "ผู้ใช้เลือกเอง" กู้จากการเลือกนั้น (id เดิม · ไม่เจอ ⇒ ชั้นที่มาเดียวกันที่ถูกเพิ่มกลับ = id ใหม่)
        #   ช่องที่ไม่ได้เลือกเอง หรือชั้นที่เลือกไว้หายไปแล้ว ⇒ เลือกให้ทุกรอบ (_auto_pick_pair คงคู่ที่ตรงกันอยู่แล้วไว้ · ช่องเดียวใช้สาขาของอีกช่อง)
        #   เดิมธงเดียว _user_picked: แตะคอมโบครั้งเดียวในอำเภอ A แล้วเปิดไฟล์อำเภอ B ⇒ ระหว่างโหลด ชั้น CT_/LandsMaps_ ที่มาก่อน (เรียงตาม id)
        #   ถูก "กู้" ซ้ำทุกรอบ ⇒ ค้างคู่ตัวแทน (💾 บันทึกชั้นผิดคู่ · ตัวเฝ้ามุมแปลงเฝ้าผิดชั้น · ด่านคีย์ปฏิเสธเครื่องมือ)
        ok = [False, False]
        picks = list(getattr(self, "_pick", None) or [None, None])
        for n, cb in enumerate((self.poly_cb, self.point_cb)):
            pk = picks[n]
            if not pk:
                continue
            i = cb.findData(pk[0])
            if i < 0 and pk[1] is not None:
                i = next((j for j in range(cb.count())
                          if self._layer_source_key(QgsProject.instance().mapLayer(cb.itemData(j))) == pk[1]), -1)
            if i >= 0:
                cb.setCurrentIndex(i)
                picks[n] = (cb.itemData(i), pk[1])
                ok[n] = True
        self._pick = picks
        # ★ 1.9.4 เกณฑ์เรียก auto-pick — เดิมใช้ธง "restored" ตัวเดียวร่วมกันทั้งสองช่อง
        #   บั๊กเดิม: ลบชั้นหมุดออกแล้วเพิ่มกลับ (PostGIS หลุด/ลากกลับจาก Browser) QGIS ออก layer id ใหม่
        #   -> ช่องหมุดกู้ไม่ได้ ตกไป index 0 = CT_<สาขา> แต่ช่องแปลงกู้ได้ -> restored=True -> ข้าม auto-pick
        #   -> รอบถัดไป prev กลายเป็น CT_id ซึ่ง "กู้สำเร็จ" ทุกครั้ง -> ค้างที่ CT ตลอดทั้ง session
        #   -> CT ไม่มีคอลัมน์ UTM -> _pairing_issues คืน None -> ตัวเตือนตายสนิท (บั๊กเดิมใต้เลขเวอร์ชันใหม่)
        if not all(ok):                             # ★ 2.3.7 (DI-02) — เลือกให้เฉพาะช่องที่ไม่ได้ถูกกู้จากการเลือกของผู้ใช้
            self._auto_pick_pair(fill_poly=not ok[0], fill_point=not ok[1])

    def _on_layer_combo_changed(self, *_a, slot=None):
        """ผู้ใช้สลับชั้นเอง -> จำไว้ว่าอย่าไปเลือกให้ใหม่ + ย้ายตัวเฝ้าไปชั้นใหม่
        (_refreshing กัน setCurrentIndex ที่โค้ดเราสั่งเองตอน refresh ไปนับเป็น 'ผู้ใช้เลือก')
        ★ 2.3.7 (review DI-02) — จำ "รายช่อง" (slot 0 = แปลง · 1 = หมุด · None = ทั้งสองช่องตามที่เห็นอยู่)"""
        if not getattr(self, "_refreshing", False):
            self._user_picked = True
            for _n in ((slot,) if slot in (0, 1) else (0, 1)):
                self._remember_pick(_n)
        self._arm_pair_watch()
        # ★ 2.3.7 — ป้ายระบบพิกัดของรายการจุด (หน้าต่างวาดเส้น) อ่านจากชั้นแปลงในคอมโบนี้ ⇒ อัปเดตทันทีที่สลับ
        #   (เดิมค้างค่าเก่าจนกว่าจะสร้าง/ลบจุด ทั้งที่จุดใช้ระบบของชั้นที่เลือก ณ ตอนกดเสมอ)
        try:
            self._line_pt_update_hint()
        except Exception:
            pass
        if slot != 1:
            self._admin_unlock_follow_conn()        # ★ 2.4.0 (review DI-09) คอมโบแปลงย้ายคอนเนกชัน ⇒ ล็อก L1 กลับ

    def _auto_pick_pair(self, fill_poly=True, fill_point=True):
        """เลือกชั้นแปลง+หมุดให้อัตโนมัติจากชื่อ <สาขา>_POLYGON / <สาขา>_POINT
        จับคู่โดย "ชื่อสาขาต้องตรงกัน" ไม่ใช่แค่ลงท้ายถูก — กันจับผิดคู่เมื่อโปรเจกต์มีหลายสาขา
        และกันหยิบ LandsMaps_<สาขา> ซึ่งเป็นชั้น polygon เหมือนกันแต่ไม่ใช่ชั้นทำงาน
        fill_poly/fill_point: เติมเฉพาะช่องที่ระบุ (ใช้ตอนของเดิมหายไปข้างเดียว)
        ★ 2.3.7 (review DI-22) — เติมช่องเดียว: สาขาของ "ช่องที่คงไว้" (เดิม pairs[0] = สาขาแรกตามตัวอักษร ⇒ คู่ข้ามสาขา + ข้อความผิด)
          สาขานั้นไม่มีชั้นคู่ ⇒ ไม่แตะช่อง + เตือนครั้งเดียว · เติมสองช่อง: คอมโบถือคู่ <สาขา>_POLYGON/_POINT ที่ตรงกันอยู่แล้ว ⇒ ไม่เปลี่ยน
          (คงการซ่อมตัวเองของ 1.9.4 — คู่ตัวแทน CT_/LandsMaps_ ไม่ใช่คู่ที่ตรงกัน) · ข้อความสร้างจากสิ่งที่ตั้งจริง"""
        try:
            polys, points = {}, {}
            for l in QgsProject.instance().mapLayers().values():
                try:
                    gt = l.geometryType()
                except Exception:
                    continue            # raster/ชั้นที่ไม่มี geometryType
                if gt == QgsWkbTypes.PolygonGeometry:
                    b = self._branch_of(l.name(), "_POLYGON")
                    if b is not None:
                        polys.setdefault(b, l)
                elif gt == QgsWkbTypes.PointGeometry:
                    b = self._branch_of(l.name(), "_POINT")
                    if b is not None:
                        points.setdefault(b, l)
            pairs = sorted(set(polys) & set(points))
            prj = QgsProject.instance()
            cur = [prj.mapLayer(cb.currentData()) if cb.currentData() else None for cb in (self.poly_cb, self.point_cb)]
            kept = None
            if fill_poly and fill_point:
                if not pairs:
                    return                  # ไม่ตรงรูปแบบ -> ปล่อยให้ผู้ใช้เลือกเอง
                # ★ 2.3.7 (review DI-22) — คู่ที่ตรงกันอยู่แล้ว (เช่นสาขาที่ 2 ที่เคยเลือกไว้) ⇒ ไม่เปลี่ยน (เดิมเลือก pairs[0] ทับทุกรอบ)
                bp = self._branch_of(cur[0].name(), "_POLYGON") if cur[0] is not None else None
                if bp is not None and bp == (self._branch_of(cur[1].name(), "_POINT") if cur[1] is not None else None):
                    return
                key = pairs[0]
                targets = [(self.poly_cb, polys[key]), (self.point_cb, points[key])]
            elif fill_poly or fill_point:
                # ★ 2.3.7 (review DI-22) — เติมช่องเดียว: ใช้สาขาของช่องที่คงไว้
                kept = cur[1] if fill_poly else cur[0]
                key = self._branch_of(kept.name(), "_POINT" if fill_poly else "_POLYGON") if kept is not None else None
                pool = polys if fill_poly else points
                if key is None:
                    return                  # ช่องที่คงไว้ไม่ใช่ชั้นตามรูปแบบชื่อ ⇒ ไม่เดาสาขา
                if key not in pool:
                    อีก, ช่อง = ("หมุด", "แปลง") if fill_poly else ("แปลง", "หมุด")
                    self._autopick_warn(
                        (key, fill_poly),
                        f"ชั้น{อีก} '{kept.name()}' เป็นของสาขา {key} แต่ในโปรเจกต์ไม่มีชั้น{ช่อง} "
                        f"'{key}_{'POLYGON' if fill_poly else 'POINT'}' — ช่อง{ช่อง}ไม่ได้เลือกให้ กรุณาเลือกเอง")
                    return
                targets = [((self.poly_cb if fill_poly else self.point_cb), pool[key])]
            else:
                return
            # หา index ให้ครบก่อนค่อยเซ็ต — กันกรณีพังกลางคันแล้วเหลือเลือกครึ่งเดียว
            plan = [(cb, i) for cb, lyr in targets
                    for i in (cb.findData(lyr.id()),) if i >= 0]
            if len(plan) != len(targets):
                return
            changed = any(cb.currentIndex() != i for cb, i in plan)
            for cb, i in plan:
                cb.setCurrentIndex(i)
            self._autopick_warned = None
            if changed:                 # แจ้งทุกครั้งที่เลือกให้จริง (เดิมแจ้งเฉพาะตอนมีหลายสาขา
                                        #  -> โปรเจกต์สาขาเดียวเงียบสนิท พนักงานไม่เห็นว่าฟีเจอร์ทำงาน)
                # ★ 2.3.7 (review DI-22) — ข้อความสร้างจากสิ่งที่ตั้งจริง (เดิมช่องเดียวก็บอกคู่ของ pairs[0] ทั้งคู่)
                if kept is None:
                    extra = f" (โปรเจกต์นี้มี {len(pairs)} สาขา — เปลี่ยนได้ที่กล่องด้านบน)" if len(pairs) > 1 else ""
                    msg = f"เลือกชั้นให้อัตโนมัติ: แปลง '{polys[key].name()}' • หมุด '{points[key].name()}'{extra}"
                else:
                    msg = (f"เลือกชั้น{'แปลง' if fill_poly else 'หมุด'}ให้อัตโนมัติ: '{targets[0][1].name()}' "
                           f"(สาขาเดียวกับชั้น{'หมุด' if fill_poly else 'แปลง'} '{kept.name()}' ที่ใช้อยู่)")
                self.iface.messageBar().pushMessage("MLEP", msg, level=0, duration=8)
        except Exception:
            pass                        # เลือกไม่ได้ -> ปล่อยให้ผู้ใช้เลือกเอง

    @staticmethod
    def _branch_of(name, suffix):
        """★ 2.3.7 (review DI-22) — ชื่อสาขาจากชื่อชั้น '<สาขา>_POLYGON' / '<สาขา>_POINT' (ไม่สนตัวพิมพ์/ช่องว่างหัวท้าย) · ไม่ตรงรูปแบบ = None"""
        up = ("" if name is None else str(name)).strip().upper()
        return up[:-len(suffix)] if up.endswith(suffix) and len(up) > len(suffix) else None

    def _autopick_warn(self, key, text):
        """★ 2.3.7 (review DI-22) — เตือน "สาขานี้ไม่มีชั้นคู่" ครั้งเดียวต่อเรื่อง (รีเฟรชคอมโบเกิดทุกครั้งที่เพิ่ม/ถอดชั้น)"""
        if getattr(self, "_autopick_warned", None) == key:
            return
        self._autopick_warned = key
        try:
            self.iface.messageBar().pushMessage("MLEP", text, level=1, duration=10)
        except Exception:
            pass

    @staticmethod
    def _layer_source_key(lyr):
        """★ 2.3.7 (review DI-02) — "ที่มา" ของชั้นแบบไม่มีรหัสผ่าน ใช้กู้ช่องที่ผู้ใช้เลือกเมื่อชั้นถูกถอดแล้วเพิ่มกลับ (QGIS ออก id ใหม่)
        PostGIS = (ฐาน, schema, ตาราง, คอลัมน์รูป) · ไฟล์ = ที่อยู่/ชั้นย่อย · memory = None (ถอดแล้วข้อมูลหาย ไม่มีอะไรให้กู้)"""
        try:
            prov = lyr.providerType()
            if prov == "memory":
                return None
            if prov == "postgres":
                from qgis.core import QgsDataSourceUri
                u = QgsDataSourceUri(lyr.source())
                return (prov, u.database(), u.schema(), u.table(), u.geometryColumn())
            return (prov, lyr.publicSource())
        except Exception:
            return None

    def _remember_pick(self, slot, *_a):
        """★ 2.3.7 (review DI-02) — จำชั้นที่ผู้ใช้เลือกในช่อง slot (0 = แปลง · 1 = หมุด) เป็น (layer id, ที่มาของชั้น)
        เปิดไฟล์เดิมซ้ำ/Revert ได้ id เดิม ⇒ กู้คืนได้ · ถอดแล้วเพิ่มชั้นกลับ ⇒ กู้ด้วยที่มา"""
        if getattr(self, "_refreshing", False):
            return
        try:
            cb = (self.poly_cb, self.point_cb)[slot]
            lid = cb.currentData()
            lyr = QgsProject.instance().mapLayer(lid) if lid else None
            picks = list(getattr(self, "_pick", None) or [None, None])
            picks[slot] = (lid, self._layer_source_key(lyr)) if lyr is not None else None
            self._pick = picks
        except Exception:
            pass

    def _arm_pair_watch(self, *_a):
        """ติดตัวเฝ้า "มุมแปลงไม่มีหมุด" กับชั้นแปลงที่เลือก ตั้งแต่เปิดปลั๊กอิน
        (เดิม _watch_layer_editing ถูกเรียกเฉพาะตอนใช้เครื่องมือของปลั๊กอิน -> คนที่ใช้
        Vertex Tool ของ QGIS ล้วน ๆ แล้วกด Save ของ QGIS ไม่เคยถูกเฝ้าเลย = ช่องโหว่ตัวจริง)"""
        try:
            for _l in (QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                       QgsProject.instance().mapLayer(self.point_cb.currentData())):
                self._watch_layer_editing(_l)   # เฝ้าทั้งชั้นแปลงและชั้นหมุด
        except Exception:
            pass

    def _project_layers_changed(self, *_a):
        """เลเยอร์ในโปรเจกต์เพิ่ม/หาย -> refresh combo อัตโนมัติ (เดิมต้องกดปุ่ม 🔄 เอง)"""
        if not getattr(self, "_alive", True):      # ★ 2.3.7 (review LC-03e) — instance ที่ถูก unload แล้วห้ามทำงาน
            return
        # ★ 2 ก.ย. 69 — ถ้าเป็นการสลับชั้นเส้นของเราเองตอนบันทึกโปรเจกต์ ให้ปล่อยผ่าน
        #   ไม่ใช่เลเยอร์ของผู้ใช้ที่หายไป จึงไม่มีเหตุต้องล้างเงาหรือสร้างคอมโบใหม่
        if getattr(self, "_line_in_save", False):
            return
        # ★ 2.3.6 (audit รอบ 2) — ชั้นชั่วคราวของเราเองถูกเพิ่ม/เอาออก (ขึ้นจุดแรก · ล้างจุด · วาดเส้นแรก)
        #   ระหว่างที่พนักงานกด Move คลิกแรกไปแล้ว ⇒ เดิม "เงาแปลง" หายจากจอ (อาการเดียวกับที่แก้ให้ Ctrl+S)
        #   ⇒ ปล่อยผ่านแบบเดียวกัน · อัปเดตแค่ลายเซ็นแม่เหล็กที่ยืมไว้ (ถ้ายืมอยู่)
        if getattr(self, "_line_own_swap", False):
            # 🔴 audit รอบ 3 — ห้าม _line_snap_resync() ตรงนี้: มันยึด "ค่าปัจจุบัน" เป็นของเรา
            #   ถ้าผู้ใช้เพิ่งเปลี่ยน tolerance เองระหว่างยืมแม่เหล็ก ตอนปิดหน้าต่างจะถูกปิดแม่เหล็กทับค่าของเขา
            #   (ถดถอยจาก 2.3.5 ในโหมด AllLayers) · ชั้นของเราไม่อยู่ในลายเซ็นอยู่แล้ว ⇒ ไม่มีอะไรต้อง resync
            return
        # ★★ 2 ก.ย. 69 — เลเยอร์ที่เพิ่งถูกเพิ่มเข้าโปรเจกต์ QGIS จะใส่ค่า snapping ให้เอง
        #   แบบ "เปิดใช้" ⇒ ชั้นที่พนักงานลากเข้ามาเอง (เช่นชั้นระวาง) กลายเป็นเป้า snap ทันที
        #   ซึ่งล้มเจตนาของ setup_snapping ที่ตั้งใจ "จำกัด snap เฉพาะชั้นแปลง+หมุดที่เลือก"
        #   ⇒ พนักงานเล็งมุมแปลง แต่ได้มุมของกรอบระวางแทน แล้วย้าย node+หมุดผิดที่ลงฐานจริง
        #   จึงตั้งค่าจำกัดใหม่ทุกครั้งที่รายชื่อเลเยอร์เปลี่ยน "เฉพาะตอนเครื่องมือของเราทำงานอยู่"
        # ★ 2.3.7 (review DI-02) — ระหว่างโหลดโปรเจกต์ QGIS เพิ่มชั้นทีละชั้น (layersAdded ยิงทีละครั้ง เรียงตาม id)
        #   ⇒ ไม่สร้างคอมโบใหม่ทุกชั้น: ล้างเงา + จำกัด snap ทันทีเหมือนเดิม แล้วรีเฟรชคอมโบครั้งเดียวหลังโหลดเสร็จ (_layers_settle)
        if getattr(self, "_layers_loading", False):
            self._preview_clear()
            self._reapply_snap_limit()
            if not getattr(self, "_layers_settle_pending", False):
                self._layers_settle_pending = True
                try:
                    QtCore.QTimer.singleShot(0, self._layers_settle)
                except Exception:
                    self._layers_settle_pending = False
                    self._layers_loading = False
            return
        # ★ 2.3.7 (review UX-32) — ลำดับใหม่: ล้างเงา → รีเฟรชคอมโบ → จำกัด snap
        #   เดิมจำกัด snap ก่อนรีเฟรช ⇒ ชุด "ชั้นทำงาน" มาจากคอมโบชุดเก่า: ถอดชั้นแปลงแล้วเพิ่มกลับ (id ใหม่) ระหว่างใช้เครื่องมือ
        #   ⇒ คอมโบเลือกชั้นใหม่ให้ แต่ชั้นนั้นถูกนับเป็น "ชั้นที่เพิ่งลากเข้ามา" แล้วถูกปิด snap (📐 วาดเส้น snap ชั้นทำงานไม่ได้)
        # เงาอ้างถึง layer ที่ cache ไว้ตอนคลิกแรก — ถ้าเลเยอร์นั้นเพิ่งถูกลบ
        # การวาดเฟรมถัดไปจะพังทุกครั้งที่ขยับเมาส์ (C++ object ถูกลบไปแล้ว) -> ทิ้งเงาก่อน
        self._preview_clear()
        if self.dlg is not None:
            try:
                self.refresh_layers()
            except Exception:
                pass
        self._reapply_snap_limit()

    def _on_loading_layer(self, *_a):
        """★ 2.3.7 (review DI-02) — QGIS กำลังอ่านไฟล์โปรเจกต์ (ยิงก่อนเพิ่มแต่ละชั้น) ⇒ โหมดโหลด: รวบการสร้างคอมโบไว้ครั้งเดียว
        จบที่ _on_project_read (โหลดเสร็จ) หรือ _layers_settle (รอบ event ถัดไป — กันค้างถ้าอ่านล้มกลางทาง)"""
        if getattr(self, "_alive", True):
            self._layers_loading = True

    def _layers_settle(self):
        """★ 2.3.7 (review DI-02) — รีเฟรชคอมโบครั้งเดียวหลังโหลดโปรเจกต์ (ตัวจับเวลาจาก _project_layers_changed)
        เป็นทางสำรองด้วย: ไม่มี readProject ตามมา (ปิดโปรเจกต์ · โหลดล้ม) ⇒ เลิกโหมดโหลดเองที่รอบ event ถัดไป
        (หน้าต่าง Handle Bad Layers รัน event loop ซ้อนกลางการโหลด ⇒ อาจมาก่อนโหลดเสร็จ: ได้คอมโบจากชั้นที่มีตอนนั้น
         แล้วชั้นที่ตามมารีเฟรชทันทีแบบเดิม — ไม่เพิ่ม/ไม่ลบเลเยอร์ จึงปลอดภัยกับ QgsProject::read())"""
        self._layers_settle_pending = False
        if not getattr(self, "_alive", True):
            return
        self._layers_loading = False
        if self.dlg is not None:
            try:
                self.refresh_layers()
            except Exception:
                pass

    def _reapply_snap_limit(self):
        """ตั้งรายชื่อชั้นที่ snap ได้ใหม่ — ใช้ตอนรายชื่อเลเยอร์ในโปรเจกต์เปลี่ยน

        ทำ "เฉพาะตอนเครื่องมือของปลั๊กอินกำลังทำงานอยู่บนแคนวาส" เท่านั้น
        ไม่งั้นจะไปยึดค่า snapping ของผู้ใช้ตอนที่เขาไม่ได้ใช้เครื่องมือเราเลย
        ตั้งเฉพาะรายชื่อชั้น ไม่แตะ tolerance/type ที่หน่วยงานตั้งไว้ และไม่เรียก _topo_guard
        (จะได้ไม่มีกล่องเด้งใส่ผู้ใช้ตอนแค่ลากชั้นเข้ามาดู)
        """
        try:
            tool = getattr(self, "temp_tool", None)
            if tool is None:
                return
            canvas = self.iface.mapCanvas()
            if canvas is None or canvas.mapTool() is not tool:
                return                      # เครื่องมือของเราไม่ได้อยู่บนแคนวาสแล้ว
            prj = QgsProject.instance()
            config = prj.snappingConfig()
            if int(config.mode()) != int(QgsSnappingConfig.AdvancedConfiguration):
                # ★ 8 ก.ย. 69 — เคยจะเติม `self._line_snap_resync()` ตรงนี้ให้ "เหมือนอีก 2 ทาง"
                #   **แล้วถอนออก** เพราะ audit พบว่าทำให้แย่ลง:
                #   ① วัดแล้วในโหมด AllLayers การเพิ่มเลเยอร์ **ไม่ทำให้ลายเซ็นเปลี่ยนเลย**
                #      (ต่างจากโหมด Advanced ที่ QGIS ใส่แถว ILS ให้ชั้นใหม่) ⇒ ไม่มีอะไรต้อง resync
                #   ② ที่สำคัญกว่า: resync = "ยึดค่าปัจจุบันเป็นของเรา" ถ้าผู้ใช้เพิ่งเปลี่ยน
                #      tolerance/type เองแล้วบังเอิญมีเลเยอร์เพิ่มเข้ามา เราจะไปยึดค่าของเขา
                #      แล้ว _line_snap_return ก็จะ "ปิดแม่เหล็ก" ทับตอนปิดหน้าต่าง
                #      (วัดแล้ว: ผู้ใช้เปลี่ยน tol 20->7 แล้ว _snap_sig_compatible = False = ปล่อยไว้ ซึ่งถูกแล้ว)
                #   ⇒ ทางนี้ **จงใจ** ไม่เหมือนอีก 2 ทาง เพราะทางนี้ return ก่อนเขียนคอนฟิก
                #      จึงไม่มี "ค่าที่เราเพิ่งเขียน" ให้ต้องจำ
                return                      # ไม่ได้อยู่ในโหมดที่เราตั้งไว้ ปล่อยของผู้ใช้ไว้
            work = [l for l in (prj.mapLayer(self.poly_cb.currentData()),
                                prj.mapLayer(self.point_cb.currentData())) if l]
            if not work:
                # ★ 2.3.7 (review MT-12) — เลิก _line_snap_resync() ตรงนี้ (เดิม ★ 3 ก.ย. 69): _snap_sig_compatible ไม่สนแถวที่มีฝั่งเดียว
                #   ซึ่งครอบกรณี "QGIS เติมแถวให้ชั้นใหม่" อยู่แล้ว ⇒ resync ไม่จำเป็น และยังยึดค่าที่ผู้ใช้เพิ่งแก้ระหว่างยืมแม่เหล็ก
                #   เป็นของปลั๊กอิน ⇒ ปิดหน้าต่างวาดเส้นแล้วแม่เหล็กถูกปิดทับค่าของเขา
                return
            work += self._ct_layers(exclude=work)
            work += self._l1_pending_layers(exclude=work)       # ★ 2.5.1 ชั้น L1 รอจด (โปรเจค V7)
            work += self._line_tool_layers(exclude=work)
            keep = {l.id() for l in work if l}
            known = getattr(self, "_snap_known_lids", None)
            if known is None:
                known = set(keep)
            # ★★ 2 ก.ย. 69 — ปิดเฉพาะ "ชั้นที่เพิ่งโผล่มาใหม่" เท่านั้น
            #   ห้ามล้าง ILS ทั้งชุดแล้วเขียนใหม่ (เคยทำแล้วเป็น regression):
            #   จะไปลบชั้นอ้างอิงที่พนักงานเปิด snap ไว้เอง และดัน tolerance/type ของเขาทิ้ง
            #   หน้าที่ตรงนี้มีอย่างเดียว: อย่าให้ชั้นที่เพิ่งเปิดเข้ามากลายเป็นเป้า snap เอง
            changed = False
            # ★ 2.3.7 (review UX-32) — ชั้นทำงานที่ "เพิ่งโผล่ใหม่" (ไม่อยู่ในรายชื่อตอนกดเครื่องมือ เช่นถอดชั้นแปลงแล้วเพิ่มกลับ = id ใหม่)
            #   ที่แถวปิดอยู่/ยังไม่มีแถว ⇒ เปิดด้วยค่าเดียวกับ setup_snapping (VertexAndSegment 20 px) · ชั้นทำงานเดิมไม่แตะ (ผู้ใช้อาจปิดเอง)
            #   🔴 ห้ามเรียก setup_snapping() จากทางนี้: _topo_guard เป็นกล่อง modal + ล้าง ILS ทั้งชุด
            on = QgsSnappingConfig.IndividualLayerSettings(
                True, QgsSnappingConfig.VertexAndSegment, 20, QgsTolerance.Pixels)
            for lyr in work:
                if lyr.id() in known or not isinstance(lyr, QgsVectorLayer) or not lyr.isSpatial():
                    continue
                st = config.individualLayerSettings(lyr)     # overload รายชั้น บน config ที่ดึงสด (คำเตือน SIGSEGV ใน _snap_sig)
                if st.valid() and st.enabled():
                    continue
                config.setIndividualLayerSettings(lyr, on)
                changed = True
            # ★ 2.3.7 (review UX-33) — ชั้นที่เพิ่งโผล่มาใหม่: ปิดแค่ "สวิตช์เปิด/ปิด" ของแถว (คง type/tolerance ที่ QGIS/ผู้ใช้ตั้งไว้)
            #   เดิมทับทั้งแถวเป็น Vertex/0 px ⇒ ผู้ใช้ติ๊กเปิดเองทีหลังแล้ว snap ไม่ติดโดยไม่มีอะไรบอก (และแถวนี้ติดลง .qgz)
            #   ขัด docstring ของเมธอดนี้เอง ("ไม่แตะ tolerance/type") · กรองชนิดชั้นแทนการพึ่ง exception
            for lid, lyr in list(prj.mapLayers().items()):
                if lid in keep or lid in known:
                    continue
                if not isinstance(lyr, QgsVectorLayer) or not lyr.isSpatial():
                    continue
                st = config.individualLayerSettings(lyr)
                if not (st.valid() and st.enabled()):
                    continue              # ไม่มีแถว/ปิดอยู่แล้ว ไม่ต้องแตะ
                st.setEnabled(False)
                config.setIndividualLayerSettings(lyr, st)
                changed = True
            self._snap_known_lids = set(known) | set(prj.mapLayers().keys())
            if not changed:
                return                    # ★ 2.3.7 (MT-12) — ไม่ resync (ดูทางออกข้างบน)
            self._write_snap_config(prj, config)
        except Exception:
            _log_exc("_reapply_snap_limit: ตั้งรายชื่อชั้นที่ snap ได้ใหม่ไม่สำเร็จ", once_key="_reapply_snap_limit")  # ★ ER-03

    def _write_snap_config(self, prj, config):
        """เขียนค่าแม่เหล็กโดยไม่ทำให้โปรเจกต์ขึ้นว่ามีการแก้ไข + อัปเดตลายเซ็นที่ยืมไว้ (หน้าต่างวาดเส้น)
        ★ rc5 แยกจาก _reapply_snap_limit ให้ _on_tree_visibility ใช้ทางเดียวกัน (เดิมอยู่ในเมธอดนั้น · ข้อความเดิมทุกบรรทัด)"""
        _sig_ก่อน = self._snap_sig(prj.snappingConfig()) if getattr(self, "_line_snap_borrowed", False) else None
        was_dirty = prj.isDirty()
        prj.setSnappingConfig(config)
        if not was_dirty:
            prj.setDirty(False)
        # ★ ที่นี่ "ไม่" ปล่อยการยืมเหมือน setup_snapping — เพราะไม่ใช่การกดเครื่องมือใหม่
        #   เป็นแค่การรักษารายชื่อชั้นให้ถูกต้องระหว่างที่เครื่องมือเดิมยังทำงานอยู่
        #   แต่เราเพิ่งเขียนค่า snapping ไป ⇒ ต้องอัปเดต "ลายเซ็นที่จำไว้" ให้ตรงด้วย
        #   ไม่งั้นตอนปิดหน้าต่างวาดเส้นจะเข้าใจผิดว่ามีคนอื่นมาตั้งค่า แล้วไม่ยอมคืน
        #   ⇒ ค่าที่พนักงานตั้งเอง (ปิดแม่เหล็ก) จะถูกทับค้างถาวร
        # ★ 2.3.7 (review MT-12) — อัปเดตเฉพาะเมื่อ "ก่อนเราเขียน" ค่ายังเป็นของเรา (เข้ากันได้กับที่จำไว้)
        #   ถ้าผู้ใช้เพิ่งแก้ค่าเองระหว่างยืมแม่เหล็ก ⇒ ไม่ยึดค่าของเขามาเป็นของเรา (_line_snap_return จะปล่อยไว้ ไม่ปิดแม่เหล็กทับ)
        _se = []
        if getattr(self, "_line_snap_borrowed", False) and self._snap_sig_compatible(
                getattr(self, "_line_wrote_snap", None), _sig_ก่อน, _se):
            self._line_wrote_snap = self._snap_sig(prj.snappingConfig())
        if _se:                       # ★ rc1 (F8 · §5.1 ER-09) เทียบลายเซ็นล้มระหว่างยืมแม่เหล็ก ⇒ ขึ้นแถบ (เดิมมีแค่ Log)
            self._qgz_leftover_warn("แม่เหล็ก (snapping) ที่ปลั๊กอินเปิดให้หน้าต่างวาดเส้นอาจไม่ถูกคืน — ถ้าบันทึกโปรเจกต์ ค่าแม่เหล็กนี้จะติดไปในไฟล์ · "
                "ตรวจ/ปิดแม่เหล็กเองก่อนบันทึกโปรเจกต์")

    # ★ 2.5.1 (เจ้าของงาน 30 ต.ค. 69 "ทำโปรเจค V7 เพิ่ม layer L1_รอจด และทำให้ปลั๊กอินรองรับการ snap ด้วย") — ชั้น L1 รอจด
    #   = ตาราง <สาขา>_L1_TEMP (แปลง L1 รอจดที่ย้ายออกจากตารางแปลง 25 ต.ค.) · <สาขา>_L1_TEMP_POINT (หมุดของมัน) · พนักงานอ่านได้อย่างเดียว
    #   setup_snapping จำกัด snap เฉพาะชั้นทำงาน ⇒ เดิมชั้นนี้ถูกปิด snap ทุกครั้งที่กดเครื่องมือของปลั๊กอิน (ตั้งในโปรเจคไว้ก็ไม่ติด)
    _L1_PENDING_TBL = re.compile(r"[A-Za-z][A-Za-z0-9]*_L1_TEMP(?:_POINT)?")

    def _l1_pending_layers(self, exclude=(), visible_only=True):
        """ชั้น L1 รอจดในโปรเจกต์ — ให้ snap ติดตอนแก้ไขแบบชั้น CT (ดูดมุม/ขอบแปลงที่รอจดเมื่อขึ้นรูปแปลงติดกัน)
        หาจากตารางของชั้น PostGIS (<สาขา>_L1_TEMP / _L1_TEMP_POINT) หรือชื่อชั้นขึ้นต้น "L1_รอจด" (ชั้นใน V7 · ชั้นที่ผู้ใช้เพิ่มเอง)
        เฉพาะชั้นเวกเตอร์ที่มีเรขาคณิต · ไม่ซ้ำกับชั้นที่เลือกในกล่องปลั๊กอินอยู่แล้ว · ไม่ทำให้เป็นชั้นทำงาน (แก้ไม่ได้อยู่แล้ว)
        ★ rc5 (ผลตรวจ Windows rc4 ⚪1) visible_only ⇒ เฉพาะชั้นที่เปิดแสดงในแผงชั้น (ปิดชั้น = ไม่ดูด) · ตาราง PostGIS เฉพาะ schema public
        (rc4 รับตารางชื่อเดียวกันใน schema อื่น เช่นสำเนา/สำรอง)"""
        out = []
        ex = {l.id() for l in exclude if l}
        try:
            for l in QgsProject.instance().mapLayers().values():
                if l.id() in ex or not isinstance(l, QgsVectorLayer) or not l.isSpatial():
                    continue
                tbl = ""
                if l.providerType() == "postgres":
                    try:
                        _u = QgsDataSourceUri(l.source())
                        tbl = _u.table() if (_u.schema() or "public") == "public" else ""
                    except Exception:
                        tbl = ""
                if self._L1_PENDING_TBL.fullmatch(tbl or "") or l.name().strip().startswith("L1_รอจด"):
                    if visible_only and not self._tree_visible(l):
                        continue
                    out.append(l)
        except Exception:
            pass
        return out

    @staticmethod
    def _tree_node_layer_ids(node):
        """★ rc6 ⚪2 — id ชั้นใต้โหนดแผงชั้นที่เปลี่ยน (โหนดชั้น ⇒ ชั้นเดียว · กลุ่ม ⇒ ทุกชั้นในกลุ่ม) · ไม่รู้โหนด ⇒ None (ทำทุกชั้นแบบเดิม)"""
        if node is None:
            return None
        try:
            from qgis.core import QgsLayerTree
            if QgsLayerTree.isLayer(node):
                return {node.layerId()}
            if QgsLayerTree.isGroup(node):
                return {n.layerId() for n in node.findLayers()}
        except Exception:
            pass
        return None

    @staticmethod
    def _tree_visible(lyr):
        """★ rc5 ⚪1 — ชั้นเปิดแสดงในแผงชั้นไหม (รวมกลุ่มแม่) · ไม่อยู่ในแผงชั้น/อ่านไม่ได้ ⇒ ถือว่าเปิด (แบบเดิม)"""
        try:
            node = QgsProject.instance().layerTreeRoot().findLayer(lyr.id())
            return node is None or bool(node.isVisible())
        except Exception:
            return True

    def _on_tree_visibility(self, node=None, *_a):
        """★ 2.5.0 rc5 (ผลตรวจ Windows rc4 ⚪1 · ใบสั่ง rc4 "เปิด-ปิดชั้นระหว่างใช้ ⇒ snap ตามสถานะ") — เปิด/ปิดชั้น L1_รอจด ในแผงชั้น
        ระหว่างที่เครื่องมือของปลั๊กอินอยู่บนแคนวาส (โหมด Advanced ที่เราตั้ง) ⇒ แถวแม่เหล็กของชั้นนั้นเปิด/ปิดตาม ·
        แตะเฉพาะแถวของชั้น L1 รอจด (ชั้นอื่น/ค่าของผู้ใช้ไม่แตะ · ไม่ใช่ _reapply_snap_limit ทั้งชุด) · เครื่องมือไม่ทำงาน ⇒ ไม่แตะเลย"""
        if not getattr(self, "_alive", True):
            return
        try:
            tool = getattr(self, "temp_tool", None)
            canvas = self.iface.mapCanvas()
            if tool is None or canvas is None or canvas.mapTool() is not tool:
                return
            prj = QgsProject.instance()
            config = prj.snappingConfig()
            if int(config.mode()) != int(QgsSnappingConfig.AdvancedConfiguration):
                return
            work = [l for l in (prj.mapLayer(self.poly_cb.currentData()), prj.mapLayer(self.point_cb.currentData())) if l]
            if not work:
                return
            on = QgsSnappingConfig.IndividualLayerSettings(True, QgsSnappingConfig.VertexAndSegment, 20, QgsTolerance.Pixels)
            # ★ rc6 (ผลตรวจ Windows rc5 ⚪2) เปิด-ปิดชั้นใดก็ได้ ⇒ rc5 วนทุกชั้น L1 รอจด: แถวที่ผู้ใช้ปิดเองถูกเปิดคืน + tolerance กลับเป็น 20 px
            #   ⇒ แตะเฉพาะชั้นใต้โหนดที่เปลี่ยน (ชั้นเดียว/ทั้งกลุ่ม) · แถวที่มีอยู่แล้ว ⇒ setEnabled อย่างเดียว (คง type/tolerance/หน่วย) ·
            #   ไม่มีแถว ⇒ ค่าตั้งต้นของ setup_snapping (VertexAndSegment 20 px)
            ids = self._tree_node_layer_ids(node)
            changed = False
            for lyr in self._l1_pending_layers(exclude=work, visible_only=False):
                if ids is not None and lyr.id() not in ids:
                    continue
                st = config.individualLayerSettings(lyr)
                if self._tree_visible(lyr):
                    if not st.valid():
                        config.setIndividualLayerSettings(lyr, on)
                        changed = True
                    elif not st.enabled():
                        st.setEnabled(True)
                        config.setIndividualLayerSettings(lyr, st)
                        changed = True
                elif st.valid() and st.enabled():
                    st.setEnabled(False)                     # คง type/tolerance ของแถว (แบบชั้นที่เพิ่งโผล่ · UX-33)
                    config.setIndividualLayerSettings(lyr, st)
                    changed = True
            if changed:
                self._write_snap_config(prj, config)
        except Exception:
            _log_exc("_on_tree_visibility: แม่เหล็กชั้น L1 รอจดตามการเปิด-ปิดชั้นไม่สำเร็จ", once_key="_on_tree_visibility")

    def _ct_layers(self, exclude=()):
        """ชั้นหมุดหลักฐาน (CT / control point) ในโปรเจกต์ — เอาไว้ให้ snap ติดตอนแก้ไข
        หาแบบอัตโนมัติจากชื่อชั้น (ชั้นที่ส่งมอบชื่อ CT_<สาขา>; ต้นทางชื่อ <สาขา>_PointXY)
        เอาเฉพาะชั้นจุด และไม่ซ้ำกับชั้นที่เลือกไว้ในกล่องปลั๊กอินอยู่แล้ว
        (จำกัดด้วยชื่อ ไม่ใช่เอาทุกชั้นจุด — ไม่งั้นจะเสียประโยชน์ของการจำกัด snap เฉพาะชั้นทำงาน)"""
        out = []
        ex = {l.id() for l in exclude if l}
        try:
            for l in QgsProject.instance().mapLayers().values():
                if l.id() in ex:
                    continue
                try:
                    if l.geometryType() != QgsWkbTypes.PointGeometry:
                        continue
                except Exception:
                    continue        # raster/ชั้นที่ไม่มี geometryType
                n = l.name().strip().upper()
                if n.startswith("CT_") or n == "CT" or "POINTXY" in n.replace("_", ""):
                    out.append(l)
        except Exception:
            pass
        return out

    # ★ 28 ส.ค. 69 — ด่านเตือน "Topological Editing"
    #   อาการที่พนักงานแจ้ง: ใช้ร่วมกับปลั๊กอินวาดเส้นแล้ว "node งอกเพิ่มในรูปแปลงเอง"
    #   ต้นตอ **ไม่ได้อยู่ในโค้ดปลั๊กอินตัวใด** แต่เป็นระบบ Topological Editing ของ QGIS เอง:
    #     เมื่อเปิดไว้ การลากมุม/วาดฟีเจอร์ จะให้ QGIS แทรก vertex ให้ "ทุกชั้นที่มองเห็นบนจอ
    #     ที่เปิดโหมดแก้ไขอยู่" ตลอดแนวขอบร่วม (QgsMapToolAddFeature -> addTopologicalPointsToLayers)
    #   หลักฐานจริง 28 ส.ค. คลองหลวง 09:33:59 — ลากครั้งเดียว 11 แปลงเรียงติดกันได้มุมเพิ่มใบละ 2 มุม
    #     เนื้อที่เปลี่ยน 0.0000% จุดศูนย์ถ่วงขยับ 0.000 ม. และ **ไม่มีหมุดตามมาเลยสักตัว**
    #   ⇒ ผิดกติกาเหล็ก "ทุก node ต้องมีหมุด" · แปลงที่โดนมี node ไร้หมุด 15.2% เทียบค่าฐาน 5.0%
    #   จึงต้องเตือน ไม่ปิดให้เงียบ ๆ (ค่านี้เป็นของโปรเจกต์ ผู้ใช้อาจตั้งใจเปิด)
    # ★ 28 ส.ค. 69 — บังคับปิด Topological Editing ทุกครั้งที่เริ่มใช้เครื่องมือของปลั๊กอิน
    #
    #   ทำไมถึง "บังคับปิด" ไม่ใช่แค่เตือน:
    #     งานนี้มีกติกาเหล็ก "ทุก node ต้องมีหมุด" แต่ Topological Editing สร้าง node
    #     ที่ไม่มีหมุดเสมอโดยธรรมชาติของมัน — QGIS แทรกมุมให้แปลงข้างเคียงตลอดแนวขอบร่วม
    #     แต่ไม่มีใครสร้างหมุดให้ => เข้ากันไม่ได้เชิงโครงสร้าง ไม่ใช่แค่ "ตั้งค่าไม่เหมาะ"
    #     หลักฐาน 28 ส.ค. คลองหลวง: แปลงที่โดนมี node ไร้หมุด 15.2% เทียบค่าฐาน 5.0%
    #     มุมเปล่า 21 จุดเรียงอยู่บนเส้นที่พนักงานวาดไว้ 2 เส้น ยาว 97 ม. คลาดเคลื่อน <1.3 ซม.
    #   ทำไมไม่ใช้กล่องถาม:
    #     ทดสอบแล้ว ถ้าถามแล้วพนักงานตอบ No ครั้งเดียว จะเงียบไปทั้งเซสชัน
    #     (กดเครื่องมืออีก 6 ครั้งก็ไม่เตือนอีก) = ความเสียหายเดินต่อโดยไม่มีใครทัก
    #   ทำไมไม่ดักสัญญาณตอนผู้ใช้กดเปิด:
    #     จะกลายเป็นแย่งปุ่มกับผู้ใช้ไม่จบ — ปล่อยให้เขาเปิดได้ แล้วค่อยปิดตอนเขากดใช้เครื่องมือ
    #     ★ ถ้าเขาตั้งใจจะใช้จริง ก็ไปเปิดใหม่เองได้ (เจ้าของงานตัดสินใจแบบนี้)
    #   🔴 ห้ามปิดเงียบ — ต้องขึ้นแถบข้อความบอกเหตุผลทุกครั้ง
    def _topo_guard(self):
        try:
            prj = QgsProject.instance()
            if not prj.topologicalEditing():
                return
            # ★★ 3 ก.ย. 69 — setTopologicalEditing() ทำให้โปรเจกต์กลายเป็น "มีการแก้ไข"
            #   ⇒ ข้อ B3 ของใบตรวจ ("กดปุ่มแล้วปิดโปรแกรม ต้องไม่ถูกถามให้บันทึก") พังทันที
            #     บนไฟล์อำเภอทุกไฟล์ที่บันทึกโดยเปิด Topological Editing ไว้
            #   เราปิดค่านี้เพื่อความปลอดภัยของข้อมูลระหว่างใช้เครื่องมือ ไม่ใช่การแก้โปรเจกต์
            #   ของพนักงาน จึงต้องไม่นับเป็นการแก้ (เหมือนที่ทำกับ snapping ที่ยืมมา)
            _was_dirty = prj.isDirty()
            prj.setTopologicalEditing(False)
            if not _was_dirty:
                prj.setDirty(False)
                try:
                    QtCore.QTimer.singleShot(0, self._line_undirty)
                except Exception:
                    pass
        except Exception:
            return
        # 🔴 ต้องเป็น "กล่องเด้ง" ไม่ใช่แถบข้อความ — แถบข้อความบนขอบแคนวาสถูกมองข้ามง่าย
        #   ไม่รบกวน เพราะพอปิดให้แล้วครั้งต่อไปจะไม่เจออีก (เด้งเฉพาะตอนที่มันเปิดอยู่จริง)
        try:
            self._ask(
                QtWidgets.QMessageBox.Information,
                "ปิด Topological Editing ให้แล้ว",
                "พบว่าโปรเจกต์เปิด <b>Topological Editing</b> อยู่ ปลั๊กอินจึงปิดให้อัตโนมัติ<br><br>"
                "ค่านี้ทำให้ QGIS <b>แทรกมุมให้แปลงข้างเคียงทุกใบตลอดแนวขอบร่วมเอง</b> "
                "และมุมที่แทรกมานั้น <b>ไม่มีหมุด</b> ซึ่งผิดกติกา &quot;ทุก node ต้องมีหมุด&quot;<br><br>"
                "ถ้าต้องการใช้จริง ให้เปิดเองอีกครั้งหลังเลิกใช้เครื่องมือของปลั๊กอิน")
        except Exception:
            pass
        try:
            self.iface.messageBar().pushMessage(
                "Topological Editing", "ปิดให้แล้ว (ดูรายละเอียดในกล่องที่เพิ่งขึ้น)",
                level=1, duration=8)
        except Exception:
            pass

    def setup_snapping(self):
        """ตั้ง snap ให้เครื่องมือของปลั๊กอิน: เปิด snap · โหมด Advanced · เฉพาะชั้นแปลง/หมุด/CT/ชั้นของหน้าต่างวาดเส้น (VertexAndSegment 20 px)
        ★ 2.3.7 (review DI-23 · เจ้าของงานตัดสิน 3 ต.ค. 69: คงพฤติกรรมนี้) — ค่าที่ตั้ง "ไม่ใช่ของชั่วคราว": ค้างทั้งเซสชัน
          (ออกจากเครื่องมือ/ปิดปลั๊กอินแล้วไม่คืนค่าเดิม) และถ้ามีคนบันทึกโปรเจกต์ ค่านี้ถูกเขียนลงไฟล์โปรเจกต์ไปด้วย
          ที่ยืมแล้วคืนจริงมีแค่ของหน้าต่างวาดเส้น (_line_snap_borrow / _line_snap_return)"""
        self.canvas = self.iface.mapCanvas()
        config = QgsProject.instance().snappingConfig()
        if not config.enabled():
            config.setEnabled(True)
            # ปรับความแรงในการดูด (Tolerance) เป็น 15-20 pixels
            config.setTolerance(20)
            config.setUnits(QgsTolerance.Pixels)
            # ให้ Snap ทั้งจุด (Vertex) และเส้น (Segment)
            config.setType(QgsSnappingConfig.VertexAndSegment)
        # จำกัด snap เฉพาะชั้นแปลง+หมุดที่เลือกในปลั๊กอิน — ต้องตั้ง "ทุกครั้ง" ไม่ใช่เฉพาะตอน snapping เริ่มปิด
        # (เดิมโค้ดก้อนนี้อยู่ใน `if not config.enabled():` -> ถ้าโปรเจกต์/ผู้ใช้เปิด snapping ค้างไว้อยู่แล้ว
        #  (ปกติเป็น AllLayers) จะถูกข้ามทั้งก้อน -> QGIS สร้าง snap index ทุกชั้นในวิว = ช้ามากบนชั้น
        #  PostgreSQL ใหญ่ และไม่ re-target เมื่อผู้ใช้สลับ combo เลเยอร์)
        work = [l for l in (QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                            QgsProject.instance().mapLayer(self.point_cb.currentData())) if l]
        work += self._ct_layers(exclude=work)   # + ชั้นหมุดหลักฐาน CT ให้ snap ติดด้วย
        work += self._l1_pending_layers(exclude=work)   # ★ 2.5.1 + ชั้น L1 รอจด (โปรเจค V7) ให้ snap ติดด้วย
        work += self._line_tool_layers(exclude=work)   # + ชั้นเส้นที่วาดจากปลั๊กอินวาดเส้น&วัดระยะ
        # ★ 2.3.7 (review ER-03) — เดิมล้ม (หรือไม่มีชั้นทำงาน) ⇒ บังคับเป็น AllLayers เงียบ ๆ = โหมดที่ช้ามากบนชั้น PostGIS ใหญ่
        #   ซึ่งโค้ดข้างบนตั้งใจหลบ และทับโหมดที่ผู้ใช้ตั้งไว้ ⇒ ไม่มีชั้นทำงาน = ไม่แตะโหมด · ตั้งไม่สำเร็จ = คืนค่าเดิมของ
        #   โปรเจกต์ (ทิ้งที่ตั้งไปครึ่งทาง) + Log + เตือนครั้งเดียว
        if work:
            try:
                config.setMode(QgsSnappingConfig.AdvancedConfiguration)
                ils = QgsSnappingConfig.IndividualLayerSettings(
                    True, QgsSnappingConfig.VertexAndSegment, 20, QgsTolerance.Pixels)
                config.clearIndividualLayerSettings()   # ล้างชั้นของรอบก่อน (กันชั้นเก่าค้างเมื่อสลับ combo)
                for l in work:
                    config.setIndividualLayerSettings(l, ils)
            except Exception:
                _log_exc("setup_snapping: ตั้ง snap เฉพาะชั้นทำงานไม่สำเร็จ — คงค่า snap เดิมของโปรเจกต์",
                         once_key="setup_snapping")
                config = QgsProject.instance().snappingConfig()
                if not config.enabled():
                    config.setEnabled(True)
                    config.setTolerance(20)
                    config.setUnits(QgsTolerance.Pixels)
                    config.setType(QgsSnappingConfig.VertexAndSegment)
                self._push_once("_snap_fail_bar", "MLEP",
                                "ตั้งแม่เหล็ก (snap) เฉพาะชั้นแปลง/หมุดไม่สำเร็จ — ใช้ค่าแม่เหล็กเดิมของโปรเจกต์แทน "
                                f"(อาจช้าลงบนชั้นใหญ่) · {self._LOG_HINT}", level=1, duration=8)
        # ★ 2 ก.ย. 69 — การกดเครื่องมือต้องไม่ทำให้โปรเจกต์กลายเป็น "มีการแก้ไข"
        #   ★ 2.3.7 (review DI-23) — เดิมคอมเมนต์นี้บอกว่าค่าที่ตั้งเป็นของชั่วคราว ซึ่งไม่จริง: ไม่มีทางไหนคืนค่าเดิม
        #   และถ้าโปรเจกต์ถูกบันทึก (Ctrl+S) ค่าที่ตั้งตรงนี้ติดลงไฟล์ไปด้วย (เจ้าของงานยอมรับ 3 ต.ค. 69) — ที่ทำตรงนี้แค่ซ่อนธง
        #   "มีการแก้ไข" ไม่ได้คืนค่า · ไม่งั้นแค่กดปุ่มแรกของวัน พนักงานก็โดนถาม "บันทึกโปรเจกต์ไหม" ตอนปิด QGIS ทุกวัน
        #   และเสี่ยงกดบันทึกทับไฟล์กลางของอำเภอโดยไม่ได้ตั้งใจ
        _prj = QgsProject.instance()
        _was_dirty = _prj.isDirty()
        _prj.setSnappingConfig(config)
        if not _was_dirty:
            _prj.setDirty(False)
        # จำรายชื่อชั้นที่มีอยู่ ณ ตอนนี้ — ใช้แยกว่าชั้นไหน "เพิ่งเปิดเข้ามาทีหลัง"
        try:
            self._snap_known_lids = set(QgsProject.instance().mapLayers().keys())
        except Exception:
            _log_exc("setup_snapping: จำรายชื่อชั้นไม่สำเร็จ", once_key="ER-09:snap-known")   # ★ 2.4.0 (review ER-09)
            self._snap_known_lids = None

        # ★★ 2 ก.ย. 69 (blocker จาก audit) — เครื่องมือนี้เพิ่งตั้งค่า snapping เองแล้ว
        #   ⇒ "การยืม" ของหน้าต่างวาดเส้นถือว่าจบไปแล้วโดยนิยาม ต้องปล่อยทิ้งตรงนี้
        #
        #   ทำไมต้องมี: _line_snap_return ตัดสินความเป็นเจ้าของด้วยการเทียบลายเซ็น
        #   แต่เมื่อโปรเจกต์อยู่ในโหมด AdvancedConfiguration อยู่ก่อนแล้ว (ซึ่งเป็นสภาพ
        #   หลังพนักงานกดเครื่องมือ MLEP ครั้งแรกของ session) สิ่งเดียวที่ก้อนข้างบน
        #   เปลี่ยนคือ individualLayerSettings ⇒ ลายเซ็นออกมา "เท่าเดิมเป๊ะ"
        #   ⇒ _line_snap_return คิดว่ายังเป็นของตัวเอง แล้วทับกลับเป็น "ปิด snap"
        #   ⇒ คลิกปลายทางตกไปใช้พิกัดพิกเซลดิบ = เขียนพิกัดผิดลงฐานข้อมูลเงียบ ๆ
        #   (วัดได้ 14.14 ม. จากพลาดเมาส์ 4 px ที่ 2.5 ม./px)
        #
        #   🔴 ต้องล้าง "ที่นี่" ไม่ใช่แก้แค่ลายเซ็น เพราะลำดับจริงคือ
        #      setup_snapping() -> setMapTool() -> mapToolSet -> _map_tool_changed
        #      -> _line_snap_return  ⇒ ถ้าไม่ล้าง จะถูกคืนทับทุกครั้งที่สลับเครื่องมือ
        self._line_snap_borrowed = False
        self._line_wrote_snap = None

        self.snap_utils = self.canvas.snappingUtils()
        self.snap_indicator = QgsSnapIndicator(self.canvas)

        self._topo_guard()   # ★ เตือนถ้าโปรเจกต์เปิด Topological Editing อยู่
        
    # ★ 28 ส.ค. 69 — ด่านก่อนเริ่มเครื่องมือ: ต้องมีคีย์ที่จับคู่แปลงกับหมุดได้
    #   เหตุ (จำลองยืนยัน 28 ส.ค.): ถ้าชั้นหมุดไม่มีคอลัมน์ UTM/Cluster
    #     · process_selection สั่ง removeSelection() ฝั่งหมุด แล้วเตือนแค่ครั้งเดียว 6 วินาที
    #     · _procsel_key ถูกจำไว้ -> **กดครั้งที่ 2,3,4... เงียบสนิท ไม่มีข้อความอีกเลย**
    #     · เครื่องมือเดินหน้าต่อ -> ย้ายแปลงไปคนเดียว หมุดค้างที่เดิม
    #     · ด่าน _pairing_issues คืน None ทันที (ไม่มี tu) -> **ไม่มีอะไรกันเลยสักชั้น**
    #   เกิดจริงได้: ชั้น CT_<อำเภอ> มี schema คนละแบบ (ไม่มีคอลัมน์ UTM)
    #   ถ้าเผลอเลือกเป็น "ชั้นหมุด" ในคอมโบ จะเข้าเคสนี้พอดี
    #   ⇒ ห้ามเริ่มเครื่องมือที่แก้ geometry เลย (แนวเดียวกับที่ปฏิเสธเมื่อยังไม่ได้เลือกแปลง)
    def _pair_key_ok(self, tool_name="เครื่องมือนี้"):
        try:
            poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
            point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        except Exception:
            # ★ 2.3.7 (review AR-06-D) — ตรวจไม่ได้ = ไม่ให้เริ่ม (fail-closed) · เดิมคืน True "ให้ด่านเดิมจัดการ"
            #   แต่ start_interactive (Move/Rotate/Scale/Transform) ไม่มีด่านเดิมของชั้นหมุด ⇒ แปลงขยับฝ่ายเดียว
            self.iface.messageBar().pushMessage(
                f"{tool_name} — เริ่มไม่ได้", "อ่านชั้นแปลง/ชั้นหมุดที่เลือกไม่ได้ — เลือกชั้นข้อมูลใหม่แล้วลองอีกครั้ง",
                level=2, duration=8)
            return False
        if not poly_lyr or not point_lyr:
            # ★ 2.3.7 (review AR-06-D) — ขาดชั้นใดชั้นหนึ่ง = ไม่ให้เริ่ม + บอกชั้นที่ขาด (เดิมคืน True ⇒ ย้ายแปลงได้โดยไม่มีชั้นหมุด)
            _ขาด = " และ ".join(n for n, l in (("ชั้นแปลง", poly_lyr), ("ชั้นหมุด", point_lyr)) if not l)
            self.iface.messageBar().pushMessage(
                f"{tool_name} — เริ่มไม่ได้", f"ยังไม่ได้เลือก{_ขาด} — เลือกให้ครบทั้งชั้นแปลงและชั้นหมุดก่อน",
                level=1, duration=8)     # ★ 2.3.7 (review UX-35) คำแนะนำ ⇒ เหลือง (เดิมแดง)
            return False
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        if pu and tu:
            return True
        # ★ 2.3.7 (review UX-34) — เดิมบอก "UTM/Cluster" ทั้งที่ตรวจแค่ชื่อคอลัมน์ UTM · บอกชั้นที่ขาดแค่ชั้นเดียว · กดซ้ำแถบแดงซ้อนเป็นตั้ง
        #   ⇒ บอกคอลัมน์ที่ตรวจจริง + ทุกชั้นที่ขาดในข้อความเดียว + แถบเดียว (ถอดตัวเก่าก่อนขึ้นใหม่) · เงื่อนไขการปฏิเสธไม่เปลี่ยน
        ขาด = ([f"ชั้นแปลง '{poly_lyr.name()}'"] if not pu else []) + ([f"ชั้นหมุด '{point_lyr.name()}'"] if not tu else [])
        self._push_once(
            "_pair_key_bar", f"{tool_name} — เริ่มไม่ได้",
            " และ ".join(ขาด) + " ไม่มีคอลัมน์ UTM (utm / utm_code / utm_id) ที่ใช้จับคู่แปลงกับหมุด "
            "— ถ้าใช้ต่อ แปลงจะขยับไปโดยหมุดไม่ตาม และด่านตรวจก่อนบันทึกก็จะตรวจไม่ได้ "
            "กรุณาเลือกชั้นข้อมูลให้ถูกก่อน", level=1, duration=0)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
        return False

    # ============ ★ 2.3.7 ตัวช่วยของเครื่องมือขยับแปลง (Move/Rotate/Scale/Transform) และ Align ============
    def _crs_info(self, title, lyr):
        """★ 2.3.7 (b9 · ต่อจาก b5a DI-03) — ระบบพิกัดของแผนที่ต่างจากชั้นข้อมูล ⇒ แจ้งเบา ๆ (ฟ้า) ครั้งเดียวตอนเริ่มเครื่องมือ
        ว่าปลั๊กอินแปลงจุดที่คลิกเป็นพิกัดของชั้นให้เอง · b5a เอาคำเตือนเหลือง 15 วิ ออกเพราะแปลงถูกต้องแล้ว ⇒ เดิมไม่มีอะไรบอกเลย
        (พนักงานที่เห็นพิกัดบนแถบสถานะไม่ตรงกับในตารางจะได้ไม่ตกใจ) · ระบบเดียวกัน/ไม่รู้ระบบ = เงียบ"""
        try:
            mc = self._map_crs()
            lc = lyr.crs() if lyr is not None else None
            if mc is None or lc is None or not lc.isValid() or mc == lc:
                return
            self.iface.messageBar().pushMessage(
                title, f"ระบบพิกัดของแผนที่ ({mc.authid() or mc.description()}) ต่างจากชั้นข้อมูล "
                       f"({lc.authid() or lc.description()}) — ปลั๊กอินแปลงจุดที่คลิกเป็นพิกัดของชั้นให้เอง ผลถูกต้องตามปกติ",
                level=0, duration=6)
        except Exception:
            _log_exc("_crs_info: ตรวจระบบพิกัดไม่ได้", once_key="_crs_info")

    def _map_crs(self):
        """ระบบพิกัดของ "จุดบนแผนที่" (จุดที่คลิก · ตำแหน่งเมาส์ · กรอบที่ลาก) = ของแคนวาส · ไม่รู้ = None (ไม่แปลง)
        ★ 2.3.7 (review DI-03) — ใน QGIS จริงแคนวาสใช้ระบบเดียวกับโปรเจกต์เสมอ · แคนวาสไม่มีระบบ = แผนที่ไม่แปลงพิกัด
        (พิกัดบนจอ = พิกัดของชั้นอยู่แล้ว) ⇒ ตกไปใช้ของโปรเจกต์ แล้วค่อยถือว่าไม่ต้องแปลง"""
        for _get in (lambda: self.iface.mapCanvas().mapSettings().destinationCrs(),
                     lambda: QgsProject.instance().crs()):
            try:
                c = _get()
                if c is not None and c.isValid():
                    return c
            except Exception:
                pass
        return None

    def _m2l_cache_drop(self, *_a):
        """★ 2.4.0 (review DI-03) — ทิ้งตัวแปลงพิกัดจุดคลิกที่เก็บไว้ (_map_to_layer สร้างใหม่ตอนใช้ครั้งถัดไป)
        เรียกตอนล้าง/เปลี่ยนโปรเจกต์ และตอนระบบพิกัดหรือวิธีแปลง datum ของโปรเจกต์เปลี่ยน
        (QgsCoordinateTransform จำ transform context ของโปรเจกต์ ณ ตอนสร้าง — เทียบแค่คู่ CRS ไม่รู้ว่าวิธีแปลงเปลี่ยน)"""
        self._m2l_cache = None

    def _map_to_layer(self, pt, lyr):
        """จุดพิกัดแผนที่ → พิกัดของชั้น lyr (QgsPointXY) · แปลงไม่ได้ = โยน exception (ผู้เรียกต้องหยุด ห้ามใช้ค่าดิบ)

        ★ 2.3.7 (review DI-03) — เดิมเอาพิกัดที่คลิก (ระบบของโปรเจกต์) ไปบวก/หมุน/ย่อกับ geometry (ระบบของชั้น) ตรง ๆ
          ⇒ โปรเจกต์ที่ตั้งเป็น EPSG:4326 (เคยมีไฟล์สาขาแบบนี้จริง) คลิกห่างขอบ 2 ม. แต่หมุด+มุมแปลงเหวี่ยงไป 668 กม.
          ⇒ แปลงเป็นพิกัดของชั้น "ตอนคลิก" ทีละจุด (เปลี่ยนระบบพิกัดของแผนที่ระหว่างคลิกก็ยังถูก)
          เก็บตัวแปลงไว้ใช้ซ้ำ (เงาตัวอย่างเรียกทุกเฟรม) โดยเทียบ "ตัวระบบพิกัด" ไม่ใช่ authid (ระบบที่กำหนดเองไม่มี authid)"""
        src = self._map_crs()
        dst = lyr.crs() if lyr is not None else None
        if src is None or dst is None or not dst.isValid() or src == dst:
            return QgsPointXY(pt.x(), pt.y())
        c = getattr(self, "_m2l_cache", None)
        if c is None or not (c[0] == src and c[1] == dst):
            c = (src, dst, QgsCoordinateTransform(src, dst, QgsProject.instance()))
            self._m2l_cache = c
        q = c[2].transform(QgsPointXY(pt.x(), pt.y()))
        if not (math.isfinite(q.x()) and math.isfinite(q.y())):
            raise ValueError("แปลงพิกัดไม่ได้")
        return QgsPointXY(q.x(), q.y())

    def _pair_crs_ok(self, title, poly, point):
        """★ 2.3.7 (review DI-03) — ชั้นแปลงกับชั้นหมุดต้องเป็นระบบพิกัดเดียวกัน
        (เครื่องมือชุดนี้ขยับสองชั้นด้วยค่าชุดเดียวกัน และด่านจับคู่แปลง-หมุดเทียบพิกัดตรง ๆ) ไม่ตรง = ไม่เริ่ม/ไม่ทำ"""
        try:
            same = poly is None or point is None or poly.crs() == point.crs()
        except Exception:
            same = False
        if not same:
            try:
                self.iface.messageBar().pushMessage(
                    title, "ชั้นแปลงกับชั้นหมุดใช้ระบบพิกัด (CRS) คนละระบบ — ขยับให้ตรงกันไม่ได้ ยังไม่ได้แก้อะไร "
                           "(ตั้ง CRS ของสองชั้นให้ตรงกันก่อน)", level=1, duration=10)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            except Exception:
                pass
        return same

    @staticmethod
    def _field_index(fields, names):
        """index ของฟิลด์แรกที่ชื่อ (ตัวพิมพ์เล็ก) อยู่ใน names; -1 ถ้าไม่พบ
        names = str (ชื่อเดียว) หรือ set ของชื่อ"""
        if isinstance(names, str):
            names = {names}
        for i, f in enumerate(fields):
            if f.name().lower() in names:
                return i
        return -1

    # ---------- ★ 2.4.0 (review DI-11) ชั้นทำงานของด่าน L1 — ไม่ต้องเปิดแผงปลั๊กอิน · ทุกคู่ในโปรเจกต์ ----------
    #   เดิมด่านของปุ่มบันทึก QGIS ดูแค่ "คู่ในคอมโบ" ⇒ ① ก่อนกดไอคอนปลั๊กอินครั้งแรก (ยังไม่มีคอมโบ/ยังไม่ต่อ hook) บันทึกเงียบ
    #   ② โปรเจกต์หลายสาขา / ชั้นที่เปิดจากตารางเดียวกันซ้ำ: แก้แปลง L1 ในชั้นที่ไม่ได้เลือกในคอมโบ (รวม topological editing
    #   ที่ลากมุม L1 ของสาขาข้างเคียงที่เปิดแก้ไขอยู่) บันทึกเงียบ
    @staticmethod
    def _geom_role(lyr):
        """0 = ชั้น polygon · 1 = ชั้น point · อื่น ๆ (เส้น/raster/ไม่มีรูป) = None"""
        try:
            gt = lyr.geometryType()
        except Exception:
            return None
        if gt == QgsWkbTypes.PolygonGeometry:
            return 0
        return 1 if gt == QgsWkbTypes.PointGeometry else None

    def _combo_pair(self):
        """(ชั้นแปลง, ชั้นหมุด) ที่เลือกในคอมโบ · ยังไม่เคยเปิดแผง/ไม่ได้เลือก/คอมโบถูกลบแล้ว = None"""
        prj = QgsProject.instance()
        out = []
        for _n in ("poly_cb", "point_cb"):
            try:
                _d = getattr(self, _n).currentData()
                out.append(prj.mapLayer(_d) if _d else None)
            except Exception:
                out.append(None)
        return tuple(out)

    def _layer_branch(self, lyr, suffix):
        """★ rc2 (audit A5-04) — สาขาของชั้นจากชื่อในสารบัญ '<สาขา>_POLYGON/_POINT' · ไม่ตรงรูปแบบ ⇒ จากชื่อตารางของ provider"""
        try:
            b = self._branch_of(lyr.name(), suffix)
        except Exception:
            b = None
        return b if b is not None else self._branch_of(self._layer_table_name(lyr), suffix)

    @staticmethod
    def _layer_table_name(lyr):
        """★ rc2 (audit A5-04) — ชื่อตารางที่ชั้นเปิดอยู่ (PostGIS/SpatiaLite = table · GPKG/ไฟล์ OGR = layername) · ไม่รู้ = ''"""
        try:
            prov = lyr.providerType()
            if prov in ("postgres", "spatialite"):
                from qgis.core import QgsDataSourceUri
                return QgsDataSourceUri(lyr.source()).table() or ""
            from qgis.core import QgsProviderRegistry
            d = QgsProviderRegistry.instance().decodeUri(prov, lyr.source()) or {}
            return str(d.get("layerName") or d.get("table") or "")
        except Exception:
            return ""

    def _sheet_cols(self, lyr):
        """index ของช่องระวาง (UTMMAP1-4 + LANDNO) · ไม่มีคอลัมน์ = -1 (_fld_idx ไม่สนตัวพิมพ์ แบบ _sheet_str)"""
        fl = lyr.fields()
        return [_fld_idx(fl, n) for n in self._SHEET_COLS]

    @staticmethod
    def _sheet_of(feat, cols, utm=None):
        """ชื่อแปลงจากฟีเจอร์ที่อ่านมาพร้อมช่องระวาง (cols จาก _sheet_cols) · ไม่มีเลขระวาง ⇒ UTM ⇒ '(ไม่มีเลขระวาง)'"""
        s = _sheet_label(*[(feat.attribute(i) if i >= 0 else None) for i in cols])
        return s or (f"UTM {_txt(utm)}" if _txt(utm) else "(ไม่มีเลขระวาง)")

    def _name_list(self, title, labels, limit=5):
        """★ 2.3.7 (review UX-06) — รายชื่อแปลงแบบสั้น: 5 รายการแรก + 'อีก N แปลง' · รายการเต็มลง Log แท็บ MLEP"""
        labels = sorted(labels, key=_natkey)
        short = " · ".join(labels[:limit])
        if len(labels) > limit:
            short += f" · อีก {len(labels) - limit:,} แปลง (รายชื่อทั้งหมดอยู่ใน Log Messages แท็บ MLEP)"
        try:
            QgsMessageLog.logMessage(f"{title}: {len(labels):,} แปลง — " + " · ".join(labels), "MLEP", Qgis.Info)
        except Exception:
            pass
        return short

    def _read_attr(self, lyr, fids, idx):
        """ค่าดิบของคอลัมน์เดียว {fid: ค่า} ในคำขอเดียว (NoGeometry · ปิดตัวอ่านเสมอ)"""
        out = {}
        req = (QgsFeatureRequest().setFilterFids(list(fids)).setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([idx]))
        it = lyr.getFeatures(req)
        try:
            for f in it:
                out[f.id()] = f.attribute(idx)
        finally:
            it.close()
        return out

    def _write_attr(self, lyr, label, todo, idx, new, old):
        """★ 2.3.7 (review PF-02 / DI-28) — เขียนคอลัมน์เดียวให้หลายแถวเป็น 1 undo step (ชั้นต้องเปิดแก้ไขแล้ว)
        · ส่งค่าเดิมที่อ่านมาแล้ว (old = {fid: ค่าดิบ}) เป็น oldValue ⇒ Undo ไม่ต้องอ่านฐานทีละแถว
          (review วัดบน PostGIS: undo 8,000 แถวค้าง ~7 วินาทีบน UI) · ผู้เรียกคัดแถวที่ค่าเท่าเดิมออกแล้ว (todo)
        · นับเฉพาะผล True · สำเร็จ 0 แถว ⇒ destroyEditCommand (ไม่ดัน undo step ว่าง · ชั้นไม่กลายเป็น "มีการแก้ไข")
        คืน (จำนวนที่เขียนได้, exception หรือ None) — exception = ย้อนทั้ง command แล้ว"""
        lyr.beginEditCommand(label)
        n = 0
        try:
            for fid in todo:
                if lyr.changeAttributeValue(fid, idx, new, old.get(fid)):
                    n += 1
        except Exception as e:
            _log_exc(f"{label}: เขียนชั้น '{lyr.name()}' ไม่สำเร็จ — ย้อนทั้งคำสั่งแล้ว", Qgis.Critical)   # ★ 2.3.7 (ER-03/ER-06)
            lyr.destroyEditCommand()
            return 0, e
        if n:
            lyr.endEditCommand()
        else:
            lyr.destroyEditCommand()
        return n, None

    def _tool_layers_ok(self, tool_poly, title, tool_point=None):
        """ยืนยันว่า "เลเยอร์ตอนกดเครื่องมือ" กับ "เลเยอร์ในคอมโบตอนนี้" ยังเป็นตัวเดียวกัน

        ★ 2026-08-06: เครื่องมือ node (แก้ชื่อ/ลบ node/Add Node) ส่ง fid + พิกัดที่คิดจาก "เลเยอร์ตอน arm"
          แต่ตัว execute กลับไปอ่านเลเยอร์จากคอมโบใหม่ · ถ้าผู้ใช้สลับคอมโบระหว่างกดปุ่มกับคลิก
          = เอา fid/พิกัดของชั้นหนึ่งไปเขียนอีกชั้น (คนละ CRS ก็เป็นไปได้) -> ข้อมูลพังเงียบ ๆ
          คืน (poly, point) ถ้าตรงกัน · None ถ้าไม่ตรง (แจ้งให้กดปุ่มใหม่)"""
        poly = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if poly is None or point is None:
            self.iface.messageBar().pushMessage(                     # ★ 2.3.7 (review UX-35) คำแนะนำ ⇒ เหลือง (เดิมแดง)
                title, "ยังไม่ได้เลือกชั้นแปลง/ชั้นหมุดให้ครบ", level=1, duration=6)
            return None
        # ★ 2.3.7 (review DI-10) — เดิมอ่านชั้นหมุดของเครื่องมือจาก self.temp_tool เท่านั้น
        #   หลังออกจากโหมด 📐 วาดเส้น temp_tool = None (เครื่องมือเดิมกลับมาบนแคนวาส แต่ไม่ได้ผูกกลับ)
        #   ⇒ ไม่ได้เทียบชั้นหมุดเลย ⇒ สลับคอมโบชั้นหมุดแล้วคลิกต่อ = เขียนลงชั้นหมุดอีกชั้นเงียบ ๆ
        #   ⇒ รับจากผู้เรียกได้ (tool_point) · ไม่ส่ง = temp_tool แล้วตามด้วย "เครื่องมือที่อยู่บนแคนวาสจริง"
        #   ชั้นที่ถูกลบไปแล้ว (RuntimeError) = ไม่ตรง (เดิมหลุดเป็น exception)
        if tool_point is None:
            tool_point = getattr(getattr(self, "temp_tool", None), "point_lyr", None)
        if tool_point is None:
            try:
                tool_point = getattr(self.iface.mapCanvas().mapTool(), "point_lyr", None)
            except Exception:
                tool_point = None
        _gone = False
        try:
            _bad = ((tool_poly is not None and tool_poly.id() != poly.id()) or
                    (tool_point is not None and tool_point.id() != point.id()))
        except RuntimeError:
            # ★ 2.3.7 (b9 · บั๊กที่เจอตอนรวมแพตช์) — ชั้นที่เครื่องมือถืออยู่ถูกลบออกจากโปรเจกต์แล้ว (เช่นกรอบ 🍩 ค้างไว้
            #   ระหว่างวาดเส้น แล้วชั้นถูกถอด) ⇒ ไม่ตรงแน่นอน และเครื่องมือตัวนี้ใช้ต่อไม่ได้อีกเลย (ทุกคลิก/ขยับเมาส์จะอ่าน
            #   ชั้นที่ตายแล้ว) ⇒ ถอดเครื่องมือ คืนเครื่องมือมาตรฐาน แล้วบอกเหตุ
            _bad = _gone = True
        if _gone:
            self._drop_plugin_tool()
            self.iface.messageBar().pushMessage(
                title, "ชั้นข้อมูลที่เครื่องมือนี้ใช้ถูกนำออกจากโปรเจกต์แล้ว — ยกเลิกเครื่องมือ ยังไม่ได้แก้อะไร "
                       "(เลือกชั้นข้อมูลแล้วกดปุ่มเครื่องมือใหม่อีกครั้ง)", level=1, duration=8)
            return None
        if _bad:
            self.iface.messageBar().pushMessage(
                title, "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดเครื่องมือ — ยกเลิกเพื่อกันแก้ผิดชั้น "
                       "(กดปุ่มเครื่องมือใหม่อีกครั้ง)", level=1, duration=8)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
            return None
        return poly, point

    def _pair_cols_ok(self, poly_lyr, point_lyr, title):
        """★ 2.3.7 (review AR-06-D) — ด่านชั้นในของ แก้ชื่อหมุด/ลบ Node: ทั้งสองชั้นต้องมีคอลัมน์ UTM ที่ใช้จับคู่แปลงกับหมุด
        ไม่มี ⇒ `_marker_candidates` คืนว่าง = "ไม่มีหมุดตรงนี้" ⇒ ลบ Node (ผู้ช่วย/ผู้ดูแล) ลบมุมแปลงไปแล้วหมุดจริงค้าง (กำพร้า)
        และด่านก่อนบันทึกก็ตรวจไม่ได้ (no-utm-field) ⇒ ปฏิเสธพร้อมบอกชั้นที่ขาด (เช่นเผลอเลือกชั้น CT เป็นชั้นหมุด)"""
        ขาด = [n for n, l in (("ชั้นแปลง", poly_lyr), ("ชั้นหมุด", point_lyr))
               if l is None or not self._resolve_field(l, _UTM_FIELD_NAMES)]
        if not ขาด:
            return True
        self.iface.messageBar().pushMessage(
            title, "%s ไม่มีคอลัมน์ UTM ที่ใช้จับคู่แปลงกับหมุด — ทำไม่ได้ (เลือกชั้นข้อมูลให้ถูกก่อน)" % " และ ".join(ขาด),
            level=1, duration=8)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
        return False

    def _addnode_name_field(self, point_lyr):
        """หา field ชื่อหมุด: ใช้ BND_NAME ก่อน ถ้าไม่มีหาฟิลด์ที่มีคำว่า NAME"""
        flds = point_lyr.fields()
        # 🔧 8 ก.ย. 69 — lookupField ไม่สนตัวพิมพ์ (ทดสอบแล้ว) ต่างจาก indexOf ที่ต้องตรงเป๊ะ
        #   ที่เหลือในไฟล์นี้รับชื่อมาจาก _resolve_field อยู่แล้ว เหลือแค่ 2 จุดที่ใส่ชื่อตรง ๆ
        # 🔴 9 ก.ย. 69 — **ต้องคืน "ชื่อจริงของคอลัมน์" ไม่ใช่สตริงคงที่**
        #   _fld_idx ไม่สนตัวพิมพ์ ⇒ บนชั้นที่คอลัมน์ชื่อ `bnd_name` มันจะเข้าเงื่อนไขนี้
        #   ถ้าคืน "BND_NAME" ผู้เรียก (`_addnode_execute`) เอาไปทำ fields().indexOf() ได้ **-1**
        #   แล้ว setAttribute(-1, ...) **โยน KeyError** (ทดสอบกับ PyQGIS แล้ว) ⇒ Add Node ล้ม
        #   🔑 นี่เป็นการถดถอยที่ 2.2.8 ทำขึ้นเอง: 2.2.7 ใช้ indexOf ตรงตัว จึงตกไปเข้าลูปข้างล่าง
        #      ซึ่งคืน f.name() = ชื่อจริง แล้วทำงานได้ปกติ
        _i = _fld_idx(flds, "BND_NAME")
        if _i >= 0:
            return flds.at(_i).name()
        # ★ 2.3.7 (audit F3 · เจ้าของงานตัดสิน 3 ต.ค. "ปลั๊กอินไม่เขียน ALT_NAME") — ทางถอย "ฟิลด์แรกที่มีคำว่า NAME"
        #   เดิมคืน ALT_NAME บนชั้นที่ไม่มี BND_NAME ⇒ แก้ชื่อหมุด · Add Node · ลบ Node · 🍩 เขียนชื่อหมุดทับประวัติชื่อ (ALT_NAME)
        #   ⇒ ข้ามคอลัมน์ ALT_* เสมอ · ไม่มีคอลัมน์ชื่ออื่น = None (ผู้เรียกทุกตัวรับ None อยู่แล้ว: ไม่ตั้งชื่อ / แจ้งไม่มีคอลัมน์ชื่อ)
        for f in flds:
            _u = f.name().upper()
            if "NAME" in _u and not _u.startswith("ALT"):
                return f.name()
        return None

    def _poly_type_str(self, poly_lyr, feat):
        """คืนค่าฟิลด์ type (ตัวพิมพ์ใหญ่) ของแปลง หรือ '' ถ้าไม่มี — ใช้เช็ค L1-RTK/L1-TS
        เรียกทุก mouse-move ตอน hover (Add Node/Move Node) -> หา field ผ่าน cache"""
        name = self._resolve_field(poly_lyr, {'type'})
        if not name:
            return ""
        # ★ 2.3.7 (review DI-01) — NULL จาก provider เดิมได้ 'NULL' ⇒ ไปโผล่เป็นตัวเลือกในเปลี่ยน Type
        return _txt(feat[name]).upper()
