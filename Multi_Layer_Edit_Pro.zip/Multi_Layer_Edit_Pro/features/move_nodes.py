# -*- coding: utf-8 -*-
"""Move Node (ลากกรอบเลือกมุม+หมุด แล้วย้ายพร้อมกัน)

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtWidgets
from qgis.core import (Qgis, QgsCoordinateTransform, QgsFeatureRequest, QgsGeometry, QgsMessageLog, QgsPointXY,
                       QgsProject, QgsRectangle, QgsUnitTypes, QgsWkbTypes)
from ..core.util import _log_exc, _norm_utm, _scrub, _UTM_FIELD_NAMES
from ..lock_rules import L1_TYPES
from ..map_tools import SyncVertexTool


class MoveNodesMixin:
    """Move Node (ลากกรอบเลือกมุม+หมุด แล้วย้ายพร้อมกัน)"""

    def start_sync_vertex_tool(self):
        """เริ่มการทำงานของ SyncVertexTool (ย้ายหมุดทีละหลายอัน)
        ★ rc2 (audit A2-07) — docstring ย้ายมาบรรทัดแรก (เดิมอยู่หลังโค้ด = สตริงลอย ไม่ใช่ docstring)"""
        if not self._pair_key_ok("Move Node"):
            return
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        # ★ ต้องมีครบทั้งคู่ (2026-08-06): เดิม "แปลงหรือหมุด" อย่างใดอย่างหนึ่งก็ผ่าน
        #   -> ถ้าชั้นแปลงว่าง ด่านล็อก L1 ใน map_tools (ซึ่งอิงชั้นแปลง) ถูกข้ามทั้งหมด = ลากหมุด
        #   ของแปลงอ้างอิงได้ · และการย้าย node ฝั่งเดียวทำให้แปลงกับหมุดหลุดคู่กัน
        if not poly_lyr or not point_lyr:
            self.iface.messageBar().pushMessage(
                "Move Node", "ต้องเลือกทั้งเลเยอร์แปลง (Polygon) และเลเยอร์หมุด (Point) ก่อน "
                             "— เครื่องมือนี้ย้ายมุมแปลงกับหมุดพร้อมกัน", level=1, duration=8)   # ★ 2.3.7 UX-35 แดง→เหลือง
            return
            
        if self.temp_tool:
            try:
                self.temp_tool.deactivate()
            except Exception:
                pass
                
        # ถ้ามีแปลงถูก Select อยู่ ให้เรียกใช้ Select by UTM อัตโนมัติ เพื่อให้หมุดติด Select สีเหลืองไปด้วย
        if poly_lyr and poly_lyr.selectedFeatureCount() > 0:
            self.process_selection('utm', hint="modify_node")

        self.mode = 'modify_node'
        # ★ การลากหลายหมุดของ SyncVertexTool เช็ค match.isValid() จาก snapping
        #   ถ้าโปรเจกต์ปิด snap ไว้และนี่คือเครื่องมือแรกของ session -> ลากไม่ติดแบบเงียบ ๆ
        self.setup_snapping()
        self.temp_tool = SyncVertexTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Move Node",
            "คลิกหมุด → คลิกตำแหน่งใหม่เพื่อย้าย • หลายหมุด: ลากกล่องเลือกแล้วลากย้าย (Shift+ลาก = เลือกเพิ่ม) • คลิกขวา = เสร็จ")

    # ★ 28 ส.ค. 69 (audit 2.8/2.9) — ด่าน "ครบคู่" ก่อนย้ายมุม/หมุด
    #
    #   ปัญหาที่ตรวจเจอ:
    #     2.8 ด่านเดิมใน map_tools.py (sel_pt_idx) ทำงานเฉพาะเมื่อ "เลือกหมุดอย่างเดียว
    #         และไม่ได้เลือกแปลง" — แต่ start_sync_vertex_tool เรียก process_selection('utm')
    #         ให้อัตโนมัติ ทำให้ selected_poly_ids ไม่เคยว่าง => **ด่านเป็นเท็จตลอดบนทางใช้งานปกติ**
    #     2.9 การลากกล่องใช้ "อยู่ในกรอบเดียวกัน" ไม่ใช่ "เป็นคู่กัน" — สองลูปแยกกันเก็บมุมแปลง
    #         กับหมุด ตัวใดเยื้องออกนอกกรอบแม้เล็กน้อยก็หลุด แล้ว _movenodes_execute
    #         แค่บวก dx,dy ให้ทุกตัวในลิสต์ ไม่มีที่ใดตรวจว่าครบคู่
    #
    #   วางด่านไว้ที่นี่เพราะ **ครอบทุกทางเข้าของ Move Node** (ลากกล่อง + คลิกเดี่ยว)
    #   ไม่ใช่แก้เฉพาะตัวเครื่องมือแล้วตกหล่นทางอื่น
    #   เทียบด้วย UTM เดียวกันเท่านั้น (ตามกติกา "ทุกแปลงต้องมีหมุดเป็นของตัวเอง")
    #   ถามแบบ Yes/No ต่อครั้ง (ดีฟอลต์ No) ไม่ใช่บล็อกตาย — เพราะงานแก้ "หมุดที่หลุดจากมุม"
    #   เป็นงานที่ต้องทำจริง ต้องเปิดทางให้ตั้งใจทำได้
    def _movenodes_pair_ok(self, selected_vertices, tol=None, cap=2000, umap_in=None):
        # ★ 31 ส.ค. 69 — v['pt'] เป็นพิกัด "CRS ของโปรเจกต์" (แปลงมาแล้วใน map_tools)
        #   ค่า 0.01 จึงเป็น 1 ซม. เฉพาะตอนโปรเจกต์เป็นเมตร ถ้าเป็นองศาจะกลายเป็น
        #   ~1.1 กม. -> ด่านนี้จะจับคู่มั่วแล้วบอกว่า "ครบคู่" ทั้งที่ไม่ครบ (เงียบสนิท)
        if tol is None:
            try:
                from ..map_tools import _canvas_is_metres
                tol = 0.01 if _canvas_is_metres(self.iface.mapCanvas()) else 1e-7
            except Exception:
                tol = 0.01
        try:
            by_layer = {}
            for v in selected_vertices:
                by_layer.setdefault(v['layer'], []).append(v)
            polyv, ptv = [], []
            for lyr, vs in by_layer.items():
                uf = self._resolve_field(lyr, _UTM_FIELD_NAMES)
                if not uf:
                    return True              # ไม่มีคีย์ให้เทียบ -> ปล่อย (_pair_key_ok คุมตั้งแต่ต้นแล้ว)
                fids = list({v['fid'] for v in vs})
                if len(fids) > cap:
                    return True              # ใหญ่เกิน -> ข้าม ไม่ให้หน่วงการทำงาน
                umap = {}
                # ★ rc2 (audit A2-06) — ใช้ UTM ที่ _movenodes_fresh เพิ่งอ่าน (ชุด fid เดียวกัน) · ไม่ครบ = อ่านเองแบบเดิม
                _pre = umap_in.get(lyr.id()) if umap_in else None
                if _pre is not None and all(fid in _pre for fid in fids):
                    umap = {fid: _pre[fid] for fid in fids}
                try:
                    if not umap:
                        # ★ 2.4.0 (review PF-07) — อ่านแค่ UTM ⇒ NoGeometry (เดิมดึงรูปแปลงทั้งรูปมาทิ้ง)
                        req = (QgsFeatureRequest().setFilterFids(fids).setFlags(QgsFeatureRequest.NoGeometry)
                               .setSubsetOfAttributes([uf], lyr.fields()))
                        for f in lyr.getFeatures(req):
                            umap[f.id()] = _norm_utm(f[uf])
                except Exception:
                    _log_exc("Move Node (_movenodes_pair_ok): อ่าน UTM ของที่เลือกไม่ได้ — ปล่อยผ่านโดยไม่ได้ตรวจคู่")  # ★ ER-03
                    return True
                for v in vs:
                    u = umap.get(v['fid'])
                    if u is None:
                        continue
                    (polyv if v.get('vidx', -1) >= 0 else ptv).append((u, v['pt']))
            if not polyv and not ptv:
                return True
            # ★ 2.3.7 (review UX-43) — ตัดจุดซ้ำ (UTM เดียวกัน · ตำแหน่งเดียวกันระดับ มม.) ก่อนนับ
            #   เดิมจุดปิดวง/มุมที่ถูกเลือกซ้ำนับเป็น 2 มุม ⇒ กล่องบอก "มุมแปลง 2 จุด" ทั้งที่จริง 1 มุม
            _res = tol / 10.0

            def _uniq(lst):
                seen, out = set(), []
                for u, q in lst:
                    k = (u, round(q.x() / _res), round(q.y() / _res))
                    if k not in seen:
                        seen.add(k)
                        out.append((u, q))
                return out
            polyv, ptv = _uniq(polyv), _uniq(ptv)

            def _near(q, lst):
                return any(abs(q.x() - r.x()) <= tol and abs(q.y() - r.y()) <= tol for r in lst)
            mk_idx = {}
            for u, q in ptv:
                mk_idx.setdefault(u, []).append(q)
            vt_idx = {}
            for u, q in polyv:
                vt_idx.setdefault(u, []).append(q)
            _miss = [(u, q) for u, q in polyv if not _near(q, mk_idx.get(u, ()))]   # มุมไม่มีหมุดคู่
            missing = len(_miss)
            orphan  = sum(1 for u, q in ptv   if not _near(q, vt_idx.get(u, ())))   # หมุดไม่มีมุมคู่
            if not missing and not orphan:
                return True
            # ★ 2.3.7 (review UX-43) — แยก "มีหมุดแต่ไม่ได้เลือก" กับ "มุมนี้ยังไม่มีหมุดเลย"
            #   เดิมรวมเป็นข้อความเดียว + แนะนำ "ลากกรอบใหม่ให้ครอบทั้งมุมและหมุด" ซึ่งช่วยไม่ได้เมื่อไม่มีหมุดให้ครอบ
            #   ⇒ ฝึกให้กด Yes จนด่านอ่อน · ตรวจแยกไม่ได้ = ข้อความรวมแบบเดิม (ยังถาม ไม่ปล่อยผ่าน)
            n_has = n_bare = None
            if _miss:
                _sp = self._movenodes_split_missing(_miss, selected_vertices)
                if _sp is not None:
                    n_has, n_bare = _sp
            parts = []
            if missing and n_has is None:
                parts.append(f"มุมแปลง {missing} จุด ที่ <b>ไม่มีหมุดของแปลงเดียวกัน</b>ถูกเลือกไปด้วย")
            if n_has:
                parts.append(f"มุมแปลง {n_has} จุด ที่<b>มีหมุดของแปลงเดียวกันอยู่ แต่ไม่ได้เลือกหมุดนั้นมาด้วย</b>")
            if n_bare:
                parts.append(f"มุมแปลง {n_bare} จุด ที่<b>ยังไม่มีหมุดเลย</b> (ไม่มีหมุดให้เลือก)")
            if orphan:
                parts.append(f"หมุด {orphan} ตัว ที่ <b>ไม่มีมุมแปลงของตัวเอง</b>ถูกเลือกไปด้วย")
            _split_pair = bool(orphan or n_has or (missing and n_has is None))   # ย้ายแล้วจะแยกคู่ที่มีอยู่
            _adv = []
            if _split_pair:
                _adv.append("ลากกรอบใหม่ให้ครอบทั้งมุมและหมุด")
            if n_bare:
                _adv.append("ใช้ ➕ Add Node เพิ่มหมุดให้มุมที่ยังไม่มีหมุดก่อน")
            if _split_pair:
                _why = ("ถ้าย้ายต่อ ของที่ไม่ครบคู่จะแยกจากกัน "
                        "(ผิดกติกา &quot;ทุก node ต้องมีหมุด&quot;)")
                _yes = ("ย้ายต่อ (ใช้เมื่อกำลังตั้งใจแก้หมุดที่หลุดจากมุมอยู่"
                        + (" หรือตั้งใจย้ายมุมที่ยังไม่มีหมุด" if n_bare else "") + ")")
            else:
                _why = ("มุมที่ยังไม่มีหมุดผิดกติกา &quot;ทุก node ต้องมีหมุด&quot; อยู่แล้ว "
                        "— ย้ายไปแล้วก็ยังต้องเพิ่มหมุดก่อนบันทึก")
                _yes = "ย้ายมุมไปก่อน (ตั้งใจย้ายมุมที่ยังไม่มีหมุด)"
            ans = self._ask(
                QtWidgets.QMessageBox.Question, "เลือกไม่ครบคู่",
                "สิ่งที่เลือกไว้ยังไม่ครบคู่:<br>&nbsp;&nbsp;• " + "<br>&nbsp;&nbsp;• ".join(parts) +
                "<br><br>" + _why + "<br><br>"
                "• <b>No</b> = ยกเลิก แล้ว" + " หรือ ".join(_adv) + " (แนะนำ)<br>"
                "• <b>Yes</b> = " + _yes,
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            return ans == QtWidgets.QMessageBox.Yes
        except Exception:
            # ★ 2.3.7 (review ER-03) — ปล่อยผ่านเหมือนเดิม แต่ต้องทิ้งร่องรอย (เดิมกลืนเงียบ = ไม่มีใครรู้ว่าด่านไม่ได้ตรวจ)
            _log_exc("Move Node (_movenodes_pair_ok): ตรวจคู่มุม-หมุดไม่ได้ — ปล่อยผ่านโดยไม่ได้ตรวจ")
            return True                      # ตรวจไม่ได้ -> อย่าไปขวางการทำงาน

    def _movenodes_tool_layers(self, selected_vertices):
        """★ 2.3.7 — (ชั้นแปลง, ชั้นหมุด) ของการเลือกชุดนี้
        เครื่องมือ Move Node ที่ถือรายการนี้อยู่ ⇒ ชั้นของเครื่องมือ (ชุดเดียวกับที่ใช้ตอนเลือก)
        ไม่งั้นดูจากชิ้นที่เลือก แล้วค่อยถอยไปคอมโบ (ผู้เรียกที่สร้างรายการเอง)"""
        pl = ptl = None
        t = getattr(self, "temp_tool", None)
        if t is not None and getattr(t, "selected_vertices", None) is selected_vertices:
            pl, ptl = getattr(t, "poly_lyr", None), getattr(t, "point_lyr", None)
        for v in selected_vertices:
            try:
                gt = v['layer'].geometryType()
            except Exception:
                continue
            if pl is None and gt == QgsWkbTypes.PolygonGeometry:
                pl = v['layer']
            elif ptl is None and gt == QgsWkbTypes.PointGeometry:
                ptl = v['layer']
        try:
            if pl is None:
                pl = QgsProject.instance().mapLayer(self.poly_cb.currentData())
            if ptl is None:
                ptl = QgsProject.instance().mapLayer(self.point_cb.currentData())
        except Exception:
            pass
        return pl, ptl

    def _movenodes_split_missing(self, miss, selected_vertices, cap=20000):
        """★ 2.3.7 (review UX-43) — แยกมุมที่ไม่มีหมุดคู่ "ในสิ่งที่เลือก" เป็น
             (ก) มีหมุดของแปลงเดียวกันอยู่ที่มุมนั้น (≤ 1 ซม. · เกณฑ์เดียวกับ _marker_exists_here) แต่ไม่ได้เลือก
             (ข) มุมนี้ยังไม่มีหมุดเลย
        miss = [(UTM ที่ normalise แล้ว, จุดในพิกัดโปรเจกต์)] · คิวรีชั้นหมุดครั้งเดียว (กรอบรวม ± 1 ซม.) แล้วเทียบ UTM ในหน่วยความจำ
        คืน (ก, ข) · ตรวจไม่ได้ (ไม่มีชั้น/คอลัมน์ · อ่านล้ม · กรอบกว้างเกิน) = None ⇒ ผู้เรียกใช้ข้อความรวมแบบเดิม"""
        try:
            ptl = self._movenodes_tool_layers(selected_vertices)[1]
            if ptl is None:
                return None
            uf = self._resolve_field(ptl, _UTM_FIELD_NAMES)
            if not uf:
                return None
            proj = QgsProject.instance()
            to_l = (QgsCoordinateTransform(proj.crs(), ptl.crs(), proj)
                    if ptl.crs() != proj.crs() else None)
            try:
                tol = 0.01 if ptl.crs().mapUnits() == QgsUnitTypes.DistanceMeters else 1e-7
            except Exception:
                tol = 0.01
            qs = [(u, to_l.transform(q) if to_l else QgsPointXY(q)) for u, q in miss]
            xs = [q.x() for _, q in qs]
            ys = [q.y() for _, q in qs]
            rect = QgsRectangle(min(xs) - tol, min(ys) - tol, max(xs) + tol, max(ys) + tol)
            want = {u for u, _ in qs}
            have = {}
            _it = ptl.getFeatures(QgsFeatureRequest().setFilterRect(rect)
                                  .setSubsetOfAttributes([uf], ptl.fields()))
            try:
                for i, f in enumerate(_it):
                    if i > cap:
                        return None                  # กรอบกว้างผิดปกติ -> ใช้ข้อความรวมแบบเดิม
                    u = _norm_utm(f[uf])
                    if u not in want:
                        continue
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    have.setdefault(u, []).append(g.vertexAt(0))
            finally:
                _it.close()
            n_has = sum(1 for u, q in qs
                        if any(abs(m.x() - q.x()) <= tol and abs(m.y() - q.y()) <= tol for m in have.get(u, ())))
            return n_has, len(qs) - n_has
        except Exception:
            return None

    # ★ 7 ก.ย. 69 — ด่าน "อย่าลากไปทับหมุดของแปลงตัวเอง"
    #
    #   ที่มา: หลังลบหมุดซ้อนในฐานไป 7,912 ดวง (7 ก.ย. เช้า) หมุดซ้อนกลับมาใหม่ภายในวันเดียว
    #   ไล่ปูม `<อำเภอ>_Move_Log` ของหมุดที่ซ้อนกันอยู่ตอนนี้แล้วพบว่า
    #     - ส่วนใหญ่เป็นหมุด "ของสายผลิต" (EDIT_SRC ว่าง) ไม่ใช่หมุดที่เพิ่งกด Add Node เพิ่ม
    #     - ปูมเกือบทั้งหมดเป็น action='moved' ลงวันเดียวกัน
    #   ⇒ ต้นตอคือ **การลากหมุดที่มีอยู่แล้วไปทับหมุดอีกดวงของแปลงเดียวกัน** ผ่าน Move Node
    #   Add Node กันเคสนี้ไปแล้วตั้งแต่ 2.2.5 (`_marker_exists_here`) แต่ Move Node ยังไม่มี
    #   ⇒ ของเสียเลยย้ายมาเข้าทางนี้แทน
    #
    #   ทำเป็น "ถาม Yes/No (ดีฟอลต์ No)" ไม่ใช่บล็อกตาย ด้วยเหตุผลเดียวกับ _movenodes_pair_ok:
    #   งาน "ยุบหมุดที่ซ้ำให้เหลือดวงเดียว" เป็นงานที่ต้องทำจริง ต้องเปิดทางให้ตั้งใจทำได้
    #   🔑 เทียบด้วย UTM เดียวกันเท่านั้น — มุมร่วมของแปลงข้างเคียงมีหมุดของตัวเองได้ ไม่ถือว่าซ้อน
    #   🔑 ไม่นับหมุดที่ "ถูกเลือกให้ย้ายไปด้วย" เพราะมันจะเลื่อนออกไปพร้อมกัน ไม่ได้ทับกันจริง
    def _movenodes_stack_ok(self, selected_vertices, dx, dy, cap=2000, umap_in=None):
        """ปลายทางมีหมุดของ 'แปลงเดียวกัน' อยู่แล้วไหม -> ถามก่อนย้าย

        🔴 audit 7 ก.ย. เจอบั๊กในฉบับแรกของด่านนี้ 2 ข้อ แก้แล้วทั้งคู่:
        ① **หน่วยของ tol ผิด** — ฉบับแรกเอา tol จาก CRS ของ *แคนวาส* ไปใช้กับพิกัดที่แปลงเป็น
           CRS ของ *เลเยอร์* แล้ว · เคสจริงที่มีอยู่ (Khlongluang_V2: โปรเจกต์ 4326 · เลเยอร์ 24047)
           จะได้ tol = 1e-7 ไปเทียบกับพิกัดหน่วยเมตร ⇒ **ด่านไม่เคยทำงานเลยแบบเงียบ ๆ**
           ⇒ ต้องเอาหน่วยจาก **CRS ของเลเยอร์** (ดู memory `qgis-canvas-crs-units-trap`)
        ② **ยิงคิวรีต่อหมุด 1 ครั้ง** — ลากกล่องเลือกหลายร้อยหมุด = หลายร้อย round-trip ไป PostGIS
           ⇒ รวมเป็น **คิวรีเดียวต่อเลเยอร์** ด้วยกรอบรวมของปลายทางทั้งหมด แล้วจับคู่ในหน่วยความจำ
        """
        try:
            pts = [v for v in selected_vertices if v.get('vidx', -1) < 0]
            if not pts or len(pts) > cap:
                return True                  # ไม่มีหมุดถูกเลือก / ใหญ่เกิน -> ไม่ขวาง
            proj = QgsProject.instance()
            hits = 0
            partial = 0                      # ★ 2.3.7 (DU-02-D3) ชั้นที่อ่านไม่ครบเพราะกรอบกว้างเกิน
            by_layer = {}
            for v in pts:
                by_layer.setdefault(v['layer'], []).append(v)
            for lyr, vs in by_layer.items():
                uf = self._resolve_field(lyr, _UTM_FIELD_NAMES)
                if not uf:
                    return True              # ไม่มีคีย์ให้เทียบ -> ไม่ขวาง
                try:
                    tol = 0.01 if lyr.crs().mapUnits() == QgsUnitTypes.DistanceMeters else 1e-7
                except Exception:
                    tol = 0.01
                moving = {v['fid'] for v in vs}
                umap = {}
                # ★ rc2 (audit A2-06) — ใช้ UTM ที่ _movenodes_fresh เพิ่งอ่าน · ไม่ครบ = อ่านเองแบบเดิม
                _pre = umap_in.get(lyr.id()) if umap_in else None
                if _pre is not None and all(fid in _pre for fid in moving):
                    umap = {fid: _pre[fid] for fid in moving}
                try:
                    if not umap:
                        # ★ 2.4.0 (review PF-07) — อ่านแค่ UTM ⇒ NoGeometry
                        req = QgsFeatureRequest().setFilterFids(list(moving)) \
                            .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([uf], lyr.fields())
                        for f in lyr.getFeatures(req):
                            umap[f.id()] = _norm_utm(f[uf])
                except Exception:
                    _log_exc("Move Node (_movenodes_stack_ok): อ่าน UTM ของหมุดที่ย้ายไม่ได้ — ปล่อยผ่านโดยไม่ได้ตรวจหมุดทับ")
                    return True
                to_lyr = (QgsCoordinateTransform(proj.crs(), lyr.crs(), proj)
                          if lyr.crs() != proj.crs() else None)
                dests = []
                for v in vs:
                    u = umap.get(v['fid'])
                    if u is None:
                        continue
                    q = QgsPointXY(v['pt'].x() + dx, v['pt'].y() + dy)
                    if to_lyr:
                        q = to_lyr.transform(q)
                    dests.append((u, q))
                if not dests:
                    continue
                # ---- คิวรีเดียวต่อเลเยอร์: กรอบรวมของปลายทางทั้งหมด ----
                xs = [q.x() for _, q in dests]
                ys = [q.y() for _, q in dests]
                rect = QgsRectangle(min(xs) - tol, min(ys) - tol, max(xs) + tol, max(ys) + tol)
                near = []
                try:
                    r2 = QgsFeatureRequest().setFilterRect(rect) \
                        .setSubsetOfAttributes([uf], lyr.fields())
                    _fit6925 = lyr.getFeatures(r2)
                    try:
                        for i, f in enumerate(_fit6925):
                            if i > 20000:
                                # ★ 2.3.7 (review DU-02-D3) — เดิม `return True` เงียบ ๆ = ด่านปิดตัวเองทั้งด่าน
                                #   (ทิ้งทั้งชั้นอื่นและคู่ที่เจอแล้ว ไม่มีข้อความ/log) ⇒ หยุดอ่านเฉพาะชั้นนี้
                                #   ตรวจเท่าที่อ่านมาแล้ว + เตือน + log · ยังไม่ขวางเพราะเรื่องนี้ (ด่านก่อนบันทึกตรวจอีกรอบ)
                                partial += 1
                                break
                            if f.id() in moving:
                                continue         # ตัวที่ย้ายไปพร้อมกัน ไม่นับว่าทับ
                            g = f.geometry()
                            if g is None or g.isEmpty():
                                continue
                            near.append((_norm_utm(f[uf]), g.asPoint()))
                    finally:
                        _fit6925.close()
                except Exception:
                    _log_exc("Move Node (_movenodes_stack_ok): อ่านหมุดที่ปลายทางไม่ได้ — ปล่อยผ่านโดยไม่ได้ตรวจหมุดทับ")
                    return True
                if not near:
                    continue
                # ★ 2.3.7 (DU-02-D3) — จัดกลุ่มตาม UTM ก่อน (เดิมเทียบทุกคู่ ⇒ อ่านถึง 20,000 ดวง × 800 ปลายทางช้ามาก)
                near_u = {}
                for u2, g in near:
                    near_u.setdefault(u2, []).append(g)
                for u, q in dests:
                    for g in near_u.get(u, ()):
                        if abs(g.x() - q.x()) <= tol and abs(g.y() - q.y()) <= tol:
                            hits += 1
                            break
            if partial:
                try:
                    QgsMessageLog.logMessage(
                        f"_movenodes_stack_ok: กรอบปลายทางมีหมุดเกิน 20,000 ดวง — ตรวจหมุดทับไม่ครบ ({partial} ชั้น)",
                        "MLEP", Qgis.Warning)
                except Exception:
                    pass
                self.iface.messageBar().pushMessage(
                    "Move Node", "ตรวจหมุดทับไม่ครบเพราะเลือกกว้างเกิน — จะตรวจอีกครั้งตอนบันทึก",
                    level=1, duration=8)
            if not hits:
                return True
            ans = self._ask(
                QtWidgets.QMessageBox.Question, "จะได้หมุดซ้อนกัน",
                f"ตำแหน่งปลายทางมีหมุด <b>ของแปลงเดียวกัน</b>อยู่แล้ว {hits} จุด<br><br>"
                "ถ้าย้ายต่อ จะได้หมุดสองดวงซ้อนกันที่มุมเดียวกัน "
                "(ผิดกติกา &quot;หนึ่งมุม หนึ่งหมุด ต่อหนึ่งแปลง&quot;)<br><br>"
                "• <b>No</b> = ยกเลิก (แนะนำ)<br>"
                "• <b>Yes</b> = ย้ายต่อ (ใช้เมื่อกำลังตั้งใจยุบหมุดที่ซ้ำให้เหลือดวงเดียว)",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No)
            return ans == QtWidgets.QMessageBox.Yes
        except Exception:
            # ★ 2.3.7 (review ER-03) — ปล่อยผ่านเหมือนเดิม แต่ต้องทิ้งร่องรอย
            _log_exc("Move Node (_movenodes_stack_ok): ตรวจหมุดทับที่ปลายทางไม่ได้ — ปล่อยผ่านโดยไม่ได้ตรวจ")
            return True                      # ตรวจไม่ได้ -> อย่าไปขวางการทำงาน

    def _movenodes_stamp(self, layers):
        """★ 2.3.7 (review DI-36) — ลายนิ้วมือ "สถานะการแก้ไข" ของชั้นแปลง/หมุด ณ ตอนนี้
        = ((ปลดล็อก L1 อยู่ไหม, CRS ของโปรเจกต์), ต่อชั้น: (layer id, ตำแหน่ง undo stack, คำสั่งบนสุด, จำนวนครั้งที่บันทึก))
        เครื่องมือ Move Node จดไว้กับทุกชิ้นตอนเลือก · _movenodes_fresh เทียบตอนลงมือ ⇒ ต่าง = มีการแก้/ย้อน
        (Ctrl+Z · ↺)/บันทึก (💾)/สลับล็อก L1 หลังเลือก ⇒ ของที่เลือกไว้อาจไม่ใช่ของเดิมแล้ว
        (ย้อนแล้วแก้ใหม่จน index กลับมาเท่าเดิม ⇒ คำสั่งบนสุดเปลี่ยน — วิธีเดียวกับที่ _op_commit/undo_transform ใช้)"""
        out = [self._movenodes_stamp_head()]
        for lyr in layers:
            if lyr is None:
                continue
            try:
                lid = lyr.id()
                st = lyr.undoStack()
                i = st.index()
                c = st.command(i - 1) if i > 0 else None
                try:
                    from qgis.PyQt import sip as _sip
                    c = _sip.unwrapinstance(c) if c is not None else 0
                except Exception:
                    c = 0
                out.append((lid, i, c, self._commit_seq.get(lid, 0)))
            except Exception:
                out.append((None,))
        return tuple(out)

    def _movenodes_stamp_head(self):
        """ส่วนหัวของลายนิ้วมือ: ปลดล็อก L1 อยู่ไหม + CRS ของโปรเจกต์
        (v['pt'] เป็นพิกัด CRS ของโปรเจกต์ — เปลี่ยน CRS ระหว่างเลือกค้าง ⇒ ระยะที่ลากคิดผิดระบบพิกัด)"""
        try:
            _c = QgsProject.instance().crs()
            _crs = _c.authid() or _c.toWkt()
        except Exception:
            _crs = None
        return ("L1", self._l1_unlocked(), _crs)

    def _movenodes_stamp_ok(self, stamp):
        """ลายนิ้วมือที่จดไว้ยังตรงกับตอนนี้ไหม (ชั้นที่จดไม่ได้ตอนเลือก = ข้าม · ชั้นหายไปจากโปรเจกต์ = ไม่ตรง)"""
        if not stamp:
            return True
        if stamp[0] != self._movenodes_stamp_head():
            return False
        proj = QgsProject.instance()
        for ent in stamp[1:]:
            if not ent or ent[0] is None:
                continue
            lyr = proj.mapLayer(ent[0])
            if lyr is None or self._movenodes_stamp([lyr])[1:] != (ent,):
                return False
        return True

    def _movenodes_fresh(self, selected_vertices, umap_out=None):
        """★ 2.3.7 (review DI-36) — ก่อนถาม/ก่อนย้าย: ของที่เลือก "ยังเป็นของเดิม" และไม่ติดล็อก L1
        ① ลายนิ้วมือที่เครื่องมือจดไว้ตอนเลือก (v['stamp']) ต้องตรงกับตอนนี้ (ไม่มี = ผู้เรียกสร้างรายการเอง ⇒ ข้ามข้อนี้)
        ② ฟีเจอร์ยังอยู่ · มุมที่ vidx และหมุด ยังอยู่ตรงพิกัดที่เลือก (≤ 1 ซม. · ชั้นหน่วยองศา 1e-7°) — คิวรีเดียวต่อชั้น
        ③ ด่าน L1 ชั้นใน: แปลง L1-RTK/L1-TS และหมุดของแปลงนั้น (เทียบ UTM) — เว้นแต่ปลดล็อก L1 อยู่ · ตรวจไม่ได้ = ไม่ย้าย
           (★ 2.4.0 DU-01 — หมุดใช้ _marker_locked: รวมหมุดที่ Type ของตัวเองเป็น L1 ด้วย)
        คืน (None, {(layer id, fid): geometry ของแปลงที่เพิ่งอ่าน}) ถ้าผ่าน · (เหตุ, None) ถ้าไม่ผ่าน (แจ้งบนแถบแล้ว)
        เหตุ 'stale' ⇒ ตั้ง self._movenodes_stale ให้เครื่องมือล้างการเลือก (ต้องเลือกใหม่)"""
        def _stale(why):
            self._movenodes_stale = True
            try:
                QgsMessageLog.logMessage("Move Node: ข้อมูลเปลี่ยนหลังเลือก — " + _scrub(str(why))[:300],
                                         "MLEP", Qgis.Info)
            except Exception:
                pass
            self.iface.messageBar().pushMessage(
                "Move Node", "ข้อมูลเปลี่ยนไปหลังเลือก (มีการแก้ไข · ย้อนกลับ หรือบันทึก) "     # ★ 2.3.7 (audit C-03)
                             "— ยังไม่ได้ย้ายอะไร กรุณาเลือกใหม่", level=1, duration=10)
            return 'stale', None
        try:
            _seen = {}
            for v in selected_vertices:
                st = v.get('stamp')
                if st is not None:
                    _seen[id(st)] = st
            for st in _seen.values():
                if not self._movenodes_stamp_ok(st):
                    return _stale("ลายนิ้วมือสถานะการแก้ไขไม่ตรง")
            proj = QgsProject.instance()
            unlocked = self._l1_unlocked()
            by_layer = {}
            for v in selected_vertices:
                by_layer.setdefault(v['layer'], []).append(v)
            feats, fresh, n_locked = {}, {}, 0
            for lyr, vs in by_layer.items():
                lid = lyr.id()
                # ★ 2.4.0 (review DU-01) — หมุดต้องอ่าน Type ของตัวเองด้วย (กติกาเดียว _marker_locked) · เดิมอ่านเฉพาะของแปลง
                tf = self._resolve_field(lyr, {'type'})
                # ★ rc2 (audit A2-06) — umap_out (ผู้เรียกขอ) ⇒ อ่าน UTM ของทุกชั้นในคำขอเดียวกันนี้ แล้วส่งต่อให้ด่านครบคู่/หมุดซ้อน
                #   (เดิมสองด่านนั้นยิง setFilterFids ชุดเดิมซ้ำอีก 2 รอบต่อการลาก)
                uf = (self._resolve_field(lyr, _UTM_FIELD_NAMES)
                      if (umap_out is not None or any(v.get('vidx', -1) < 0 for v in vs)) else None)
                flds = [n for n in (tf, uf) if n]
                req = QgsFeatureRequest().setFilterFids(list({v['fid'] for v in vs}))
                if flds:
                    req.setSubsetOfAttributes(flds, lyr.fields())
                else:
                    req.setNoAttributes()
                _it = lyr.getFeatures(req)
                try:
                    for f in _it:
                        feats[(lid, f.id())] = f
                        if umap_out is not None and uf:
                            umap_out.setdefault(lid, {})[f.id()] = _norm_utm(f[uf])
                finally:
                    _it.close()
                try:
                    tol = 0.01 if lyr.crs().mapUnits() == QgsUnitTypes.DistanceMeters else 1e-7
                except Exception:
                    tol = 0.01
                to_lyr = (QgsCoordinateTransform(proj.crs(), lyr.crs(), proj)
                          if lyr.crs() != proj.crs() else None)
                for v in vs:
                    f = feats.get((lid, v['fid']))
                    g = f.geometry() if f is not None else None
                    if g is None or g.isEmpty():
                        return _stale(f"ไม่พบฟีเจอร์ fid {v['fid']} ของชั้น {lyr.name()}")
                    # พิกัดในชั้นที่จดไว้ตอนเลือก (ตรงเป๊ะ ไม่ผ่านการแปลงพิกัดไป-กลับ) · ไม่มี = รายการที่ผู้เรียกสร้างเอง
                    exp = v.get('lpt')
                    if exp is None:
                        exp = to_lyr.transform(v['pt']) if to_lyr else v['pt']
                    vidx = v.get('vidx', -1)
                    q = g.vertexAt(vidx if vidx >= 0 else 0)
                    if q.isEmpty() or abs(q.x() - exp.x()) > tol or abs(q.y() - exp.y()) > tol:
                        return _stale(f"fid {v['fid']} vertex {vidx} ของชั้น {lyr.name()} ไม่อยู่ที่เดิม")
                    if vidx >= 0:
                        fresh[(lid, v['fid'])] = g
                        if not unlocked and self._poly_type_str(lyr, f) in L1_TYPES:     # ★ 2.4.0 (DU-01) lock_rules
                            n_locked += 1
            pts = [v for v in selected_vertices if v.get('vidx', -1) < 0]
            if pts and not unlocked:
                pl_lock = self._movenodes_tool_layers(selected_vertices)[0]
                if pl_lock is None:
                    self.iface.messageBar().pushMessage(
                        "Move Node", "ตรวจล็อก L1 ของหมุดไม่ได้ (ไม่พบชั้นแปลง) — ยังไม่ได้ย้ายอะไร",
                        level=1, duration=10)     # ★ 2.3.7 b13 (UX-35) ปฏิเสธ ⇒ เหลือง (เดิมแดง)
                    return 'locked', None
                lm = self._locked_map_or_block(pl_lock, "Move Node")
                if lm is None:
                    return 'lockscan', None          # แจ้งแล้วใน _locked_map_or_block
                for v in pts:
                    f = feats.get((v['layer'].id(), v['fid']))
                    uf = self._resolve_field(v['layer'], _UTM_FIELD_NAMES)
                    # ★ 2.4.0 (review DU-01) — กติกาเดียว: Type ของหมุดเอง หรือ UTM ตรงแปลง L1 (เดิมดูแค่ UTM)
                    if f is not None and self._marker_locked(f, lm, uf)[0]:
                        n_locked += 1
            if n_locked:
                self.iface.messageBar().pushMessage(
                    "MLEP Guard", f"มีแปลง/หมุด L1-RTK / L1-TS (รวมหมุดของแปลง L1) อยู่ในสิ่งที่เลือก ({n_locked} ชิ้น) "
                                  "— ยังไม่ได้ย้ายอะไร", level=1, duration=8)
                return 'locked', None
            return None, fresh
        except Exception as e:
            # ตรวจไม่ได้ (เช่นชั้นถูกถอดออกจากโปรเจกต์) ⇒ ไม่ย้าย และให้เลือกใหม่
            _log_exc("Move Node: ตรวจของที่เลือกไม่ได้ — ไม่ย้าย")          # ★ 2.3.7 (ER-03) traceback
            return _stale(f"ตรวจไม่ได้: {e}")

    def _movenodes_execute(self, selected_vertices, dx, dy):
        """ประมวลผลการย้ายพิกัดหมุดหลายเลเยอร์พร้อมกัน"""
        self._movenodes_stale = False        # ★ 2.3.7 (DI-36) ให้เครื่องมือรู้ว่าปฏิเสธเพราะ "ข้อมูลเปลี่ยนหลังเลือก"
        if not selected_vertices:
            return False
        # ★ 2.3.7 (review DI-36) — ตรวจก่อนถามหรือลงมือ: สิ่งที่เลือกยังเป็นของเดิมไหม และล็อก L1 ยังผ่านไหม
        #   เดิมเชื่อ snapshot ตอนเลือกล้วน ๆ ⇒ แทรกมุมก่อนหน้า / ↺ / Ctrl+Z / 💾 / สลับล็อก L1 ระหว่างนั้น
        #   = ย้ายมุมผิดตัว (มุมเปลือย + หมุดลอย) หรือย้ายของ L1 ได้ โดยไม่มีอะไรเตือนจนถึงด่าน Save
        _umap = {}                           # ★ rc2 (audit A2-06) UTM ที่ _movenodes_fresh อ่าน ⇒ ด่านครบคู่/หมุดซ้อนไม่อ่านซ้ำ
        _why, _fresh = self._movenodes_fresh(selected_vertices, umap_out=_umap)
        if _why is not None:
            return False                     # แจ้งแล้วใน _movenodes_fresh · ยังไม่ได้แตะอะไร
        _fail = None                         # ★ 2.3.7 (DI-28) เหตุที่ยกเลิกทั้งหมด (ข้อความถึงพนักงาน)
        if not self._movenodes_pair_ok(selected_vertices, umap_in=_umap):
            return False                     # ★ ผู้ใช้เลือก "ยกเลิก" ที่ด่านครบคู่
        if not self._movenodes_stack_ok(selected_vertices, dx, dy, umap_in=_umap):
            return False                     # ★ ผู้ใช้เลือก "ยกเลิก" ที่ด่านหมุดซ้อน
            
        layers = set()
        for v in selected_vertices:
            layers.add(v['layer'])

        # ★ 2.4.0 (review DI-15) — เปิดโหมดแก้ไขทุกชั้นก่อน _op_begin/เปิดคำสั่ง (เดิมเปิดในลูปและไม่ดูผล
        #   ⇒ ชั้นที่เปิดไม่ได้ beginEditCommand ไม่ทำอะไร แล้วไปล้มตอนเขียน) · เปิดไม่ได้ = ยังไม่ได้ย้ายอะไร
        if not self._ensure_editing(*layers, title="Move Node", what="ยังไม่ได้ย้ายอะไร"):
            return False
        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            lyr.beginEditCommand("Move Nodes (Sync)")
            
        try:
            proj = QgsProject.instance()
            # สร้าง transform ครั้งเดียวต่อเลเยอร์ (เดิมสร้างใหม่ทุก vertex ในลูป)
            xform_cache = {}
            for _lyr in layers:
                xform_cache[_lyr.id()] = (QgsCoordinateTransform(proj.crs(), _lyr.crs(), proj)
                                          if _lyr.crs() != proj.crs() else None)
            # ดึง geometry ของ polygon/line ที่ต้องแก้ทั้งหมดใน "คิวรีเดียวต่อเลเยอร์"
            # (เดิมดึงทีละ feature — บน PostgreSQL = 1 round-trip ต่อ feature)
            # ★ 2.3.7 (DI-36) — ใช้ geometry ที่ _movenodes_fresh เพิ่งอ่านและตรวจตำแหน่งมาแล้ว (ไม่อ่านซ้ำ)
            geom_updates = {k: QgsGeometry(g) for k, g in _fresh.items()}
            _written = {}                    # ★ 2.3.7 (DI-28) layer id -> จำนวนที่เขียนสำเร็จ

            for v in selected_vertices:
                lyr = v['layer']
                fid = v['fid']
                vidx = v['vidx']
                pt = v['pt']

                # แปลงพิกัดใหม่กลับไปเป็น CRS ของเลเยอร์เป้าหมาย (ใช้ transform ที่ cache ไว้)
                to_lyr = xform_cache.get(lyr.id())
                new_map_pt = QgsPointXY(pt.x() + dx, pt.y() + dy)
                new_lyr_pt = to_lyr.transform(new_map_pt) if to_lyr else new_map_pt

                key = (lyr.id(), fid)

                if vidx >= 0:
                    # Polygon หรือ Line (ย้ายเฉพาะ vertex นั้นๆ)
                    geom = geom_updates.get(key)
                    # ★ 2.3.7 (DI-36/DI-28) — ห้ามข้ามเงียบ ๆ (เดิม continue ⇒ ย้ายแค่บางชิ้น = ครึ่ง ๆ กลาง ๆ)
                    if geom is None:
                        _fail = "ไม่พบรูปแปลงที่เลือก (ถูกลบหรือเปลี่ยนไประหว่างทำงาน)"
                        raise RuntimeError(_fail)
                    if not geom.moveVertex(new_lyr_pt.x(), new_lyr_pt.y(), vidx):
                        _fail = f"ย้ายมุมที่ {vidx} ของแปลงไม่ได้"
                        raise RuntimeError(_fail)
                else:
                    # Point (ย้ายทั้ง geometry)
                    geom_updates[key] = QgsGeometry.fromPointXY(new_lyr_pt)

            # นำ geometry ที่แก้ไขแล้วไปอัปเดต โดยใช้ changeGeometry เพื่อข้ามระบบ Topological Editing ของ QGIS
            # (ป้องกันไม่ให้หมุดแปลงข้างเคียงขยับตาม หากไม่ได้ถูกเลือกไว้)
            for v in selected_vertices:
                lyr = v['layer']
                fid = v['fid']
                key = (lyr.id(), fid)
                if key in geom_updates:
                    # ★ 2.3.7 (review DI-28) — ตรวจผลการเขียนทุกครั้ง (เดิมไม่ดู) · ล้มแม้ชิ้นเดียว = ยกเลิกทั้งสองชั้น
                    #   (ทั้งคู่หรือไม่เลย — มุมขยับแต่หมุดไม่ขยับ = ผิดกติกาเหล็ก) เช่นชั้นนั้นไม่มีสิทธิ์แก้รูป
                    if not lyr.changeGeometry(fid, geom_updates[key]):
                        _fail = f"เขียนพิกัดลงชั้น '{lyr.name()}' ไม่ได้ (อาจไม่มีสิทธิ์แก้รูปของชั้นนี้)"
                        raise RuntimeError(_fail)
                    _written[lyr.id()] = _written.get(lyr.id(), 0) + 1
                    del geom_updates[key]  # ป้องกันการรันซ้ำ
                    
            for lyr in layers:
                # ★ 2.3.7 (review DI-28) — ชั้นที่ไม่ได้เขียนอะไรเลย ⇒ ทิ้งคำสั่ง (เดิม endEditCommand ⇒ undo step เปล่า
                #   + ชั้นกลายเป็น "มีการแก้ไข" แล้ว ↺ ไปย้อนขั้นเปล่าแทนงานจริง)
                if _written.get(lyr.id()):
                    lyr.endEditCommand()
                else:
                    lyr.destroyEditCommand()

            self._op_commit()   # ปิด operation -> เก็บประวัติ undo
            self.iface.mapCanvas().refresh()
            if not _written:
                self.iface.messageBar().pushMessage(
                    "Move Node", "ไม่มีอะไรถูกย้าย — ยังไม่ได้แก้ข้อมูล", level=1, duration=6)
                return False
            return True
        except Exception:
            _log_exc("Move Node: ย้ายไม่สำเร็จ — ยกเลิกทั้งหมดแล้ว", Qgis.Critical)      # ★ 2.3.7 (ER-03/ER-06)
            for lyr in layers:
                lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline (delta=0 -> ไม่บันทึก)
            if _fail:
                # ★ 2.3.7 (DI-28/DI-36) — บอกเหตุเป็นภาษาคน + ยืนยันว่ายกเลิกทั้งหมดแล้ว (ทั้งสองชั้นกลับเหมือนเดิม)
                self.iface.messageBar().pushMessage(
                    "Move Node", f"ย้ายไม่สำเร็จ — {_fail} · ยกเลิกทั้งหมดแล้ว ไม่มีอะไรเปลี่ยน",
                    level=2, duration=0)
            else:
                # ★ 2.3.7 (review ER-06) — เดิมหัวข้อ 'Error' + ข้อความ exception ดิบ
                self.iface.messageBar().pushMessage(
                    "Move Node", f"ย้ายไม่สำเร็จ — ยกเลิกทั้งหมดแล้ว ไม่มีอะไรเปลี่ยน · {self._LOG_HINT}", level=2, duration=0)
            return False
