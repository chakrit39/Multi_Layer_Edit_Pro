# -*- coding: utf-8 -*-
"""เครื่องมือวาดเส้นและวัดระยะ (ชั้นเส้นชั่วคราว, เส้นขนาน, จุดพิกัด)

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import math
import os
import re
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import (Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsGeometry,
                       QgsMessageLog, QgsPointXY, QgsProject, QgsSnappingConfig, QgsTolerance, QgsUnitTypes,
                       QgsVectorLayer, QgsWkbTypes)
from ..core.const import _MLEP_MAIN_FILE
from ..core.util import _log_exc

# ★ 2.4.0 — บางเมธอดเรียก MultiLayerEditPro.<ชื่อ> ตรง ๆ (ย้ายมาตรงตัว) ⇒ main.py ผูกชื่อนี้เป็นคลาสหลักทันทีหลังสร้างคลาส
MultiLayerEditPro = None


class LineToolMixin:
    """เครื่องมือวาดเส้นและวัดระยะ (ชั้นเส้นชั่วคราว, เส้นขนาน, จุดพิกัด)"""

    def _line_clear_save_flag(self):
        if not getattr(self, "_alive", True):
            return
        self._line_in_save = False

    def _line_restore_after_write(self):
        """ตาข่ายรอง: สร้างชั้นเส้นคืนหลังการบันทึกจบ ไม่ว่าจะสำเร็จหรือล้มเหลว

        _line_sync_layer มีด่าน _line_window_open อยู่แล้ว ⇒ ถ้าหน้าต่างปิดไปแล้วจะไม่สร้างคืน
        และทำซ้ำกับ _on_project_saved ได้ ไม่มีผลข้างเคียง (ถ้าชั้นมีอยู่แล้วก็แค่เขียนทับเส้นเดิม)
        """
        if not getattr(self, "_alive", True):
            return
        # ★ 2.3.7 rc3 (Windows audit 🔴1) — ตัวจับเวลานี้ยิงในลูปของกล่องที่เด้งหลังบันทึกได้ (เช่นกล่อง "บันทึกไม่สำเร็จ" ของ QGIS)
        #   และ _line_sync_layer สร้าง/ถอดชั้นได้ ⇒ รอกล่องปิดก่อน (ทางบันทึกสำเร็จ projectSaved สร้างคืนให้แล้ว รอบนี้แค่เขียนทับ)
        if self._line_wait_free(self._line_restore_after_write):
            return
        try:
            self._line_sync_layer()
        except Exception:
            _log_exc("_line_restore_after_write: สร้างชั้นเส้น/จุดวัดระยะคืนหลังบันทึกโปรเจกต์ไม่สำเร็จ",
                     once_key="ER-09:restore-after-write")                  # ★ 2.4.0 (review ER-09)

    def _line_switch_settle(self):
        """★ 2.3.7 (review DI-19) — หลังโปรเจกต์ถูกล้างจบ: ไม่มีชื่อไฟล์ = New/Close (ไม่มีไฟล์ใหม่กำลังเปิด) ⇒ ปลดธง"""
        if not getattr(self, "_alive", True):
            return
        try:
            if not QgsProject.instance().fileName():
                self._line_switching = False
        except Exception:
            pass

    def _line_remember_project_path(self):
        """จำพาธโปรเจกต์ล่าสุด — เฉพาะเมื่อไฟล์ถูกเขียนออกมาจริง

        🔴 ต้องไม่ทำงานระหว่างที่กำลังสลับโปรเจกต์อยู่
           ตัวจับเวลาสองตัวนี้เข้าคิวรวมกันได้ (บันทึกแล้วสลับอำเภอทันที)
           ถ้าตัวนี้ทำงานก่อน จะไปจำพาธของ "อำเภอใหม่" ไว้เป็นของเก่า
           แล้ว _line_after_project_load จะเทียบได้ว่า "ไฟล์เดิม" ⇒ ไม่ล้างเส้นอำเภอเก่า
        """
        if not getattr(self, "_alive", True):
            return
        if getattr(self, "_line_switching", False):
            return
        try:
            fn = QgsProject.instance().fileName()
            if fn and os.path.exists(fn):
                self._line_project_path = fn
        except Exception:
            pass

    def _line_after_project_load(self):
        """โปรเจกต์เปลี่ยนเสร็จแล้ว — ถ้าเป็น "คนละไฟล์" กับที่เปิดอยู่ก่อน ให้ทิ้งเส้นของอำเภอเดิม

        ทำไมต้องแยกสองกรณีนี้ (ผู้ตรวจจับได้ 2 ก.ย. 69):
          · เปลี่ยนอำเภอ (คนละไฟล์)             -> ต้องทิ้ง เส้นเป็นพิกัดของพื้นที่เดิม
          · Revert / เปิดไฟล์เดิมซ้ำ (ไฟล์เดิม)  -> **ต้องเก็บไว้**
            Revert คือคำสั่งที่พนักงานกดเพื่อทิ้งการแก้ "รูปแปลง" ไม่ได้ตั้งใจทิ้งงานวัดระยะ
            ถ้าทิ้งให้ = งานวัดทั้งช่วงหายในคลิกเดียว ไม่ถาม และกู้คืนไม่ได้

        🔴 ต้องเทียบกับพาธที่จำไว้ "ตอนโปรเจกต์ก่อนหน้าโหลดเสร็จ" เท่านั้น
           ห้ามอ่าน fileName() ตอน aboutToBeCleared เพราะ QGIS ตั้งค่าเป็นพาธใหม่ไปแล้ว
        เรียกแบบเลื่อนออกไป (QTimer) ทั้งจากขาล้างและขาอ่าน — ทำซ้ำได้ ไม่มีผลข้างเคียง
        """
        if not getattr(self, "_alive", True):
            return
        # ★ 2.3.7 rc3 (Windows audit 🔴1) — ทางนี้สร้าง/ถอดชั้นเส้น (_line_sync_layer · _line_forget_lines) ⇒ ไม่ทำในลูปของกล่อง modal
        #   ที่ QGIS/ปลั๊กอินอื่นเปิดหลังโหลด (QGIS อาจถือ pointer ของเลเยอร์อยู่) · ระหว่างรอ _line_switching ยังเป็น True
        #   (งานชั้นเส้นตาม CRS ข้ามไป · ไม่จำพาธ) แล้วรอบที่ทำจริงตัดสิน "ไฟล์เดิม/เปลี่ยนสาขา" เหมือนเดิมทุกอย่าง
        if self._line_wait_free(self._line_after_project_load):
            return
        try:
            now = QgsProject.instance().fileName()
        except Exception:
            self._line_switching = False
            return
        # 🔴🔴 3 ก.ย. 69 (ผู้ตรวจจับได้ · ทำซ้ำได้บน QGIS 3.40.6 Windows) —
        #   ยังไม่มีชื่อไฟล์ = โปรเจกต์อยู่ระหว่างถูกล้าง/ยังโหลดไม่เสร็จ ⇒ "ยังตัดสินไม่ได้"
        #   QgisApp::fileRevert() และ fileOpen() ต่างเรียก addProject() ซึ่งเรียก
        #   closeProject() -> QgsProject::clear() ก่อน แล้วค่อย read()
        #   ⇒ ตัวจับเวลาที่ตั้งไว้จาก aboutToBeCleared ทำงานตอน fileName() ยัง "ว่าง"
        #     เดิมจึงเทียบได้ว่า "" != พาธเดิม = เปลี่ยนอำเภอ แล้วลบงานวัดทั้งวันทิ้ง
        #     ทั้งที่พนักงานแค่กด Revert เพื่อทิ้งการแก้รูปแปลง
        #   (ทดสอบด้วย QgsProject.read() ตรง ๆ จะไม่เจอ เพราะ read() ไม่ล้างก่อน —
        #    เป็นเหตุที่เทสต์รุ่นแรกรายงานว่าผ่าน)
        #   ปล่อยให้สัญญาณ readProject (ซึ่งยิงตอนโหลดเสร็จจริง) เป็นคนตัดสินแทน
        #   ★ ไม่แตะ _line_project_path ตรงนี้ เพื่อให้รอบหน้ายังเทียบกับพาธเดิมได้ถูก
        if not now:
            self._line_switching = False
            return
        prev = getattr(self, "_line_project_path", None)
        self._line_project_path = now
        self._line_switching = False
        if prev is None or self._same_project_file(now, prev):
            # ไฟล์เดิม (Revert / เปิดซ้ำ) -> เก็บงานวัดไว้
            # 🔴 แต่ต้องสร้าง "ชั้นเส้น" คืนด้วย เพราะการล้างโปรเจกต์ทำลายชั้นเดิมไปแล้ว
            #    ถ้าไม่คืน เส้นจะยังเห็นบนจอแต่เครื่องมืออื่นเลิกเกาะแนวนั้น (ผิดกับที่ CHANGELOG บอก)
            try:
                self._line_sync_layer()
            except Exception:
                _log_exc("_line_after_project_load: สร้างชั้นเส้น/จุดวัดระยะคืนหลังเปิดไฟล์เดิมซ้ำไม่สำเร็จ",
                         once_key="ER-09:load-sync")                        # ★ 2.4.0 (review ER-09)
            self._line_reborrow_if_drawing()
            return
        try:
            self._line_forget_lines()
        except Exception:
            _log_exc("_line_after_project_load: ทิ้งเส้นวัดของสาขาเดิมไม่สำเร็จ", once_key="ER-09:load-forget")  # ★ 2.4.0 (ER-09)
        self._line_reborrow_if_drawing()

    def _line_reborrow_if_drawing(self):
        """โปรเจกต์ใหม่มาแล้ว ถ้ายังอยู่ในโหมดวาดเส้น ต้องยืมแม่เหล็กใหม่

        ★ 2 ก.ย. 69 — การยืมผูกกับ "โปรเจกต์" ไม่ใช่กับหน้าต่าง พอสลับอำเภอ
          _on_project_reset ทิ้งการยืมของโปรเจกต์เก่าไป (ถูกแล้ว) แต่โปรเจกต์ใหม่
          ยังไม่มีใครยืมให้ ⇒ ปุ่มยังขึ้นว่า "■ หยุดวาด" แต่คลิกลงไปได้พิกัดดิบ
          (วัดได้ คลาดจากมุมแปลง 4.475 ม. ที่ 3.214 ม./พิกเซล)
        """
        try:
            from ..map_tools import DrawLineTool
            if not isinstance(getattr(self, "temp_tool", None), DrawLineTool):
                return
            btn = getattr(self, "_line_toggle", None)
            if btn is None or not btn.isChecked():
                return
            self._line_snap_borrow()
        except Exception:
            _log_exc("_line_reborrow_if_drawing: ยืมแม่เหล็กให้โปรเจกต์ใหม่ไม่สำเร็จ", once_key="ER-09:reborrow")  # ★ 2.4.0 (ER-09)

    def _line_sweep_ghosts(self):
        """ลบชั้น "เส้นที่วาด (Line) — MLEP" ที่ติดมากับไฟล์โปรเจกต์

        ★ เทียบ "ชื่อเป๊ะ ๆ" ไม่ใช่ startswith — กันไปโดนชั้นของปลั๊กอินวาดเส้นตัวเดิม
          (CHK_Node-Topo ใช้ชื่อ "เส้นที่วาด (Line)" ซึ่งไม่มีคำว่า MLEP ต่อท้าย)
        ★ และต้องเป็น memory provider เท่านั้น
        ★ ข้ามชั้นของรอบปัจจุบันที่เราเพิ่งสร้างเอง (ถ้ามี)
        """
        if not getattr(self, "_alive", True):
            return
        # ★ 2.3.7 rc3 (Windows audit 🔴1) — removeMapLayers ในลูปของกล่อง modal (เช่นกล่องเลือก transformation ที่ QGIS เปิดหลังโหลด)
        #   = ลบชั้นที่ QGIS ยังถือ pointer ไว้ ⇒ ดับ · รอกล่องปิดก่อน (ชั้นผีค้างนานขึ้นไม่กี่ร้อยมิลลิวินาที ไม่มีผลอื่น)
        if self._line_wait_free(self._line_sweep_ghosts):
            return
        try:
            prj = QgsProject.instance()
            # ★ 2.3.6 — ชั้นจุดที่กรอกพิกัดก็ติดมากับไฟล์ได้แบบเดียวกัน (ไฟล์ที่เซฟด้วยรุ่นอื่น)
            mine = {getattr(self, "_line_layer_id", None), getattr(self, "_line_pt_layer_id", None)}
            ours = (self.LINE_LAYER_NAME, self.LINE_PT_LAYER_NAME)
            doomed = []
            for lid, lyr in list(prj.mapLayers().items()):
                if lid in mine:
                    continue
                try:
                    if lyr.name() not in ours:
                        continue
                    if lyr.dataProvider().name() != "memory":
                        continue
                except Exception:
                    _log_exc("_line_sweep_ghosts: อ่านชื่อ/ชนิดของชั้น %s ไม่ได้ (ข้ามชั้นนั้น)" % lid,
                             once_key="ER-09:sweep-read")                   # ★ 2.4.0 (review ER-09)
                    continue
                doomed.append(lid)
            if not doomed:
                return
            was = prj.isDirty()
            prj.removeMapLayers(doomed)
            if not was:
                prj.setDirty(False)   # ไม่ให้กลายเป็น "โปรเจกต์มีการแก้ไข" เพราะการเก็บกวาดของเรา
            # ★ 2.4.0 (review ER-09) — ถอดไม่ออก = ชั้นผียังอยู่ บันทึกเมื่อไรก็ลงไฟล์อีก ⇒ Log + แถบเตือน
            if any(prj.mapLayer(lid) is not None for lid in doomed):
                QgsMessageLog.logMessage("_line_sweep_ghosts: ถอดชั้นชั่วคราวที่ติดมากับไฟล์ไม่ออก (%s)" % ", ".join(
                    lid for lid in doomed if prj.mapLayer(lid) is not None), "MLEP", Qgis.Warning)
                self._qgz_ghost_warn()
        except Exception:
            _log_exc("_line_sweep_ghosts: กวาดชั้นชั่วคราวที่ติดมากับไฟล์โปรเจกต์ไม่สำเร็จ",
                     once_key="ER-09:sweep")                                # ★ 2.4.0 (review ER-09)
            self._qgz_ghost_warn()

    def _line_forget_lines(self):
        """ทิ้งเส้นที่วัดไว้ทั้งหมด (ใช้ตอนเปลี่ยนโปรเจกต์ — เส้นของอำเภอเดิมต้องไม่ตามไป)"""
        # ★ 2.3.7 (review DI-19) — บอกพนักงานเมื่อมีของถูกทิ้งจริง (เดิมหายเงียบ ๆ ทั้งเส้นและจุด)
        try:
            _it0 = getattr(self, "_line_item", None)
            _n_ln = (len(_it0.lines) + (1 if len(_it0.temp) >= 2 else 0)) if _it0 is not None else 0
        except Exception:
            _n_ln = 0
        _n_pt = len(getattr(self, "_line_pts", None) or [])
        if _n_ln or _n_pt:
            try:
                self.iface.messageBar().pushMessage(
                    "วาดเส้น", "ทิ้งเส้นวัด %d เส้น · จุด %d จุด ของสาขาเดิมแล้ว" % (_n_ln, _n_pt),
                    level=0, duration=8)
            except Exception:
                pass
        # ★ 2.3.6 — จุดที่กรอกพิกัดเป็นพิกัดของสาขาเดิมเหมือนกัน ⇒ ทิ้งไปด้วย
        #   (ทำก่อนด่าน `it is None` — ไม่ให้จุดค้างข้ามสาขาแม้ไอเทมบนแคนวาสยังไม่ถูกสร้าง)
        self._line_pts = []
        self._line_pt_seq = 0
        try:
            self._line_pt_refresh_list()
        except Exception:
            pass
        it = getattr(self, "_line_item", None)
        if it is None:
            return
        try:
            it.lines = []
            it.temp = []
            it.cursor = None
            it.updatePosition()
        except Exception:
            pass
        self._line_clear_undo = None       # ★ 2.3.7 (UX-37) — สำเนาที่ ↺ เรียกคืนได้เป็นเส้นของสาขาเดิม ⇒ ทิ้ง
        # ★★ 2 ก.ย. 69 — ต้องล้าง "แนวอ้างอิงมุม" ผ่าน _line_clear_ref เท่านั้น
        #   ห้ามตั้ง self._line_ref_az = None เฉย ๆ เพราะป้ายบนหน้าต่างกับคอมโบ "นับมุมจาก"
        #   จะยังค้างเป็น "แนวอ้างอิงที่ตั้งไว้ 45°" ทั้งที่ค่าถูกล้างไปแล้ว
        #   ⇒ พนักงานกด Shift ล็อกมุมต่อ จะได้มุมที่นับจากทิศเหนือแทน โดยหน้าจอยังบอกว่า 45°
        #      = เส้นเบี้ยวเงียบ ๆ (วัดได้ 29 ม. ในเคสที่ผู้ตรวจลอง) แล้วเส้นผิดแนวนั้น
        #      ยังถูกใช้เป็นแนวให้ Move Node เกาะต่ออีก
        try:
            self._line_clear_ref()
        except Exception:
            self._line_ref_az = None
        # ★★ 3 ก.ย. 69 — ต้องถอด "ชั้นเส้น" ออกด้วย ไม่ใช่แค่ล้างข้อมูลในหน่วยความจำ
        #   วัดได้: หลังเรียกฟังก์ชันนี้ lines=0 แต่ชั้น "เส้นที่วาด (Line) — MLEP"
        #   ยังอยู่ในโปรเจกต์ ⇒ มีทางที่ชั้นของอำเภอเดิมค้างไปโผล่ในโปรเจกต์ใหม่
        #   (_line_layer_drop ปลอดภัยตรงนี้ เพราะจุดนี้ไม่ได้อยู่ในสัญญาณ aboutToBeCleared)
        try:
            self._line_layer_drop()
        except Exception:
            pass
        # อัปเดตตารางบนหน้าต่างถ้ายังเปิดค้างอยู่ — ไม่ให้เหลือยอดระยะของอำเภอเดิมค้างจอ
        try:
            if getattr(self, "_line_tree", None) is not None:
                self._line_tree.clear()
            if getattr(self, "_line_total", None) is not None:
                self._line_total.setText("รวมทั้งหมด %s" % it.fmt(0.0))
        except Exception:
            pass

    def _line_snap_resync(self):
        """อัปเดต "ลายเซ็น snapping ที่จำไว้" ให้ตรงกับของจริง ถ้ายังยืมแม่เหล็กอยู่

        🔴 3 ก.ย. 69 (ผู้ตรวจจับได้ · ทดสอบซ้ำบน QGIS 3.40.6 Windows แล้ว) —
          _line_snap_return ตัดสินความเป็นเจ้าของด้วยการเทียบลายเซ็น ถ้าไม่ตรงจะถือว่า
          "มีคนอื่นมาตั้งค่าใหม่" แล้วปล่อยทิ้งไว้ ไม่คืนค่าให้
          ปัญหา: พอมีเลเยอร์ถูกเพิ่มเข้าโปรเจกต์ระหว่างอยู่ในโหมดวาดเส้น QGIS ใส่แถว
          IndividualLayerSettings ให้ชั้นใหม่ "เอง" (วัดแล้ว: ILS 2 -> 3 แถว)
          ⇒ ลายเซ็นเปลี่ยนทั้งที่ไม่มีใครมาแย่งความเป็นเจ้าของ
          ⇒ ตอนปิดหน้าต่างวาดเส้น แม่เหล็กที่พนักงาน "ตั้งใจปิดไว้" ถูกเปิดค้างถาวร
          เดิมโค้ดอัปเดตลายเซ็นไว้ที่ท้าย _reapply_snap_limit เท่านั้น จึงหลุดทุกครั้งที่
          ฟังก์ชันนั้น return ออกไปก่อน (ไม่มีชั้นทำงาน / ไม่มีอะไรเปลี่ยน)
          วัดผลก่อนแก้: โหมด Advanced + มีเลเยอร์เพิ่มระหว่างวาด -> แม่เหล็กเปิดค้าง
                        โหมด Advanced ไม่มีเลเยอร์เพิ่ม / โหมด AllLayers -> คืนถูก
        """
        if not getattr(self, "_line_snap_borrowed", False):
            return
        try:
            self._line_wrote_snap = self._snap_sig(QgsProject.instance().snappingConfig())
        except Exception:
            # ★ 2.4.0 (review ER-09) — ลายเซ็นไม่ตรง ⇒ ตอนคืนอาจเข้าใจว่ามีคนอื่นตั้งค่าแล้วไม่คืนแม่เหล็กที่ยืม
            _log_exc("_line_snap_resync: อัปเดตลายเซ็นแม่เหล็กที่ยืมไม่สำเร็จ", once_key="ER-09:snap-resync")
            # ★ rc1 (F8 · §5.1 ER-09) — + แถบเตือน (เดิมมีแค่ Warning ใน Log ⇒ ไฟล์ถูกบันทึก enabled="1" โดยไม่มีใครรู้)
            self._qgz_leftover_warn("แม่เหล็ก (snapping) ที่ปลั๊กอินเปิดให้หน้าต่างวาดเส้นอาจไม่ถูกคืน — ถ้าบันทึกโปรเจกต์ ค่าแม่เหล็กนี้จะติดไปในไฟล์ · "
                    "ตรวจ/ปิดแม่เหล็กเองก่อนบันทึกโปรเจกต์")

    def _line_tool_layers(self, exclude=()):
        """ชั้น "เส้นที่วาด (Line)" ของปลั๊กอินวาดเส้น&วัดระยะ — เอาไว้ให้ snap ติดตอนแก้ไข

        (ผู้ใช้สั่ง 26 ส.ค. 69) พนักงานวาดเส้นอ้างอิง/เส้นวัดระยะไว้ แล้วอยากลากมุมแปลง
        หรือหมุดเข้าไปเกาะเส้นนั้นได้ตรง ๆ เหมือนที่ snap ติดชั้นหมุดหลักฐาน CT
        จับด้วย **ชื่อชั้น** เพราะเป็น memory layer ที่ปลั๊กอินอีกตัวสร้าง (ไม่มีคีย์ร่วมให้ยึด)
        เอาเฉพาะชั้นเส้น และไม่เอาชั้นป้ายระยะ (ชื่อคนละอัน แต่เป็น LineString เหมือนกัน)
        """
        out = []
        ex = {l.id() for l in exclude if l}
        try:
            for l in QgsProject.instance().mapLayers().values():
                if l.id() in ex:
                    continue
                try:
                    gt = l.geometryType()
                except Exception:
                    continue        # raster/ชั้นที่ไม่มี geometryType
                n = (l.name() or "").strip()
                # ★ 2.3.6 — จุดที่กรอกพิกัดในหน้าต่างวาดเส้น ให้วาดเส้น/Move Node เกาะได้
                if gt == QgsWkbTypes.PointGeometry:
                    if n == self.LINE_PT_LAYER_NAME or n.startswith(self.LINE_PT_LAYER_NAME):
                        out.append(l)
                    continue
                if gt != QgsWkbTypes.LineGeometry:
                    continue
                if n == self.LINE_TOOL_LABEL:
                    continue
                # ตรงชื่อเป๊ะ หรือขึ้นต้นด้วยชื่อนั้น (เผื่อผู้ใช้ทำสำเนา -> QGIS เติม " copy"/" (1)")
                if n == self.LINE_TOOL_LAYER or n.startswith(self.LINE_TOOL_LAYER):
                    out.append(l)
        except Exception:
            pass
        return out

    def start_draw_line(self):
        """เปิดหน้าต่างวาดเส้น แล้วเข้าโหมดวาดให้เลย
        ★ rc2 (audit A1-08) — ไม่เรียก cancel_transform แล้ว: เดิมล้างการเลือกทุกชั้นและเลิกเครื่องมือที่ทำค้าง (กลับเครื่องมือ Select)
          ⇒ วัดระยะกลางงาน Move Node/Align แล้วที่เลือกไว้หายทั้งหมด · ขัดกับ ▶ ในหน้าต่างที่ "พัก" เครื่องมือเดิม
          ตอนนี้ปุ่ม 📐 พักเครื่องมือเดิมแบบเดียวกับ ▶ (_line_set_drawing จำไว้ใน _line_prev_tool · ออกจากโหมดวาด = คืนให้)"""
        self._line_build_dock()
        # เปิดใหม่หลังเคยปิดไป -> เอาเส้นที่ซ่อนไว้กลับมาแสดง
        if getattr(self, "_line_item", None) is not None:
            self._line_item.setVisible(True)
            self._line_sync_layer()      # สร้างชั้นเส้นคืนจากข้อมูลที่เก็บไว้
        self._line_dock.show()
        self._line_dock.raise_()
        self._line_dock.activateWindow()
        self._line_pt_update_hint()      # ★ 2.3.7 — เปิดหน้าต่างใหม่ = อ่านระบบพิกัดล่าสุด (ชั้น/แผนที่อาจเปลี่ยนระหว่างปิด)
        self._line_set_drawing(True)

    # ---------- สร้างหน้าต่าง ----------
    def _line_build_dock(self):
        if getattr(self, "_line_dock", None) is not None:
            return
        from ..map_tools import LineMeasureItem
        canvas = self.iface.mapCanvas()
        self._line_item = LineMeasureItem(canvas)
        self._line_item.layer_shown = self._line_layer_shown      # ★ 2.3.7 (UX-49)
        # ★ 2.3.7 (review DI-40) — จุดของเส้นวัดเป็นพิกัดใน CRS ของแผนที่ ณ ตอนคลิก ⇒ จำ CRS ไว้ แล้วแปลงตามเมื่อ CRS เปลี่ยน
        self._line_crs = QgsCoordinateReferenceSystem(canvas.mapSettings().destinationCrs())
        try:
            canvas.destinationCrsChanged.connect(self._line_on_crs_changed)
        except Exception:
            pass
        self._line_snap_borrowed = False
        self._line_ref_az = None

        # หน้าต่างลอย (ไม่ใช่แผงตรึงข้างจอ) — ย้าย/ย่อขยายได้อิสระ
        # ★ ใช้ธง Qt.Dialog + มี parent เป็นหน้าต่างหลักของ QGIS
        #   = ลอยอยู่หน้า QGIS เสมอ ไม่จมหายไปข้างหลังเวลาคลิกบนแผนที่
        #   (พฤติกรรมเดียวกับแผงหลักของปลั๊กอินเราเอง)
        #   ต้นฉบับใช้ Qt.Window ซึ่งกลายเป็นหน้าต่างอิสระ จมหลัง QGIS ได้
        win = QtWidgets.QDialog(self.iface.mainWindow())
        win.setWindowFlags(QtCore.Qt.Dialog
                           | QtCore.Qt.WindowTitleHint
                           | QtCore.Qt.WindowMinMaxButtonsHint
                           | QtCore.Qt.WindowCloseButtonHint)
        win.setModal(False)
        win.setWindowTitle("%s  %s" % (self.LINE_DOCK_TITLE, self.version))
        win.setObjectName("MLEP_LineMeasureWindow")
        win.setMinimumWidth(300)
        icon_path = os.path.join(os.path.dirname(_MLEP_MAIN_FILE), 'icon.png')
        win.setWindowIcon(QtGui.QIcon(icon_path))
        # ★ 2.3.6 (audit รอบ 2) — เพิ่มกลุ่ม "ขึ้นจุดจากพิกัด" แล้วหน้าต่างสูงขั้นต่ำ ~1,055 px
        #   เกินจอโน้ตบุ๊ก 1080p ที่ขยาย 125% (ใช้ได้ ~830 px) ⇒ ส่วน "ผลการวัด" เลื่อนไปดูไม่ได้
        #   ⇒ ใส่เนื้อหาทั้งหน้าต่างในกรอบเลื่อน · ย่อหน้าต่างได้ · เลื่อนดูส่วนล่างได้
        _outer = QtWidgets.QVBoxLayout(win)
        _outer.setContentsMargins(0, 0, 0, 0)
        _sc = QtWidgets.QScrollArea(win)
        _sc.setWidgetResizable(True)
        _sc.setFrameShape(QtWidgets.QFrame.NoFrame)
        _sc.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        _body = QtWidgets.QWidget()
        _sc.setWidget(_body)
        _outer.addWidget(_sc)
        root = QtWidgets.QVBoxLayout(_body)
        root.setSpacing(6)

        def grp(title):
            g = QtWidgets.QGroupBox(title)
            g.setStyleSheet("QGroupBox::title{background:transparent;}")
            return g, QtWidgets.QVBoxLayout(g)

        # ---------- กลุ่ม 1: เครื่องมือวาดเส้น ----------
        # ★ 2.3.6 (1 ต.ค. 69 เจ้าของงานจัดใหม่) — ปุ่ม เริ่มวาด / ล้างเส้น · ระยะบนเส้นและจุดหัก "แสดงเสมอ" (ซ่อนตัวเลือก)
        g1, v1 = grp("เครื่องมือวาดเส้น (Line)")
        v1.setSpacing(5)
        row = QtWidgets.QHBoxLayout()
        self._line_toggle = QtWidgets.QPushButton()
        self._line_toggle.setToolTip("เปิด/ปิดโหมดวาดเส้นวัดระยะ — เกาะหมุดและมุมแปลงให้ · ไม่แตะข้อมูลในฐาน")
        self._line_toggle.setCheckable(True)
        self._line_toggle.setFixedHeight(34)
        self._line_toggle.clicked.connect(lambda on: self._line_set_drawing(on))
        b_clr = QtWidgets.QPushButton("🧹 ล้างเส้น")
        b_clr.setToolTip("ลบเส้นวัดระยะที่วาดไว้ทั้งหมดออกจากจอ — ไม่แตะข้อมูลในฐาน\n"
                         "กดพลาด = กด ↺ ถอยจุด/เส้น เรียกคืนได้ (ก่อนเริ่มวาดเส้นใหม่)")   # ★ 2.3.7 (UX-37)
        b_clr.setFixedHeight(34)
        b_clr.setStyleSheet("color:#b71c1c;")
        b_clr.clicked.connect(self._line_clear)
        row.addWidget(self._line_toggle, 1)
        row.addWidget(b_clr, 1)
        v1.addLayout(row)
        # ตัวเลือกเดิม "แสดงระยะบนเส้น / แสดง Node ที่จุดหัก" — เจ้าของงานสั่งบังคับแสดงเสมอแล้วซ่อนไว้
        #   คงวัตถุไว้ (ซ่อน · ไม่ต่อสัญญาณ) ให้โค้ด/เทสเดิมที่อ้างถึงไม่พัง
        self._line_lbl_chk = QtWidgets.QCheckBox("แสดงระยะบนเส้น (เมตร)", win)
        self._line_lbl_chk.setChecked(True)
        self._line_lbl_chk.setVisible(False)
        self._line_node_chk = QtWidgets.QCheckBox("แสดง Node ที่จุดหัก", win)
        self._line_node_chk.setChecked(True)
        self._line_node_chk.setVisible(False)
        self._line_item.show_labels = True
        self._line_item.show_nodes = True

        hint = QtWidgets.QLabel(
            "คลิกซ้าย = ลงจุด · คลิกขวา/ดับเบิลคลิก = จบเส้น\n"
            "Backspace / Ctrl+Z = ถอยจุด · Esc = ทิ้งเส้นที่กำลังวาด")      # ★ 2.3.7 (DI-25) + Ctrl+Z
        hint.setStyleSheet("color:#546e7a; font-size:11px;")
        hint.setWordWrap(True)
        v1.addWidget(hint)
        root.addWidget(g1)

        # ---------- กลุ่ม 2: ล็อกการวาด ----------
        # ★ 2.3.6 (1 ต.ค. 69) — เอา "แนวอ้างอิงมุม" (Ctrl + คลิก 2 จุด) และ "นับมุมจาก" ออก ·
        #   ล็อกระยะเลือกหน่วยได้ (เมตร / เส้น · 1 เส้น = 40 ม.) · Shift แบบใหม่ (ดู DrawLineTool.constrain)
        g2, v2 = grp("ล็อกการวาด")
        v2.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        self._line_dist_chk = QtWidgets.QCheckBox("ล็อกระยะ")
        self._line_dist_chk.setToolTip("บังคับให้ทุกช่วงของเส้นยาวเท่ากับตัวเลขข้าง ๆ พอดี — คลิกได้แค่ทิศทาง")
        self._line_dist_spin = QtWidgets.QDoubleSpinBox()
        self._line_dist_spin.setRange(0.01, 100000.0)
        self._line_dist_spin.setDecimals(2)
        self._line_dist_spin.setValue(10.0)
        self._line_dist_unit = self._line_unit_combo()
        r.addWidget(self._line_dist_chk)
        r.addWidget(self._line_dist_spin, 1)
        r.addWidget(self._line_dist_unit)
        v2.addLayout(r)

        r = QtWidgets.QHBoxLayout()
        self._line_ang_chk = QtWidgets.QCheckBox("กด Shift เพื่อล็อกมุม")
        self._line_ang_chk.setToolTip(
            "ไม่ติ๊ก: กด Shift ค้างตอนลากเส้น = ล็อกแนวที่กำลังลากอยู่ แล้วยังลากให้สั้น/ยาวได้ตามแนวนั้น\n"
            "  วางเมาส์ให้ snap ติดหมุด/มุมแปลงก่อน แล้วค่อยกด Shift = ล็อกแนวตรงไปที่จุดนั้นพอดี\n"
            "  คลิกต่อทั้งที่กดค้าง = ลงจุดต่อบนแนวเดิม\n"
            "ติ๊ก: กด Shift ค้าง = หักมุมทีละขั้นตามตัวเลขข้าง ๆ โดยนับจากแนวช่วงก่อนหน้า (2 จุดล่าสุด)\n"
            "  ช่วงแรกของเส้นยังไม่มีช่วงก่อนหน้า ⇒ นับจากทิศเหนือ")
        self._line_ang_spin = QtWidgets.QDoubleSpinBox()
        self._line_ang_spin.setRange(0.01, 180.0)
        self._line_ang_spin.setDecimals(2)
        self._line_ang_spin.setValue(90.0)
        self._line_ang_spin.setSuffix(" °")
        r.addWidget(self._line_ang_chk, 1)
        r.addWidget(self._line_ang_spin)
        v2.addLayout(r)
        self._line_bind_unit(self._line_dist_spin, self._line_dist_unit)
        hint2 = QtWidgets.QLabel(
            "Shift ค้าง (ไม่ติ๊ก) = ล็อกแนวที่กำลังลาก ยืด/หดได้ · คลิกต่อทั้งที่กดค้าง = ต่อบนแนวเดิม\n"
            "ติ๊กไว้ = หักมุมทีละขั้น นับจากช่วงก่อนหน้า (ช่วงแรกนับจากทิศเหนือ)")
        hint2.setStyleSheet("color:#546e7a; font-size:11px;")
        hint2.setWordWrap(True)
        v2.addWidget(hint2)
        # คงวัตถุของ "นับมุมจาก" / "แนวอ้างอิงมุม" ไว้แบบซ่อน — โค้ดล้างค่าตอนเปลี่ยนสาขา/ล้างเส้นยังอ้างถึง
        self._line_basis_cb = QtWidgets.QComboBox(win)
        self._line_basis_cb.addItem("ทิศเหนือ (0°)", "north")
        self._line_basis_cb.addItem("แนวอ้างอิงที่ตั้งไว้", "ref")
        self._line_basis_cb.setVisible(False)
        self._line_ref_lbl = QtWidgets.QLineEdit("ยังไม่ได้ตั้ง", win)
        self._line_ref_lbl.setReadOnly(True)
        self._line_ref_lbl.setVisible(False)
        root.addWidget(g2)

        for wdg, sig in ((self._line_dist_chk, "toggled"), (self._line_ang_chk, "toggled"),
                         (self._line_dist_spin, "valueChanged"),
                         (self._line_ang_spin, "valueChanged"),
                         (self._line_dist_unit, "currentIndexChanged")):
            getattr(wdg, sig).connect(lambda *_a: self._line_push_locks())

        # ---------- กลุ่ม 3: เส้นขนาน (Offset) — บรรทัดเดียว (เจ้าของงานสั่ง 1 ต.ค.) ----------
        g35, v35 = grp("เส้นขนาน (Offset)")
        v35.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(QtWidgets.QLabel("ระยะ:"))
        self._line_off_spin = QtWidgets.QDoubleSpinBox()
        self._line_off_spin.setRange(0.01, 100000.0)
        self._line_off_spin.setDecimals(2)
        self._line_off_spin.setValue(5.0)
        r.addWidget(self._line_off_spin, 1)
        self._line_off_unit = self._line_unit_combo()
        self._line_bind_unit(self._line_off_spin, self._line_off_unit)
        r.addWidget(self._line_off_unit)
        b_offl = QtWidgets.QPushButton("◀")
        b_offl.setToolTip("สร้างเส้นขนานกับเส้นที่วาดไว้ ไปทางซ้าย ตามระยะที่กรอก")
        b_offr = QtWidgets.QPushButton("▶")
        b_offr.setToolTip("สร้างเส้นขนานกับเส้นที่วาดไว้ ไปทางขวา ตามระยะที่กรอก")
        b_offl.clicked.connect(lambda: self._line_offset(True))
        b_offr.clicked.connect(lambda: self._line_offset(False))
        for b in (b_offl, b_offr):
            b.setFixedHeight(28)
            b.setFixedWidth(40)
            r.addWidget(b)
        v35.addLayout(r)
        hint35 = QtWidgets.QLabel(
            "ทำจากเส้นที่เลือกไว้ในช่อง \"ผลการวัด\" · ไม่ได้เลือก = ใช้เส้นล่าสุด · ทำแล้วจะเลือกเส้นที่ได้ให้ "
            "⇒ กดอีกครั้ง = ขนานต่อจากเส้นที่ได้ล่าสุด (อยากได้อีกข้างของเส้นเดิม ให้คลิกเลือกเส้นเดิมก่อน)\n"
            "◀ ซ้าย / ▶ ขวา นับตามทิศที่วาดเส้นนั้น (จากจุดแรกไปจุดสุดท้าย) · เส้นที่ได้มีทิศเดียวกับเส้นต้นทาง")
        hint35.setStyleSheet("color:#546e7a; font-size:11px;")
        hint35.setWordWrap(True)
        v35.addWidget(hint35)
        root.addWidget(g35)

        # ---------- กลุ่ม 4: สร้างจุดจากค่าพิกัด ----------
        # ★ 2.3.6 (25 ก.ย. 69 เจ้าของงานขอ · จัดใหม่ 1 ต.ค.) — สร้างได้หลายจุด · snap ได้ · แสดงเหมือนจุดหักของเส้น
        #   ไม่ต้องใส่ชื่อ (ระบบตั้ง P1, P2 … ไว้ในรายการเอง)
        g36, v36 = grp("สร้างจุดจากค่าพิกัด")
        v36.setSpacing(5)
        # ★ 2.3.7 b13 (เจ้าของงานสั่ง 3 ต.ค. 69) — ช่อง N ก่อน E (ป้าย · ลำดับ · Tab · Enter · คำแนะนำ)
        #   วางคู่ค่าลงช่องไหนก็ได้ ⇒ แยก N/E ตามขนาดตัวเลข (ดู _parse_coord_text) ⇒ วาง "N E" หรือ "E N" ก็ได้
        r = QtWidgets.QHBoxLayout()
        r.addWidget(QtWidgets.QLabel("N:"))
        self._line_pt_n = QtWidgets.QLineEdit()
        self._line_pt_n.setObjectName("MLEP_line_pt_n")
        self._line_pt_n.setPlaceholderText("เช่น 1559486.827")
        self._line_pt_n.setToolTip("ค่า N (Northing) เป็นเมตร · วางคู่ค่า \"N E\" หรือ \"E N\" ลงช่องนี้ช่องเดียวก็ได้ "
                                   "(แยก N / E ให้ตามขนาดตัวเลข) · Enter = ไปช่อง E")
        r.addWidget(self._line_pt_n, 1)
        r.addWidget(QtWidgets.QLabel("E:"))
        self._line_pt_e = QtWidgets.QLineEdit()
        self._line_pt_e.setObjectName("MLEP_line_pt_e")
        self._line_pt_e.setPlaceholderText("เช่น 711180.810")
        self._line_pt_e.setToolTip("ค่า E (Easting) เป็นเมตร · วางคู่ค่าลงช่องนี้ช่องเดียวก็ได้ · Enter = สร้างจุด")
        r.addWidget(self._line_pt_e, 1)                 # ลำดับ Tab ตามลำดับที่สร้าง/วางในแถว = N ก่อน E
        v36.addLayout(r)
        # ช่องชื่อเดิม — ไม่ต้องใส่ชื่อแล้ว (เจ้าของงานสั่ง 1 ต.ค.) · คงไว้แบบซ่อน ว่างเสมอ ⇒ ตั้งชื่อ P1, P2 … ให้เอง
        self._line_pt_name = QtWidgets.QLineEdit(win)
        self._line_pt_name.setObjectName("MLEP_line_pt_name")
        self._line_pt_name.setVisible(False)
        r = QtWidgets.QHBoxLayout()
        b_pt = QtWidgets.QPushButton("📍 สร้างจุด")
        b_pt.setToolTip("สร้างจุดตามพิกัดที่กรอก (กด Enter ในช่องกรอกก็ได้) — สร้างได้หลายจุด · snap ได้ "
                        "ใช้เป็นจุดเริ่ม/ปลายเส้น หรือให้ Move Node เกาะ · ไม่แตะข้อมูลในฐาน")
        b_pt.setFixedHeight(30)
        b_pt.clicked.connect(lambda *_a: self._line_add_coord_point())
        b_ptdel = QtWidgets.QPushButton("ลบจุดที่เลือก")
        b_ptdel.setToolTip("ลบจุดที่เลือกในรายการออกจากแผนที่ — ไม่แตะข้อมูลในฐาน")
        b_ptdel.clicked.connect(lambda *_a: self._line_pt_delete_selected())
        b_ptclr = QtWidgets.QPushButton("ล้างจุดทั้งหมด")
        b_ptclr.setToolTip("ลบจุดที่สร้างจากค่าพิกัดทั้งหมดออกจากแผนที่ — ไม่แตะข้อมูลในฐาน (เส้นที่วาดไม่หาย)")
        b_ptclr.setStyleSheet("color:#b71c1c;")
        b_ptclr.clicked.connect(lambda *_a: self._line_pt_clear())
        for b in (b_ptdel, b_ptclr):
            b.setFixedHeight(30)
        r.addWidget(b_pt, 1)
        r.addWidget(b_ptdel, 1)
        r.addWidget(b_ptclr, 1)
        v36.addLayout(r)
        # Enter = สร้างจุด (ปุ่มทุกตัวในหน้าต่างนี้ปิด autoDefault ไว้ Enter จึงไม่ไปกดปุ่มอื่น)
        # ★ 2.3.7 b13 — ช่องแรก (N) กรอกค่าเดียวแล้วกด Enter ขณะช่อง E ยังว่าง = ไปช่อง E (ไม่ขึ้นข้อความผิด)
        self._line_pt_n.returnPressed.connect(self._line_pt_n_enter)
        self._line_pt_e.returnPressed.connect(self._line_add_coord_point)
        self._line_pt_list = QtWidgets.QListWidget()
        self._line_pt_list.setMaximumHeight(76)
        self._line_pt_list.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self._line_pt_list.setToolTip("จุดที่สร้างไว้ (พิกัดตามที่กรอก) · เลือกแล้วกด \"ลบจุดที่เลือก\" ได้")
        v36.addWidget(self._line_pt_list)
        self._line_pt_hint = QtWidgets.QLabel()
        self._line_pt_hint.setStyleSheet("color:#546e7a; font-size:11px;")
        self._line_pt_hint.setWordWrap(True)
        v36.addWidget(self._line_pt_hint)
        self._line_pt_update_hint()
        root.addWidget(g36)

        # ---------- กลุ่ม 5: ผลการวัด ----------
        g4, v4 = grp("ผลการวัด")
        v4.setSpacing(5)
        self._line_tree = QtWidgets.QTreeWidget()
        self._line_tree.setHeaderLabels(["เส้น / ช่วง", "ระยะ"])
        self._line_tree.setAlternatingRowColors(True)
        self._line_tree.setMinimumHeight(140)
        self._line_tree.header().setStretchLastSection(False)
        self._line_tree.header().setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        self._line_tree.header().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        v4.addWidget(self._line_tree, 1)

        self._line_total = QtWidgets.QLabel("รวมทั้งหมด 0.00 ม.")
        self._line_total.setStyleSheet(
            "font-weight:bold; color:#0d47a1; padding:4px;"
            " background:#e3f2fd; border-radius:3px;")
        self._line_total.setAlignment(QtCore.Qt.AlignCenter)
        v4.addWidget(self._line_total)

        r = QtWidgets.QHBoxLayout()
        b_undo = QtWidgets.QPushButton("↺ ถอยจุด/เส้น")
        b_undo.setToolTip("ถอยจุดล่าสุดที่คลิก หรือถอยทั้งเส้นถ้าวาดจบแล้ว (Ctrl+Z ก็ได้)\n"
                          "เพิ่งกด 🧹 ล้างเส้น = เรียกคืนเส้นที่ล้างไป")       # ★ 2.3.7 (DI-25 · UX-37)
        b_undo.clicked.connect(self._line_undo)
        b_copy = QtWidgets.QPushButton("📋 คัดลอกผล")
        b_copy.setToolTip("คัดลอกผลการวัด (ระยะ) ไปคลิปบอร์ด เอาไปวางในโปรแกรมอื่นได้")
        b_copy.clicked.connect(self._line_copy)
        for b in (b_undo, b_copy):
            b.setFixedHeight(30)
            r.addWidget(b, 1)
        v4.addLayout(r)
        root.addWidget(g4, 1)

        # ★ 1 ก.ย. 69 — ปิด autoDefault ของทุกปุ่มในหน้าต่างนี้
        #   QDialog ยกปุ่มแรกเป็น default button อัตโนมัติ -> พนักงานพิมพ์ระยะที่จะล็อก
        #   เช่น 12.50 แล้วกด Enter ตามสัญชาตญาณ = ไปกดปุ่ม "หยุดวาด" ให้ (หรือแย่กว่านั้น
        #   ถ้า focus อยู่ที่ปุ่มล้าง จะล้างงานที่วัดไว้ทั้งหมด)
        for _b in win.findChildren(QtWidgets.QPushButton):
            _b.setAutoDefault(False)
            _b.setDefault(False)

        # ★ audit รอบ 3 — หมุนล้อเมาส์เลื่อนหน้าต่าง แล้วช่องตัวเลข/คอมโบที่ผ่านใต้เมาส์ "กินล้อ" เปลี่ยนค่าเงียบ ๆ
        #   (ล็อกระยะ 10 → 9 ม. มีผลกับเครื่องมือทันที) ⇒ ช่องพวกนี้รับล้อเฉพาะตอนถูกคลิกเลือกอยู่ (มีโฟกัส)
        #   นอกนั้นส่งล้อต่อให้กรอบเลื่อน (ignore + คืน True = Qt ส่งต่อให้แม่)
        class _WheelGuard(QtCore.QObject):
            def eventFilter(self, obj, ev):
                if ev.type() == QtCore.QEvent.Wheel and (not obj.hasFocus() or obj.property("mlep_no_wheel")):
                    ev.ignore()
                    return True
                return False
        self._line_wheel_guard = _WheelGuard(win)
        for _w in _body.findChildren(QtWidgets.QAbstractSpinBox) + _body.findChildren(QtWidgets.QComboBox):
            try:
                _w.setFocusPolicy(QtCore.Qt.StrongFocus)
                _w.installEventFilter(self._line_wheel_guard)
            except Exception:
                pass
        # ★ audit รอบ 3 — ไม่มีแถบเลื่อนแนวนอน ⇒ ห้ามแคบกว่าเนื้อหา (เดิมย่อได้ถึง 300 ขอบขวาของปุ่ม/ช่องถูกตัด)
        try:
            _minw = _body.minimumSizeHint().width() + _sc.verticalScrollBar().sizeHint().width() + 6
            _sc.setMinimumWidth(_minw)
            win.setMinimumWidth(max(300, _minw))
        except Exception:
            pass
        # ★ 2.3.6 — ขนาดเริ่มต้น = พอดีเนื้อหา แต่ไม่เกิน 90% ของความสูงจอ (ที่เหลือเลื่อนเอา)
        #   audit รอบ 3: ใช้จอที่หน้าต่างหลักของ QGIS อยู่ (ก่อนเปิดหน้าต่าง win.screen() ยังเป็นจอหลักเสมอ)
        try:
            _h = _body.sizeHint().height() + 24
            _mw = self.iface.mainWindow()
            _scr = (_mw.screen() if _mw is not None and hasattr(_mw, "screen") and _mw.screen() is not None
                    else QtWidgets.QApplication.primaryScreen())
            _avail = _scr.availableGeometry().height() if _scr is not None else 900
            win.resize(max(_body.sizeHint().width() + 24, 330), min(_h, int(_avail * 0.9)))
        except Exception:
            pass
        # ปิดหน้าต่าง = ออกจากโหมดวาด + คืนค่า snapping ที่ยืมไป + ซ่อนเส้น
        win.installEventFilter(self._line_close_filter())
        self._line_dock = win
        self._line_refresh()

    # ---------- ★ 2.3.6 หน่วยของช่องระยะ (เมตร / เส้น) ----------
    def _line_unit_combo(self):
        """คอมโบหน่วยของช่องระยะในหน้าต่างวาดเส้น — เมตร / เส้น (1 เส้น = 40 ม.)

        ★ 2.3.6 (1 ต.ค. 69 เจ้าของงานสั่ง) — ใช้แปลง "ตัวเลขที่กรอก" เป็นเมตรเท่านั้น
          ป้ายระยะบนแผนที่ · ผลการวัด · ข้อความคัดลอก เป็นเมตรเสมอ (เจ้าของงานย้ำ 1 ต.ค.)
          สลับหน่วยแล้วตัวเลขในช่องไม่แปลงตาม = ตัวเลขเดิมในหน่วยใหม่ (กรอกเลขก่อนแล้วค่อยเลือกหน่วยได้)
        """
        cb = QtWidgets.QComboBox()
        cb.addItem("เมตร", 1.0)
        cb.addItem("เส้น", 40.0)
        # ★ รอบ 6 — ล้อเมาส์ไม่เปลี่ยนหน่วยเลย (แม้คอมโบมีโฟกัส) — เปลี่ยนหน่วย = ระยะเปลี่ยน 40 เท่า (ดู _WheelGuard)
        cb.setProperty("mlep_no_wheel", True)
        cb.setToolTip("หน่วยของตัวเลขในช่องข้าง ๆ · 1 เส้น = 40 เมตร\n"
                      "ระยะบนแผนที่และผลการวัดแสดงเป็นเมตรเสมอ")
        return cb

    @staticmethod
    def _line_unit_factor(cb):
        """ตัวคูณเป็นเมตรของคอมโบหน่วย (ไม่มีคอมโบ/อ่านไม่ได้ = เมตร)"""
        try:
            f = float(cb.currentData())
            return f if f > 0 else 1.0
        except Exception:
            return 1.0

    def _line_bind_unit(self, spin, cb):
        """ทศนิยม 4 ตำแหน่งคงที่ทั้งเมตรและเส้น (0.0125 เส้น = 50 ซม.)

        ★ รอบ 6 (ผู้ตรวจ B) — เดิมสลับ 2/4 ตามหน่วย ⇒ ตอนลดเป็น 2 Qt ปัดตัวเลขในช่องทิ้งเงียบ ๆ
          (1.2345 เส้น สลับไปเมตรแล้วกลับ = 1.23 เส้น หาย 18 ซม. · พิมพ์ 0.0125 ตอนเป็นเมตรรับได้แค่ 0.01)
          ขัดกับที่ออกแบบไว้ว่า "สลับหน่วยแล้วตัวเลขไม่แปลงตาม"
        """
        spin.setDecimals(4)

    def _line_close_filter(self):
        """ตัวดักเหตุการณ์ของหน้าต่างวาดเส้น

        ★ 1 ก.ย. 69 — เดิมดักแค่ Close/Hide แล้วออกจากโหมดวาด ซึ่งไม่พอ 2 เรื่อง
          ① ปิดด้วยปุ่ม X แล้ว "เส้นที่วาด" ยังค้างทับแผนที่ตลอดไป พนักงานลบไม่ได้
             ถ้าไม่เปิดหน้าต่างกลับมากดปุ่มล้าง (ซึ่งไม่มีทางรู้)
          ② QDialog ผูก Esc ไว้กับ reject() มาในตัว -> กด Esc ตอน focus อยู่ที่หน้าต่าง
             (เช่นเพิ่งปรับช่องล็อกระยะมา) จะปิดหน้าต่างทั้งบาน
             ทั้งที่บนหน้าต่างเขียนสอนว่า "Esc = ทิ้งเส้นที่กำลังวาด"
        """
        plugin = self

        class _F(QtCore.QObject):
            def eventFilter(self, obj, ev):
                t = ev.type()
                # ★ 1 ก.ย. 69 — ต้องจับคู่ Show ให้ครบกับ Hide
                #   เดิมมีแต่ขาซ่อน ขาเปิดคืนอยู่ที่ start_draw_line ที่เดียว
                #   (ปุ่ม 📐 บนหน้าต่างหลัก) ⇒ ย่อหน้าต่างวาดเส้นแล้วเรียกคืน
                #   = เส้น preview / จุดหัก / ป้ายระยะ หายค้างทั้ง session
                #   ปุ่มบนหน้าต่างเอง (เริ่มวาด/หยุดวาด/ล้าง) ไม่มีตัวไหนกู้คืนได้เลย
                if t == QtCore.QEvent.Show:
                    try:
                        if getattr(plugin, "_line_item", None) is not None:
                            plugin._line_item.setVisible(True)
                        plugin._line_sync_layer()
                    except Exception:
                        pass
                    return False
                # Esc ที่หน้าต่าง = ทิ้งเส้นที่กำลังวาด (ให้ตรงกับที่เขียนสอนไว้) ไม่ใช่ปิดหน้าต่าง
                if t == QtCore.QEvent.KeyPress and ev.key() == QtCore.Qt.Key_Escape:
                    # ★ 2.3.6 (audit รอบ 2) — Esc ในช่องกรอกพิกัด = ล้างช่องนั้น
                    #   (เดิมทิ้งเส้นที่กำลังวาดค้างไว้ทันที ทั้งที่ผู้ใช้แค่อยากลบตัวเลขที่พิมพ์ผิด)
                    try:
                        fw = QtWidgets.QApplication.focusWidget()
                        if fw is not None and any(fw is getattr(plugin, _n, None)
                                                  for _n in ("_line_pt_e", "_line_pt_n", "_line_pt_name")):
                            fw.clear()
                            return True
                    except Exception:
                        pass
                    try:
                        plugin._line_discard_temp()
                    except Exception:
                        pass
                    return True            # กินไว้ ไม่ให้ตกไปถึง QDialog.reject()
                if t in (QtCore.QEvent.Close, QtCore.QEvent.Hide):
                    try:
                        plugin._line_set_drawing(False)
                        # ซ่อนเส้นไปพร้อมหน้าต่าง — ไม่ลบทิ้ง เปิดใหม่แล้วยังอยู่
                        if getattr(plugin, "_line_item", None) is not None:
                            plugin._line_item.setVisible(False)
                        plugin._line_layer_drop()      # ไม่ทิ้งชั้นค้างในโปรเจกต์
                    except Exception:
                        _log_exc("หน้าต่างวาดเส้นปิด/ซ่อน: หยุดวาด/ถอดชั้นเส้นและจุดวัดระยะไม่สำเร็จ",
                                 once_key="ER-09:close-drop")               # ★ 2.4.0 (review ER-09)
                return False

        self._line_filter = _F(self.iface.mainWindow())
        return self._line_filter

    def _line_discard_temp(self):
        """ทิ้งเฉพาะเส้นที่กำลังวาดค้างอยู่ (เส้นที่จบแล้วไม่หาย)"""
        item = getattr(self, "_line_item", None)
        if item is None:
            return
        if item.temp:
            item.temp = []
            item.cursor = None
            item.updatePosition()
            self._line_refresh()

    # ---------- ส่งค่าล็อกให้เครื่องมือ ----------
    def _line_lock_units_check(self):
        """★ 2.3.7 (review DI-41) — แผนที่ไม่ใช่หน่วยเมตร (เช่นโปรเจกต์ตั้ง EPSG:4326)
        เครื่องมือข้ามล็อกระยะไปเงียบ ๆ (ตัวเลขคนละหน่วยกับที่พิมพ์) และล็อกมุมคิดบนระนาบองศา (ไม่ตรงพื้นจริง)
        ⇒ ช่องล็อกระยะเป็นสีเทาพร้อมบอกเหตุใน tooltip · ติ๊กล็อกไว้ = บอกครั้งเดียวต่อ session
        กลับมาเป็นเมตร = ใช้ได้ตามเดิม (ถูกเรียกตอนส่งค่าล็อก และตอน CRS ของแผนที่เปลี่ยน)"""
        chk = getattr(self, "_line_dist_chk", None)
        if chk is None:
            return
        from ..map_tools import _canvas_is_metres
        try:
            metres = _canvas_is_metres(self.iface.mapCanvas())
        except Exception:
            metres = True
        try:
            if getattr(self, "_line_dist_tip0", None) is None:
                self._line_dist_tip0 = chk.toolTip()
            chk.setEnabled(metres)
            chk.setToolTip(self._line_dist_tip0 if metres else
                           "ใช้ไม่ได้ตอนนี้: แผนที่ไม่ใช่หน่วยเมตร — ตั้ง CRS ของโปรเจกต์เป็น EPSG:24047 "
                           "(Project > Properties > CRS)")
            ang = getattr(self, "_line_ang_chk", None)
            ticked = chk.isChecked() or (ang is not None and ang.isChecked())
        except Exception:
            return
        if not metres and ticked and not getattr(self, "_line_nonmetre_warned", False):
            self._line_nonmetre_warned = True
            self.iface.messageBar().pushMessage(
                "วาดเส้น", "แผนที่ไม่ใช่หน่วยเมตร — ล็อกระยะไม่ทำงาน และล็อกมุมคิดบนองศา (ไม่ตรงพื้นจริง) · "
                "ตั้ง CRS โปรเจกต์เป็น EPSG:24047", level=1, duration=10)

    def _line_push_locks(self):
        self._line_lock_units_check()        # ★ 2.3.7 (review DI-41)
        tool = getattr(self, "temp_tool", None)
        from ..map_tools import DrawLineTool
        if not isinstance(tool, DrawLineTool):
            return
        # ★ 2.3.6 — ช่องระยะมีหน่วย (เมตร / เส้น) ⇒ ส่งให้เครื่องมือเป็นเมตรเสมอ
        tool.lock_dist = (self._line_dist_spin.value()
                          * self._line_unit_factor(getattr(self, "_line_dist_unit", None))
                          if self._line_dist_chk.isChecked() else None)
        tool.lock_angle = (self._line_ang_spin.value()
                           if self._line_ang_chk.isChecked() else None)
        # ★ 2.3.6 (1 ต.ค. 69 เจ้าของงานสั่ง) — ไม่มี "นับมุมจาก" / แนวอ้างอิงแล้ว:
        #   ล็อกมุมนับจากแนวช่วงก่อนหน้าของเส้นที่กำลังวาดเสมอ (ช่วงแรกนับจากทิศเหนือ) — ดู DrawLineTool._point
        tool.angle_basis = None

    def _line_on_ref(self, az):
        self._line_ref_az = az
        self._line_ref_lbl.setText("%.4f°" % az)
        # ตั้งแนวแล้วให้เลือก "นับมุมจากแนวอ้างอิง" ให้เลย ไม่ต้องไปกดเอง
        idx = self._line_basis_cb.findData("ref")
        if idx >= 0:
            self._line_basis_cb.setCurrentIndex(idx)
        self._line_push_locks()

    def _line_clear_ref(self):
        # ★★ 2 ก.ย. 69 — ต้องล้าง "จุดแรก" ที่ค้างอยู่ในเครื่องมือวาดเส้นด้วย
        #   Ctrl+คลิกจุดแรกแล้วยังไม่คลิกจุดที่สอง จุดนั้นค้างใน DrawLineTool._ref_pts
        #   ถ้าไม่ล้าง: กด "ล้างแนว" หรือเปลี่ยนอำเภอแล้ว Ctrl+คลิกใหม่
        #   จะได้แนวที่คำนวณจาก "จุดเก่าของงานก่อน + จุดใหม่" ⇒ มุมผิดเงียบ ๆ
        #   (วัดได้: ควรเป็น 90° แต่ได้ 16.39° · และปนข้ามอำเภอได้ด้วย)
        try:
            from ..map_tools import DrawLineTool
            tool = getattr(self, "temp_tool", None)
            if isinstance(tool, DrawLineTool):
                tool._ref_pts = []
        except Exception:
            pass
        self._line_ref_az = None
        self._line_ref_lbl.setText("ยังไม่ได้ตั้ง")
        if getattr(self, "_line_item", None) is not None:
            self._line_item.ref_line = None
            self._line_item.updatePosition()
        idx = self._line_basis_cb.findData("north")
        if idx >= 0:
            self._line_basis_cb.setCurrentIndex(idx)
        self._line_push_locks()

    # ---------- เส้นขนาน (Offset) ----------
    def _line_offset(self, to_left):
        """สร้างเส้นขนานจากเส้นที่วาดไว้  (to_left=True ซ้าย / False ขวา)

        ★ เครื่องหมายของ QGIS: `offsetCurve` ระยะ **บวก = ด้านซ้ายของทิศทางเส้น**
          (ทดสอบยืนยันแล้ว) ⇒ ขวา = ใส่ค่าลบ
        ★ ใช้ **Miter** เพื่อให้หัวมุมคม จำนวนจุดเท่าเดิม — งานรังวัดไม่ควรได้ส่วนโค้ง
          ที่ Round แถมมา (10 จุดต่อหนึ่งมุม)
        """
        it = getattr(self, "_line_item", None)
        if it is None or not [p for p in it.lines if len(p) >= 2]:
            self._ask(QtWidgets.QMessageBox.Information, "เส้นขนาน",
                      "ยังไม่มีเส้นที่วาดเสร็จให้ทำเส้นขนาน\n"
                      "วาดเส้นให้จบก่อน (คลิกขวา = จบเส้น)")
            return

        # 🔴 ระยะเป็น "เมตร" แต่เส้นเก็บด้วยหน่วยของ CRS โปรเจกต์
        #   มีไฟล์อำเภอจริงที่ตั้ง projectCrs เป็น EPSG:4326 (องศา) อยู่
        #   -> offset 5 "หน่วย" บนองศา = ~550 กม. ⇒ ต้องปฏิเสธ ห้ามคำนวณมั่ว
        #   (คลาสเดียวกับบั๊กรัศมี hover ที่แก้ไปใน 2.2.4)
        from ..map_tools import _canvas_is_metres
        canvas = self.iface.mapCanvas()
        if not _canvas_is_metres(canvas):
            self._ask(QtWidgets.QMessageBox.Warning, "เส้นขนาน",
                      "หน่วยของโปรเจกต์ไม่ใช่เมตร จึงคำนวณระยะขนานเป็นเมตรไม่ได้\n\n"
                      "ตั้ง CRS ของโปรเจกต์เป็น EPSG:24047 ก่อน "
                      "(Project > Properties > CRS) แล้วลองใหม่")
            return

        if not self._line_crs_ok():              # ★ 2.3.7 (DI-40)
            return
        # ★ 2.3.6 — ช่องระยะมีหน่วย (เมตร / เส้น) ⇒ คิดเป็นเมตรก่อนทำ (ข้อความแจ้งผลเป็นเมตร)
        dist = float(self._line_off_spin.value()) * self._line_unit_factor(getattr(self, "_line_off_unit", None))
        if dist <= 0:
            return

        # เลือกเส้น: ตัวที่เลือกไว้ในรายการผลการวัด -> ถ้าไม่ได้เลือก ใช้เส้นล่าสุดที่มี >= 2 จุด
        idx = None
        try:
            sel = self._line_tree.selectedItems()
            if sel:
                top = sel[0]
                while top.parent() is not None:
                    top = top.parent()
                v = top.data(0, QtCore.Qt.UserRole)
                if v is not None:
                    idx = int(v)
        except Exception:
            idx = None
        if idx is None or not (0 <= idx < len(it.lines)) or len(it.lines[idx]) < 2:
            idx = None
            for k in range(len(it.lines) - 1, -1, -1):
                if len(it.lines[k]) >= 2:
                    idx = k
                    break
        if idx is None:
            return

        src = [QgsPointXY(q) for q in it.lines[idx]]
        ring = len(src) >= 4 and src[0].distance(src[-1]) < 1e-6        # ★ 2.3.7 (DI-27) เส้นปิด
        try:
            g = QgsGeometry.fromPolylineXY(src)
            try:
                from qgis.core import Qgis
                join = Qgis.JoinStyle.Miter
            except Exception:
                join = QgsGeometry.JoinStyleMiter
            # ★ 2.3.7 (DI-26) เดิม miter 2.0 ⇒ มุมแหลมกว่า 60° ถูกตัดมุม · (DI-27) เส้นปิดด้านนอกเดิมได้เส้นเปิดขาด 2 ด้าน
            off = (self._line_offset_ring(src, dist, to_left, join) if ring else
                   g.offsetCurve(dist if to_left else -dist, 8, join, self.LINE_OFFSET_MITRE))
        except Exception:
            self._fail("เส้นขนาน", "สร้างเส้นขนานไม่สำเร็จ", "ลองลดระยะ หรือสลับข้าง", modal=True, level=1)  # ★ 2.3.7 ER-06
            return

        # offsetCurve คืนค่าว่างได้จริง (เส้นตัดตัวเอง / ระยะกว้างกว่าส่วนโค้ง) -> ต้องแจ้ง ไม่ปล่อยเงียบ
        if off is None or off.isEmpty():
            self._ask(QtWidgets.QMessageBox.Warning, "เส้นขนาน",
                      "สร้างเส้นขนานที่ระยะ %.2f ม. ไม่ได้\n"
                      "มักเกิดกับเส้นที่หักกลับมาตัดตัวเอง หรือระยะกว้างเกินกว่าช่วงโค้งของเส้น\n"
                      "ลองลดระยะ หรือสลับข้าง" % dist)
            return

        try:
            parts = off.asMultiPolyline() if off.isMultipart() else [off.asPolyline()]
        except Exception:
            parts = []
        # ★ 2.3.7 (review DI-27) — เส้นปิดต้องได้เส้นปิด: ได้เส้นเปิด/ขาดด้าน ⇒ เตือน ไม่เพิ่มเส้นพิกล (เดิมบอกว่าสำเร็จ)
        if ring and any(len(pt_) < 4 or pt_[0].distance(pt_[-1]) > 1e-6 for pt_ in parts if pt_):
            self._ask(QtWidgets.QMessageBox.Warning, "เส้นขนาน",
                      "เส้นขนานของเส้นปิด (เส้นที่ %d) ได้ผลเป็นเส้นที่ไม่ปิด จึงไม่สร้างให้\n"
                      "ลองลดระยะ หรือสลับข้าง" % (idx + 1))
            return
        # ★ 2.3.7 b13 (review UX-17) — ① เส้นที่ได้จัดทิศให้ตามเส้นต้นทาง (QGIS กลับทิศเส้นซ้ายบางกรณี ⇒ ◀/▶ บนเส้นที่ได้เคยกลับความหมาย)
        #   ② เส้นที่ทับเส้นเดิม (≤ 1 มม. ทุกจุด) ไม่สร้างซ้ำ — กดข้างเดิมซ้ำที่ระยะเดิม = เตือน (เดิมได้เส้นที่ 2 เท่าโดยบังเอิญ)
        # ★★ 2.3.8 (เจ้าของงานสั่ง 8 ต.ค. 69) — **offset ครั้งต่อไปอ้างอิงเส้นที่ได้ครั้งล่าสุด** (แทนข้อ ③ ของ 2.3.7 ที่เลือกเส้นต้นทางค้างไว้)
        #   หลังสร้าง ⇒ เลือกเส้นที่เพิ่งได้ให้ (ที่เลือกให้เอง = _line_par_auto · วาดเส้นใหม่จบแล้วปล่อย) ⇒ กดซ้ำ = ขนานต่อออกไปอีก
        #   อยากได้อีกข้างของเส้นเดิม ⇒ คลิกเลือกเส้นเดิมในช่อง "ผลการวัด" เอง (ที่ผู้ใช้เลือกเองยังใช้เป็นต้นทางเสมอ)
        added, dup, ใหม่ = 0, [], []
        for part in parts:
            if part and len(part) >= 2:
                q = [QgsPointXY(x) for x in part]
                if not ring:
                    q = self._line_par_orient(src, q, dist, to_left)
                k = self._line_par_same(it.lines, q)
                if k is not None:
                    dup.append(k)
                    continue
                it.lines.append(q)
                ใหม่.append(len(it.lines) - 1)
                added += 1
        if not added:
            if dup:
                # เส้นแบบเดียวกันมีอยู่แล้ว ⇒ ถือเส้นนั้นเป็น "เส้นล่าสุด" (กดอีกครั้ง = ขนานต่อจากเส้นนั้น ไม่วนกลับมาที่เดิม)
                ล่าสุด = max(dup)
                self._line_tree_select(ล่าสุด)
                self._line_par_auto = ล่าสุด
                self.iface.messageBar().pushMessage(
                    "เส้นขนาน", "เส้นขนานระยะ %.2f ม. ทาง%sของเส้นที่ %d มีอยู่แล้ว (เส้นที่ %s) — ไม่สร้างซ้ำ"
                    % (dist, "ซ้าย" if to_left else "ขวา", idx + 1, ", ".join(str(k + 1) for k in sorted(set(dup)))),
                    level=1, duration=6)
                return
            self._ask(QtWidgets.QMessageBox.Warning, "เส้นขนาน",
                      "ผลลัพธ์ไม่มีเส้นที่ใช้ได้ (ลองลดระยะ หรือสลับข้าง)")
            return

        try:
            it.updatePosition()
        except Exception:
            pass
        self._line_refresh()
        ล่าสุด = ใหม่[-1]
        self._line_tree_select(ล่าสุด)                    # ★ 2.3.8 เลือกเส้นที่เพิ่งได้ ⇒ กดอีกครั้ง = ขนานต่อจากเส้นนี้
        self._line_par_auto = ล่าสุด                      # เลือกให้เอง ⇒ วาดเส้นใหม่จบแล้วปล่อย (กลับไปใช้เส้นล่าสุด)
        txt = ("สร้างจากเส้นที่ %d ระยะ %.2f ม. ทาง%s แล้ว %d เส้น (เส้นที่ %s) — กดอีกครั้งจะขนานต่อจากเส้นที่ %d"
               % (idx + 1, dist, "ซ้าย" if to_left else "ขวา", added, ", ".join(str(k + 1) for k in ใหม่), ล่าสุด + 1))
        if dup:
            txt += " (ข้าม %d เส้นที่มีอยู่แล้ว)" % len(dup)
        if ring:                                  # ★ 2.3.7 (DI-27) เส้นปิด: บอกว่าเป็นด้านในหรือด้านนอก
            txt += " (ด้าน%sของเส้นปิด)" % ("ใน" if to_left == (self._line_ring_area2(src) > 0) else "นอก")
        sharp = self._line_sharp_corners(src, to_left, ring)
        if sharp:
            # ★ 2.3.7 (review DI-26) — มุมที่แหลมเกินขีดจำกัด miter ยังถูกตัดมุม (ปลายมุมจริงอยู่ไกลเกิน 10 เท่าของระยะ)
            self.iface.messageBar().pushMessage(
                "เส้นขนาน", txt + " · มุมที่แหลมกว่า %.1f° %d มุมถูกตัดมุม (ปลายมุมจริงยื่นไกลเกิน %g เท่าของระยะ)"
                % (math.degrees(2.0 * math.asin(1.0 / self.LINE_OFFSET_MITRE)), sharp, self.LINE_OFFSET_MITRE),
                level=1, duration=10)
        else:
            self.iface.messageBar().pushInfo("เส้นขนาน", txt)

    @staticmethod
    def _line_par_orient(src, q, dist, to_left):
        """★ 2.3.7 b13 (review UX-17) — จัดทิศเส้นขนานของ "เส้นเปิด" ให้ไปทางเดียวกับเส้นต้นทาง
        QGIS กลับทิศผลของ offsetCurve เองบางกรณี (เทียบทิศหมุนของเส้นเปิด — เส้นตรงแนวนอนทำทางซ้ายได้เส้นกลับทิศ
        ขึ้นกับรุ่น GEOS) ⇒ ◀/▶ บนเส้นที่ได้กลับความหมาย · เทียบปลายทั้งสองกับตำแหน่งที่ควรเป็น (จุดแรก/จุดสุดท้ายของ
        ต้นทาง เลื่อนตั้งฉากไปข้างที่สั่ง) แล้วกลับทิศเมื่อใกล้แบบกลับด้านมากกว่า · ทำไม่ได้ (เส้นยาว 0) = คืนเดิม"""
        def _dir(pts):
            for i in range(len(pts) - 1):
                dx, dy = pts[i + 1].x() - pts[i].x(), pts[i + 1].y() - pts[i].y()
                ln = math.hypot(dx, dy)
                if ln > 1e-9:
                    return dx / ln, dy / ln
            return None
        u0, u1 = _dir(src), _dir(list(reversed(src)))
        if u0 is None or u1 is None or len(q) < 2:
            return q
        u1 = (-u1[0], -u1[1])                     # ทิศของช่วงสุดท้าย (จากต้นไปปลาย)
        sg = 1.0 if to_left else -1.0             # ซ้ายของทิศ (ux, uy) = (-uy, ux)
        s = QgsPointXY(src[0].x() - sg * u0[1] * dist, src[0].y() + sg * u0[0] * dist)
        e = QgsPointXY(src[-1].x() - sg * u1[1] * dist, src[-1].y() + sg * u1[0] * dist)
        same = q[0].distance(s) + q[-1].distance(e)
        rev = q[0].distance(e) + q[-1].distance(s)
        return list(reversed(q)) if rev < same - 1e-9 else q

    @staticmethod
    def _line_par_same(lines, q, tol=0.001):
        """★ 2.3.7 b13 (review UX-17) — index ของเส้นใน lines ที่ทับเส้น q (จำนวนจุดเท่ากัน · ทุกจุดห่าง ≤ 1 มม.
        ทางเดียวกันหรือกลับทาง) หรือ None"""
        n = len(q)
        for k, ln in enumerate(lines):
            if len(ln) != n:
                continue
            if all(a.distance(b) <= tol for a, b in zip(ln, q)) or \
                    all(a.distance(b) <= tol for a, b in zip(ln, reversed(q))):
                return k
        return None

    def _line_tree_select(self, idx, row=-1):
        """★ 2.3.7 b13 (review UX-17) — เลือกเส้นที่ idx (index ใน it.lines) ในรายการผลการวัด (row ≥ 0 = แถวช่วงย่อย)
        มีแถวของเส้นนั้นเลือกอยู่แล้ว = ไม่แตะ · ใช้ setSelected ไม่ใช่ setCurrentItem (ไม่เลื่อน/ไม่กางเส้นที่ผู้ใช้หุบไว้)"""
        tree = getattr(self, "_line_tree", None)
        if tree is None or idx is None:
            return
        try:
            for x in tree.selectedItems():
                while x.parent() is not None:
                    x = x.parent()
                v = x.data(0, QtCore.Qt.UserRole)
                if v is not None and int(v) == int(idx):
                    return
            for k in range(tree.topLevelItemCount()):
                t = tree.topLevelItem(k)
                v = t.data(0, QtCore.Qt.UserRole)
                if v is not None and int(v) == int(idx):
                    tree.clearSelection()
                    (t.child(row) if 0 <= row < t.childCount() else t).setSelected(True)
                    return
        except Exception:
            pass

    @staticmethod
    def _line_ring_area2(pts):
        """สองเท่าของพื้นที่มีเครื่องหมาย (shoelace) ของเส้นปิด — บวก = วาดทวนเข็มนาฬิกา"""
        return sum(pts[i].x() * pts[i + 1].y() - pts[i + 1].x() * pts[i].y() for i in range(len(pts) - 1))

    @staticmethod
    def _line_sharp_corners(pts, to_left, closed=False):
        """★ 2.3.7 (review DI-26) — จำนวนมุมที่ GEOS จะตัดมุม (bevel) ฝั่งที่ทำเส้นขนาน
        = มุมที่ฝั่งนั้นเป็นด้านนอกของการเลี้ยว และมุมภายในแคบกว่า 2·asin(1/LINE_OFFSET_MITRE) · ด้านในของมุมไม่ถูกตัด"""
        th = 2.0 * math.asin(1.0 / MultiLayerEditPro.LINE_OFFSET_MITRE)
        q = [pt_ for i, pt_ in enumerate(pts) if i == 0 or pt_.distance(pts[i - 1]) > 1e-9]   # ข้ามจุดซ้ำ
        if closed and len(q) > 1 and q[0].distance(q[-1]) <= 1e-6:
            q = q[:-1]
        n = len(q)
        if n < 3:
            return 0
        out = 0
        for i in (range(n) if closed else range(1, n - 1)):
            a, b, c = q[i - 1], q[i], q[(i + 1) % n]
            ux, uy = b.x() - a.x(), b.y() - a.y()
            vx, vy = c.x() - b.x(), c.y() - b.y()
            cross, dot = ux * vy - uy * vx, ux * vx + uy * vy
            interior = math.pi - abs(math.atan2(cross, dot))
            outer = (cross < 0) if to_left else (cross > 0)          # เลี้ยวขวา ⇒ ด้านซ้ายคือด้านนอกของมุม
            if outer and interior < th - 1e-12:
                out += 1
        return out

    def _line_offset_ring(self, src, dist, to_left, join):
        """★ 2.3.7 (review DI-27) — เส้นขนานของ "เส้นปิด" (จุดแรก = จุดสุดท้าย เช่นวาดรอบแปลง)
        offsetCurve ของ GEOS กับเส้นปิด: ด้านในถูก แต่ด้านนอกได้ "เส้นเปิด" ที่ขาด 2 ด้าน (วัดแล้ว GEOS 3.12.1 / 3.13)
        ⇒ ทำจากรูปปิดแทน: buffer ±ระยะ แบบ Miter (ขีดจำกัดเดียวกับเส้นเปิด) แล้วเอาวงขอบ (รวมรูที่เกิดจากรูปเว้า)
        ซ้าย/ขวานับตามทิศที่วาดเหมือนเส้นเปิด: วาดทวนเข็ม (พื้นที่มีเครื่องหมายบวก) ⇒ ซ้าย = ด้านใน
        ผลจัดทิศให้หมุนทางเดียวกับเส้นต้นทาง และเริ่มที่มุมที่ใกล้จุดเริ่มของเส้นต้นทางที่สุด (ช่วงที่ 1 ตรงกับช่วงที่ 1)
        คืน QgsGeometry เส้นปิด (หลายวงได้ เช่นด้านในขาดเป็นหลายก้อน) · ทำไม่ได้ = เรขาคณิตว่าง (ผู้เรียกแจ้งเตือน)"""
        area2 = self._line_ring_area2(src)
        if abs(area2) < 1e-12:
            return QgsGeometry()
        inward = (to_left == (area2 > 0))
        poly = QgsGeometry.fromPolygonXY([[QgsPointXY(q) for q in src]])
        if not poly.isGeosValid():
            return QgsGeometry()              # เส้นปิดที่ตัดตัวเอง (เลข 8) — ไม่เดาให้
        try:
            from qgis.core import Qgis
            cap = Qgis.EndCapStyle.Flat
        except Exception:
            cap = QgsGeometry.CapFlat
        b = poly.buffer(-dist if inward else dist, 8, cap, join, self.LINE_OFFSET_MITRE)
        if b is None or b.isEmpty():
            return QgsGeometry()
        rings = []
        for pg in (b.asMultiPolygon() if b.isMultipart() else [b.asPolygon()]):
            for r in pg:
                d = [QgsPointXY(q) for q in r[:-1]]
                if len(d) < 3:
                    continue
                if (self._line_ring_area2(d + [d[0]]) > 0) != (area2 > 0):
                    d.reverse()
                j = min(range(len(d)), key=lambda k: d[k].distance(src[0]))
                d = d[j:] + d[:j]
                rings.append(d + [QgsPointXY(d[0])])
        if not rings:
            return QgsGeometry()
        return QgsGeometry.fromPolylineXY(rings[0]) if len(rings) == 1 else QgsGeometry.fromMultiPolylineXY(rings)

    def _line_set_nodes(self, on):
        self._line_item.show_nodes = bool(on)
        self._line_item.updatePosition()

    # ---------- โหมดวาด ----------
    def _line_set_drawing(self, on):
        from ..map_tools import DrawLineTool
        canvas = self.iface.mapCanvas()
        if on:
            # ★ 1 ก.ย. 69 — จำเครื่องมือเดิมไว้ เพื่อคืนตอนออกจากโหมดวาด
            #   เดิมใช้ unsetMapTool เฉย ๆ ทำให้แคนวาส "ไม่มีเครื่องมือเลย"
            #   คลิกแผนที่แล้วเงียบสนิท — พนักงานจะรายงานว่า QGIS ค้าง
            #   ซึ่งเป็นอาการเดียวกับปัญหาที่เรากำลังไล่หาสาเหตุอยู่พอดี
            cur = canvas.mapTool()
            if not isinstance(cur, DrawLineTool):
                self._line_prev_tool = cur
                # ★ 2.3.7 (review LC-06) — จำว่าเครื่องมือเดิมเป็น "ของปลั๊กอิน" (= temp_tool ตอนนี้) ไหม
                #   ⇒ ตอนคืนต้องให้ temp_tool ถือมันไว้ (ดู _line_restore_tool)
                self._line_prev_ours = cur is not None and cur is getattr(self, "temp_tool", None)
            # เกราะชั้นสอง: ปุ่ม "เริ่มวาด" บนหน้าต่างเองต้องกู้สภาพซ่อนค้างได้ด้วย
            # ไม่ให้เหลือทางไหนที่ผู้ใช้กดแล้วเส้นยังไม่กลับมา
            try:
                if self._line_item is not None and not self._line_item.isVisible():
                    self._line_item.setVisible(True)
                    self._line_sync_layer()
            except Exception:
                pass
            self._line_snap_borrow()
            self.temp_tool = DrawLineTool(canvas, self._line_item,
                                          self._line_refresh, self._line_on_ref)
            self._line_push_locks()
            canvas.setMapTool(self.temp_tool)
            self.iface.messageBar().pushInfo(
                "วาดเส้น", "คลิกลงจุด · คลิกขวาจบเส้น · Esc ทิ้งเส้นที่กำลังวาด")
        else:
            # ★ 1 ก.ย. 69 — ต้องเช็คว่าเครื่องมือบนแคนวาสเป็นของเราจริง
            #   self.temp_tool ใช้ร่วมกับเครื่องมืออื่นทุกตัวของปลั๊กอิน
            #   ถ้าพนักงานเปิดหน้าต่างวาดเส้นค้างไว้ แล้วไปกด Move Node
            #   พอปิด/ย่อหน้าต่างวาดเส้น โค้ดเดิมจะถอน Move Node ของเขาทิ้งกลางคัน
            cur = canvas.mapTool()
            if isinstance(cur, DrawLineTool):
                # ★ rc2 S_close (review R3-02a) — unsetMapTool ยิง mapToolSet(None) ⇒ _map_tool_changed ต้องรู้ว่านี่คือ
                #   "คืนเครื่องมือที่พักไว้" ไม่ใช่ออกจากงาน (ไม่งั้นงาน 🍩/ที่เลือกของ Align ถูกเก็บกวาดก่อนคืน)
                self._line_unparking = True
                try:
                    canvas.unsetMapTool(cur)
                finally:
                    self._line_unparking = False
                self._line_restore_tool(canvas)
            self._line_snap_return()
            # ★★ 2 ก.ย. 69 (blocker จาก audit) — ต้องล้าง self.temp_tool ด้วย
            #   เดิมล้างแต่เครื่องมือบนแคนวาส แต่ self.temp_tool ยังชี้ DrawLineTool ตัวเก่า
            #   ⇒ พอพนักงานกด Move Node ต่อ start_sync_vertex_tool เรียก
            #      self.temp_tool.deactivate() ซึ่งคือ DrawLineTool.deactivate()
            #      -> _finish() -> _changed() -> _line_refresh() -> _line_sync_layer()
            #      -> _line_layer_get(create=True)  ⇒ **ชั้นเส้นฟื้นคืนชีพเองทั้งที่หน้าต่างปิดไปแล้ว**
            #      แล้ว setup_snapping ที่บรรทัดถัดมาก็ดึงชั้นผีนั้นเข้าเป็นเป้า snap ให้ด้วย
            #      ⇒ ปลายทางการย้ายมุมแปลง+หมุดไปเกาะ "เส้นที่วาดไว้" ได้
            #   ล้างเฉพาะตอนที่มันเป็นของเราจริง — ถ้าพนักงานเปิดหน้าต่างวาดเส้นค้างไว้
            #   แล้วไปกด Move Node อยู่ temp_tool เป็น SyncVertexTool ต้องไม่ไปแตะ
            if isinstance(getattr(self, "temp_tool", None), DrawLineTool):
                self.temp_tool = None
        self._line_sync_toggle(on)

    def _line_restore_tool(self, canvas):
        """คืนเครื่องมือที่ใช้อยู่ก่อนเข้าโหมดวาด — ไม่ทิ้งแคนวาสไว้แบบไม่มีเครื่องมือ

        ★ 2 ก.ย. 69 — คืนแล้วต้องทำให้ self.temp_tool "ตรงกับของจริงบนแคนวาส" ด้วย
          self.temp_tool เป็นตัวแปรใช้ร่วมของเครื่องมือทุกตัวในปลั๊กอิน และมีโค้ดหลายที่
          ที่เชื่อมันตรง ๆ (start_sync_vertex_tool เรียก .deactivate() · unload เทียบกับ
          mapTool() · cancel_transform เรียก .reset_tool()) ถ้าปล่อยให้ค้างเป็นเครื่องมือ
          ที่ถูกถอดออกไปแล้ว จะสั่งงานเครื่องมือผีย้อนหลังได้
        """
        from ..map_tools import DrawLineTool
        prev = getattr(self, "_line_prev_tool", None)
        ours = getattr(self, "_line_prev_ours", False)
        self._line_prev_tool = None
        self._line_prev_ours = False
        if isinstance(getattr(self, "temp_tool", None), DrawLineTool):
            self.temp_tool = None
        try:
            # ★ rc2 S_close (review R3-02a) — ตาข่าย: เครื่องมือกรอบ 🍩 ที่งานของมันถูกเก็บกวาดไปแล้วระหว่างวาดเส้น
            #   (ไม่มีแปลงที่จะหัก) ⇒ ไม่คืน (ปิดกรอบแล้วจะเงียบ) · ไปเครื่องมือมาตรฐานข้างล่างแทน
            from ..map_tools import DonutFrameTool as _DFT
            if isinstance(prev, _DFT) and (getattr(self, "_donut_stage", None) is None
                                           or not getattr(self, "_donut_outer", None)):
                prev = None
            if prev is not None and not isinstance(prev, DrawLineTool):
                # ★ 2.3.7 (review LC-06) — เครื่องมือเดิมของปลั๊กอิน (Move/Rotate/Scale/Transform · Align ขั้น 2 · Move Node)
                #   ต้องกลับไปอยู่ใน temp_tool "ก่อน" setMapTool: ① ตัว QgsMapToolEmitPoint ที่ Python เป็นเจ้าของ
                #   ถูกทำลายทันทีที่ตัวแปรท้องถิ่นนี้หมดอายุ (ref สุดท้าย) ⇒ แคนวาสไม่มีเครื่องมือ คลิกแล้วเงียบ = "QGIS ค้าง"
                #   ② temp_tool ต้องตรงกับของจริงบนแคนวาส (_reapply_snap_limit · unload · cancel_transform เชื่อมัน)
                #   คู่กับ _map_tool_changed ที่ทิ้ง src_pts ⇒ เครื่องมือที่คืนมาเริ่มคลิกแรกใหม่ ไม่ทำงานต่อจากจุดเก่า
                if ours:
                    self.temp_tool = prev
                canvas.setMapTool(prev)      # ตัวที่ถูกลบไปแล้วจะโยน RuntimeError -> ตกไป fallback
                if canvas.mapTool() is not None:
                    return
        except Exception:
            pass
        if ours and getattr(self, "temp_tool", None) is prev:
            self.temp_tool = None            # คืนไม่สำเร็จ ⇒ ไม่ค้างเครื่องมือผีไว้ใน temp_tool
        # ไม่มีตัวเดิมให้คืน -> กลับไปเครื่องมือมาตรฐานของ QGIS
        for name in ("actionPan", "actionSelect"):
            try:
                act = getattr(self.iface, name, None)
                if act is not None:
                    act().trigger()
                    return
            except Exception:
                continue

    def _line_sync_toggle(self, on):
        btn = getattr(self, "_line_toggle", None)
        if btn is None:
            return
        btn.blockSignals(True)
        btn.setChecked(bool(on))
        btn.setText("■ หยุดวาด" if on else "▶ เริ่มวาด")
        btn.setStyleSheet(
            "background-color:#ffcdd2; font-weight:bold; color:#b71c1c;" if on
            else "background-color:#c8e6c9; font-weight:bold; color:#1b5e20;")
        btn.blockSignals(False)

    # ---------- snapping: ยืมแล้วต้องคืน ----------
    @staticmethod
    def _snap_type_int(o):
        """คืนชนิดการดูดเป็น int — ลอง typeFlag() ก่อน (3.14+) แล้วถอยไป type() ของรุ่นเก่า

        typeFlag() คืน Qgis.SnappingTypes ซึ่ง "ไม่ใช่" int ต้อง int() ก่อนเสมอ
        ส่วน type() มี DeprecationWarning ใน 3.44 จึงลอง typeFlag ก่อน
        """
        for name in ("typeFlag", "type"):
            try:
                f = getattr(o, name)
            except Exception:
                continue
            try:
                return int(f())
            except Exception:
                continue
        return None

    @staticmethod
    def _snap_sig(cfg):
        """ลายเซ็นของค่า snapping — ใช้เทียบว่ามีใครมาเปลี่ยนต่อจากเราหรือยัง

        ★★ 2 ก.ย. 69 (blocker จาก audit) — ของเดิมเก็บแค่
           (enabled, mode, typeFlag, tolerance, units) ซึ่ง **ไม่ครอบ individualLayerSettings**
           แต่ตอนโปรเจกต์อยู่ในโหมด AdvancedConfiguration (สภาพจริงของพนักงานหลังกด
           เครื่องมือ MLEP ครั้งแรก) ILS คือ "สิ่งเดียว" ที่ setup_snapping เปลี่ยน
           ⇒ ลายเซ็นออกมาเท่าเดิมเป๊ะ ⇒ เจ้าของค่าถูกตัดสินผิด ⇒ snapping ถูกปิดกลับเงียบ ๆ

        🔴 ต้องเรียกบน cfg ที่ "ดึงสด" จาก QgsProject.instance().snappingConfig() เท่านั้น
           ห้ามเรียกบนสำเนาที่เก็บค้างไว้ — ถ้ามีชั้นใน ILS ของสำเนานั้นถูกลบออกจากโปรเจกต์
           ไปแล้ว การเรียก individualLayerSettings() จะ **SIGSEGV** (ดัก except ไม่ได้)
           วัดเองแล้ว 2 ก.ย. 69: exit 139 core dumped
           (นี่คือเหตุผลที่ _line_snap_borrow เลิกเก็บสำเนา QgsSnappingConfig ไปแล้ว)
        """
        if cfg is None:
            return None
        try:
            glob = (bool(cfg.enabled()),
                    int(cfg.mode()),
                    MultiLayerEditPro._snap_type_int(cfg),
                    float(cfg.tolerance()),
                    int(cfg.units()))
        except Exception:
            return None
        rows, dead = [], 0
        # ★★ 2 ก.ย. 69 (regression ของรอบสอง) — เอา ILS เข้าลายเซ็น **เฉพาะโหมด Advanced**
        #   ในโหมด AllLayers ค่า ILS ราย layer เป็นของที่ QGIS ไม่ได้ใช้ (inert)
        #   แต่ QGIS ยังใส่/ลบรายการให้เองทุกครั้งที่มีเลเยอร์เพิ่ม-ลบ
        #   ⇒ ถ้านับเข้าลายเซ็นด้วย แค่มีเลเยอร์เพิ่มหนึ่งชั้นระหว่างที่ 📐 ยืมแม่เหล็กอยู่
        #     ลายเซ็นก็เปลี่ยน ⇒ เข้าใจผิดว่า "คนอื่นตั้งใหม่" ⇒ ไม่คืน
        #     ⇒ แม่เหล็กค้างเปิดแบบ AllLayers ทับค่าที่พนักงานปิดไว้เอง (วัดได้ คลาด 4.24 ม.)
        #   โหมด Advanced ยังต้องนับ เพราะที่นั่น ILS คือ "สิ่งเดียว" ที่ setup_snapping เปลี่ยน
        try:
            _adv = int(cfg.mode()) == int(QgsSnappingConfig.AdvancedConfiguration)
        except Exception:
            _adv = False
        try:
            ils = (cfg.individualLayerSettings() or {}) if _adv else {}
        except Exception:
            ils = {}                     # API รุ่นเก่า/ไม่มี ILS -> ใช้แค่ค่าหลัก
        for lyr, st in ils.items():
            try:
                key = lyr.id()           # ชั้นที่ถูกลบไปแล้ว -> RuntimeError (ดักได้)
                # ★★ 2 ก.ย. 69 — ต้องข้าม "ชั้นเส้นของเราเอง" ออกจากลายเซ็น
                #   ไม่งั้นพอวาดเส้นเสร็จ ปลั๊กอินสร้างชั้นเส้นขึ้นมา QGIS ก็ใส่ ILS ให้ชั้นนั้น
                #   อัตโนมัติ ⇒ ลายเซ็นเปลี่ยนเพราะการกระทำของตัวเราเอง
                #   ⇒ _line_snap_return เข้าใจผิดว่า "มีคนอื่นมาตั้งค่าใหม่" แล้วไม่ยอมคืน
                #   ⇒ ค่าที่พนักงานตั้งเอง (ปิดแม่เหล็ก) ถูกทับค้างไว้ถาวร
                #   เทียบด้วย "ชื่อ" ไม่ใช่ id เพราะชั้นถูกทิ้ง/สร้างใหม่ได้ระหว่างทาง (ตอนบันทึก)
                if lyr.name() in (MultiLayerEditPro.LINE_LAYER_NAME,
                                  MultiLayerEditPro.LINE_PT_LAYER_NAME):   # ★ 2.3.6 ชั้นจุดที่กรอกพิกัด
                    continue
            except Exception:
                dead += 1
                continue
            try:
                rows.append((key, bool(st.enabled()),
                             MultiLayerEditPro._snap_type_int(st),
                             float(st.tolerance()), int(st.units())))
            except Exception:
                rows.append((key, None, None, None, None))
        rows.sort(key=lambda r: r[0])    # ★ dict มาจาก QHash ลำดับสุ่มต่อโปรเซส ต้องเรียงเอง
        return (glob, tuple(rows), dead)

    def _line_snap_borrow(self):
        """เปิด snapping ให้เฉพาะตอนที่ผู้ใช้ปิดไว้ — แล้วปิดคืนตอนออกจากโหมดวาด

        ★ ตั้งใจ "ไม่" ไปเปลี่ยน mode/type/tolerance ที่หน่วยงานตั้งไว้
          แตะแค่สวิตช์เปิด/ปิด และคืนให้ทุกครั้งที่ออกจากโหมดวาด

        ★★ 2 ก.ย. 69 — เลิกเก็บ "สำเนา QgsSnappingConfig" ไว้คืน เก็บแค่ธงว่ายืมอยู่
          เหตุ: สำเนานั้นถือ pointer ของเลเยอร์ไว้ข้างใน ถ้าพนักงานลบเลเยอร์ออกจาก
          สารบัญระหว่างอยู่ในโหมดวาด แล้วมีโค้ดไหนไปอ่าน ILS ของสำเนา = QGIS ดับทั้งตัว
          (SIGSEGV ดัก except ไม่ได้ · วัดเองแล้ว exit 139)
          และเราไม่จำเป็นต้องใช้สำเนาเลย เพราะยืมแค่สวิตช์เปิด/ปิดอย่างเดียว
        """
        if getattr(self, "_line_snap_borrowed", False):
            return                                   # ยืมอยู่แล้ว
        try:
            prj = QgsProject.instance()
            cfg = prj.snappingConfig()
            if cfg.enabled():
                return                               # เปิดอยู่แล้ว ไม่ต้องยืม
            # ★ 2 ก.ย. 69 — setSnappingConfig ทำให้โปรเจกต์เป็น "มีการแก้ไข"
            #   ⇒ แค่กดปุ่ม 📐 เปิดหน้าต่างวาดเส้น พนักงานก็จะโดนถาม "บันทึกโปรเจกต์ไหม"
            #     ตอนปิด QGIS ทั้งที่ไม่ได้แก้อะไรในโปรเจกต์เลย
            #     เสี่ยงกดบันทึกทับไฟล์กลางของอำเภอโดยไม่ได้ตั้งใจ
            #   เราแค่ "ยืม" สวิตช์แล้วคืน จึงไม่ควรนับเป็นการแก้โปรเจกต์
            was_dirty = prj.isDirty()
            cfg.setEnabled(True)
            prj.setSnappingConfig(cfg)
            if not was_dirty:
                prj.setDirty(False)
            self._line_snap_borrowed = True
            # จำ "สิ่งที่เราเขียนลงไป" ไว้ด้วย — ใช้ตัดสินตอนคืนว่าเรายังเป็นเจ้าของค่าอยู่ไหม
            self._line_wrote_snap = self._snap_sig(prj.snappingConfig())
        except Exception as e:
            self._line_snap_borrowed = False
            self._line_wrote_snap = None
            QgsMessageLog.logMessage("_line_snap_borrow: เปิดแม่เหล็กให้หน้าต่างวาดเส้นไม่สำเร็จ — %s" % e,
                                     "MLEP", Qgis.Warning)                  # ★ 2.3.7 (UX-49)

    @staticmethod
    def _snap_sig_compatible(wrote, live, _err=None):
        """ลายเซ็นยัง "เป็นของเรา" อยู่ไหม — โดยไม่ถือสาชั้นที่เพิ่งมี/เพิ่งหายไป

        🔴🔴 3 ก.ย. 69 (ผู้ตรวจจับได้ · ทำซ้ำได้บน QGIS 3.40.6 Windows) —
          QGIS ใส่แถว IndividualLayerSettings ให้ชั้นที่ "เพิ่งถูกเพิ่มเข้าโปรเจกต์" เอง
          (วัดได้: ILS 2 -> 3 แถว ทันทีที่ลากชั้นระวางเข้ามา)
          ⇒ ลายเซ็นเปลี่ยนทั้งที่ไม่มีใครมาแย่งความเป็นเจ้าของค่า snapping เลย
          ⇒ _line_snap_return เข้าใจผิดว่า "มีคนอื่นตั้งค่าใหม่" แล้วไม่ยอมคืน
          ⇒ แม่เหล็กที่พนักงานตั้งใจปิดไว้ ถูกเปิดค้างถาวร เสี่ยงหมุดโดนดูดผิดตำแหน่ง
             แล้วเขียนพิกัดผิดลงฐาน (ลำดับจริง: กด Move Node -> ปิดแม่เหล็กเอง ->
             เปิดวาดเส้น -> ลากชั้นเข้ามา -> ปิดหน้าต่างวาดเส้น)

        จึงเทียบแค่สองอย่าง
          ① ค่าระดับโปรเจกต์ (enabled/mode/type/tolerance/units) ต้องตรง
          ② ชั้นที่ "มีอยู่ทั้งสองฝั่ง" ค่าต้องไม่ถูกแก้
        ยังจับกรณีที่ต้องจับได้เหมือนเดิม: setup_snapping ของเครื่องมืออื่นเขียนทับค่า
        ของชั้นทำงานเดิม ซึ่งอยู่ทั้งสองฝั่งอยู่แล้ว
        ★ rc1 (F8 · §5.1 ER-09) _err = ลิสต์ (ผู้เรียกที่มี self) ⇒ เติม True เมื่อเทียบล้ม ให้ผู้เรียกขึ้นแถบ _qgz_leftover_warn
        """
        if wrote is None or live is None:
            return False
        try:
            if wrote[0] != live[0]:
                return False
            wa = {r[0]: tuple(r[1:]) for r in (wrote[1] or ())}
            la = {r[0]: tuple(r[1:]) for r in (live[1] or ())}
            for k in set(wa) & set(la):
                if wa[k] != la[k]:
                    return False
            return True
        except Exception:
            # ★ 2.4.0 (review ER-09) — ตอบ "ไม่ใช่ของเรา" ⇒ แม่เหล็กที่ยืมไม่ถูกคืน (ค้างลงไฟล์ได้) ⇒ ต้องมีร่องรอย
            _log_exc("_snap_sig_compatible: เทียบลายเซ็นแม่เหล็กไม่สำเร็จ (ถือว่าไม่ใช่ค่าที่ยืม)", once_key="ER-09:snap-sig")
            if _err is not None:
                _err.append(True)
            return False

    def _line_snap_return(self):
        """คืนค่า snapping — เฉพาะเมื่อค่าปัจจุบันยังเป็นของที่เราเขียนไว้

        🔴 1 ก.ย. 69 — เดิมคืนแบบทับดื้อ ๆ ซึ่งพังหนัก:
          เครื่องมืออื่นทุกตัวที่ต้องใช้ snapping (Move Node · Align · แก้ชื่อหมุด · ลบ Node)
          เรียก setup_snapping() ตั้งค่าก่อน แล้วค่อย setMapTool
          พอ setMapTool ยิง signal เข้ามาที่ _map_tool_changed เราก็คืนค่าเก่าทับทันที
          -> snapping ถูกปิดกลับ พนักงานลากหมุดไม่ติดแบบไม่มีสัญญาณเตือนอะไรเลย
          ตอนนี้: ถ้าค่าปัจจุบันไม่ใช่ของที่เราเขียน = มีคนอื่นตั้งใหม่แล้ว ให้ปล่อยของเขาไว้
        """
        if not getattr(self, "_line_snap_borrowed", False):
            return
        wrote = getattr(self, "_line_wrote_snap", None)
        # ★ 2.3.7 (review UX-49) — ปล่อยธง "ยืมอยู่" เมื่อคืนสำเร็จ หรือรู้แน่ว่ามีคนอื่นตั้งค่าใหม่แล้ว เท่านั้น
        #   เดิมล้างธงก่อนลองคืน ⇒ คืนล้มครั้งเดียว แม่เหล็กที่พนักงานปิดไว้ค้างเปิดถาวร ไม่มีใครลองคืนอีก และไม่มี log
        try:
            prj = QgsProject.instance()
            _se = []
            if wrote is not None and not self._snap_sig_compatible(
                    wrote, self._snap_sig(prj.snappingConfig()), _se):
                self._line_snap_borrowed = False
                self._line_wrote_snap = None
                if _se:                   # ★ rc1 (F8 · §5.1 ER-09) ไม่ใช่ "คนอื่นตั้งใหม่" แต่เทียบล้ม ⇒ แม่เหล็กไม่ถูกคืน · บอก
                    self._qgz_leftover_warn("แม่เหล็ก (snapping) ที่ปลั๊กอินเปิดให้หน้าต่างวาดเส้นอาจไม่ถูกคืน — ถ้าบันทึกโปรเจกต์ ค่าแม่เหล็กนี้จะติดไปในไฟล์ · "
                    "ตรวจ/ปิดแม่เหล็กเองก่อนบันทึกโปรเจกต์")
                return                    # มีคนอื่นตั้งค่าใหม่แล้ว — ปล่อยของเขาไว้
            cfg = prj.snappingConfig()    # ★ ดึงสด ไม่ใช้สำเนาเก่า (กัน SIGSEGV)
            was_dirty = prj.isDirty()
            cfg.setEnabled(False)
            prj.setSnappingConfig(cfg)
            if not was_dirty:
                prj.setDirty(False)       # คืนของที่ยืม ไม่นับเป็นการแก้โปรเจกต์เช่นกัน
            self._line_snap_borrowed = False
            self._line_wrote_snap = None
        except Exception as e:
            QgsMessageLog.logMessage("_line_snap_return: คืนค่าแม่เหล็กไม่สำเร็จ (จะลองใหม่รอบหน้า) — %s" % e,
                                     "MLEP", Qgis.Warning)

    # ---------- ปุ่มต่าง ๆ ----------
    def _line_set_labels(self, on):
        self._line_item.show_labels = bool(on)
        self._line_item.updatePosition()

    def _line_owns_undo(self):
        """★ 2.3.7 (review DI-25) — คีย์ Undo ของปลั๊กอิน (Ctrl+Z) ควรถอยงานวัดระยะแทนงานแปลง/หมุดไหม
        ใช่ เมื่อเครื่องมือวาดเส้นอยู่บนแคนวาส หรือหน้าต่างวาดเส้นเปิดอยู่และเป็นหน้าต่างที่ใช้งาน (โฟกัสที่ปุ่ม/ผลการวัด)
        ช่องกรอก E/N กิน Ctrl+Z ของตัวเองก่อน (ShortcutOverride) จึงไม่มาถึงที่นี่"""
        if getattr(self, "_line_item", None) is None:
            return False
        try:
            from ..map_tools import DrawLineTool
            if isinstance(self.iface.mapCanvas().mapTool(), DrawLineTool):
                return True
            win = getattr(self, "_line_dock", None)
            return bool(win is not None and win.isVisible() and win.isActiveWindow())
        except Exception:
            return False

    def _line_undo(self):
        it = getattr(self, "_line_item", None)
        if it is None:
            return
        # ★ 2.3.7 (review UX-37) — ไม่มีอะไรให้ถอยแล้ว แต่เพิ่งกด 🧹 ล้างเส้น ⇒ เรียกคืนทั้งชุด (ครั้งเดียว)
        snap = getattr(self, "_line_clear_undo", None)
        if snap and not it.temp and not it.lines:
            self._line_clear_undo = None
            it.lines = [[QgsPointXY(q) for q in ln] for ln in snap[0]]
            it.temp = [QgsPointXY(q) for q in snap[1]]
            it.cursor = None
            it.updatePosition()
            self._line_refresh()
            self.iface.messageBar().pushMessage(
                "วาดเส้น", "เรียกคืนเส้นที่ล้างไปแล้ว (%d เส้น)" % len([ln for ln in it.lines if len(ln) >= 2]),
                level=0, duration=5)
            return
        it.undo_last()
        # ★ 2.3.7 (review DI-25) — ↺ / Ctrl+Z ถอยจุดระหว่างล็อกแนว (Shift ค้าง) ⇒ ปล่อยแนวแบบเดียวกับ Backspace
        #   (ถอยเลยจุดตั้งต้นของแนว = จุดก่อนหน้าไม่อยู่บนแนวแล้ว)
        try:
            from ..map_tools import DrawLineTool
            tool = getattr(self, "temp_tool", None)
            if isinstance(tool, DrawLineTool) and not tool._on_dir_line(it.temp[-1] if it.temp else None):
                tool._dir_az = None
        except Exception:
            pass
        self._line_refresh()

    def _line_clear(self):
        """ปุ่ม 🧹 ล้างเส้นทั้งหมด — CHANGELOG บอกพนักงานว่าใช้ปุ่มนี้ "เริ่มวัดใหม่ทั้งหมด"
        จึงต้องล้าง "แนวอ้างอิงมุม" ให้ด้วย ไม่งั้นเส้นชุดใหม่จะถูกล็อกเข้าแนวของงานเก่า
        ★ 2.3.7 (review UX-37 · ทางตั้งต้นที่หัวหน้างานเลือก: ไม่ถาม แต่เรียกคืนได้) — ปุ่มนี้อยู่ติด ▶ เริ่มวาด กว้างเท่ากัน
          (สเปก 1 ต.ค.) กดพลาดได้ แล้วงานวัดสะสมหายในคลิกเดียว ⇒ เก็บสำเนา 1 ขั้นให้ ↺ ถอยจุด/เส้น เรียกคืน
          ทิ้งสำเนาเมื่อเริ่มเส้นใหม่ (_line_refresh) / เปลี่ยนสาขา (_line_forget_lines) · จุดจากค่าพิกัดไม่ถูกล้าง (สเปก 2.3.6)"""
        it = self._line_item
        had = bool(it.lines or it.temp)
        if had:
            self._line_clear_undo = ([[QgsPointXY(q) for q in ln] for ln in it.lines],
                                     [QgsPointXY(q) for q in it.temp])
        self._line_item.clear_all()
        try:
            self._line_clear_ref()
        except Exception:
            pass
        self._line_refresh()
        if had:
            self.iface.messageBar().pushMessage(
                "วาดเส้น", "ล้างเส้นแล้ว — กด ↺ ถอยจุด/เส้น เพื่อเรียกคืน", level=0, duration=6)

    def _line_copy(self):
        txt = self._line_text()
        if not txt:
            # ★ 2.3.7 (review UX-37) — เดิมเงียบ (คลิปบอร์ดไม่เปลี่ยน ไม่มีข้อความ) ตอนมีแต่เส้นที่ยังวาดไม่จบ
            self.iface.messageBar().pushMessage(
                "วาดเส้น", "ยังไม่มีเส้นที่วาดจบ — คลิกขวาเพื่อจบเส้นก่อน", level=0, duration=5)
            return
        try:
            QtWidgets.QApplication.clipboard().setText(txt)
            self.iface.messageBar().pushInfo("วาดเส้น", "คัดลอกผลการวัดแล้ว")
        except Exception as e:
            # ★ 2.3.7 (review UX-37) — เดิมกลืนเงียบ ⇒ ลง log + บอกว่าไม่สำเร็จ
            QgsMessageLog.logMessage("_line_copy: คัดลอกลงคลิปบอร์ดไม่สำเร็จ — %s" % e, "MLEP", Qgis.Warning)
            self.iface.messageBar().pushMessage("วาดเส้น", "คัดลอกผลการวัดไม่สำเร็จ — ลองกดอีกครั้ง",
                                                level=1, duration=5)

    def _line_text(self):
        it = self._line_item
        out = []
        for i, pts in enumerate(it.lines, 1):
            if len(pts) < 2:
                continue
            segs = " + ".join(it.fmt(it.seg_len(pts[j], pts[j + 1]))
                              for j in range(len(pts) - 1))
            out.append("เส้นที่ %d: %s = %s" % (i, segs, it.fmt(it.line_len(pts))))
        if out:
            out.append("รวมทั้งหมด %s" % it.fmt(it.total_len()))
        # ★ 2.3.6 — จุดที่กรอกพิกัด (มีเฉพาะเมื่อมีจุด ⇒ ผลแบบเดิมไม่เปลี่ยน)
        for p in (getattr(self, "_line_pts", None) or []):
            # ★ 2.3.7 — N ก่อน E ให้ตรงกับช่องกรอกและรายการจุด (เจ้าของงานสั่ง 3 ต.ค.)
            out.append("จุด %s: N %.3f  E %.3f" % (p["name"], p["n"], p["e"]))
        return "\n".join(out)

    # ---------- ตาราง ----------
    # ---------- ชั้นเส้นจริง (ให้ snap ติด + ให้ QGIS วาดเอง) ----------
    #  ★ 1 ก.ย. 69 — เดิมวาดลงแคนวาสอย่างเดียว ไม่สร้างชั้น ผลคือ
    #    ① เครื่องมือของปลั๊กอิน snap ติดเส้นที่วาดไม่ได้เลย (เจ้าของงานเจอเอง)
    #       ทั้งที่ setup_snapping มีโค้ดรับชั้นนี้อยู่แล้ว — จับด้วย "ชื่อชั้น" = LINE_TOOL_LAYER
    #    ② เส้นบางครั้งไม่โผล่หลังปิด/เปิดหน้าต่างใหม่ (ปัญหาการวาดของ QgsMapCanvasItem)
    #    -> ให้ QGIS วาดเส้นเองผ่านชั้นจริง ส่วนแคนวาสไอเทมเหลือหน้าที่แค่
    #       เส้นที่กำลังลาก + ป้ายระยะ + แนวอ้างอิง
    #  โปรเจกต์จะไม่ถูกทำให้ "มีการแก้ไข" เพราะเราคืนค่า dirty เดิมทุกครั้งที่เพิ่ม/ลบชั้น
    def _line_layer_get(self, create=True):
        prj = QgsProject.instance()
        lid = getattr(self, "_line_layer_id", None)
        if lid:
            lyr = prj.mapLayer(lid)
            if lyr is not None:
                return lyr
            self._line_layer_id = None
        if not create:
            return None
        try:
            crs = self.iface.mapCanvas().mapSettings().destinationCrs().authid() or "EPSG:24047"
            lyr = QgsVectorLayer("LineString?crs=%s&field=ระยะ_ม:double" % crs,
                                 self.LINE_LAYER_NAME, "memory")
            _lc = getattr(self, "_line_crs", None)
            if lyr.isValid() and _lc is not None and _lc.isValid() and lyr.crs() != _lc:
                lyr.setCrs(_lc)              # ★ 2.3.7 (DI-40) ชั้น = CRS เดียวกับจุดของเส้น (ไม่ใช่แค่ authid ของแผนที่)
            if not lyr.isValid():
                # ★ 2.3.7 (review UX-49) — เดิมคืน None เงียบ ⇒ ตามไม่ได้ว่าทำไม "เส้นที่วาดไม่ขึ้น/snap ไม่ได้"
                QgsMessageLog.logMessage("_line_layer_get: สร้างชั้นเส้นวัดไม่สำเร็จ (ชั้นไม่ valid · CRS %s)" % crs,
                                         "MLEP", Qgis.Warning)
                return None
            # ★★ 2 ก.ย. 69 — ปิดกล่องเตือนของ QGIS
            #   "This project includes one or more temporary scratch layers ...
            #    their contents will be permanently lost"
            #   QgisApp::checkMemoryLayers() อ่านคุณสมบัตินี้แล้ว .toInt() != 0 -> ข้ามชั้นนี้ไป
            #   ครอบทุกทางเข้าที่มี 9 จุด: File>New · Open · Revert · Exit · กากบาทปิดหน้าต่าง ·
            #   ลากไฟล์เข้ามา · openLayer  (ตรวจจากไบนารีและทดสอบกับ QGIS จริงแล้ว 2 ก.ย. 69)
            #   🔴 ต้องเป็นค่าที่ toInt() ไม่เป็นศูนย์ — สตริง "true" ใช้ไม่ได้ (toInt()==0)
            #   ชั้นนี้เป็นแค่ภาพสะท้อนของเส้นบนแคนวาส ไม่มีข้อมูลอะไรให้เสียอยู่แล้ว
            #   จึงไม่ควรไปขวางพนักงานด้วยกล่องที่ตอบ Cancel แล้วปิดโปรเจกต์ไม่ได้
            try:
                lyr.setCustomProperty("skipMemoryLayersCheck", 1)
            except Exception:
                _log_exc("_line_layer_get: ตั้ง skipMemoryLayersCheck ไม่สำเร็จ", once_key="ER-09:skipmem")  # ★ 2.4.0 (ER-09)
            # ★ 1 ก.ย. 69 — ตั้งเป็น "อ่านอย่างเดียว"
            #   ชั้นนี้เป็นภาพสะท้อนของเส้นที่วาดไว้ ปลั๊กอินเขียนทับใหม่ทุกครั้งที่คลิก
            #   ถ้าพนักงานเผลอเปิดแก้ไขแล้วเพิ่มเส้นของตัวเองเข้าไป
            #   จะถูกลบทิ้งเงียบ ๆ ในคลิกถัดไป (ทดสอบแล้ว: ฟีเจอร์ 2 -> 1 ไม่มีคำเตือน)
            #   อ่านอย่างเดียวไม่กระทบการ snap — snap ไม่ต้องการสิทธิ์แก้ไข
            try:
                lyr.setReadOnly(True)
            except Exception:
                pass
            try:    # สีเดียวกับที่ไอเทมบนแคนวาสใช้ จะได้ดูเป็นของชิ้นเดียวกัน
                sym = lyr.renderer().symbol()
                sym.setColor(QtGui.QColor(21, 101, 192))
                sym.setWidth(0.5)
            except Exception:
                pass
            was = prj.isDirty()
            self._line_add_own_layer(prj, lyr)
            if not was:
                prj.setDirty(False)      # ไม่ให้ QGIS ถามว่าจะบันทึกโปรเจกต์ไหมเพราะชั้นชั่วคราวของเรา
                # 🔴 3 ก.ย. 69 — setDirty(False) เฉย ๆ ไม่พอ: QGIS ตั้งธง dirty จาก
                #   addMapLayer แบบ "เข้าคิว" (queued) ⇒ มันมาทับทีหลังตัวกันนี้เสมอ
                #   วัดได้: ทันที=True · หลังตัวกัน=False · +50ms=True · +450ms=True
                #   ผลคือวาดเส้นแล้วปิด QGIS ทีไรก็โดนถาม "บันทึกโปรเจกต์ไหม"
                #   เสี่ยงพนักงานเผลอกดบันทึกทับไฟล์กลางของอำเภอ (ตรงข้ามกับข้อ B3)
                #   ⇒ ปลดธงซ้ำในรอบ event loop ถัดไป (แพตเทิร์นเดียวกับ _line_clear_save_flag)
                try:
                    QtCore.QTimer.singleShot(0, self._line_undirty)
                except Exception:
                    _log_exc("_line_layer_get: ตั้งเวลาปลดธง 'มีการแก้ไข' ไม่สำเร็จ", once_key="ER-09:undirty-timer")  # ★ ER-09
            self._line_layer_id = lyr.id()
            return lyr
        except Exception as e:
            QgsMessageLog.logMessage("_line_layer_get: สร้างชั้นเส้นวัดล้ม — %s" % e, "MLEP", Qgis.Warning)  # ★ 2.3.7 UX-49
            return None

    def _line_layer_drop(self):
        """เอาชั้นออกตอนปิดหน้าต่าง — ไม่ทิ้งชั้นค้างไว้ในโปรเจกต์
        ★ 2.3.6 — เอาออกทั้งชั้นเส้นและชั้นจุดที่กรอกพิกัด (ทุกทางที่เรียกต้องการให้หายทั้งคู่:
          ปิดหน้าต่าง · ก่อนเขียนไฟล์โปรเจกต์ · unload · เปลี่ยนสาขา)"""
        self._line_drop_one("_line_layer_id")
        self._line_drop_one("_line_pt_layer_id")

    def _line_drop_one(self, attr):
        """เอาชั้นชั่วคราวของเราออก 1 ชั้น (attr = ชื่อแอตทริบิวต์ที่เก็บ layer id)"""
        prj = QgsProject.instance()
        lid = getattr(self, attr, None)
        if not lid or prj.mapLayer(lid) is None:
            setattr(self, attr, None)          # ไม่มีชั้นนี้อยู่แล้วจริง ⇒ ลืม id ได้
            return
        try:
            was = prj.isDirty()
            self._line_own_swap = True
            try:
                prj.removeMapLayer(lid)
            finally:
                self._line_own_swap = False
            # ★ 2.3.7 (review UX-49) — ลืม id หลังถอดสำเร็จเท่านั้น (เดิมลืมก่อนถอด ⇒ ถอดล้ม = ชั้นค้างในโปรเจกต์
            #   โดยไม่มีใครรู้ id · _on_project_write ไม่รู้ว่าต้องตัดชั้นไหนออกจาก .qgz · กวาดชั้นผีก็ข้าม)
            if prj.mapLayer(lid) is None:
                setattr(self, attr, None)
            else:
                QgsMessageLog.logMessage("_line_drop_one: ถอดชั้น %s ไม่สำเร็จ (ยังอยู่ในโปรเจกต์)" % lid,
                                         "MLEP", Qgis.Warning)
            if not was:
                prj.setDirty(False)
                try:
                    # ★ 2.3.7 (review LC-03b) — ห้ามอ้าง self: ตอน unload ธง _alive เป็น False แล้ว _line_undirty จะ return
                    #   ⇒ โปรเจกต์ค้าง "มีการแก้ไข" หลัง reload/อัปเดตตัวเอง (ถูกถาม save project แล้วอาจทับ .qgz ของสาขา)
                    QtCore.QTimer.singleShot(0, lambda: QgsProject.instance().setDirty(False))   # เหตุผลเดียวกับขาเพิ่มชั้น
                except Exception:
                    _log_exc("_line_drop_one: ตั้งเวลาปลดธง 'มีการแก้ไข' ไม่สำเร็จ", once_key="ER-09:undirty-timer")  # ★ ER-09
        except Exception as e:
            QgsMessageLog.logMessage("_line_drop_one: ถอดชั้น %s ล้ม — %s" % (lid, e), "MLEP", Qgis.Warning)  # ★ 2.3.7

    def _line_add_own_layer(self, prj, lyr):
        """ใส่ชั้นชั่วคราวของเราเข้าโปรเจกต์ (★ 2.3.6 audit รอบ 2)
        · `addMapLayer(lyr, False)` + ใส่บนสุดของสารบัญเอง — เดิม `addMapLayer(lyr)` ทำให้ QGIS
          ① เลือกชั้นใหม่เป็น "ชั้นปัจจุบัน" (autoSelectAddedLayer) ⇒ พนักงานคลิกเลือกแปลงไม่ติด
          ② วางชั้นตามจุดแทรกของแผงชั้น ⇒ ถ้าเลือกกลุ่มที่ปิดไว้อยู่ ชั้นจะมองไม่เห็นและ snap ไม่ได้
        · ยกธง `_line_own_swap` ⇒ `_project_layers_changed` ไม่ล้างเงาแปลงของ Move ที่ทำค้างอยู่"""
        self._line_own_swap = True
        try:
            prj.addMapLayer(lyr, False)
            try:
                prj.layerTreeRoot().insertLayer(0, lyr)
            except Exception:
                pass
        finally:
            self._line_own_swap = False
        self._line_snap_own_layer(prj, lyr)       # ★ 2.3.7 (ข้อทราบแล้ว 2.3.6 🔎)

    def _line_snap_own_layer(self, prj, lyr):
        """★ 2.3.7 (เอกสารตรวจ 2.3.6 ข้อทราบแล้ว 🔎) — โหมด snap แบบ Advanced (สภาพจริงหลังกดเครื่องมือที่ตั้ง snap ให้)
        ชั้นเส้น/ชั้นจุดของเราที่เกิด "ทีหลัง" (จุดแรก · หลัง Ctrl+S · ปิด-เปิดหน้าต่าง · ล้างแล้วสร้างใหม่) ได้ค่าของ QGIS
        สำหรับชั้นใหม่ (digitizing/default-snap-enabled) — ถ้าค่านั้นถูกบันทึกเป็นปิด ชั้นเรา snap ไม่ได้จนกว่าจะกด Move Node ฯลฯ อีกครั้ง
        ⇒ ตั้งแถวของ "ชั้นเราเท่านั้น" ให้เปิด ค่าเดียวกับที่ setup_snapping ให้ชั้นทำงาน (VertexAndSegment 20 px)
        · ดึง config สดแล้วทิ้ง ห้ามเก็บสำเนา QgsSnappingConfig ข้ามการเรียก (SIGSEGV ดู _snap_sig) · ไม่แตะแถวชั้นอื่น
        · ชั้นเราไม่อยู่ในลายเซ็นแม่เหล็ก (_snap_sig ข้ามด้วยชื่อ) ⇒ การยืม/คืนแม่เหล็กไม่เพี้ยน · ไม่ทำให้โปรเจกต์ dirty
        · โหมดอื่น (AllLayers/ActiveLayer) ไม่แตะ — snap ตามค่าระดับโปรเจกต์อยู่แล้ว"""
        try:
            cfg = prj.snappingConfig()
            if int(cfg.mode()) != int(QgsSnappingConfig.AdvancedConfiguration):
                return
            want = QgsSnappingConfig.IndividualLayerSettings(
                True, QgsSnappingConfig.VertexAndSegment, 20, QgsTolerance.Pixels)
            cur = cfg.individualLayerSettings(lyr)
            try:
                if (cur.valid() and cur.enabled() and self._snap_type_int(cur) == self._snap_type_int(want)
                        and float(cur.tolerance()) == 20.0 and int(cur.units()) == int(QgsTolerance.Pixels)):
                    return                # ตั้งไว้ถูกอยู่แล้ว
            except Exception:
                pass
            cfg.setIndividualLayerSettings(lyr, want)
            was = prj.isDirty()
            prj.setSnappingConfig(cfg)
            if not was:
                prj.setDirty(False)
        except Exception as e:
            QgsMessageLog.logMessage("_line_snap_own_layer: ตั้ง snap ให้ชั้นชั่วคราวของเราไม่สำเร็จ — %s" % e,
                                     "MLEP", Qgis.Warning)

    def _line_undirty(self):
        """ปลดธง "โปรเจกต์มีการแก้ไข" ในรอบ event loop ถัดไป

        ใช้คู่กับ setDirty(False) แบบทันที เพราะ QGIS ตั้งธงนี้จาก addMapLayer/removeMapLayer
        แบบเข้าคิว ตัวกันแบบทันทีจึงถูกทับเสมอ (วัดเอง 3 ก.ย. 69 บน QGIS 3.40.6)
        เรียกเฉพาะกรณีที่ "ก่อนหน้านี้โปรเจกต์สะอาด" เท่านั้น (ผู้เรียกเป็นคนเช็ก)
        จึงไม่มีทางไปกลบการแก้ไขจริงของพนักงาน
        """
        if not getattr(self, "_alive", True):
            return
        try:
            QgsProject.instance().setDirty(False)
        except Exception:
            _log_exc("_line_undirty: ปลดธง 'มีการแก้ไข' ไม่สำเร็จ", once_key="ER-09:undirty")   # ★ 2.4.0 (review ER-09)

    def _line_window_open(self):
        """หน้าต่างวาดเส้น "เปิดใช้งานอยู่" หรือไม่ — ใช้ตัดสินว่าชั้นเส้นควรมีตัวตนไหม

        ★ 2 ก.ย. 69 — ใช้ "ไอเทมบนแคนวาสมองเห็นอยู่ไหม" ไม่ใช่ dock.isVisible()
          เพราะ start_draw_line ตั้ง _line_item.setVisible(True) แล้วเรียก _line_sync_layer()
          "ก่อน" จะ show() หน้าต่าง ⇒ ถ้าเช็คที่หน้าต่างจะบล็อกทางเปิดปกติทิ้ง
          ส่วนขาปิด/ย่อ (Close/Hide) ตั้ง setVisible(False) ก่อนเสมอ ⇒ เช็คนี้จับได้ถูกจังหวะ
        """
        if getattr(self, "_line_dock", None) is None:
            return False
        it = getattr(self, "_line_item", None)
        if it is None:
            return False
        try:
            return bool(it.isVisible())
        except Exception:
            return False

    def _line_on_crs_changed(self, *_a):
        """★ 2.3.7 (review DI-40) — CRS ของแผนที่ (ตาม CRS โปรเจกต์) เปลี่ยน ⇒ แปลงพิกัดเส้นวัดทั้งหมดตาม (ตำแหน่งบนพื้นเท่าเดิม)
        เดิมจุดเป็นตัวเลขเปลือยของ CRS เก่า: เปลี่ยน 4326 → 24047 (ที่ปลั๊กอินเองแนะนำ) แล้วเส้น 108 ม. กลายเป็น 0.001 ม.
        เส้นขนาน 5 ม. ไปโผล่ห่าง ~550 กม. และชั้นเส้นยังเป็น CRS เดิมแต่รับพิกัดของ CRS ใหม่
        · แปลงทันทีในสัญญาณ (คำนวณล้วน ไม่แตะเลเยอร์) — คลิกถัดไปได้จุดใน CRS ใหม่ จึงห้ามมีช่องว่าง
        · CRS ใช้ไม่ได้ (เช่นระหว่างล้างโปรเจกต์) = ยังไม่แปลง รอ CRS ที่ใช้ได้แล้วแปลงจาก _line_crs ตรง ๆ (ไม่ไป-กลับผ่าน CRS ชั่วคราว)
        · ชั้นเส้นสร้างใหม่ใน CRS ใหม่แบบเลื่อนออกไป (_line_after_crs_change · _line_sync_layer ตรวจ CRS ของชั้นอีกชั้น)
        · แปลงไม่ได้ = ล้างเส้นพร้อมบอก ไม่ตีความตัวเลขเดิมเป็นพิกัดของระบบใหม่"""
        if not getattr(self, "_alive", True):
            return
        it = getattr(self, "_line_item", None)
        if it is None:
            return
        try:
            new = QgsCoordinateReferenceSystem(self.iface.mapCanvas().mapSettings().destinationCrs())
        except Exception:
            return
        if not new.isValid():
            return
        old = getattr(self, "_line_crs", None)
        if old is not None and old.isValid() and old != new:
            snap = getattr(self, "_line_clear_undo", None)
            try:
                xf = QgsCoordinateTransform(old, new, QgsProject.instance())

                def tr(q):
                    r = xf.transform(QgsPointXY(q))
                    if not (math.isfinite(r.x()) and math.isfinite(r.y())):
                        raise ValueError("พิกัดนอกขอบเขตของระบบใหม่")
                    return QgsPointXY(r)
                lines = [[tr(q) for q in ln] for ln in it.lines]
                temp = [tr(q) for q in it.temp]
                cur = tr(it.cursor) if it.cursor is not None else None
                ref = tuple(tr(q) for q in it.ref_line) if it.ref_line else None
                snap2 = ([[tr(q) for q in ln] for ln in snap[0]], [tr(q) for q in snap[1]]) if snap else None
            except Exception as e:
                n = len(it.lines) + (1 if it.temp else 0)
                it.lines, it.temp, it.cursor, it.ref_line = [], [], None, None
                self._line_clear_undo = None
                QgsMessageLog.logMessage("_line_on_crs_changed: แปลงพิกัดเส้นวัด %s → %s ไม่ได้ — %s"
                                         % (old.authid(), new.authid(), e), "MLEP", Qgis.Warning)
                if n:
                    self.iface.messageBar().pushMessage(
                        "วาดเส้น", "ระบบพิกัดของแผนที่เปลี่ยน (%s → %s) แต่แปลงพิกัดเส้นวัดไม่ได้ — ล้างเส้นวัด %d เส้นแล้ว "
                        "(วาดใหม่ได้)" % (old.authid(), new.authid(), n), level=1, duration=10)
            else:
                it.lines, it.temp, it.cursor, it.ref_line = lines, temp, cur, ref
                self._line_clear_undo = snap2
            # แนวที่ล็อกด้วย Shift คิดในระนาบของ CRS เดิม ⇒ ปล่อย (กด Shift ใหม่ได้)
            try:
                from ..map_tools import DrawLineTool
                tool = getattr(self, "temp_tool", None)
                if isinstance(tool, DrawLineTool):
                    tool._dir_az = None
                    tool._dir_anchor = None
                    tool._dir_block = False
                    tool._ref_pts = []
            except Exception:
                pass
        self._line_crs = new
        try:
            it.updatePosition()
        except Exception:
            pass
        for _fn in (self._line_pt_update_hint, self._line_lock_units_check):   # ป้ายระบบพิกัดของจุด · ล็อกระยะ (DI-41)
            try:
                _fn()
            except Exception:
                pass
        # ★ 2.3.7 rc3 (Windows audit 🔴1) — รวบเป็นงานเดียว: CRS เปลี่ยนติดกันหลายครั้ง (กด Apply ซ้ำ · setCrs ต่อกัน ·
        #   ระหว่างกล่องเลือก transformation เปิดค้าง) = สร้างชั้นเส้นใหม่รอบเดียว · จุดของเส้นแปลงตามทันทีทุกครั้งข้างบนแล้ว
        #   รอบที่เลื่อนไปจึงใช้ _line_crs ล่าสุดตอนทำ (ธงถูกปลดใน _line_after_crs_change ตอนทำจริงเท่านั้น)
        if not getattr(self, "_line_crs_pending", False):
            self._line_crs_pending = True
            try:
                QtCore.QTimer.singleShot(0, self._line_after_crs_change)
            except Exception:
                self._line_crs_pending = False

    @staticmethod
    def _line_ui_busy():
        """★ 2.3.7 rc3 (Windows audit 🔴1) — ตอนนี้อาจอยู่ใน event loop ซ้อนของโค้ดอื่นไหม: มีกล่อง modal ของใครก็ได้เปิดอยู่
        (Select Transformation · Project Properties · กล่องของเราเอง _ask) หรือมีเมนู popup เปิดอยู่ (QMenu::exec = ลูปซ้อนเหมือนกัน)
        ระหว่างนั้นโค้ดที่เปิดกล่องยังค้างอยู่บน stack และอาจถือ pointer ดิบของเลเยอร์ไว้:
        QgisApp::projectCrsChanged สำเนา mapLayers() แล้วถาม crs() ทีละชั้น พร้อมเปิดกล่องเลือก transformation (exec)
        ⇒ ถ้าตัวจับเวลาของเราถอดชั้นเส้นในลูปของกล่องนั้น ปิดกล่องแล้ว QGIS ไปอ่านชั้นที่ถูกลบ = ดับทั้งโปรแกรม (ผู้ตรวจ Windows 5/5)"""
        try:
            app = QtWidgets.QApplication
            return app.activeModalWidget() is not None or app.activePopupWidget() is not None
        except Exception:
            return False

    def _line_wait_free(self, fn):
        """★ 2.3.7 rc3 (Windows audit 🔴1) — ด่านของงานชั้นเส้นที่ถูกเลื่อนด้วย QTimer (เพิ่ม/ถอด/สร้างชั้นใหม่) — ผู้เรียกตรวจ _alive มาก่อน
        มีกล่อง modal/เมนูเปิดอยู่ ⇒ ตั้งเวลาเรียก fn ใหม่ แล้วคืน True (ผู้เรียก return ทันที ไม่แตะเลเยอร์) · ว่างแล้ว ⇒ คืน False (ทำต่อได้)
        แบบเดียวกับ _schedule_self_reload / _ask_when_free แต่ไม่มีเพดาน: ฝืนทำตอนกล่องยังเปิด = ดับ · เลิกรอ = ชั้นค้าง CRS/สถานะเก่า
        (ผู้ใช้เปิดกล่องค้างไว้นานแค่ไหนก็รอ — ตรวจแค่ 2 ค่าทุก 200 มิลลิวินาที) · unload ⇒ _alive = False ⇒ รอบถัดไปจบที่ด่าน _alive
        ของผู้เรียก (ไม่ตั้งเวลาต่อ · ไม่แตะเลเยอร์) — ตัวจับเวลาไม่ค้างทำงานกับ instance ที่ตายแล้ว
        · เพิ่งเห็นกล่องเปิดอยู่ในรอบก่อน แล้วรอบนี้ว่าง ⇒ รออีก 1 รอบของ event loop (ตั้งเวลา 0) ค่อยทำ:
          ตัวจัดคิวแบบ glib/UNIX (Linux) ยิงตัวจับเวลาที่ถึงเวลาแล้วต่อในรอบเดียวกับที่กล่องเพิ่งปิด ทั้งที่ exec() ของกล่องยังไม่คืน
          (โค้ดที่เปิดกล่อง เช่นลูปใน QgisApp::projectCrsChanged ยังถือ pointer ของเลเยอร์อยู่บน stack) · ตัวจับเวลาที่ตั้งระหว่างรอบ
          จะยิงได้รอบถัดไปเท่านั้น = หลังโค้ดนั้นทำงานจบ หรืออยู่ในกล่องใบใหม่ (ซึ่งด่านนี้เห็นว่าไม่ว่างอีก) · Windows ไม่มีช่องนี้
          (ตัวจัดคิว Win32 หยุดรอบทันทีที่ปิดกล่อง) แต่กันไว้ให้เหมือนกันทุกระบบ"""
        seen = getattr(self, "_line_busy_seen", None)
        if seen is None:
            seen = self._line_busy_seen = set()
        key = getattr(fn, "__name__", None) or repr(fn)
        busy = self._line_ui_busy()
        if not busy and key not in seen:
            return False
        if busy:
            seen.add(key)
        else:
            seen.discard(key)          # ว่างแล้ว แต่ให้โค้ดที่เพิ่งปิดกล่องคืนตัวก่อน 1 รอบ
        try:
            QtCore.QTimer.singleShot(self.LINE_BUSY_RETRY_MS if busy else 0, fn)
        except Exception as e:
            # ตั้งเวลาไม่ได้ (ไม่ควรเกิด) ⇒ ไม่ฝืนทำตอนกล่องเปิด · ชั้นเส้นถูกเขียนใหม่ในการคลิก/ปุ่มครั้งถัดไป (_line_sync_layer)
            QgsMessageLog.logMessage("_line_wait_free: ตั้งเวลารอกล่องปิดไม่ได้ — ข้ามงานชั้นเส้นรอบนี้ (%s)" % e,
                                     "MLEP", Qgis.Warning)
        return True

    def _line_after_crs_change(self):
        """★ 2.3.7 (DI-40) — เลื่อนออกจากสัญญาณ: สร้างชั้นเส้นใหม่ใน CRS ใหม่ + อัปเดตตาราง
        ไม่ทำระหว่างโหลด/บันทึกโปรเจกต์ (เพิ่ม/ถอดเลเยอร์ตอนนั้น = QGIS ดับ ดู _on_project_reset) — ทางนั้น
        _line_after_project_load / _on_project_saved เรียก _line_sync_layer ให้เองเมื่อเสร็จ
        ★ 2.3.7 rc3 (Windows audit 🔴1) — และไม่ทำระหว่างมีกล่อง modal/เมนูเปิด (เลื่อนไปจนปิด · _line_wait_free):
        ตัวจับเวลา 0 มิลลิวินาทีนี้เคยไปทำงานในลูปของกล่อง "Select Transformation" ที่ QgisApp::projectCrsChanged เปิดค้าง
        ⇒ ถอดชั้นเส้นทิ้งขณะ QGIS ยังถือ pointer ของมัน ⇒ ปิดกล่องแล้ว QGIS ดับ (access violation · QgsMapLayer::crs)
        ระหว่างรอ ชั้นเส้นเดิมยังอยู่ครบ (พิกัด CRS เดิม + CRS เดิม ⇒ QGIS ฉายมาแสดงถูกที่) · จุดของเส้นแปลงไปแล้วตั้งแต่ในสัญญาณ"""
        if not getattr(self, "_alive", True):
            return
        if self._line_wait_free(self._line_after_crs_change):
            return
        self._line_crs_pending = False
        if getattr(self, "_line_switching", False) or getattr(self, "_line_in_save", False):
            return
        try:
            self._line_refresh()
        except Exception as e:
            QgsMessageLog.logMessage("_line_after_crs_change: %s" % e, "MLEP", Qgis.Warning)

    def _line_crs_ok(self):
        """★ 2.3.7 (review DI-40) — ด่านของเส้นขนาน: จุดของเส้นต้องอยู่ใน CRS เดียวกับแผนที่
        (ปกติแปลงตามทันทีที่ CRS เปลี่ยน · ไม่ตรง = สัญญาณหลุด ⇒ ลองแปลงตามก่อน ยังไม่ตรงค่อยปฏิเสธพร้อมบอก)"""
        try:
            cc = self.iface.mapCanvas().mapSettings().destinationCrs()
        except Exception:
            return True
        lc = getattr(self, "_line_crs", None)
        if lc is not None and lc.isValid() and lc != cc:
            self._line_on_crs_changed()
            lc = getattr(self, "_line_crs", None)
        if lc is None or not lc.isValid() or lc == cc:
            return True
        self._ask(QtWidgets.QMessageBox.Warning, "เส้นขนาน",
                  "เส้นที่วัดไว้อยู่คนละระบบพิกัดกับแผนที่ (%s · แผนที่ %s) จึงทำเส้นขนานไม่ได้\n"
                  "กด 🧹 ล้างเส้นแล้ววาดใหม่" % (lc.authid(), cc.authid()))
        return False

    def _line_layer_shown(self):
        """★ 2.3.7 (review UX-49) — ชั้นเส้นของเรามีอยู่ในโปรเจกต์และติ๊กแสดงอยู่ (รวมกลุ่มแม่) ไหม
        ไม่ใช่ ⇒ LineMeasureItem วาดเส้นที่จบแล้วเอง · ถูกเรียกตอนวาดภาพ: อ่านอย่างเดียว ห้ามโยน exception"""
        if not getattr(self, "_alive", True):
            return False
        lid = getattr(self, "_line_layer_id", None)
        if not lid:
            return False
        try:
            prj = QgsProject.instance()
            if prj.mapLayer(lid) is None:
                return False
            node = prj.layerTreeRoot().findLayer(lid)
            return bool(node is not None and node.isVisible())
        except Exception:
            return False

    def _line_sync_layer(self):
        """เขียนเส้นที่วาดเสร็จแล้วลงชั้นจริง (แหล่งความจริงยังเป็น _line_item.lines)"""
        it = getattr(self, "_line_item", None)
        if it is None:
            return
        # ★★ 2 ก.ย. 69 (blocker จาก audit) — เกราะชั้นสองกัน "ชั้นผีฟื้นคืนชีพ"
        #   ต้นตอจริงคือ self.temp_tool ค้าง (แก้ที่ _line_set_drawing แล้ว) แต่ทางนี้
        #   ถูกเรียกจากหลายที่มาก (_line_refresh · Show event · ปุ่มบนหน้าต่าง · DrawLineTool
        #   ยิง _on_change ทุกคลิก) ⇒ กันไว้อีกชั้นให้ครบทุกทาง
        #   ปิดหน้าต่างแล้ว = ไม่ควรมีชั้นนี้ในโปรเจกต์อีกเลย ไม่ว่าใครจะเรียกมาทางไหน
        if not self._line_window_open():
            try:
                self._line_layer_drop()
            except Exception:
                _log_exc("_line_sync_layer: ถอดชั้นเส้น/จุดวัดระยะหลังปิดหน้าต่างไม่สำเร็จ",
                         once_key="ER-09:sync-drop")                        # ★ 2.4.0 (review ER-09)
            return
        # ★ ไม่ใช่แค่ตอนเพิ่มชั้น — การเพิ่ม/ลบฟีเจอร์ในชั้นก็ทำให้โปรเจกต์เป็น "มีการแก้ไข" ด้วย
        #   ต้องจำค่าเดิมแล้วคืนท้ายสุด ไม่งั้นพนักงานจะโดนถามว่าจะบันทึกโปรเจกต์ไหมตอนปิด QGIS
        # ★ 2.3.6 — จุดที่กรอกพิกัด (ทำก่อน เพราะขาเส้นข้างล่างมี return กลางทางหลายจุด)
        try:
            self._line_sync_points()
        except Exception as e:
            QgsMessageLog.logMessage(
                "_line_sync_points: เขียนชั้นจุดที่กรอกพิกัดล้ม — %s" % e, "MLEP", Qgis.Warning)
        prj0 = QgsProject.instance()
        was_dirty = prj0.isDirty()
        if not it.lines:
            self._line_drop_one("_line_layer_id")    # ★ 2.3.6 — เฉพาะชั้นเส้น (ชั้นจุดดูแลแยก)
            if not was_dirty:
                prj0.setDirty(False)
            return
        # ★ 2.3.7 (review DI-40) — ชั้นเดิมอยู่คนละ CRS กับจุดของเส้น (CRS แผนที่เปลี่ยนไปแล้ว) ⇒ ทิ้งแล้วสร้างใหม่
        _old = self._line_layer_get(create=False)
        _lc = getattr(self, "_line_crs", None)
        if _old is not None and _lc is not None and _lc.isValid() and _old.crs() != _lc:
            self._line_drop_one("_line_layer_id")
        lyr = self._line_layer_get()
        if lyr is None:
            if not was_dirty:
                prj0.setDirty(False)
            return
        try:
            # ปลดอ่านอย่างเดียวชั่วคราวเฉพาะตอนที่ "เรา" เขียนเอง แล้วล็อกคืนทันที
            try:
                lyr.setReadOnly(False)
            except Exception:
                pass
            dp = lyr.dataProvider()
            ids = [f.id() for f in lyr.getFeatures()]
            if ids:
                dp.deleteFeatures(ids)
            feats = []
            for pts in it.lines:
                if len(pts) < 2:
                    continue
                f = QgsFeature(lyr.fields())
                f.setGeometry(QgsGeometry.fromPolylineXY(list(pts)))
                try:
                    f.setAttribute("ระยะ_ม", round(it.line_len(pts), 3))
                except Exception:
                    pass
                feats.append(f)
            dp.addFeatures(feats)
            lyr.updateExtents()
            lyr.triggerRepaint()
            # 🔴🔴 8 ก.ย. 69 — เจ้าของงานทำซ้ำได้: "เส้นที่วาดใหม่ Move Node เข้าไปแล้วไม่เกาะ
            #   แต่เส้นรอบก่อนเกาะได้ · ปิด-เปิดหน้าต่างวาดเส้นแล้วเกาะได้หมด · วาดใหม่ก็ไม่เกาะอีก"
            #
            #   เหตุ: ตรงนี้เขียนผ่าน `dataProvider()` ตรง ๆ ซึ่ง **ไม่ยิงสัญญาณระดับเลเยอร์**
            #   (featureAdded / geometryChanged / featuresDeleted / dataChanged)
            #   แต่ `QgsPointLocator` — ตัวทำดัชนี snap — ล้างดัชนีตัวเองจากสัญญาณพวกนั้นเท่านั้น
            #   `triggerRepaint()` ทำให้ **เห็นเส้นบนจอ** แต่ไม่แตะดัชนี
            #   ⇒ เส้นใหม่อยู่บนจอ แต่ **ไม่อยู่ในดัชนี snap** = เกาะไม่ได้
            #   ⇒ ปิด-เปิดหน้าต่าง = ชั้นถูกลบแล้วสร้างใหม่ (id ใหม่) = ดัชนีใหม่ ⇒ เกาะได้ชั่วคราว
            #      แล้วพอวาดเพิ่มก็กลับมาเป็นเหมือนเดิม (ตรงกับที่เจ้าของงานเจอเป๊ะ)
            #
            #   ยิง dataChanged เองหลังเขียนเสร็จ = บอกให้ทิ้งดัชนีเก่า (ทดสอบแล้ว `MLEP_test/sim32.py`)
            #   ★ ตรวจแล้วว่า **ไม่ทำให้โปรเจกต์กลายเป็น "มีการแก้ไข"** ทั้งทันทีและหลัง event loop
            #     (สำคัญมาก — ถ้า dirty พนักงานจะโดนถาม "บันทึกไหม" แล้วเสี่ยงเซฟทับไฟล์กลาง
            #      ซึ่งเกิดขึ้นจริงกับคลองหลวง/ลำลูกกา เมื่อ 7 ก.ย.)
            try:
                lyr.dataChanged.emit()
            except Exception:
                try:
                    lyr.reload()          # ทางถอย: reload() ยิง dataChanged ให้เอง
                except Exception:
                    pass
        except Exception as e:
            # ★ 2.3.0 — เดิมกลืนเงียบ (ตกลงกันไว้ตั้งแต่ 2.2.9 ว่ารอรุ่นหน้า)
            #   ชั้นนี้เป็นชั้นเส้นวัดของเราเอง ไม่ใช่ข้อมูลจริง จึงไม่ควรเด้งกล่องรบกวนผู้ใช้
            #   แต่ต้องตามเรื่องย้อนหลังได้ว่า "เส้นที่วาดไม่ขึ้น" เกิดจากอะไร
            QgsMessageLog.logMessage(
                "_line_sync_layer: เขียนชั้นเส้นวัดล้ม — %s" % e, "MLEP", Qgis.Warning)
        try:
            lyr.setReadOnly(True)
        except Exception:
            pass
        if not was_dirty:
            try:
                prj0.setDirty(False)
            except Exception:
                _log_exc("_line_sync_layer: ปลดธง 'มีการแก้ไข' ไม่สำเร็จ", once_key="ER-09:undirty")   # ★ 2.4.0 (ER-09)

    # ---------- ★ 2.3.6 ขึ้นจุดจากพิกัด ----------
    def _line_coord_crs(self):
        """CRS ของค่า E/N ที่กรอก = CRS ของชั้นแปลงที่เลือกในหน้าต่างหลัก (ฐานเก็บเป็น EPSG:24047)
        ไม่มีชั้นแปลง -> ใช้ CRS ของแผนที่ · ต้องเป็นระบบพิกัดฉากหน่วยเมตร ไม่งั้นคืน None"""
        crs = None
        try:
            cb = getattr(self, "poly_cb", None)
            lyr = QgsProject.instance().mapLayer(cb.currentData()) if cb is not None else None
            if lyr is not None and lyr.crs().isValid():
                crs = QgsCoordinateReferenceSystem(lyr.crs())
        except Exception:
            crs = None
        if crs is None:
            try:
                crs = QgsCoordinateReferenceSystem(self.iface.mapCanvas().mapSettings().destinationCrs())
            except Exception:
                crs = None
        try:
            if crs is None or not crs.isValid() or crs.isGeographic() \
                    or crs.mapUnits() != QgsUnitTypes.DistanceMeters:
                return None
        except Exception:
            return None
        return crs

    def _line_pt_update_hint(self):
        lbl = getattr(self, "_line_pt_hint", None)
        if lbl is None:
            return
        crs = self._line_coord_crs()
        try:
            cb = getattr(self, "poly_cb", None)
            _pl = QgsProject.instance().mapLayer(cb.currentData()) if cb is not None else None
            ที่มา = "ชั้นแปลงที่เลือก" if (_pl is not None and crs is not None and _pl.crs() == crs) else "แผนที่"
        except Exception:
            ที่มา = "แผนที่"
        lbl.setText("พิกัดตามระบบของ%s (%s) · จุด snap ได้ · อยู่นอกจอจะเลื่อนแผนที่ไปให้"
                    % (ที่มา, (crs.authid() or crs.description()) if crs is not None else "ยังไม่มีระบบพิกัดเมตร"))

    @staticmethod
    def _coord_single(t):
        """★ 2.3.7 b13 — ข้อความในช่องเป็น "ตัวเลขค่าเดียว" ไหม (มีป้าย N=/E: นำหน้าได้ · จุลภาคหลักพันที่ถูกตำแหน่งได้ เช่น 1,559,486.83)
        แยก "กรอกค่าเดียว ยังขาดอีกช่อง" ออกจาก "วางคู่ค่าลงช่องเดียว" ("711180,1559486" = คู่ค่า ไม่ใช่ค่าเดียว)"""
        t2 = re.sub(r"^\s*[ENen]\s*[=:]?\s*", "", t or "").strip()
        return re.fullmatch(r"[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?", t2) is not None

    def _line_pt_n_enter(self):
        """★ 2.3.7 b13 — Enter ในช่อง N (ช่องแรก): กรอกค่าเดียวแล้วช่อง E ยังว่าง ⇒ ไปช่อง E (ยังไม่สร้าง · ไม่ขึ้นข้อความผิด)
        วางคู่ค่าไว้ / กรอกครบสองช่อง ⇒ สร้างจุดเหมือนกด 📍"""
        n_le, e_le = getattr(self, "_line_pt_n", None), getattr(self, "_line_pt_e", None)
        if n_le is None or e_le is None:
            return
        if not (e_le.text() or "").strip() and self._coord_single(n_le.text()):
            e_le.setFocus()
            e_le.selectAll()
            return
        self._line_add_coord_point()

    @staticmethod
    def _parse_coord_text(e_txt, n_txt):
        """ข้อความที่กรอก -> (E, N) เป็น float · ผิดรูปแบบ/นอกช่วง = โยน ValueError พร้อมเหตุภาษาไทย

        รับได้: ช่องละค่า (มีจุลภาคหลักพันได้ เช่น 711,180.810)
                หรือวางคู่ค่าลงช่องใดช่องหนึ่งแล้วเว้นอีกช่องว่าง ("1559486.83 711180.81" · "711180.81 1559486.83" ·
                "711180.81,1559486.83" · "N=1559486.83 E=711180.81" · คั่นด้วยแท็บจาก Excel)
        ★ 2.3.7 b13 (เจ้าของงานสั่ง 3 ต.ค. 69) — หน้าต่างเรียงช่อง N ก่อน E แล้ว · คู่ค่าแยก N/E ตาม "ขนาดตัวเลข"
          ไม่ใช่ตามลำดับหรือช่องที่วาง (ประเทศไทย UTM: N > 900,000 · E 100,000-900,000) ⇒ "N E" และ "E N" ได้ผลเดียวกัน
          แยกไม่ได้ (ทั้งคู่ไม่เกิน / ทั้งคู่เกิน 900,000) ⇒ ให้กรอกทีละช่อง ไม่เดา
        ตรวจช่วงแบบ UTM (E 100,000-900,000 · N 100,000-10,000,000) และจับกรณีกรอก N/E สลับช่องกัน
        คืน (E, N) ลำดับเดิม
        """
        # ★ audit รอบ 2 — ช่องว่างที่มองไม่เห็น (nbsp/zero-width) ติดมากับการคัดลอกจากเว็บ/เอกสาร
        _ล่องหน = {"\u00a0": " ", "\u202f": " ", "\u2007": " ", "\u200b": "", "\u200c": "", "\u200d": "", "\ufeff": ""}
        for _k, _v in _ล่องหน.items():
            e_txt = (e_txt or "").replace(_k, _v)
            n_txt = (n_txt or "").replace(_k, _v)
        e_txt = (e_txt or "").strip()
        n_txt = (n_txt or "").strip()

        def one(t, lab):
            t = re.sub(r"^\s*[ENen]\s*[=:]?\s*", "", t).replace(",", "").replace(" ", "")
            if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", t):
                raise ValueError("ค่า %s \"%s\" ไม่ใช่ตัวเลข" % (lab, t))
            return float(t)

        if bool(e_txt) != bool(n_txt):          # มีค่าช่องเดียว: ค่าเดียว (ยังขาดอีกช่อง) หรือวางคู่ค่าลงช่องนั้น
            t = e_txt or n_txt
            if MultiLayerEditPro._coord_single(t):
                raise ValueError("กรอกค่า %s ด้วย (หรือวางคู่ค่า N E ลงช่องเดียว)" % ("N" if e_txt else "E"))
            nums = re.findall(r"[+-]?\d+(?:\.\d+)?", t)
            if len(nums) != 2:
                raise ValueError("แยกค่า N / E ไม่ออก — กรอกทีละช่อง (ไม่ต้องใส่จุลภาคหลักพัน)")
            a, b = float(nums[0]), float(nums[1])
            if "," in t and min(a, b) < 100000.0:
                raise ValueError("แยกค่า N / E ไม่ออก — ถ้ามีจุลภาคหลักพัน ให้กรอก N กับ E ทีละช่อง")
            # ★ 2.3.7 b13 — แยกตามขนาด: ค่าเดียวที่เกิน 900,000 = N (E ของประเทศไทยไม่เกิน 900,000) · ลำดับที่วางไม่มีผล
            if (a > 900000.0) == (b > 900000.0):
                raise ValueError("แยกค่า N / E จากขนาดตัวเลขไม่ได้ (N ต้องเกิน 900,000 · E อยู่ 100,000-900,000) "
                                 "— กรอก N และ E ทีละช่อง")
            n, e = (a, b) if a > 900000.0 else (b, a)
        elif not e_txt:
            raise ValueError("กรอกค่า N และ E ก่อน")
        else:
            e, n = one(e_txt, "E"), one(n_txt, "N")
        if e > 900000.0 and 100000.0 <= n <= 900000.0:          # ★ 2.3.7 b13 — ถ้อยคำตามลำดับช่องใหม่ (N ก่อน E)
            raise ValueError("ค่า N / E น่าจะสลับช่องกัน — N ราว 100,000-10,000,000 · E ราว 100,000-900,000 "
                             "(ค่าที่เกิน 900,000 ต้องอยู่ช่อง N)")
        if not (100000.0 <= e <= 900000.0):
            raise ValueError("ค่า E %.3f อยู่นอกช่วงพิกัด UTM (100,000-900,000)" % e)
        # ★ audit รอบ 2 — ขั้นต่ำ 100,000 (เดิม 0): "711180,5" เคยผ่านเป็น N=5 แล้วแผนที่กระโดดไปเส้นศูนย์สูตร
        #   ประเทศไทยอยู่ราว N 620,000 - 2,300,000 · ขั้นต่ำนี้กันเลขหลุดหลักแบบรุนแรงเท่านั้น
        #   (ตัวหลุดหลักที่ยังอยู่ในช่วง จับด้วยด่าน "ห่างจากแผนที่ที่เปิดอยู่" ตอนขึ้นจุด)
        if not (100000.0 <= n <= 10000000.0):
            raise ValueError("ค่า N %.3f อยู่นอกช่วงพิกัด UTM (100,000-10,000,000)" % n)
        return e, n

    def _line_add_coord_point(self):
        """★ 2.3.6 — ปุ่ม 📍 สร้างจุด: กรอก N/E แล้วสร้างจุดบนแผนที่ (snap ได้ · ไม่แตะข้อมูลในฐาน) · ★ 2.3.7 b13 ช่อง N ก่อน E"""
        title = "สร้างจุดจากค่าพิกัด"
        if getattr(self, "_line_pt_e", None) is None:
            return
        try:
            e, n = self._parse_coord_text(self._line_pt_e.text(), self._line_pt_n.text())
        except ValueError as ex:
            self.iface.messageBar().pushMessage(title, str(ex), level=1, duration=6)
            try:                           # ★ 2.3.7 b13 — พาไปช่องที่ต้องกรอกต่อ (N ก่อน E)
                if not (self._line_pt_n.text() or "").strip():
                    self._line_pt_n.setFocus()
                elif not (self._line_pt_e.text() or "").strip() and self._coord_single(self._line_pt_n.text()):
                    self._line_pt_e.setFocus()
            except Exception:
                pass
            return
        crs = self._line_coord_crs()
        if crs is None:
            self._ask(QtWidgets.QMessageBox.Warning, title,
                      "ระบบพิกัดของชั้นแปลง/แผนที่ไม่ใช่หน่วยเมตร จึงสร้างจุดจากค่า N / E ไม่ได้\n\n"
                      "ตั้ง CRS ของโปรเจกต์เป็น EPSG:24047 ก่อน (Project > Properties > CRS) แล้วลองใหม่")
            return
        pts = getattr(self, "_line_pts", None)
        if pts is None:
            pts = self._line_pts = []
        # กดซ้ำ/Enter ซ้ำ = ไม่ขึ้นจุดซ้อนที่เดิม (ห่างกันไม่เกิน 1 มม. ในระบบพิกัดเดียวกัน)
        for p in pts:
            if p["crs"] == crs and abs(p["e"] - e) <= 0.001 and abs(p["n"] - n) <= 0.001:
                self.iface.messageBar().pushMessage(
                    title, "มีจุด %s ที่พิกัดนี้อยู่แล้ว" % p["name"], level=1, duration=5)
                return
        # ★ audit รอบ 2 — N หลักหาย (155948 แทน 1559486) ยังอยู่ในช่วง UTM แต่แผนที่กระโดดไป ~1,400 กม.
        #   ⇒ ห่างจากกลางแผนที่ที่เปิดอยู่เกิน 20 กม. ให้ถามก่อน (วัดในระบบพิกัดของค่าที่กรอก = เมตร)
        try:
            _cv = self.iface.mapCanvas()
            _c = QgsPointXY(_cv.extent().center())
            _dc = _cv.mapSettings().destinationCrs()
            if _dc != crs:
                _c = QgsCoordinateTransform(_dc, crs, QgsProject.instance()).transform(_c)
            _ไกล = math.hypot(_c.x() - e, _c.y() - n)
        except Exception:
            _ไกล = 0.0
        # audit รอบ 3 — ปุ่มตั้งต้น "ไม่": กล่องนี้มาจากการกด Enter ในช่องกรอก ถ้า Enter ซ้ำจะรับค่าที่พิมพ์ผิดทันที
        if _ไกล > 20000.0 and self._ask(
                QtWidgets.QMessageBox.Question, title,
                "จุดนี้อยู่ห่างจากแผนที่ที่เปิดอยู่ %.1f กม.\nพิมพ์ค่าถูกหรือเปล่า (เช่น ตัวเลขหายไป 1 หลัก)?\n\n"
                "สร้างจุดต่อไหม?" % (_ไกล / 1000.0),
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return
        name = (self._line_pt_name.text() or "").strip()[:40]
        if not name:
            self._line_pt_seq = getattr(self, "_line_pt_seq", 0) + 1
            name = "P%d" % self._line_pt_seq
        pts.append({"name": name, "e": e, "n": n, "crs": crs})
        self._line_pts_ver = getattr(self, "_line_pts_ver", 0) + 1
        self._line_sync_layer()
        self._line_pt_refresh_list()
        # อยู่นอกจอ -> เลื่อนแผนที่ไปให้เห็น (ไม่เปลี่ยนมาตราส่วน)
        try:
            canvas = self.iface.mapCanvas()
            dcrs = canvas.mapSettings().destinationCrs()
            q = QgsPointXY(e, n)
            if dcrs != crs:
                q = QgsCoordinateTransform(crs, dcrs, QgsProject.instance()).transform(q)
            if not canvas.extent().contains(q):
                canvas.setCenter(q)
            canvas.refresh()
        except Exception:
            pass
        for _le in (self._line_pt_e, self._line_pt_n, self._line_pt_name):
            _le.clear()
        self._line_pt_n.setFocus()                   # ★ 2.3.7 b13 — กลับไปช่องแรก (N)
        self.iface.messageBar().pushMessage(
            title, "สร้างจุด %s ที่ N %.3f · E %.3f แล้ว — snap ได้ · ไม่แตะข้อมูลในฐาน" % (name, n, e),
            level=0, duration=5)

    def _line_pt_refresh_list(self):
        lw = getattr(self, "_line_pt_list", None)
        if lw is None:
            return
        lw.clear()
        for i, p in enumerate(getattr(self, "_line_pts", None) or []):
            item = QtWidgets.QListWidgetItem("%s    N %.3f    E %.3f" % (p["name"], p["n"], p["e"]))   # ★ 2.3.7 b13 N ก่อน E
            item.setData(QtCore.Qt.UserRole, i)
            lw.addItem(item)
        self._line_pt_update_hint()

    def _line_pt_delete_selected(self):
        lw = getattr(self, "_line_pt_list", None)
        pts = getattr(self, "_line_pts", None) or []
        if lw is None:
            return
        idx = sorted({int(x.data(QtCore.Qt.UserRole)) for x in lw.selectedItems()}, reverse=True)
        if not idx:
            self.iface.messageBar().pushMessage("สร้างจุดจากค่าพิกัด", "เลือกจุดในรายการก่อน", level=1, duration=4)
            return
        for i in idx:
            if 0 <= i < len(pts):
                del pts[i]
        self._line_pts_ver = getattr(self, "_line_pts_ver", 0) + 1
        self._line_sync_layer()
        self._line_pt_refresh_list()

    def _line_pt_clear(self):
        self._line_pts = []
        self._line_pt_seq = 0
        self._line_pts_ver = getattr(self, "_line_pts_ver", 0) + 1
        self._line_sync_layer()
        self._line_pt_refresh_list()

    def _line_pt_layer_get(self, create=True):
        """ชั้นจุดชั่วคราวของ "จุดที่กรอกพิกัด" — กันชนแบบเดียวกับ _line_layer_get ทุกข้อ"""
        prj = QgsProject.instance()
        lid = getattr(self, "_line_pt_layer_id", None)
        if lid:
            lyr = prj.mapLayer(lid)
            if lyr is not None:
                return lyr
            self._line_pt_layer_id = None
        if not create:
            return None
        try:
            # 🔑 สร้างชั้นใน "ระบบพิกัดของค่าที่กรอก" (ปกติ EPSG:24047) ไม่ใช่ระบบของแผนที่แบบชั้นเส้น
            #    ⇒ พิกัดในชั้น = ตัวเลขที่พิมพ์เป๊ะ ไม่ผ่านการแปลงพิกัดเลย
            #    (วัดแล้ว 25 ก.ย.: 24047 -> 4326 -> 24047 ไป-กลับคลาด 1.4 มม. ใน PROJ เอง
            #     ถ้าเก็บในระบบของแผนที่ที่เป็นองศา จุดจะคลาดจากค่าที่กรอกตั้งแต่ต้น)
            pts = getattr(self, "_line_pts", None) or []
            c0 = pts[0]["crs"] if pts else self.iface.mapCanvas().mapSettings().destinationCrs()
            crs = c0.authid() or "EPSG:24047"
            lyr = QgsVectorLayer("Point?crs=%s&field=ชื่อ:string(40)&field=E:double&field=N:double" % crs,
                                 self.LINE_PT_LAYER_NAME, "memory")
            if not lyr.isValid():
                QgsMessageLog.logMessage("_line_pt_layer_get: สร้างชั้นจุดที่กรอกพิกัดไม่สำเร็จ (ชั้นไม่ valid · CRS %s)"
                                         % crs, "MLEP", Qgis.Warning)       # ★ 2.3.7 (UX-49)
                return None
            try:
                lyr.setCustomProperty("skipMemoryLayersCheck", 1)   # ไม่เด้งกล่องเตือน scratch layer
            except Exception:
                _log_exc("_line_pt_layer_get: ตั้ง skipMemoryLayersCheck ไม่สำเร็จ", once_key="ER-09:skipmem")  # ★ ER-09
            try:
                lyr.setReadOnly(True)        # ปลั๊กอินเขียนทับทุกครั้ง ห้ามผู้ใช้เผลอแก้เอง
            except Exception:
                pass
            # ★ 2.3.6 (1 ต.ค. 69 เจ้าของงานสั่ง) — หน้าตาเหมือน "จุดหัก" ของเส้นที่วาด
            #   วงกลมทึบสีเดียวกับเส้น ขอบขาว 1 px · กว้าง 7 px (= LineMeasureItem วาด drawEllipse รัศมี 3.5 px)
            #   ไม่มีป้ายชื่อแล้ว (ไม่ต้องตั้งชื่อ · ชื่อ P1, P2 … มีแค่ในรายการ/ข้อความคัดลอก)
            try:
                from qgis.core import QgsMarkerSymbol
                from ..map_tools import LineMeasureItem
                _c = LineMeasureItem.C_LINE
                lyr.renderer().setSymbol(QgsMarkerSymbol.createSimple({
                    "name": "circle", "color": "%d,%d,%d" % (_c.red(), _c.green(), _c.blue()),
                    "outline_color": "255,255,255", "outline_style": "solid",
                    "outline_width": "1", "outline_width_unit": "Pixel",
                    "size": "7", "size_unit": "Pixel"}))
            except Exception:
                pass
            was = prj.isDirty()
            self._line_add_own_layer(prj, lyr)
            if not was:
                prj.setDirty(False)
                try:
                    QtCore.QTimer.singleShot(0, self._line_undirty)   # ★ เหตุผลเดียวกับชั้นเส้น (3 ก.ย.)
                except Exception:
                    _log_exc("_line_pt_layer_get: ตั้งเวลาปลดธง 'มีการแก้ไข' ไม่สำเร็จ",
                             once_key="ER-09:undirty-timer")                # ★ 2.4.0 (review ER-09)
            self._line_pt_layer_id = lyr.id()
            return lyr
        except Exception as e:
            QgsMessageLog.logMessage("_line_pt_layer_get: สร้างชั้นจุดที่กรอกพิกัดล้ม — %s" % e, "MLEP",
                                     Qgis.Warning)                          # ★ 2.3.7 (UX-49)
            return None

    @staticmethod
    def _line_pt_labels(lyr):
        """ป้ายชื่อจุด — ให้ QGIS วาดเองจากชั้น (ไม่ใช้ไอเทมบนแคนวาส ที่เคยมีปัญหาไม่โผล่หลังเปิดหน้าต่างใหม่)"""
        from qgis.core import (QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                               QgsVectorLayerSimpleLabeling)
        s = QgsPalLayerSettings()
        s.fieldName = "ชื่อ"
        s.enabled = True
        fmt = QgsTextFormat()
        fmt.setSize(10)
        fmt.setColor(QtGui.QColor(183, 28, 28))
        buf = QgsTextBufferSettings()
        buf.setEnabled(True)
        buf.setSize(1.0)
        buf.setColor(QtGui.QColor(255, 255, 255))
        fmt.setBuffer(buf)
        s.setFormat(fmt)
        try:
            s.placement = Qgis.LabelPlacement.AroundPoint
        except Exception:
            s.placement = QgsPalLayerSettings.AroundPoint
        s.dist = 1.5
        lyr.setLabeling(QgsVectorLayerSimpleLabeling(s))
        lyr.setLabelsEnabled(True)

    def _line_sync_points(self):
        """เขียนจุดที่กรอกพิกัดลงชั้นจุดชั่วคราว (แหล่งความจริง = self._line_pts)
        ผู้เรียก (_line_sync_layer) ผ่านด่าน "หน้าต่างเปิดอยู่" มาแล้ว
        🔑 เก็บพิกัดตามที่กรอก + ระบบพิกัดของมัน แล้วค่อยแปลงเป็นระบบของชั้นตอนเขียน
           (ชั้นถูกสร้างใหม่ได้หลายรอบ เช่นหลังบันทึกโปรเจกต์ — ระบบพิกัดแผนที่อาจเปลี่ยนไปแล้ว)
        🔑 เขียนใหม่เฉพาะเมื่อรายการจุดเปลี่ยน หรือชั้นถูกสร้างใหม่ — ฟังก์ชันนี้ถูกเรียกทุกคลิกวาดเส้น
           ถ้าเขียนทุกครั้ง ดัชนี snap ของชั้นจุดจะถูกล้างทิ้งทุกคลิกโดยไม่จำเป็น"""
        pts = getattr(self, "_line_pts", None) or []
        prj0 = QgsProject.instance()
        was_dirty = prj0.isDirty()
        try:
            if not pts:
                self._line_drop_one("_line_pt_layer_id")
                self._line_pt_synced = None
                return
            lyr = self._line_pt_layer_get()
            if lyr is None:
                return
            key = (lyr.id(), getattr(self, "_line_pts_ver", 0))
            if getattr(self, "_line_pt_synced", None) == key:
                return
            try:
                lyr.setReadOnly(False)
            except Exception:
                pass
            try:
                dp = lyr.dataProvider()
                ids = [f.id() for f in lyr.getFeatures()]
                if ids:
                    dp.deleteFeatures(ids)
                feats = []
                for p in pts:
                    q = QgsPointXY(p["e"], p["n"])
                    if p["crs"] != lyr.crs():
                        q = QgsCoordinateTransform(p["crs"], lyr.crs(), prj0).transform(q)
                    f = QgsFeature(lyr.fields())
                    f.setGeometry(QgsGeometry.fromPointXY(q))
                    f.setAttribute("ชื่อ", p["name"])
                    f.setAttribute("E", float(p["e"]))
                    f.setAttribute("N", float(p["n"]))
                    feats.append(f)
                dp.addFeatures(feats)
                lyr.updateExtents()
                lyr.triggerRepaint()
                # ★ บทเรียน 8 ก.ย. (sim32): เขียนผ่าน dataProvider ไม่ยิงสัญญาณระดับเลเยอร์
                #   ⇒ ดัชนี snap ไม่รู้ว่ามีจุดใหม่ = เห็นจุดแต่เกาะไม่ได้ ⇒ ยิง dataChanged เอง
                try:
                    lyr.dataChanged.emit()
                except Exception:
                    try:
                        lyr.reload()
                    except Exception:
                        pass
                self._line_pt_synced = key
            finally:
                try:
                    lyr.setReadOnly(True)
                except Exception:
                    pass
        finally:
            if not was_dirty:
                try:
                    prj0.setDirty(False)
                except Exception:
                    _log_exc("_line_sync_points: ปลดธง 'มีการแก้ไข' ไม่สำเร็จ", once_key="ER-09:undirty")  # ★ 2.4.0 (ER-09)

    def _line_refresh(self):
        self._line_sync_layer()
        it = getattr(self, "_line_item", None)
        tree = getattr(self, "_line_tree", None)
        # ★ 2.3.7 (review UX-37) — เริ่มเส้นใหม่หลังกด 🧹 แล้ว ⇒ ทิ้งสำเนาที่ไว้เรียกคืน (↺ ถอยแค่เส้นใหม่)
        if it is not None and (it.lines or it.temp):
            self._line_clear_undo = None
        if it is None or tree is None:
            return
        # ★ 2.3.7 (review UX-17 เฉพาะส่วนนี้) — จำว่าเส้นไหนกาง/หุบไว้ (เดิมรีเฟรชทุกคลิก แล้วกาง/หุบใหม่ตามจำนวนเส้นหมด)
        #   ค่าตั้งต้น (≤ 3 เส้น = กาง) ใช้กับเส้นที่เพิ่งเพิ่มเท่านั้น
        _exp = {}
        try:
            for _k in range(tree.topLevelItemCount()):
                _t = tree.topLevelItem(_k)
                _v = _t.data(0, QtCore.Qt.UserRole)
                if _v is not None:
                    _exp[int(_v)] = _t.isExpanded()
        except Exception:
            _exp = {}
        # ★ 2.3.7 b13 (review UX-17) — จำแถวที่เลือกไว้ (= เส้นต้นทางของเส้นขนาน) ข้ามการรีเฟรช (เดิม tree.clear() ทิ้งทุกคลิก
        #   ⇒ ◀ แล้ว ▶ ไปทำจากเส้นที่เพิ่งได้ ไม่ใช่เส้นเดิม) · ที่เลือกให้เองตอนทำเส้นขนาน (_line_par_auto) ปล่อยเมื่อมีเส้นใหม่
        #   เพิ่มเข้ามา (วาดเส้นใหม่จบ) ⇒ กลับไปใช้ "เส้นล่าสุด" ตามคำแนะนำในหน้าต่าง · ที่ผู้ใช้เลือกเองคงไว้
        _sel = None
        try:
            for _x in tree.selectedItems()[:1]:
                _row = -1
                if _x.parent() is not None:
                    _row = _x.parent().indexOfChild(_x)
                    _x = _x.parent()
                _v = _x.data(0, QtCore.Qt.UserRole)
                if _v is not None:
                    _sel = (int(_v), _row)
        except Exception:
            _sel = None
        _n_prev, self._line_refresh_n = getattr(self, "_line_refresh_n", None), len(it.lines)
        _auto = getattr(self, "_line_par_auto", None)
        if _auto is not None and (_sel is None or _sel[0] != _auto or _auto >= len(it.lines)):
            _auto = self._line_par_auto = None        # ผู้ใช้เลือกเส้นอื่น/ยกเลิกเลือก/เส้นนั้นถูกลบ ⇒ ไม่ใช่ที่เลือกให้เองแล้ว
        if _auto is not None and _n_prev is not None and len(it.lines) > _n_prev:
            _sel, self._line_par_auto = None, None    # วาดเส้นใหม่จบ ⇒ ปล่อยที่เลือกให้เอง
        tree.clear()
        for i, pts in enumerate(it.lines, 1):
            if len(pts) < 2:
                continue
            top = QtWidgets.QTreeWidgetItem(
                ["เส้นที่ %d  (%d จุด)" % (i, len(pts)), it.fmt(it.line_len(pts))])
            f = top.font(0)
            f.setBold(True)
            top.setFont(0, f)
            top.setFont(1, f)
            for j in range(len(pts) - 1):
                QtWidgets.QTreeWidgetItem(
                    top, ["ช่วง %d" % (j + 1), it.fmt(it.seg_len(pts[j], pts[j + 1]))])
            # ★ 2.2.5 — ฝัง index จริงของเส้นไว้ในรายการ
            #   ลูปนี้ **ข้ามเส้นที่มี < 2 จุด** (`continue` ด้านบน) ⇒ ลำดับในรายการ
            #   ไม่ตรงกับ index ใน it.lines · ถ้าใช้ลำดับในรายการไปอ้างอิง จะ offset ผิดเส้น
            top.setData(0, QtCore.Qt.UserRole, i - 1)
            tree.addTopLevelItem(top)
            top.setExpanded(_exp.get(i - 1, len(it.lines) <= 3))      # ★ 2.3.7 (UX-17) จำสถานะเดิม
        if _sel is not None:
            self._line_tree_select(*_sel)                                 # ★ 2.3.7 b13 (UX-17)
        if it.temp:
            n = len(it.temp)
            live = QtWidgets.QTreeWidgetItem(
                ["กำลังวาด… (%d จุด)" % n,
                 it.fmt(it.line_len(it.temp)) if n > 1 else "-"])
            live.setForeground(0, QtGui.QBrush(QtGui.QColor(230, 81, 0)))
            tree.addTopLevelItem(live)
        self._line_total.setText("รวมทั้งหมด %s" % it.fmt(it.total_len()))

    # ---------- ปิดหน้าต่าง ----------
    def _line_cleanup(self):
        """เรียกตอน unload — เก็บของบนแคนวาสและคืน snapping ให้เรียบร้อย"""
        try:
            self.iface.mapCanvas().destinationCrsChanged.disconnect(self._line_on_crs_changed)   # ★ 2.3.7 (DI-40)
        except Exception:
            pass
        self._line_snap_return()
        try:
            self._line_layer_drop()
        except Exception:
            pass
        item = getattr(self, "_line_item", None)
        if item is not None:
            try:
                self.iface.mapCanvas().scene().removeItem(item)
            except Exception:
                pass
            self._line_item = None
        win = getattr(self, "_line_dock", None)
        if win is not None:
            try:
                win.removeEventFilter(getattr(self, "_line_filter", None))
            except Exception:
                pass
            try:
                win.close()
                win.deleteLater()
            except Exception:
                pass
            self._line_dock = None
        # ★ 2.3.7 (review LC-03a) — ตัวดักเป็นลูกของหน้าต่างหลัก QGIS และถือ plugin=self ⇒ ไม่ลบ = ทุก reload/อัปเดตตัวเอง
        #   instance เก่า (ประวัติ Undo · cache · เครื่องมือ) ค้างอยู่ในหน่วยความจำจนปิด QGIS
        _flt = getattr(self, "_line_filter", None)
        if _flt is not None:
            try:
                _flt.setParent(None)
                _flt.deleteLater()
            except Exception:
                pass
        self._line_filter = None
