# -*- coding: utf-8 -*-
"""ค้นภาพโฉนด/หลักฐานรังวัดจากระบบกรมที่ดิน (DOL iLands) — ต้องต่อเครือข่ายกรม

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import (Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry, QgsMessageLog,
                       QgsProject, QgsWkbTypes)
from qgis.gui import QgsRubberBand
from ..core.util import (_branch_office_of, _dol_here_hint, _dol_more_hint, _dol_via_note, _log_err,
                         _net_err_text, _probe_xy_24047, _scrub, _sheet_str, _txt)
from ..map_tools import PolygonPickTool
from ..services.workers import ParcelLookupWorker


class DolMixin:
    """ค้นภาพโฉนด/หลักฐานรังวัดจากระบบกรมที่ดิน (DOL iLands) — ต้องต่อเครือข่ายกรม"""

    # ============ DOL iLands: ค้นหาเอกสารจากแปลง ============
    def start_dol_search(self, mode='image'):
        """เปิด map tool คลิกเลือกแปลง -> mode 'image'=ภาพลักษณ์(public) / 'survey'=หลักฐานรังวัด(login)"""
        # ★ 2.3.7 (review DI-21) — ด่าน "กำลังค้นอยู่" ต้องมาก่อนแตะสถานะใด ๆ (เดิมเขียน _dol_mode ทับก่อน
        #   ⇒ ผลของคำค้นเดิมที่มาทีหลังถูกตีความด้วยโหมดของคำค้นใหม่ เช่นผลภาพลักษณ์ถูกส่งไปค้นหลักฐานรังวัด)
        if self._dol_refuse_if_busy():
            return
        self._dol_mode = mode
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if lyr is None:
            self._ask(
                QtWidgets.QMessageBox.Warning, "ไม่พบเลเยอร์", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        try:
            if lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
                self._ask(
                    QtWidgets.QMessageBox.Warning, "เลเยอร์ไม่ถูกต้อง", f"เลเยอร์ '{lyr.name()}' ไม่ใช่ Polygon")
                return
        except Exception:
            pass
        self._dol_clear_highlight()
        canvas = self.iface.mapCanvas()
        # ล็อกให้คลิก/ไฮไลต์ได้เฉพาะแปลงในเลเยอร์ที่เลือกในปลั๊กอินเท่านั้น
        self.temp_tool = PolygonPickTool(
            canvas, lyr, self._on_polygon_picked, self._dol_on_hover)
        canvas.setMapTool(self.temp_tool)
        what = "ภาพลักษณ์" if mode == 'image' else "หลักฐานการรังวัด"
        self.temp_tool.push_hint(                                       # ★ 2.3.7 (UX-01) ข้อความของเครื่องมือ
            "DOL", f"คลิกบนแปลงในเลเยอร์ '{lyr.name()}' เพื่อค้นหา{what} (Esc เพื่อยกเลิก)")

    def _on_polygon_picked(self, feat, layer):
        """อ่าน attribute UTM ของแปลงที่คลิก (จากเลเยอร์ที่เลือก) แล้วยิงค้นหา"""
        gv = lambda name: _sheet_str(feat, name)      # noqa: E731  (ดู _sheet_str)

        m1, m2, m3 = gv("UTMMAP1"), gv("UTMMAP2"), gv("UTMMAP3")
        m4 = gv("UTMMAP4") or "00"
        scale = gv("UTMSCALE")
        landno = gv("LANDNO")
        self.iface.actionSelect().trigger()  # คืน cursor ปกติ
        # ★ 2.3.7 (review DI-21) — ด่านกันยิงซ้อนต้องมาก่อนไฮไลต์/เขียน _dol_attrs (เดิมอยู่หลัง ⇒ ระวางของคำค้นใหม่
        #   ทับของคำค้นที่ยังรอผล แล้วผลของแปลงเดิมถูกแสดง/ค้นต่อด้วยระวางของแปลงใหม่)
        if self._dol_refuse_if_busy():
            return
        req = self._dol_new_req(getattr(self, "_dol_mode", "image"), None)

        # ไฮไลต์แปลงที่คลิกทันที (กรอบแดง) — ★ 2.3.7 (review UX-31) อยู่จน flow ของคำขอนี้จบจริง (_dol_end)
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass
        req["rb"] = getattr(self, "_dol_highlight", None)

        if not m1 or not m2 or not m3 or not scale or not landno:
            try:
                self._ask(
                    QtWidgets.QMessageBox.Warning, "ข้อมูลแปลงไม่ครบ",
                    f"แปลงนี้ไม่มี attribute ระวางครบ\n"
                    f"UTMMAP={m1} {m2} {m3} {m4} | SCALE={scale} | LANDNO={landno}")
            finally:
                self._dol_end(req)
            return

        # centroid ของแปลงที่คลิก (แปลงเป็น datum 24047) -> ใช้แก้ปัญหา "ระวางคร่อมสาขา"
        # ที่ LAND_NO ซ้ำข้ามสาขา (เลือกแปลงที่ใกล้จุดคลิกสุด แทนการหยิบตัวแรกมั่ว)
        near_xy = None
        try:
            c = feat.geometry().centroid().asPoint()
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            if layer.crs() != dst:
                c = QgsCoordinateTransform(layer.crs(), dst, QgsProject.instance()).transform(c)
            near_xy = (c.x(), c.y())
        except Exception:
            near_xy = None

        attrs = {"m1": m1, "m2": m2, "m3": m3, "m4": m4,
                 "scale": scale, "landno": landno, "near_xy": near_xy,
                 "probe_xy": _probe_xy_24047(feat.geometry(), layer.crs()),     # ★ 2.3.9 ทางสำรอง iLands
                 "office_seq": _branch_office_of(layer)}                         # ★ 2.3.10 ล็อกสาขา
        self._dol_attrs = attrs   # เก็บไว้ใช้ค้นหลักฐานรังวัด (ต้องใช้ utmmap เดิม)
        req["attrs"] = attrs      # ★ 2.3.7 (review DI-21) — ผลของคำขอนี้ใช้ระวางของตัวเองเสมอ

        # ★ กันยิงซ้อน (2026-08-06) — ★ 2.3.7 (review DI-21) ย้ายไปบนสุดของฟังก์ชันแล้ว (_dol_refuse_if_busy)
        #   🔴 การผูก self._dol_worker ตัวใหม่ทับ ห้ามทำให้ตัวเก่าที่ยังวิ่งเหลือ ref 0 (sip ลบ QThread ทั้งที่ยังไม่ finish
        #   ⇒ qFatal "QThread: Destroyed while thread is still running" = QGIS ดับ) ⇒ worker ทุกตัว (รวมตัวที่ถูกกดยกเลิก)
        #   ถูกถือไว้ใน _net_workers จนถึง finished — ผูกทับ _dol_worker ได้ปลอดภัย

        self._dol_busy = QtWidgets.QProgressDialog(
            f"กำลังค้นหา PARCEL_SEQ...\nระวาง {m1} {m2} {m3}-{m4} ที่ดิน {landno}",
            None, 0, 0, self.dlg)
        self._dol_busy.setWindowTitle("DOL")
        self._dol_busy.setCancelButton(None)
        self._dol_busy.setWindowModality(QtCore.Qt.WindowModal)
        self._dol_wait_arm(self._dol_busy, req, own=True)   # ★ 2.3.7 (review UX-22) — ปุ่ม "ยกเลิก" จริง
        self._dol_busy.show()

        # ถือ ref ไว้ในลิสต์เหมือน _run_net (กัน GC เก็บ worker ระหว่างรัน) แล้วปล่อยตอน finished
        w = ParcelLookupWorker(attrs, zone=47)
        self._dol_worker = w
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)

        def _drop_worker(_w=w):
            try:
                self._net_workers.remove(_w)
            except Exception:
                pass
            try:
                _w.deleteLater()       # finished ยิงหลัง QThreadPrivate::finish() แล้ว -> ลบปลอดภัย
            except Exception:
                pass
        w.finished.connect(_drop_worker)
        # ★ 2.3.7 (review DI-21/UX-22) — ผลผูกกับคำขอนี้ (req) · คำขอที่ถูกยกเลิก/มีคำขอใหม่กว่า ⇒ ผลถูกทิ้ง
        w.done.connect(lambda res, _r=req: self._on_dol_done(res, _r))
        w.fail.connect(lambda msg, _r=req: self._on_dol_fail(msg, _r))
        w.start()

    def _on_dol_done(self, res, req=None):
        """ผลค้น PARCEL_SEQ (worker) — ★ 2.3.7 (review DI-21/UX-22) req = คำขอที่ผลนี้เป็นของ (ผูกตอนยิง)
        ถูกยกเลิก/มีคำขอใหม่กว่า ⇒ ทิ้งผล (ไม่เปิดเบราว์เซอร์ ไม่เด้งกล่อง) · req=None = เรียกตรง (เทส/โค้ดเดิม)
        ⇒ ใช้โหมด/ระวางบน self เหมือนเดิม · ★ UX-31 ไฮไลต์ถูกล้างเมื่อ flow จบจริง (เดิมล้างก่อนกล่อง login)"""
        req = self._dol_result_req(req)
        if req is None:
            return
        _cont = False
        try:
            _cont = bool(self._dol_show_result(res, req))
        finally:
            if not _cont:
                self._dol_end(req)

    def _dol_show_result(self, res, req):
        """แสดง/เปิดผลค้น PARCEL_SEQ ตามโหมดของคำขอ · คืน True = flow ยังไม่จบ (ไปขั้นหลักฐานรังวัด)"""
        a = req.get("attrs") or {}
        ระวาง = "%s %s %s-%s ที่ดิน %s" % (a.get("m1", "?"), a.get("m2", "?"), a.get("m3", "?"),
                                           a.get("m4", "?"), a.get("landno", "?"))
        # 🔧 2.3.1 (21 ก.ย. 69) — "หาไม่เจอ" บอกให้ตรงว่าเพราะอะไร
        #   🔴 ข้อความเดิม "ตรวจเลขระวาง / zone UTM" **ชี้ผิดทาง** เมื่อระวางถูกอยู่แล้ว
        #      เคสจริงที่เจ้าของงานเจอ: องครักษ์ gid 20265 ระวาง 5137 2 1058-07 ที่ดิน 89
        #      ระวางนี้ DOL มี 98 เลข แต่ไม่มี 88/89/105 ⇒ เป็นเรื่อง "ไม่มีทะเบียน" ไม่ใช่คีย์ผิด
        if isinstance(res, dict) and res.get("not_found"):
            # ★ 2.3.9 rc5 — ทางสุดท้าย: ทะเบียน iLands (ต้อง login · ช้า) — ยังไม่ได้เข้าสู่ระบบ ⇒ ถามก่อน (ปุ่มตั้งต้น = ค้น)
            #   "มีบางแปลงที่ไม่มีรูปแปลงแต่มีทะเบียน จึงหาใน arcgis ไม่ได้" · "ให้เป็นทางสุดท้ายนะ เพราะใช้เวลานาน" (เจ้าของงาน 11 ต.ค.)
            if res.get("lis") == "login" and not req.get("lis_tried") and self._dol_offer_lis(res, req, ระวาง):
                return True                       # flow ยังไม่จบ — รอเข้าสู่ระบบ/ค้นทะเบียน
            มีระวาง = res.get("sheet_exists")
            n = res.get("sheet_land_count")
            # ★ 2.3.11 — ค้นแบบล็อกสาขา: "มีระวาง / จำนวนเลขในระวาง" นับเฉพาะแปลงของสาขานี้ ⇒ ถ้อยคำบอกว่า "ของสาขานี้"
            #   (2.3.10 ขึ้น "แปลงไม่มีทะเบียน" / "ระบบกรมไม่มีระวางนี้เลย" ทั้งที่เลขนี้เป็นแปลงของสำนักงานอื่น · ผู้ตรวจคู่มือ 2.3.10)
            bo = str(res.get("branch_office") or a.get("office_seq") or "").strip()
            oo = str((res.get("other_office") or {}).get("office_seq") or "").strip()
            # ★ 2.3.9 — ArcGIS ไม่มีคีย์นี้ + ถาม iLands ที่ตำแหน่งแปลงแล้วเจอแปลงคีย์อื่น ⇒ บอกพนักงาน (มักแปลว่าคีย์ของแปลงเราผิด)
            ที่นี่ = _dol_here_hint(res) + _dol_more_hint(res, skip_other=bool(oo))
            if oo:
                self._ask(
                    QtWidgets.QMessageBox.Information, "เป็นแปลงของสำนักงานที่ดินอื่น",
                    "ระวาง/เลขที่ดินนี้ไม่มีในสำนักงานที่ดินของสาขานี้" + (f" (รหัส {bo})" if bo else "") + "\n"
                    f"แต่บนแผนที่กรมเป็นแปลงของสำนักงานที่ดินอื่น (รหัส {oo})\n"
                    f"ระวาง {ระวาง}\n\n"
                    "ปลั๊กอินค้นเฉพาะแปลงของสาขาตามชั้นข้อมูลนี้ จึงไม่เปิดภาพลักษณ์/หลักฐานการรังวัดของสำนักงานอื่น\n"
                    "ถ้าระวาง/เลขที่ดินของแปลงนี้ผิด แจ้งผู้ดูแลให้แก้ · ถ้าถูกและเป็นแปลงของสำนักงานอื่นจริง "
                    "แจ้งผู้ดูแลพร้อมรหัสสำนักงาน" + ที่นี่)
            elif res.get("arc_miss"):
                # ★ 2.4.1 — แผนที่ ArcGIS มีเลขนี้ แต่ระบบทะเบียนไม่มีข้อมูลที่จุดกลาง (udm_empty) / ไม่มีจุดกลาง (no_origin)
                #   เดิม: ข้อผิดพลาด "ค้นด้วยระวางนี้ไม่ได้" ทันที · ห้ามใช้ "แปลงไม่มีทะเบียน … ไม่มีเลขที่ดินนี้" (แผนที่มีเลขนี้อยู่)
                #   และห้ามสรุปว่ายกเลิก (คลองหลวง 5137 3 8052 ที่ดิน 201 · 14 ต.ค. 69)
                self._ask(
                    QtWidgets.QMessageBox.Information, "ระบบทะเบียนไม่มีข้อมูลแปลงนี้",
                    f"แผนที่ของกรม (ArcGIS) มีระวาง/เลขที่ดินนี้{'ของสาขานี้' if bo else ''} แต่"
                    + ("ระบบทะเบียน (iLands) ไม่มีข้อมูลที่ตำแหน่งของแปลงนั้น" if res.get("arc_miss") == "udm_empty"
                       else "ไม่มีพิกัดจุดกลางของแปลง จึงถามระบบทะเบียน (iLands) ไม่ได้")
                    + f"\nระวาง {ระวาง}\n\n"
                    "สาเหตุที่เป็นไปได้: ข้อมูลแผนที่กับทะเบียนของกรมยังไม่ตรงกัน หรือแปลงถูกแบ่งแยก/ยกเลิกแล้วแต่แผนที่ยังไม่อัปเดต\n"
                    "จึงเปิดภาพลักษณ์/หลักฐานการรังวัดจากปลั๊กอินไม่ได้" + ที่นี่)
            elif มีระวาง is True:
                self._ask(
                    QtWidgets.QMessageBox.Information, "แปลงไม่มีทะเบียน",
                    f"แปลงนี้ไม่มีทะเบียนในระบบของกรมที่ดิน (DOL)\n"
                    f"ระวาง {ระวาง}\n\n"
                    f"ระวางนี้มีอยู่ในระบบ (มีที่ดิน{'ของสาขานี้' if bo else ''} {n:,} เลข) "   # ★ 2.3.7 (review UX-29) เดิม ** โผล่ในกล่อง
                    f"แต่ไม่มีเลขที่ดินนี้\n"
                    "จึงเปิดภาพลักษณ์/หลักฐานการรังวัดจากปลั๊กอินไม่ได้" + ที่นี่)
            elif มีระวาง is False:
                self._ask(
                    QtWidgets.QMessageBox.Information, "ไม่พบระวางในสาขานี้" if bo else "ไม่พบระวาง",
                    ("ระวางนี้ไม่มีแปลงของสำนักงานที่ดินของสาขานี้\n" if bo else
                     "ระบบกรมที่ดิน (DOL) ไม่มีระวางนี้เลย\n")                 # ★ 2.3.7 (review UX-29)
                    + f"ระวาง {ระวาง}\n\n"
                    "ตรวจเลขระวาง / มาตราส่วน / zone UTM ของแปลงนี้อีกครั้ง" + ที่นี่)
            else:
                self._ask(
                    QtWidgets.QMessageBox.Information, "ไม่พบแปลง",
                    f"ไม่พบแปลง{'ของสาขานี้' if bo else ''}ในระบบ DOL\n"
                    f"ระวาง {ระวาง}\n\n"
                    "ตรวจสอบสาเหตุเพิ่มไม่ได้ (ต่อระบบ DOL ไม่ได้ชั่วคราว)" + ที่นี่)
            return
        if not res:
            self._ask(
                QtWidgets.QMessageBox.Information, "ไม่พบแปลง", "ไม่พบแปลงในระบบ (ตรวจเลขระวาง / zone UTM)")
            return

        # 🔧 2.2.10 (17 ก.ย. 69) — แปลงไม่มีทะเบียนในระบบ DOL: บอกตรง ๆ
        #   เดิม: ปุ่มหลักฐานรังวัดขึ้น "ยังไม่รองรับจังหวัดของแปลงนี้ ()" (ชี้ผิดทาง — จังหวัดรองรับอยู่)
        #         ปุ่มภาพลักษณ์ขึ้นว่า "เปิดภาพลักษณ์แล้ว" ทั้งที่ไม่มีลิงก์ให้เปิด
        #   เจ้าของงานเลือก "บอกให้ตรง" (ไม่เดาจังหวัดจากชื่อสำนักงาน)
        if res.get("not_registered"):
            what = "หลักฐานการรังวัด" if req.get("mode") == "survey" else "ภาพลักษณ์"
            if res.get("via") == "arcgis_temp":
                # ★ rc5 — คีย์อยู่ในชั้นแปลงรอจดของกรม (UDM ยืนยันคีย์ตรง แต่ยังไม่มีทะเบียน) ⇒ รอจด ไม่ใช่ "ไม่มีทะเบียน"
                #   วัดจริง 11 ต.ค.: คลองหลวง 5137 3 8058 1:4000 เลข 1527 (กรมบอกส่งงานทะเบียนแล้ว)
                self._ask(
                    QtWidgets.QMessageBox.Information, "แปลงรอจดทะเบียน",
                    f"แปลงนี้อยู่ในชั้นแปลงรอจดทะเบียนของกรมที่ดิน (รังวัดแล้ว ยังไม่จดทะเบียน)\n"
                    f"จึงยังค้นหา{what}จากปลั๊กอินไม่ได้\n\n"
                    f"ระวาง {res.get('rawang') or ''} • ที่ดิน {res.get('land_no') or ''}\n"
                    f"{res.get('office') or ''}")
                return
            self._ask(
                QtWidgets.QMessageBox.Information, "แปลงไม่มีทะเบียน",
                f"แปลงนี้ไม่มีทะเบียนในระบบของกรมที่ดิน (DOL)\n"
                f"จึงค้นหา{what}จากปลั๊กอินไม่ได้\n\n"
                f"ระวาง {res.get('rawang') or ''} • ที่ดิน {res.get('land_no') or ''}\n"
                f"{res.get('office') or ''}")
            return

        if req.get("mode") == "survey":          # ★ 2.3.7 (review DI-21) — โหมดของคำขอนี้ ไม่ใช่ของปุ่มล่าสุด
            self._open_survey(res)
            return True

        # ภาพลักษณ์ -> เปิดทันที (ไม่เด้ง popup) เฉพาะผลที่ยืนยันได้ว่าเป็นแปลงที่คลิก
        # ★ 2.3.7 (review DI-16) — เดิมเปิดทุกกรณี แล้วค่อยต่อท้าย "⚠️ MAP_PARCEL_SEQ ไม่ตรง" ในแถบสีเขียว
        #   ⇒ พนักงานอาจกำลังอ่านโฉนดของแปลงข้างเคียง · ยืนยันไม่ได้ (หรือระวางคร่อมสาขาแต่หาตำแหน่งแปลงที่คลิกไม่ได้)
        #   ⇒ ถามก่อน ปุ่มตั้งต้น "ไม่" · ไม่แสดงชื่อเจ้าของที่ดินที่ระบบกรมส่งมา
        n_match = res.get("match_count") or 1
        near = a.get("near_xy") is not None
        # ★ 2.3.11 — ค้นแบบล็อกสาขาแล้ว "หลายรายการ" ไม่ใช่ระวางคร่อมสาขา (ซ้ำในสำนักงานเดียว) · ทะเบียน iLands = ใช้รายการแรก
        locked = bool(res.get("branch_office") or a.get("office_seq"))
        lis_many = res.get("via") == "lis"
        # ★ rc2 (audit A4-05) — ผลจากทะเบียน iLands ไม่มีพิกัด ⇒ "ใกล้จุดคลิกสุด" ใช้เลือกไม่ได้ (near_xy มีเกือบทุกครั้ง)
        #   เดิมถือว่าแน่ใจ ⇒ เปิดรายการแรกทันทีโดยไม่ถาม + แถบเขียว (อาจเป็นโฉนดของแปลงอื่น · ขัด DI-16) ⇒ หลายรายการ = ถามก่อน
        sure = bool(res.get("verified")) and (n_match <= 1 or (near and not lis_many))
        if not sure:
            why = ("ระบบกรมตอบข้อมูลที่ยืนยันไม่ได้ว่าเป็นแปลงที่คลิก (เลขแปลงในแผนที่ของระบบไม่ตรงกัน)"
                   if not res.get("verified") else
                   f"ทะเบียนของ iLands มีเลขนี้ {n_match} รายการ (ทะเบียนไม่มีพิกัด จึงเลือกรายการที่ตรงกับแปลงที่คลิกไม่ได้)"
                   if lis_many else
                   f"ระวางนี้มีเลขที่ดินนี้ {n_match} แปลงในสาขานี้ และหาตำแหน่งแปลงที่คลิกไม่ได้" if locked else
                   f"ระวางนี้มีเลขที่ดินนี้ {n_match} แปลง (คร่อมสาขา) และหาตำแหน่งแปลงที่คลิกไม่ได้")
            ans = self._ask(
                QtWidgets.QMessageBox.Warning, "ยืนยันแปลงไม่ได้",
                f"{why}\nภาพลักษณ์ที่จะเปิดอาจเป็นของแปลงอื่น\n\n"
                f"แปลงที่คลิก: ระวาง {ระวาง}\n"
                f"ระบบกรมตอบ: โฉนด {res.get('parcel_no') or '-'} • ระวาง {res.get('rawang') or '-'} • "
                f"ที่ดิน {res.get('land_no') or '-'} • {res.get('office') or ''}\n\n"
                "เปิดภาพลักษณ์นี้หรือไม่?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if ans != QtWidgets.QMessageBox.Yes:
                self.iface.messageBar().pushMessage(
                    "DOL", f"ไม่ได้เปิดภาพลักษณ์ — ยืนยันไม่ได้ว่าเป็นแปลงที่คลิก (ระวาง {ระวาง})", level=1, duration=8)
                return
        if res.get("doc_url"):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(res["doc_url"]))
        warn = "" if res.get("verified") else "  ⚠️ ยืนยันไม่ได้ว่าเป็นแปลงที่คลิก"
        if _dol_via_note(res):                   # ★ rc5 — udm_point · ชั้นรอจด · ชั้นประวัติ · ทะเบียน iLands
            warn += "  ℹ️ " + _dol_via_note(res)
        if n_match > 1:
            _ที่ = ("(เลือกใกล้จุดคลิกสุด)" if near else "(หาตำแหน่งแปลงที่คลิกไม่ได้ — ใช้รายการแรกที่ระบบตอบ)")
            if lis_many:
                warn += f"  🔀 ทะเบียนของ iLands มีเลขนี้ {n_match} รายการ (ใช้รายการแรก)"
            elif locked:
                warn += f"  🔀 พบเลขนี้ {n_match} แปลงในสาขานี้ " + _ที่
            else:
                warn += f"  🔀 ระวางคร่อม {n_match} สาขา " + _ที่
        self.iface.messageBar().pushMessage(
            "DOL", f"โฉนด {res.get('parcel_no')} | {res.get('office','')} "
                   f"({res.get('city','')}) — เปิดภาพลักษณ์แล้ว (ระวาง {ระวาง}){warn}",
            level=3 if sure else 1, duration=8)

    # ---------- หลักฐานการรังวัด (ต้อง login) ----------
    def _dol_ask_credentials(self, user="", err=""):
        """popup ขอ user/pass (UI อย่างเดียว — network ไปทำใน thread แยก)
        -> (user, pass) หรือ None ถ้ายกเลิก/กรอกไม่ครบ
        ★ 2.3.7 (review UX-31) — ปุ่มตกลงกดได้เมื่อกรอกครบทั้งสองช่อง (เดิมกดได้แล้วได้ None เงียบ ๆ)
          · user = ชื่อผู้ใช้ที่จำไว้ในหน่วยความจำ (เติมให้ แล้ววางเคอร์เซอร์ที่ช่องรหัส · ไม่จำรหัสผ่าน)
          · err = เหตุที่เข้าสู่ระบบรอบก่อนไม่ผ่าน (แสดงสีแดงบนสุด)"""
        dlg = QtWidgets.QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("เข้าสู่ระบบ DOL iLands")
        dlg.setMinimumWidth(320)
        form = QtWidgets.QFormLayout(dlg)
        if err:
            _lbl_err = QtWidgets.QLabel(str(err))
            _lbl_err.setWordWrap(True)
            _lbl_err.setStyleSheet("color:#c62828;")
            form.addRow(_lbl_err)
        ed_user = QtWidgets.QLineEdit()
        if user:
            ed_user.setText(str(user))
        ed_pass = QtWidgets.QLineEdit()
        ed_pass.setEchoMode(QtWidgets.QLineEdit.Password)
        form.addRow("ผู้ใช้:", ed_user)
        form.addRow("รหัสผ่าน:", ed_pass)
        note = QtWidgets.QLabel("🔒 ไม่เก็บรหัสถาวร — ปิด QGIS แล้วต้องเข้าสู่ระบบใหม่")
        note.setStyleSheet("color:#666; font-size:11px;")
        form.addRow(note)
        bb = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        form.addRow(bb)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        _okb = bb.button(QtWidgets.QDialogButtonBox.Ok)

        def _can_ok(*_a):
            _okb.setEnabled(bool(ed_user.text().strip()) and bool(ed_pass.text()))
        ed_user.textChanged.connect(_can_ok)
        ed_pass.textChanged.connect(_can_ok)
        _can_ok()
        (ed_pass if ed_user.text().strip() else ed_user).setFocus()
        _ok = dlg.exec_() == QtWidgets.QDialog.Accepted
        u, p = ed_user.text().strip(), ed_pass.text()
        # ★ 2.3.7 (review SE-03) — ล้างช่องรหัส + ลบกล่องทิ้ง (เดิมค้างเป็นลูกของหน้าต่างหลักพร้อมรหัสในช่อง)
        ed_pass.clear()
        dlg.deleteLater()
        if not _ok or not u or not p:
            return None
        return (u, p)

    def _cadastral_label(self, rec, i):
        """สร้างข้อความบรรยาย 1 รายการรังวัด (โชว์ field ที่มี)"""
        parts = []
        for k in ("CADASTRAL_NO", "CADASTRALNO", "SURVEY_NO", "SURVEYNO",
                  "TYPE_OF_SURVEY", "TYPEOFSURVEY", "SCALE", "SHEET_CODE",
                  "SHEETCODE", "SURVEY_DATE", "SURVEYDATE", "UTMMAP4"):
            v = rec.get(k)
            if v not in (None, "", "null"):
                parts.append(f"{k}={v}")
        label = " | ".join(parts) if parts else "(ไม่มีรายละเอียด)"
        return f"{i + 1}. {label}  [seq {rec.get('CADASTRAL_SEQ')}]"

    def _choose_cadastral(self, recs):
        """หลายรายการรังวัด -> popup ให้เลือก (คืน record หรือ None)"""
        items = [self._cadastral_label(rec, i) for i, rec in enumerate(recs)]
        item, ok = QtWidgets.QInputDialog.getItem(
            self.iface.mainWindow(), "เลือกหลักฐานการรังวัด",
            f"แปลงนี้มี {len(recs)} รายการ — เลือกที่ต้องการเปิด:", items, 0, False)
        if not ok:
            return None
        return recs[items.index(item)]

    def _open_survey(self, res):
        """ค้นหลักฐานรังวัดจากแปลงที่คลิก (login ถ้าจำเป็น) แล้วเปิด viewer; หลายรายการ -> ให้เลือก
        network ทั้งหมด (login + ค้นหา) รันใน thread แยกผ่าน _run_net — เดิม block UI สูงสุด 30 วิ"""
        from .. import dol_api
        # ★ 2.3.7 (review DI-21) — บริบทของคำขอนี้ (req) ส่งต่อทุกขั้น (เดิมอ่าน/เขียน self._survey_ctx ร่วมกัน)
        req = getattr(self, "_dol_req", None)
        if not self._dol_live(req) or req.get("attrs") is not getattr(self, "_dol_attrs", None):
            req = self._dol_new_req("survey", getattr(self, "_dol_attrs", None))     # เรียกตรง (เทส/โค้ดเดิม)
        attrs = req.get("attrs") or {}
        prov = dol_api.province_code_from_city(res.get("city", ""))
        office = _txt(res.get("office_seq"))
        stop = ""
        # ★ 2.3.7 (review UX-30) — แยก "ไม่รองรับจังหวัด" ออกจาก "ระบบไม่ส่งรหัสสำนักงาน" (เดิมเงื่อนไขเดียว ⇒ กล่องขัดกันเอง
        #   'ยังไม่รองรับจังหวัด (จ.ปทุมธานี …) … ปัจจุบันรองรับ: … ปทุมธานี') · รายชื่อรวมจังหวัดที่เพิ่มผ่าน QSettings
        #   · ชื่อคีย์ QSettings ลง Log ของ MLEP ให้ผู้ดูแล ไม่ใส่ในกล่องของพนักงาน
        if not prov:
            known = " ".join(dol_api.known_provinces())
            stop = (f"ยังไม่รองรับจังหวัดของแปลงนี้ ({res.get('city') or 'ระบบ DOL ไม่ส่งชื่อจังหวัดมา'})\n"
                    f"ปัจจุบันรองรับ: {known}\n"
                    "(รหัสจังหวัดภายในระบบ DOL ไม่ตรงรหัสมาตรฐาน ต้องเก็บเพิ่มจากระบบจริง)")
            if res.get("city"):
                QgsMessageLog.logMessage(
                    f"หลักฐานการรังวัด: ยังไม่มีรหัสจังหวัดของ '{res.get('city')}' — เพิ่มได้ที่ QSettings "
                    "MultiLayerEditPro/ProvinceCode/<ชื่อจังหวัด> = <รหัสจังหวัดภายในระบบ DOL>", "MLEP", Qgis.Info)
        elif not office:
            stop = ("ระบบ DOL ไม่ส่งรหัสสำนักงานของแปลงนี้มา — ค้นหลักฐานการรังวัดจากปลั๊กอินไม่ได้\n"
                    f"(ระวาง {self._dol_rawang_text(attrs)} • {res.get('office') or ''} {res.get('city') or ''})")
        else:
            # ★ 2.3.7 (review ER-07) — มาตราส่วน/รหัสจังหวัดที่ใช้ไม่ได้ แจ้งก่อนถามรหัสผ่าน (เดิมรู้หลังค้นแล้ว หรือได้ ValueError เปล่า)
            try:
                dol_api.scale_code(attrs.get("scale"))
                dol_api._as_int(prov, "รหัสจังหวัดของระบบ DOL")
            except dol_api.DOLError as e:
                stop = f"{e}\n(ระวาง {self._dol_rawang_text(attrs)})"
                QgsMessageLog.logMessage(
                    f"หลักฐานการรังวัด: {e} — จังหวัด '{res.get('city')}' (รหัสจังหวัดตั้งได้ที่ QSettings "
                    "MultiLayerEditPro/ProvinceCode/<ชื่อจังหวัด>)", "MLEP", Qgis.Warning)
        if stop:
            try:
                self._ask(QtWidgets.QMessageBox.Warning, "หลักฐานการรังวัด", stop)
            finally:
                self._dol_end(req)
            return
        req.update(prov=prov, office=office, verified=bool(res.get("verified", True)))
        self._survey_ctx = req
        self._survey_step(req)

    def _survey_step(self, ctx=None):
        """ขั้น login: ถ้ายังไม่ login -> ขอรหัส (UI) แล้ว login ใน thread แยก จากนั้นค่อยค้นหา
        ★ 2.3.7 (review UX-31) — เติมชื่อผู้ใช้ที่จำไว้ (หน่วยความจำของปลั๊กอินเท่านั้น: ไม่ลง QSettings · ไม่จำรหัสผ่าน)
          + เหตุที่รอบก่อนไม่ผ่าน · กดยกเลิก = จบ flow (ล้างไฮไลต์) · ctx = คำขอของ flow นี้ (★ DI-21)"""
        from .. import dol_api
        ctx = self._dol_ctx(ctx)
        if dol_api.is_logged_in():
            self._survey_search(ctx)
            return
        creds = self._dol_ask_credentials(user=getattr(self, "_dol_user", "") or "", err=ctx.pop("login_err", ""))
        if not creds:
            self._dol_end(ctx)
            return
        u, p = creds
        self._dol_user = u
        ctx["tries"] = ctx.get("tries", 0) + 1
        self._run_net("กำลังเข้าสู่ระบบ DOL...",
                      lambda: dol_api.login(u, p),
                      lambda _s, c=ctx: self._survey_search(c),
                      lambda e, c=ctx: self._survey_login_failed(e, c), req=ctx)

    def _survey_login_failed(self, e, ctx=None):
        from .. import dol_api
        ctx = self._dol_ctx(ctx)
        tries = ctx.get("tries", 0)
        if isinstance(e, dol_api.DOLAuthError) and getattr(e, "ask_again", False) and tries < 3:
            # ★ 2.3.7 (review UX-31) — รหัสผิด ⇒ เปิดกล่องเข้าสู่ระบบซ้ำในรอบเดิม (บอกเหตุ + ชื่อเดิม) ไม่เกิน 3 ครั้ง
            #   เดิมเตือนแล้วจบ ⇒ ต้องกดปุ่ม คลิกแปลง รอค้น แล้วพิมพ์ใหม่ทั้งสองช่อง
            ctx["login_err"] = f"{e}\n(ลองแล้ว {tries} จาก 3 ครั้ง)"
            self._survey_step(ctx)
            return
        try:
            if isinstance(e, dol_api.DOLAuthError):
                more = ("\n\nลองครบ 3 ครั้งแล้ว — เริ่มใหม่ได้ที่ปุ่ม 📐 หลักฐานการรังวัด"
                        if getattr(e, "ask_again", False) else "")
                if not getattr(e, "ask_again", False):
                    # ★ 2.3.7 (review ER-06) — ต่อระบบไม่ได้/ใบรับรอง: ข้อความดิบของ requests ถูกตัดออกจากเหตุแล้ว (dol_api.net_reason)
                    #   ⇒ เก็บตัวจริง (exception ที่ซ้อนอยู่ข้างใน) ลง Log ให้ผู้ดูแลตามเรื่องได้
                    _log_err("DOL: เข้าสู่ระบบไม่สำเร็จ", e)
                self._ask(QtWidgets.QMessageBox.Warning, "เข้าสู่ระบบไม่สำเร็จ", str(e) + more)
            else:
                # ★ 2.3.7 (review ER-06) — เดิมแปะข้อความดิบของ exception · ตัวจริงลง Log
                _log_err("DOL: เข้าสู่ระบบผิดพลาด", e, Qgis.Critical)
                self._ask(QtWidgets.QMessageBox.Critical, "เข้าสู่ระบบผิดพลาด",
                          f"เข้าสู่ระบบ DOL ไม่สำเร็จ — {_net_err_text(e)}\nลองใหม่อีกครั้ง ({self._LOG_HINT})")
        finally:
            self._dol_end(ctx)

    # ---------- ★ 2.3.9 rc5 — ทางสุดท้าย: ค้นทะเบียน iLands ด้วยคีย์ (หน้า LIS · ต้อง login · ช้า) ----------
    #   เจ้าของงาน 11 ต.ค.: "มีบางแปลงที่ไม่มีรูปแปลงแต่มีทะเบียน จึงหาใน arcgis ไม่ได้" · "ให้เป็นทางสุดท้ายนะ เพราะใช้เวลานาน"
    #   เข้าสู่ระบบอยู่แล้ว ⇒ dol_api ค้นให้เองในงานเดียวกัน · ยังไม่เข้า ⇒ ถามก่อน (ตรงนี้) แล้วใช้กล่องเข้าสู่ระบบเดียวกับ 📐
    def _dol_offer_lis(self, res, req, ระวาง):
        """แผนที่กรมทุกชั้นไม่มีคีย์นี้ + ยังไม่ได้เข้าสู่ระบบ ⇒ ถามว่าจะค้นต่อในทะเบียน iLands ไหม
        คืน True = ไปต่อ (flow ยังไม่จบ) · False = ไม่ค้น (ผู้เรียกแสดงผลไม่พบตามเดิม)"""
        # ★ 2.3.11 — ค้นแบบล็อกสาขา: บอกว่าไม่มี "ในสาขานี้" (+ เลขนี้เป็นของสำนักงานอื่น) · ทะเบียนค้นเฉพาะสำนักงานของสาขา
        bo = str((res or {}).get("branch_office") or ((req or {}).get("attrs") or {}).get("office_seq") or "").strip()
        oo = str(((res or {}).get("other_office") or {}).get("office_seq") or "").strip()
        head = "แผนที่ของกรมไม่มีแปลงของสาขานี้ตามระวาง/เลขที่ดินนี้" if bo else "แผนที่ของกรมไม่มีแปลงตามระวาง/เลขที่ดินนี้"
        if (res or {}).get("arc_miss"):         # ★ 2.4.1 แผนที่มีเลขนี้ แต่ถามทะเบียนที่จุดกลางไม่ได้
            head = ("แผนที่ของกรมมีระวาง/เลขที่ดินนี้ แต่ระบบทะเบียนไม่มีข้อมูลที่ตำแหน่งของแปลงนั้น"
                    if res.get("arc_miss") == "udm_empty" else "แผนที่ของกรมมีระวาง/เลขที่ดินนี้ แต่ไม่มีพิกัดจุดกลางของแปลง")
        if oo:
            head += f"\n(บนแผนที่กรม เลขนี้เป็นแปลงของสำนักงานที่ดินอื่น รหัส {oo})"
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ค้นในทะเบียน iLands",
            f"{head}\nระวาง {ระวาง}\n\n"
            "บางแปลงมีทะเบียนแต่ยังไม่มีรูปบนแผนที่กรม — ค้นต่อในทะเบียนของ iLands"
            + (" (เฉพาะสำนักงานที่ดินของสาขานี้)" if bo else "") + " ไหม?\n"
            "(ต้องเข้าสู่ระบบด้วยบัญชีกรมที่ดิน · ใช้เวลาราว 5–10 วินาที)",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.Yes)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        req["lis_tried"] = True
        req["lis_base"] = res
        self._dol_lis_step(req)
        return True

    def _dol_lis_step(self, req):
        """เข้าสู่ระบบ (ถ้ายัง) แล้วค้นทะเบียน — กล่องเข้าสู่ระบบ/ลองซ้ำ 3 ครั้งแบบเดียวกับ 📐"""
        from .. import dol_api
        if dol_api.is_logged_in():
            self._dol_lis_search(req)
            return
        creds = self._dol_ask_credentials(user=getattr(self, "_dol_user", "") or "", err=req.pop("login_err", ""))
        if not creds:
            self._dol_lis_done(dict(req.get("lis_base") or {"not_found": True}, lis=None), req, final=True)
            return
        u, p = creds
        self._dol_user = u
        req["tries"] = req.get("tries", 0) + 1
        self._run_net("กำลังเข้าสู่ระบบ DOL...",
                      lambda: dol_api.login(u, p),
                      lambda _s, r=req: self._dol_step_done(r) and self._dol_lis_search(r),
                      lambda e, r=req: self._dol_lis_failed(e, r), req=req)

    def _dol_lis_search(self, req):
        from .. import dol_api
        a = req.get("attrs") or {}
        here = (req.get("lis_base") or {}).get("udm_here")
        self._run_net("กำลังค้นในทะเบียน iLands... (ทางสุดท้าย ใช้เวลาสักครู่)",
                      lambda: dol_api.lookup_parcel_lis(a.get("m1"), a.get("m2"), a.get("m3"), a.get("m4"),
                                                        a.get("scale"), a.get("landno"), zone=47,
                                                        near_xy=a.get("near_xy"), here=here,
                                                        office_seq=a.get("office_seq")),   # ★ 2.3.10 ล็อกสาขา
                      lambda r, q=req: self._dol_step_done(q) and self._dol_lis_done(r, q),
                      lambda e, q=req: self._dol_lis_failed(e, q), req=req)

    def _dol_lis_failed(self, e, req):
        """เข้าสู่ระบบ/ค้นทะเบียนไม่สำเร็จ — รหัสผิดหรือเซสชันหมด ⇒ ถามรหัสใหม่ (รวม 3 ครั้ง) · อื่น ๆ ⇒ แสดงผลไม่พบ + เหตุ"""
        from .. import dol_api
        if not self._dol_step_done(req):
            return
        if isinstance(e, dol_api.DOLAuthError) and getattr(e, "ask_again", False) and req.get("tries", 0) < 3:
            dol_api.logout()
            req["login_err"] = f"{e}\n(ลองแล้ว {req.get('tries', 0)} จาก 3 ครั้ง)"
            self._dol_lis_step(req)
            return
        _log_err("DOL: ค้นในทะเบียน iLands ไม่สำเร็จ", e)
        base = dict(req.get("lis_base") or {"not_found": True})
        base["lis"], base["lis_error"] = "error", (str(e) if isinstance(e, dol_api.DOLError) else _net_err_text(e))
        self._dol_lis_done(base, req, final=True)

    def _dol_lis_done(self, r, req, final=False):
        """ผลทะเบียน iLands → พบ = เปิดภาพลักษณ์/หลักฐานรังวัดตามโหมด · ไม่พบ = ข้อความไม่พบเดิม + "ทะเบียนก็ไม่มีเลขนี้"
        final = r เป็นผลที่จะแสดงตรง ๆ แล้ว (ผู้ใช้ไม่เข้าสู่ระบบ / ล้ม)"""
        if final or not isinstance(r, dict) or not r.get("not_found"):
            res = r
        else:
            res = dict(req.get("lis_base") or {"not_found": True}, lis="none")
        _cont = False
        try:
            _cont = bool(self._dol_show_result(res, req))
        finally:
            if not _cont:
                self._dol_end(req)
        return _cont

    def _survey_search(self, ctx=None):
        from .. import dol_api
        ctx = self._dol_ctx(ctx)
        a = ctx["attrs"]
        self._run_net(
            "กำลังค้นหาหลักฐานการรังวัด...",
            lambda: dol_api.search_cadastral(
                a.get("m1"), a.get("m2"), a.get("m3"), a.get("m4"),
                a.get("scale"), a.get("landno"), ctx["prov"], ctx["office"], zone=47),
            lambda recs, c=ctx: self._survey_show(recs, c),
            lambda e, c=ctx: self._survey_failed(e, c), req=ctx)

    def _survey_failed(self, e, ctx=None):
        from .. import dol_api
        ctx = self._dol_ctx(ctx)
        if isinstance(e, dol_api.DOLAuthError):
            dol_api.logout()
            # ★ 2.3.7 (review ER-04/UX-31) — ถามรหัสซ้ำเฉพาะเมื่อช่วยได้ (ยังไม่ได้เข้าสู่ระบบ / รหัสที่จำไว้ใช้ไม่ได้แล้ว)
            #   ในกล่องเดียว (บอกเหตุ + ชื่อเดิม) ไม่เกิน 3 ครั้งต่อรอบ · เดิมถามซ้ำทุก DOLAuthError ครั้งเดียว
            #   รวมตอนระบบกรมล่มที่ถูกนับเป็น "token หมดอายุ"
            if getattr(e, "ask_again", False) and ctx.get("tries", 0) < 3:
                ctx["login_err"] = str(e)
                self._survey_step(ctx)
                return
        try:
            if isinstance(e, dol_api.DOLAuthError):
                more = ("\n\nลองครบ 3 ครั้งแล้ว — เริ่มใหม่ได้ที่ปุ่ม 📐 หลักฐานการรังวัด"
                        if getattr(e, "ask_again", False) else "")
                self._ask(QtWidgets.QMessageBox.Warning, "หลักฐานการรังวัด", str(e) + more)
            else:
                # ★ 2.3.7 (review ER-04/DI-18) — คำตอบดิบจากระบบกรม (HTML/JSON) ลง Log ให้ผู้ดูแล ไม่ใส่ในกล่อง
                _d = getattr(e, "detail", "")
                if _d:
                    QgsMessageLog.logMessage(
                        f"ค้นหลักฐานการรังวัดไม่สำเร็จ: {e} — คำตอบจากระบบกรม: {_scrub(str(_d))[:2000]}",
                        "MLEP", Qgis.Warning)
                elif not isinstance(e, dol_api.DOLError):
                    _log_err("ค้นหลักฐานการรังวัดไม่สำเร็จ", e, Qgis.Critical)       # ★ 2.3.7 (ER-06) exception ที่ไม่คาดคิด
                self._ask(QtWidgets.QMessageBox.Critical, "ค้นหารังวัดผิดพลาด",
                          f"{_net_err_text(e)}\n(ค้นด้วยระวาง {self._dol_rawang_text(ctx.get('attrs'))} • สนง.{ctx.get('office')})")
        finally:
            self._dol_end(ctx)

    def _survey_show(self, recs, ctx=None):
        from .. import dol_api
        ctx = self._dol_ctx(ctx)
        a = ctx.get("attrs") or {}
        try:
            if not recs:
                self._ask(
                    QtWidgets.QMessageBox.Information, "ไม่พบหลักฐานการรังวัด",
                    "ไม่พบหลักฐานการรังวัดของแปลงนี้\n"
                    f"(ค้นด้วยระวาง {a.get('m1')} {a.get('m2')} {a.get('m3')}-"
                    f"{a.get('m4')} ที่ดิน {a.get('landno')} • สนง.{ctx.get('office')})"
                    + ("" if ctx.get("verified", True) else
                       "\n⚠️ รหัสสำนักงานมาจากผลค้นที่ระบบกรมยืนยันไม่ได้ว่าเป็นแปลงนี้"))
                return
            rec = recs[0] if len(recs) == 1 else self._choose_cadastral(recs)
            if rec is None:
                return
            url = dol_api.survey_doc_url(rec.get("CADASTRAL_SEQ"), "1")
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(url))
            self.iface.messageBar().pushMessage(
                "DOL", f"เปิดหลักฐานการรังวัด (พบ {len(recs)} รายการ) — "
                       f"CADASTRAL_SEQ {rec.get('CADASTRAL_SEQ')} · ระวาง {self._dol_rawang_text(a)}",
                level=3, duration=8)
        finally:
            self._dol_end(ctx)          # ★ 2.3.7 (review UX-31) — flow จบจริงตรงนี้ ⇒ ค่อยล้างไฮไลต์

    def _on_dol_fail(self, msg, req=None):
        req = self._dol_result_req(req)     # ★ 2.3.7 (review DI-21/UX-22) — คำขอที่ถูกยกเลิก/เก่า ⇒ ทิ้ง
        if req is None:
            return
        try:
            self._ask(QtWidgets.QMessageBox.Critical, "DOL ผิดพลาด", msg)
        finally:
            self._dol_end(req)

    # ---------- ★ 2.3.7 (review DI-21 · UX-22 · UX-31) — คำขอ DOL หนึ่งครั้ง = บริบทที่ผูกกับผลของมันเอง ----------
    #   เดิมสถานะอยู่บน self ร่วมกัน (_dol_mode / _dol_attrs / _survey_ctx / ไฮไลต์) และด่านกันยิงซ้อนอยู่หลังการเขียนทับ
    #   ⇒ ผลของแปลง A ที่มาช้าถูกแสดง/ค้นต่อด้วยระวาง โหมด และไฮไลต์ของแปลง B · กล่องรอปิดด้วย Esc ได้แต่งานยังวิ่ง
    #   req = {seq, mode, attrs, wait (มีขั้นเน็ตรอผล), abandoned (กดยกเลิก), ended, tries (กล่องเข้าสู่ระบบ), rb (ไฮไลต์),
    #          busy (กล่องรอค้น PARCEL_SEQ), prov/office/verified (ขั้นหลักฐานรังวัด)} · self._dol_req = คำขอล่าสุด
    def _dol_new_req(self, mode, attrs):
        self._dol_seq = getattr(self, "_dol_seq", 0) + 1
        req = {"seq": self._dol_seq, "mode": mode or "image", "attrs": attrs if attrs is not None else {}, "wait": False,
               "abandoned": False, "ended": False, "tries": 0}
        self._dol_req = req
        return req

    def _dol_live(self, req):
        """ผลของคำขอนี้ยังใช้ได้ไหม — False = ถูกยกเลิก / จบไปแล้ว / มีคำขอใหม่กว่า"""
        return bool(req) and not req.get("abandoned") and not req.get("ended") \
            and req is getattr(self, "_dol_req", None)

    def _dol_refuse_if_busy(self):
        """มีคำขอ DOL รอผลอยู่ (ยังไม่กดยกเลิก) ⇒ แจ้งแล้วคืน True — ต้องเรียกก่อนแตะสถานะใด ๆ"""
        req = getattr(self, "_dol_req", None)
        if not (req and req.get("wait") and self._dol_live(req)):
            return False
        try:
            _shown = req.get("dlg") is not None and req["dlg"].isVisible()
        except Exception:
            _shown = False
        if not _shown:
            # กล่องรอหายไปทั้งที่ยังนับว่ารอ (ไม่ควรเกิด เช่น ล้มกลางทางก่อนเริ่มงาน) ⇒ ทิ้งคำขอนั้น ไม่ให้ปุ่ม DOL ค้างตาย
            req["abandoned"] = True
            self._dol_end(req)
            return False
        self.iface.messageBar().pushMessage(
            "DOL", "กำลังค้นหาอยู่ — รอผลก่อนแล้วค่อยค้นใหม่ (หรือกด ยกเลิก ที่กล่องรอ)", level=1, duration=5)
        return True

    def _dol_wait_arm(self, busy, req, own=False):
        """กล่องรอของงาน DOL มีปุ่ม "ยกเลิก" จริง — ยกเลิก / Esc / กากบาท ⇒ ทิ้งผลของคำขอนี้แล้วค้นใหม่ได้ทันที
        (worker วิ่งต่อจนจบเอง: ห้าม terminate QThread · ยังถูกถือใน _net_workers จน finished ⇒ _reload_blocker เห็น)
        own=True = กล่องเป็นของคำขอ (ปิด/ลบตอนได้ผลหรือยกเลิก) · False = ของ _run_net (ลบเองตอนงานจบ)"""
        busy.setCancelButtonText("ยกเลิก")
        busy.canceled.connect(lambda _r=req: self._dol_cancel(_r))
        busy.rejected.connect(lambda _r=req: self._dol_cancel(_r))
        req["wait"] = True
        req["dlg"] = busy
        if own:
            req["busy"] = busy

    def _dol_cancel(self, req):
        if not req or not req.get("wait") or req.get("abandoned") or req.get("ended"):
            return          # ปิดกล่องเองตอนได้ผลแล้ว (close() ยิง canceled ด้วย) — ไม่ใช่การยกเลิก
        req["abandoned"] = True
        self._dol_end(req)
        try:
            self.iface.messageBar().pushMessage(
                "DOL", "ยกเลิกการค้นหาแล้ว — ผลที่ระบบกรมตอบกลับมาทีหลังจะไม่ถูกเปิด", level=0, duration=5)
        except Exception:
            pass

    def _dol_drop_busy(self, req):
        b = req.pop("busy", None) if req else None
        if b is None:
            return
        if getattr(self, "_dol_busy", None) is b:
            self._dol_busy = None
        try:
            b.hide()                    # hide ไม่ยิง canceled (close() ยิง)
            b.deleteLater()
        except Exception:
            pass

    def _dol_end(self, req):
        """จบ flow ของคำขอนี้จริง: ไม่รอผลแล้ว + ปิดกล่องรอ + ล้างไฮไลต์ของคำขอนี้
        (ไฮไลต์ที่เครื่องมืออื่นวาดทับไปแล้วไม่แตะ) · เรียกซ้ำได้"""
        if not req or req.get("ended"):
            return
        req["ended"] = True
        req["wait"] = False
        self._dol_drop_busy(req)
        rb = req.get("rb")
        if "rb" not in req or (rb is not None and getattr(self, "_dol_highlight", None) is rb):
            self._dol_clear_highlight()

    def _dol_result_req(self, req):
        """ผลของงานค้น PARCEL_SEQ มาถึง ⇒ คำขอที่จะใช้ต่อ หรือ None = ทิ้งผล (ถูกยกเลิก/เก่า/ปลั๊กอินถูกปิด)"""
        if req is None:
            # เรียกตรง (เทส/โค้ดเดิม) ⇒ ใช้โหมด/ระวางที่ตั้งไว้บน self เหมือนเดิม
            b = getattr(self, "_dol_busy", None)
            if b is not None:
                try:
                    b.close()
                except Exception:
                    pass
            return self._dol_new_req(getattr(self, "_dol_mode", "image"), getattr(self, "_dol_attrs", None))
        if not getattr(self, "_alive", True) or not self._dol_live(req):
            return None
        req["wait"] = False             # ก่อนปิดกล่อง (close() ยิง canceled)
        self._dol_drop_busy(req)
        return req

    def _dol_step_done(self, req):
        """ขั้นเน็ตของ flow หลักฐานรังวัด (_run_net) ได้ผล ⇒ True = ใช้ผลต่อ · False = ทิ้ง (ยกเลิก/เก่า)"""
        if not self._dol_live(req):
            return False
        req["wait"] = False
        return True

    def _dol_ctx(self, ctx):
        """บริบทของขั้นหลักฐานรังวัด: ctx ที่ส่งมากับผล หรือ self._survey_ctx (เรียกตรงแบบเดิม ⇒ ยกเป็นคำขอปัจจุบัน)"""
        if ctx is None:
            ctx = getattr(self, "_survey_ctx", None)
            if ctx is None:
                ctx = self._dol_new_req("survey", getattr(self, "_dol_attrs", None))
            elif ctx is not getattr(self, "_dol_req", None) and not ctx.get("ended"):
                for _k, _v in (("seq", 0), ("mode", "survey"), ("attrs", {}), ("wait", False),
                               ("abandoned", False), ("ended", False), ("tries", 0)):
                    ctx.setdefault(_k, _v)
                self._dol_req = ctx
        return ctx

    @staticmethod
    def _dol_rawang_text(a):
        a = a or {}
        return "%s %s %s-%s ที่ดิน %s" % (a.get("m1", "?"), a.get("m2", "?"), a.get("m3", "?"),
                                         a.get("m4", "?"), a.get("landno", "?"))

    def _dol_highlight_feature(self, geom, layer):
        """ไฮไลต์แปลงบนแผนที่ด้วยกรอบแดง"""
        self._dol_clear_highlight()
        if geom is None or geom.isEmpty():
            return
        canvas = self.iface.mapCanvas()
        rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(255, 0, 0))
        rb.setFillColor(QtGui.QColor(255, 0, 0, 50))
        rb.setWidth(3)
        rb.setToGeometry(geom, layer)
        rb.show()
        self._dol_highlight = rb
        # ไม่เรียก canvas.refresh() — rubber band วาดตัวเองอยู่แล้ว (เดิม refresh ทั้งแมพทุกครั้งที่ hover แปลง = หน่วง)

    def _dol_clear_highlight(self):
        rb = getattr(self, "_dol_highlight", None)
        if rb is not None:
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
            self._dol_highlight = None

    def _dol_on_hover(self, feat, layer):
        """ไฮไลต์แปลงใต้เมาส์ก่อนคลิก (ตัวช่วยตัดสินใจ)"""
        if feat is None:
            self._dol_clear_highlight()
            return
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass
