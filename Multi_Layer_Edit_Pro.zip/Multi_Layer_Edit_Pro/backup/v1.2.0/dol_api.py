"""
DOL iLands API client (self-contained) สำหรับ Multi-Layer Edit Pro
- login (CAS SSO)  -> รับ cookie DOL-TOKEN
- search_by_rawang (LIS QDocParcel) -> ค้นหาโฉนดด้วยเลขระวาง UTM

ใช้แค่ requests (มากับ QGIS) ไม่ต้องพึ่ง BeautifulSoup
"""

import re
import json
import base64
import hashlib
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---- เข้ารหัส/ถอดรหัสรหัสผ่าน (กันการอ่าน plaintext ใน QSettings) ----
# หมายเหตุ: คีย์ฝังในปลั๊กอิน = ระดับ obfuscation (กันการเห็นรหัสตรง ๆ)
# ถ้าต้องการความปลอดภัยสูงสุดควรใช้ QgsAuthManager (auth DB + master password)
_ENC_PREFIX = "enc:"
_ENC_SECRET = b"MultiLayerEditPro-DOL-iLands-secret-v1"


def _xor(data, key):
    return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))


def encrypt(plaintext):
    """เข้ารหัสรหัสผ่านก่อนเก็บลง QSettings"""
    if not plaintext:
        return ""
    key = hashlib.sha256(_ENC_SECRET).digest()
    raw = _xor(plaintext.encode("utf-8"), key)
    return _ENC_PREFIX + base64.b64encode(raw).decode("ascii")


def decrypt(token):
    """ถอดรหัส (รองรับค่าเดิมที่ยังเป็น plaintext)"""
    if not token:
        return ""
    if not token.startswith(_ENC_PREFIX):
        return token  # ค่าเก่าที่ยังไม่ได้เข้ารหัส
    try:
        key = hashlib.sha256(_ENC_SECRET).digest()
        raw = base64.b64decode(token[len(_ENC_PREFIX):].encode("ascii"))
        return _xor(raw, key).decode("utf-8")
    except Exception:
        return ""

BASE = "https://ilands.dol.go.th"
LOGIN_URL = f"{BASE}/dolauth/login"
QDOC_URL = f"{BASE}/LIS/Application/QDocParcel.aspx"

# ---- รหัส dropdown (จังหวัด ชลบุรี / นครนายก / ปทุมธานี) ----
PROVINCE = {"ชลบุรี": "11", "นครนายก": "17", "ปทุมธานี": "4"}

SCALE_MAP = {"500": "1", "1000": "2", "2000": "3", "4000": "5"}

LANDOFFICE = {
    "ชลบุรี": {
        "สำนักงานที่ดินจังหวัดชลบุรี": "258",
        "สำนักงานที่ดินจังหวัดชลบุรี สาขาบางละมุง": "371",
        "สำนักงานที่ดินจังหวัดชลบุรี สาขาบ้านบึง": "372",
        "สำนักงานที่ดินจังหวัดชลบุรี สาขาพนัสนิคม": "373",
        "สำนักงานที่ดินจังหวัดชลบุรี สาขาศรีราชา": "374",
        "สำนักงานที่ดินจังหวัดชลบุรี สาขาสัตหีบ": "375",
    },
    "นครนายก": {
        "สำนักงานที่ดินจังหวัดนครนายก": "264",
        "สำนักงานที่ดินจังหวัดนครนายก สาขาองครักษ์": "393",
    },
    "ปทุมธานี": {
        "สำนักงานที่ดินจังหวัดปทุมธานี": "251",
        "สำนักงานที่ดินจังหวัดปทุมธานี สาขาคลองหลวง": "453",
        "สำนักงานที่ดินจังหวัดปทุมธานี สาขาธัญบุรี": "454",
        "สำนักงานที่ดินจังหวัดปทุมธานี สาขาลำลูกกา": "456",
    },
}

RESULT_COLUMNS = [
    "ลำดับ", "เลขที่เอกสารสิทธิ", "pin_code", "เลขโฉนด", "เลขหน้าสำรวจ",
    "ระวาง_utm", "มาตราส่วน", "เลขที่ดิน_utm", "ตำบล", "อำเภอ", "จังหวัด",
    "ผู้ถือกรรมสิทธิ์", "สำนักงานที่ดิน", "landoffice_seq",
]


class DOLError(Exception):
    pass


class DOLAuthError(DOLError):
    """รหัสผู้ใช้/รหัสผ่านไม่ถูกต้อง หรือเข้าสู่ระบบไม่สำเร็จ"""
    pass


class DOLAuthExpired(DOLError):
    """เซสชัน/token หมดอายุระหว่างใช้งาน"""
    pass


def province_code(name):
    if name in PROVINCE:
        return PROVINCE[name]
    if name in PROVINCE.values():
        return name
    raise DOLError(f"ไม่รู้จักจังหวัด: {name}")


def scale_code(scale):
    s = str(scale).strip()
    if s in SCALE_MAP:
        return SCALE_MAP[s]
    if s in SCALE_MAP.values():
        return s
    raise DOLError(f"ไม่รู้จักมาตราส่วน: {scale}")


def doc_url(seq, plate_type="1"):
    """URL หน้าดูภาพเอกสาร (evdsimgs001) จากเลขที่เอกสารสิทธิ"""
    return (f"{BASE}/evd/pages/contents/evd/evdsimgs001.jsf"
            f"?id=1&readOnly=2&dataId={seq}&plateType={plate_type}&page=1")


class DOLClient:
    def __init__(self, verify=False, timeout=60):
        self.s = requests.Session()
        self.s.headers.update({
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
        })
        self.verify = verify
        self.timeout = timeout
        self.logged_in = False
        self._user = None
        self._pass = None

    # ---------- login ----------
    def login(self, username, password):
        # จำ credential ไว้ใช้ re-login เมื่อ token หมดอายุ
        self._user = username
        self._pass = password

        # 1) GET หน้า login เพื่อรับ cookie (JSESSIONID, F5)
        r = self.s.get(LOGIN_URL, verify=self.verify, timeout=self.timeout)
        r.raise_for_status()
        m = re.search(r'name="lt"\s+value="([^"]*)"', r.text)
        lt = m.group(1) if m else ""

        # 2) POST credentials
        payload = {
            "username": username, "password": password,
            "lt": lt, "_eventId": "submit", "warn": "true",
        }
        r = self.s.post(LOGIN_URL, data=payload, verify=self.verify,
                        timeout=self.timeout, allow_redirects=True)
        r.raise_for_status()

        if not self.s.cookies.get("DOL-TOKEN"):
            self.logged_in = False
            raise DOLAuthError("เข้าสู่ระบบไม่สำเร็จ — ตรวจสอบรหัสผู้ใช้/รหัสผ่าน")
        self.logged_in = True
        return self

    @staticmethod
    def _is_login_page(resp):
        """ตรวจว่า response เด้งกลับหน้า login (session/token หมดอายุ)"""
        return ("dolauth/login" in resp.url
                or "Single Sign On" in resp.text
                or "__VIEWSTATE" not in resp.text)

    # ---------- helpers ----------
    @staticmethod
    def _hidden(html, name):
        m = (re.search(rf'id="{name}"\s+value="([^"]*)"', html)
             or re.search(rf'name="{name}"\s+value="([^"]*)"', html))
        return m.group(1) if m else ""

    @staticmethod
    def _parse_grid(delta_html):
        i = delta_html.find('id="gvwSearchResultList"')
        if i < 0:
            return []
        start = delta_html.rfind("<table", 0, i + 5)
        end = delta_html.find("</table>", i)
        tbl = delta_html[start:end + 8]
        rows = re.findall(r"<tr[^>]*>(.*?)</tr>", tbl, re.S)
        out = []
        for row in rows[1:]:
            cells = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.S)
            vals = [re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", c)).strip() for c in cells]
            vals = [v for v in vals if v != ""]
            if not vals:
                continue
            rec = {RESULT_COLUMNS[j]: vals[j]
                   for j in range(min(len(vals), len(RESULT_COLUMNS)))}
            seq = rec.get("เลขที่เอกสารสิทธิ", "")
            if seq:
                rec["doc_url"] = doc_url(seq, "1")
            out.append(rec)
        return out

    # ---------- search ----------
    def search_by_rawang(self, *, utmmap, scale, page, landno,
                         province="ชลบุรี", landoffice="374", landno_to=""):
        if not self.logged_in:
            raise DOLError("ยังไม่ได้ login")

        prov = province_code(province)
        sc = scale_code(scale)
        lo = LANDOFFICE.get(province, {}).get(landoffice, landoffice)

        # 1) GET ดึง viewstate สด + กันชน token หมดอายุ (re-login อัตโนมัติ 1 ครั้ง)
        g = self.s.get(QDOC_URL, verify=self.verify, timeout=self.timeout)
        g.raise_for_status()
        if self._is_login_page(g):
            if self._user and self._pass:
                self.login(self._user, self._pass)  # ต่อ token ใหม่
                g = self.s.get(QDOC_URL, verify=self.verify, timeout=self.timeout)
                g.raise_for_status()
                if self._is_login_page(g):
                    raise DOLAuthExpired("เซสชันหมดอายุ และเข้าสู่ระบบใหม่ไม่สำเร็จ")
            else:
                raise DOLAuthExpired("เซสชันหมดอายุ — กรุณาเข้าสู่ระบบใหม่")
        html = g.text

        # 2) POST ค้นหา (ASP.NET UpdatePanel async postback)
        headers = {
            "X-Requested-With": "XMLHttpRequest",
            "X-MicrosoftAjax": "Delta=true",
            "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
            "Cache-Control": "no-cache", "Origin": BASE, "Referer": QDOC_URL,
        }
        form = {
            "ScriptManager1": "UpdatePanel1|btnSearch", "CurrentControlId": "none",
            "ddlProvince": prov, "ddlLandOffice": lo, "ddlAmphur": "0",
            "txtPinCode": "",
            "txtParcelLandNoFrom": "", "txtParcelLandNoTo": "",
            "txtParcelLandSurveyNoFrom": "", "txtParcelLandSurveyNoTo": "",
            "SelectCriteria": "radParcelLandUTMMap",
            "txtUTMMap": utmmap, "ddlUTMScale": sc, "ddlUTMPage": page or "00",
            "txtUTMLandNo": landno, "txtUTMLandNoTo": landno_to,
            "txtTotalRecord": "0", "ddlRecordPerPage": "10",
            "txtGoToPage": "", "txtCurrentPage": "1", "txtTotalPage": "1",
            "__EVENTTARGET": "btnSearch", "__EVENTARGUMENT": "", "__LASTFOCUS": "",
            "__VIEWSTATE": self._hidden(html, "__VIEWSTATE"),
            "__VIEWSTATEGENERATOR": self._hidden(html, "__VIEWSTATEGENERATOR"),
            "__EVENTVALIDATION": self._hidden(html, "__EVENTVALIDATION"),
            "__SCROLLPOSITIONX": "0", "__SCROLLPOSITIONY": "0",
            "__VIEWSTATEENCRYPTED": "", "__ASYNCPOST": "true",
        }
        r = self.s.post(QDOC_URL, data=form, headers=headers,
                        verify=self.verify, timeout=self.timeout)
        r.raise_for_status()
        return self._parse_grid(r.text)


# ============================================================
#  ArcGIS + UDM (public — ไม่ต้อง login) : ระวาง -> PARCEL_SEQ
#  เชนทนทาน: ใช้ attribute เลขระวาง (ไม่พึ่งตำแหน่ง polygon ใน QGIS)
#  ① ArcGIS หา centroid ทางการ + MAP_PARCEL_SEQ
#  ② UDM GetMapInformation(centroid) -> strRegParcelSeq (=PARCEL_SEQ) + ข้อมูลครบ
# ============================================================
ARCGIS_PARCEL_LAYER = {
    47: "https://ilands.dol.go.th/arcgis/rest/services/MapDOL_47/MapServer/6",
    48: "https://ilands.dol.go.th/arcgis/rest/services/MapDOL_48/MapServer/6",
}
UDM_MAPINFO_URL = f"{BASE}/UDM_MAP/frmMain.aspx/GetMapInformation"


def _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                        zone=47, timeout=20):
    """ค้นแปลงใน ArcGIS ด้วย attribute เลขระวาง -> centroid ทางการ + MAP_PARCEL_SEQ"""
    layer = ARCGIS_PARCEL_LAYER.get(int(zone))
    if not layer:
        raise DOLError(f"ไม่รองรับ zone {zone}")
    where = (f"UTMMAP1='{utmmap1}' AND UTMMAP2={int(utmmap2)} AND UTMMAP3='{utmmap3}' "
             f"AND UTMMAP4='{utmmap4}' AND UTMSCALE={int(scale)} AND LAND_NO='{landno}'")
    params = {
        "where": where,
        "outFields": "MAP_PARCEL_SEQ,ORIGIN_X,ORIGIN_Y,LANDOFFICE_SEQ,LAND_NO",
        "returnGeometry": "false", "f": "json",
    }
    r = requests.get(f"{layer}/query", params=params, verify=False, timeout=timeout)
    r.raise_for_status()
    feats = r.json().get("features", [])
    return feats[0]["attributes"] if feats else None


def get_map_information(x, y, zone=47, parcel_type=1, timeout=20):
    """UDM GetMapInformation: พิกัด (X,Y datum 24047) -> ข้อมูลแปลง (dict)"""
    payload = {"Zone": str(zone), "X": str(x), "Y": str(y),
               "PARCEL_TYPE": str(parcel_type), "pid": "", "pr_Sys": "udm"}
    headers = {"Content-Type": "application/json; charset=utf-8",
               "X-Requested-With": "XMLHttpRequest"}
    r = requests.post(UDM_MAPINFO_URL, data=json.dumps(payload), headers=headers,
                      verify=False, timeout=timeout)
    r.raise_for_status()
    return json.loads(r.json()["d"])  # {"d":"<json string>"} -> dict


def lookup_parcel_by_rawang(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno,
                            zone=47, parcel_type=1):
    """
    ระวาง(attribute) -> PARCEL_SEQ + ข้อมูลแปลง  (public, ~90ms)
    คืน dict (มี key 'verified') หรือ None ถ้าไม่พบ
    """
    arc = _arcgis_find_parcel(utmmap1, utmmap2, utmmap3, utmmap4, scale, landno, zone)
    if not arc:
        return None
    d = get_map_information(arc["ORIGIN_X"], arc["ORIGIN_Y"], zone, parcel_type)
    map_seq = str(arc.get("MAP_PARCEL_SEQ"))
    return {
        "parcel_seq": d.get("strRegParcelSeq"),       # PARCEL_SEQ ฝั่งโฉนด (ที่ต้องการ)
        "map_parcel_seq": d.get("strMapParcelSeq"),
        "parcel_no": d.get("strParcelNo"),            # เลขโฉนด
        "land_no": d.get("strLandNo"),
        "survey_no": d.get("strSurveyNo"),            # หน้าสำรวจ
        "rawang": d.get("strRawang"),
        "area": d.get("strArea"),
        "owner": d.get("strOwner"),
        "city": d.get("strCity"),
        "office": d.get("strOfficeSname"),
        "office_seq": d.get("strOfficeSeq"),
        "parcel_type": d.get("strParcel_Type"),
        # กันพลาด: centroid ต้องตกบนแปลง MAP_PARCEL_SEQ เดิม
        "verified": str(d.get("strMapParcelSeq")) == map_seq,
        "doc_url": doc_url(d.get("strRegParcelSeq"), "1"),
    }
