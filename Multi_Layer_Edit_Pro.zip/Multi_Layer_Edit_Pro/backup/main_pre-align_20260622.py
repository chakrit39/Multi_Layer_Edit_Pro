import os
import re
import math
import requests
import zipfile
import io
import difflib
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import (QgsProject, QgsPointXY, QgsPoint, QgsGeometry, QgsPointLocator,
                       QgsSnappingConfig, QgsTolerance, QgsLineString, QgsWkbTypes,
                       QgsFeatureRequest, QgsSpatialIndex)
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsVertexMarker, QgsRubberBand, QgsSnapIndicator
from qgis.core import QgsRectangle, QgsCoordinateTransform, QgsCoordinateReferenceSystem
from qgis.utils import iface


class AutoTransformDialog(QtWidgets.QDialog):
    """Dialog สำหรับ Auto Transform โดยย้ายและส่งผ่านพิกัดแบบลูกโซ่ (Chained Propagation)"""

    def __init__(self, plugin, poly_lyr, point_lyr):
        super().__init__(plugin.iface.mainWindow())
        self.plugin     = plugin
        self.poly_lyr   = poly_lyr
        self.point_lyr  = point_lyr
        self.canvas     = plugin.iface.mapCanvas()

        self.ref_feats      = []     # QgsFeature list ของกลุ่มแปลงอ้างอิงเริ่มต้น
        self.tgt_feats      = []     # QgsFeature list ของกลุ่มแปลงเป้าหมายที่จะขยับ
        self.chained_results = []    # ผลลัพธ์คำนวณ: [{'poly_id', 'utm', 'success', 'pairs_count', 'matrix', 'new_geom', 'new_points'}]
        self.preview_items  = []     # RubberBand + VertexMarker สำหรับวาดบนแผนที่

        self.setWindowTitle("Auto Transform — จับคู่หมุดสะสมแบบลูกโซ่")
        self.setMinimumWidth(580)
        self._build_ui()

    # ─────────────────────────── UI ────────────────────────────────────
    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        # Step 1: Reference Selection
        grp_ref = QtWidgets.QGroupBox("1. กลุ่มอ้างอิง (Reference) — เลือกแปลงเริ่มต้นที่เป็นพิกัดที่ถูกต้อง แล้วกดปุ่ม")
        r_lay = QtWidgets.QHBoxLayout(grp_ref)
        btn_ref = QtWidgets.QPushButton("📌 ตั้งค่าจาก Selection ปัจจุบัน")
        btn_ref.clicked.connect(self._set_ref)
        self.ref_lbl = QtWidgets.QLabel("ยังไม่ได้เลือก")
        r_lay.addWidget(btn_ref)
        r_lay.addWidget(self.ref_lbl, 1)
        layout.addWidget(grp_ref)

        # Step 2: Target Selection
        grp_tgt = QtWidgets.QGroupBox("2. กลุ่มเป้าหมาย (Target) — เลือกกลุ่มแปลงที่ต้องการให้ขยับพิกัดตามอ้างอิง")
        t_lay = QtWidgets.QHBoxLayout(grp_tgt)
        btn_tgt = QtWidgets.QPushButton("🎯 ตั้งค่าจาก Selection ปัจจุบัน")
        btn_tgt.clicked.connect(self._set_tgt)
        self.tgt_lbl = QtWidgets.QLabel("ยังไม่ได้เลือก")
        t_lay.addWidget(btn_tgt)
        t_lay.addWidget(self.tgt_lbl, 1)
        layout.addWidget(grp_tgt)

        # Step 3: Matching Settings
        grp_opt = QtWidgets.QGroupBox("3. รูปแบบและเงื่อนไขการจับคู่หมุดแปลงที่ดิน")
        o_lay = QtWidgets.QGridLayout(grp_opt)
        
        o_lay.addWidget(QtWidgets.QLabel("วิธีการจับคู่:"), 0, 0)
        self.method_cb = QtWidgets.QComboBox()
        self.method_cb.addItems([
            "ชื่อหมุดตรงกัน (Strict Name Matching)",
            "ชื่อหมุดใกล้เคียง (Fuzzy Name Matching)",
            "ระยะห่างหมุดเดิม (Point Proximity Matching)",
            "จุดมุมแปลงเดิม (Vertex Proximity Matching)"
        ])
        o_lay.addWidget(self.method_cb, 0, 1)
        
        o_lay.addWidget(QtWidgets.QLabel("ความคลาดเคลื่อนค้นหา (เมตร):"), 1, 0)
        self.tol_sb = QtWidgets.QDoubleSpinBox()
        self.tol_sb.setRange(0.01, 100.0)
        self.tol_sb.setValue(2.0)
        self.tol_sb.setSingleStep(0.5)
        o_lay.addWidget(self.tol_sb, 1, 1)
        
        o_lay.addWidget(QtWidgets.QLabel("ความคล้ายคลึงชื่อหมุดขั้นต่ำ (%):"), 2, 0)
        self.sim_sb = QtWidgets.QSpinBox()
        self.sim_sb.setRange(50, 100)
        self.sim_sb.setValue(90)
        self.sim_sb.setSuffix(" %")
        o_lay.addWidget(self.sim_sb, 2, 1)
        
        # เชื่อมต่อสัญญาณเพื่อปิด/เปิดช่องกรอกข้อมูลให้เหมาะสม
        self.method_cb.currentIndexChanged.connect(self._on_method_changed)
        self._on_method_changed(0)
        
        layout.addWidget(grp_opt)

        # Run & Calculate Button
        self.btn_run = QtWidgets.QPushButton("🚀 เริ่มคำนวณพิกัดสะสมแบบลูกโซ่ & Preview")
        self.btn_run.setStyleSheet("padding: 10px; font-weight: bold; background-color: #ede7f6; color: #4527a0;")
        self.btn_run.clicked.connect(self._update_preview)
        layout.addWidget(self.btn_run)

        # Progress Table
        progress_grp = QtWidgets.QGroupBox("ความคืบหน้าการส่งผ่านพิกัด ( Chained Transform Progress )")
        p_vlay = QtWidgets.QVBoxLayout(progress_grp)
        
        self.pair_count_lbl = QtWidgets.QLabel("ยังไม่ได้คำนวณ")
        p_vlay.addWidget(self.pair_count_lbl)

        self.table = QtWidgets.QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(
            ["แปลงที่ดิน (UTM)", "คู่เชื่อมต่อหลัก", "สถานะการประมวลผล"]
        )
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        hh.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QtWidgets.QHeaderView.Stretch)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.NoSelection)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(200)
        p_vlay.addWidget(self.table)
        layout.addWidget(progress_grp)

        # Bottom info
        self.info_lbl = QtWidgets.QLabel("เส้นพรีวิว: 🟠 = ตำแหน่งแปลงใหม่  🟢+ = หมุดตำแหน่งใหม่")
        self.info_lbl.setStyleSheet("color: #555; font-style: italic;")
        layout.addWidget(self.info_lbl)

        # OK / Cancel
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        layout.addWidget(line)
        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
        )
        btns.button(QtWidgets.QDialogButtonBox.Ok).setText("✅  ตกลง — บันทึกพิกัด")
        btns.button(QtWidgets.QDialogButtonBox.Ok).setStyleSheet(
            "background-color:#c8e6c9; font-weight:bold; padding:8px; color:#1b5e20;"
        )
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _on_method_changed(self, index):
        # index 0: Strict Name, 1: Fuzzy Name, 2: Point Proximity, 3: Vertex Proximity
        # เปิดให้แก้ไขค่า % ความคล้ายคลึงเฉพาะโหมดที่ใช้ชื่อหมุดจับคู่ (0 และ 1)
        self.sim_sb.setEnabled(index in (0, 1))
        # เปิดให้แก้ไขค่าความคลาดเคลื่อนค้นหาเฉพาะโหมดจับคู่เชิงพื้นที่ (2 และ 3)
        self.tol_sb.setEnabled(index in (2, 3))

    # ─────────────────────────── helpers ───────────────────────────────
    def _get_utm_vals(self, poly_feats):
        """ดึงค่า UTM field จาก polygon features"""
        utm_field = next(
            (f.name() for f in self.poly_lyr.fields()
             if f.name().lower() in {'utm', 'utm_code', 'utm_id'}),
            None
        )
        if not utm_field:
            return set(), None
        vals = set()
        for f in poly_feats:
            v = f[utm_field]
            if v is not None:
                vals.add(str(v).strip())
        return vals, utm_field

    def _get_all_associated_points(self, poly_feats):
        """ดึงจุดหมุดทั้งหมดของแปลงที่กำหนด (ทำแบบ Batch คิวรี่รอบเดียวเพื่อความเร็ว)"""
        if not poly_feats:
            return {}

        poly_utm_field = next(
            (f.name() for f in self.poly_lyr.fields()
             if f.name().lower() in {'utm', 'utm_code', 'utm_id'}),
            None
        )
        point_utm_field = next(
            (f.name() for f in self.point_lyr.fields()
             if f.name().lower() in {'utm', 'utm_code', 'utm_id'}),
            None
        )
        if not poly_utm_field or not point_utm_field:
            return {}

        utm_vals = set()
        for f in poly_feats:
            v = f[poly_utm_field]
            if v is not None:
                utm_vals.add(str(v).strip())
        if not utm_vals:
            return {}

        extent = None
        for f in poly_feats:
            if f.hasGeometry():
                geom = f.geometry()
                if not geom.isNull():
                    if extent is None:
                        extent = geom.boundingBox()
                    else:
                        extent.combineExtentWith(geom.boundingBox())

        quoted = ", ".join(f"'{v}'" for v in utm_vals)
        expr = f'"{point_utm_field}" IN ({quoted})'
        req = QgsFeatureRequest().setFilterExpression(expr)
        
        if extent is not None:
            poly_crs = self.poly_lyr.crs()
            point_crs = self.point_lyr.crs()
            if poly_crs != point_crs:
                from qgis.core import QgsCoordinateTransform
                transform = QgsCoordinateTransform(poly_crs, point_crs, QgsProject.instance())
                extent = transform.transformBoundingBox(extent)
            # ขยายขอบเขตพอสมควรเพื่อให้แน่ใจว่าครอบคลุมหมด
            extent.grow(max(extent.width(), extent.height()) * 0.05 + 100.0)
            req.setFilterRect(extent)

        pts_by_utm = {}
        for pt in self.point_lyr.getFeatures(req):
            utm_val = pt[point_utm_field]
            if utm_val is not None:
                utm_str = str(utm_val).strip()
                if utm_str not in pts_by_utm:
                    pts_by_utm[utm_str] = []
                pts_by_utm[utm_str].append(pt)

        poly_points = {}
        for f in poly_feats:
            utm_val = f[poly_utm_field]
            if utm_val is not None:
                utm_str = str(utm_val).strip()
                poly_points[f.id()] = pts_by_utm.get(utm_str, [])
            else:
                poly_points[f.id()] = []

        return poly_points

    def _select_best_two_pairs(self, pairs):
        """เลือก 2 คู่ที่พิกัดเป้าหมายอยู่ห่างกันที่สุดเพื่อลดความคลาดเคลื่อนทางคณิตศาสตร์"""
        if len(pairs) == 2:
            return pairs[0], pairs[1]
        best_i, best_j, max_d = 0, 1, -1.0
        for i in range(len(pairs)):
            for j in range(i+1, len(pairs)):
                p1 = pairs[i]['tgt_xy']
                p2 = pairs[j]['tgt_xy']
                d = math.sqrt((p1.x()-p2.x())**2 + (p1.y()-p2.y())**2)
                if d > max_d:
                    max_d, best_i, best_j = d, i, j
        return pairs[best_i], pairs[best_j]

    def _compute_matrix(self, p1, p2):
        """Similarity transform: target (ตำแหน่งผิด) → reference (ตำแหน่งถูก)"""
        s1, d1 = p1['tgt_xy'], p1['ref_xy']
        s2, d2 = p2['tgt_xy'], p2['ref_xy']
        dsx, dsy = s2.x()-s1.x(), s2.y()-s1.y()
        ddx, ddy = d2.x()-d1.x(), d2.y()-d1.y()
        mag_sq = dsx**2 + dsy**2
        if mag_sq == 0:
            return None
        a = (dsx*ddx + dsy*ddy) / mag_sq
        b = (dsx*ddy - dsy*ddx) / mag_sq
        tx = d1.x() - (a*s1.x() - b*s1.y())
        ty = d1.y() - (b*s1.x() + a*s1.y())
        return QtGui.QTransform(a, b, -b, a, tx, ty)

    def _set_ref(self):
        feats = list(self.poly_lyr.selectedFeatures())
        if not feats:
            QtWidgets.QMessageBox.warning(self, "ไม่พบ Selection",
                "กรุณาเลือกแปลงอ้างอิงบนแผนที่ก่อน แล้วกลับมากดปุ่มนี้")
            return
        self.ref_feats = feats
        self.ref_lbl.setText(f"✓  {len(feats)} แปลง")
        self.ref_lbl.setStyleSheet("color:#1b5e20; font-weight:bold;")
        self._reset_pairs()

    def _set_tgt(self):
        feats = list(self.poly_lyr.selectedFeatures())
        if not feats:
            QtWidgets.QMessageBox.warning(self, "ไม่พบ Selection",
                "กรุณาเลือกแปลงเป้าหมายบนแผนที่ก่อน แล้วกลับมากดปุ่มนี้")
            return
        self.tgt_feats = feats
        self.tgt_lbl.setText(f"✓  {len(feats)} แปลง")
        self.tgt_lbl.setStyleSheet("color:#1565c0; font-weight:bold;")
        self._reset_pairs()

    def _reset_pairs(self):
        self.chained_results = []
        self.table.setRowCount(0)
        self.pair_count_lbl.setText("ยังไม่ได้คำนวณ")
        self._clear_preview()

    def _normalize_name(self, name):
        if name is None:
            return ""
        s = str(name).strip().lower()
        s = re.sub(r'[\s\.\-\_\,\/\\#]', '', s)
        return s

    def _get_polygon_vertices(self, geom):
        vertices = []
        if geom.isNull():
            return vertices
        for vertex in geom.vertices():
            vertices.append(QgsPointXY(vertex.x(), vertex.y()))
        return vertices

    # ─────────────────────────── core logic ────────────────────────────
    def _run_chained_transform(self):
        """คำนวณการส่งผ่านพิกัดแบบลูกโซ่ทีละแปลงสะสม"""
        if not self.ref_feats:
            return False, "กรุณาตั้งค่ากลุ่มอ้างอิงก่อน (ข้อ 1)"
        if not self.tgt_feats:
            return False, "กรุณาตั้งค่ากลุ่มเป้าหมายก่อน (ข้อ 2)"

        poly_utm_field = next(
            (f.name() for f in self.poly_lyr.fields()
             if f.name().lower() in {'utm', 'utm_code', 'utm_id'}),
            None
        )
        if not poly_utm_field:
            return False, "ไม่พบฟิลด์ UTM ใน Polygon Layer"

        method = self.method_cb.currentIndex()
        tol = self.tol_sb.value()

        # 1. โหลดข้อมูลจุดอ้างอิงเริ่มต้น
        ref_points_by_poly = self._get_all_associated_points(self.ref_feats)
        
        # โครงสร้างสำหรับเก็บ reference ตามแต่ละวิธี
        solved_ref_pts = {}  # normalized_name -> QgsPointXY (สำหรับ Name-based)
        solved_pts_list = [] # [{'orig_xy', 'correct_xy'}] (สำหรับ Point Proximity)
        solved_vertices = [] # [{'orig_xy', 'correct_xy'}] (สำหรับ Vertex Proximity)

        # เตรียมข้อมูลเริ่มต้นจากกลุ่มอ้างอิง
        if method in (0, 1): # Strict หรือ Fuzzy Name
            for fid, pts in ref_points_by_poly.items():
                for pt in pts:
                    name_val = pt['BND_NAME']
                    if name_val is not None:
                        name_str = str(name_val).strip()
                        if name_str:
                            key = self._normalize_name(name_str) if method == 1 else name_str.lower()
                            if key:
                                solved_ref_pts[key] = pt.geometry().asPoint()
        elif method == 2: # Point Proximity
            for fid, pts in ref_points_by_poly.items():
                for pt in pts:
                    xy = pt.geometry().asPoint()
                    solved_pts_list.append({'orig_xy': xy, 'correct_xy': xy})
        elif method == 3: # Vertex Proximity
            for f in self.ref_feats:
                if f.hasGeometry():
                    vertices = self._get_polygon_vertices(f.geometry())
                    for v in vertices:
                        solved_vertices.append({'orig_xy': v, 'correct_xy': v})

        # 2. โหลดจุดหมุดของแปลงเป้าหมายทั้งหมดแบบ Batch
        tgt_points_by_poly = self._get_all_associated_points(self.tgt_feats)

        self.chained_results = []
        remaining_targets = list(self.tgt_feats)

        # 3. ลูปค้นหาขยับแปลงทีละก้าว (Chained Propagation Loop)
        poly_type_idx = -1
        for i, field in enumerate(self.poly_lyr.fields()):
            if field.name().lower() == 'type':
                poly_type_idx = i
                break

        propagated_in_loop = True
        while remaining_targets and propagated_in_loop:
            propagated_in_loop = False

            for tgt_poly in remaining_targets:
                # กฎการล็อก: แปลงที่มีประเภท L1-RTK และ L1-TS ไม่สามารถขยับโดย Auto Transform
                if poly_type_idx != -1:
                    type_val = tgt_poly.attribute(poly_type_idx)
                    if type_val is not None:
                        type_str = str(type_val).strip().upper()
                        if type_str in ("L1-RTK", "L1-TS"):
                            self.chained_results.append({
                                'poly_id': tgt_poly.id(),
                                'utm': str(tgt_poly[poly_utm_field]),
                                'success': False,
                                'pairs_count': 0,
                                'matrix': None,
                                'new_geom': None,
                                'new_points': []
                            })
                            remaining_targets.remove(tgt_poly)
                            propagated_in_loop = True
                            break

                pts = tgt_points_by_poly.get(tgt_poly.id(), [])
                matching_pairs = []

                # ทำการจับคู่ตามแต่ละวิธี
                if method in (0, 1): # Name-based (0: Strict, 1: Fuzzy)
                    threshold = self.sim_sb.value() / 100.0
                    for pt in pts:
                        name_val = pt['BND_NAME']
                        if name_val is not None:
                            name_str = str(name_val).strip()
                            if name_str:
                                tgt_key = self._normalize_name(name_str) if method == 1 else name_str.lower()
                                
                                # หาชื่อหมุดที่คล้ายคลึงที่สุดในกลุ่มอ้างอิงสะสม
                                best_ref_key = None
                                max_ratio = 0.0
                                for ref_key in solved_ref_pts.keys():
                                    if tgt_key == ref_key:
                                        ratio = 1.0
                                    else:
                                        ratio = difflib.SequenceMatcher(None, tgt_key, ref_key).ratio()
                                    if ratio > max_ratio:
                                        max_ratio = ratio
                                        best_ref_key = ref_key
                                
                                if best_ref_key and max_ratio >= threshold:
                                    matching_pairs.append({
                                        'tgt_xy': pt.geometry().asPoint(),
                                        'ref_xy': solved_ref_pts[best_ref_key]
                                    })
                elif method == 2: # Point Proximity
                    for pt in pts:
                        tgt_xy = pt.geometry().asPoint()
                        best_match = None
                        min_dist = tol
                        for s_pt in solved_pts_list:
                            dist = math.sqrt(tgt_xy.sqrDist(s_pt['orig_xy']))
                            if dist < min_dist:
                                min_dist = dist
                                best_match = s_pt
                        if best_match:
                            matching_pairs.append({
                                'tgt_xy': tgt_xy,
                                'ref_xy': best_match['correct_xy']
                            })
                elif method == 3: # Vertex Proximity
                    if tgt_poly.hasGeometry():
                        tgt_vertices = self._get_polygon_vertices(tgt_poly.geometry())
                        for v_xy in tgt_vertices:
                            best_match = None
                            min_dist = tol
                            for s_v in solved_vertices:
                                dist = math.sqrt(v_xy.sqrDist(s_v['orig_xy']))
                                if dist < min_dist:
                                    min_dist = dist
                                    best_match = s_v
                            if best_match:
                                matching_pairs.append({
                                    'tgt_xy': v_xy,
                                    'ref_xy': best_match['correct_xy']
                                })

                # ถ้าหาคู่เชื่อมต่อได้ตั้งแต่ 2 คู่ขึ้นไป
                if len(matching_pairs) >= 2:
                    best_p1, best_p2 = self._select_best_two_pairs(matching_pairs)
                    matrix = self._compute_matrix(best_p1, best_p2)

                    if matrix:
                        # คำนวณขยับ Polygon
                        orig_geom = tgt_poly.geometry()
                        new_geom = QgsGeometry(orig_geom)
                        new_geom.transform(matrix)

                        # คำนวณขยับพิกัดหมุดทั้งหมดของแปลงนี้
                        new_pts_coords = []
                        for pt in pts:
                            pt_geom = QgsGeometry(pt.geometry())
                            pt_geom.transform(matrix)
                            new_pt_xy = pt_geom.asPoint()
                            new_pts_coords.append((pt.id(), pt_geom))

                            # ถ้าใช้โหมด Name หรือ Point Proximity ให้อัปเดตจุดอ้างอิงสะสม
                            if method in (0, 1):
                                name_val = pt['BND_NAME']
                                if name_val is not None:
                                    name_str = str(name_val).strip()
                                    if name_str:
                                        key = self._normalize_name(name_str) if method == 1 else name_str.lower()
                                        if key:
                                            solved_ref_pts[key] = new_pt_xy
                            elif method == 2:
                                solved_pts_list.append({
                                    'orig_xy': pt.geometry().asPoint(),
                                    'correct_xy': new_pt_xy
                                })

                        # ถ้าเป็นวิธี Vertex Proximity ให้อัปเดตโหนดมุมแปลงสะสม
                        if method == 3:
                            tgt_vertices = self._get_polygon_vertices(tgt_poly.geometry())
                            new_vertices = self._get_polygon_vertices(new_geom)
                            for orig_v, new_v in zip(tgt_vertices, new_vertices):
                                solved_vertices.append({
                                    'orig_xy': orig_v,
                                    'correct_xy': new_v
                                })

                        self.chained_results.append({
                            'poly_id': tgt_poly.id(),
                            'utm': str(tgt_poly[poly_utm_field]),
                            'success': True,
                            'pairs_count': len(matching_pairs),
                            'matrix': matrix,
                            'new_geom': new_geom,
                            'new_points': new_pts_coords
                        })

                        remaining_targets.remove(tgt_poly)
                        propagated_in_loop = True
                        break # ค้นหาแปลงถัดไปต่อในโซ่

        # 4. บันทึกแปลงที่หลุดกลุ่ม
        for tgt_poly in remaining_targets:
            self.chained_results.append({
                'poly_id': tgt_poly.id(),
                'utm': str(tgt_poly[poly_utm_field]),
                'success': False,
                'pairs_count': 0,
                'matrix': None,
                'new_geom': None,
                'new_points': []
            })

        success_count = sum(1 for r in self.chained_results if r['success'])
        return True, f"คำนวณสำเร็จ: {success_count}/{len(self.chained_results)} แปลง"

    def _populate_table_chained(self):
        self.table.setRowCount(0)
        for i, res in enumerate(self.chained_results):
            self.table.insertRow(i)

            item_utm = QtWidgets.QTableWidgetItem(res['utm'])
            self.table.setItem(i, 0, item_utm)

            pairs_str = f"{res['pairs_count']} คู่หมุด" if res['success'] else "—"
            item_pairs = QtWidgets.QTableWidgetItem(pairs_str)
            item_pairs.setTextAlignment(QtCore.Qt.AlignCenter)
            self.table.setItem(i, 1, item_pairs)

            status_str = "⭐ สำเร็จ" if res['success'] else "❌ หลุดกลุ่ม (ไม่มีคู่เชื่อม)"
            item_status = QtWidgets.QTableWidgetItem(status_str)
            self.table.setItem(i, 2, item_status)

            bg_color = QtGui.QColor("#e8f5e9") if res['success'] else QtGui.QColor("#ffebee")
            for col in range(3):
                cell = self.table.item(i, col)
                if cell:
                    cell.setBackground(bg_color)

        success_count = sum(1 for r in self.chained_results if r['success'])
        self.pair_count_lbl.setText(
            f"ประมวลผลผ่าน: {success_count} / {len(self.chained_results)} แปลง"
        )

    # ─────────────────────────── preview ───────────────────────────────
    def _update_preview(self):
        self._clear_preview()
        ok, msg = self._run_chained_transform()
        if not ok:
            QtWidgets.QMessageBox.warning(self, "คำนวณล้มเหลว", msg)
            return

        self._populate_table_chained()

        # ตรวจสอบเรื่องการแปลงพิกัดจุดสำหรับ QgsVertexMarker
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        layer_crs = self.poly_lyr.crs()
        reproject = (canvas_crs != layer_crs)
        if reproject:
            from qgis.core import QgsCoordinateTransform
            layer_to_canvas = QgsCoordinateTransform(layer_crs, canvas_crs, QgsProject.instance())

        # วาด Rubber Bands สำหรับพรีวิวแผนที่
        for res in self.chained_results:
            if res['success'] and res['new_geom']:
                band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
                band.setColor(QtGui.QColor(255, 140, 0))
                band.setFillColor(QtGui.QColor(255, 140, 0, 45))
                band.setWidth(2)
                band.setToGeometry(res['new_geom'], self.poly_lyr)
                self.preview_items.append(band)

                for pt_id, pt_geom in res['new_points']:
                    new_xy = pt_geom.asPoint()
                    marker_xy = layer_to_canvas.transform(new_xy) if reproject else new_xy
                    
                    m = QgsVertexMarker(self.canvas)
                    m.setCenter(marker_xy)
                    m.setColor(QtGui.QColor(0, 180, 0))
                    m.setIconType(QgsVertexMarker.ICON_CROSS)
                    m.setPenWidth(3)
                    self.preview_items.append(m)

        self.canvas.refresh()

    def _clear_preview(self):
        for item in self.preview_items:
            self.canvas.scene().removeItem(item)
        self.preview_items = []
        self.canvas.refresh()

    # ─────────────────────────── accept / reject ───────────────────────
    def accept(self):
        if not self.chained_results:
            ok, msg = self._run_chained_transform()
            if not ok:
                QtWidgets.QMessageBox.warning(self, "ข้อผิดพลาด", msg)
                return

        self._clear_preview()
        self.plugin._apply_chained_transform(
            self.poly_lyr, self.point_lyr, self.chained_results
        )
        super().accept()

    def reject(self):
        self._clear_preview()
        super().reject()

    def closeEvent(self, event):
        self._clear_preview()
        super().closeEvent(event)

    def reject(self):
        self._clear_preview()
        super().reject()

    def closeEvent(self, event):
        self._clear_preview()
        super().closeEvent(event)

class SemiAutoTransformTool(QgsMapTool):
    def __init__(self, canvas, plugin):
        super().__init__(canvas)
        self.canvas = canvas
        self.plugin = plugin
        self.poly_lyr = None
        self.point_lyr = None
        self.target_feat = None
        self.ref_feat = None
        self.matrix = None
        self.transformed_geom = None
        self.rubber_band = None
        self.vector_bands = []
        self.snap_indicator = QgsSnapIndicator(canvas)
        self.snap_utils = canvas.snappingUtils()
        
        # State: 0 = waiting for target click, 1 = showing preview, waiting for confirmation
        self.state = 0
        
    def canvasPressEvent(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self.reset_tool()
            return

        point = event.mapPoint()
        self.poly_lyr = QgsProject.instance().mapLayer(self.plugin.poly_cb.currentData())
        self.point_lyr = QgsProject.instance().mapLayer(self.plugin.point_cb.currentData())
        if not self.poly_lyr or not self.point_lyr:
            self.plugin.iface.messageBar().pushMessage("Error", "กรุณาตั้งค่าชั้นข้อมูล Polygon และ Point ก่อน", level=2)
            return

        if self.state == 0:
            # Find the target polygon clicked
            self.target_feat = self._find_polygon_at(point)
            if not self.target_feat:
                return
            
            # Lock rules verification
            type_idx = self.poly_lyr.fields().indexOf('type')
            if type_idx != -1:
                val = self.target_feat.attribute(type_idx)
                if val is not None and str(val).strip().upper() == "L1-RTK":
                    self.plugin.iface.messageBar().pushMessage("MLEP Lock", "แปลง L1-RTK ถูกล็อกพิกัดอ้างอิงหลัก ไม่สามารถขยับได้!", level=2)
                    self.reset_tool()
                    return

            success = self._find_best_reference_and_match()
            if success:
                self.state = 1
                self.plugin.iface.messageBar().pushMessage(
                    "Semi-Auto Preview", 
                    "แสดง Preview: คลิกซ้ายอีกครั้งเพื่อยอมรับและบันทึกพิกัดใหม่ หรือคลิกขวาเพื่อยกเลิก", 
                    level=1, duration=0
                )
            else:
                self.plugin.iface.messageBar().pushMessage("Semi-Auto Match", "ไม่พบแปลงอ้างอิงใกล้เคียงที่มีหมุดตรงกัน (อย่างน้อย 2 คู่)", level=2)
                self.reset_tool()
        
        elif self.state == 1:
            # Confirm transform (second left click)
            self._apply_transform()
            self.reset_tool()

    def canvasMoveEvent(self, event):
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
        match = self.snap_utils.snapToMap(event.mapPoint())
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

    def deactivate(self):
        self.clear_preview()
        if hasattr(self, 'snap_indicator') and self.snap_indicator:
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            self.snap_indicator = None
        super().deactivate()

    def _find_polygon_at(self, point):
        # แปลงพิกัดจาก Canvas CRS ไปเป็น Layer CRS
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        layer_crs = self.poly_lyr.crs()
        if canvas_crs != layer_crs:
            from qgis.core import QgsCoordinateTransform
            transform = QgsCoordinateTransform(canvas_crs, layer_crs, QgsProject.instance())
            layer_point = transform.transform(point)
        else:
            layer_point = point

        rect = QgsGeometry.fromPointXY(layer_point).buffer(1.0, 5).boundingBox()
        req = QgsFeatureRequest().setFilterRect(rect)
        
        best_feat = None
        min_dist = 99999.0
        pt_geom = QgsGeometry.fromPointXY(layer_point)
        
        for f in self.poly_lyr.getFeatures(req):
            geom = f.geometry()
            if geom.isNull():
                continue
            
            # ถ้าจุดคลิกอยู่ข้างในแปลงโดยตรง ให้ส่งคืนทันที
            if geom.contains(layer_point):
                return f
                
            # ถ้าไม่อยู่ข้างในตรงๆ (กรณีดึงดูด/snap ไปที่จุดมุมบนขอบแปลง) ให้ใช้ระยะทางที่ใกล้ที่สุดในรัศมี 1 เมตร
            d = geom.distance(pt_geom)
            if d < min_dist:
                min_dist = d
                best_feat = f
                
        if min_dist < 1.0:
            return best_feat
            
        return None

    def _get_poly_points(self, poly_feat):
        poly_utm_field = next((f.name() for f in self.poly_lyr.fields() if f.name().lower() in {'utm', 'utm_code', 'utm_id'}), None)
        point_utm_field = next((f.name() for f in self.point_lyr.fields() if f.name().lower() in {'utm', 'utm_code', 'utm_id'}), None)
        if not poly_utm_field or not point_utm_field:
            return []
            
        utm_val = poly_feat[poly_utm_field]
        if utm_val is None:
            return []
            
        expr = f'"{point_utm_field}" = \'{str(utm_val).strip()}\''
        req = QgsFeatureRequest().setFilterExpression(expr)
        
        bbox = poly_feat.geometry().boundingBox()
        bbox.grow(5.0)
        req.setFilterRect(bbox)
        
        return list(self.point_lyr.getFeatures(req))

    def _select_best_two_pairs(self, pairs):
        if len(pairs) == 2:
            return pairs[0], pairs[1]
        best_i, best_j, max_d = 0, 1, -1.0
        for i in range(len(pairs)):
            for j in range(i+1, len(pairs)):
                p1 = pairs[i]['tgt_xy']
                p2 = pairs[j]['tgt_xy']
                d = math.sqrt((p1.x()-p2.x())**2 + (p1.y()-p2.y())**2)
                if d > max_d:
                    max_d, best_i, best_j = d, i, j
        return pairs[best_i], pairs[best_j]

    def _compute_matrix(self, p1, p2):
        s1, d1 = p1['tgt_xy'], p1['ref_xy']
        s2, d2 = p2['tgt_xy'], p2['ref_xy']
        dsx, dsy = s2.x()-s1.x(), s2.y()-s1.y()
        ddx, ddy = d2.x()-d1.x(), d2.y()-d1.y()
        mag_sq = dsx**2 + dsy**2
        if mag_sq == 0:
            return None
        a = (dsx*ddx + dsy*ddy) / mag_sq
        b = (dsx*ddy - dsy*ddx) / mag_sq
        tx = d1.x() - (a*s1.x() - b*s1.y())
        ty = d1.y() - (b*s1.x() + a*s1.y())
        return QtGui.QTransform(a, b, -b, a, tx, ty)

    def _get_polygon_vertices(self, geom):
        vertices = []
        if geom.isNull():
            return vertices
        for vertex in geom.vertices():
            vertices.append(QgsPointXY(vertex.x(), vertex.y()))
        return vertices

    def _find_best_reference_and_match(self):
        geom = self.target_feat.geometry()
        bbox = geom.boundingBox()
        bbox.grow(15.0) # Search range: 15 meters
        
        type_idx = self.poly_lyr.fields().indexOf('type')
        score_idx = self.poly_lyr.fields().indexOf('score')
        
        candidates = []
        req = QgsFeatureRequest().setFilterRect(bbox)
        for f in self.poly_lyr.getFeatures(req):
            if f.id() == self.target_feat.id():
                continue
            
            is_ref = False
            if type_idx != -1:
                t_val = f.attribute(type_idx)
                if t_val is not None and str(t_val).strip().upper() == "L1-RTK":
                    is_ref = True
            if score_idx != -1:
                s_val = f.attribute(score_idx)
                if s_val is not None and str(s_val).strip() == "1":
                    is_ref = True
            
            if is_ref:
                candidates.append(f)
        
        if not candidates:
            return False

        tgt_pts = self._get_poly_points(self.target_feat)
        
        best_ref = None
        best_pairs = []
        best_matrix = None

        for ref_poly in candidates:
            ref_pts = self._get_poly_points(ref_poly)
            matching_pairs = []
            
            # Method A: Match by BND_NAME
            if tgt_pts and ref_pts:
                for t_pt in tgt_pts:
                    t_name = t_pt['BND_NAME']
                    if t_name is not None and str(t_name).strip():
                        t_name_str = str(t_name).strip().lower()
                        for r_pt in ref_pts:
                            r_name = r_pt['BND_NAME']
                            if r_name is not None and str(r_name).strip():
                                r_name_str = str(r_name).strip().lower()
                                if t_name_str == r_name_str:
                                    matching_pairs.append({
                                        'tgt_xy': t_pt.geometry().asPoint(),
                                        'ref_xy': r_pt.geometry().asPoint()
                                    })
                                    break
            
            # Method B: Match by Proximity
            if len(matching_pairs) < 2 and tgt_pts and ref_pts:
                matching_pairs = []
                for t_pt in tgt_pts:
                    t_xy = t_pt.geometry().asPoint()
                    closest_ref_pt = None
                    min_d = 2.0
                    for r_pt in ref_pts:
                        r_xy = r_pt.geometry().asPoint()
                        d = math.sqrt(t_xy.sqrDist(r_xy))
                        if d < min_d:
                            min_d = d
                            closest_ref_pt = r_pt
                    if closest_ref_pt:
                        matching_pairs.append({
                            'tgt_xy': t_xy,
                            'ref_xy': closest_ref_pt.geometry().asPoint()
                        })

            if len(matching_pairs) >= 2:
                p1, p2 = self._select_best_two_pairs(matching_pairs)
                matrix = self._compute_matrix(p1, p2)
                if matrix:
                    if len(matching_pairs) > len(best_pairs):
                        best_pairs = matching_pairs
                        best_ref = ref_poly
                        best_matrix = matrix

        # Method C: Match by Shared Vertices (if points matching failed)
        if (not best_ref or not best_matrix) and self.target_feat.hasGeometry():
            for ref_poly in candidates:
                if ref_poly.hasGeometry():
                    tgt_vertices = self._get_polygon_vertices(self.target_feat.geometry())
                    ref_vertices = self._get_polygon_vertices(ref_poly.geometry())
                    matching_pairs = []
                    for tv in tgt_vertices:
                        closest_rv = None
                        min_d = 2.0
                        for rv in ref_vertices:
                            d = math.sqrt(tv.sqrDist(rv))
                            if d < min_d:
                                min_d = d
                                closest_rv = rv
                        if closest_rv:
                            matching_pairs.append({
                                'tgt_xy': tv,
                                'ref_xy': closest_rv
                            })
                    if len(matching_pairs) >= 2:
                        p1, p2 = self._select_best_two_pairs(matching_pairs)
                        matrix = self._compute_matrix(p1, p2)
                        if matrix:
                            if len(matching_pairs) > len(best_pairs):
                                best_pairs = matching_pairs
                                best_ref = ref_poly
                                best_matrix = matrix

        if best_ref and best_matrix:
            self.ref_feat = best_ref
            self.matrix = best_matrix
            self._create_preview_items(best_pairs)
            return True
            
        return False

    def _create_preview_items(self, pairs):
        self.clear_preview()
        
        self.transformed_geom = QgsGeometry(self.target_feat.geometry())
        self.transformed_geom.transform(self.matrix)
        
        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubber_band.setColor(QtGui.QColor(255, 140, 0))
        self.rubber_band.setFillColor(QtGui.QColor(255, 140, 0, 45))
        self.rubber_band.setWidth(2)
        self.rubber_band.setToGeometry(self.transformed_geom, self.poly_lyr)
        
        # ตรวจสอบเรื่องการแปลงพิกัดจุดสำหรับ QgsVertexMarker
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        layer_crs = self.poly_lyr.crs()
        reproject = (canvas_crs != layer_crs)
        if reproject:
            from qgis.core import QgsCoordinateTransform
            layer_to_canvas = QgsCoordinateTransform(layer_crs, canvas_crs, QgsProject.instance())
            
        for pair in pairs:
            pt_geom = QgsGeometry.fromPointXY(pair['tgt_xy'])
            pt_geom.transform(self.matrix)
            new_xy = pt_geom.asPoint()
            
            line_geom = QgsGeometry.fromPolylineXY([pair['tgt_xy'], new_xy])
            v_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            v_band.setColor(QtGui.QColor(0, 180, 0))
            v_band.setWidth(2)
            v_band.setToGeometry(line_geom, self.poly_lyr)
            
            marker_xy = layer_to_canvas.transform(new_xy) if reproject else new_xy
            
            m = QgsVertexMarker(self.canvas)
            m.setCenter(marker_xy)
            m.setColor(QtGui.QColor(0, 180, 0))
            m.setIconType(QgsVertexMarker.ICON_BOX)
            m.setPenWidth(3)
            
            self.vector_bands.append(v_band)
            self.vector_bands.append(m)

        self.canvas.refresh()

    def _apply_transform(self):
        type_idx = self.poly_lyr.fields().indexOf('type')
        if type_idx != -1:
            tgt_val = self.target_feat.attribute(type_idx)
            if tgt_val is not None and str(tgt_val).strip().upper() == "L1-TS":
                ref_val = self.ref_feat.attribute(type_idx) if self.ref_feat else None
                is_ref_rtk = False
                if ref_val is not None and str(ref_val).strip().upper() == "L1-RTK":
                    is_ref_rtk = True
                
                if not is_ref_rtk:
                    self.plugin.iface.messageBar().pushMessage(
                        "MLEP Lock", 
                        "แปลง L1-TS จะสามารถขยับได้เฉพาะกรณีนำไปต่อกับแปลง L1-RTK เท่านั้น!", 
                        level=2, duration=10
                    )
                    return
                
                # Check snapped nodes on RTK within 5cm
                tgt_pts = self._get_poly_points(self.target_feat)
                for pt in tgt_pts:
                    pt_geom = QgsGeometry(pt.geometry())
                    pt_geom.transform(self.matrix)
                    new_xy = pt_geom.asPoint()
                    if not self.plugin._is_point_on_rtk_node(self.poly_lyr, new_xy):
                        self.plugin.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            "แปลง L1-TS ต้องขยับไปต่อและ snap กับหมุดของแปลง L1-RTK เท่านั้น!", 
                            level=2, duration=10
                        )
                        return

        layers = [self.poly_lyr, self.point_lyr]
        self.plugin.last_layers = layers
        self.plugin.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        if not self.poly_lyr.isEditable(): self.poly_lyr.startEditing()
        if not self.point_lyr.isEditable(): self.point_lyr.startEditing()

        self.poly_lyr.beginEditCommand("Semi-Auto Transform — แปลง")
        self.point_lyr.beginEditCommand("Semi-Auto Transform — หมุด")

        try:
            self.poly_lyr.changeGeometry(self.target_feat.id(), self.transformed_geom)
            
            tgt_pts = self._get_poly_points(self.target_feat)
            for pt in tgt_pts:
                pt_geom = QgsGeometry(pt.geometry())
                pt_geom.transform(self.matrix)
                self.point_lyr.changeGeometry(pt.id(), pt_geom)
                
            self.poly_lyr.endEditCommand()
            self.point_lyr.endEditCommand()
            
            self.plugin.iface.messageBar().pushMessage(
                "Semi-Auto Success", 
                f"แปลง {self.target_feat.id()} ขยับพิกัดเรียบร้อยแล้ว (ใช้ ↺ Undo Last เพื่อย้อนกลับ)", 
                level=3, duration=6
            )
        except Exception as e:
            self.poly_lyr.destroyEditCommand()
            self.point_lyr.destroyEditCommand()
            self.plugin.iface.messageBar().pushMessage("Semi-Auto Error", f"เกิดข้อผิดพลาด: {e}", level=2)

        self.canvas.refresh()

    def clear_preview(self):
        if self.rubber_band:
            try:
                self.canvas.scene().removeItem(self.rubber_band)
            except Exception:
                pass
            self.rubber_band = None
        for band in self.vector_bands:
            try:
                self.canvas.scene().removeItem(band)
            except Exception:
                pass
        self.vector_bands = []
        self.canvas.refresh()

    def reset_tool(self):
        self.clear_preview()
        self.target_feat = None
        self.ref_feat = None
        self.matrix = None
        self.transformed_geom = None
        self.state = 0
        self.plugin.iface.messageBar().clearWidgets()


class MultiLayerEditPro:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = [] 
        self.temp_tool = None
        self.last_layers = []
        self.mode = "" 
        self.version = "1.2.1"
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล
        
        self.rubber_band = None
        self.markers = []
        self.src_pts = []
        self._dol_highlight = None  # rubber band ไฮไลต์แปลงที่ค้นหา

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", self.action)
        self.clear_markers()
        self._dol_clear_highlight()
        if hasattr(self, 'temp_tool') and self.temp_tool:
            canvas = self.iface.mapCanvas()
            if canvas and canvas.mapTool() == self.temp_tool:
                canvas.unsetMapTool(self.temp_tool)

    def run(self):
        if self.dlg is None: self.create_dialog()
        self.dlg.show()

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.dlg.setWindowIcon(QtGui.QIcon(icon_path))
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro {self.version}")
        self.dlg.setMinimumWidth(360)
        root = QtWidgets.QVBoxLayout(self.dlg)
        root.setSpacing(6)

        def mkbtn(text, slot, style="", tip=""):
            b = QtWidgets.QPushButton(text)
            b.setStyleSheet(style or "padding:5px;")
            if tip:
                b.setToolTip(tip)
            b.clicked.connect(slot)
            return b

        # ---------- ชั้นข้อมูล (กระทัดรัด) ----------
        grp_layer = QtWidgets.QGroupBox("ชั้นข้อมูล")
        gl = QtWidgets.QGridLayout(grp_layer)
        gl.setHorizontalSpacing(6)
        gl.setVerticalSpacing(4)
        gl.setColumnStretch(0, 0)   # label ชิดซ้าย ไม่ยืด
        gl.setColumnStretch(1, 1)   # combo ดูดพื้นที่ว่างทั้งหมด -> label ชิด combo
        self.poly_cb = QtWidgets.QComboBox()
        self.point_cb = QtWidgets.QComboBox()
        gl.addWidget(QtWidgets.QLabel("แปลง:"), 0, 0)
        gl.addWidget(self.poly_cb, 0, 1)
        gl.addWidget(QtWidgets.QLabel("หมุด:"), 1, 0)
        gl.addWidget(self.point_cb, 1, 1)
        btn_refresh = mkbtn("🔄", self.refresh_layers, tip="Refresh Layers")
        btn_refresh.setFixedWidth(36)
        gl.addWidget(btn_refresh, 0, 2, 2, 1)
        root.addWidget(grp_layer)
        self.refresh_layers()

        # ---------- DOL search (เด่น เต็มกว้าง, public) ----------
        root.addWidget(mkbtn(
            "🔍 ค้นหาภาพลักษณ์", self.start_dol_search,
            "background-color:#fff3e0; font-weight:bold; padding:8px; color:#e65100;"))

        # ---------- เลือก & ปรับแต่ง (หน้าเดียว) ----------
        grp_edit = QtWidgets.QGroupBox("เลือก / ปรับแต่ง")
        ve = QtWidgets.QVBoxLayout(grp_edit)
        ve.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("By Cluster ID", lambda: self.process_selection('cluster')))
        r.addWidget(mkbtn("By UTM", lambda: self.process_selection('utm')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Move", lambda: self.start_interactive('move')))
        r.addWidget(mkbtn("Rotate", lambda: self.start_interactive('rotate')))
        r.addWidget(mkbtn("Scale", lambda: self.start_interactive('scale')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Transform (2 จุด)", lambda: self.start_interactive('transform'),
                          "background-color:#ffccbc; font-weight:bold; padding:6px;"))
        r.addWidget(mkbtn("Move Node (Sync)", lambda: self.start_interactive('modify_node'),
                          "background-color:#e8f5e9; font-weight:bold; padding:6px;"))
        ve.addLayout(r)
        ve.addWidget(mkbtn("📏 Align Points to Line", self.start_align_tool))
        root.addWidget(grp_edit)

        # ---------- จัดกลุ่ม / Score ----------
        grp_grp = QtWidgets.QGroupBox("จัดกลุ่ม / Score")
        vg = QtWidgets.QVBoxLayout(grp_grp)
        vg.setSpacing(5)
        vg.addWidget(mkbtn("🔗 Sync Cluster ID", self.group_cluster_ids,
                           "background-color:#e3f2fd; padding:6px;"))
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Score = 1", lambda: self.set_score_value(1),
                          "background-color:#c8e6c9; font-weight:bold; color:#1b5e20; padding:6px;"))
        r.addWidget(mkbtn("Score = 0", lambda: self.set_score_value(0),
                          "background-color:#ffcdd2; font-weight:bold; color:#b71c1c; padding:6px;"))
        vg.addLayout(r)
        root.addWidget(grp_grp)

        # ปุ่ม Auto Transform / Semi-Auto Transform ถูกซ่อน (เมธอดยังอยู่:
        #   self.start_auto_transform / self.start_semi_auto_transform)

        # ---------- แถบ action (เห็นตลอด) ----------
        r = QtWidgets.QHBoxLayout()
        btn_reset = mkbtn("Reset", self.cancel_transform)
        btn_undo = mkbtn("Undo", self.undo_transform)
        for _b in (btn_reset, btn_undo):
            _b.setFixedHeight(34)   # บังคับสูงเท่ากัน (กัน emoji เรนเดอร์ไม่เท่า)
            r.addWidget(_b)
        root.addLayout(r)
        root.addWidget(mkbtn("💾 บันทึก (Commit)", self.save_all_changes,
                             "background-color:#c8e6c9; font-weight:bold; padding:8px; color:#1b5e20;"))

        # ---------- footer ----------
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        root.addWidget(line)
        root.addWidget(mkbtn("🚀 Check Update", self.update_plugin))
        lbl = QtWidgets.QLabel("ชาคฤตย์ จันทรสุกศรี · กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        f = QtGui.QFont()
        f.setPointSize(8)
        lbl.setFont(f)
        lbl.setAlignment(QtCore.Qt.AlignCenter)
        root.addWidget(lbl)

    # ============ DOL iLands: ค้นหาโฉนดด้วยเลขระวาง ============
    def start_dol_search(self):
        """เปิด map tool: เปลี่ยน cursor ให้คลิกเลือกแปลงที่จะค้นหา (public ไม่ต้อง login)"""
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if lyr is None:
            QtWidgets.QMessageBox.warning(
                self.dlg, "ไม่พบเลเยอร์", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        try:
            if lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
                QtWidgets.QMessageBox.warning(
                    self.dlg, "เลเยอร์ไม่ถูกต้อง", f"เลเยอร์ '{lyr.name()}' ไม่ใช่ Polygon")
                return
        except Exception:
            pass
        self._dol_clear_highlight()
        canvas = self.iface.mapCanvas()
        # ล็อกให้คลิก/ไฮไลต์ได้เฉพาะแปลงในเลเยอร์ที่เลือกในปลั๊กอินเท่านั้น
        self.temp_tool = PolygonPickTool(
            canvas, lyr, self._on_polygon_picked, self._dol_on_hover)
        canvas.setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "DOL", f"คลิกบนแปลงในเลเยอร์ '{lyr.name()}' เพื่อค้นหาโฉนด (Esc เพื่อยกเลิก)")

    def _on_polygon_picked(self, feat, layer):
        """อ่าน attribute UTM ของแปลงที่คลิก (จากเลเยอร์ที่เลือก) แล้วยิงค้นหา"""
        def gv(name):
            try:
                if feat.fields().indexOf(name) < 0:
                    return ""
                v = feat[name]
                return "" if v is None else str(v).strip()
            except Exception:
                return ""

        m1, m2, m3 = gv("UTMMAP1"), gv("UTMMAP2"), gv("UTMMAP3")
        m4 = gv("UTMMAP4") or "00"
        scale = gv("UTMSCALE")
        landno = gv("LANDNO")
        self.iface.actionSelect().trigger()  # คืน cursor ปกติ

        # ไฮไลต์แปลงที่คลิกทันที (กรอบแดง)
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

        if not m1 or not m2 or not m3 or not scale or not landno:
            self._dol_clear_highlight()
            QtWidgets.QMessageBox.warning(
                self.dlg, "ข้อมูลแปลงไม่ครบ",
                f"แปลงนี้ไม่มี attribute ระวางครบ\n"
                f"UTMMAP={m1} {m2} {m3} {m4} | SCALE={scale} | LANDNO={landno}")
            return

        attrs = {"m1": m1, "m2": m2, "m3": m3, "m4": m4,
                 "scale": scale, "landno": landno}

        self._dol_busy = QtWidgets.QProgressDialog(
            f"กำลังค้นหา PARCEL_SEQ...\nระวาง {m1} {m2} {m3}-{m4} ที่ดิน {landno}",
            None, 0, 0, self.dlg)
        self._dol_busy.setWindowTitle("DOL")
        self._dol_busy.setCancelButton(None)
        self._dol_busy.setWindowModality(QtCore.Qt.WindowModal)
        self._dol_busy.show()

        self._dol_worker = ParcelLookupWorker(attrs, zone=47)
        self._dol_worker.done.connect(self._on_dol_done)
        self._dol_worker.fail.connect(self._on_dol_fail)
        self._dol_worker.start()

    def _on_dol_done(self, res):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()  # รันเสร็จ -> ลบไฮไลต์
        if not res:
            QtWidgets.QMessageBox.information(
                self.dlg, "ไม่พบแปลง", "ไม่พบแปลงในระบบ (ตรวจเลขระวาง / zone UTM)")
            return

        # เจอแล้ว -> เปิดภาพลักษณ์ทันที (ไม่เด้ง popup)
        if res.get("doc_url"):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(res["doc_url"]))
        warn = "" if res.get("verified") else "  ⚠️ MAP_PARCEL_SEQ ไม่ตรง"
        self.iface.messageBar().pushInfo(
            "DOL", f"PARCEL_SEQ {res.get('parcel_seq')} | โฉนด {res.get('parcel_no')} "
                   f"({res.get('city','')}) — เปิดภาพลักษณ์แล้ว{warn}")

    def _on_dol_fail(self, msg):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()
        QtWidgets.QMessageBox.critical(self.dlg, "DOL ผิดพลาด", msg)

    def _dol_highlight_feature(self, geom, layer):
        """ไฮไลต์แปลงบนแผนที่ด้วยกรอบแดง"""
        self._dol_clear_highlight()
        if geom is None or geom.isEmpty():
            return
        canvas = self.iface.mapCanvas()
        rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(255, 0, 0))
        rb.setFillColor(QtGui.QColor(255, 0, 0, 50))
        rb.setWidth(3)
        rb.setToGeometry(geom, layer)
        rb.show()
        self._dol_highlight = rb
        canvas.refresh()

    def _dol_clear_highlight(self):
        rb = getattr(self, "_dol_highlight", None)
        if rb is not None:
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
            self._dol_highlight = None

    def _dol_on_hover(self, feat, layer):
        """ไฮไลต์แปลงใต้เมาส์ก่อนคลิก (ตัวช่วยตัดสินใจ)"""
        if feat is None:
            self._dol_clear_highlight()
            return
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                lyr.selectByIds(ids)
        self.iface.mapCanvas().refresh()

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def refresh_layers(self):
        # แปลง = เฉพาะเลเยอร์ Polygon, หมุด = เฉพาะเลเยอร์ Point
        self.poly_cb.clear(); self.point_cb.clear()
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                gt = lyr.geometryType()   # มีเฉพาะ vector layer (raster -> error -> ข้าม)
            except Exception:
                continue
            if gt == QgsWkbTypes.PolygonGeometry:
                self.poly_cb.addItem(lyr.name(), lyr.id())
            elif gt == QgsWkbTypes.PointGeometry:
                self.point_cb.addItem(lyr.name(), lyr.id())
    def setup_snapping(self):
        self.canvas = self.iface.mapCanvas()
        config = QgsProject.instance().snappingConfig()
        if not config.enabled():
            config.setEnabled(True)
            config.setMode(QgsSnappingConfig.AllLayers)
            # ปรับความแรงในการดูด (Tolerance) เป็น 15-20 pixels
            config.setTolerance(20) 
            config.setUnits(QgsTolerance.Pixels)
            # ให้ Snap ทั้งจุด (Vertex) และเส้น (Segment)
            config.setType(QgsSnappingConfig.VertexAndSegment) 
            QgsProject.instance().setSnappingConfig(config)
        
        self.snap_utils = self.canvas.snappingUtils()
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        
    def start_interactive(self, mode):
        # 1. เลือก UTM ก่อน
        self.process_selection('utm')
        
        # 2. เช็คว่ามีอะไรถูกเลือกไหม
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_lyr or poly_lyr.selectedFeatureCount() == 0:
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกแปลงที่ต้องการก่อน", level=2, duration=10)
            return

        # 3. เคลียร์ Marker เก่า (แต่ไม่เคลียร์ Selection!)
        self.clear_markers()
        self.src_pts = []
        
        # 4. ตั้งค่า Tool
        self.mode = mode
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.temp_tool.canvasMoveEvent = self.handle_generic_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_click(self, point, button):
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        
        # 2. เลือกพิกัด: ถ้า Snap ติดใช้จุด Snap ถ้าไม่ติดใช้ point (ที่ว่าง) ตรงๆ
        pt = match.point() if match.isValid() and match.point().x() != 0 else point
        
        # กำหนดสี Marker: Snap=แดง, ที่ว่าง=น้ำเงิน
        color = QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255)

        # 3. วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setPenWidth(4)
        m.setColor(color)
        m.setIconType(QgsVertexMarker.ICON_X)
        self.markers.append(m)
        self.src_pts.append(QgsPointXY(pt.x(), pt.y())) # บังคับเป็น PointXY
        
        # 4. ตรวจสอบจำนวนจุดตามโหมด
        limit = {'move': 2, 'modify_node': 2, 'rotate': 3, 'scale': 3, 'transform': 4}.get(self.mode, 2)
        
        if len(self.src_pts) >= limit:
            self.execute_tool()
            
    def handle_generic_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือทั่วไป (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            # แทนที่จะใส่ None ให้ใช้ Match ว่างๆ แทนครับ
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            
    def execute_tool(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        
        if not layers:
            self.cancel_transform()
            return
            
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self.last_layers = layers
        p = self.src_pts

        # ─── ตรวจสอบกฎการล็อกแปลง L1-RTK / L1-TS ───
        if poly_lyr:
            type_idx = -1
            for i, field in enumerate(poly_lyr.fields()):
                if field.name().lower() == 'type':
                    type_idx = i
                    break
            if type_idx != -1:
                poly_ids = poly_lyr.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_lyr.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str == "L1-RTK":
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-RTK ซึ่งเป็นพิกัดอ้างอิงหลัก ไม่สามารถขยับได้!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return
                            elif val_str == "L1-TS":
                                # ยกเว้นกรณีใช้ปุ่ม transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                                if self.mode == 'transform' and len(p) >= 4:
                                    p2, p4 = p[1], p[3]
                                    if self._is_point_on_rtk_node(poly_lyr, p2) and self._is_point_on_rtk_node(poly_lyr, p4):
                                        continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                                        
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-TS ไม่สามารถขยับได้ ยกเว้นใช้โหมด Transform (2 Pts) ไปต่อกับ L1-RTK เท่านั้น!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return

        # ตรวจสอบสิทธิ์การขยับพิกัดผ่านจุดหมุด (กรณีจุดหมุดถูกเลือก)
        if point_lyr and point_lyr.selectedFeatureCount() > 0 and poly_lyr:
            for pt_f in point_lyr.selectedFeatures():
                is_locked, type_str = self._is_point_feature_locked(poly_lyr, pt_f)
                if is_locked:
                    # ข้อยกเว้นเฉพาะโหมด transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                    if type_str == "L1-TS" and self.mode == 'transform' and len(p) >= 4:
                        p2, p4 = p[1], p[3]
                        if self._is_point_on_rtk_node(poly_lyr, p2) and self._is_point_on_rtk_node(poly_lyr, p4):
                            continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                            
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return
                    else:
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return

        # เปิด edit ทั้งเลเยอร์แปลง+หมุดที่ตั้งค่าไว้ แยกจากเงื่อนไข selection
        # (แก้: บางทีหมุดไม่ถูกเลือก -> point layer ไม่ขึ้น edit)
        for _l in (poly_lyr, point_lyr):
            if _l and not _l.isEditable():
                _l.startEditing()

        for lyr in layers:
            if not lyr.isEditable(): lyr.startEditing()
            lyr.beginEditCommand(f"MLEP {self.mode}")
            
            try:
                # Optimize: ดึงเฉพาะ Geometry และรวบรวมเป็น list ก่อนวนลูปแก้ไข เพื่อป้องกันปัญหา cursor ล็อกขณะเขียนข้อมูล
                req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
                features = list(lyr.getFeatures(req))
                for f in features:
                    geom = f.geometry()
                    if geom.isNull(): continue

                    # --- 1. Move ---
                    if self.mode == 'move' and len(p) >= 2:
                        dx, dy = p[1].x() - p[0].x(), p[1].y() - p[0].y()
                        geom.translate(dx, dy)
                        lyr.changeGeometry(f.id(), geom)

                    # --- 2. Rotate (ใส่ลบหน้ามุมตามที่ตกลงกัน) ---
                    elif self.mode == 'rotate' and len(p) >= 3:
                        a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                        a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
                        geom.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))
                        lyr.changeGeometry(f.id(), geom)

                    # --- 3. Scale (ปรับใหม่ให้ชัวร์) ---
                    elif self.mode == 'scale' and len(p) >= 3:
                        d1 = math.sqrt(p[0].sqrDist(p[1]))
                        d2 = math.sqrt(p[0].sqrDist(p[2]))
                        if d1 > 0:
                            s = d2 / d1
                            # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                            geom.translate(-p[0].x(), -p[0].y())
                            matrix = QtGui.QTransform(); matrix.scale(s, s)
                            geom.transform(matrix)
                            geom.translate(p[0].x(), p[0].y())
                            lyr.changeGeometry(f.id(), geom)

                    # --- 4. Transform ---
                    elif self.mode == 'transform' and len(p) >= 4:
                        self.apply_similarity_direct(lyr, f, p)

                    # --- 5. Move Node (Optimized via C++ closestVertex) ---
                    elif self.mode == 'modify_node' and len(p) >= 2:
                        closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(p[0])
                        if sqr_dist < 0.000001:  # threshold 0.001 (sqrDist = 0.001 ** 2)
                            if vertex_idx >= 0:
                                lyr.moveVertex(p[1].x(), p[1].y(), f.id(), vertex_idx)
                
                lyr.endEditCommand()
            except Exception as e:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("MLEP Error", f"เกิดข้อผิดพลาดใน {lyr.name()}: {e}", level=2, duration=10)
                print(f"Error in execute_tool for layer {lyr.name()}: {e}")

        self.iface.mapCanvas().refresh()
        self.clear_markers()
        self.src_pts = []
        if self.mode == 'transform' :
            self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def apply_similarity_direct(self, lyr, f, p):
        """คำนวณ Transform แบบ Matrix (Similarity)"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        # x' = ax - by + tx , y' = bx + ay + ty
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        lyr.changeGeometry(f.id(), geom)

    def apply_similarity_geometry(self, lyr, f, p):
        """แก้ไขข้อ 4: ใช้ Matrix Transform ป้องกันรูปหาย/จุดรวมกัน"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        lyr.changeGeometry(f.id(), geom)

    def _is_point_on_rtk_node(self, poly_lyr, point_xy):
        """ตรวจสอบว่าพิกัด point_xy อยู่บน Node ของแปลงประเภท L1-RTK หรือไม่"""
        search_rect = QgsGeometry.fromPointXY(point_xy).buffer(0.05, 5).boundingBox()
        
        type_idx = -1
        for i, field in enumerate(poly_lyr.fields()):
            if field.name().lower() == 'type':
                type_idx = i
                break
        if type_idx == -1:
            return False
            
        req = QgsFeatureRequest().setFilterRect(search_rect).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
        for feat in poly_lyr.getFeatures(req):
            val = feat.attribute(type_idx)
            if val is not None and str(val).strip().upper() == "L1-RTK":
                geom_feat = poly_lyr.getFeature(feat.id())
                geom = geom_feat.geometry()
                if geom and not geom.isNull():
                    closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(point_xy)
                    if sqr_dist < 0.0025: # 0.05 ** 2
                        return True
        return False

    def _is_point_feature_locked(self, poly_lyr, point_f):
        """ตรวจสอบว่าฟีเจอร์จุดหมุดนี้เชื่อมโยงกับแปลงที่ถูกล็อก (L1-RTK หรือ L1-TS) หรือไม่ ผ่านฟิลด์ UTM"""
        point_utm_field = next(
            (f.name() for f in point_f.fields()
             if f.name().lower() in {'utm', 'utm_code', 'utm_id'}),
            None
        )
        poly_utm_field = next(
            (f.name() for f in poly_lyr.fields()
             if f.name().lower() in {'utm', 'utm_code', 'utm_id'}),
            None
        )
        poly_type_field = next(
            (f.name() for f in poly_lyr.fields()
             if f.name().lower() == 'type'),
            None
        )
        
        if not point_utm_field or not poly_utm_field or not poly_type_field:
            return False, None
            
        utm_val = point_f[point_utm_field]
        if utm_val is None:
            return False, None
            
        expr = f'"{poly_utm_field}" = \'{str(utm_val).strip()}\''
        req = QgsFeatureRequest().setFilterExpression(expr).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([poly_lyr.fields().indexFromName(poly_type_field)])
        
        for poly_feat in poly_lyr.getFeatures(req):
            val = poly_feat[poly_type_field]
            if val is not None:
                val_str = str(val).strip().upper()
                if val_str in ("L1-RTK", "L1-TS"):
                    return True, val_str
                    
        return False, None

    def set_score_value(self, value):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย score จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())

        # ตรวจสอบกฎการห้ามใส่ Score ให้กับแปลง L1-RTK และ L1-TS
        if poly_layer:
            type_idx = -1
            for i, field in enumerate(poly_layer.fields()):
                if field.name().lower() == 'type':
                    type_idx = i
                    break
            if type_idx != -1:
                poly_ids = poly_layer.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_layer.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str in ("L1-RTK", "L1-TS"):
                                self.iface.messageBar().pushMessage(
                                    "Score Blocked", 
                                    f"แปลง {f.id()} เป็นประเภท {val_str} ไม่อนุญาตให้ตั้งค่า Score!", 
                                    level=2, duration=10
                                )
                                return
                                
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return

        # เก็บรายชื่อเลเยอร์ไว้ให้ปุ่ม Undo รู้ว่าจะต้องไปย้อนที่เลเยอร์ไหน
        self.last_layers = layers 
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        for lyr in layers:
            # ตรวจสอบว่าเลเยอร์อยู่ในโหมดแก้ไขหรือไม่
            if not lyr.isEditable(): 
                lyr.startEditing()
            
            # เริ่มบันทึกคำสั่งสำหรับ Undo
            lyr.beginEditCommand(f"Change Score to {value}")
            
            # ค้นหา index ของฟิลด์ Score
            idx = -1
            for i, field in enumerate(lyr.fields()):
                if field.name().lower() == 'score':
                    idx = i
                    break
            
            if idx != -1:
                # Optimize: วนลูปแก้เฉพาะค่า Attribute ผ่าน ID โดยตรงเพื่อความรวดเร็วและใช้แรมน้อย
                for fid in lyr.selectedFeatureIds():
                    lyr.changeAttributeValue(fid, idx, value)
                lyr.endEditCommand() # ปิดคำสั่ง (จะถูกส่งเข้า Undo Stack ของ QGIS)
            else:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"ไม่พบฟิลด์ Score ใน {lyr.name()}", level=3, duration=10)

        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def group_cluster_ids(self):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย cluster id จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        fields = [f.name() for f in poly_layer.fields()]
        target_field = next((f for f in fields if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
        if not target_field: return
        
        # Optimize: ดึงค่าเฉพาะ Attribute ฟิลด์แรกที่เลือกโดยไม่ต้องดึงพิกัดเพื่อประหยัดหน่วยความจำ
        first_id = poly_layer.selectedFeatureIds()[0]
        f_idx = poly_layer.fields().indexFromName(target_field)
        req = QgsFeatureRequest().setFilterFid(first_id).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([f_idx])
        first_feat = next(poly_layer.getFeatures(req), None)
        if not first_feat: return
        main_val = first_feat[target_field]

        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        for lyr in layers:
            lyr.beginEditCommand("Group Cluster ID")
            lyr_f = [f.name() for f in lyr.fields()]
            lyr_t = next((f for f in lyr_f if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
            if lyr_t:
                idx = lyr.fields().indexFromName(lyr_t)
                # Optimize: แก้ไขเฉพาะค่า Attribute ผ่าน IDs โดยตรง
                for fid in lyr.selectedFeatureIds():
                    lyr.changeAttributeValue(fid, idx, main_val)
            lyr.endEditCommand()
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        """ล้างค่าหน้าจอและทำลายตัวช่วย Snap อย่างปลอดภัย"""
        if hasattr(self, 'snap_indicator') and self.snap_indicator:
            # ล้างสัญลักษณ์บนหน้าจอก่อนทำลาย Object
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            self.snap_indicator = None

        self.clear_rubber_band()
        self._dol_clear_highlight()
        
        # รีเซ็ตเครื่องมือ Semi-Auto (ถ้ามี)
        if hasattr(self, 'temp_tool') and self.temp_tool:
            if hasattr(self.temp_tool, 'reset_tool'):
                try:
                    self.temp_tool.reset_tool()
                except Exception:
                    pass

        if hasattr(self, 'markers'):
            for m in self.markers:
                if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []
        self.src_pts = []
        
        self.iface.mapCanvas().refresh()
        self.iface.actionSelect().trigger()

    def undo_transform(self):
        """ย้อนกลับการแก้ไขล่าสุดในทุกเลเยอร์ที่ถูกบันทึกไว้ใน self.last_layers"""
        if not self.last_layers:
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการล่าสุดให้ย้อนกลับ", level=2, duration=10)
            return

        for lyr in self.last_layers:
            if lyr and lyr.isEditable():
                # สั่งให้ Stack ของเลเยอร์นั้นๆ ย้อนกลับ 1 ขั้น
                lyr.undoStack().undo()
        
        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดเรียบร้อยแล้ว", level=1, duration=10)

    def save_all_changes(self):
        for lyr in [QgsProject.instance().mapLayer(self.poly_cb.currentData()), QgsProject.instance().mapLayer(self.point_cb.currentData())]:
            if lyr and lyr.isEditable(): lyr.commitChanges(); lyr.startEditing()
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3, duration=3)

    def update_plugin(self):
        def check_and_update():
            V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
            Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"
            try:
                res = requests.get(V_URL, timeout=5)
                new_version = res.text.strip()
                if new_version > self.version:
                    QtCore.QTimer.singleShot(0, lambda: self.prompt_update(new_version, Z_URL))
                else:
                    QtCore.QTimer.singleShot(0, lambda: QtWidgets.QMessageBox.information(self.dlg, "Update", "คุณใช้เวอร์ชันล่าสุดแล้ว"))
            except Exception as e:
                QtCore.QTimer.singleShot(0, lambda: QtWidgets.QMessageBox.warning(self.dlg, "Update Error", f"ไม่สามารถตรวจสอบอัปเดตได้: {e}"))

        import threading
        self.iface.messageBar().pushMessage("Update", "กำลังตรวจสอบเวอร์ชันใหม่ในพื้นหลัง...", level=0, duration=3)
        threading.Thread(target=check_and_update, daemon=True).start()

    def prompt_update(self, new_version, download_url):
        if QtWidgets.QMessageBox.question(self.dlg, "Update", f"พบเวอร์ชันใหม่ {new_version} ต้องการอัปเดตไหม?") == QtWidgets.QMessageBox.Yes:
            self.iface.messageBar().pushMessage("Update", "กำลังดาวน์โหลดอัปเดตในพื้นหลัง...", level=0, duration=3)
            def do_download():
                try:
                    r = requests.get(download_url, timeout=15)
                    z = zipfile.ZipFile(io.BytesIO(r.content))
                    dest_dir = os.path.dirname(os.path.dirname(__file__))
                    z.extractall(dest_dir)
                    QtCore.QTimer.singleShot(0, lambda: QtWidgets.QMessageBox.information(self.dlg, "Done", "อัปเดตเสร็จแล้ว! กรุณา Restart QGIS"))
                except Exception as e:
                    QtCore.QTimer.singleShot(0, lambda: QtWidgets.QMessageBox.critical(self.dlg, "Update Error", f"การดาวน์โหลดล้มเหลว: {e}"))
            import threading
            threading.Thread(target=do_download, daemon=True).start()

    def process_selection(self, mode):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        selected_ids = poly_layer.selectedFeatureIds()
        if not selected_ids: return
        
        fields = poly_layer.fields()
        target_names = (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])
        target = None
        target_idx = -1
        for i, field in enumerate(fields):
            if field.name().lower() in target_names:
                target = field.name()
                target_idx = i
                break
        if target_idx == -1: return
        
        # Optimize: ดึงเฉพาะข้อมูล Attribute ของฟิลด์ที่กำหนดโดยไม่ดึงพิกัดเพื่อประหยัดหน่วยความจำ
        req = QgsFeatureRequest().setFilterFids(selected_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([target_idx])
        v_list = []
        for f in poly_layer.getFeatures(req):
            val = f.attribute(target_idx)
            if val is not None:
                v_list.append(f"'{val}'" if isinstance(val, str) else str(val))
        
        if v_list:
            expr = f'"{target}" IN ({",".join(list(set(v_list)))})'
            poly_layer.selectByExpression(expr)
            if point_layer: point_layer.selectByExpression(expr)
            self.iface.mapCanvas().refresh()
            
    def start_auto_transform(self):
        """เปิด Auto Transform Dialog (modeless — ใช้งานแผนที่ขณะ dialog เปิดอยู่ได้)"""
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_lyr or not point_lyr:
            self.iface.messageBar().pushMessage(
                "Auto Transform", "กรุณาตั้งค่าเลเยอร์แปลงและหมุดก่อน", level=2, duration=5
            )
            return
        # ปิด dialog เก่าถ้ายังเปิดอยู่
        if hasattr(self, '_auto_tf_dlg') and self._auto_tf_dlg:
            self._auto_tf_dlg.close()
        self._auto_tf_dlg = AutoTransformDialog(self, poly_lyr, point_lyr)
        self._auto_tf_dlg.show()

    def start_semi_auto_transform(self):
        """เริ่มใช้งานเครื่องมือกึ่งอัตโนมัติ (Semi-Auto Snap Transform)"""
        self.cancel_transform()
        self.mode = 'semi_auto_transform'
        self.setup_snapping()
        self.temp_tool = SemiAutoTransformTool(self.iface.mapCanvas(), self)
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def _pts_in_polys(self, poly_feats, point_lyr):
        """หาหมุดที่อยู่ใน/บน กลุ่มแปลง โดยใช้ spatial filter + geometry check"""
        if not poly_feats or not point_lyr:
            return []
        # Build bounding extent from all polygons
        ext = poly_feats[0].geometry().boundingBox()
        for f in poly_feats[1:]:
            ext.combineExtentWith(f.geometry().boundingBox())
        ext.grow(max(ext.width(), ext.height()) * 0.01 + 0.5)

        result, seen = [], set()
        req = QgsFeatureRequest().setFilterRect(ext)
        for pt_f in point_lyr.getFeatures(req):
            if pt_f.id() in seen:
                continue
            pt_geom = pt_f.geometry()
            for poly_f in poly_feats:
                if poly_f.geometry().intersects(pt_geom):
                    result.append(pt_f)
                    seen.add(pt_f.id())
                    break
        return result

    def _apply_chained_transform(self, poly_lyr, point_lyr, chained_results):
        """บันทึกพิกัดใหม่ที่ประมวลผลสะสมแบบลูกโซ่สำเร็จลงในชั้นข้อมูลจริง"""
        layers = [l for l in [poly_lyr, point_lyr] if l]
        self.last_layers      = layers
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        success_poly_count = 0
        success_point_count = 0

        try:
            # 1. เปิดโหมดแก้ไข
            if poly_lyr and not poly_lyr.isEditable():
                poly_lyr.startEditing()
            if point_lyr and not point_lyr.isEditable():
                point_lyr.startEditing()

            # เริ่มคำสั่ง Edit สำหรับแปลง (Polygon)
            if poly_lyr:
                poly_lyr.beginEditCommand("Chained Transform — แปลงแปลงที่ดิน")
            # เริ่มคำสั่ง Edit สำหรับหมุด (Point)
            if point_lyr:
                point_lyr.beginEditCommand("Chained Transform — แปลงหมุด")

            for res in chained_results:
                if res['success']:
                    # บันทึกพิกัดใหม่ Polygon
                    if poly_lyr and res['new_geom']:
                        poly_lyr.changeGeometry(res['poly_id'], res['new_geom'])
                        success_poly_count += 1
                        
                    # บันทึกพิกัดใหม่ Points
                    if point_lyr and res['new_points']:
                        for pt_id, pt_geom in res['new_points']:
                            point_lyr.changeGeometry(pt_id, pt_geom)
                            success_point_count += 1

            if poly_lyr:
                poly_lyr.endEditCommand()
            if point_lyr:
                point_lyr.endEditCommand()

            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage(
                "Chained Transform",
                f"สำเร็จ: ขยับแปลง {success_poly_count} แปลง, ขยับหมุด {success_point_count} จุด  "
                "(ใช้ ↺ Undo Last เพื่อย้อนกลับ)",
                level=3, duration=6
            )
        except Exception as e:
            for lyr in layers:
                try:
                    lyr.destroyEditCommand()
                except Exception:
                    pass
            self.iface.messageBar().pushMessage(
                "Chained Transform Error", str(e), level=2, duration=10
            )
            print(f"Chained Transform Error: {e}")

    def start_align_tool(self):
        self.cancel_transform()
        self.mode = 'align_point_driven'
        self.setup_snapping() # เรียกใช้ระบบ Snap  
        self.temp_tool = QgsMapToolEmitPoint(self.canvas)
        self.temp_tool.canvasClicked.connect(self.handle_align_click)
        self.temp_tool.canvasMoveEvent = self.handle_align_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_align_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือ Align (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
        # แก้จาก self.snapping_utils เป็น self.snap_utils
        if not hasattr(self, 'snap_utils'):
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # Logic สำหรับวาด Rubber Band เส้นยางยืด (ถ้ามี)
        if hasattr(self, 'rubber_band') and self.rubber_band and len(self.src_pts) == 1:
            curr_pt = match.point() if match.isValid() else event.mapPoint()
            self.rubber_band.removeLastPoint()
            self.rubber_band.addPoint(curr_pt)
            
    def handle_align_click(self, point, button):
        """จัดการการคลิกจุด P1 และ P2 สำหรับสร้างแนวเส้น (รองรับที่ว่าง)"""
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        # 2. ถ้า Snap ไม่ติด ให้ใช้พิกัดที่คลิกจริง (point)
        pt = match.point() if match.isValid() else point
        
        self.src_pts.append(QgsPointXY(pt.x(), pt.y()))
        
        # วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        m.setPenWidth(5)
        self.markers.append(m)
        
        if len(self.src_pts) == 1:
            self.clear_rubber_band()
            self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            self.rubber_band.setColor(QtGui.QColor(255, 0, 0))
            self.rubber_band.setWidth(2)
            self.rubber_band.addPoint(pt)
            self.rubber_band.addPoint(pt)

        if len(self.src_pts) == 2:
            self.execute_point_node_alignment()
            # ทำความสะอาดหน้าจอหลังเสร็จงาน
            self.clear_markers()
            self.clear_rubber_band()
            self.src_pts = []
            
    def clear_rubber_band(self):
        """ลบ Rubber Band ออกจากหน้าจอและหน่วยความจำอย่างเด็ดขาด"""
        if self.rubber_band:
            self.rubber_band.hide() # ซ่อนทันที
            self.iface.mapCanvas().scene().removeItem(self.rubber_band) # ลบออกจาก Scene
            self.rubber_band = None # คืนค่าว่าง
            
    def execute_point_node_alignment(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        if not point_lyr or point_lyr.selectedFeatureCount() == 0:
            return

        # --- แก้ไขจุดที่ทำให้เกิด NameError ---
        self.last_layers = []
        if point_lyr: self.last_layers.append(point_lyr)
        if poly_lyr: self.last_layers.append(poly_lyr)
        
        # ใช้ self.last_layers แทนคำว่า layers
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in self.last_layers}
        
        p1, p2 = self.src_pts[0], self.src_pts[1]
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag_sq = dx**2 + dy**2
        if mag_sq == 0: return

        def get_projected_pt(old_x, old_y):
            u = ((old_x - p1.x()) * dx + (old_y - p1.y()) * dy) / mag_sq
            return QgsPointXY(p1.x() + u * dx, p1.y() + u * dy)

        # --- ส่วนแก้ไข: เปิด Edit Mode และ Command ให้ทั้งสองเลเยอร์ ---
        if not point_lyr.isEditable(): point_lyr.startEditing()
        point_lyr.beginEditCommand("Align Points to Line")
        
        if poly_lyr:
            if not poly_lyr.isEditable(): poly_lyr.startEditing()
            poly_lyr.beginEditCommand("Align Nodes to Line")

        try:
            for pt_f in point_lyr.selectedFeatures():
                old_geom = pt_f.geometry()
                old_xy = old_geom.asPoint()
                
                # ตรวจสอบสิทธิ์การย้ายจุดหมุดว่าเชื่อมโยงกับแปลงที่ล็อกหรือไม่
                if poly_lyr:
                    is_locked, type_str = self._is_point_feature_locked(poly_lyr, pt_f)
                    if is_locked:
                        self.iface.messageBar().pushMessage(
                            "Align Warning", 
                            f"ข้ามการย้ายจุดหมุด {pt_f.id()} เนื่องจากเชื่อมโยงกับแปลงประเภท {type_str} (ถูกล็อก)", 
                            level=2, duration=5
                        )
                        continue

                new_pt = get_projected_pt(old_xy.x(), old_xy.y())
                
                # ย้าย Point
                point_lyr.changeGeometry(pt_f.id(), QgsGeometry.fromPointXY(new_pt))

                # ย้าย Node ใน Polygon
                if poly_lyr:
                    search_rect = old_geom.buffer(0.01, 5).boundingBox()
                    
                    # ดึงข้อมูลแบบ list เพื่อป้องกัน Cursor ล็อกขณะที่ moveVertex
                    poly_features = list(poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(search_rect)))
                    for poly_f in poly_features:
                        # ตรวจสอบว่าแปลงนี้ล็อกพิกัดหรือไม่
                        poly_type_idx = -1
                        for i, field in enumerate(poly_lyr.fields()):
                            if field.name().lower() == 'type':
                                poly_type_idx = i
                                break
                        is_poly_locked = False
                        if poly_type_idx != -1:
                            val = poly_f.attribute(poly_type_idx)
                            if val is not None:
                                val_str = str(val).strip().upper()
                                if val_str in ("L1-RTK", "L1-TS"):
                                    is_poly_locked = True
                                    
                        if is_poly_locked:
                            self.iface.messageBar().pushMessage(
                                "Align Warning", 
                                f"ข้ามการย้ายโหนดของแปลง {poly_f.id()} เนื่องจากเป็นประเภท {val_str} (ถูกล็อก)", 
                                level=2, duration=5
                            )
                            continue

                        geom = poly_f.geometry()
                        # Optimize: ค้นหา Node ที่ใกล้ที่สุดด้วยคำสั่ง C++ ของ QGIS API โดยใช้ old_xy (QgsPointXY)
                        closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(old_xy)
                        if sqr_dist < 0.000025: # threshold 0.005 (sqrDist = 0.005 ** 2)
                            if vertex_idx >= 0:
                                poly_lyr.moveVertex(new_pt.x(), new_pt.y(), poly_f.id(), vertex_idx)

            # ปิด Command ทั้งสองเลเยอร์
            point_lyr.endEditCommand()
            if poly_lyr:
                poly_lyr.endEditCommand()
                
        except Exception as e:
            point_lyr.destroyEditCommand()
            if poly_lyr: poly_lyr.destroyEditCommand()
            self.iface.messageBar().pushMessage("Align Error", f"เกิดข้อผิดพลาด: {e}", level=2, duration=10)
            print(f"Align Error: {e}")

        self.canvas.refresh()
        self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)


# ============================================================
#  DOL iLands — เครื่องมือคลิกเลือกแปลง + worker เรียก API
# ============================================================
class PolygonPickTool(QgsMapTool):
    """cursor กากบาท + ไฮไลต์แปลงใต้เมาส์ (ก่อนคลิก) เป็นตัวช่วยตัดสินใจ
    คลิก = ส่ง feature กลับผ่าน click_cb ; เลื่อนเมาส์ = hover_cb"""

    def __init__(self, canvas, layer, click_cb, hover_cb):
        super().__init__(canvas)
        self._canvas = canvas
        self._layer = layer
        self._click_cb = click_cb
        self._hover_cb = hover_cb
        self._last_fid = None
        self._picked = False
        self.setCursor(QtCore.Qt.CrossCursor)
        # cache transform ครั้งเดียว (เดิมสร้างใหม่ทุก mouse-move ตอน hover)
        proj = QgsProject.instance()
        self._xform = None
        if layer.crs() != proj.crs():
            try:
                self._xform = QgsCoordinateTransform(proj.crs(), layer.crs(), proj)
            except Exception:
                self._xform = None

    def _feature_at(self, event):
        """หา feature ในเลเยอร์ที่เลือก ใต้ตำแหน่งเมาส์ (None ถ้าไม่มี)"""
        map_pt = self.toMapCoordinates(event.pos())   # CRS ของโปรเจกต์
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
            except Exception:
                pt = map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))

        tol = self._canvas.mapUnitsPerPixel() * 4
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                pass

        found = fallback = None
        for f in self._layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            g = f.geometry()
            if fallback is None:
                fallback = f
            if g and g.contains(gp):
                found = f
                break
        return found or fallback

    def canvasMoveEvent(self, event):
        # ไฮไลต์แปลงใต้เมาส์ (อัปเดตเฉพาะเมื่อเปลี่ยนแปลง)
        feat = self._feature_at(event)
        fid = feat.id() if feat is not None else None
        if fid == self._last_fid:
            return
        self._last_fid = fid
        self._hover_cb(feat, self._layer)

    def canvasReleaseEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        feat = self._feature_at(event)
        if feat is None:
            iface.messageBar().pushWarning(
                "DOL", "ไม่พบแปลงในเลเยอร์ที่เลือกตรงตำแหน่งที่คลิก ลองใหม่อีกครั้ง")
            return
        self._picked = True
        self._click_cb(feat, self._layer)

    def deactivate(self):
        # ถ้าเลิกใช้เครื่องมือโดยไม่ได้คลิก -> ลบไฮไลต์ hover ทิ้ง
        if not self._picked:
            try:
                self._hover_cb(None, self._layer)
            except Exception:
                pass
        super().deactivate()


class ParcelLookupWorker(QtCore.QThread):
    """ระวาง(attribute) -> PARCEL_SEQ ผ่าน ArcGIS + UDM (public, ไม่ต้อง login)"""
    done = QtCore.pyqtSignal(object)   # dict หรือ None
    fail = QtCore.pyqtSignal(str)

    def __init__(self, attrs, zone=47):
        super().__init__()
        self.attrs = attrs
        self.zone = zone

    def run(self):
        from . import dol_api
        try:
            a = self.attrs
            res = dol_api.lookup_parcel_by_rawang(
                a["m1"], a["m2"], a["m3"], a["m4"], a["scale"], a["landno"],
                zone=self.zone)
            self.done.emit(res)
        except Exception as e:
            self.fail.emit(f"ค้นหาไม่สำเร็จ: {e}")
