def classFactory(iface):
    from .main import MultiLayerEditPro
    return MultiLayerEditPro(iface)