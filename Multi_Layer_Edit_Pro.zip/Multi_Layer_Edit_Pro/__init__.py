# -*- coding: utf-8 -*-
# ★ 2.4.0 (M1 · ตรวจ handoff A2-03) — ล้างโมดูลย่อยของปลั๊กอินนี้ที่ค้างใน sys.modules ก่อนโหลดทุกครั้ง
#   QGIS (reloadPlugin / Plugin Manager / ตัวอัปเดตของเรา) ลบเฉพาะโมดูลที่มันจดไว้ ซึ่งไม่รวมแพ็กเกจย่อย
#   (core/ services/ ui/) ⇒ ไม่ล้าง = รุ่นใหม่ที่โหลดสดในเซสชันเดิมอาจได้ __init__ ของแพ็กเกจย่อยรุ่นเก่า
#   🛑 ไฟล์นี้ต้องมีแค่ส่วนนี้ + classFactory ทุกรุ่น (ห้ามเพิ่มโค้ดอื่น — sim101 ตรวจ)
def _mlep_purge_stale_modules(_pkg=__name__):
    import sys
    for _k in [k for k in list(sys.modules) if k.startswith(_pkg + ".")]:
        sys.modules.pop(_k, None)


_mlep_purge_stale_modules()


def classFactory(iface):
    from .main import MultiLayerEditPro
    return MultiLayerEditPro(iface)
