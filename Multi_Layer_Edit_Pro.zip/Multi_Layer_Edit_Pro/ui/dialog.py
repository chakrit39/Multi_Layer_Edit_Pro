# -*- coding: utf-8 -*-
"""หน้าต่างหลักของปลั๊กอิน, What's New, กล่องถาม/แจ้งเตือน และแถบข้อความ

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import os
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import Qgis, QgsFeature, QgsProject
from ..changelog import CHANGELOG
from ..core.const import _MLEP_MAIN_FILE
from ..core.util import _fld_idx, _log_exc, _sheet_label, _sheet_str, _txt, _vkey
from ..ui.qt_helpers import _half_save_orphan_watch, _lift_dlg, _whats_new_rows


class DialogMixin:
    """หน้าต่างหลักของปลั๊กอิน, What's New, กล่องถาม/แจ้งเตือน และแถบข้อความ"""

    def _show_whats_new(self):
        """เด้ง popup สรุปสิ่งที่เปลี่ยน เมื่อเปิดปลั๊กอินครั้งแรกหลังเวอร์ชันใหม่
        (เทียบกับเวอร์ชันที่เคยเห็นใน QSettings; ติดตั้งครั้งแรกจะเงียบ ตั้ง baseline ไว้)"""
        s = QtCore.QSettings()
        key = "MultiLayerEditPro/lastSeenVersion"
        last = s.value(key, "", str)
        if _vkey(self.version) <= _vkey(last):
            return                      # เคยเห็นแล้ว / ไม่ใช่เวอร์ชันใหม่
        s.setValue(key, self.version)   # บันทึกทันทีกันเด้งซ้ำ
        if last:
            # หา index ของเวอร์ชันล่าสุดที่เคยเห็น
            last_idx = next((i for i, (v, _) in enumerate(CHANGELOG) if _vkey(v) <= _vkey(last)), len(CHANGELOG))
            # โชว์สิ่งที่ใหม่กว่าทั้งหมด + ขอย้อนดูอดีตด้วยให้รวมเป็น 3 เวอร์ชันเป็นอย่างน้อย
            show_count = max(last_idx, 3)
            new_entries = CHANGELOG[:show_count]
            head = f"อัปเดตเป็นเวอร์ชัน {self.version} แล้ว 🎉"
        else:
            # ครั้งแรก -> โชว์ 3 เวอร์ชันล่าสุด
            new_entries = CHANGELOG[:3]
            head = f"ยินดีต้อนรับสู่เวอร์ชัน {self.version} 🎉"
        if not new_entries:
            return
        rows = _whats_new_rows(new_entries)        # ★ 2.3.7 (review UX-26) — escape ข้อความ changelog
        # ★ ใช้ "หน้าต่างมีขนาด + เลื่อนอ่านได้" แทน QMessageBox (2026-08-07)
        #   QMessageBox ยืดตามเนื้อหา: changelog ยาว ๆ (1.9.7 มี 24 บรรทัด) จะได้กล่องสูงเก้งก้าง
        #   ล้นจอ อ่านยาก และปรับขนาดเองไม่ได้ · QDialog + QTextBrowser = กำหนดขนาดได้ เลื่อนได้ ย่อ/ขยายได้
        #   ★ parent = หน้าต่างหลักเสมอ (self.dlg อาจถูกปิด/ย่อ -> กล่อง modal ไปซ่อน = ดูเหมือนค้าง)
        dlg = QtWidgets.QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Multi-Layer Edit Pro — มีอะไรใหม่ ✨")
        dlg.setModal(True)
        dlg.setSizeGripEnabled(True)                       # ลากมุมปรับขนาดได้
        lay = QtWidgets.QVBoxLayout(dlg)
        lab = QtWidgets.QLabel(f"<h3 style='margin:0'>{head}</h3>")
        lab.setTextFormat(QtCore.Qt.RichText)
        lay.addWidget(lab)
        view = QtWidgets.QTextBrowser()
        view.setHtml("<div style='font-size:11pt; line-height:150%'>" + "<br>".join(rows) + "</div>")
        view.setOpenExternalLinks(True)
        lay.addWidget(view, 1)
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok)
        bb.accepted.connect(dlg.accept)
        lay.addWidget(bb)
        # ขนาดเริ่มต้น: กว้าง 760 สูง 60% ของจอ (ไม่เกิน 640) — เล็กพอไม่ล้นจอเล็ก ใหญ่พออ่านสบาย
        try:
            _scr = QtWidgets.QApplication.primaryScreen().availableGeometry()
            _w = max(560, min(760, int(_scr.width() * 0.55)))
            _h = max(360, min(640, int(_scr.height() * 0.60)))
        except Exception:
            _w, _h = 720, 520
        dlg.resize(_w, _h)
        dlg.setMinimumSize(480, 320)
        dlg.show()
        try:
            dlg.raise_(); dlg.activateWindow()
            QtCore.QTimer.singleShot(0, lambda: _lift_dlg(dlg))
        except Exception:
            pass
        try:
            dlg.exec_()
        finally:
            dlg.deleteLater()           # ★ 2.3.7 (review LC-11) — ไม่ค้างเป็นลูกของหน้าต่างหลักทุกครั้งที่เด้ง

    def _dlg_shown(self):
        """★ 2.4.0 (review DI-09) — แผงหลักเปิดให้เห็นอยู่จริง (มี · ยังไม่ถูกลบ · isVisible · ไม่ถูกย่อ)
        ใช้กั้นทาง "เข้าโหมดพิเศษ / ปลดล็อก L1" ให้เกิดได้เฉพาะตอนที่ป้ายแดงในแผงมองเห็นได้ · อ่านไม่ได้ = False (ปิดไว้ก่อน)"""
        d = getattr(self, "dlg", None)
        if d is None:
            return False
        try:
            if not d.isVisible() or d.isMinimized():
                return False
        except Exception:                   # RuntimeError: วัตถุ C++ ถูกลบไปแล้ว
            return False
        # ★ 2.4.0 (review DI-09) — แผงเป็นหน้าต่างลูกของ QGIS: ย่อหน้าต่าง QGIS ⇒ ระบบซ่อนแผงไปด้วย แต่ isVisible() ของแผงยัง True
        try:
            mw = self.iface.mainWindow()
            if mw is not None and mw.isMinimized():
                return False
        except Exception:
            pass
        return True

    def _fit_dialog_height(self, initial=False):
        """ย่อ/ขยายความสูงหน้าต่างให้พอดีเนื้อหา หลังซ่อน/โชว์กล่อง ADMIN
        Qt ไม่ย่อหน้าต่างให้เองเวลา setVisible(False) — ความสูงเดิมค้างไว้เป็นที่ว่าง
        (คงความกว้างที่ผู้ใช้ปรับไว้ ปรับเฉพาะความสูง)"""
        dlg = getattr(self, "dlg", None)
        if dlg is None:
            return
        try:
            body = getattr(self, "_dlg_body", None)
            if body is None:                                # หน้าต่างแบบเก่า (ไม่มีกรอบเลื่อน)
                lay = dlg.layout()
                if lay is not None:
                    lay.activate()          # บังคับคำนวณ sizeHint ใหม่ทันที
                dlg.resize(dlg.width(), dlg.sizeHint().height())
                return
            if body.layout() is not None:
                body.layout().invalidate()  # ซ่อน/โชว์กล่องแล้ว sizeHint เดิมยังค้างในแคชของเลย์เอาต์ (วัดแล้ว: 882 ค้างหลังปิดโหมด)
                body.layout().activate()    # บังคับคำนวณ sizeHint ใหม่ทันที
            self._dlg_fit_width()
            # ★ 2.3.9 — สูงพอดีเนื้อหา แต่ไม่เกิน 90% ของจอที่หน้าต่างอยู่ (เกิน = เลื่อนดูในแผง)
            fw = 2 * self._dlg_scroll.frameWidth()
            want = body.sizeHint().height() + fw
            w = dlg.width()
            if initial:      # ยังไม่เคยแสดง: กว้างตามเนื้อหา (เหมือน 2.3.8) + ที่ของแถบเลื่อน
                w = max(dlg.minimumWidth(), body.sizeHint().width() + self._dlg_scroll.verticalScrollBar().sizeHint().width() + fw)
            # ★ 2.4.0 (review DI-09) — ป้ายแดงย้ายออกมานอกกรอบเลื่อน ⇒ บวกความสูงของป้าย (ตัดบรรทัดตามความกว้างแผง) เมื่อป้ายแสดง
            _b = getattr(self, "_admin_banner", None)
            if _b is not None and not _b.isHidden():
                want += _b.heightForWidth(w) if _b.hasHeightForWidth() else _b.sizeHint().height()
            dlg.resize(w, min(want, self._dlg_screen_cap()))
        except Exception:
            pass

    def _dlg_screen_cap(self):
        """★ 2.3.9 — ความสูงสูงสุดของแผงหลัก = 90% ของพื้นที่ใช้ได้ของจอที่แผงอยู่ (ยังไม่แสดง = จอของ QGIS)"""
        try:
            dlg = self.dlg
            scr = None
            if dlg.isVisible() and hasattr(dlg, "screen"):
                scr = dlg.screen()
            if scr is None:
                mw = self.iface.mainWindow()
                scr = mw.screen() if (mw is not None and hasattr(mw, "screen")) else None
            if scr is None:
                scr = QtWidgets.QApplication.primaryScreen()
            return int(scr.availableGeometry().height() * 0.9) if scr is not None else 900
        except Exception:
            return 900

    def _dlg_fit_width(self):
        """★ 2.3.9 — ไม่มีแถบเลื่อนแนวนอน ⇒ แผงห้ามแคบกว่าเนื้อหา (+ ที่ของแถบเลื่อนแนวตั้ง) ไม่งั้นขอบขวาของปุ่มถูกตัด"""
        try:
            body, sc = self._dlg_body, self._dlg_scroll
            minw = body.minimumSizeHint().width() + sc.verticalScrollBar().sizeHint().width() + 2 * sc.frameWidth() + 2
            self.dlg.setMinimumWidth(max(360, minw))
        except Exception:
            pass

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        icon_path = os.path.join(os.path.dirname(_MLEP_MAIN_FILE), 'icon.png')
        self.dlg.setWindowIcon(QtGui.QIcon(icon_path))
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro {self.version}")
        self.dlg.setMinimumWidth(360)
        # ★ 1 ก.ย. 69 — ปิดหน้าต่างหลัก = ล้าง cache
        #   ผูกตรงนี้ (ตอนสร้างหน้าต่าง) ไม่ใช่ใน run() เพราะ run() ไม่ใช่เส้นทางเดียวที่เปิดหน้าต่าง
        try:
            self.dlg.finished.connect(lambda *_a: self._on_main_dialog_closed())
        except Exception:
            pass
        # ★ 2.3.7 (review UX-05) — Esc = เลิกเครื่องมือ (ไม่ปิดแผง) · Enter ไม่กดปุ่มซ้ำ
        try:
            self._dlg_key_filter = self._main_key_filter()
            self.dlg.installEventFilter(self._dlg_key_filter)
        except Exception:
            pass
        # ★ 2.3.9 — จอเล็ก (เจ้าของงานสั่ง 11 ต.ค.): 2.3.8 วางเลย์เอาต์ตรงบนหน้าต่าง ไม่มีแถบเลื่อน
        #   ⇒ โหมดผู้ดูแลสูง ~800 px ล้นจอ 768/โน้ตบุ๊กขยาย 125% (ปุ่ม 💾 บันทึก ตกขอบล่าง)
        #   ⇒ ใส่เนื้อหาทั้งแผงในกรอบเลื่อน (แบบหน้าต่าง 📐 วาดเส้น 2.3.6) · ความสูงไม่เกิน 90% ของจอ (_fit_dialog_height)
        _outer = QtWidgets.QVBoxLayout(self.dlg)
        _outer.setContentsMargins(0, 0, 0, 0)
        self._dlg_scroll = QtWidgets.QScrollArea(self.dlg)
        self._dlg_scroll.setWidgetResizable(True)
        self._dlg_scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        self._dlg_scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self._dlg_body = QtWidgets.QWidget()
        self._dlg_scroll.setWidget(self._dlg_body)
        _outer.addWidget(self._dlg_scroll)
        root = QtWidgets.QVBoxLayout(self._dlg_body)
        root.setSpacing(6)

        # แถบผู้ดูแล (ซ่อนจนเข้าโหมด admin)
        self._admin_banner = QtWidgets.QLabel("🔓 โหมดผู้ดูแล (ADMIN)")
        # ★ 2.4.0 (review DI-09) — ป้ายอยู่ "นอก" กรอบเลื่อน (บนสุดของหน้าต่าง ไม่เลื่อนตาม) — เดิมอยู่ในกรอบเลื่อน 2.3.9
        #   ⇒ จอเล็กที่โหมดผู้ดูแลล้นแผง เลื่อนลงไปกด 🔓 ปลดล็อก L1 (กล่อง ADMIN ล่างแผง) แล้วป้ายหลุดขอบบนไป
        #   margin ของ QSS อยู่นอกพื้นหลังแดง = ระยะขอบเท่าเนื้อหาในกรอบเลื่อน · ป้ายซ่อน = ไม่กินที่ (เลย์เอาต์ข้ามวิดเจ็ตที่ซ่อน)
        _bm = root.contentsMargins()
        _outer.setSpacing(0)
        self._admin_banner.setStyleSheet(
            "background-color:#b71c1c; color:white; font-weight:bold; padding:6px; border-radius:3px;"
            " margin:%dpx %dpx 0px %dpx;" % (_bm.top(), _bm.right(), _bm.left()))
        self._admin_banner.setAlignment(QtCore.Qt.AlignCenter)
        # ★ 2.3.9 rc3 (ผลตรวจ Windows 🟡2) — ข้อความโหมดผู้ช่วยยาว ⇒ แผงกว้าง 362→531 px และค้างกว้างหลังออกจากโหมด
        #   ให้ตัดบรรทัดในความกว้างแผงแทน (ขั้นต่ำเท่าคำที่ยาวสุด ไม่ดันแผงให้กว้างตามทั้งประโยค)
        self._admin_banner.setWordWrap(True)
        self._admin_banner.setVisible(False)
        _outer.insertWidget(0, self._admin_banner)      # ★ 2.4.0 (review DI-09) เหนือกรอบเลื่อน (เดิม root.addWidget)

        def mkbtn(text, slot, style="", tip=""):
            b = QtWidgets.QPushButton(text)
            b.setStyleSheet(style or "padding:5px;")
            b.setFixedHeight(34)   # สูงเท่ากันทุกปุ่ม (กันไทย/Latin/emoji เรนเดอร์สูงไม่เท่า)
            if tip:
                b.setToolTip(tip)
            # ★ 28 ส.ค. 69 — ตรวจ Topological Editing "ทุกครั้งที่กดปุ่มใดก็ตาม" ของปลั๊กอิน
            #   ดักที่โรงงานสร้างปุ่มจุดเดียว ครอบได้ทุกปุ่มพร้อมกัน
            #   (ถ้าไปไล่ใส่ทีละเครื่องมือจะตกหล่นแน่ ๆ — ของเดิมเช็คจาก setup_snapping
            #    ซึ่งไม่ครอบ ➕ Add Node, 📏 Align Points ตอนกด, 💾 บันทึก)
            #   ไม่รบกวน เพราะกล่องเด้งเฉพาะตอนที่ค่านี้เปิดอยู่จริง พอปิดให้แล้วก็เงียบ
            def _slot(*_a, _s=slot):
                try:
                    self._topo_guard()
                except Exception:
                    pass
                return _s()
            b.clicked.connect(_slot)
            # ★ 2.3.7 (review UX-05) — QPushButton ใน QDialog เป็น autoDefault เอง ⇒ กด Enter ตอนโฟกัสอยู่ = ปุ่มทำงานซ้ำ
            b.setAutoDefault(False)
            b.setDefault(False)
            return b

        # ---------- ชั้นข้อมูล (กระทัดรัด) ----------
        grp_layer = QtWidgets.QGroupBox("ชั้นข้อมูล")
        # ★ 31 ส.ค. 69 — ธีมบางตัววาดพื้นหลังทึบใต้ข้อความหัวข้อ ทำให้เส้นกรอบขาด
        grp_layer.setStyleSheet("QGroupBox::title{background:transparent;}")
        gl = QtWidgets.QGridLayout(grp_layer)
        gl.setHorizontalSpacing(6)
        gl.setVerticalSpacing(4)
        gl.setColumnStretch(0, 0)   # label ชิดซ้าย ไม่ยืด
        gl.setColumnStretch(1, 1)   # combo ดูดพื้นที่ว่างทั้งหมด -> label ชิด combo
        self.poly_cb = QtWidgets.QComboBox()
        self.point_cb = QtWidgets.QComboBox()
        gl.addWidget(QtWidgets.QLabel("แปลง:"), 0, 0)
        gl.addWidget(self.poly_cb, 0, 1)
        gl.addWidget(QtWidgets.QLabel("หมุด:"), 1, 0)
        gl.addWidget(self.point_cb, 1, 1)
        btn_refresh = mkbtn("🔄", self.refresh_layers,
                              tip="โหลดรายชื่อชั้นข้อมูลใหม่ — กดเมื่อเพิ่งเพิ่ม/ปิดเลเยอร์ใน QGIS แล้วรายการด้านบนยังไม่เปลี่ยน")
        btn_refresh.setFixedWidth(36)
        gl.addWidget(btn_refresh, 0, 2)
        # ★ 31 ส.ค. 69 — เลือก "ผู้รับผิดชอบ" ที่จะให้สัญลักษณ์ไฮไลต์
        #   ตั้งเป็นตัวแปร global ของ QGIS (@owner_name) -> ตั้งครั้งเดียวใช้ได้ทุกอำเภอ
        #   วางซ้อนใต้ปุ่ม refresh ในคอลัมน์เดิม เพื่อไม่ให้คอมโบชั้นข้อมูลแคบลง
        self._owner_btn = mkbtn("👤", self.choose_owner_name,
                              tip="เลือกชื่อผู้รับผิดชอบ — แผนที่จะเน้นสีเฉพาะแปลงของคนนั้นให้")
        self._owner_btn.setFixedWidth(36)
        gl.addWidget(self._owner_btn, 1, 2)
        self._grp_layer = grp_layer
        self._refresh_owner_ui()
        # ซิงก์ป้าย rule ตั้งแต่เปิดแผง — ไม่งั้นพนักงานต้องกดปุ่ม 👤 หนึ่งครั้งก่อน
        # ป้ายถึงจะตรงกับชื่อที่ตั้งค้างไว้จากครั้งก่อน
        try:
            self._sync_owner_rule_labels()
        except Exception:
            pass
        root.addWidget(grp_layer)
        self.refresh_layers()
        # สลับชั้นเอง -> จำว่าผู้ใช้เลือก + ย้ายตัวเฝ้าไปชั้นใหม่ (ต่อทั้งสองช่อง)
        # ★ 2.3.7 (review DI-02) — จำการเลือก "รายช่อง" · activated = ผู้ใช้กดเลือกเอง (รวมเลือกตัวเดิมซ้ำ)
        for _n, _cb in enumerate((self.poly_cb, self.point_cb)):
            try:
                _cb.currentIndexChanged.connect(lambda *_a, _s=_n: self._on_layer_combo_changed(slot=_s))
                _cb.activated.connect(lambda *_a, _s=_n: self._remember_pick(_s))
            except Exception:
                pass

        # ---------- DOL search (คลิกแปลง -> เปิดเอกสาร) ----------
        # ★ 2.3.7 (3 ต.ค. 69 เจ้าของงานสั่ง) — ปุ่ม ℹ️ สอบถามข้อมูลแปลง ซ้ายสุด ชื่อเป็น emoji อย่างเดียว (แบบ Identify ของ QGIS)
        #   กว้างคงที่ไม่กินพื้นที่ · ที่เหลือแบ่งครึ่งให้ 🔍 กับ 📐: stretch 1 เท่ากัน + ความกว้างขั้นต่ำเท่ากัน (= ปุ่มที่ข้อความยาวกว่า)
        #   ⇒ กว้างเท่ากันเสมอ ข้อความไม่ถูกตัด · padding ซ้าย-ขวาลดจาก 8 เหลือ 4 px ชดเชยที่ปุ่ม ℹ️ ใช้ แผงหลักไม่กว้างขึ้น
        r = QtWidgets.QHBoxLayout()
        self._info_btn = mkbtn(
            "ℹ️", lambda: self.start_parcel_info(),
            "background-color:#e8eaf6; font-weight:bold; padding:4px; color:#1a237e;",
            "สอบถามข้อมูลแปลง — คลิกแปลงเพื่อดูระวาง เนื้อที่รูปแปลง และเนื้อที่ทะเบียน "
            "(ตร.ม. / ไร่-งาน-วา) พร้อมส่วนต่าง\nเครื่องมือค้างไว้ คลิกแปลงอื่นต่อได้ · Esc = เลิก")
        self._info_btn.setFixedWidth(40)
        r.addWidget(self._info_btn)
        _dol_b = (mkbtn(
            "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image'),
            "background-color:#fff3e0; font-weight:bold; padding:8px 4px; color:#e65100;",
            "คลิกแปลง — เปิดภาพสแกนโฉนดของแปลงนั้นจากระบบกรม"), mkbtn(
            "📐 หลักฐานการรังวัด", lambda: self.start_dol_search('survey'),
            "background-color:#e3f2fd; font-weight:bold; padding:8px 4px; color:#0d47a1;",
            "คลิกแปลง — เปิดหลักฐานการรังวัดของแปลงนั้นจากระบบกรม (ต้องเข้าสู่ระบบกรมก่อน)"))
        _dol_w = max(_b.sizeHint().width() for _b in _dol_b)
        for _b in _dol_b:
            _b.setMinimumWidth(_dol_w)
            r.addWidget(_b, 1)
        root.addLayout(r)

        # ---------- เลือก & ปรับแต่ง (หน้าเดียว) ----------
        grp_edit = QtWidgets.QGroupBox("เลือก / ปรับแต่ง")
        grp_edit.setStyleSheet("QGroupBox::title{background:transparent;}")
        ve = QtWidgets.QVBoxLayout(grp_edit)
        ve.setSpacing(5)
        # ★ 2.2.9 — เจ้าของงานสั่งเรียงใหม่เป็น 4 แถว และย้าย ✏️ แก้ชื่อหมุด / 🗑 ลบ node
        #   ออกจากกล่อง ADMIN มาที่นี่ (ดูด่านสิทธิ์ใน _rename_node_execute / _delete_node_execute)
        #   1. ClusterID / วาดเส้น / สลับหมุด
        #   2. Move / Rotate / Scale
        #   3. Transform / แก้ชื่อหมุด / Align Points
        #   4. Move Node / Add Node / ลบ node
        r = QtWidgets.QHBoxLayout()
        # ★ 31 ส.ค. 69 — เดิมตรงนี้เป็นปุ่ม "By UTM" ซึ่งไม่มีใครกดเลย เพราะทุกเครื่องมือ
        #   เรียก process_selection('utm') ให้เองอยู่แล้ว (เมธอดยังอยู่ ใช้ภายในเหมือนเดิม)
        r.addWidget(mkbtn("ClusterID", lambda: self.process_selection('cluster'),
                              tip="เลือกแปลงที่อยู่กลุ่มเดียวกัน (cluster id เดียวกัน) กับแปลงที่เลือกอยู่ ทั้งกลุ่ม"))
        r.addWidget(mkbtn("📐 วาดเส้น", self.start_draw_line,
                          "background-color:#e1f5fe; font-weight:bold; color:#01579b; padding:6px;",
                          "วาดเส้นวัดระยะบนแผนที่ — เกาะหมุด/มุมแปลงให้ "
                          "และไม่แตะข้อมูลในฐานข้อมูลเลย"))
        r.addWidget(mkbtn("🔁 สลับหมุด", self.start_swap_node,
                          "background-color:#ede7f6; font-weight:bold; color:#4527a0; padding:6px;",
                          "คลิกเลือกแปลง แล้วคลิกหมุด 2 จุดของแปลงนั้น เพื่อสลับตำแหน่งกัน "
                          "(ใช้กับเคสชื่อหมุดสลับลำดับกัน)"))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Move", lambda: self.start_interactive('move'),
                          tip="เลือกแปลงก่อน แล้วลากเพื่อเลื่อนทั้งกลุ่ม — หมุดของแปลงเลื่อนตามไปด้วย"))
        r.addWidget(mkbtn("Rotate", lambda: self.start_interactive('rotate'),
                          tip="เลือกแปลงก่อน แล้วลากเพื่อหมุนทั้งกลุ่ม — หมุดหมุนตามไปด้วย"))
        r.addWidget(mkbtn("Scale", lambda: self.start_interactive('scale'),
                          tip="เลือกแปลงก่อน แล้วลากเพื่อย่อ/ขยายทั้งกลุ่ม — หมุดขยับตามไปด้วย"))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Transform", lambda: self.start_interactive('transform'),
                          "background-color:#ffccbc; font-weight:bold; padding:6px;",
                          "เลือกแปลงก่อน แล้วคลิก 4 จุดตามลำดับ: ① ต้นทาง 1 → ② ปลายทาง 1 → ③ ต้นทาง 2 → "
                          "④ ปลายทาง 2 — แปลงเลื่อน/หมุน/ย่อขยายให้ต้นทางไปทับปลายทาง หมุดขยับตามไปด้วย"))
        r.addWidget(mkbtn("✏️ แก้ชื่อหมุด", self.start_rename_node,
                          "background-color:#e1f5fe; font-weight:bold; color:#01579b; padding:6px;",
                          "คลิกแปลง แล้วคลิกหมุดของแปลงนั้น เพื่อแก้ชื่อหมุด "
                          "(แก้ได้เฉพาะหมุดที่ยังไม่มีชื่อ — ชื่อเดิมต้องให้ผู้ช่วยผู้ดูแล/ผู้ดูแลแก้ให้)\n"
                          "ยกเว้นแปลง LandsMaps (L2-LM) แก้ชื่อเดิมได้เลย"))     # ★ 2.3.7 (review UX-13) — ไม่บอกโหมดซ่อน
        r.addWidget(mkbtn("📏 Align Points", self.start_align_tool,
                          tip="ดึงมุมแปลงให้ไปตรงกับหมุด — ต้องเลือกทั้งชั้นแปลงและชั้นหมุดก่อน"))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        # (Sync) ถูกตัดออกเพื่อให้พอดีสามปุ่ม — ความหมายย้ายไปอยู่ใน tooltip แทน
        r.addWidget(mkbtn("Move Node", self.start_sync_vertex_tool,
                          "background-color:#e8f5e9; font-weight:bold; padding:6px;",
                          "ลากมุมแปลง แล้วหมุดของแปลงนั้นเลื่อนตามไปด้วยอัตโนมัติ"))
        r.addWidget(mkbtn("➕ Add Node", self.start_add_node,
                          "background-color:#e8f5e9; font-weight:bold; color:#1b5e20;",
                          "คลิกแปลง แล้วคลิกหมุดข้างเคียงเพื่อเพิ่มมุม "
                          "— ถ้าคลิกตรงมุมของแปลงตัวเองที่ยังไม่มีหมุด จะสร้างหมุดให้ที่มุมนั้น"))
        r.addWidget(mkbtn("🗑 ลบ Node", self.start_delete_node,
                          "background-color:#fce4ec; font-weight:bold; color:#880e4f; padding:6px;",
                          "คลิกแปลงเพื่อดูว่ามีหมุดซ้อน/node ซ้อนตรงไหน แล้วคลิกที่จุดนั้นเพื่อลบ "
                          "(ลบมุมแปลงจริงต้องให้ผู้ช่วยผู้ดูแล/ผู้ดูแลลบให้)\n"
                          "ยกเว้นแปลง LandsMaps (L2-LM) ลบหมุด/มุมแปลงได้เลย"))     # ★ 2.3.7 (review UX-13)
        ve.addLayout(r)
        root.addWidget(grp_edit)

        # ---------- จัดกลุ่ม / Score ----------
        grp_grp = QtWidgets.QGroupBox("จัดกลุ่ม / Score")
        grp_grp.setStyleSheet("QGroupBox::title{background:transparent;}")
        vg = QtWidgets.QVBoxLayout(grp_grp)
        vg.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("📝 หมายเหตุ (REMARK)", self.set_remark_value,
                          "background-color:#fff3e0; padding:6px; color:#e65100;",
                          "ใส่/แก้ข้อความหมายเหตุให้แปลงที่เลือก (เลือกจากรายการที่ใช้บ่อย หรือพิมพ์เอง)"))
        r.addWidget(mkbtn("🔗 Sync Cluster ID", self.group_cluster_ids,
                          "background-color:#e3f2fd; padding:6px;",
                          "ตั้ง cluster id ของแปลงที่เลือกทั้งกลุ่มให้เป็นค่าเดียวกัน (หมุดได้ค่าตามไปด้วย)"))
        vg.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Score = 1", lambda: self.set_score_value(1),
                          "background-color:#c8e6c9; font-weight:bold; color:#1b5e20; padding:6px;",
                          "ทำเสร็จแล้ว — กดเมื่อเชื่อมต่อรูปแปลงเรียบร้อย\n(เว็บติดตามงานนับเป็น \"ผ่าน\" ถ้าไม่ติดธงจากตัวตรวจ)"))
        r.addWidget(mkbtn("Score = 0", lambda: self.set_score_value(0),
                          "background-color:#ffcdd2; font-weight:bold; color:#b71c1c; padding:6px;",
                          "ทำไม่ได้/ไม่ผ่าน — กดเมื่อแปลงนี้ยังเชื่อมไม่ได้\n(เว็บติดตามงานนับเป็น \"ไม่ผ่าน\" แต่ถือว่าทำแล้ว)"))
        vg.addLayout(r)
        root.addWidget(grp_grp)

        # ---------- ผู้ดูแล (ADMIN) — ซ่อนจนกด Ctrl+Shift+F12 ----------
        self._admin_group = QtWidgets.QGroupBox("ผู้ดูแล (ADMIN)")
        # ★ 31 ส.ค. 69 — เดิมหัวข้อทับเส้นกรอบแดง (subcontrol-origin ปริยาย = padding)
        #   ย้ายไปอยู่ในระยะ margin เหนือเส้น + เว้นซ้าย/ขวาให้เท่ากับหัวข้อกลุ่มอื่น
        self._admin_group.setStyleSheet(
            "QGroupBox{border:1px solid #b71c1c; border-radius:3px;"
            " margin-top:14px; padding:8px 6px 6px 6px;} "
            "QGroupBox::title{subcontrol-origin:margin; subcontrol-position:top left;"
            " left:2px; padding:0 4px 2px 0;"
            " color:#b71c1c; background:transparent; font-weight:bold;}")
        va = QtWidgets.QVBoxLayout(self._admin_group)
        va.setSpacing(5)
        self._admin_unlock_btn = mkbtn(
            "🔓 ปลดล็อก L1", self.toggle_unlock_l1,
            "background-color:#ffcdd2; font-weight:bold; color:#b71c1c; padding:6px 2px;",
            "เปิด/ปิดการแก้แปลง L1 (L1-RTK / L1-TS) ซึ่งปกติล็อกไว้เพราะเป็นสมอของสายผลิต\n"
            "ใช้เฉพาะเมื่อจำเป็นจริง ๆ แล้วกดล็อกกลับทันที")
        # ★ 2.3.7 (3 ต.ค. 69 เจ้าของงานสั่ง) — ป้ายสั้นลงเหลือ "ปลดล็อก L1" + ปุ่ม 📝 แก้ไขข้อมูลรูปแปลง อยู่แถวเดียวกัน
        # ★ 2.3.9 — เก็บปุ่มของกล่องไว้ตาม id (ชุดเดียวกับ _admin_shortcut_actions) ⇒ ผู้ช่วยผู้ดูแลเห็นเฉพาะปุ่มชั้นตัวเอง
        self._adm_btn = {"unlock_l1": self._admin_unlock_btn}
        # ★ 2.3.9 — ใส่ ➕ สร้างรูปแปลง ขวาของ 📝 แล้ว 3 ปุ่มในแถวเดียวทำแผงกว้างขึ้น 76 px (วัด offscreen 390 → 466)
        #   ⇒ 🔓 ปลดล็อก L1 ขึ้นแถวบนเดี่ยว (แบบ 2.3.6) · แถวถัดไป 📝 แก้ไขข้อมูลรูปแปลง | ➕ สร้างรูปแปลง (ขวาของ 📝 ตามที่สั่ง)
        _adm_row0 = QtWidgets.QHBoxLayout()
        _adm_row0.addWidget(self._admin_unlock_btn, 1)
        va.addLayout(_adm_row0)
        _adm_row1 = QtWidgets.QHBoxLayout()
        self._adm_btn["edit_parcel"] = mkbtn(
            "📝 แก้ไขข้อมูลรูปแปลง", self.start_edit_parcel_data,
            "background-color:#bbdefb; font-weight:bold; color:#0d47a1; padding:6px 2px;",
            "คลิกแปลง — แก้ระวาง (UTMMAP1-4) · มาตราส่วน · เลขที่ดิน แล้วสร้าง UTM ใหม่\n"
            "หมุดของแปลงเปลี่ยนคีย์ตาม · ดึงเนื้อที่ทะเบียนจากระบบกรมใหม่ · กด 💾 บันทึกเพื่อลงฐาน\n"
            "เปลี่ยนประเภทแปลง (Type — แปลง + หมุดของแปลง) และชนิดเอกสารสิทธิ์ได้ในกล่องเดียวกัน\n"
            "โฉนดที่ดินที่เปลี่ยนคีย์/ชนิดเอกสาร: ต้องคีย์ไม่ซ้ำและได้เนื้อที่ทะเบียนก่อนจึงจะแก้ได้")
        _adm_row1.addWidget(self._adm_btn["edit_parcel"], 1)
        # ★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค.) — ➕ สร้างรูปแปลง ด้านขวาของ 📝 แก้ไขข้อมูลรูปแปลง · ผู้ช่วยผู้ดูแลใช้ได้ (เฉพาะ L2)
        self._adm_btn["create_parcel"] = mkbtn(
            "➕ สร้างรูปแปลง", self.start_create_parcel,
            "background-color:#c5e1a5; font-weight:bold; color:#33691e; padding:6px 2px;",
            "คลิกหมุด (snap) · มุมแปลง หรือที่ว่าง ทีละจุดตามแนวแปลง → คลิกจุดแรกซ้ำ/คลิกขวา/Enter = ปิดรูป\n"
            "แล้วกรอกคีย์ (ค้นทะเบียนได้) · เลือก Type · ชนิดเอกสาร · ผู้รับผิดชอบ → สร้างแปลง + หมุดทุกมุม\n"
            "Backspace = ถอย · Esc = เลิก · กด 💾 บันทึกเพื่อลงฐาน")
        _adm_row1.addWidget(self._adm_btn["create_parcel"], 1)
        va.addLayout(_adm_row1)
        # ★ 2.2.9 — ✏️ แก้ชื่อหมุด และ 🗑 ลบ node ย้ายไปโซน "เลือก / ปรับแต่ง" แล้ว
        #   (ยังเป็นเครื่องมือเดิม แต่ทำงานได้กว้างขึ้นเมื่อเปิดโหมดผู้ดูแล)
        #   คงตัวแปร _admin_btn_row ไว้เป็นเลย์เอาต์ว่าง เผื่อโค้ดเก่าอ้างถึง
        self._admin_btn_row = QtWidgets.QHBoxLayout()
        va.addLayout(self._admin_btn_row)
        # ★ 2.3.6 (1 ต.ค. 69 เจ้าของงานจัดตำแหน่งใหม่) — แถวบน ปลดล็อก L1 (อยู่เดี่ยว)
        #   แถว 2: Audit / แบ่งหัก/แยก / ลบแปลง · แถว 3: เปลี่ยน Type / มอบหมาย / ล้าง Score
        #   stretch 1 เท่ากันทุกปุ่ม -> กว้างเท่ากันเสมอไม่ว่าข้อความจะสั้นยาวต่างกัน
        #   แถวละ 3 ปุ่ม: เว้นข้างแค่ 2px (เดิม 6px) ไม่ให้แผงหลักกว้างขึ้นตอนเปิดโหมดนี้ (วัดแล้ว 394 -> 413 px)
        _adm_row2 = QtWidgets.QHBoxLayout()
        # ★ 2.3.2 (21 ก.ย. 69) เจ้าของงานสั่งเพิ่มปุ่ม audit
        _adm_row2.addWidget(self._adm_keep("audit", mkbtn(
            "✅ Audit", self.audit_parcels,
            "background-color:#c8e6c9; font-weight:bold; color:#1b5e20; padding:6px 2px;",
            "ผลตรวจของผู้ดูแล (คอลัมน์ AUDIT) — ผ่าน / ไม่ผ่าน / ล้าง\n"
            "ผ่าน: แปลงที่พนักงานกด Score 0 จะถูกนับเป็น \"ผ่าน\" และล้างธงเนื้อที่ให้\n"
            "ไม่ผ่าน: แปลงที่พนักงานกด Score 1 จะเข้าช่อง \"แปลงที่ต้องแก้ไข\"")), 1)
        # ★ 2.3.1 (21 ก.ย. 69) เจ้าของงานสั่งเพิ่ม
        _adm_row2.addWidget(self._adm_keep("donut", mkbtn(
            "🍩 แบ่งหัก/แยก", self.start_donut,
            "background-color:#d7ccc8; font-weight:bold; color:#4e342e; padding:6px 2px;",
            "คลิกแปลงที่จะหัก → คลิกหมุดในแปลงทีละดวงตามแนวกรอบ → คลิกหมุดดวงแรกซ้ำ (หรือคลิกขวา/Enter) "
            "= หักส่วนในกรอบออก · ส่วนในกรอบว่างไว้ ไม่สร้างแปลงใหม่ · Backspace = ถอย · Esc = เลิก")), 1)
        _adm_row2.addWidget(self._adm_keep("delete_parcel", mkbtn(
            "🗑 ลบแปลง", self.start_delete_parcel,
            "background-color:#b71c1c; font-weight:bold; color:#ffffff; padding:6px 2px;",
            "คลิกแปลงที่ต้องการลบ — ลบทั้งรูปแปลงและหมุดทุกจุดของแปลงนั้นพร้อมกัน")), 1)
        va.addLayout(_adm_row2)
        _adm_row3 = QtWidgets.QHBoxLayout()
        # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "ยุบปุ่มเปลี่ยน type ไปรวมกับปุ่มแก้ไขข้อมูล และให้แก้ doc type ได้ด้วย")
        #   ปุ่ม 🏷 เปลี่ยน Type ออกจากแถวนี้ — เปลี่ยน Type/ชนิดเอกสารในกล่อง 📝 แก้ไขข้อมูลรูปแปลง (แถว 3 เหลือ มอบหมาย | ล้าง Score)
        # ★ 2.2.10 (17 ก.ย. 69) เจ้าของงานสั่ง "เพิ่มปุ่มมอบหมายใน admin mode"
        #   ตั้งผู้รับผิดชอบ (NAME) ให้แปลงที่เลือก · พนักงานทั่วไปไม่มีสิทธิ์ UPDATE(NAME) — มีแต่ mlep_admin
        _adm_row3.addWidget(self._adm_keep("assign_owner", mkbtn(
            "👤 มอบหมาย", self.assign_owner,
            "background-color:#e1bee7; font-weight:bold; color:#4a148c; padding:6px 2px;",
            "ตั้งผู้รับผิดชอบ (NAME) ให้แปลงที่เลือกไว้ — เลือกชื่อจากรายการ หรือพิมพ์ชื่อใหม่")), 1)
        # ★ 2.3.1 (21 ก.ย. 69) เจ้าของงานสั่งเพิ่ม
        _adm_row3.addWidget(self._adm_keep("clear_score", mkbtn(
            "🧹 ล้าง Score", self.clear_score,
            "background-color:#cfd8dc; font-weight:bold; color:#37474f; padding:6px 2px;",
            "ล้างค่า SCORE ของแปลงที่เลือกให้ว่าง (NULL) — ใช้ตอนต้องให้กลับไปทำใหม่ "
            "· เว็บติดตามงานจะนับเป็น \"ยังไม่ทำ\"")), 1)
        va.addLayout(_adm_row3)
        self._admin_group.setVisible(False)
        root.addWidget(self._admin_group)

        # ---------- แถบ action (เห็นตลอด) ----------
        r = QtWidgets.QHBoxLayout()
        btn_reset = mkbtn("✖ Reset", self.cancel_transform,
                          tip="ยกเลิกเครื่องมือที่กำลังใช้อยู่ และล้างเส้นชั่วคราวบนจอ — ไม่แตะข้อมูล")
        btn_undo = mkbtn("↺ Undo", self.undo_transform,
                          tip="ย้อนคำสั่งล่าสุดของปลั๊กอิน — ย้อนทั้งแปลงและหมุดให้ตรงกัน\n(ยังไม่ลงฐานจนกว่าจะกด 💾 บันทึก)")
        for _b in (btn_reset, btn_undo):
            _b.setFixedHeight(34)   # บังคับสูงเท่ากัน (กัน emoji เรนเดอร์ไม่เท่า)
            r.addWidget(_b, 1)
        root.addLayout(r)
        root.addWidget(mkbtn("💾 บันทึก (Commit)", self.save_all_changes,
                             "background-color:#c8e6c9; font-weight:bold; padding:8px; color:#1b5e20;",
                             "บันทึกงานที่แก้ทั้งหมดลงฐานข้อมูล — มีการตรวจให้ก่อน ถ้าเจอปัญหาจะเตือนก่อนบันทึก"))

        # ---------- footer ----------
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        root.addWidget(line)
        rf = QtWidgets.QHBoxLayout()
        btn_sc = mkbtn("⌨ ตั้งค่า Shortcut", self.open_shortcut_settings,
                          tip="ตั้งปุ่มลัดของเครื่องมือแต่ละตัวเอง")
        btn_up = mkbtn("🚀 Check Update", self.update_plugin,
                          tip="ตรวจว่ามีปลั๊กอินรุ่นใหม่ไหม — ถ้ามีจะติดตั้งให้ แล้วโหลดรุ่นใหม่ให้เองโดยไม่ต้องปิด-เปิด QGIS")
        for _b in (btn_sc, btn_up):
            _b.setFixedHeight(34)   # สูงเท่ากัน
            rf.addWidget(_b, 1)     # stretch เท่ากัน -> กว้างเท่ากัน
        root.addLayout(rf)
        lbl = QtWidgets.QLabel("ชาคฤตย์ จันทรสุกศรี · กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        f = QtGui.QFont()
        f.setPointSize(8)
        lbl.setFont(f)
        lbl.setAlignment(QtCore.Qt.AlignCenter)
        root.addWidget(lbl)
        # ★ 2.3.9 — กรอบเลื่อนแล้ว: หมุนล้อเมาส์เลื่อนแผง ห้ามให้คอมโบ/ช่องตัวเลขที่ผ่านใต้เมาส์ "กินล้อ"
        #   (คอมโบเลือกชั้นแปลง/ชั้นหมุดเปลี่ยนเงียบ ๆ = เครื่องมือทำงานผิดชั้น) — รับล้อเฉพาะตอนถูกคลิกเลือกอยู่
        class _MainWheelGuard(QtCore.QObject):
            def eventFilter(self, obj, ev):
                if ev.type() == QtCore.QEvent.Wheel and not obj.hasFocus():
                    ev.ignore()
                    return True
                return False
        self._dlg_wheel_guard = _MainWheelGuard(self.dlg)
        for _w in (self._dlg_body.findChildren(QtWidgets.QAbstractSpinBox)
                   + self._dlg_body.findChildren(QtWidgets.QComboBox)):
            try:
                _w.setFocusPolicy(QtCore.Qt.StrongFocus)
                _w.installEventFilter(self._dlg_wheel_guard)
            except Exception:
                pass
        self._fit_dialog_height(initial=True)    # ★ 2.3.9 — ขนาดเริ่ม = พอดีเนื้อหา แต่ไม่เกิน 90% ของจอ
        self._load_shortcuts()   # ผูก shortcut ที่บันทึกไว้

        # refresh combo เลเยอร์อัตโนมัติเมื่อโปรเจกต์เพิ่ม/ลบเลเยอร์ (disconnect ใน unload)
        proj = QgsProject.instance()
        for _sname in ("layersAdded", "layersRemoved"):
            try:
                getattr(proj, _sname).connect(self._project_layers_changed)
                self._signal_conns.append((None, _sname, self._project_layers_changed))
            except Exception:
                pass
        # ★ rc5 (ผลตรวจ Windows rc4 ⚪1) เปิด/ปิดชั้นในแผงชั้น ⇒ แม่เหล็กชั้น L1 รอจดตาม (_on_tree_visibility · disconnect ใน unload)
        try:
            proj.layerTreeRoot().visibilityChanged.connect(self._on_tree_visibility)
            self._signal_conns.append(("__tree__", "visibilityChanged", self._on_tree_visibility))
        except Exception:
            pass
        # ★ 2.3.7 (review DI-02) — รู้ว่า "กำลังอ่านไฟล์โปรเจกต์" จากสัญญาณ loadingLayer (ยิงเฉพาะระหว่าง read · ก่อนเพิ่มแต่ละชั้น)
        #   ⇒ ระหว่างอ่านสร้างคอมโบครั้งเดียวหลังโหลดเสร็จ · QgsProject.clear() เฉย ๆ (ปิด/ล้างโปรเจกต์) ไม่ยิง ⇒ ไม่ค้างโหมดโหลด
        #   (รุ่นแรกของแพตช์นี้เข้าโหมดที่ aboutToBeCleared เมื่อโปรเจกต์มีชื่อไฟล์ ⇒ clear() จากไฟล์ที่บันทึกแล้วแล้วเพิ่มชั้นต่อทันที
        #    = คอมโบค้างชั้นของโปรเจกต์เก่า · sim20 ข้อ 6)
        try:
            proj.loadingLayer.connect(self._on_loading_layer)
            self._signal_conns.append((None, "loadingLayer", self._on_loading_layer))
        except Exception:
            pass
        # ★ 2.3.7 (review LC-07) — ชั้นถูกถอดออก ⇒ ทิ้งประวัติ ↺ Undo/คิวล็อกที่อ้างชั้นนั้น (สัญญาณนี้ยิงก่อนชั้นถูกทำลาย)
        try:
            proj.layersWillBeRemoved.connect(self._on_layers_will_be_removed)
            self._signal_conns.append((None, "layersWillBeRemoved", self._on_layers_will_be_removed))
        except Exception:
            pass

    def _push_once(self, key, title, text, level=1, duration=0):
        """★ 2.3.7 (review UX-34) — แถบข้อความแบบ "ตัวเดียวต่อเรื่อง": ถอดแถบเดิมของ key นี้ (ถ้ายังอยู่) ก่อนขึ้นตัวใหม่
        กดปุ่มซ้ำ ๆ แล้วแถบแดง (duration=0 = ค้างจนกดปิด) ไม่ซ้อนกันเป็นตั้ง · แถบที่ผู้ใช้กดปิดไปแล้ว ⇒ ถอดไม่ได้ (RuntimeError) ข้ามไป
        แถบที่ไม่มี pushItem/popWidget (ฮาร์เนสทดสอบ) ⇒ pushMessage แบบเดิม"""
        bar = self.iface.messageBar()
        old = getattr(self, key, None)
        setattr(self, key, None)
        if old is not None:
            try:
                bar.popWidget(old)
            except Exception:
                pass
        try:
            from qgis.gui import QgsMessageBarItem
            item = QgsMessageBarItem(title, text, getattr(Qgis, self._BAR_LEVEL.get(level, "Info")), duration)
            bar.pushItem(item)
            setattr(self, key, item)
            self._bar_keys = set(getattr(self, "_bar_keys", None) or ()) | {key}     # ★ 2.3.7 (audit LIFE-08)
        except Exception:
            bar.pushMessage(title, text, level=level, duration=duration)

    def _push_with_button(self, title, text, level, duration, btn_text, slot):
        """★ 2.3.7 — ข้อความบนแถบข้อความพร้อมปุ่ม (แบบเดียวกับ _donut_step1_msg) · ทำไม่ได้ ⇒ ข้อความธรรมดา
        คืน item (ไว้ popWidget ภายหลัง) หรือ None"""
        bar = self.iface.messageBar()
        try:
            from qgis.gui import QgsMessageBar
            item = QgsMessageBar.createMessage(title, text)
            btn = QtWidgets.QPushButton(btn_text)
            btn.clicked.connect(lambda *_a: slot())
            item.layout().addWidget(btn)
            bar.pushWidget(item, level, duration)
            item._mlep_btn = btn            # ★ 2.3.7 (audit LIFE-08) — จำไว้ให้ unload ถอด/เอาปุ่มออก
            self._bar_track(item)
            return item
        except Exception:
            try:
                bar.pushMessage(title, text, level=level, duration=duration)
            except Exception:
                pass
            return None

    def _bar_track(self, item):
        """★ 2.3.7 (audit LIFE-08) — จำแถบข้อความที่มีปุ่มของ instance นี้ (ตัวที่หมดเวลา/ถูกปิดแล้วถูกทิ้งจากรายการ)"""
        try:
            from qgis.PyQt import sip
            keep = [i for i in (getattr(self, "_bar_btn_items", None) or []) if not sip.isdeleted(i)]
        except Exception:
            keep = list(getattr(self, "_bar_btn_items", None) or [])
        keep.append(item)
        self._bar_btn_items = keep

    def _bar_items_pop(self):
        """★ 2.3.7 (audit LIFE-08) — unload: ถอดแถบข้อความของ instance นี้ที่ยังค้าง (มีปุ่ม · ค้างจนกดปิด · คำแนะนำของเครื่องมือ)
        เดิมค้างหลัง unload/อัปเดตตัวเอง ⇒ ปุ่ม "💾 บันทึก … ด้วย" / "💾 บันทึกเลย" ผูกกับ instance ที่ตายแล้ว = กดแล้วไม่มีอะไรเกิดขึ้น
        ป้าย "⚠️ บันทึกไปชั้นเดียว" (DI-05) ยังเป็นความจริงหลังปิดปลั๊กอิน (อีกชั้นยังค้าง · ห้าม Discard) ⇒ คงข้อความ เอาปุ่มออก"""
        try:
            bar = self.iface.messageBar()
        except Exception:
            return
        try:
            from qgis.PyQt import sip
            _dead = sip.isdeleted
        except Exception:
            def _dead(_o):
                return False
        half = [it for it in (getattr(self, "_half_save_items", None) or {}).values() if it is not None]
        for it in half:
            try:
                b = getattr(it, "_mlep_btn", None)
                if b is not None and not _dead(b):
                    try:
                        b.clicked.disconnect()
                    except Exception:
                        pass
                    b.setEnabled(False)
                    b.hide()
            except Exception:
                pass
        # ★ 2.3.7 b17 (audit nit) — ป้ายที่คงไว้ต้องไม่ค้างตลอดไป: ผูกกับสัญญาณของอีกชั้นตรง ๆ (บันทึก ⇒ เอาออก ·
        #   ทิ้งงาน ⇒ เอาออก + แถบแดง) — instance ใหม่หลังโหลดใหม่ไม่รู้จักป้ายนี้ และอาจยังไม่ได้เปิดแผง (ยังไม่เฝ้าชั้น)
        for _olid, _hs in list((getattr(self, "_half_save_items", None) or {}).items()):
            if _hs is None:
                continue
            try:
                _l = QgsProject.instance().mapLayer(_olid)
                if _l is not None and not _dead(_hs):
                    _half_save_orphan_watch(bar, _hs, _l, getattr(_hs, "_mlep_half_rec", None)
                                            or (getattr(self, "_half_saved", None) or {}).get(_olid))
            except Exception:
                pass
        hids = {id(it) for it in half}
        items = list(getattr(self, "_bar_btn_items", None) or [])
        self._bar_btn_items = []
        for key in set(getattr(self, "_bar_keys", None) or ()) | {"_xform_hint_item", "_donut_hint_item"}:
            items.append(getattr(self, key, None))
            try:
                setattr(self, key, None)
            except Exception:
                pass
        for it in items:
            if it is None or id(it) in hids:
                continue
            try:
                if not _dead(it):
                    bar.popWidget(it)
            except Exception:
                pass

    def _fail(self, title, what, todo="", modal=False, level=2, duration=0, log=True):
        """แจ้งความล้มเหลว: เกิดอะไร (what) · ต้องทำอะไรต่อ (todo) · รายละเอียดทางเทคนิคอยู่ที่ Log แท็บ MLEP
        เรียกในบล็อก except (log=True ⇒ เขียน traceback ผ่าน _log_exc ระดับ Critical) · modal=True ⇒ กล่องข้อความ (_ask)
        ไม่งั้นแถบข้อความ · เดิมแปะ str(e) ดิบ (ภาษาอังกฤษ/ข้อความของฐาน) และหัวข้อ 'Error' ให้พนักงานอ่าน"""
        if log:
            _log_exc(f"{title}: {what}", Qgis.Critical)
        text = what + (f" — {todo}" if todo else "") + f" · {self._LOG_HINT}"
        try:
            if modal:
                self._ask(QtWidgets.QMessageBox.Critical if level >= 2 else QtWidgets.QMessageBox.Warning, title, text)
            else:
                self.iface.messageBar().pushMessage(title, text, level=level, duration=duration)
        except Exception:
            _log_exc("_fail: แสดงข้อความไม่ได้")

    def _feat_label(self, layer, f):
        """★ 2.3.7 (review ER-06) — ชื่อแปลง/หมุดที่พนักงานอ่านรู้เรื่อง ('ระวาง 5136 4 7842-07 ที่ดิน 12' · หมุดมีชื่อ BND_NAME นำ)
        แทน fid ล้วน · ฟีเจอร์ที่อ่านมาไม่ครบคอลัมน์ ⇒ อ่านใหม่ทั้งแถว · อ่านไม่ได้/ไม่มีระวาง ⇒ 'gid N' แบบเดิม"""
        fid = None
        try:
            fid = f if isinstance(f, int) else f.id()
            lab = ""
            for _round in (0, 1):
                if _round or not isinstance(f, QgsFeature):
                    f = layer.getFeature(int(fid))
                lab = _sheet_label(*(_sheet_str(f, k) for k in ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "LANDNO")))
                if lab:
                    break
            nf = _fld_idx(f.fields(), "BND_NAME")
            nm = _txt(f[nf]) if nf >= 0 else ""
            if lab:
                return (f"หมุด {nm} ({lab})" if nm else lab)
            if nm:
                return f"หมุด {nm} (gid {fid})"
        except Exception:
            pass
        return f"gid {fid}" if fid is not None else "(ไม่ทราบแปลง)"

    # ============ กล่องข้อความที่ "มองเห็นแน่นอน" ============
    def _ask(self, icon, title, text, buttons=None, default=None):
        """เปิด QMessageBox โดยผูก parent กับ "หน้าต่างหลักของ QGIS" แล้วบังคับยกขึ้นหน้าสุด

        🔴 เหตุการณ์จริง 2026-08-05 ~19:03 (พนักงานคนหนึ่ง): กดบันทึกหลังแก้งานสะสม ~20 นาที
           แล้วโปรแกรม "ค้าง" จนต้อง kill ทิ้ง — งานทั้ง 20 นาทีหาย (ฐานข้อมูลไม่ได้รับสักแถว)
           ต้นเหตุ: กล่องยืนยัน "พบมุมแปลงที่ไม่มีหมุด" ผูก parent ไว้กับ self.dlg (หน้าต่างปลั๊กอิน)
           ซึ่งอาจถูกย่อ/ถูกบังอยู่หลังหน้าต่างหลัก · กล่องนี้เป็น application-modal = บล็อกทั้ง QGIS
           ผู้ใช้จึงเห็นเป็น "โปรแกรมค้าง" ทั้งที่จริงระบบกำลังรอคำตอบจากกล่องที่มองไม่เห็น
           (บันทึกยืนยัน: 18:31-18:41 บันทึกทีละน้อยผ่านฉลุย เพราะไม่มีมุมขาดหมุด = กล่องไม่เด้ง)
        ⇒ ทุกกล่องที่อยู่ "เส้นทางบันทึก" และกล่องยืนยันสิ่งที่ทำลายข้อมูล ต้องผ่านฟังก์ชันนี้เท่านั้น
        """
        if buttons is None:
            # ★ ให้ default ตรงกับ static API เดิม (2026-08-06): QMessageBox.question() ดีฟอลต์ Yes|No
            #   ถ้าปล่อยเป็น Ok กล่องคำถามจะมีปุ่มเดียว แล้วโค้ดที่เทียบ `!= Yes` จะเป็นจริงเสมอ
            #   (เกือบทำ self-update ตายถาวรทั้งกรม — จับได้ตอน release gate)
            buttons = (QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
                       if icon == QtWidgets.QMessageBox.Question else QtWidgets.QMessageBox.Ok)
        parent = None
        try:
            parent = self.iface.mainWindow()
        except Exception:
            parent = None
        box = QtWidgets.QMessageBox(icon, title, text, buttons, parent)
        if default is not None:
            box.setDefaultButton(default)

        def _lift():
            try:
                box.raise_()
                box.activateWindow()
            except RuntimeError:       # ★ 2.3.7 (LC-11) — กล่องถูกลบไปแล้วก่อนตัวจับเวลายิง
                pass
        try:
            box.setWindowModality(QtCore.Qt.ApplicationModal)
            box.show()
            box.raise_()               # ยกขึ้นเหนือหน้าต่างอื่น
            box.activateWindow()       # และให้โฟกัส (กันไปโผล่หลังจอ)
            # ยกซ้ำอีกครั้งหลัง event loop map หน้าต่างจริง — บาง window manager กิน raise แรก
            # (กล่องเป็น sibling ของหน้าต่างปลั๊กอินแล้ว ไม่ใช่ลูก จึงต้องยกเองให้แน่)
            QtCore.QTimer.singleShot(0, _lift)
        except Exception:
            pass
        self._ask_depth = getattr(self, "_ask_depth", 0) + 1     # ★ audit rc3 — _ask_when_free รอให้กล่องของเราปิดก่อน
        try:
            return box.exec_()
        finally:
            self._ask_depth = max(0, getattr(self, "_ask_depth", 1) - 1)
            # ★ 2.3.7 (review LC-11) — parent = หน้าต่างหลักของ QGIS ⇒ ไม่ลบเอง = ค้างเป็นลูกของหน้าต่างหลัก
            #   ทุกใบจนปิด QGIS (~300 KB/กล่อง · บน Windows กินโควตา USER/GDI handle ของโปรเซสด้วย)
            try:
                box.deleteLater()
            except Exception:
                pass

    def _gesture_busy(self):
        """★ 2.3.7 (audit LIFE-07) — ผู้ใช้กำลังกด/ลากเมาส์อยู่ไหม: ปุ่มเมาส์ค้าง · หรือเครื่องมือของปลั๊กอินกดค้างกลางท่า
        (Move Node: drag_start_pt/is_moving/_placing · กล่องเลือก: _start) — กล่อง modal ที่เด้งตอนนี้จะกินการปล่อยเมาส์"""
        try:
            if QtWidgets.QApplication.mouseButtons() != QtCore.Qt.NoButton:
                return True
        except Exception:
            pass
        try:
            t = self.iface.mapCanvas().mapTool()
        except Exception:
            t = None
        try:
            if t is None or not self._is_plugin_tool(t):
                return False
            if getattr(t, "is_moving", False) is True or getattr(t, "_placing", False) is True:
                return True
            for _a in ("drag_start_pt", "_start"):          # จุดที่กดไว้ (ยังไม่ปล่อย) · ข้ามถ้าเป็นเมธอด
                _v = getattr(t, _a, None)
                if _v is not None and not callable(_v):
                    return True
            return False
        except Exception:
            return False

    def _modal_open(self):
        """มีกล่อง modal เปิดค้างอยู่ไหม — ของใครก็ได้ (กล่องของปลั๊กอิน · QInputDialog · หน้าต่างของ QGIS)
        ★ 2.3.7 (review LC-08) — เดิมดูแค่ธง _modal_busy ซึ่งตั้งแค่ 2 จาก ~110 จุดที่เปิดกล่อง"""
        try:
            if QtWidgets.QApplication.activeModalWidget() is not None:
                return True
        except Exception:
            pass
        return bool(getattr(self, "_modal_busy", False))

    def _ask_when_free(self, icon, title, text, _tries=0):
        """เปิดกล่องข้อความ "เมื่อไม่มีกล่องของปลั๊กอินเปิดค้างอยู่"

        🔴 3 ก.ย. 69 (2.2.4 · จับได้จาก sim16 ค้าง) — กล่องเลือกหมุดของ 2.2.3 ใช้ exec_()
          ซึ่งเปิด nested event loop ⇒ QTimer.singleShot ที่ตั้งไว้ตอน afterCommitChanges
          ไปยิง "ข้างใน" loop นั้น แล้วเปิดกล่องซ้อนบนกล่องเลือกหมุดอีกที
          (โค้ดตรงนั้นมีคอมเมนต์เตือนเรื่องเปิด modal ผิดจังหวะไว้เองอยู่แล้ว)
        ⇒ ถ้ามีกล่องของเราเปิดค้าง ให้เลื่อนออกไปก่อน แล้วค่อยลองใหม่
        """
        if not getattr(self, "_alive", True):
            return
        # ★ มีเพดาน 50 รอบ (~10 วินาที) กันวนไม่รู้จบ ถ้า _modal_busy ค้างเพราะเหตุที่คาดไม่ถึง
        #   ครบเพดานแล้วยอมให้กล่องเด้งไปเลย ดีกว่าเงียบหายจนพนักงานไม่รู้ว่ามีมุมไม่มีหมุด
        # ★ 2.4.2 (audit rc3) — กล่อง _ask ของปลั๊กอินเองยังเปิดอยู่ ⇒ รอต่อโดยไม่นับเพดาน (พนักงานอาจอ่านกล่องนั้นนานเกิน 10 วิ ·
        #   เดิมครบเพดานแล้วเด้งซ้อนบนกล่องนั้น แบบเหตุ 3 ก.ย.) · เพดานยังใช้กับกล่องอื่นที่ไม่รู้ว่าจะปิดเมื่อไร
        if self._modal_open() and (_tries < 50 or getattr(self, "_ask_depth", 0) > 0):      # ★ 2.3.7 (review LC-08)
            QtCore.QTimer.singleShot(
                200, lambda: self._ask_when_free(icon, title, text, _tries + 1))
            return
        # ★ 2.5.0 rc3 text เป็นฟังก์ชันได้ ⇒ ประกอบข้อความตอนกล่องเปิดจริง (สถานะหลังบันทึกครบทุกชั้นแล้ว)
        self._ask(icon, title, text() if callable(text) else text)
