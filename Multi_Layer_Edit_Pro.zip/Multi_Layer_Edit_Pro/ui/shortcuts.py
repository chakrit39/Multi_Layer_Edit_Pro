# -*- coding: utf-8 -*-
"""คีย์ลัดของปลั๊กอิน, การยืม-คืน Ctrl+Z ของ QGIS และหน้าตั้งค่าคีย์ลัด

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import os
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import Qgis, QgsMessageLog
from ..core.const import _MLEP_MAIN_FILE
from ..core.util import _log_exc
from ..ui.qt_helpers import _OWN_PROP, _qobj_dispose


class ShortcutsMixin:
    """คีย์ลัดของปลั๊กอิน, การยืม-คืน Ctrl+Z ของ QGIS และหน้าตั้งค่าคีย์ลัด"""

    def _main_key_filter(self):
        """ตัวดักคีย์ของแผงหลัก — ★ 2.3.7 (review UX-05)
        · Esc = เลิกเครื่องมือของปลั๊กอินที่ค้างบนแคนวาส (สลับเป็นเครื่องมือเลือกของ QGIS — เก็บกวาดผ่าน _map_tool_changed)
                และ **ไม่ปิดแผง** (QDialog ผูก Esc กับ reject() มาในตัว ⇒ เดิมแผงปิดแต่เครื่องมือยัง arm ค้าง)
        · Enter/Return = กินทิ้ง (ปุ่มทุกปุ่มเลิกเป็น autoDefault แล้ว — กันกด Enter แล้วปุ่มที่โฟกัสอยู่ทำงานซ้ำ)
        ปิดแผงด้วยปุ่ม X ยังเหมือนเดิม (ไม่แตะ Close)"""
        plugin = self

        class _MainKeys(QtCore.QObject):
            def eventFilter(self, obj, ev):
                try:
                    if ev.type() == QtCore.QEvent.KeyPress:
                        k = ev.key()
                        if k == QtCore.Qt.Key_Escape:
                            try:
                                cv = plugin.iface.mapCanvas()
                                if cv is not None and plugin._is_plugin_tool(cv.mapTool()):
                                    plugin.iface.actionSelect().trigger()
                            except Exception:
                                pass
                            try:
                                plugin._pair_hl_clear_marks()     # ★ 2.4.0 (review UX-09) Esc = เก็บเครื่องหมายจุดที่ต้องแก้
                            except Exception:
                                pass
                            return True
                        if k in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
                            return True
                except Exception:
                    pass
                return False

        return _MainKeys(self.dlg)

    # ============ Shortcut ปุ่มต่าง ๆ ============
    def _shortcut_actions(self):
        """รายการ action ที่ตั้ง shortcut ได้: (id, label, callable)"""
        return [
            ("parcel_info", "ℹ️ สอบถามข้อมูลแปลง", lambda: self.start_parcel_info()),
            ("dol_search", "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image')),
            ("dol_survey", "📐 ค้นหาหลักฐานการรังวัด", lambda: self.start_dol_search('survey')),
            ("by_cluster", "By Cluster ID", lambda: self.process_selection('cluster')),
            # ★ ปุ่ม By UTM ถูกถอดออกจากแผงตั้งแต่ 2.1.0 (เครื่องมืออื่นเลือกให้เองแล้ว)
            #   แต่ยังต้องคงรายการไว้ เพราะพนักงานที่เคยผูกคีย์ไว้จะเสียคีย์ทันทีถ้าลบ
            #   เปลี่ยนชื่อให้ตรงกับความจริงแทน
            ("by_utm", "เลือกหมุดตาม UTM (ไม่มีปุ่มแล้ว — เครื่องมืออื่นเลือกให้เอง)", lambda: self.process_selection('utm')),
            ("move", "Move", lambda: self.start_interactive('move')),
            ("rotate", "Rotate", lambda: self.start_interactive('rotate')),
            ("scale", "Scale", lambda: self.start_interactive('scale')),
            ("transform", "Transform (คลิก 4 จุด: ต้นทาง 1 → ปลายทาง 1 → ต้นทาง 2 → ปลายทาง 2)",
             lambda: self.start_interactive('transform')),
            ("modify_node", "Move Node", self.start_sync_vertex_tool),
            ("align", "Align Points", self.start_align_tool),
            ("add_node", "Add Node", self.start_add_node),
            ("sync_cluster", "Sync Cluster ID", self.group_cluster_ids),
            ("set_remark", "หมายเหตุ (REMARK)", self.set_remark_value),
            ("score1", "Score = 1", lambda: self.set_score_value(1)),
            ("score0", "Score = 0", lambda: self.set_score_value(0)),
            ("reset", "Reset", self.cancel_transform),
            # ★ 2.4.3 (ผลตรวจ Windows rc3 ข้อ 2) — คีย์ Undo: งานของปลั๊กอินก่อน · ไม่มี ⇒ ส่งต่อ Undo ของ QGIS (_undo_key_pressed)
            ("undo", "Undo", lambda: self._undo_key_pressed()),
            ("save", "บันทึก (Commit)", self.save_all_changes),
        ]

    def _load_shortcuts(self):
        """อ่าน QSettings -> สร้าง QShortcut ผูกกับ main window (ทำงานทั้งแอปขณะใช้ QGIS)"""
        for sc in getattr(self, "_shortcuts", []):
            _qobj_dispose(sc)               # ★ 2.3.7 (audit LIFE-02) ปิด + ถอดจาก QgsShortcutsManager + ลบ
        self._shortcuts = []
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        mw = self.iface.mainWindow()
        # ★ 2.3.7 b13 (review UX-03 ทาง ข · เจ้าของงานตัดสิน 3 ต.ค. 69) — เลิกปลดคีย์ Ctrl+Z ของ QGIS "ถาวร" ลงโปรไฟล์
        #   (เดิมครั้งแรกที่ติดตั้ง: _release_qgis_shortcuts(["Ctrl+Z"]) ผ่าน QgsShortcutsManager = เขียนลงโปรไฟล์ QGIS แล้วไม่เคยคืน
        #    — ปิด/ถอนปลั๊กอินแล้ว Ctrl+Z ของ QGIS ก็ไม่กลับมา และไม่มีข้อความบอก)
        #   ⇒ คีย์ Undo ของปลั๊กอินตั้งต้น Ctrl+Z (ตั้งเฉพาะเมื่อยังไม่เคยมีค่า — ผู้ใช้ล้างเองแล้วไม่ใส่กลับ)
        #   ⇒ ยึดคีย์จาก Undo ของ QGIS เฉพาะตอนปลั๊กอินโหลดอยู่ (_undo_capture ท้ายฟังก์ชันนี้) · คืนตอน unload (_undo_release)
        if not s.contains(k + "undo"):
            s.setValue(k + "undo", "Ctrl+Z")

        for aid, label, slot in self._shortcut_actions():
            seq = s.value(k + aid, "", str)
            if not seq:
                continue
            sc = QtWidgets.QShortcut(QtGui.QKeySequence(seq), mw)
            # ★ 2.3.7 (audit LIFE-02) — ชื่อเฉพาะต่อปุ่ม: QShortcut ไม่มีชื่อที่ QGIS ลงทะเบียนตอนเปิด (สร้างใน initGui) ใช้คีย์โปรไฟล์
            #   '/shortcuts/' ร่วมกันทุกตัว ⇒ อะไรเขียนคีย์นั้น (เช่น 2.3.6 ปลดคีย์ไปโดนคีย์ลัดของปลั๊กอินเอง) = Ctrl+Z + คีย์ซ่อนว่างหมด
            sc.setObjectName("MLEP_sc_" + aid)
            self._tag_own(sc)                   # ★ (audit LIFE-04) ป้ายของ MLEP
            sc.setContext(QtCore.Qt.ApplicationShortcut)
            # ★ shortcut ทำงานได้ตั้งแต่ยังไม่เปิดหน้าต่างปลั๊กอิน (ผูกที่ initGui แล้ว)
            #   ทุก action ยกเว้น undo อ้าง widget ในหน้าต่าง (poly_cb ฯลฯ) -> ต้องกัน
            def _guarded(_slot=slot, _aid=aid):
                # ★ 2.3.7 (review DI-25) — Ctrl+Z ระหว่างวัดระยะ = ถอยจุด/เส้นที่วัด (เท่าปุ่ม ↺ ถอยจุด/เส้น)
                #   เดิมไปย้อนงานแปลง/หมุดล่าสุดเงียบ ๆ (เช่น Move Node ที่เพิ่งทำตามเส้นนำ) ทั้งที่จุดที่คลิกพลาดยังอยู่
                #   คีย์ลัดเป็น ApplicationShortcut ⇒ มาถึงก่อน keyPressEvent ของเครื่องมือ จึงต้องดักที่นี่
                if _aid == "undo" and self._line_owns_undo():
                    self._line_undo()
                    return
                if _aid != "undo" and getattr(self, "dlg", None) is None:
                    self.iface.messageBar().pushMessage(
                        "MLEP", "เปิดหน้าต่างปลั๊กอินก่อน แล้วค่อยใช้คีย์ลัดนี้",
                        level=1, duration=4)
                    return
                # ★ 2.3.7 rc3 — คีย์ลัดต้องผ่านด่าน Topological Editing เหมือนปุ่ม (กติกา 28 ส.ค. "ทุกครั้งที่กดปุ่มใดก็ตาม" ·
                #   ปุ่มดักที่โรงงานสร้างปุ่ม) — เดิมคีย์ลัดข้ามด่านนี้ ⇒ เริ่มเครื่องมือด้วยคีย์ลัดตอนเปิด Topological Editing ไว้ = ไม่ถูกปิดให้
                try:
                    self._topo_guard()
                except Exception:
                    pass
                _slot()
            sc.activated.connect(_guarded)
            if aid == "undo":
                # ★ 2.3.7 b13 (UX-03) — Qt เจอคีย์เดียวกันสองที่ = ไม่ยิงทั้งคู่ (activatedAmbiguously) · ถ้าเพราะ QGIS ตั้งคีย์ Undo
                #   คืนให้ตัวเอง (เช่นตอนเปิด QGIS) ⇒ ยึดคืนแล้วทำ Undo ของปลั๊กอินครั้งนี้เลย
                sc.activatedAmbiguously.connect(lambda _g=_guarded: self._undo_ambiguous(_g))
            self._shortcuts.append(sc)
        # ★ 2.3.7 b13 (UX-03) — ยึดคีย์ Undo ของปลั๊กอินจาก QGIS เฉพาะตอนโหลดอยู่ (ไม่ลงโปรไฟล์) · เปลี่ยนคีย์ = ยึด/คืนตามค่าใหม่
        try:
            self._undo_capture()
        except Exception:
            _log_exc("_load_shortcuts: ยึดคีย์ Undo จาก QGIS ไม่สำเร็จ", once_key="_undo_capture")
        # ★ 2.3.7 b17 (audit R2-LIFE-03) — คีย์ Undo ของ MLEP ชนกับคีย์ลัดทั้งแอปของปลั๊กอินอื่น ⇒ บอกพนักงาน (ครั้งเดียวต่อ session)
        #   ตรวจเมื่อ QGIS เปิดเสร็จแล้วเท่านั้น (ตอนเปิด QGIS ปลั๊กอินอื่นอาจยังไม่โหลด ⇒ _on_qgis_ready เรียกฟังก์ชันนี้อีกที)
        try:
            if self._undo_rival_ready():
                self._undo_rival_warn()
        except Exception:
            _log_exc("_load_shortcuts: ตรวจคีย์ลัดชนกับปลั๊กอินอื่นไม่สำเร็จ", once_key="_undo_rival")

    def _undo_gpkg_claim(self, s):
        """★ 2.3.7 rc3 (Windows audit 🟡3 · ฉาก W) — GPKG_Editor ใช้ Ctrl+Z บนโปรไฟล์นี้ ⇒ คืนหลักฐาน (ข้อความ) · ไม่ใช้ ⇒ ''
        ① มีธงของมัน (GPKGEditor/ShortcutUndoInit) = คำตัดสินเจ้าของงาน 4 ต.ค. 69
        ② ไม่มีธง แต่คีย์ ↺ ของมัน = Ctrl+Z — GPKG_Editor 1.5.1 ตั้งธงแบบเดียวกับ 2.3.5/2.3.6 (ตั้งเฉพาะเมื่อไม่เห็น Ctrl+Z เหลือ
           ซึ่งนับ QShortcut ของตัวเองที่ QGIS ลงทะเบียนตอนเปิดโปรแกรม) ⇒ เครื่องที่ QGIS โหลด GPKG_Editor ตอนเปิด = ไม่มีธง
           ทั้งที่ Ctrl+Z ทั้งแอปของมันทำงานได้เพราะ Undo ของ QGIS ไม่มีคีย์ (ผู้ตรวจวัดบน 3.40.6 จริง ฉาก W: `mActionUndo=` ·
           `[GPKGEditor] Shortcut\\undo=Ctrl+Z` ไม่มีธง · GPKG_Editor ลำพังกด Ctrl+Z ได้) ⇒ ซ่อม (ข) ตรงนี้ = GPKG_Editor กดไม่ได้เงียบ ๆ"""
        if s.contains(self._UNDO_GPKG_KEY):
            return self._UNDO_GPKG_KEY
        try:
            v = s.value(self._UNDO_GPKG_UNDO)
            if isinstance(v, (list, tuple)):        # 'Ctrl+Z, Ctrl+Y' ในไฟล์ ini อ่านกลับมาเป็นรายการ
                v = ", ".join(str(x) for x in v)
            if v and QtGui.QKeySequence(str(v)).toString() == QtGui.QKeySequence("Ctrl+Z").toString():
                return self._UNDO_GPKG_UNDO + "=Ctrl+Z"
        except Exception:
            pass
        return ""

    def _undo_profile_cleared(self, mgr, ua, s):
        """★ 2.3.7 rc3 (Windows audit 🟡2) — โปรไฟล์ QGIS เก็บคีย์ลัดของ Undo เป็น "ค่าว่าง" อย่างชัดแจ้ง (`[shortcuts] mActionUndo=`)
        = ร่องรอยที่ 2.3.5/2.3.6 ปลดคีย์ไว้ (setKeySequence(Undo, '') ลงโปรไฟล์) · ไม่มีคีย์นี้ในโปรไฟล์ (ไม่เคยตั้ง = QGIS ใช้
        ค่าตั้งต้น Ctrl+Z) หรือมีคีย์อื่นอยู่ ⇒ False · คีย์โปรไฟล์ถามจาก QgsShortcutsManager (QGIS ≥3.30: '/shortcuts/mActionUndo')"""
        k = ""
        try:
            k = mgr.objectSettingKey(ua) if mgr is not None else ""
        except Exception:
            k = ""
        k = (k or "shortcuts/" + (ua.objectName() or "mActionUndo")).strip("/")
        if not s.contains(k):
            return False
        v = s.value(k)
        if v is None:                           # '@Invalid()' = QgsSettings ข้ามค่า null ⇒ QGIS ใช้ค่าตั้งต้น (= ไม่เคยตั้ง)
            return False
        if isinstance(v, (list, tuple)):        # 'Ctrl+Z, Ctrl+Y' ในไฟล์ ini อ่านกลับมาเป็นรายการ
            v = "".join(str(x) for x in v)
        return not str(v).strip()

    def _undo_gpkg_skip_log(self, why=""):
        """★ 2.3.7 rc3 (Windows audit 🟡3) — บอกใน Log ครั้งเดียวต่อ session ว่าทำไมไม่คืน Ctrl+Z ให้ Undo ของ QGIS
        why = หลักฐานจาก _undo_gpkg_claim (คีย์ในโปรไฟล์)"""
        app = QtCore.QCoreApplication.instance()
        try:
            if app is not None:
                if app.property(self._UNDO_GPKG_PROP):
                    return
                app.setProperty(self._UNDO_GPKG_PROP, True)
        except Exception:
            pass
        try:
            QgsMessageLog.logMessage(
                "ไม่คืนคีย์ลัด Undo ของ QGIS (Ctrl+Z) — ปลั๊กอิน GPKG Editor ใช้ Ctrl+Z เองทั้งแอป "
                "(ถ้าคืนให้ QGIS แล้ว GPKG Editor ที่เปิดลำพังจะกด Ctrl+Z ไม่ได้) · ตัดสินจาก %s ในโปรไฟล์"
                % (why or self._UNDO_GPKG_KEY), "MLEP", Qgis.Info)
        except Exception:
            pass

    def _undo_key_pressed(self):
        """★ 2.4.3 (ผลตรวจ Windows rc3 ข้อ 2 🟡) — คีย์ Undo ของปลั๊กอิน (ยึด Ctrl+Z จาก Undo ของ QGIS ตอนโหลดอยู่ — _undo_capture)
        มีงานของปลั๊กอินให้ย้อน ⇒ ↺ ของปลั๊กอินตามเดิม · ไม่มี ⇒ ส่งต่อให้ Undo ของ QGIS (ชั้นที่ใช้งาน เช่น จุดที่ลบด้วย Vertex Tool)
        (เดิมขึ้นแถบ "ไม่มีรายการล่าสุดให้ย้อนกลับ" แล้วจบ ⇒ ต้องไปเมนู Edit ▸ Undo เอง) · ปุ่ม ↺ บนแผงยังเป็น Undo ของปลั๊กอินอย่างเดียว
        ★ 2.4.3 (review 🔴1) — งานบนสุดของชั้นที่ใช้งานเป็นของปลั๊กอิน (ประวัติ ↺ ถูกล้างตั้งใจหลังบันทึกได้บางชั้น · เก่าเกินเพดาน 100 งาน)
          ⇒ ไม่ส่งต่อ: Undo ของ QGIS ย้อนทีละชั้น ⇒ แปลงได้คีย์ใหม่แต่หมุดกลับเป็นคีย์เดิม (ผู้ตรวจทานจำลองแล้ว)"""
        if not self.op_history:
            _own = self._own_undo_top()
            if _own:
                self.iface.messageBar().pushMessage(
                    "Undo", f"ไม่ย้อนให้ — งานล่าสุดของชั้น '{_own}' เป็นงานของปลั๊กอินที่ ↺ ย้อนไม่ได้แล้ว "
                            "(อีกชั้นของคู่บันทึกลงฐานไปแล้ว หรือเก่าเกินประวัติ 100 งาน) · ย้อนชั้นเดียวจะทำให้แปลงกับหมุดไม่ตรงกัน"
                            " — ถ้าเพิ่งบันทึกได้บางส่วน ให้กด 💾 บันทึก อีกครั้ง", level=1, duration=12)
                return
            ua = self._qgis_undo_action()
            try:
                if ua is not None and ua.isEnabled():
                    ua.trigger()
                    return
            except Exception:
                _log_exc("คีย์ Undo: ส่งต่อให้ Undo ของ QGIS ไม่สำเร็จ", once_key="_undo_key_fwd")
        self.undo_transform()

    def _qgis_undo_action(self):
        """QAction "Undo" ของ QGIS (เมนู Edit · objectName mActionUndo) หรือ None (โปรแกรมอื่น/ฮาร์เนส)"""
        try:
            mw = self.iface.mainWindow()
            a = mw.findChild(QtWidgets.QAction, "mActionUndo") if mw is not None else None
            if a is None:
                from qgis.gui import QgsGui
                a = QgsGui.shortcutsManager().actionByName("mActionUndo")
            return a
        except Exception:
            return None

    def _undo_key(self):
        """คีย์ Undo ของปลั๊กอินตามที่ตั้งไว้ (รูปแบบเดียวกับ QKeySequence.toString() เช่น 'Ctrl+Z') · ไม่ได้ตั้ง = ''"""
        try:
            k = QtCore.QSettings().value("MultiLayerEditPro/Shortcut/undo", "", str) or ""
            return QtGui.QKeySequence(k).toString() if k else ""
        except Exception:
            return ""

    def _undo_capture(self):
        """ยึดคีย์ Undo ของปลั๊กอินจาก Undo ของ QGIS ที่ตัว QAction ตรง ๆ (ไม่ผ่าน QgsShortcutsManager = ไม่ลงโปรไฟล์) · คืนใน _undo_release
        เรียกซ้ำได้ (initGui · เปิดหน้าต่าง · เปลี่ยนคีย์ · QGIS เปิดเสร็จ · คีย์ชน) · คืน True ถ้าเปลี่ยนคีย์บน QAction ของ QGIS
        ① จำ "คีย์ที่ Undo ของ QGIS ควรมี" ครั้งเดียว — เมื่อ QGIS ลงทะเบียน action กับ QgsShortcutsManager แล้วเท่านั้น
           (ก่อนนั้นคีย์บน action เป็นค่าจากไฟล์ .ui ซึ่ง QGIS จะตั้งทับด้วยค่าจากโปรไฟล์ทีหลัง)
        ② เครื่องที่ 2.3.5/2.3.6 ปลดคีย์ไว้ถาวร (คีย์ของ QGIS ว่าง + ธง ShortcutUndoInit · ★ rc3 หรือไม่มีธงแต่โปรไฟล์เก็บ Undo
           เป็นค่าว่างชัดแจ้ง + คีย์ ↺ ของ MLEP = Ctrl+Z) ⇒ ซ่อมโปรไฟล์กลับเป็นค่าตั้งต้นของ QGIS
           ครั้งเดียว (setKeySequence = ลงโปรไฟล์ ⇒ ถอนปลั๊กอินแล้วเปิด QGIS ใหม่ Ctrl+Z ของ QGIS ยังอยู่) แล้วเลิกใช้ธงเก่า
           (ถ้าถอยกลับไปรุ่นเก่า รุ่นนั้นเห็นว่าไม่มีธง จะปลดคีย์เองตามเดิม ⇒ ไม่เหลือคีย์ชนกัน)
           ★ rc3 ยกเว้น: GPKG_Editor ใช้ Ctrl+Z (ธง GPKGEditor/ShortcutUndoInit หรือไม่มีธงแต่คีย์ ↺ ของมัน = Ctrl+Z
           · _undo_gpkg_claim) ⇒ ไม่ซ่อม · Log Info บอกเหตุครั้งเดียวต่อ session
        ③ เอาเฉพาะคีย์ของปลั๊กอินออกจาก QAction ของ QGIS (คีย์อื่นของ Undo ไม่แตะ) — ปลั๊กอินไม่ได้ใช้คีย์นั้นแล้ว = คืนให้ QGIS"""
        ua = self._qgis_undo_action()
        if ua is None:
            return False
        # ★ 2.3.7 (audit LIFE-01 · C-06 · พิสูจน์บน QGIS 3.44.7 จริง) — ตอนเปิด QGIS ปลั๊กอิน initGui "ก่อน" QGIS ลงทะเบียนคีย์ลัด
        #   (0 action ตอน initGui · 331 ตอน initializationCompleted) และ QGIS จดคีย์ "ปัจจุบัน" ของ action เป็นค่าตั้งต้นตอนลงทะเบียน
        #   ⇒ เดิมล้าง Ctrl+Z ตอนนี้ = ค่าตั้งต้นของ Undo กลายเป็น '' ⇒ ซ่อมโปรไฟล์ของ 2.3.5/2.3.6 (`if dflt:`) ไม่ทำงานทั้งเซสชัน
        #   ⇒ ปิด/ถอนปลั๊กอินแล้วเปิด QGIS ใหม่ = QGIS ไม่มี Ctrl+Z (ผิดคำตัดสิน: ถอนปลั๊กอิน = คืนคีย์ให้ QGIS)
        #   ⇒ Undo ยังไม่ถูกลงทะเบียน ⇒ ไม่แตะเลย · _on_qgis_ready (QGIS เปิดเสร็จ) ยึด + ซ่อมให้
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
        except Exception:
            mgr = None
        registered = None                                     # None = ตรวจไม่ได้ ⇒ ทางเดิม (ดูจากค่าตั้งต้น)
        if mgr is not None:
            try:
                registered = ua in mgr.listActions()
            except Exception:
                registered = None
        if registered is False and not getattr(self, "_qgis_ready", False):
            return False
        cur = [q.toString() for q in ua.shortcuts() if not q.isEmpty()]
        keep = getattr(self, "_qgis_undo_keys", None)
        keep = self._undo_user_changed(cur, keep)             # ★ 2.3.7 b17 (audit R2-LIFE-02)
        if keep is None:
            try:
                dflt = (mgr.defaultKeySequence(ua) or "") if mgr is not None else ""
            except Exception:
                dflt = ""
            if registered or dflt:                            # ① ลงทะเบียนแล้ว ⇒ cur = ค่าจากโปรไฟล์
                s = QtCore.QSettings()
                keep = list(cur)
                legacy = s.contains(self._UNDO_LEGACY_KEY)
                # ② รุ่นก่อนปลดคีย์ Undo ของ QGIS ไว้ถาวร ⇒ ซ่อมโปรไฟล์ เมื่อ (ก) มีธงของ 2.3.5/2.3.6 หรือ
                #   ★ 2.3.7 rc3 (Windows audit 🟡2 · เจ้าของงานตัดสิน 4 ต.ค. 69) (ข) ไม่มีธง แต่โปรไฟล์เก็บ Undo เป็นค่าว่างชัดแจ้ง
                #   และคีย์ ↺ ของ MLEP = Ctrl+Z — 2.3.5/2.3.6 ตั้งธงเฉพาะเมื่อไม่เห็น Ctrl+Z เหลือ ซึ่งนับ QShortcut Ctrl+Z ของ MLEP เอง
                #   ที่ QGIS ลงทะเบียนตอนเปิดโปรแกรมด้วย ⇒ เครื่องที่ QGIS โหลด 2.3.6 ตอนเปิดแล้วเปิดแผง = ปลดคีย์ไปแต่ไม่มีธง
                #   (ผู้ตรวจวัดบน QGIS 3.40.6 จริง ฉาก U: `[shortcuts] mActionUndo=` · ไม่มีธง ⇒ rc1/rc2 ไม่ซ่อม)
                if not keep and (legacy or (self._undo_key() == QtGui.QKeySequence("Ctrl+Z").toString()
                                            and self._undo_profile_cleared(mgr, ua, s))):
                    gpkg = self._undo_gpkg_claim(s)
                    if gpkg:
                        # ★ 2.3.7 rc3 (Windows audit 🟡3 · เจ้าของงานตัดสิน 4 ต.ค. 69) — GPKG_Editor ปลด Ctrl+Z ของ QGIS ไว้และใช้เอง
                        #   (ฉาก Y: ซ่อมแล้วปิด MLEP ⇒ GPKG_Editor ลำพังกด Ctrl+Z ไม่มีอะไรทำงาน) ⇒ ไม่ซ่อม · ไม่แตะธงทั้งสองตัว
                        #   (keep = [] ⇒ unload คืน "ไม่มีคีย์" ให้ Undo ของ QGIS = Ctrl+Z เป็นของ GPKG_Editor ตามเดิม)
                        #   ★ rc3 ฉาก W: GPKG_Editor ไม่มีธง แต่คีย์ ↺ ของมัน = Ctrl+Z ⇒ เหมือนกัน (_undo_gpkg_claim ②)
                        self._undo_gpkg_skip_log(gpkg)
                    else:
                        # ★ (audit LIFE-01) คืน "Ctrl+Z" ตายตัว = คีย์ที่ 2.3.5/2.3.6 ปลดไป (_release_qgis_shortcuts(["Ctrl+Z"]))
                        #   ไม่พึ่ง defaultKeySequence: ถ้ามีอะไรล้างคีย์ก่อน QGIS ลงทะเบียน ค่าตั้งต้นถูกจดเป็น '' ⇒ ไม่ซ่อมเลย
                        dflt = "Ctrl+Z"
                        keep = [QtGui.QKeySequence(dflt).toString()]
                        try:
                            ok = bool(mgr.setKeySequence(ua, dflt))
                        except Exception:
                            ok = False
                            _log_exc("_undo_capture: คืนคีย์ Undo ของ QGIS ลงโปรไฟล์ไม่สำเร็จ")
                        if ok:
                            s.remove(self._UNDO_LEGACY_KEY)  # (ข) ไม่มีธงอยู่แล้ว = ไม่มีผล
                            QgsMessageLog.logMessage(
                                "คืนคีย์ลัด Undo ของ QGIS (%s) ที่รุ่นก่อนปลดไว้ถาวรแล้ว — ปลั๊กอินยึดคีย์เฉพาะตอนโหลดอยู่" % dflt,
                                "MLEP", Qgis.Info)
                        cur = [q.toString() for q in ua.shortcuts() if not q.isEmpty()]
                elif legacy and keep:
                    s.remove(self._UNDO_LEGACY_KEY)          # โปรไฟล์ปกติอยู่แล้ว ⇒ ไม่ต้องใช้ธงเก่า
                self._qgis_undo_keys = keep
        base = list(keep) if keep is not None else \
            cur + [x for x in getattr(self, "_qgis_undo_taken", []) if x not in cur]
        key = self._undo_key()
        want = [x for x in base if x != key]                  # ③
        self._qgis_undo_taken = [x for x in base if key and x == key]
        if want != cur:
            ua.setShortcuts([QtGui.QKeySequence(x) for x in want])
            self._undo_applied = [q.toString() for q in ua.shortcuts() if not q.isEmpty()]     # ★ b17 (R2-LIFE-02)
            return True
        self._undo_applied = list(cur)                        # ★ b17 (R2-LIFE-02) สิ่งที่ MLEP "ถือ" ไว้บน Undo ของ QGIS ตอนนี้
        return False

    def _undo_user_changed(self, cur, keep):
        """★ 2.3.7 b17 (audit R2-LIFE-02 · QGIS 3.44.7 จริง) — คีย์บน Undo ของ QGIS ตอนนี้ (cur) ≠ ที่ MLEP ตั้งไว้ครั้งล่าสุด
        ⇒ มีคนเปลี่ยนระหว่าง MLEP โหลดอยู่ (ผู้ใช้ตั้งใน Settings ▸ Keyboard Shortcuts · ปุ่มคืนค่าตั้งต้นของ QGIS)
        ⇒ นั่นคือ "คีย์ที่ Undo ของ QGIS ควรมี" ชุดใหม่ ⇒ จำแทนชุดเดิม (คืนชุดใหม่) · ไม่เปลี่ยน/ยังไม่เคยตั้ง ⇒ คืน keep เดิม
        เดิมยึดรายการเก่าที่จำไว้ตั้งทับ ⇒ คีย์ใหม่ของผู้ใช้ถูกถอดทิ้งทั้ง session (เปิดแผง MLEP · บันทึกคีย์ของ MLEP)
        และตอน unload ได้ Ctrl+Z เก่าคืนแทนคีย์ของผู้ใช้ (ถูกต้องเฉพาะหลังเปิด QGIS ใหม่)"""
        applied = getattr(self, "_undo_applied", None)
        if keep is None or applied is None or list(cur) == list(applied):
            return keep
        self._qgis_undo_keys = list(cur)
        try:
            QgsMessageLog.logMessage(
                "คีย์ลัด Undo ของ QGIS ถูกเปลี่ยนระหว่างปลั๊กอินโหลดอยู่ (%s → %s) — ใช้ค่าใหม่เป็นค่าที่คืนให้ QGIS"
                % (", ".join(applied) or "-", ", ".join(cur) or "-"), "MLEP", Qgis.Info)
        except Exception:
            pass
        return list(cur)

    def _undo_release(self):
        """คืนคีย์ Undo ให้ QGIS ตอน unload (ค่าที่จำไว้ใน _undo_capture หรือคีย์ที่ยึดไปถ้ายังไม่ได้จำ) · ที่ QAction ตรง ๆ ไม่ลงโปรไฟล์"""
        ua = self._qgis_undo_action()
        if ua is not None:
            try:
                cur = [q.toString() for q in ua.shortcuts() if not q.isEmpty()]
                keys = getattr(self, "_qgis_undo_keys", None)
                keys = self._undo_user_changed(cur, keys)     # ★ 2.3.7 b17 (audit R2-LIFE-02) คืน "คีย์ของผู้ใช้" ไม่ใช่ชุดเก่า
                if keys is None:
                    keys = cur + [x for x in getattr(self, "_qgis_undo_taken", []) if x not in cur]
                if list(keys) != cur:
                    ua.setShortcuts([QtGui.QKeySequence(x) for x in keys])
            except Exception:
                _log_exc("unload: คืนคีย์ Undo ให้ QGIS ไม่สำเร็จ")
        self._qgis_undo_taken = []
        self._undo_applied = None          # ★ 2.3.7 b17 (R2-LIFE-02) คืนแล้ว ไม่ได้ถืออะไรบน Undo ของ QGIS

    def _undo_ambiguous(self, fire):
        """คีย์ Undo ของปลั๊กอินชนกับคีย์อื่น (Qt ไม่ยิงทั้งคู่) · เพราะ QGIS ตั้งคีย์ Undo คืนให้ตัวเอง ⇒ ยึดคืนแล้วทำครั้งนี้เลย
        ชนกับอย่างอื่น (เช่นปลั๊กอินอื่นใช้คีย์เดียวกัน) ⇒ ไม่เดา ไม่ทำ · บอกใน Log ครั้งเดียว"""
        if not getattr(self, "_alive", True):
            return
        try:
            took = self._undo_capture()
        except Exception:
            took = False
            _log_exc("_undo_ambiguous: ยึดคีย์ Undo คืนไม่สำเร็จ", once_key="_undo_ambiguous")
        if took:
            fire()
            return
        try:
            from qgis.gui import QgsGui
            _ua = self._qgis_undo_action()
            if _ua is not None and _ua not in QgsGui.shortcutsManager().listActions():
                return      # ★ 2.3.7 (audit LIFE-01) QGIS ยังเปิดไม่เสร็จ (ยังไม่ลงทะเบียน Undo) — _on_qgis_ready ยึดให้ ไม่ใช่คีย์ชนจริง
        except Exception:
            pass
        if not getattr(self, "_undo_amb_logged", False):
            self._undo_amb_logged = True
            QgsMessageLog.logMessage(
                "คีย์ลัด Undo ของปลั๊กอิน (%s) ชนกับคีย์ของโปรแกรม/ปลั๊กอินอื่น — Qt จึงไม่ทำงานทั้งคู่ "
                "(เปลี่ยนคีย์ได้ที่ ⌨ ตั้งค่า Shortcut ของ MLEP)" % self._undo_key(), "MLEP", Qgis.Warning)
        try:
            self._undo_rival_warn()          # ★ 2.3.7 b17 (audit R2-LIFE-03) — กดแล้วไม่ทำงาน ⇒ บอกพนักงานว่าเพราะอะไร (ครั้งเดียวต่อ session)
        except Exception:
            pass

    def _undo_rival_ready(self):
        """★ 2.3.7 b17 (audit R2-LIFE-03) — ตรวจคีย์ชนได้หรือยัง: QGIS เปิดเสร็จแล้ว (initializationCompleted) หรือ Undo ของ QGIS
        ลงทะเบียนแล้ว (เปิดปลั๊กอินกลาง session) · ตอนเปิด QGIS (initGui ก่อนลงทะเบียน) = ยัง — ปลั๊กอินอื่นอาจยังไม่โหลด"""
        if getattr(self, "_qgis_ready", False):
            return True
        try:
            from qgis.gui import QgsGui
            ua = self._qgis_undo_action()
            return ua is not None and ua in QgsGui.shortcutsManager().listActions()
        except Exception:
            return False

    def _undo_rivals(self):
        """★ 2.3.7 b17 (audit R2-LIFE-03) — QShortcut/QAction ที่ไม่ใช่ของ MLEP ซึ่งใช้คีย์ Undo ของ MLEP (ปกติ Ctrl+Z) แบบชนกันจริง:
        บริบททั้งแอป (ApplicationShortcut · ทุกหน้าต่าง) หรือทั้งหน้าต่างหลัก (WindowShortcut ใต้หน้าต่างหลัก · รวมเมนู/แถบเครื่องมือ)
        ไม่นับ: Undo ของ QGIS เอง (MLEP ยึดคืนเองที่ _undo_ambiguous) · ของที่ติดป้าย MLEP · QShortcut ที่ปิดอยู่"""
        key = self._undo_key()
        mw = self.iface.mainWindow()
        if not key or mw is None:
            return []
        ks = QtGui.QKeySequence(key)
        from qgis.PyQt import sip as _sip

        def _p(o):
            try:
                return _sip.unwrapinstance(o)
            except Exception:
                return None
        mwp = _p(mw)
        uap = _p(self._qgis_undo_action())

        def _in_mw(w):
            n = 0
            while w is not None and n < 50:
                if _p(w) == mwp:
                    return True
                w = w.parentWidget()
                n += 1
            return False
        A, W = QtCore.Qt.ApplicationShortcut, QtCore.Qt.WindowShortcut
        tops = [mw] + [w for w in QtWidgets.QApplication.topLevelWidgets() if _p(w) != mwp]
        out, seen = [], set()
        for top in tops:
            own = _p(top) == mwp
            objs = top.findChildren(QtWidgets.QShortcut) + top.findChildren(QtWidgets.QAction)
            if own:                     # action ที่ไม่มี parent แต่ถูกใส่ในแถบเครื่องมือ/เมนูของหน้าต่างหลัก
                try:
                    objs += list(top.actions())
                    for w in top.findChildren(QtWidgets.QToolBar) + top.findChildren(QtWidgets.QMenu):
                        objs += list(w.actions())
                except Exception:
                    pass
            for o in objs:
                try:
                    po = _p(o)
                    if po in seen:
                        continue
                    seen.add(po)
                    if po == uap or o.property(_OWN_PROP):
                        continue
                    if isinstance(o, QtWidgets.QShortcut):
                        if not o.isEnabled() or o.key() != ks:
                            continue
                        ctx, ws = o.context(), [o.parentWidget()]
                    else:
                        if not any(q == ks for q in o.shortcuts()):
                            continue
                        ctx, ws = o.shortcutContext(), list(o.associatedWidgets())
                    if ctx == A or (own and ctx == W and any(_in_mw(w) for w in ws)):
                        out.append(o)
                except Exception:
                    continue
        return out

    def _undo_rival_names(self, objs):
        """★ 2.3.7 b17 (audit R2-LIFE-03) — ป้ายที่บอกพนักงานได้: "ปลั๊กอิน 'ชื่อ'" (หาวัตถุในตัวแปรของปลั๊กอินใน qgis.utils.plugins
        → ชื่อใน metadata) · หาเจ้าของไม่เจอ ⇒ "คำสั่ง 'ข้อความของ action/ชื่อวัตถุ'" · ไม่มีเลย ⇒ ข้าม"""
        from qgis.PyQt import sip as _sip

        def _p(o):
            try:
                return _sip.unwrapinstance(o)
            except Exception:
                return None
        try:
            import qgis.utils as _qu
            plugins = dict(getattr(_qu, "plugins", None) or {})
        except Exception:
            _qu, plugins = None, {}
        me = os.path.basename(os.path.dirname(_MLEP_MAIN_FILE))
        names = []
        for o in objs:
            po, nm = _p(o), ""
            for pkg, inst in plugins.items():
                if pkg == me or nm:
                    continue
                try:
                    vals = list(vars(inst).values())
                except Exception:
                    continue
                for v in vals:
                    cand = list(v.values()) if isinstance(v, dict) else (list(v) if isinstance(v, (list, tuple, set)) else [v])
                    if any(isinstance(c, QtCore.QObject) and _p(c) == po for c in cand):
                        nm = pkg
                        try:
                            md = _qu.pluginMetadata(pkg, "name")
                            if md and md != "__error__":
                                nm = md
                        except Exception:
                            pass
                        nm = f"ปลั๊กอิน '{nm}'"
                        break
            if not nm:
                try:
                    nm = ((o.text() if isinstance(o, QtWidgets.QAction) else "") or o.objectName() or "").replace("&", "")
                except Exception:
                    nm = ""
                nm = f"คำสั่ง '{nm}'" if nm else ""
            if nm and nm not in names:
                names.append(nm)
        return names

    def _undo_rival_warn(self):
        """★ 2.3.7 b17 (audit R2-LIFE-03 · QGIS 3.44.7 จริง) — ปลั๊กอินอื่นผูก Ctrl+Z ทั้งแอป (เช่น GPKG_Editor ที่อยู่ในเครื่องพนักงาน)
        ⇒ Qt เจอคีย์เดียวกันสองที่ = ไม่ทำงานทั้งคู่ (กด Ctrl+Z แล้วเงียบ ทั้ง ↺ ของ MLEP และของปลั๊กอินนั้น) ⇒ บอกพนักงานครั้งเดียว
        ต่อ session (แถบเหลือง) ว่าเพราะอะไร + ทางออก · ไม่เปลี่ยนพฤติกรรมอื่น (ไม่แย่งคีย์ ไม่ปิดของปลั๊กอินอื่น) · คืน True = เตือนแล้ว"""
        if not getattr(self, "_alive", True):
            return False
        app = QtCore.QCoreApplication.instance()
        try:
            if app is not None and app.property(self._RIVAL_PROP):
                return False
        except Exception:
            pass
        rivals = self._undo_rivals()
        if not rivals:
            return False
        try:
            if app is not None:
                app.setProperty(self._RIVAL_PROP, True)
        except Exception:
            pass
        key = self._undo_key()
        names = self._undo_rival_names(rivals)
        who = ", ".join(names[:3]) if names else "ปลั๊กอิน/คำสั่งอื่น"
        try:
            QgsMessageLog.logMessage("คีย์ลัด Undo ของ MLEP (%s) ชนกับ %s (%d รายการ)" % (key, who, len(rivals)), "MLEP", Qgis.Warning)
        except Exception:
            pass
        self._push_once("_undo_rival_bar", "คีย์ลัดชนกัน",
                        f"{who} ใช้คีย์ {key} เหมือน ↺ Undo ของ MLEP — ขณะเปิดอยู่ทั้งคู่ กด {key} แล้วจะไม่มีอะไรทำงาน "
                        f"· ใช้ปุ่ม ↺ Undo ในหน้าต่าง MLEP แทน หรือปิดคีย์ {key} ของ{who}", level=1, duration=0)
        return True

    def _on_qgis_ready(self, *_a):
        """iface.initializationCompleted — QGIS เปิดเสร็จ (ลงทะเบียน + ตั้งคีย์ลัดจากโปรไฟล์แล้ว) ⇒ สร้างคีย์ลัดใหม่ + ยึดคีย์ Undo
        + จำค่าที่ Undo ของ QGIS ควรมี (+ ซ่อมโปรไฟล์ที่ 2.3.5/2.3.6 ปลดไว้)"""
        if not getattr(self, "_alive", True):
            return
        self._qgis_ready = True
        # ★ 2.3.7 (audit LIFE-01/LIFE-02 · ต้นแบบผ่านบน QGIS 3.44.7 จริง) — ตอนเปิด QGIS:
        #   ① _undo_capture ตอน initGui ข้ามไป (Undo ยังไม่ลงทะเบียน) ⇒ ยึด + ซ่อมโปรไฟล์ที่นี่ (_load_shortcuts เรียกท้ายฟังก์ชัน)
        #   ② QShortcut ที่สร้างตอน initGui ถูก QGIS ลงทะเบียนไปด้วย (ค่าในโปรไฟล์ตั้งคีย์ทับได้ · โผล่ในหน้าคีย์ลัดของ QGIS)
        #      ⇒ สร้างใหม่หลังลงทะเบียน = ไม่ถูกลงทะเบียน · รวมคีย์ซ่อนของโหมดพิเศษ (เดิมบางเครื่องคีย์ว่างจนเปิดหน้าต่าง)
        try:
            self._load_shortcuts()
        except Exception:
            _log_exc("_on_qgis_ready: ยึดคีย์ Undo ไม่สำเร็จ", once_key="_on_qgis_ready")
        try:
            self._make_admin_sc()
        except Exception:
            _log_exc("_on_qgis_ready: สร้างคีย์ลัดซ่อนใหม่ไม่สำเร็จ", once_key="_on_qgis_ready_sc")

    def _make_admin_sc(self):
        """คีย์ลัดซ่อน Ctrl+Shift+F12 (สลับโหมดพิเศษ) · ★ 2.3.7 (audit LIFE-02) ชื่อเฉพาะ + ป้ายของ MLEP · สร้างซ้ำได้
        (ตัวเดิมถูกทิ้งก่อน ⇒ ไม่มีสองตัวคีย์เดียวกัน = Qt ไม่ยิงทั้งคู่)"""
        old = getattr(self, "_admin_sc", None)
        self._admin_sc = None
        if old is not None:
            _qobj_dispose(old)
        sc = QtWidgets.QShortcut(QtGui.QKeySequence("Ctrl+Shift+F12"), self.iface.mainWindow())
        sc.setObjectName("MLEP_sc_mode")
        self._tag_own(sc)
        sc.setContext(QtCore.Qt.ApplicationShortcut)
        sc.activated.connect(self.toggle_admin_mode)
        self._admin_sc = sc
        return sc

    def _admin_shortcut_actions(self):
        """ปุ่มที่มีเฉพาะในโหมดพิเศษ: (id, ป้าย = ข้อความบนปุ่ม, callable เดียวกับปุ่ม, ชั้นที่เห็นปุ่ม) เรียงตามตำแหน่งในกล่อง ADMIN
        ชั้น = ชั้นที่ปุ่มโผล่ (_set_admin_mode) และทุกตัวมีด่านชั้นในตัวเอง (_admin_ready · _mod_ready · toggle_unlock_l1)
        ★ 2.3.9 (เจ้าของงานสั่ง 11 ต.ค. "ปุ่ม แบ่งหัก/แยก ปุ่มสร้างรูปแปลง ผู้ช่วยสามารถใช้ได้") — 🍩 เป็นชั้นผู้ช่วยผู้ดูแล
        (เดิม 2.3.7 rc3: ผู้ช่วยไม่มีปุ่มเพิ่มเลย) · callable หาเมธอดตอนกด (เมธอดเดียวกับที่ปุ่มผูกไว้)"""
        A, MD = self.TIER_ADMIN, self.TIER_MOD
        return [
            ("unlock_l1", "🔓 ปลดล็อก L1", lambda: self.toggle_unlock_l1(), A),
            ("edit_parcel", "📝 แก้ไขข้อมูลรูปแปลง", lambda: self.start_edit_parcel_data(), A),
            ("create_parcel", "➕ สร้างรูปแปลง", lambda: self.start_create_parcel(), MD),     # ★ 2.3.9
            ("audit", "✅ Audit", lambda: self.audit_parcels(), A),
            ("donut", "🍩 แบ่งหัก/แยก", lambda: self.start_donut(), MD),
            ("delete_parcel", "🗑 ลบแปลง", lambda: self.start_delete_parcel(), A),
            # ★ 2.4.3 (เจ้าของงาน 21 ต.ค. 69 "ยุบปุ่มเปลี่ยน type ไปรวมกับปุ่มแก้ไขข้อมูล") — ไม่มีปุ่ม 🏷 แล้ว (เปลี่ยน Type ใน 📝)
            ("assign_owner", "👤 มอบหมาย", lambda: self.assign_owner(), A),
            ("clear_score", "🧹 ล้าง Score", lambda: self.clear_score(), A),
        ]

    def _admin_sc_rows(self):
        """แถวคีย์ลัดโหมดผู้ดูแลที่ใช้ได้ "ตอนนี้" = อยู่ในโหมด และชั้นถึง · ไม่อยู่ในโหมด ⇒ [] เสมอ
        (ชั้นของแถวต่ำกว่าผู้ช่วยผู้ดูแล = ผิดพลาด ⇒ ไม่ให้ — ปิดไว้ก่อนเมื่อไม่แน่ใจ)"""
        if not getattr(self, "_admin_on", False):
            return []
        t = self._tier_now()
        return [r for r in self._admin_shortcut_actions() if t >= r[3] >= self.TIER_MOD]

    def _drop_admin_shortcuts(self):
        """ทิ้ง QShortcut ของปุ่มโหมดผู้ดูแลทั้งหมด (ออกจากโหมด · ก่อนสร้างใหม่ · unload)"""
        for sc in getattr(self, "_admin_shortcuts", None) or []:
            _qobj_dispose(sc)
        self._admin_shortcuts = []

    def _load_admin_shortcuts(self):
        """สร้าง QShortcut ของปุ่มโหมดผู้ดูแลตามโหมด/ชั้นตอนนี้ — ทิ้งชุดเดิมก่อนเสมอ (ไม่อยู่ในโหมด/instance ตายแล้ว = ไม่มีเลย)
        คีย์ที่ชน ⇒ ไม่สร้าง (สองตัวคีย์เดียวกัน Qt ไม่ยิงทั้งคู่ = คีย์ของพนักงาน/QGIS ใช้ไม่ได้ไปด้วย) + แถบเหลือง 1 ข้อความรวมทุกคีย์:
        คีย์ลัดของพนักงานที่ใช้อยู่ · คีย์สลับโหมด · คีย์ที่ QGIS ใช้ (ชุดเดียวกับที่ ⌨ เตือนหลังบันทึก) · คีย์โหมดผู้ดูแลตัวก่อนหน้า
        คืนรายการที่ชน"""
        self._drop_admin_shortcuts()
        if not getattr(self, "_alive", True):
            return []
        rows = self._admin_sc_rows()
        if not rows:
            return []
        s = QtCore.QSettings()
        mw = self.iface.mainWindow()
        names = {aid: label for aid, label, _slot in self._shortcut_actions()}
        taken = {}                          # คีย์ → ชนกับอะไร
        for sc in getattr(self, "_shortcuts", None) or []:
            try:
                q = sc.key().toString()
                if q and sc.isEnabled():
                    aid = sc.objectName()[len("MLEP_sc_"):]
                    taken.setdefault(q, "คีย์ลัด '%s'" % names.get(aid, aid))
            except Exception:
                continue
        for q in self._reserved_shortcut_keys():
            taken.setdefault(q, "คีย์สลับโหมดพิเศษ")
        qgis, clash = None, []
        for aid, label, slot, need in rows:
            try:
                raw = s.value(self._ADMIN_SC_KEY + aid, "", str) or ""
            except Exception:
                raw = ""                    # ค่าในโปรไฟล์เสีย (ไม่ใช่ข้อความ) ⇒ ข้ามแถวนี้แถวเดียว
            seq = QtGui.QKeySequence(raw).toString() if raw else ""
            if not seq:
                continue                    # ว่าง = ไม่ใช้
            who = taken.get(seq)
            if who is None:
                if qgis is None:
                    qgis = self._qgis_shortcut_keys()
                if seq in qgis:
                    nm = self._qgis_key_owner(seq)
                    who = "คีย์ของ QGIS" + (f" '{nm}'" if nm else "")
            if who is not None:
                clash.append(f"{label} = {seq} (ชนกับ{who})")
                continue
            sc = QtWidgets.QShortcut(QtGui.QKeySequence(seq), mw)
            sc.setObjectName(self._ADMIN_SC_NAME + aid)
            self._tag_own(sc)                   # ป้ายของ MLEP (instance ตายโดยไม่ unload ⇒ _mlep_debris_clear เก็บให้)
            sc.setContext(QtCore.Qt.ApplicationShortcut)
            sc.setAutoRepeat(False)             # กดค้าง = คลิกครั้งเดียวแบบปุ่ม (🔓 ปลดล็อก L1 เป็นสวิตช์ — ยิงซ้ำ = สถานะกลับไปกลับมา)
            sc.activated.connect(lambda _s=slot, _n=need, _a=aid: self._admin_sc_fire(_s, _n, _a))
            self._admin_shortcuts.append(sc)
            taken[seq] = "คีย์ลัด '%s'" % label
        if clash:
            self.iface.messageBar().pushMessage(
                "MLEP", "คีย์ลัดโหมดผู้ดูแลที่ไม่ได้เปิดใช้ เพราะคีย์ชนกัน: " + " · ".join(clash)
                + " — เปลี่ยนคีย์ได้ที่ ⌨ ตั้งค่า Shortcut ขณะอยู่ในโหมดผู้ดูแล", level=1, duration=10)
        return clash

    def _sync_admin_shortcuts(self, where):
        """_load_admin_shortcuts แบบไม่โยน error (ล้ม ⇒ ทิ้งหมด = ปิดไว้ก่อน + Log) · ใช้ตอนเปลี่ยนโหมด/บันทึก ⌨"""
        try:
            self._load_admin_shortcuts()
        except Exception:
            self._drop_admin_shortcuts()
            _log_exc("%s: สร้างคีย์ลัดโหมดผู้ดูแลไม่สำเร็จ" % where, once_key="_admin_sc_" + where)

    def _admin_sc_fire(self, slot, need, aid=None):
        """กดคีย์ลัดโหมดผู้ดูแล = ทางเดียวกับคลิกปุ่ม (mkbtn: _topo_guard แล้ว callable ของปุ่ม — ด่านชั้น/ข้อความอยู่ในตัวมันเอง)
        ด่านซ้อนแบบเงียบ: instance ตายแล้ว · ออกจากโหมด/ชั้นไม่ถึง · ไม่มีแผง (ปกติคีย์ถูกทิ้งไปก่อนแล้ว — กันจังหวะคาบเกี่ยวเท่านั้น)
        ★ 2.4.0 (review DI-09) — คีย์ "🔓 ปลดล็อก L1" (aid = 'unlock_l1'): ล็อกกลับ = ทำได้เสมอ (แม้แผงปิด/ไม่มีแผง)
          · ปลดล็อก = ด่าน "เห็นแผง + ถามสิทธิ์จากฐานใหม่" อยู่ใน toggle_unlock_l1 เอง (ปุ่มในแผง · คีย์ลัด · คอนโซล ได้ด่านเดียวกัน)"""
        if not getattr(self, "_alive", True):
            return
        if not getattr(self, "_admin_on", False) or self._tier_now() < need:
            return
        if aid == "unlock_l1" and getattr(self, "_admin_unlock_l1", False):
            slot()                          # ★ 2.4.0 (review DI-09) ล็อก L1 กลับ — ไม่ติดด่านใด
            return
        if getattr(self, "dlg", None) is None:
            return
        if aid == "unlock_l1" and not self._dlg_shown():
            return                          # ★ 2.4.0 (review DI-09) แผงปิด/ย่ออยู่ = มองไม่เห็นป้ายแดง ⇒ ไม่ปลดล็อก (ไม่เด้งกล่อง Topological ด้วย)
        try:
            self._topo_guard()
        except Exception:
            pass
        slot()

    def _qgis_key_owner(self, seq):
        """ชื่อคำสั่งของ QGIS ที่ใช้คีย์ seq (บอกว่าคีย์ลัดโหมดผู้ดูแลชนกับอะไร) · หาไม่เจอ = ''"""
        ks = QtGui.QKeySequence(seq)
        objs = []
        try:
            objs += list(self.iface.mainWindow().findChildren(QtWidgets.QAction))
        except Exception:
            pass
        try:
            from qgis.gui import QgsGui
            _m = QgsGui.shortcutsManager()
            objs += list(_m.listActions()) + list(_m.listShortcuts())
        except Exception:
            pass
        for o in objs:
            try:
                if isinstance(o, QtWidgets.QShortcut):
                    hit = o.key() == ks
                else:
                    hit = any(q == ks for q in (o.shortcuts() or [o.shortcut()]))
                if hit:
                    nm = ((o.text() if isinstance(o, QtWidgets.QAction) else "") or o.objectName() or "").replace("&", "")
                    if nm:
                        return nm
            except Exception:
                continue
        return ""

    def open_shortcut_settings(self):
        """popup ตั้งค่า shortcut แต่ละปุ่ม"""
        dlg = QtWidgets.QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("⌨ ตั้งค่า Shortcut")
        dlg.setMinimumWidth(380)
        v = QtWidgets.QVBoxLayout(dlg)
        v.addWidget(QtWidgets.QLabel(
            "คลิกในช่องแล้วกดคีย์ที่ต้องการ (เว้นว่าง = ไม่ใช้)\nทำงานทั้งแอปขณะใช้ QGIS"))
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        form = QtWidgets.QFormLayout()
        editors = {}
        for aid, label, slot in self._shortcut_actions():
            ed = QtWidgets.QKeySequenceEdit(QtGui.QKeySequence(s.value(k + aid, "", str)))
            editors[aid] = ed
            btn_clr = QtWidgets.QPushButton("✖"); btn_clr.setFixedWidth(28)
            btn_clr.setToolTip("ล้างปุ่มลัดของบรรทัดนี้ให้ว่าง")
            btn_clr.clicked.connect(ed.clear)
            row = QtWidgets.QHBoxLayout(); row.addWidget(ed, 1); row.addWidget(btn_clr, 0)
            w = QtWidgets.QWidget(); w.setLayout(row)
            form.addRow(label + ":", w)
        # ★ 2.3.7 rc3 (เจ้าของงานสั่ง 4 ต.ค.: คีย์ลัดโหมดผู้ดูแล) — แถวของปุ่มโหมดพิเศษ "สร้าง" เฉพาะตอนอยู่ในโหมด และเฉพาะปุ่มที่ชั้นนี้ใช้ได้
        #   ไม่อยู่ในโหมด (หรือชั้นไม่มีปุ่มเพิ่ม) ⇒ ไม่สร้างวิดเจ็ตใด ๆ เลย (ไม่ใช่ซ่อน) = กล่องของพนักงานเหมือนเดิมทุกตัวอักษร
        adm_rows = self._admin_sc_rows()
        adm_eds = {}
        if adm_rows:
            head = QtWidgets.QLabel("คีย์ลัดโหมดผู้ดูแล")
            head.setStyleSheet("color:#b71c1c; font-weight:bold; margin-top:8px;")
            form.addRow(head)
            note = QtWidgets.QLabel("ทำงานเฉพาะตอนอยู่ในโหมดผู้ดูแล · คีย์ที่ชนกับคีย์ลัดของพนักงานหรือของ QGIS จะไม่ถูกเปิดใช้")
            note.setWordWrap(True)
            form.addRow(note)
            for aid, label, _slot, _need in adm_rows:          # แถวแบบเดียวกับของพนักงาน
                ed = QtWidgets.QKeySequenceEdit(QtGui.QKeySequence(s.value(self._ADMIN_SC_KEY + aid, "", str)))
                adm_eds[aid] = ed
                btn_clr = QtWidgets.QPushButton("✖"); btn_clr.setFixedWidth(28)
                btn_clr.setToolTip("ล้างปุ่มลัดของบรรทัดนี้ให้ว่าง")
                btn_clr.clicked.connect(ed.clear)
                row = QtWidgets.QHBoxLayout(); row.addWidget(ed, 1); row.addWidget(btn_clr, 0)
                w = QtWidgets.QWidget(); w.setLayout(row)
                form.addRow(label + ":", w)
        inner = QtWidgets.QWidget(); inner.setLayout(form)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(inner)
        v.addWidget(scroll)
        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        # ★ 2.3.7 (review UX-27) — ตรวจก่อนบันทึก และไม่ปิดกล่องถ้าไม่ผ่าน
        #   เดิมบันทึก + ผูกคีย์ไปก่อนแล้วค่อยเตือนในกล่องผล ⇒ QShortcut สองตัวคีย์เดียวกัน = Qt ถือว่ากำกวม ไม่ยิงทั้งคู่
        #   และตั้งทับคีย์ซ่อนของระบบได้โดยไม่มีคำเตือน (ข้อความกลาง ๆ ไม่เอ่ยว่าคีย์นั้นใช้ทำอะไร)
        warn = QtWidgets.QLabel("")
        warn.setWordWrap(True)
        warn.setStyleSheet("color:#b71c1c; font-weight:bold;")
        warn.setVisible(False)
        v.addWidget(warn)
        v.addWidget(btns)
        reserved = self._reserved_shortcut_keys()
        labels = {aid: label for aid, label, _slot in self._shortcut_actions()}
        # ★ 2.3.7 rc3 — คีย์ซ้ำ/คีย์สงวน ตรวจรวมแถวของพนักงาน + แถวโหมดผู้ดูแล (ถ้ามี) · คีย์ของแถวโหมดผู้ดูแลขึ้นต้น "mode:" กันชื่อชน
        all_eds = dict(editors)
        all_eds.update({"mode:" + aid: ed for aid, ed in adm_eds.items()})
        labels.update({"mode:" + aid: label for aid, label, _slot, _need in adm_rows})

        def _validate():
            use = {}
            for aid, ed in all_eds.items():
                seq = ed.keySequence().toString()
                if seq:
                    use.setdefault(seq, []).append(aid)
            res = {q for q in use if q in reserved}
            dup = {q: a for q, a in use.items() if len(a) > 1 and q not in res}
            for aid, ed in all_eds.items():
                seq = ed.keySequence().toString()
                ed.setStyleSheet("border:2px solid #d32f2f;" if seq and (seq in res or seq in dup) else "")
            msgs = []
            if dup:
                msgs.append("⚠️ คีย์ซ้ำกัน (1 คีย์ใช้ได้กับปุ่มเดียว): " + " · ".join(
                    f"{q} = {' / '.join(labels.get(a, a) for a in aids)}" for q, aids in sorted(dup.items())))
            if res:
                msgs.append("⚠️ คีย์ในช่องที่ขีดแดงระบบใช้อยู่ — เลือกคีย์อื่น")
            if msgs:
                warn.setText("\n".join(msgs) + "\n(ยังไม่ได้บันทึก — แก้ช่องที่ขีดแดงแล้วกด Save อีกครั้ง)")
                warn.setVisible(True)
                return
            dlg.accept()
        btns.accepted.connect(_validate); btns.rejected.connect(dlg.reject)
        try:
            _accepted = dlg.exec_() == QtWidgets.QDialog.Accepted
            vals = {aid: ed.keySequence().toString() for aid, ed in editors.items()}
            adm_vals = {aid: ed.keySequence().toString() for aid, ed in adm_eds.items()}     # ★ 2.3.7 rc3
        finally:
            dlg.deleteLater()               # ★ 2.3.7 (review LC-11) — ไม่ค้างเป็นลูกของหน้าต่างหลัก
        if _accepted:
            for aid, seq in vals.items():
                s.setValue(k + aid, seq)
            # ★ 2.3.7 rc3 (เจ้าของงานสั่ง 4 ต.ค.: คีย์ลัดโหมดผู้ดูแล) — เขียนเฉพาะแถวที่แสดง และเฉพาะปุ่มที่ชั้น "ตอนกดบันทึก" ยังใช้ได้
            #   (กล่องที่เปิดตอนไม่อยู่ในโหมดไม่มีแถวเหล่านี้ · หลุดโหมดระหว่างเปิดกล่อง ⇒ ไม่แตะคีย์ที่ตั้งไว้)
            #   ทิ้งชุดเดิมก่อนผูกคีย์ของพนักงานใหม่ (ไม่มีสองตัวคีย์เดียวกันแม้ชั่วขณะ) · สร้างใหม่ท้ายสุดหลังคีย์ของพนักงาน/QGIS ลงตัว
            _adm_ok = {r[0] for r in self._admin_sc_rows()}
            for aid, seq in adm_vals.items():
                if aid in _adm_ok:
                    s.setValue(self._ADMIN_SC_KEY + aid, seq)
            self._drop_admin_shortcuts()
            # ★ 2.3.7 b13 (UX-03) — โหลดคีย์ใหม่ก่อน (ยึด/คืนคีย์ Undo ของ QGIS ตามค่าใหม่) แล้วค่อยตรวจชนกับคีย์ของ QGIS
            #   (เดิมตรวจก่อน ⇒ ย้ายคีย์ Undo ของปลั๊กอินออกจาก Ctrl+Z แล้วเอา Ctrl+Z ไปใช้ปุ่มอื่น = ไม่เห็นว่าชนกับ Undo ของ QGIS)
            self._load_shortcuts()
            qgis_keys = self._qgis_shortcut_keys()
            conflict = {seq for seq in vals.values() if seq and seq in qgis_keys}
            msg = "บันทึก shortcut แล้ว ✅"
            if conflict:
                ck = ", ".join(sorted(conflict))
                ans = self._ask(
                    QtWidgets.QMessageBox.Question, "คีย์ชนกับ QGIS",
                    f"คีย์เหล่านี้ QGIS ใช้อยู่: {ck}\n"
                    "ถ้าปล่อยไว้ Qt จะถือว่ากำกวม → ปุ่มลัดอาจไม่ทำงาน\n\n"
                    "ต้องการให้ปลดคีย์เดิมของ QGIS ออก เพื่อให้ปลั๊กอินใช้คีย์นี้ได้ไหม?\n"
                    "(เปลี่ยนคีย์ลัด QGIS ถาวร — ย้อนคืนได้ที่ Settings → Keyboard Shortcuts)",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No)
                if ans == QtWidgets.QMessageBox.Yes:
                    released = self._release_qgis_shortcuts(conflict)
                    self._load_shortcuts()   # โหลดใหม่ให้คีย์ปลั๊กอินจับได้หลังปลดคีย์ QGIS
                    if released:
                        msg += f"\n✅ ปลดคีย์ QGIS แล้ว: {', '.join(sorted(released))}"
                    left = conflict - released
                    if left:
                        msg += (f"\n⚠️ ปลดไม่ได้: {', '.join(sorted(left))} "
                                "(แก้เองที่ Settings → Keyboard Shortcuts)")
                else:
                    msg += f"\n⚠️ ยังชนกับ QGIS: {ck} (ปุ่มลัดอาจไม่ทำงาน)"
            # ★ 2.3.7 rc3 (เจ้าของงานสั่ง 4 ต.ค.: คีย์ลัดโหมดผู้ดูแล) — สร้างคีย์ลัดโหมดผู้ดูแลใหม่ (ไม่อยู่ในโหมด = ไม่มีอะไรเกิดขึ้น)
            #   คีย์โหมดผู้ดูแลที่ชนกับคีย์ของ QGIS ไม่เข้ากล่อง "ปลดคีย์ QGIS" ข้างบน (ปลดถาวรลงโปรไฟล์ = พนักงานที่ใช้โปรไฟล์เดียวกัน
            #   เสียคีย์ของ QGIS ไปเพื่อปุ่มที่ตัวเองไม่มี) ⇒ ไม่สร้างตัวที่ชน + แถบเหลืองบอก (ใน _load_admin_shortcuts)
            self._sync_admin_shortcuts("open_shortcut_settings")
            self._ask(QtWidgets.QMessageBox.Information, "Shortcut", msg)

    def _release_qgis_shortcuts(self, keys):
        """ปลดคีย์เดิมของ QGIS ที่ชน ผ่าน QgsShortcutsManager (บันทึกถาวร) -> set คีย์ที่ปลดได้"""
        released = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
        except Exception:
            return released
        for key in keys:
            seq = QtGui.QKeySequence(key)
            obj = None
            for getter in ("objectForSequence", "actionForSequence", "shortcutForSequence"):
                if hasattr(mgr, getter):
                    try:
                        obj = getattr(mgr, getter)(seq)
                    except Exception:
                        obj = None
                    if obj is not None:
                        break
            if obj is not None:
                try:
                    if mgr.setKeySequence(obj, ""):
                        released.add(key)
                except Exception:
                    pass
        return released

    def _reserved_shortcut_keys(self):
        """คีย์ของ QShortcut ภายในปลั๊กอินที่ตั้งให้ปุ่มอื่นไม่ได้ — อ่านจากตัว QShortcut จริง (ไม่พิมพ์ค่าซ้ำในโค้ด)
        ★ 2.3.7 (review UX-27) — ตั้งทับแล้วมี QShortcut สองตัวคีย์เดียวกัน ⇒ Qt ไม่ยิงทั้งคู่"""
        keys = set()
        sc = getattr(self, "_admin_sc", None)
        try:
            t = sc.key().toString() if sc is not None else ""
        except Exception:
            t = ""
        if t:
            keys.add(t)
        return keys

    def _qgis_shortcut_keys(self):
        """รวมคีย์ลัดที่ QGIS ใช้อยู่ (ไว้เตือนเมื่อตั้งคีย์ชนกันจน Qt ถือว่ากำกวม)"""
        keys = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
            for a in mgr.listActions():
                for _q in (a.shortcuts() or [a.shortcut()]):     # ★ 2.3.7 (review UX-27) — รวมคีย์รองด้วย
                    t = _q.toString()
                    if t:
                        keys.add(t)
            for sc in mgr.listShortcuts():
                t = sc.key().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        try:
            for a in self.iface.mainWindow().findChildren(QtWidgets.QAction):
                for _q in (a.shortcuts() or [a.shortcut()]):     # ★ 2.3.7 (review UX-27) — รวมคีย์รองด้วย
                    t = _q.toString()
                    if t:
                        keys.add(t)
        except Exception:
            pass
        return keys
