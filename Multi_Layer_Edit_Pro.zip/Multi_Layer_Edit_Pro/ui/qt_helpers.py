# -*- coding: utf-8 -*-
"""ตัวช่วยฝั่ง Qt: ยกหน้าต่าง, เก็บกวาด QAction/QShortcut ที่ค้าง, แถบเตือนบันทึกครึ่งคู่, เครื่องมือคลิกจุด

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import Qgis, QgsMessageLog
from qgis.gui import QgsMapToolEmitPoint
from ..map_tools import _MlepKeys


def _lift_dlg(w):
    """ยกหน้าต่างขึ้นหน้าสุด + โฟกัส — ทนหน้าต่างที่ถูกลบไปแล้ว (★ 2.3.7 LC-11: ใช้กับตัวจับเวลาที่อาจยิงหลัง deleteLater)"""
    try:
        w.raise_()
        w.activateWindow()
    except RuntimeError:
        pass


def _whats_new_rows(entries):
    """แถว HTML ของหน้าต่าง What's New จาก [(เวอร์ชัน, [ข้อความ, ...]), ...]

    ★ 2.3.7 (review UX-26) — ข้อความ changelog เป็นข้อความล้วน ต้อง escape ก่อนใส่ HTML
      เดิมใส่ดิบ ⇒ '<อำเภอ>_V3.qgz' แสดงเป็น '_V3.qgz' · '(CT_<สาขา>)' เป็น '(CT_)' (Qt ถือเป็นแท็กแล้วทิ้ง)
      markup อยู่ในแม่แบบนี้เท่านั้น"""
    import html as _html
    rows = []
    for v, items in entries:
        rows.append(f"<b>v{_html.escape(str(v), quote=False)}</b>")
        rows += [f"&nbsp;&nbsp;• {_html.escape(str(it), quote=False)}" for it in items]
        rows.append("")
    return rows


# ==================== ★ 2.3.7 (audit LIFE-02/LIFE-04) ของที่ MLEP สร้างบนหน้าต่างหลักของ QGIS ====================
_OWN_PROP = "_mlep_owner"       # ป้าย (dynamic property) บน QAction/QShortcut ที่ MLEP สร้างบนหน้าต่างหลัก = token ของ instance
_MLEP_MENU = "&Multi-Layer Edit Pro"


def _qobj_dispose(o):
    """ทิ้ง QShortcut/QAction ของ MLEP ให้หมดจริง: ปิด · ถอดจาก QgsShortcutsManager (ตอนเปิด QGIS ตัวที่สร้างก่อน QGIS ลงทะเบียน
    คีย์ลัดจะถูกลงทะเบียนไปด้วย) · ตัด signal · ตัดจากหน้าต่างหลัก · ลบ · พังก็ไม่เป็นไร"""
    if o is None:
        return
    try:
        from qgis.gui import QgsGui
        _mgr = QgsGui.shortcutsManager()
    except Exception:
        _mgr = None
    try:
        if isinstance(o, QtWidgets.QShortcut):
            o.setEnabled(False)                 # ปิดก่อน — ระหว่างรอ deleteLater ไม่ชนกับตัวใหม่ (Qt ถือว่ากำกวม)
            sigs = (o.activated, o.activatedAmbiguously)
            _unreg = getattr(_mgr, "unregisterShortcut", None)
        else:
            sigs = (o.triggered,)
            _unreg = getattr(_mgr, "unregisterAction", None)
        if _unreg is not None:
            try:
                _unreg(o)
            except Exception:
                pass
        for sig in sigs:
            try:
                sig.disconnect()
            except Exception:
                pass
        o.setParent(None)
        o.deleteLater()
    except Exception:
        pass


def _mlep_debris_clear(iface, undo_keys=None, keep=None):
    """★ 2.3.7 (audit LIFE-04) — รุ่นใหม่ล้มกลาง initGui ⇒ QGIS ทิ้ง instance นั้นโดยไม่เรียก unload ⇒ ไอคอน/QShortcut ที่มันสร้าง
    ค้างบนหน้าต่างหลัก (Ctrl+Z ซ้อน 2 ตัว = Qt ไม่ยิงทั้งคู่ + TypeError ทุกครั้งที่กด · ไอคอน 2 อัน) และคีย์ Undo ของ QGIS ถูกยึดค้าง
    ⇒ ก่อนเปิดรุ่นเดิมกลับมา: เอาของที่ติดป้าย _mlep_owner ออกทั้งหมด (ยกเว้นของ instance ที่ยังเปิดอยู่ = keep) แล้วคืนคีย์ Undo
    undo_keys = คีย์ที่ Undo ของ QGIS ควรมี (จำจาก instance เดิมก่อนสั่งโหลดใหม่) · None = ไม่แตะ · คืนจำนวนชิ้นที่เก็บ"""
    n = 0
    try:
        mw = iface.mainWindow()
    except Exception:
        mw = None
    if mw is not None:
        for cls in (QtWidgets.QShortcut, QtWidgets.QAction):
            try:
                objs = mw.findChildren(cls)
            except Exception:
                objs = []
            for o in objs:
                try:
                    tok = o.property(_OWN_PROP)
                except Exception:
                    continue
                if not tok or (keep is not None and tok == keep):
                    continue
                if cls is QtWidgets.QAction:
                    try:
                        iface.removeToolBarIcon(o)
                    except Exception:
                        pass
                    try:
                        iface.removePluginMenu(_MLEP_MENU, o)
                    except Exception:
                        pass
                _qobj_dispose(o)
                n += 1
    if undo_keys is not None:
        try:
            ua = mw.findChild(QtWidgets.QAction, "mActionUndo") if mw is not None else None
            if ua is None:
                from qgis.gui import QgsGui
                ua = QgsGui.shortcutsManager().actionByName("mActionUndo")
            if ua is not None:
                cur = [q.toString() for q in ua.shortcuts() if not q.isEmpty()]
                if list(undo_keys) != cur:
                    ua.setShortcuts([QtGui.QKeySequence(x) for x in undo_keys])
        except Exception:
            pass
    return n


def _half_rb_text(nm, rec):
    """★ 2.3.7 (review DI-05 · b17 แยกออกมา) — ข้อความ "ทิ้งงานของอีกชั้นหลังชั้นหนึ่งลงฐานไปแล้ว" (ใช้ทั้ง instance และป้ายที่ค้างหลังโหลดใหม่)"""
    keys = rec.get("keys") or rec.get("rb_keys") or set()
    ks = sorted(keys)
    smp = ", ".join(ks[:10]) + (f" … (รวม {len(ks):,})" if len(ks) > 10 else "")
    return (f"ทิ้งงานของชั้น '{nm}' ไปแล้ว แต่ชั้น '{rec.get('saved')}' ลงฐานไปก่อนหน้านี้ — แปลงกับหมุดในฐานไม่ตรงกัน"
            + (f" ที่ UTM {smp}" if smp else "") + " · ต้องแก้ให้ตรงกันแล้วบันทึกใหม่")


_HALF_PROP = "_mlep_half_save"      # ★ b17 — ป้ายบนแถบ "⚠️ บันทึกไปชั้นเดียว" = id ของชั้นที่ยังค้าง


def _half_save_orphans_pop(bar, lid, keep=None):
    """★ 2.3.7 b17 (audit nit) — ป้าย "⚠️ บันทึกไปชั้นเดียว" ของชั้น lid ที่ instance ก่อนโหลดใหม่ทิ้งไว้บนแถบ (unload คงไว้ — LIFE-08)
    ⇒ เอาออก (instance ใหม่ไม่รู้จักมัน เดิมจึงค้างตลอดไป) · คืนบันทึก (rec) ที่ติดมากับป้าย ไว้ทำข้อความ "ทิ้งงาน" ต่อ"""
    recs = []
    try:
        items = list(bar.items())
    except Exception:
        return recs
    for x in items:
        try:
            if x is keep or x.property(_HALF_PROP) != lid or getattr(x, "_mlep_half_done", False):
                continue
            x._mlep_half_done = True
            r = getattr(x, "_mlep_half_rec", None)
            if r:
                recs.append(r)
            bar.popWidget(x)
        except Exception:
            continue
    return recs


def _half_save_orphan_watch(bar, item, lyr, rec):
    """★ 2.3.7 b17 (audit nit) — unload คงป้าย "⚠️ บันทึกไปชั้นเดียว" ไว้ (ยังเป็นความจริง) แต่ไม่มีใครเก็บ ⇒ ค้างตลอดไป
    ⇒ ผูกกับสัญญาณของ "อีกชั้น" ตรง ๆ โดยไม่อ้าง instance ที่ตายแล้ว: บันทึกชั้นนั้น ⇒ เอาป้ายออก · ทิ้งงานชั้นนั้น ⇒ เอาป้ายออก
    + แถบแดงแบบ _half_save_rolled_back · ทำครั้งเดียวแล้วตัดสัญญาณ · instance ใหม่จัดการไปก่อนแล้ว (_mlep_half_done) ⇒ ไม่ซ้ำ"""
    from qgis.PyQt import sip as _sip
    conns = []

    def _dead(o):
        try:
            return _sip.isdeleted(o)
        except Exception:
            return False                    # ไม่ใช่วัตถุของ sip (ตัวปลอมในเทส) = ยังอยู่

    def _done(rolled_back):
        while conns:
            _sig, _fn = conns.pop()
            try:
                _sig.disconnect(_fn)
            except Exception:
                pass
        if getattr(item, "_mlep_half_done", False):
            return
        item._mlep_half_done = True
        try:
            if not _dead(item):
                bar.popWidget(item)
        except Exception:
            pass
        if rolled_back and rec:
            try:
                msg = _half_rb_text(lyr.name(), rec)
                QgsMessageLog.logMessage("บันทึกไม่ครบคู่: " + msg, "MLEP", Qgis.Critical)
                if not _dead(bar):
                    bar.pushMessage("⚠️ แปลงกับหมุดไม่ตรงกันในฐาน", msg, level=2, duration=0)
            except Exception:
                pass

    def _on_commit(*_a):
        _done(False)

    def _on_rollback(*_a):
        _done(True)
    for _sig, _fn in ((lyr.afterCommitChanges, _on_commit), (lyr.afterRollBack, _on_rollback)):
        try:
            _sig.connect(_fn)
            conns.append((_sig, _fn))
        except Exception:
            pass
    return len(conns)




class _EmitClickTool(_MlepKeys, QgsMapToolEmitPoint):
    """★ 2.3.7 (review UX-02 / LC-04) — เครื่องมือคลิกจุดของ Move/Rotate/Scale/Transform และ Align ขั้น ②

    เดิมเป็น QgsMapToolEmitPoint เปล่า ๆ = ไม่มีคีย์ลัดเลย ทั้งที่ข้อความแนะนำของ Align บอก "Esc = ยกเลิก"
    และ Backspace/Delete ไม่ถูก "กิน" ⇒ QGIS เอาไปสั่ง "ลบฟีเจอร์ที่เลือกไว้" ของชั้นที่แก้อยู่ (ไม่ถามถ้าอยู่ในจอ)
    ระหว่างที่กลุ่มแปลง+หมุดถูกเลือกค้างไว้พอดี
    Esc → on_key("esc") · Backspace/Delete → on_key("back") · คีย์ที่ใช้แล้วต้อง ignore() = "เครื่องมือกินคีย์แล้ว"
    (กติกาคีย์ของ QGIS กลับด้านโดยตั้งใจ — ดู DrawLineTool._กินคีย์ ใน map_tools)
    ★ 2.3.7 (audit F1) — _MlepKeys: ระหว่างกดปุ่มเมาส์ค้าง แคนวาสไม่ส่งคีย์ให้เครื่องมือ ⇒ ตัวกรองบนแคนวาสส่ง Backspace/Delete
      มาที่ keyPressEvent นี้แทน (แคนวาสไม่เห็นคีย์ ⇒ QGIS ไม่ลบฟีเจอร์ที่เลือก)"""

    def __init__(self, canvas, on_key):
        super().__init__(canvas)
        self._on_key = on_key
        # ป้าย "เครื่องมือของ MLEP" (แบบเดียวกับที่ LC-03c ใช้ทุกจุดสร้างเครื่องมือ) — ใส่ที่ตัวสร้างแทนจุดสร้าง
        self.setProperty("_mlep_tool", True)

    def keyPressEvent(self, e):
        k = e.key()
        if k == QtCore.Qt.Key_Escape:
            what = "esc"
        elif k in (QtCore.Qt.Key_Backspace, QtCore.Qt.Key_Delete):
            what = "back"
        else:
            return
        try:
            e.ignore()
        except Exception:
            pass
        try:
            self._on_key(what)
        except Exception:
            import traceback
            QgsMessageLog.logMessage("_EmitClickTool: " + traceback.format_exc(), "MLEP", Qgis.Warning)


class _EscWatch(QtCore.QObject):
    """★ 2.4.0 (review UX-09) — ตัวดัก Esc บนแผนที่ (ติดตั้งเฉพาะตอนมีเครื่องหมาย "จุดที่ต้องแก้" ของด่านจับคู่)
    Esc ⇒ เรียก on_esc (เก็บเครื่องหมาย) · ไม่กินคีย์ (เครื่องมือที่ใช้อยู่ยังได้ Esc ตามเดิม)"""

    def __init__(self, on_esc):
        super().__init__()
        self._on_esc = on_esc

    def eventFilter(self, obj, ev):
        try:
            if ev.type() == QtCore.QEvent.KeyPress and ev.key() == QtCore.Qt.Key_Escape:
                self._on_esc()
        except Exception:
            pass
        return False


class _FitScroll(QtWidgets.QScrollArea):
    """★ rc9 (ผลตรวจ Windows rc8 ⚪8 · agent B ⚪6 · agent A 🟡2) กรอบเลื่อนรอบส่วนฟอร์มของ 📝 ที่ "สูงเท่าเนื้อหา"
    sizeHint / heightForWidth = ของเนื้อหาเต็ม ⇒ จอพอ: ไม่มีแถบเลื่อน ขนาดหน้าต่างคิดแบบเดิมทุกอย่าง (_fit_now · _grow_to_fit)
    minimumSizeHint สูงแค่ _MIN_H ⇒ จอเตี้ยกว่าเนื้อหา (เช่น 1366×768 ปรับ 125% · พื้นที่ 1093×587) หน้าต่างหดลงได้ ปุ่ม OK/Cancel
    อยู่ในจอเสมอ ส่วนฟอร์มเลื่อนดูได้ — rc8 ไม่มีกรอบเลื่อน ⇒ ความสูงขั้นต่ำของ layout ดันปุ่มตกใต้แถบงาน 40 px
    (QScrollArea ปกติจำกัด sizeHint ไว้ 24 บรรทัด ⇒ ต้องคืนขนาดของเนื้อหาเอง) · ความกว้างขั้นต่ำเผื่อแถบเลื่อนแนวตั้ง (ไม่มีแถบแนวนอน)"""
    _MIN_H = 120

    def __init__(self, body, parent=None):
        super().__init__(parent)
        self.setWidget(body)
        self.setWidgetResizable(True)
        self.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        self.setFocusPolicy(QtCore.Qt.NoFocus)     # ไม่แทรกในลำดับ Tab (เคอร์เซอร์เริ่มที่ชนิดเอกสารตามเดิม · sim119 U2)

    def _body_h(self, w):
        b = self.widget()
        if b is None:
            return 0
        lay = b.layout()
        if lay is not None and lay.hasHeightForWidth():
            return lay.totalHeightForWidth(max(1, int(w)))
        return b.sizeHint().height()

    def sizeHint(self):
        b = self.widget()
        if b is None:
            return super().sizeHint()
        s = b.sizeHint()
        f = 2 * self.frameWidth()
        return QtCore.QSize(s.width() + f, s.height() + f)

    def minimumSizeHint(self):
        b = self.widget()
        if b is None:
            return super().minimumSizeHint()
        m = b.minimumSizeHint()
        f = 2 * self.frameWidth()
        sb = self.verticalScrollBar().sizeHint().width()
        return QtCore.QSize(m.width() + f + sb, min(self._MIN_H, self._body_h(m.width()) + f))

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, w):
        f = 2 * self.frameWidth()
        return self._body_h(w - f) + f

    def _fix_policy(self):
        """แถบเลื่อนแนวตั้ง: สูงพอสำหรับเนื้อหาที่ความกว้างเต็ม ⇒ ปิด · ไม่พอ ⇒ ตามต้องการ — กันอาการค้างของ QScrollArea กับเนื้อหาที่ตัดบรรทัด
        (แถบโผล่ ⇒ พื้นที่แคบลง ⇒ ข้อความสูงขึ้น ⇒ แถบไม่หายแม้หน้าต่างขยายพอแล้ว)"""
        try:
            f = 2 * self.frameWidth()
            pol = (QtCore.Qt.ScrollBarAlwaysOff if self.height() >= self._body_h(self.width() - f) + f
                   else QtCore.Qt.ScrollBarAsNeeded)
            if self.verticalScrollBarPolicy() != pol:
                self.setVerticalScrollBarPolicy(pol)
        except RuntimeError:
            pass

    def resizeEvent(self, e):
        self._fix_policy()
        super().resizeEvent(e)

    def eventFilter(self, o, e):
        # เนื้อหาเปลี่ยน (แถวโผล่/ข้อความยาวขึ้น ⇒ LayoutRequest ที่ตัวเนื้อหา) ⇒ ล้างค่า sizeHint/heightForWidth ที่ layout ของหน้าต่างจำไว้
        #   (QWidgetItemV2 จำค่าต่อความกว้าง ⇒ ไม่ล้าง = หน้าต่างคิดจากความสูงเก่า ⇒ กรอบเตี้ยกว่าเนื้อหา ⇒ แถบเลื่อนโผล่ทั้งที่จอพอ)
        try:
            if o is self.widget() and e.type() == QtCore.QEvent.LayoutRequest:
                self.updateGeometry()
        except RuntimeError:
            pass
        return super().eventFilter(o, e)


class _FitVBox(QtWidgets.QVBoxLayout):
    """★ rc10 (ผลตรวจ Windows rc9 🟡1 🟡2) layout บนสุดของหน้าต่างที่มี _FitScroll (📝) — heightForWidth = เนื้อหาเต็มตามเดิม (ใช้คิดขนาด
    หน้าต่าง: _fit_now · _grow_to_fit) แต่ minimumHeightForWidth ไม่นับส่วนที่กรอบเลื่อนสูงเกินขั้นต่ำของมัน (_FitScroll._MIN_H)
    เหตุ: Qt บน Windows แก้ขนาดหน้าต่างระดับบนทุกครั้งที่เปลี่ยนขนาด (WM_WINDOWPOSCHANGING → QWidgetWindow::closestAcceptableGeometry →
    QLayout::closestAcceptableSize) ให้สูงไม่ต่ำกว่า layout.minimumHeightForWidth(กว้าง) — QBoxLayout นับรายการที่มี heightForWidth เต็มความสูง ⇒
    rc9 หน้าต่างหดต่ำกว่าเนื้อหาไม่ได้ (จอเตี้ย: ปุ่มตกใต้แถบงาน ไม่มีแถบเลื่อน) และตอนเปิด Qt วางจากขนาดแรกแล้วขยายเป็นเนื้อหาเต็มโดยยึด
    ขอบล่าง ⇒ ขอบบนหลุดจอ 152–237 px · offscreen ไม่มีกลไกนี้ (เทสจำลองด้วย QLayout.closestAcceptableSize) · รายการอื่นในหน้าต่าง
    (คำอธิบายท้ายกล่อง · ปุ่ม) ยังนับเต็มตามเดิม ⇒ หดหน้าต่างเองแล้วข้อความนอกกรอบเลื่อนไม่ถูกตัด"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._fit = None            # _FitScroll ในหน้าต่าง (ผู้สร้างตั้งหลัง addWidget)

    def minimumHeightForWidth(self, w):
        m = super().minimumHeightForWidth(w)
        sa = self._fit
        if sa is None or m < 0:
            return m
        try:
            if sa.isHidden():
                return m
            l, _t, r, _b = self.getContentsMargins()
            iw = max(1, int(w) - l - r)
            # ★ rc11 (ผลตรวจ Windows rc10 ⚪9 · agent A ⚪2) พื้นที่ไม่พอ ⇒ QBoxLayout (qGeomCalc "ตัดจากตัวใหญ่สุดก่อน") ลดทุกรายการที่สูงกว่า
            #   ระดับหนึ่งลงเท่ากัน ⇒ กรอบเลื่อนถูกลดเหลือเท่าคำอธิบายท้ายกล่อง แล้วคำอธิบายถูกตัดไปด้วย (rc10: ต้องการ 137 ได้ 130) ⇒ ขั้นต่ำของ
            #   กรอบเลื่อน = ไม่ต่ำกว่ารายการอื่นที่สูงที่สุด (ระดับที่ตัดไม่ถึงรายการอื่น)
            top = 0
            for i in range(self.count()):
                it = self.itemAt(i)
                if it is None or it.widget() is sa or it.isEmpty():
                    continue
                top = max(top, it.heightForWidth(iw) if it.hasHeightForWidth() else it.minimumSize().height())
            ex = sa.heightForWidth(iw) - max(sa.minimumSizeHint().height(), top)
            return max(self.minimumSize().height(), m - max(0, ex))
        except RuntimeError:
            return m


class _WheelGuard(QtCore.QObject):
    """★ rc10 (ผลตรวจ Windows rc9 ⚪1 · agent B) คอมโบ/ช่องตัวเลขในกรอบเลื่อนรับล้อเมาส์เฉพาะตอนมีโฟกัส (คลิกเลือกอยู่) — ล้อที่ผ่านใต้เมาส์
    ระหว่างเลื่อนฟอร์มส่งต่อให้กรอบเลื่อน (ev.ignore + กินไว้ ⇒ Qt ส่งต่อให้วิดเจ็ตแม่) · เดิม Type L2-TS → L2-RO / ชนิดเอกสารเปลี่ยนเงียบ ๆ ·
    แบบ _MainWheelGuard ของแผงหลัก (2.3.9) · ผู้ใช้ _guard_wheel ตั้ง StrongFocus ด้วย (WheelFocus = ล้อให้โฟกัสก่อนถึงตัวกรอง)
    ★ rc11 (ผลตรวจ Windows rc10 ⚪1 · agent A ⚪3 · agent B ⚪4) "มีโฟกัส" ไม่พอ: ① คอมโบชนิดเอกสารได้โฟกัสเองตอนเปิดกล่อง (ช่องแรกของลำดับ Tab ·
    ผู้ใช้ไม่ได้คลิก) ⇒ rc10 หมุนล้อเหนือช่องนี้แล้วโฉนดที่ดิน → โฉนดตราจอง ⇒ ยอมล้อเฉพาะช่องที่ผู้ใช้เลือกเอง (ได้โฟกัสด้วยคลิก/Tab/คีย์ลัด —
    จำเหตุจาก FocusIn · ได้โฟกัสเพราะหน้าต่างเปิด/กลับมาเป็นหน้าต่างหลัก/รายการปิด = คงสถานะเดิม · โปรแกรมตั้งโฟกัส = ไม่นับ) ·
    ② คอมโบพิมพ์ได้ (REMARK · ชื่อทางสาธารณะ · ผู้รับผิดชอบ) ที่คลิกเพื่อพิมพ์แล้วหมุนล้อเลื่อนฟอร์ม ⇒ rc10 ข้อความที่พิมพ์ถูกแทนด้วยรายการ
    ⇒ ล้อไม่เปลี่ยนค่าคอมโบพิมพ์ได้เลย (ส่งให้กรอบเลื่อน · รายการที่กางอยู่เลื่อนเองตามปกติ — ล้อในรายการเป็นของ popup ไม่ผ่านตัวกรองนี้)"""

    _PROP = "_mlep_wheel_ok"
    _USER = (QtCore.Qt.MouseFocusReason, QtCore.Qt.TabFocusReason, QtCore.Qt.BacktabFocusReason, QtCore.Qt.ShortcutFocusReason)
    _KEEP = (QtCore.Qt.ActiveWindowFocusReason, QtCore.Qt.PopupFocusReason)

    def eventFilter(self, obj, ev):
        try:
            t = ev.type()
            if t in (QtCore.QEvent.FocusIn, QtCore.QEvent.FocusOut):
                # ช่องตัวเลข: โฟกัสอยู่ที่ช่องพิมพ์ภายใน (focus proxy) ⇒ จำไว้ที่ตัวช่องตัวเลข (ตัวที่รับล้อ)
                tgt = obj.parent() if (isinstance(obj, QtWidgets.QLineEdit)
                                       and isinstance(obj.parent(), QtWidgets.QAbstractSpinBox)) else obj
                r = ev.reason()
                if t == QtCore.QEvent.FocusIn and r in self._USER:
                    tgt.setProperty(self._PROP, True)
                elif r not in self._KEEP:
                    tgt.setProperty(self._PROP, False)
            elif t == QtCore.QEvent.Wheel:
                if isinstance(obj, QtWidgets.QLineEdit):
                    return False            # ช่องพิมพ์ภายในช่องตัวเลขไม่ใช้ล้อ ⇒ Qt ส่งต่อให้ช่องตัวเลข (ตัดสินที่นั่น)
                if isinstance(obj, QtWidgets.QComboBox) and obj.isEditable():
                    try:
                        if obj.view() is not None and obj.view().isVisible():
                            return False
                    except RuntimeError:
                        pass
                    ev.ignore()
                    return True
                if not (obj.hasFocus() and bool(obj.property(self._PROP))):
                    ev.ignore()
                    return True
        except RuntimeError:
            pass
        return False


def _guard_wheel(root, owner):
    """ติด _WheelGuard ให้คอมโบ/ช่องตัวเลขทุกตัวใต้ root (ตัวกรองเป็นลูกของ owner — อายุเท่าหน้าต่าง) -> ตัวกรอง"""
    g = _WheelGuard(owner)
    for w in root.findChildren(QtWidgets.QAbstractSpinBox) + root.findChildren(QtWidgets.QComboBox):
        try:
            w.setFocusPolicy(QtCore.Qt.StrongFocus)
            w.installEventFilter(g)
            if isinstance(w, QtWidgets.QAbstractSpinBox):
                le = w.findChild(QtWidgets.QLineEdit)       # ★ rc11 FocusIn ของช่องตัวเลขมาที่ช่องพิมพ์ภายใน
                if le is not None:
                    le.installEventFilter(g)
        except Exception:
            pass
    return g
