# -*- coding: utf-8 -*-
"""ตัวช่วยฝั่ง Qt: ยกหน้าต่าง, เก็บกวาด QAction/QShortcut ที่ค้าง, แถบเตือนบันทึกครึ่งคู่, เครื่องมือคลิกจุด

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import Qgis, QgsMessageLog
from qgis.gui import QgsMapToolEmitPoint
from ..map_tools import _MlepKeys


def _lift_dlg(w):
    """ยกหน้าต่างขึ้นหน้าสุด + โฟกัส — ทนหน้าต่างที่ถูกลบไปแล้ว (★ 2.3.7 LC-11: ใช้กับตัวจับเวลาที่อาจยิงหลัง deleteLater)"""
    try:
        w.raise_()
        w.activateWindow()
    except RuntimeError:
        pass


def _whats_new_rows(entries):
    """แถว HTML ของหน้าต่าง What's New จาก [(เวอร์ชัน, [ข้อความ, ...]), ...]

    ★ 2.3.7 (review UX-26) — ข้อความ changelog เป็นข้อความล้วน ต้อง escape ก่อนใส่ HTML
      เดิมใส่ดิบ ⇒ '<อำเภอ>_V3.qgz' แสดงเป็น '_V3.qgz' · '(CT_<สาขา>)' เป็น '(CT_)' (Qt ถือเป็นแท็กแล้วทิ้ง)
      markup อยู่ในแม่แบบนี้เท่านั้น"""
    import html as _html
    rows = []
    for v, items in entries:
        rows.append(f"<b>v{_html.escape(str(v), quote=False)}</b>")
        rows += [f"&nbsp;&nbsp;• {_html.escape(str(it), quote=False)}" for it in items]
        rows.append("")
    return rows


# ==================== ★ 2.3.7 (audit LIFE-02/LIFE-04) ของที่ MLEP สร้างบนหน้าต่างหลักของ QGIS ====================
_OWN_PROP = "_mlep_owner"       # ป้าย (dynamic property) บน QAction/QShortcut ที่ MLEP สร้างบนหน้าต่างหลัก = token ของ instance
_MLEP_MENU = "&Multi-Layer Edit Pro"


def _qobj_dispose(o):
    """ทิ้ง QShortcut/QAction ของ MLEP ให้หมดจริง: ปิด · ถอดจาก QgsShortcutsManager (ตอนเปิด QGIS ตัวที่สร้างก่อน QGIS ลงทะเบียน
    คีย์ลัดจะถูกลงทะเบียนไปด้วย) · ตัด signal · ตัดจากหน้าต่างหลัก · ลบ · พังก็ไม่เป็นไร"""
    if o is None:
        return
    try:
        from qgis.gui import QgsGui
        _mgr = QgsGui.shortcutsManager()
    except Exception:
        _mgr = None
    try:
        if isinstance(o, QtWidgets.QShortcut):
            o.setEnabled(False)                 # ปิดก่อน — ระหว่างรอ deleteLater ไม่ชนกับตัวใหม่ (Qt ถือว่ากำกวม)
            sigs = (o.activated, o.activatedAmbiguously)
            _unreg = getattr(_mgr, "unregisterShortcut", None)
        else:
            sigs = (o.triggered,)
            _unreg = getattr(_mgr, "unregisterAction", None)
        if _unreg is not None:
            try:
                _unreg(o)
            except Exception:
                pass
        for sig in sigs:
            try:
                sig.disconnect()
            except Exception:
                pass
        o.setParent(None)
        o.deleteLater()
    except Exception:
        pass


def _mlep_debris_clear(iface, undo_keys=None, keep=None):
    """★ 2.3.7 (audit LIFE-04) — รุ่นใหม่ล้มกลาง initGui ⇒ QGIS ทิ้ง instance นั้นโดยไม่เรียก unload ⇒ ไอคอน/QShortcut ที่มันสร้าง
    ค้างบนหน้าต่างหลัก (Ctrl+Z ซ้อน 2 ตัว = Qt ไม่ยิงทั้งคู่ + TypeError ทุกครั้งที่กด · ไอคอน 2 อัน) และคีย์ Undo ของ QGIS ถูกยึดค้าง
    ⇒ ก่อนเปิดรุ่นเดิมกลับมา: เอาของที่ติดป้าย _mlep_owner ออกทั้งหมด (ยกเว้นของ instance ที่ยังเปิดอยู่ = keep) แล้วคืนคีย์ Undo
    undo_keys = คีย์ที่ Undo ของ QGIS ควรมี (จำจาก instance เดิมก่อนสั่งโหลดใหม่) · None = ไม่แตะ · คืนจำนวนชิ้นที่เก็บ"""
    n = 0
    try:
        mw = iface.mainWindow()
    except Exception:
        mw = None
    if mw is not None:
        for cls in (QtWidgets.QShortcut, QtWidgets.QAction):
            try:
                objs = mw.findChildren(cls)
            except Exception:
                objs = []
            for o in objs:
                try:
                    tok = o.property(_OWN_PROP)
                except Exception:
                    continue
                if not tok or (keep is not None and tok == keep):
                    continue
                if cls is QtWidgets.QAction:
                    try:
                        iface.removeToolBarIcon(o)
                    except Exception:
                        pass
                    try:
                        iface.removePluginMenu(_MLEP_MENU, o)
                    except Exception:
                        pass
                _qobj_dispose(o)
                n += 1
    if undo_keys is not None:
        try:
            ua = mw.findChild(QtWidgets.QAction, "mActionUndo") if mw is not None else None
            if ua is None:
                from qgis.gui import QgsGui
                ua = QgsGui.shortcutsManager().actionByName("mActionUndo")
            if ua is not None:
                cur = [q.toString() for q in ua.shortcuts() if not q.isEmpty()]
                if list(undo_keys) != cur:
                    ua.setShortcuts([QtGui.QKeySequence(x) for x in undo_keys])
        except Exception:
            pass
    return n


def _half_rb_text(nm, rec):
    """★ 2.3.7 (review DI-05 · b17 แยกออกมา) — ข้อความ "ทิ้งงานของอีกชั้นหลังชั้นหนึ่งลงฐานไปแล้ว" (ใช้ทั้ง instance และป้ายที่ค้างหลังโหลดใหม่)"""
    keys = rec.get("keys") or rec.get("rb_keys") or set()
    ks = sorted(keys)
    smp = ", ".join(ks[:10]) + (f" … (รวม {len(ks):,})" if len(ks) > 10 else "")
    return (f"ทิ้งงานของชั้น '{nm}' ไปแล้ว แต่ชั้น '{rec.get('saved')}' ลงฐานไปก่อนหน้านี้ — แปลงกับหมุดในฐานไม่ตรงกัน"
            + (f" ที่ UTM {smp}" if smp else "") + " · ต้องแก้ให้ตรงกันแล้วบันทึกใหม่")


_HALF_PROP = "_mlep_half_save"      # ★ b17 — ป้ายบนแถบ "⚠️ บันทึกไปชั้นเดียว" = id ของชั้นที่ยังค้าง


def _half_save_orphans_pop(bar, lid, keep=None):
    """★ 2.3.7 b17 (audit nit) — ป้าย "⚠️ บันทึกไปชั้นเดียว" ของชั้น lid ที่ instance ก่อนโหลดใหม่ทิ้งไว้บนแถบ (unload คงไว้ — LIFE-08)
    ⇒ เอาออก (instance ใหม่ไม่รู้จักมัน เดิมจึงค้างตลอดไป) · คืนบันทึก (rec) ที่ติดมากับป้าย ไว้ทำข้อความ "ทิ้งงาน" ต่อ"""
    recs = []
    try:
        items = list(bar.items())
    except Exception:
        return recs
    for x in items:
        try:
            if x is keep or x.property(_HALF_PROP) != lid or getattr(x, "_mlep_half_done", False):
                continue
            x._mlep_half_done = True
            r = getattr(x, "_mlep_half_rec", None)
            if r:
                recs.append(r)
            bar.popWidget(x)
        except Exception:
            continue
    return recs


def _half_save_orphan_watch(bar, item, lyr, rec):
    """★ 2.3.7 b17 (audit nit) — unload คงป้าย "⚠️ บันทึกไปชั้นเดียว" ไว้ (ยังเป็นความจริง) แต่ไม่มีใครเก็บ ⇒ ค้างตลอดไป
    ⇒ ผูกกับสัญญาณของ "อีกชั้น" ตรง ๆ โดยไม่อ้าง instance ที่ตายแล้ว: บันทึกชั้นนั้น ⇒ เอาป้ายออก · ทิ้งงานชั้นนั้น ⇒ เอาป้ายออก
    + แถบแดงแบบ _half_save_rolled_back · ทำครั้งเดียวแล้วตัดสัญญาณ · instance ใหม่จัดการไปก่อนแล้ว (_mlep_half_done) ⇒ ไม่ซ้ำ"""
    from qgis.PyQt import sip as _sip
    conns = []

    def _dead(o):
        try:
            return _sip.isdeleted(o)
        except Exception:
            return False                    # ไม่ใช่วัตถุของ sip (ตัวปลอมในเทส) = ยังอยู่

    def _done(rolled_back):
        while conns:
            _sig, _fn = conns.pop()
            try:
                _sig.disconnect(_fn)
            except Exception:
                pass
        if getattr(item, "_mlep_half_done", False):
            return
        item._mlep_half_done = True
        try:
            if not _dead(item):
                bar.popWidget(item)
        except Exception:
            pass
        if rolled_back and rec:
            try:
                msg = _half_rb_text(lyr.name(), rec)
                QgsMessageLog.logMessage("บันทึกไม่ครบคู่: " + msg, "MLEP", Qgis.Critical)
                if not _dead(bar):
                    bar.pushMessage("⚠️ แปลงกับหมุดไม่ตรงกันในฐาน", msg, level=2, duration=0)
            except Exception:
                pass

    def _on_commit(*_a):
        _done(False)

    def _on_rollback(*_a):
        _done(True)
    for _sig, _fn in ((lyr.afterCommitChanges, _on_commit), (lyr.afterRollBack, _on_rollback)):
        try:
            _sig.connect(_fn)
            conns.append((_sig, _fn))
        except Exception:
            pass
    return len(conns)




class _EmitClickTool(_MlepKeys, QgsMapToolEmitPoint):
    """★ 2.3.7 (review UX-02 / LC-04) — เครื่องมือคลิกจุดของ Move/Rotate/Scale/Transform และ Align ขั้น ②

    เดิมเป็น QgsMapToolEmitPoint เปล่า ๆ = ไม่มีคีย์ลัดเลย ทั้งที่ข้อความแนะนำของ Align บอก "Esc = ยกเลิก"
    และ Backspace/Delete ไม่ถูก "กิน" ⇒ QGIS เอาไปสั่ง "ลบฟีเจอร์ที่เลือกไว้" ของชั้นที่แก้อยู่ (ไม่ถามถ้าอยู่ในจอ)
    ระหว่างที่กลุ่มแปลง+หมุดถูกเลือกค้างไว้พอดี
    Esc → on_key("esc") · Backspace/Delete → on_key("back") · คีย์ที่ใช้แล้วต้อง ignore() = "เครื่องมือกินคีย์แล้ว"
    (กติกาคีย์ของ QGIS กลับด้านโดยตั้งใจ — ดู DrawLineTool._กินคีย์ ใน map_tools)
    ★ 2.3.7 (audit F1) — _MlepKeys: ระหว่างกดปุ่มเมาส์ค้าง แคนวาสไม่ส่งคีย์ให้เครื่องมือ ⇒ ตัวกรองบนแคนวาสส่ง Backspace/Delete
      มาที่ keyPressEvent นี้แทน (แคนวาสไม่เห็นคีย์ ⇒ QGIS ไม่ลบฟีเจอร์ที่เลือก)"""

    def __init__(self, canvas, on_key):
        super().__init__(canvas)
        self._on_key = on_key
        # ป้าย "เครื่องมือของ MLEP" (แบบเดียวกับที่ LC-03c ใช้ทุกจุดสร้างเครื่องมือ) — ใส่ที่ตัวสร้างแทนจุดสร้าง
        self.setProperty("_mlep_tool", True)

    def keyPressEvent(self, e):
        k = e.key()
        if k == QtCore.Qt.Key_Escape:
            what = "esc"
        elif k in (QtCore.Qt.Key_Backspace, QtCore.Qt.Key_Delete):
            what = "back"
        else:
            return
        try:
            e.ignore()
        except Exception:
            pass
        try:
            self._on_key(what)
        except Exception:
            import traceback
            QgsMessageLog.logMessage("_EmitClickTool: " + traceback.format_exc(), "MLEP", Qgis.Warning)


class _EscWatch(QtCore.QObject):
    """★ 2.4.0 (review UX-09) — ตัวดัก Esc บนแผนที่ (ติดตั้งเฉพาะตอนมีเครื่องหมาย "จุดที่ต้องแก้" ของด่านจับคู่)
    Esc ⇒ เรียก on_esc (เก็บเครื่องหมาย) · ไม่กินคีย์ (เครื่องมือที่ใช้อยู่ยังได้ Esc ตามเดิม)"""

    def __init__(self, on_esc):
        super().__init__()
        self._on_esc = on_esc

    def eventFilter(self, obj, ev):
        try:
            if ev.type() == QtCore.QEvent.KeyPress and ev.key() == QtCore.Qt.Key_Escape:
                self._on_esc()
        except Exception:
            pass
        return False
