# -*- coding: utf-8 -*-
"""บันทึกการเปลี่ยน Type ของแปลงลงตาราง log

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.core import Qgis, QgsExpression, QgsMessageLog, QgsProject
from ..core.util import _log_sql_val, _scrub, _txt


class TypeLogMixin:
    """บันทึกการเปลี่ยน Type ของแปลงลงตาราง log"""

    def _drop_type_log(self, lid):
        """ทิ้งคิวล็อกเปลี่ยน Type ของเลเยอร์นี้ (ใช้ตอนย้อนการแก้)
        ★ rc2 (audit A3 · ผู้ตรวจทานพบเพิ่ม) — ไม่ทิ้งแถวที่ "ลงฐานแล้ว" (`saved` · INSERT Move_Log รอบก่อนล้ม รอเขียนซ้ำ)
          การย้อน/ทิ้งงานรอบนี้ไม่ได้ย้อนสิ่งที่ลงฐานไปแล้ว ⇒ เดิมแถวเหล่านี้หายถาวร (การเปลี่ยน Type ที่ลงฐานแล้วไม่มีร่องรอย)"""
        n = len(self._pending_type_log)
        _gone = [e for e in self._pending_type_log if e['lid'] == lid and not e.get('saved')]
        self._pending_type_log = [e for e in self._pending_type_log if e['lid'] != lid or e.get('saved')]
        if n != len(self._pending_type_log) and any(e.get('layer') != 'POINT' for e in _gone):   # ★ rc2 (A3-10)
            # ค่าที่แคชไว้อาจมาจาก buffer ที่เพิ่งถูกย้อน -> ให้อ่านใหม่จากฐาน
            self._locked_cache = None

    def _ux_mark(self, lyr):
        """★ 2.3.7 (audit F8) — ตัวตนของคำสั่งแก้ไขล่าสุดบน undo stack ของชั้น: (index หลังคำสั่ง, pointer, ข้อความ)
        ผูกแถวคิว Move_Log กับคำสั่งของมัน (เทียบ pointer คู่ข้อความแบบด่าน (3) ของ ↺ — LC-02) · อ่านไม่ได้ = None (เขียนตามเดิม)"""
        try:
            st = lyr.undoStack()
            i = st.index()
            if i <= 0:
                return None
            c = st.command(i - 1)
            if c is None:
                return None
            from qgis.PyQt import sip as _sip
            return (i, _sip.unwrapinstance(c), c.text())
        except Exception:
            return None

    def _ux_live(self, lyr, ux):
        """★ 2.3.7 (audit F8) — คำสั่งที่ผูกกับแถวคิว (ux จาก _ux_mark) ยังมีผลอยู่บน undo stack ไหม
        index ต่ำกว่า = ถูกย้อนแล้ว (Edit ▸ Undo / แผง Undo/Redo) · ตำแหน่งนั้นเป็นคำสั่งอื่น = ย้อนแล้วแก้ใหม่ทับ
        · Redo กลับมา = คำสั่งตัวเดิม ⇒ ยังมีผล · ux ว่าง (ลงฐานแล้ว/จดไม่ได้) หรืออ่าน stack ไม่ได้ ⇒ True (เขียนตามเดิม)"""
        if not ux:
            return True
        try:
            i, ptr, txt = ux
            st = lyr.undoStack()
            if st is None:
                return True
            if st.index() < i:
                return False
            c = st.command(i - 1)
            if c is None:
                return False
            from qgis.PyQt import sip as _sip
            return _sip.unwrapinstance(c) == ptr and c.text() == txt
        except Exception:
            return True

    @staticmethod
    def _geom_sig(g):
        """★ 2.3.7 b17 (audit R2-D2) — ลายเซ็นของรูป (md5 ของ WKB) ไว้เทียบ "รูปเดียวกันเป๊ะ" (Undo ของ QGIS คืนรูปเดิมทุกไบต์)
        · ว่าง/อ่านไม่ได้ = None"""
        try:
            if g is None or g.isNull() or g.isEmpty():
                return None
            import hashlib
            return hashlib.md5(bytes(g.asWkb())).hexdigest()
        except Exception:
            return None

    def _fx_now(self, lyr, e):
        """★ 2.3.7 b17 (audit R2-D2) — ค่าปัจจุบันของสิ่งที่แถวคิวนี้เปลี่ยน (ก่อนบันทึก = ค่าใน buffer · หลังบันทึก = ค่าในฐาน)
        'attr' ⇒ tuple ของค่าคอลัมน์ (_txt) · 'geom' ⇒ ลายเซ็นรูป · แปลงหาไม่เจอ/อ่านไม่ได้ ⇒ None (= ไม่ตัดสิน เขียนตามเดิม)"""
        fx = e.get('fx')
        try:
            f = lyr.getFeature(int(e.get('gid')))
            if f is None or not f.isValid():
                return None
            if fx[0] == 'geom':
                return self._geom_sig(f.geometry())
            out = []
            for nm in fx[1]:
                i = f.fields().indexOf(nm)
                if i < 0:
                    return None
                out.append(_txt(f.attribute(i)))
            return tuple(out)
        except Exception:
            return None

    def _fx_gone(self, lyr, e, later):
        """★ 2.3.7 b17 (audit R2-D2) — ผลของแถวคิวนี้ "หายไปแล้ว" แน่ ๆ ไหม — ด่านที่สองต่อจาก _ux_live
        (ตัวตนคำสั่ง = index + address + ข้อความ หลอกได้เมื่อคำสั่งที่ถูกย้อนถูกทิ้งแล้ว address ถูกใช้ซ้ำกับคำสั่งข้อความเดียวกัน)
        fx = (ชนิด, คอลัมน์, ค่าก่อน, ค่าหลัง) ที่จดตอนเข้าคิว · later = แถวที่ผ่านด่านแล้วซึ่งอยู่หลังแถวนี้ (เรียงเก่า → ใหม่)
          ① แถวถัดไปของแปลงเดียวกัน (ชนิด/คอลัมน์เดียวกัน) เริ่มจากค่า "ก่อน" ของแถวนี้ ⇒ แถวนี้ถูกย้อนไปก่อนแถวนั้นเกิด = หาย
          ② แถวถัดไปเริ่มจากค่า "หลัง" ของแถวนี้ ⇒ แก้ซ้ำต่อกันเป็นลำดับ = เกิดจริง (เขียนทั้งคู่ — ร่องรอยครบ)
          ③ ไม่มีแถวต่อ ⇒ ค่าปัจจุบัน = ค่า "ก่อน" ของแถวนี้ ⇒ ถูกย้อนแล้ว = หาย
        ค่าปัจจุบันเป็นค่าอื่น (แก้ทับภายหลัง เช่น 🍩 แล้ว Move Node ต่อ) = ไม่หาย — ไม่ตัดสินจาก "ค่าหลังต้องตรงเป๊ะ" เพราะงานที่แก้ต่อ
        ก่อนบันทึกจะทำให้แถวของงานที่เกิดจริงหาย · ไม่มี fx (แถวเก่า/ลงฐานแล้ว) หรืออ่านไม่ได้ ⇒ ไม่หาย (เขียนตามเดิม)"""
        fx = e.get('fx')
        if not fx:
            return False
        try:
            kind, names, before, after = fx
        except Exception:
            return False
        if before == after:
            return False
        for x in later:
            xf = x.get('fx')
            if not xf or x.get('gid') != e.get('gid') or xf[0] != kind or xf[1] != names:
                continue
            if xf[2] == before:
                return True                     # ①
            if xf[2] == after:
                return False                    # ②
            break
        now = self._fx_now(lyr, e)
        return now is not None and now == before     # ③

    def _type_log_judge(self, lyr, rows):
        """★ 2.3.7 b17 (audit R2-D2) — แถวคิวของชั้นเดียว (เรียงตามคิว) ⇒ (เก็บ, ทิ้ง)
        ทิ้ง = คำสั่งของมันถูกย้อนบน undo stack (_ux_live) หรือผลของมันหายไปแล้ว (_fx_gone) · ไล่จากใหม่ไปเก่า:
        แถวที่ใหม่กว่าและผ่านด่านแล้วเท่านั้นที่ใช้ตัดสินแถวที่เก่ากว่า (_fx_gone ข้อ ①②)"""
        keep, drop = [], []
        for e in reversed(list(rows)):
            if not self._ux_live(lyr, e.get('ux')) or self._fx_gone(lyr, e, keep):
                drop.append(e)
            else:
                keep.insert(0, e)
        return keep, drop

    def _type_log_prune(self, lid, dry=False):
        """★ 2.3.7 (audit F8) — ทิ้งแถวคิว Move_Log ('retyped' · 'rekeyed' · 'donut') ของชั้นนี้ที่การแก้ของมันถูกย้อนด้วย Undo ของ QGIS เอง
        เดิมคิวถูกทิ้งเฉพาะ ↺ ของปลั๊กอินกับ rollback ⇒ ย้อนด้วย Edit ▸ Undo แล้วบันทึก = เขียนแถวของสิ่งที่ไม่ได้เกิดขึ้น (ผู้ตรวจ p10)
        เรียกตอน beforeCommitChanges — undo stack ยังอยู่ (QGIS ล้าง stack ก่อนยิง afterCommitChanges ที่ _flush_type_log ทำงาน)
        ⇒ ตรวจ "ก่อนเขียน" ได้ตรงที่สุด และ Redo กลับมาก่อนบันทึก = แถวยังอยู่ · คืนจำนวนที่ทิ้ง"""
        lyr = QgsProject.instance().mapLayer(lid)
        if lyr is None:
            return 0
        q = list(self._pending_type_log)
        # ★ 2.3.7 b17 (audit R2-D2) — นอกจากคำสั่งถูกย้อน (_ux_live) ตรวจด้วยว่าผลของแถวยังอยู่ (_fx_gone) — ดู _type_log_judge
        #   dry=True = นับอย่างเดียว ไม่ทิ้งแถว (_reload_blocker: ยังไม่บันทึก · Redo กลับมาได้ แถวต้องยังอยู่ให้เขียนตอนบันทึก)
        _gone = self._type_log_judge(lyr, [e for e in q if e.get('lid') == lid])[1]
        keep = [e for e in q if not any(e is g for g in _gone)]
        n = len(q) - len(keep)
        if n and not dry:
            self._pending_type_log = keep
            if any(g.get('layer') != 'POINT' for g in _gone):     # ★ rc2 (audit A3-10) Type หมุดไม่อยู่ในตารางล็อก
                self._locked_cache = None    # แบบ _drop_type_log — ค่า Type ใน buffer ถูกย้อน ⇒ อ่านตารางล็อกใหม่
            try:
                QgsMessageLog.logMessage(
                    "Move_Log: ไม่เขียน %d รายการ — การแก้ของมันถูกย้อนด้วย Undo ของ QGIS ก่อนบันทึก" % n, "MLEP", Qgis.Info)
            except Exception:
                pass
        return n

    @staticmethod
    def _tl_bbox(f):
        """★ rc2 S_close (review R3-01) — กรอบรูปของฟีเจอร์ (ไว้ตรวจการจับคู่ fid ชั่วคราว→จริง) · ไม่มีรูป = None"""
        try:
            g = f.geometry()
            if g is None or g.isNull() or g.isEmpty():
                return None
            r = g.boundingBox()
            return (r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum())
        except Exception:
            return None

    def _tl_match(self, olds, feats):
        """★ rc2 S_close (review R3-01) — จับคู่ fid ชั่วคราว→fid จริงของ committedFeaturesAdded
        olds = [(fid ชั่วคราว, กรอบ)] เรียงแบบที่ QGIS ส่ง (คีย์มากไปน้อย) · จับตามลำดับก่อน แล้วตรวจกรอบรูปทุกคู่
        คู่ไหนกรอบไม่ตรง ⇒ จับด้วยกรอบที่ไม่ซ้ำแทน · จับไม่ได้ ⇒ ไม่ใส่ในผล (แถวนั้นเขียน gid NULL แทน gid ของฟีเจอร์อื่น)"""
        def same(a, b):
            if a is None or b is None:
                return a is None and b is None
            return all(abs(x - y) <= 1e-6 * max(1.0, abs(x), abs(y)) for x, y in zip(a, b))
        fb = [(f.id(), self._tl_bbox(f)) for f in feats]
        if all(same(o[1], n[1]) for o, n in zip(olds, fb)):
            return {o[0]: n[0] for o, n in zip(olds, fb)}
        m = {}
        for k, ob in olds:
            if ob is None:
                continue
            hit = [n for n, nb in fb if same(ob, nb)]
            if len(hit) == 1 and len([1 for _k, b in olds if same(b, ob)]) == 1:
                m[k] = hit[0]
        return m

    def _type_log_unwritable(self, lid, lyr, why):
        """★ 2.3.7 b19 (doc-verify E5) — ชั้นที่ "ไม่มีวันเขียน Move_Log ได้" (ไม่ใช่ PostGIS · ไม่ใช่ตาราง <สาขา>_POLYGON)
        ⇒ ทิ้งแถวคิวของชั้นนี้ + Log (Info) · เดิม _flush_type_log คืนโดยไม่เอาแถวออก ⇒ คิวค้างทั้งเซสชัน ⇒ _reload_blocker บอก
        "ยังมีงานที่ยังไม่ได้บันทึก" ตลอด (อัปเดตแล้วไม่โหลดใหม่ให้) · PostGIS ที่เขียนล้มกลางทางยังเก็บไว้ลองใหม่ตามเดิม"""
        n = len([e for e in self._pending_type_log if e.get('lid') == lid])
        if not n:
            return
        self._pending_type_log = [e for e in self._pending_type_log if e.get('lid') != lid]
        try:
            QgsMessageLog.logMessage("Move_Log: ไม่เขียน %d รายการของชั้น '%s' — %s (ไม่มีตาราง Move_Log ให้เขียน)"
                                     % (n, lyr.name(), why), "MLEP", Qgis.Info)
        except Exception:
            pass

    def _flush_type_log(self, lid):
        """เขียนล็อกการเปลี่ยน Type ลง <D>_Move_Log หลัง commit สำเร็จ

        ★ 31 ส.ค. 69 — trigger ในฐานข้อมูลไม่จับการเปลี่ยน Type (log_move ดู geom,
          trg_audit_polygon ดู SCORE/geom) การเปลี่ยนชั้นของแปลงอ้างอิงจึงไม่มีร่องรอย
          ทั้งที่เป็นเหตุผลตั้งต้นของปุ่มนี้ -> ปลั๊กอินเขียนเองด้วย action='retyped'
        เขียนหลัง commit เท่านั้น ถ้าผู้ใช้กด Reset/Undo คิวถูกทิ้งที่ on_rollback"""
        queue = [e for e in self._pending_type_log if e['lid'] == lid]
        if not queue:
            return
        # ★ 31 ส.ค. 69 — เดิมดึงคิวออกทั้งก้อนก่อนเขียน ถ้าล้มกลางทางรายการที่เหลือหายถาวร
        #   ตอนนี้เอาออกทีละรายการ "หลังเขียนสำเร็จ" เท่านั้น ที่เหลือค้างไว้ให้รอบหน้าลองใหม่
        lyr = QgsProject.instance().mapLayer(lid)
        if lyr is None:
            return
        # ★ 2.3.7 b17 (audit R2-D2) — ก่อนเขียนตรวจซ้ำว่าผลของแถวยังอยู่ (ตาข่ายหลัง _type_log_prune ตอน beforeCommitChanges)
        #   แถวที่ค้างจากการบันทึกรอบก่อน (fx ถูกล้างแล้ว = ลงฐานไปแล้ว) เขียนตามเดิม
        try:
            queue, _gone = self._type_log_judge(lyr, queue)
        except Exception:
            _gone = []
        if _gone:
            self._pending_type_log = [x for x in self._pending_type_log if not any(x is g for g in _gone)]
            try:
                QgsMessageLog.logMessage("Move_Log: ไม่เขียน %d รายการ — ผลของมันไม่อยู่แล้วตอนบันทึก" % len(_gone),
                                         "MLEP", Qgis.Info)
            except Exception:
                pass
        if not queue:
            return
        try:
            dp = lyr.dataProvider()
            if dp is None or dp.name() != "postgres":
                self._type_log_unwritable(lid, lyr, "ชั้นนี้ไม่ใช่ PostGIS")        # ★ 2.3.7 b19 (doc-verify E5) เดิมค้างตลอด
                return
            from qgis.core import QgsDataSourceUri, QgsProviderRegistry
            uri = QgsDataSourceUri(dp.dataSourceUri())
            tbl = uri.table()
            # ★ rc1 S5 (review R1-01) — ชั้นหมุด <สาขา>_POINT เขียนได้ด้วย (🏷 ปรับ Type หมุดให้ตรงแปลง · layer 'POINT' แบบ trigger)
            _sfx = next((x for x in ("_POLYGON", "_POINT") if tbl.upper().endswith(x)), None)
            if _sfx is None:
                self._type_log_unwritable(lid, lyr, f"ตาราง '{tbl}' ไม่ใช่ <สาขา>_POLYGON / <สาขา>_POINT")   # ★ b19 E5
                return
            log_tbl = f'"{uri.schema() or "public"}"."{tbl[:-len(_sfx)]}_Move_Log"'
            _lay = _sfx[1:]
            md = QgsProviderRegistry.instance().providerMetadata("postgres")
            conn = md.createConnection(uri.connectionInfo(True), {})
            done = 0
            for e in queue:
                # ★ 2.3.7 — คิวเดียวกันใช้กับ 📝 แก้ไขข้อมูลรูปแปลง (action 'rekeyed' + op ของตัวเอง)
                op = e.get('op') or (f"Type {e['old'] or '(ว่าง)'} -> {e['new']}"
                                     f" · หมุด {e['n_mk']} จุด · MLEP {self.version}")
                _bnd = _lay == "POINT" and bool(e.get('bnd'))
                conn.executeSql(
                    f"INSERT INTO {log_tbl}(edited_by,layer,gid,\"UTM\",\"Type\",action,op"
                    + (",\"BND_NAME\"" if _bnd else "") + ") "
                    # ★ session_user ให้ตรงกับ trigger ทุกตัว (log_move/log_delete ใช้ session_user)
                    #   ถ้าใช้ current_user แล้วมีการ SET ROLE ล็อกจะบันทึกคนละชื่อกับแถวอื่น
                    # ★ 2.4.0 (review DI-08-leftover) — UTM/Type ผ่าน _log_sql_val: ว่าง/NULL = SQL NULL (เดิม str() ได้ '' หรือ 'None'
                    #   เช่น 🍩 ของแปลงที่ UTM ว่างเขียน '' ลงล็อก) · คีย์ตัด .0 แบบ _norm_utm · ตัด \x00 ทุกช่อง (libpq ตัดคำสั่งที่ NUL)
                    # ★ rc2 (audit A3-04) — gid ติดลบ (fid ชั่วคราว · แปลงเป็น fid จริงไม่ได้) ⇒ NULL (แถวยังมี UTM/ชื่อหมุดให้ตามรอย)
                    f"VALUES (session_user,'{_lay}',{int(e['gid']) if int(e['gid']) >= 0 else 'NULL'},"
                    f"{_log_sql_val(e.get('utm'), utm=True)},"
                    f"{_log_sql_val(e.get('new'))},"
                    f"{QgsExpression.quotedValue((e.get('action') or 'retyped').replace(chr(0), ''))},"
                    f"{QgsExpression.quotedValue(str(op).replace(chr(0), ''))}"
                    + (f",{_log_sql_val(e.get('bnd'))}" if _bnd else "") + ")")
                # เขียนแถวนี้ผ่านแล้วค่อยเอาออกจากคิว
                self._pending_type_log = [x for x in self._pending_type_log if x is not e]
                done += 1
        except Exception as ex:
            # เขียนล็อกไม่ได้ = ไม่ควรทำให้การบันทึกที่สำเร็จไปแล้วดูเหมือนล้มเหลว
            # แต่ต้องบอกผู้ใช้ เพราะการเปลี่ยนชั้นแปลงอ้างอิงต้องตามรอยได้
            try:
                _left = len([x for x in self._pending_type_log if x['lid'] == lid])
                # ★ 2.3.7 (review SE-03) — ข้อความ error ของคอนเนกชันอาจมีรหัสผ่าน ⇒ แถบแสดงประโยคกลาง · รายละเอียด (ปิดรหัสแล้ว) ลง Log
                QgsMessageLog.logMessage("_flush_type_log: " + _scrub(ex), "MLEP", Qgis.Warning)
                self.iface.messageBar().pushMessage(
                    "Move_Log",
                    "บันทึกข้อมูลสำเร็จ แต่เขียนล็อกลง Move_Log ไม่ได้ (รายละเอียดใน Log Messages แท็บ MLEP) "
                    f"— ค้างอยู่ {_left} รายการ จะลองใหม่ตอนบันทึกครั้งถัดไป "
                    "· ถ้ายังไม่ได้ให้แจ้งผู้ดูแลฐานข้อมูล", level=1, duration=10)
            except Exception:
                pass
