# -*- coding: utf-8 -*-
"""แกนของตัวอัปเดต (ไม่ผูกกับหน้าจอ): ตรวจซิป ติดตั้ง ย้อนรุ่น และ path สำรอง

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import io
import os
import requests
import time
import zipfile
from qgis.core import Qgis
from ..core.util import _meta_value, _net_err_text, _parse_version


# ที่อยู่ไฟล์อัปเดตบน GitHub — ใช้ร่วมกันทั้งปุ่ม 🚀 Check Update และการเช็คอัตโนมัติตอนเปิด
UPDATE_V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
UPDATE_Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"


# ==================== ★ 2.3.7 (review ER-02) — ตัวติดตั้งอัปเดต ====================
#   เดิม: ตรวจแค่ testzip + บรรทัด version= + มี main.py แล้วสลับโฟลเดอร์ + ลบสำเนาเดิมทันที + โหลดใหม่เลย
#   ⇒ ซิปที่ขาด map_tools.py / มีไวยากรณ์ผิด / ต้องใช้ QGIS ใหม่กว่า ผ่านทุกด่าน แล้วทุกเครื่องที่อัปเดตไม่มี MLEP ใช้
#     (ต้องลงใหม่เองทีละเครื่อง ~105 เครื่อง) และรุ่นแก้ถัดไปก็ติดตั้งตัวเองไม่ได้ เพราะตัวอัปเดตอยู่ในแพ็กเกจที่เสีย
#   ⇒ ตรวจครบ "ก่อน" ย้ายโฟลเดอร์ใด ๆ · เก็บรุ่นเดิมไว้ที่ <โปรไฟล์>/python/mlep_backup/<ชื่อ>_prev (คืนได้ถ้ารุ่นใหม่โหลดไม่ขึ้น)
#   🔑 โค้ดชุดนี้ทำงานจาก "รุ่นที่ติดตั้งอยู่" ⇒ คุ้มครองการอัปเดตจาก 2.3.7 ขึ้นไปเท่านั้น (2.3.6 -> 2.3.7 ใช้ตัวของ 2.3.6)
#      รูปแบบซิป/metadata ต้องคงเดิม ให้ตัวอัปเดตรุ่นเก่ายังติดตั้งรุ่นใหม่ได้
#   🔑 ทำงานใน worker thread ของ _run_net — ห้ามแตะ widget ในนี้
_UPD_PREV = ".mlep_prev"        # (แบบเดิม) สำเนารุ่นก่อนหน้าใน plugins/ — ★ LIFE-05 เลิกสร้างแล้ว: อ่านตอนคืนรุ่นเดิม/ย้ายออกเท่านั้น
_UPD_FAILED = ".mlep_failed"    # (แบบเดิม) รุ่นใหม่ที่โหลดไม่ขึ้น ใน plugins/ — ★ LIFE-05 เลิกสร้างแล้ว
# ★ 2.3.7 (audit LIFE-05) — ที่เก็บสำเนาย้ายออกนอก plugins/ ⇒ <โปรไฟล์>/python/mlep_backup/<ชื่อ>_prev | <ชื่อ>_failed
#   จุดนำหน้าซ่อนได้แค่บน Linux/glob ของ Python · ตัวจัดการปลั๊กอินของ QGIS ไล่โฟลเดอร์ด้วย QDir (AllDirs ไม่รวม Hidden)
#   ⇒ บน Windows (ชื่อจุดไม่ได้ถือว่าซ่อน) เห็น .mlep_prev/.mlep_failed เป็นปลั๊กอิน "Multi-Layer Edit Pro" ซ้ำ/เสีย
#   ⚠️ ห้ามตั้งชื่อโฟลเดอร์สำเนาเป็นชื่อแพ็กเกจตรง ๆ ใต้ python/ (python/ อยู่ใน sys.path ⇒ บังปลั๊กอินจริงตอน import ได้)
_UPD_BACKUP = "mlep_backup"


class _UpdateInstallError(RuntimeError):
    """ติดตั้งอัปเดตไม่สำเร็จ (ซิปไม่ผ่านด่าน / ย้ายโฟลเดอร์ไม่ได้) — แยกจาก "ดาวน์โหลดไม่สำเร็จ"
    intact=True = ยังไม่ได้แตะโฟลเดอร์ปลั๊กอิน (รุ่นเดิมใช้ต่อได้ตามปกติ)
    already=True = ★ 2.3.7 (audit LIFE-03) ไม่ใช่ความล้มเหลว: บนเครื่องมีรุ่นที่ติดตั้งรอไว้แล้ว (ยังไม่ได้เปิดใช้) ⇒ บอกให้ปิด-เปิด QGIS"""

    def __init__(self, msg, intact=True, already=False):
        super().__init__(msg)
        self.intact = intact
        self.already = already


def _rmtree_quiet(path):
    """ลบโฟลเดอร์แบบไม่โยน error · symlink = ลบแค่ตัวลิงก์ (ห้ามตามเข้าไปลบของจริง)
    ★ 2.3.7 b17 (audit nit) — Windows ลบไฟล์/โฟลเดอร์ที่ติดบิตอ่านอย่างเดียวไม่ได้ (PermissionError) ⇒ เดิม ignore_errors
    ข้ามเงียบ ๆ แล้วโฟลเดอร์ค้าง · ตอนนี้ปลดบิตแล้วลองใหม่ 1 ครั้งต่อรายการ (ยังไม่โยน error เหมือนเดิม)"""
    import shutil
    import stat
    import sys

    def _ro(func, p, _exc):
        try:
            os.chmod(p, stat.S_IWRITE | stat.S_IREAD)
            func(p)
        except Exception:
            pass
    try:
        if os.path.islink(path):
            os.unlink(path)
        elif os.path.isdir(path):
            if sys.version_info >= (3, 12):
                shutil.rmtree(path, onexc=_ro)          # onerror เลิกใช้ใน 3.12 (QGIS 3.40 บน Windows ใช้ 3.12)
            else:
                shutil.rmtree(path, onerror=_ro)
    except Exception:
        pass


def _rename_retry(src, dst, tries=5, delay=0.5):
    """os.rename แบบลองซ้ำ — บน Windows โปรแกรมป้องกันไวรัส/ตัวทำดัชนีล็อกไฟล์ที่เพิ่งแตกออกมาได้ชั่วครู่"""
    for i in range(tries):
        try:
            os.rename(src, dst)
            return
        except OSError:
            if i == tries - 1:
                raise
            time.sleep(delay)


def _upd_paths(plugins_dir, name):
    """★ 2.3.7 (audit LIFE-05) — ที่อยู่ของการติดตั้ง: here = โฟลเดอร์ปลั๊กอิน · bak = <โปรไฟล์>/python/mlep_backup ·
    prev/failed = สำเนาใน bak · old_prev/old_failed = ที่เก็บแบบเดิมใน plugins/ (ตัวติดตั้ง 2.3.7 ก่อนแก้)"""
    pd = os.path.abspath(plugins_dir)
    bak = os.path.join(os.path.dirname(pd), _UPD_BACKUP)
    return {"here": os.path.join(pd, name), "bak": bak,
            "prev": os.path.join(bak, name + "_prev"), "failed": os.path.join(bak, name + "_failed"),
            "old_prev": os.path.join(pd, _UPD_PREV), "old_failed": os.path.join(pd, _UPD_FAILED)}


def _disk_version(here):
    """เลขรุ่นใน metadata.txt ของโฟลเดอร์ปลั๊กอินบนดิสก์ (อ่านไม่ได้ = '') — ★ 2.3.7 (audit LIFE-03)"""
    try:
        with open(os.path.join(here, "metadata.txt"), encoding="utf-8-sig") as fh:
            return _meta_value(fh.read(), "version")
    except Exception:
        return ""


def _upd_check_disk(here, new_version, cur_version):
    """★ 2.3.7 (audit LIFE-03) — ติดตั้งรุ่นเดียวกันซ้ำในเซสชันเดียว (โหลดใหม่ถูกเลื่อนเพราะมีงานค้าง แล้วกด 🚀 อีก · หรือ QGIS
    อีกหน้าต่างของโปรไฟล์เดียวกันอัปเดตไปแล้ว) ⇒ เดิมย้าย "รุ่นใหม่ที่ติดตั้งรอไว้" ไปทับสำเนารุ่นเดิม ⇒ ถอยกลับไม่ได้อีก
    ⇒ รุ่นบนดิสก์ ≠ รุ่นที่เปิดอยู่ ⇒ ไม่ติดตั้ง ไม่แตะอะไร (already=True) · อ่านรุ่นบนดิสก์ไม่ได้ ⇒ ทางเดิม"""
    disk = _disk_version(here)
    dv, rv = _parse_version(disk), _parse_version(cur_version)
    if dv is None or rv is None or dv == rv:
        return
    nv = _parse_version(new_version)
    if nv is not None and dv >= nv:
        raise _UpdateInstallError(
            f"ติดตั้งรุ่น {disk} ไว้แล้ว — กรุณาบันทึกงาน แล้วปิด QGIS และเปิดใหม่เพื่อใช้รุ่นใหม่", already=True)
    raise _UpdateInstallError(
        f"มีรุ่น {disk} ติดตั้งรอไว้แล้ว (ยังไม่ได้เปิดใช้ · ที่เปิดอยู่คือ {cur_version}) — "
        f"กรุณาปิด QGIS แล้วเปิดใหม่ก่อน แล้วค่อยอัปเดตเป็น {new_version}", already=True)


def _os_reason(e):
    """★ 2.3.7 (audit LIFE-06) — OSError ระหว่างติดตั้ง ⇒ เหตุภาษาไทยสั้น ๆ (ตัวจริงอยู่ใน Log ของ MLEP)"""
    import errno
    no, win = getattr(e, "errno", None), getattr(e, "winerror", None)
    if isinstance(e, PermissionError) or no in (errno.EACCES, errno.EPERM) or win in (5, 32, 33):
        return "ไม่มีสิทธิ์เขียนไฟล์ในโฟลเดอร์ของ QGIS หรือมีไฟล์ถูกโปรแกรมอื่นเปิด/ล็อกอยู่ (เช่นโปรแกรมป้องกันไวรัส)"
    if no == errno.ENOSPC or win == 112:
        return "พื้นที่ดิสก์เต็ม"
    if no == errno.EROFS:
        return "ดิสก์เป็นแบบอ่านอย่างเดียว"
    if no == errno.ENAMETOOLONG or win == 206:
        return "ที่อยู่ไฟล์ยาวเกินที่ระบบรับได้"
    return "เขียนไฟล์ลงเครื่องไม่ได้"


def _upd_migrate_legacy(plugins_dir, name):
    """★ 2.3.7 (audit LIFE-05) — สำเนาแบบเดิมใน plugins/ (.mlep_prev · .mlep_failed · .mlep_upd_* ที่ค้าง) ⇒ ย้ายไป mlep_backup/
    (ปลายทางมีอยู่แล้ว / ไฟล์ชั่วคราวของการติดตั้งที่ค้าง ⇒ ลบ) · ไม่มีของค้าง = ไม่ทำอะไร · ไม่โยน error · คืนรายการที่ทำ"""
    done = []
    try:
        import glob
        P = _upd_paths(plugins_dir, name)
        for old, new in ((P["old_prev"], P["prev"]), (P["old_failed"], P["failed"])):
            if not os.path.lexists(old):
                continue
            try:
                if os.path.isdir(old) and not os.path.islink(old) and not os.path.lexists(new):
                    os.makedirs(P["bak"], exist_ok=True)
                    os.rename(old, new)
                    done.append(f"{old} -> {new}")
                else:
                    _rmtree_quiet(old)
                    done.append(f"ลบ {old}")
            except Exception:
                continue
        for t in glob.glob(os.path.join(glob.escape(os.path.abspath(plugins_dir)), ".mlep_upd_*")):
            _rmtree_quiet(t)
            done.append(f"ลบ {t}")
        # ★ 2.3.7 b17 (audit nit) — สำเนาของตัวอัปเดต 2.3.6 (<ชื่อ>_bak_update · ไม่มีจุดนำหน้า) ค้างได้เมื่อ rmtree ของมันล้ม
        #   (ไฟล์อ่านอย่างเดียวบน Windows) ⇒ QGIS เห็นเป็นปลั๊กอินตัวที่สอง · เดิมเก็บเฉพาะตอนตัวติดตั้งของ 2.3.7 ทำงาน
        #   ตอนนี้เก็บตอนเปิดปลั๊กอินด้วย (ปลั๊กอินเปิดอยู่จากโฟลเดอร์จริง ⇒ สำเนานี้ไม่ได้ใช้แล้วแน่นอน)
        _bu = os.path.join(os.path.abspath(plugins_dir), name + "_bak_update")
        if os.path.lexists(_bu):
            _rmtree_quiet(_bu)
            done.append(f"ลบ {_bu}" + (" (ไม่สำเร็จ)" if os.path.lexists(_bu) else ""))
    except Exception:
        pass
    return done


def _qgis_version_tuple(qgis_int=None):
    """Qgis.QGIS_VERSION_INT (เช่น 34407) -> (3, 44, 7)"""
    try:
        v = int(qgis_int if qgis_int is not None else Qgis.QGIS_VERSION_INT)
        return (v // 10000, (v // 100) % 100, v % 100)
    except Exception:
        return None


def _guarded_imports(tree):
    """id ของ ImportFrom ที่อยู่ใน try: … except ImportError/ModuleNotFoundError/Exception (หรือ except เปล่า)
    = โค้ดตั้งใจให้ "ไม่มีก็ได้" ⇒ ไม่นับเป็นไฟล์ที่ซิปต้องมี (ไม่งั้นบล็อกรุ่นที่ถูกต้องโดยไม่จำเป็น)"""
    import ast as _ast
    broad = {"ImportError", "ModuleNotFoundError", "Exception", "BaseException"}
    out = set()
    for node in _ast.walk(tree):
        if not isinstance(node, _ast.Try):
            continue
        catch = False
        for h in node.handlers:
            if h.type is None:
                catch = True
                break
            names = {x.id if isinstance(x, _ast.Name) else getattr(x, "attr", "")
                     for x in (h.type.elts if isinstance(h.type, _ast.Tuple) else [h.type])}
            if names & broad:
                catch = True
                break
        if catch:
            for stmt in node.body:
                out.update(id(sub) for sub in _ast.walk(stmt) if isinstance(sub, _ast.ImportFrom))
    return out


def _missing_relative_imports(trees, files):
    """โมดูลในแพ็กเกจที่โค้ดเรียกใช้ (from .x import … / from . import x) แต่ไม่มีไฟล์ในซิป
    ไม่ผูกกับรายชื่อไฟล์ตายตัว ⇒ รุ่นที่จัดโครงสร้างใหม่ (2.4.0) ยังติดตั้งผ่านตัวอัปเดตนี้ได้
    ข้าม import ที่อยู่ใน try/except ImportError|Exception (ตั้งใจให้ไม่มีก็ได้)"""
    import ast as _ast
    have = set(files)
    init_names = set()          # ชื่อที่ __init__.py รากนิยามเอง ⇒ `from . import <ชื่อ>` ไม่ใช่ไฟล์
    t0 = trees.get("__init__.py")
    if t0 is not None:
        for node in _ast.walk(t0):
            if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef, _ast.ClassDef)):
                init_names.add(node.name)
            elif isinstance(node, _ast.Assign):
                init_names.update(t.id for t in node.targets if isinstance(t, _ast.Name))
            elif isinstance(node, (_ast.Import, _ast.ImportFrom)):
                init_names.update((a.asname or a.name).split(".")[0] for a in node.names)
    missing = set()
    for rel, tree in trees.items():
        pkg = rel.split("/")[:-1]
        opt = _guarded_imports(tree)
        for node in _ast.walk(tree):
            if not isinstance(node, _ast.ImportFrom) or not node.level or id(node) in opt:
                continue
            up = node.level - 1
            if up > len(pkg):
                continue                                   # ออกนอกแพ็กเกจ — ไม่ใช่เรื่องของซิปนี้
            base = pkg[:len(pkg) - up]
            if node.module:
                targets = [base + node.module.split(".")]
            elif not base:
                targets = [[a.name] for a in node.names if a.name not in init_names]
            else:
                continue                                   # from . import x ในแพ็กเกจย่อย — ไม่เดา
            for parts in targets:
                p = "/".join(parts)
                if p + ".py" not in have and p + "/__init__.py" not in have:
                    missing.add(p.replace("/", ".") + ".py")
    return missing


def _check_update_zip(z, name, new_version, cur_version, qgis_int=None):
    """ตรวจซิปอัปเดตก่อนแตะโฟลเดอร์ปลั๊กอิน · ไม่ผ่าน = โยน _UpdateInstallError (ข้อความไทย) · ผ่าน = คืนเลขรุ่นในซิป"""
    import ast as _ast
    bad = z.testzip()
    if bad:
        raise _UpdateInstallError(f"ไฟล์ในซิปเสีย: {bad}")
    pre = name + "/"
    files = {n[len(pre):]: n for n in z.namelist() if n.startswith(pre) and not n.endswith("/")}
    for need in ("metadata.txt", "__init__.py"):
        if need not in files:
            raise _UpdateInstallError(f"ซิปไม่มี {pre}{need} — โครงไฟล์ไม่ถูกต้อง")
    # metadata ต้องอ่านได้แบบเดียวกับ QGIS (อ่านไม่ได้ = QGIS ไม่รู้จักปลั๊กอินหลังรีสตาร์ต)
    try:
        meta = z.read(files["metadata.txt"]).decode("utf-8")
        zver = _meta_value(meta, "version", strict=True)
        qmin = _meta_value(meta, "qgisMinimumVersion", strict=True)
        icon = _meta_value(meta, "icon", strict=True)
    except Exception as e:
        raise _UpdateInstallError(
            f"metadata.txt ในซิปอ่านไม่ได้แบบที่ QGIS อ่าน ({e.__class__.__name__}) — ยกเลิกการติดตั้ง")
    zv, nv = _parse_version(zver), _parse_version(new_version)
    if zv is None or nv is None:
        raise _UpdateInstallError(f"อ่านเลขรุ่นไม่ได้ (ในซิป {zver!r} · ที่ประกาศ {new_version!r}) — ยกเลิกการติดตั้ง")
    if zv != nv:
        raise _UpdateInstallError(f"ซิปเป็นเวอร์ชัน {zver} แต่ประกาศไว้ว่า {new_version} — ยกเลิกการติดตั้ง")
    cv = _parse_version(cur_version)
    if cv is not None and zv == cv:
        # ★ rc2 (audit A5-03) — รุ่นเท่ากันไม่ใช่ downgrade (เดิมข้อความเดียวกัน) · เครื่องที่ลงรุ่นทดสอบ (rc) เลขเดียวกับตัวจริง
        #   ได้ข้อความนี้ ⇒ บอกทางออก (ติดตั้งตัวจริงทับด้วย Install from ZIP)
        raise _UpdateInstallError(
            f"ซิปเป็นเวอร์ชัน {zver} ซึ่งเป็นรุ่นเดียวกับที่ใช้อยู่ — ไม่ต้องติดตั้งซ้ำ "
            "(ถ้าเครื่องนี้ลงรุ่นทดสอบไว้ ให้ติดตั้งตัวจริงทับด้วย Plugins ▸ Install from ZIP)")
    if cv is not None and zv < cv:
        raise _UpdateInstallError(
            f"ซิปเป็นเวอร์ชัน {zver} ซึ่งไม่ใหม่กว่าของที่ใช้อยู่ ({cur_version}) — ยกเลิก กัน downgrade")
    qv = _parse_version(qmin)
    if qv is None:
        raise _UpdateInstallError(f"qgisMinimumVersion ในซิปอ่านไม่ได้ ({qmin!r}) — ยกเลิกการติดตั้ง")
    cq = _qgis_version_tuple(qgis_int)
    if cq is not None and qv > cq:
        raise _UpdateInstallError(
            f"รุ่น {zver} ต้องใช้ QGIS {qmin} ขึ้นไป แต่เครื่องนี้เป็น QGIS {'.'.join(map(str, cq))} — "
            "ยกเลิกการติดตั้ง (แจ้งผู้ดูแลให้อัปเดต QGIS)")
    if icon and icon not in files:
        raise _UpdateInstallError(f"ซิปไม่มีไฟล์ไอคอน {icon} ที่ metadata.txt อ้างถึง — ยกเลิกการติดตั้ง")
    # ทุกไฟล์ .py ต้อง compile ผ่าน (ไฟล์ถูกตัด/ไวยากรณ์ผิด = QGIS โหลดปลั๊กอินไม่ขึ้นทั้งเครื่อง)
    trees = {}
    for rel, full in sorted(files.items()):
        if not rel.endswith(".py"):
            continue
        try:
            tree = _ast.parse(z.read(full), filename=full)
            compile(tree, full, "exec", dont_inherit=True)
        except (SyntaxError, ValueError) as e:
            raise _UpdateInstallError(
                f"ไฟล์ {rel} ในซิปมีข้อผิดพลาด ({e.__class__.__name__} บรรทัด {getattr(e, 'lineno', '?')}) "
                "— ยกเลิกการติดตั้ง")
        trees[rel] = tree
    if not any(isinstance(n, _ast.FunctionDef) and n.name == "classFactory" for n in trees["__init__.py"].body):
        raise _UpdateInstallError("__init__.py ในซิปไม่มี classFactory — QGIS โหลดปลั๊กอินไม่ได้ · ยกเลิกการติดตั้ง")
    miss = _missing_relative_imports(trees, files)
    if miss:
        raise _UpdateInstallError("ซิปขาดไฟล์ที่โค้ดเรียกใช้: " + ", ".join(sorted(miss)) + " — ยกเลิกการติดตั้ง")
    return zver


def _install_update_zip(data, plugins_dir, name, new_version, cur_version, qgis_int=None):
    """ตรวจซิป -> แตกลงโฟลเดอร์ชั่วคราว -> ย้ายรุ่นเดิมไปเก็บ -> ย้ายรุ่นใหม่เข้าที่ · คืนเลขรุ่นที่ติดตั้ง
    ★ 2.3.7 (audit LIFE-05) สำเนา/ไฟล์ชั่วคราวอยู่ที่ mlep_backup/ นอก plugins (_upd_paths) · (LIFE-03) รุ่นบนดิสก์ ≠ รุ่นที่เปิดอยู่
    ⇒ ไม่ติดตั้งซ้ำ · (LIFE-06) OSError (โฟลเดอร์ถูกล็อก/เขียนไม่ได้/ดิสก์เต็ม) ⇒ _UpdateInstallError ภาษาไทย
    (เดิมหลุดออกไปเป็น "ดาวน์โหลดรุ่นใหม่ไม่สำเร็จ … ตรวจการเชื่อมต่ออินเทอร์เน็ต" = ชี้ผิดสาเหตุ)"""
    import tempfile
    P = _upd_paths(plugins_dir, name)
    here, prev = P["here"], P["prev"]
    _upd_check_disk(here, new_version, cur_version)          # ★ LIFE-03 — ก่อนแตะอะไรทั้งสิ้น
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except Exception as e:
        raise _UpdateInstallError(f"ไฟล์ซิปเสีย ({e.__class__.__name__})")
    zver = _check_update_zip(z, name, new_version, cur_version, qgis_int)
    tmp = None
    try:
        try:
            os.makedirs(P["bak"], exist_ok=True)
            tmp = tempfile.mkdtemp(prefix="upd_", dir=P["bak"])
            z.extractall(tmp)
        except OSError as e:
            raise _UpdateInstallError(f"แตกไฟล์รุ่นใหม่ลงเครื่องไม่ได้ — {_os_reason(e)} · ยกเลิกการติดตั้ง") from e
        src = os.path.join(tmp, name)
        if not os.path.isfile(os.path.join(src, "__init__.py")):
            raise _UpdateInstallError("ซิปแตกออกมาไม่ครบ (ไม่พบ __init__.py) — ยกเลิกการติดตั้ง")
        if os.path.lexists(prev):
            _rmtree_quiet(prev)
            if os.path.lexists(prev):
                raise _UpdateInstallError(
                    f"ลบสำเนารุ่นก่อนหน้า ({prev}) ไม่ได้ — ยกเลิกการติดตั้ง (ปิด QGIS แล้วลองใหม่)")
        try:
            _rename_retry(here, prev)                   # เก็บรุ่นเดิมไว้ (ไม่ลบ) — ใช้คืนถ้ารุ่นใหม่โหลดไม่ขึ้น
        except OSError as e:                            # ★ LIFE-06 — os.rename ไม่สำเร็จ = ยังไม่ได้ย้ายอะไร
            raise _UpdateInstallError(f"ย้ายรุ่นเดิมออกไปเก็บไม่ได้ — {_os_reason(e)} · ยกเลิกการติดตั้ง") from e
        try:
            _rename_retry(src, here)
        except Exception as e:
            try:
                _rename_retry(prev, here)
            except Exception:
                raise _UpdateInstallError(
                    f"ติดตั้งไม่สำเร็จ และย้ายรุ่นเดิมกลับไม่ได้ — สำเนารุ่นเดิมอยู่ที่ {prev} "
                    "· กรุณาปิด QGIS แล้วแจ้งผู้ดูแล", intact=False)
            _why = _os_reason(e) if isinstance(e, OSError) else e.__class__.__name__      # ★ LIFE-06 เหตุภาษาไทย
            raise _UpdateInstallError(f"ย้ายรุ่นใหม่เข้าที่ไม่ได้ ({_why}) — คืนรุ่นเดิมแล้ว")
    finally:
        if tmp:
            _rmtree_quiet(tmp)
    # สำเนาสำรองแบบเก่าของตัวอัปเดต 2.3.6 (`<ชื่อ>_bak_update` ไม่มีจุดนำหน้า) ถ้าค้าง QGIS จะโหลดเป็นปลั๊กอินตัวที่สอง
    _rmtree_quiet(os.path.join(plugins_dir, name + "_bak_update"))
    # ★ 2.3.7 (audit LIFE-05) — สำเนาแบบเดิมใน plugins/ (.mlep_prev · .mlep_failed · .mlep_upd_*) ⇒ ย้ายไป/ลบ (สำเนาจริงอยู่ที่ prev แล้ว)
    _upd_migrate_legacy(plugins_dir, name)
    return zver


def _rollback_failed_update(plugins_dir, name):
    """รุ่นใหม่โหลดไม่ขึ้น ⇒ ย้ายรุ่นใหม่ไปเก็บ (<ชื่อ>_failed) แล้วคืนสำเนารุ่นเดิมเข้าที่ · คืน (สำเร็จ?, รายละเอียด/ที่เก็บรุ่นเสีย)
    ★ 2.3.7 (audit LIFE-05) — สำเนาอยู่ที่ mlep_backup/ นอก plugins · ยังรับสำเนาแบบเดิม plugins/.mlep_prev (ตัวติดตั้งก่อนแก้)"""
    P = _upd_paths(plugins_dir, name)
    here, failed = P["here"], P["failed"]
    prev = P["prev"] if os.path.isdir(P["prev"]) else P["old_prev"]
    if not os.path.isdir(prev):
        return False, f"ไม่พบสำเนารุ่นเดิม ({P['prev']})"
    try:
        os.makedirs(P["bak"], exist_ok=True)
        if os.path.lexists(failed):
            _rmtree_quiet(failed)
        if os.path.lexists(here):
            _rename_retry(here, failed)
        _rename_retry(prev, here)
        return True, failed
    except Exception as e:
        # ย้ายรุ่นใหม่ออกแล้วแต่คืนรุ่นเดิมไม่ได้ ⇒ เอารุ่นใหม่กลับที่เดิม (ยังดีกว่าไม่มีปลั๊กอินเลย)
        if not os.path.lexists(here) and os.path.isdir(failed):
            try:
                _rename_retry(failed, here)
            except Exception:
                pass
        return False, f"{e.__class__.__name__}: {e} · สำเนารุ่นเดิมอยู่ที่ {prev}"


def _upd_get(url, timeout):
    """★ 2.3.7 b19 (doc-verify E6) — GET ไปเซิร์ฟเวอร์อัปเดต (GitHub) ด้วยการตรวจใบรับรองชุดเดียวกับระบบกรม
    (dol_api._new_session → _TrustAdapter: ที่เก็บใบรับรองของ Windows + certifi) · เดิม requests.get ตรง = certifi อย่างเดียว
    ⇒ เครื่องที่โปรแกรมป้องกันไวรัสตรวจ HTTPS (ใบรับรองของโปรแกรมอยู่ในที่เก็บของ Windows) ตรวจ/ดาวน์โหลดอัปเดตไม่ได้
    ทั้งที่ปุ่มระบบกรมใช้ได้ · session ใหม่ทุกครั้ง (เรียกจากเธรดเบื้องหลัง · ไม่ใช้ร่วมข้ามเธรด) แล้วปิดทิ้ง · ยังตรวจใบรับรองเสมอ"""
    from .. import dol_api
    s = dol_api._new_session("QGIS-MultiLayerEditPro")
    try:
        return s.get(url, timeout=timeout)
    finally:
        try:
            s.close()
        except Exception:
            pass


def _upd_net_text(e):
    """★ 2.3.7 b19 (doc-verify E6) — เหตุภาษาไทยของงานเครือข่ายของ "ตัวอัปเดต" (เซิร์ฟเวอร์อัปเดต = GitHub)
    เดิมใช้ _net_err_text → dol_api.net_reason ⇒ ใบรับรองไม่ผ่านขึ้นว่า "…ของระบบกรมไม่ผ่าน…" = บอกผิดระบบ
    🔑 ลำดับเหมือน net_reason: SSLError / ConnectTimeout เป็นลูกของ ConnectionError ⇒ ตรวจก่อน
    ไม่ใช่ exception ของ requests ⇒ _net_err_text ตามเดิม (ข้อความไทยของเราเอง / 'เกิดข้อผิดพลาดที่ไม่คาดคิด')"""
    try:
        if isinstance(e, requests.exceptions.SSLError):
            return ("ตรวจใบรับรองของเซิร์ฟเวอร์อัปเดต (GitHub) ไม่ผ่าน — เครือข่ายหรือโปรแกรมป้องกันไวรัสอาจดักการเชื่อมต่อ "
                    "· แจ้งผู้ดูแล")
        if isinstance(e, requests.exceptions.Timeout):
            return "เซิร์ฟเวอร์อัปเดต (GitHub) ตอบช้าเกินเวลา (หมดเวลารอ) — ลองใหม่ภายหลัง"
        if isinstance(e, requests.exceptions.ConnectionError):
            return "เชื่อมต่อเซิร์ฟเวอร์อัปเดต (GitHub) ไม่ได้ — ตรวจอินเทอร์เน็ต/เครือข่ายของสำนักงาน"
        if isinstance(e, requests.exceptions.HTTPError):
            code = getattr(getattr(e, "response", None), "status_code", None)
            return "เซิร์ฟเวอร์อัปเดต (GitHub) ตอบผิดปกติ" + (f" (HTTP {code})" if code else "")
        if isinstance(e, requests.exceptions.RequestException):
            return "เชื่อมต่อเซิร์ฟเวอร์อัปเดต (GitHub) ผิดพลาด"
    except Exception:
        pass
    return _net_err_text(e)
