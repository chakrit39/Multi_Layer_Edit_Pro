# -*- coding: utf-8 -*-
"""กติกา 1 มุม : 1 หมุด — ตรวจคู่ก่อนบันทึก, มุมเปลือย, หมุดซ้อน, มุมซ้อน

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import math
import os
import time
from qgis.core import (Qgis, QgsCoordinateTransform, QgsExpression, QgsFeatureRequest, QgsMessageLog,
                       QgsPointXY, QgsProject, QgsRectangle, QgsUnitTypes)
from ..core.util import (_fld_idx, _LockScanError, _log_exc, _norm_utm, _scrub, _txt, _UTM_FIELD_NAMES, _กริดจุด)
from ..lock_rules import L1_TYPES


class PairingMixin:
    """กติกา 1 มุม : 1 หมุด — ตรวจคู่ก่อนบันทึก, มุมเปลือย, หมุดซ้อน, มุมซ้อน"""

    def _pairing_gap(self):
        """★ 2.3.7 (review ER-01) — เหตุที่ด่านรอบล่าสุด "ไม่ได้ตรวจ" หรือ "ตรวจไม่ครบ" · None = ตรวจครบ/ไม่มีอะไรต้องตรวจ"""
        why = str(getattr(self, "_pairing_last_why", "ok") or "ok")
        # ★ 2.4.0 (review DU-02) no-metric-crs = ชั้นพิกัดองศา (เกณฑ์ 1 มม. ใช้ไม่ได้) ⇒ ต้องบอกว่าไม่ได้ตรวจ
        if why in self._PERF_SKIP or why in ("no-utm-field", "no-metric-crs", "crs-mismatch") or why.startswith("partial-"):
            return why
        return None

    @staticmethod
    def _pairing_gap_th(why, n=None):
        """★ 2.3.7 (review ER-01) — (หัว, เหตุผลภาษาไทย) ของ _pairing_gap() สำหรับบอกพนักงาน"""
        why = str(why or "")
        txt = {
            "skip-cap": "แก้ไว้หลายแปลงเกินกว่าจะตรวจได้ในครั้งเดียว" + (f" ({n:,} แปลง)" if n else ""),
            "skip-budget": "ตรวจนานเกินเวลาที่กำหนด จึงหยุดตรวจเพื่อไม่ให้การบันทึกค้าง",
            "skip-error": "ตัวตรวจขัดข้อง (รายละเอียดอยู่ในแผง Log ของ QGIS แท็บ MLEP)",
            "no-utm-field": "ไม่พบคอลัมน์ UTM ในชั้นแปลงหรือชั้นหมุด",
            "partial-markers": "ฝั่งหมุดตรวจได้ไม่ครบ (แก้หมุด/ลบแปลงไว้มากเกินไป หรืออ่านข้อมูลหมุดไม่ได้)",
            "partial-noutm": "มีแปลงที่แก้แต่ไม่มีค่า UTM" + (f" {n:,} แปลง" if n else "") + " — ตรวจคู่หมุดไม่ได้ ตรวจด้วยตาเอง",
            # ★ 2.4.0 (review DU-02)
            "no-metric-crs": "ชั้นแปลงหรือชั้นหมุดใช้พิกัดหน่วยองศา — วัดระยะหมุดกับมุมเป็นมิลลิเมตรไม่ได้ ตรวจด้วยตาเอง",
            "partial-degrees": "ชั้นแปลงหรือชั้นหมุดใช้พิกัดหน่วยองศา — ตรวจได้เฉพาะหมุดของแปลงที่ถูกลบ "
                               "มุม/หมุดของแปลงที่แก้ ตรวจด้วยตาเอง",
            # ★ rc2 (audit A4-09)
            "crs-mismatch": "ชั้นแปลงกับชั้นหมุดใช้ระบบพิกัด (CRS) คนละระบบ — เทียบหมุดกับมุมแปลงไม่ได้ "
                            "ตั้ง CRS ของสองชั้นให้ตรงกัน หรือตรวจด้วยตาเอง",
            "partial-crs": "ชั้นแปลงกับชั้นหมุดใช้ระบบพิกัด (CRS) คนละระบบ — ตรวจได้เฉพาะหมุดของแปลงที่ถูกลบ "
                           "มุม/หมุดของแปลงที่แก้ ตรวจด้วยตาเอง",
        }.get(why, why)
        head = "ตรวจมุม/หมุดได้ไม่ครบ" if why.startswith("partial-") else "ยังไม่ได้ตรวจมุม/หมุด"
        return head, txt

    def _pairing_text(self, iss, saved=False, why=None):
        """★ 2.3.7 (review UX-39 · DI-48 · DI-47) — ข้อความเดียวกันของกล่องก่อนบันทึกและคำเตือนหลังบันทึก
        เดิมรวม 3 ความผิด (มุมไม่มีหมุด · หมุดซ้อน · หมุดไม่อยู่บนมุม) เป็นตัวเลข "มุมที่ไม่มีหมุด" ตัวเดียว
        (ได้ "6 มุม จาก 3 มุมที่ตรวจ") และแนะนำ Add Node เสมอ ⇒ นับแยก · หัวเรื่องตามชนิด · สาเหตุ/วิธีแก้ตามชนิด
        คืน (หัวเรื่อง, สรุปบรรทัดเดียว, เนื้อความ)"""
        bad, checked, sample = iss[0], iss[1], iss[2]
        k = getattr(iss, "kinds", None) or {}
        miss = k.get("missing", 0 if k else bad)
        stk, stray, orph, near = k.get("stacked", 0), k.get("stray", 0), k.get("orphan", 0), k.get("near", 0)
        parts = []
        if miss:
            parts.append(f"มุมไม่มีหมุด {miss:,} มุม")
        if stk:
            parts.append(f"มุมมีหมุดซ้อน {stk:,} มุม")
        if stray:
            parts.append(f"หมุดไม่อยู่บนมุม {stray:,} จุด")
        if orph:
            parts.append(f"หมุดของแปลงที่ถูกลบ {orph:,} ดวง")
        n_kind = sum(1 for x in (miss, stk, stray, orph) if x)
        if n_kind != 1:
            title = "แปลงกับหมุดไม่ตรงกัน"
        elif miss:
            title = "มุมแปลงที่ไม่มีหมุด"
        elif stk:
            title = "มุมแปลงที่มีหมุดซ้อนกัน"
        elif stray:
            title = "หมุดที่ไม่อยู่บนมุมแปลง"
        else:
            title = "หมุดของแปลงที่ถูกลบ"
        summary = " · ".join(parts) + (f" (ตรวจ {checked:,} มุม)" if checked else "")
        lines = "\n".join("• " + s for s in sample)
        causes = []
        if miss or stray:
            if saved:
                causes += ["• ใช้เครื่องมือ Vertex Tool / แก้รูปร่าง ของ QGIS แก้มุมแปลงโดยตรง\n"
                           "  → เครื่องมือของ QGIS ไม่สร้าง/ไม่ย้ายหมุดให้ ต้องใช้ปุ่มของปลั๊กอิน",
                           "• กด Undo ของ QGIS (เมนู Edit / แถบเครื่องมือ) ซึ่งย้อนแค่ชั้นเดียว"]
            else:
                # ★ 2.3.7 rc3 (ตรวจคู่มือ 5 ต.ค. 69) — 2.3.7 ให้ Ctrl+Z เป็นของ ↺ Undo ของปลั๊กอินระหว่างเปิดใช้ปลั๊กอิน
                #   ⇒ "กด Ctrl+Z ของ QGIS" ไม่จริงแล้ว · Undo ของ QGIS ที่ย้อนชั้นเดียวคือเมนู Edit / ปุ่มบนแถบเครื่องมือ
                causes += ["• กด Undo ของ QGIS (เมนู Edit / แถบเครื่องมือ) ซึ่งย้อนแค่ชั้นที่เลือกอยู่ อีกชั้นไม่ย้อนตาม"
                           " — ใช้ปุ่ม ↺ Undo ของปลั๊กอินแทน",
                           "• Align ดึงมุมแปลงข้างเคียงไปตามเส้น แต่หมุดของแปลงนั้นไม่ได้ถูกเลือกให้ย้ายด้วย",
                           "• เพิ่ม node แล้วหมุดใหม่เข้าไม่สำเร็จ"]
        if stk:
            causes.append("• หมุดซ้อน: กด Add Node ซ้ำที่มุมเดิม หรือนำเข้าหมุดซ้ำ — ใช้ ลบ Node ที่มุมนั้นให้เหลือหมุดดวงเดียว")
        if orph:
            causes.append("• ลบแปลงด้วยเครื่องมือของ QGIS แต่หมุดของแปลงนั้นยังอยู่ — ลบหมุดเหล่านั้นด้วย หรือย้อนการลบแปลง")
        causes.append("• มีคนอื่นแก้และบันทึกแปลงนี้ไปก่อน (ข้อมูลในฐานเปลี่ยนระหว่างที่คุณแก้)")
        if near:
            fix = (f"มุมที่มีหมุดของแปลงเดียวกันลอยอยู่ใกล้ ๆ (ไม่เกิน {self._PAIR_NEAR_M:g} ม.) "
                   + ("→ กด No แล้วใช้ ↺ Undo ของปลั๊กอิน หรือ Move Node ลากหมุดนั้นไปวางที่มุม" if not saved
                      else "→ ใช้ Move Node ลากหมุดนั้นไปวางที่มุม แล้วบันทึกอีกครั้ง")
                   + "\n  อย่าใช้ Add Node ตรงมุมนั้น (จะได้หมุดเพิ่มอีกดวง) — Add Node ใช้เฉพาะมุมที่ไม่มีหมุดอยู่ใกล้เลย")
        elif miss:
            fix = 'ใช้ "➕ Add Node" เพิ่มหมุดที่มุมเหล่านั้น' + (" แล้วบันทึกอีกครั้ง" if saved else "")
        else:
            fix = ""
        gap = ""
        if why and str(why).startswith("partial-"):
            gap = "\n(" + " — ".join(self._pairing_gap_th(why, getattr(self, "_pairing_last_n", None))) + ")"
        # ★ 2.4.0 (review UX-09) — รายการข้างบนมีแค่ 5 จุดแรก ⇒ บอกว่าทุกจุดถูกทำเครื่องหมายบนแผนที่ + ไล่ดูได้จากแถบข้อความ
        _np = len(getattr(iss, "points", None) or ())
        if _np:
            gap += (f"\n\n📍 ทั้ง {_np:,} จุดจะถูกทำเครื่องหมายบนแผนที่หลังปิดหน้าต่างนี้ — "
                    "ไล่ดูทีละจุดด้วยปุ่ม ◀ ▶ บนแถบข้อความเหนือแผนที่")
        if saved:
            body = (f"บันทึกลงฐานข้อมูลเรียบร้อยแล้ว แต่ตรวจพบ: {summary}\n\n{lines}{gap}\n\n"
                    "สาเหตุที่พบบ่อยที่สุด:\n" + "\n".join(causes) + (f"\n\nวิธีแก้: {fix}" if fix else ""))
        else:
            body = (f"ในงานที่กำลังจะบันทึก พบ: {summary}\n\n{lines}{gap}\n\n"
                    "สาเหตุที่พบบ่อย:\n" + "\n".join(causes) + (f"\n\nแนะนำ: {fix}" if fix else "")
                    + "\n\nยังต้องการบันทึกต่อหรือไม่?")
        return title, summary, body

    def _pairing_orphans(self, poly_lyr, point_lyr, buf, pu, tu, cap, pts_out=None):
        """★ 2.3.7 (review DI-47) — แปลงที่ถูกลบในรอบนี้ (เช่น Delete Selected ของ QGIS) แต่หมุดของแปลงนั้นยังอยู่ = หมุดลอยทั้งชุด
        คืน (จำนวนหมุดค้าง, [utm...], ตรวจครบไหม) · เตือนอย่างเดียว ไม่ลบอะไรเอง
        ไม่นับ: UTM ที่ยังมีแปลงอื่นในชั้น (แปลงแฝด) · หมุดที่ถูกลบไปพร้อมแปลง (อ่านผ่านชั้น = เห็น buffer แล้ว)
        ★ 2.4.0 (review UX-09) — pts_out (list) = เติมตำแหน่งหมุดที่นับ ('orphan', x, y, 'point', utm) จากคิวรีเดิม (ไม่ดึงเพิ่ม)"""
        dels = list(buf.deletedFeatureIds()) if buf is not None else []
        if not dels:
            return 0, [], True
        if len(dels) > cap:
            return 0, [], False
        gone = {}                                  # utm(normalize) -> [{ค่าดิบ, ค่า normalize}, กรอบรวม]
        it = poly_lyr.dataProvider().getFeatures(QgsFeatureRequest().setFilterFids(dels))
        try:
            for f in it:
                raw = _txt(f[pu])
                if not raw:
                    continue
                k = _norm_utm(raw)
                rec = gone.setdefault(k, [set(), QgsRectangle()])
                rec[0].update({raw, k})
                g = f.geometry()
                if g is not None and not g.isNull() and not g.isEmpty():
                    rec[1].combineExtentWith(g.boundingBox())
        finally:
            it.close()

        def _in(col):
            vals = sorted(set().union(*(r[0] for r in gone.values())))
            return f"{QgsExpression.quotedColumnRef(col)} IN ({','.join(QgsExpression.quotedValue(v) for v in vals)})"
        if gone:
            it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(_in(pu))
                                      .setFlags(QgsFeatureRequest.NoGeometry))
            try:
                for f in it:
                    gone.pop(_norm_utm(f[pu]), None)          # ยังมีแปลงแฝด UTM เดียวกัน ⇒ หมุดยังมีเจ้าของ
            finally:
                it.close()
        if not gone:
            return 0, [], True
        req = QgsFeatureRequest().setFilterExpression(_in(tu))
        bb = QgsRectangle()
        for _r in gone.values():
            if not _r[1].isNull():
                bb.combineExtentWith(_r[1])
        if not bb.isNull() and max(bb.width(), bb.height()) <= 5000.0:
            bb.grow(1.0)
            req.setFilterRect(bb)
        cnt = {}
        it = point_lyr.getFeatures(req)
        try:
            for f in it:
                k = _norm_utm(f[tu])
                if k in gone:
                    cnt[k] = cnt.get(k, 0) + 1
                    if pts_out is not None:                      # ★ 2.4.0 (review UX-09)
                        try:
                            _g = f.geometry()
                            if _g is not None and not _g.isEmpty():
                                _p = _g.asPoint()
                                pts_out.append(('orphan', _p.x(), _p.y(), 'point', k))
                        except Exception:
                            pass
        finally:
            it.close()
        return sum(cnt.values()), sorted(cnt), True

    def _why(self, why):
        """จดว่าด่านจบด้วยเหตุผลอะไร แล้วคืน None (ใช้แทน `return None` เดิม)"""
        self._pairing_last_why = why
        return None

    @staticmethod
    def _perf_dir():
        d = os.environ.get('MLEP_PERF_DIR')          # ให้เทสชี้ที่อื่นได้
        if d:
            return d
        return r'C:\QGIS_Debug\logs' if os.name == 'nt' else ''

    def _busy(self, tag):
        return self._Busy(self, tag)

    def _perf_slow(self, tag, dt):
        """★ 2.3.7 (review PF-03) — จดงานที่ช้า (≥ _PERF_SLOW_S) ลง mlep_perf.log + แผง Log แท็บ MLEP"""
        if dt < self._PERF_SLOW_S:
            return
        line = '\t'.join([time.strftime('%Y-%m-%d %H:%M:%S'), str(tag), '%.3fs' % dt,
                          'v=' + str(getattr(self, 'version', '?'))])
        self._perf_write(line)
        QgsMessageLog.logMessage('งานช้า ' + ' · '.join(line.split('\t')[1:]), 'MLEP',
                                 Qgis.Warning if dt >= self._PERF_WARN_S else Qgis.Info)

    def _perf_write(self, line):
        d = self._perf_dir()
        if not d or not os.path.isdir(d):
            return False
        p = os.path.join(d, 'mlep_perf.log')
        # ★ 2.3.7 (review ER-01) — ย้ายไฟล์ (หมุนรุ่น) กับเขียนต่อท้าย คนละ try: ไฟล์ถูกล็อกจนย้ายไม่ได้ ยังเขียนต่อท้ายได้
        try:
            if os.path.exists(p) and os.path.getsize(p) > self._PERF_MAX_BYTES:
                os.replace(p, p + '.1')
        except Exception:
            pass
        try:
            with open(p, 'a', encoding='utf-8') as f:
                f.write(line + '\n')
            return True
        except Exception:
            return False

    def _pairing_issues(self, poly_lyr, point_lyr, cap=2000):
        """ตัวห่อของ `_pairing_issues_impl` — ผลเหมือนเดิมทุกอย่าง แค่จับเวลาแล้วจดไว้"""
        self._pairing_last_why = 'ok'
        self._pairing_last_err = ''      # ★ 2.3.7 (review ER-01) ข้อความ exception — เก็บเป็น string เท่านั้น (ห้ามเก็บตัว
                                         #   exception: traceback ค้ำ frame + iterator ที่เปิดอยู่ = คอนเนกชันพูลค้าง)
        self._pairing_last_n = None      # ★ 2.3.7 จำนวนประกอบเหตุผล (แปลงที่เกินเพดาน / แปลงไม่มี UTM)
        t0 = time.monotonic()
        res = self._pairing_issues_impl(poly_lyr, point_lyr, cap)
        try:
            dt = time.monotonic() - t0
            why = getattr(self, '_pairing_last_why', 'ok')
            _gap = self._pairing_gap()       # ★ 2.3.7 (review ER-01) ข้าม/ตรวจไม่ครบ ⇒ จดเสมอ (เดิมไม่มีร่องรอยของ "ไม่ครบ")
            if dt >= self._PERF_SLOW_S or why in self._PERF_SKIP or _gap:
                def _n(lyr):
                    try:
                        b = lyr.editBuffer() if (lyr is not None and lyr.isEditable()) else None
                        return (len(b.changedGeometries()) + len(b.addedFeatures())
                                + len(b.deletedFeatureIds())) if b is not None else 0
                    except Exception:
                        return -1
                line = '\t'.join([
                    time.strftime('%Y-%m-%d %H:%M:%S'), 'save-check', '%.3fs' % dt,
                    'why=' + why, 'poly=%d' % _n(poly_lyr), 'pts=%d' % _n(point_lyr),
                    'bad=%s' % (res[0] if res else '-'),
                    'layer=' + (poly_lyr.name() if poly_lyr is not None else '-'),
                    'v=' + str(getattr(self, 'version', '?'))])
                if self._pairing_last_err:       # ★ 2.3.7 (review ER-01) เหตุที่ตัวตรวจล้ม (เดิมทิ้งไปเงียบ ๆ)
                    line += '\terr=' + _scrub(self._pairing_last_err).replace('\t', ' ').replace('\n', ' ')[:200]
                self._perf_write(line)
                QgsMessageLog.logMessage(
                    'ตรวจก่อนบันทึก ' + ' · '.join(line.split('\t')[2:]), 'MLEP',
                    Qgis.Warning if (dt >= self._PERF_WARN_S or why in self._PERF_SKIP or _gap) else Qgis.Info)
        except Exception:
            pass
        return res

    def _pairing_issues_impl(self, poly_lyr, point_lyr, cap=2000):
        """ตรวจกติกาเหล็ก **"ใน 1 แปลง ทุก node ต้องมีหมุดของแปลงนั้นพอดี 1 หมุด"** (คิดแยกรายแปลง)
        ตรวจครบสามเงื่อนไข: มุมไม่มีหมุด · มุมมีหมุดซ้อนเกิน 1 · หมุดไม่อยู่บนมุมใดเลย
        ตรวจเฉพาะแปลงที่ค้างอยู่ใน edit buffer
        (ยังไม่ commit) -> คืน (n_bad, n_checked, ตัวอย่าง) หรือ None ถ้าตรวจไม่ได้/ข้าม.

        ตรวจ "ผลลัพธ์" ไม่ใช่ "สาเหตุ" จึงดักได้ทุกทางที่ทำแปลงกับหมุดหลุดคู่กัน:
          • กด Undo ของ QGIS — เมนู Edit / แถบเครื่องมือ (undo แค่เลเยอร์ที่ active -> อีกชั้นยังค้างใน buffer)
          • Align ดึงมุมแปลงข้างเคียงตามเส้น แต่หมุดของแปลงนั้นไม่ได้ถูกเลือกให้ย้ายด้วย
          • เพิ่ม node แล้วหมุดใหม่เข้าไม่ได้ (เช่นสิทธิ์ INSERT ไม่พอ)
          • ใช้เครื่องมือแก้ไขของ QGIS ตรงๆ โดยไม่ผ่านปลั๊กอิน
        คิวรีเดียว (ดึงหมุดของ UTM ที่เกี่ยวทั้งชุด) แล้วเทียบในหน่วยความจำ -> ไม่ยิง DB ต่อแปลง

        ★ มีเพดานเวลา `budget` วินาที (2026-08-05): ด่านนี้เป็นแค่ "ตัวเตือน" ห้ามมีทางทำให้บันทึกค้าง
          เกินเวลา -> คืน None = ข้ามการเตือน แล้วปล่อยให้บันทึกเดินต่อ (ไม่ได้ทำข้อมูลเสีย)"""
        _t0 = time.monotonic()
        budget = float(getattr(self, "_pairing_budget_s", 8.0))
        try:
            if not poly_lyr or not point_lyr:
                return self._why('no-layer')
            # ★ รองรับ "แก้ชั้นหมุดอย่างเดียว" ด้วย — เดิมบังคับว่าชั้นแปลงต้องเปิดแก้ไข
            #   -> ย้าย/ลบหมุดด้วยเครื่องมือ QGIS โดยไม่แตะแปลง = ตรวจไม่ได้เลย
            if not (poly_lyr.isEditable() or point_lyr.isEditable()):
                return self._why('not-editing')
            buf = poly_lyr.editBuffer() if poly_lyr.isEditable() else None
            fids = (set(buf.changedGeometries().keys()) | set(buf.addedFeatures().keys())) if buf is not None else set()
            if len(fids) > cap:
                self._pairing_last_n = len(fids)                  # ★ 2.3.7 (ER-01) บอกจำนวนในข้อความ
                return self._why('skip-cap')                      # แก้เยอะเกิน -> ข้าม (กันหน่วงตอน Save)
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if not pu or not tu:
                return self._why('no-utm-field')
            # ★ 2.4.2 (เจ้าของงานสั่ง 15 ต.ค. "เวลาแก้ไขแล้วไปซ้ำกัน ให้เตือนด้วย") — แปลง/หมุดที่ "เปลี่ยนค่า UTM" ในรอบนี้ต้องตรวจด้วย
            #   เดิมดูแค่รูปที่แก้ + ของที่เพิ่ม ⇒ 📝 / ตาราง attribute เปลี่ยน UTM ไปซ้ำแปลงข้างเคียง (มุมร่วมมีหมุด UTM เดียวกันซ้อน)
            #   หรือหมุดไม่ได้เปลี่ยนตาม (มุมไม่มีหมุด) บนแปลงที่บันทึกไว้แล้ว = ด่านไม่เห็นเลย
            if buf is not None:
                _iu = poly_lyr.fields().indexOf(pu)
                if _iu >= 0:
                    fids |= {f for f, a in buf.changedAttributeValues().items() if _iu in a}
                if len(fids) > cap:
                    self._pairing_last_n = len(fids)
                    return self._why('skip-cap')
            polys = {}
            n_nokey = 0                          # ★ 2.3.7 (DI-08) แปลงที่แก้แต่ไม่มีค่า UTM — ตรวจคู่หมุดไม่ได้
            _part = None                         # ★ 2.3.7 (review ER-01) ฝั่งหมุดถูกตัด/ล้ม = ตรวจไม่ครบ (เดิมจบ 'ok' เงียบ ๆ)
            if fids:
                # ★ 2.4.0 (review PF-07) — ใช้แค่ UTM + รูป ⇒ ไม่ดึงคอลัมน์อื่น (ผลเท่าเดิม · feature ไม่ถูกส่งต่อ)
                for f in poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(fids))
                                              .setSubsetOfAttributes([pu], poly_lyr.fields())):
                    u = f[pu]
                    # ★ 2.3.7 (review DI-08) — NULL มีชนิดจาก provider ไม่ใช่ None ⇒ ตัวแทน \x00 หลุดเข้า IN (...) = นิพจน์พัง
                    #   ⇒ ด่านเตือนมุมเปลือยหลอกทุกมุม (รวมแปลงที่จับคู่ถูก) · แปลงไม่มีคีย์ตรวจคู่ไม่ได้อยู่แล้ว ข้ามไป
                    if not _txt(u):
                        n_nokey += 1
                        continue
                    polys[f.id()] = (_norm_utm(u), f.geometry())
            # ★ การแก้ฝั่ง "ชั้นหมุด" (ย้าย/เพิ่ม/ลบ) -> ดึงแปลงของ UTM ที่หมุดถูกแตะมาตรวจด้วย
            touched_mk = []                  # [(utm, x, y)] หมุดที่ผู้ใช้ เพิ่ม/ย้าย ในรอบนี้
            try:
                pbuf = point_lyr.editBuffer() if point_lyr.isEditable() else None
                if pbuf is not None:
                    extra = set()
                    ch = set(pbuf.changedGeometries().keys()) | set(pbuf.addedFeatures().keys())
                    _it = point_lyr.fields().indexOf(tu)          # ★ 2.4.2 หมุดที่เปลี่ยนค่า UTM (ดูหมายเหตุด้านบน)
                    if _it >= 0:
                        ch |= {f for f, a in pbuf.changedAttributeValues().items() if _it in a}
                    if len(ch) > cap:
                        _part = 'partial-markers'                # ★ 2.3.7 (ER-01)
                    if ch and len(ch) <= cap:
                        # ★ 2.4.0 (review PF-07) — ใช้แค่ UTM + รูป
                        for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(ch))
                                                       .setSubsetOfAttributes([tu], point_lyr.fields())):
                            u = f[tu]
                            if _txt(u):                                  # ★ 2.3.7 DI-08
                                extra.add(_norm_utm(u))
                                # ★ เก็บไว้ตรวจ "หมุดลอย" เฉพาะหมุดที่ผู้ใช้เพิ่ง เพิ่ม/ย้าย ในรอบนี้
                                #   (ไม่ตรวจหมุดเก่าทั้งชั้น — หมุดเสียที่ติดมากับข้อมูลเดิมไม่ใช่
                                #    ความผิดของการบันทึกครั้งนี้ ถ้าเตือนด้วยจะกลายเป็น noise
                                #    จนพนักงานกด "บันทึกต่อ" ทิ้งโดยไม่อ่าน)
                                try:
                                    _g = f.geometry()
                                    if _g is not None and not _g.isEmpty():
                                        _p = _g.asPoint()
                                        touched_mk.append((_norm_utm(u),
                                                           round(_p.x(), 3), round(_p.y(), 3)))
                                except Exception:
                                    pass
                    dels = list(pbuf.deletedFeatureIds())
                    if len(dels) > cap:
                        _part = 'partial-markers'                # ★ 2.3.7 (ER-01)
                    if dels and len(dels) <= cap:
                        # หมุดที่ถูกลบหายจาก layer แล้ว -> อ่านค่า UTM เดิมจาก provider
                        # ★ 2.4.0 (review PF-07) — ใช้แค่ UTM ⇒ ไม่ดึงรูป/คอลัมน์อื่น (ชื่อฟิลด์ของ provider)
                        _dp = point_lyr.dataProvider()
                        for f in _dp.getFeatures(QgsFeatureRequest().setFilterFids(dels)
                                                 .setFlags(QgsFeatureRequest.NoGeometry)
                                                 .setSubsetOfAttributes([tu], _dp.fields())):
                            u = f[tu]
                            if _txt(u):                                  # ★ 2.3.7 DI-08
                                extra.add(_norm_utm(u))
                    extra -= {u for u, _g in polys.values()}
                    if extra and len(extra) + len(polys) > cap:
                        _part = 'partial-markers'                # ★ 2.3.7 (ER-01)
                    if extra and len(extra) + len(polys) <= cap:
                        qs0 = ",".join(QgsExpression.quotedValue(u) for u in extra)
                        e0 = f"{QgsExpression.quotedColumnRef(pu)} IN ({qs0})"
                        # ★ 2.4.0 (review PF-07) — ใช้แค่ UTM + รูป
                        _fit5191 = poly_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(e0)
                                                        .setSubsetOfAttributes([pu], poly_lyr.fields()))
                        try:
                            for f in _fit5191:
                                if f.id() not in polys:
                                    u = f[pu]
                                    if _txt(u):                          # ★ 2.3.7 DI-08
                                        polys[f.id()] = (_norm_utm(u), f.geometry())
                                if len(polys) > cap:
                                    _part = 'partial-markers'    # ★ 2.3.7 (ER-01)
                                    break
                        finally:
                            _fit5191.close()
            except Exception as e:
                _part = 'partial-markers'                        # ★ 2.3.7 (ER-01) เดิม pass เงียบ ๆ แล้วจบ 'ok'
                self._pairing_last_err = repr(e)[:300]
            # ★ 2.3.7 (review DI-47) — แปลงที่ถูกลบในรอบนี้แต่หมุดยังอยู่ (เดิมด่านดูแค่แปลงที่แก้รูป/เพิ่ม ⇒ 'nothing-to-check')
            n_orph, orph_utms = 0, []
            orph_pts = []                        # ★ 2.4.0 (review UX-09) ตำแหน่งหมุดของแปลงที่ถูกลบ
            try:
                n_orph, orph_utms, _ok = self._pairing_orphans(poly_lyr, point_lyr, buf, pu, tu, cap,
                                                               pts_out=orph_pts)
                if not _ok:
                    _part = 'partial-markers'
            except Exception as e:
                _part = 'partial-markers'
                self._pairing_last_err = repr(e)[:300]
            _orph_line = (f"หมุดของแปลงที่ถูกลบ {n_orph:,} ดวง — ระวาง/UTM {', '.join(orph_utms[:3])}"
                          + (" …" if len(orph_utms) > 3 else "")) if n_orph else ""

            def _done(bad, checked, sample, kinds, pts=()):
                # ★ 2.3.7 (review UX-39/ER-01) ผลพร้อมนับแยกชนิด + เหตุ "ตรวจไม่ครบ" (ตรวจได้บางส่วนยังคืนผล ไม่ใช่ None)
                if _part:
                    self._pairing_last_why = _part
                elif n_nokey:
                    self._pairing_last_why = 'partial-noutm'
                    self._pairing_last_n = n_nokey
                r = self._PairIssues((bad, checked, sample))
                kinds.update(orphan=n_orph, orphan_utms=orph_utms, nokey=n_nokey)
                r.kinds = kinds
                # ★ 2.4.0 (review UX-09) — ทุกจุดที่ผิด (มุม/หมุดของแปลงที่แก้ก่อน แล้วหมุดของแปลงที่ถูกลบ) + CRS ของสองชั้น
                r.points = list(pts) + orph_pts
                r.crs = (poly_lyr.crs(), point_lyr.crs())
                return r
            if not polys:
                if n_orph:
                    return _done(n_orph, 0, [_orph_line], dict(missing=0, stacked=0, stray=0, near=0, near_utms=[]))
                if _part:
                    return self._why(_part)
                if n_nokey:
                    self._pairing_last_n = n_nokey
                    return self._why('partial-noutm')
                return self._why('nothing-to-check')
            # ★ 2.4.0 (review DU-02) — เกณฑ์ 1 มม./1 ซม. ของด่านนี้เป็นเมตร (รวมคีย์ปัดมิลลิเมตร · กรอบ ±1 ม. · near 2 ม.)
            #   ชั้นพิกัดองศา 0.001 = 0.001° ≈ 110 ม. ⇒ มุมไม่มีหมุดหลุดเงียบ (2.3.10 ก็เป็น) ⇒ ไม่ตรวจมุม/หมุด แล้วบอกว่า "ตรวจไม่ได้"
            #   (หมุดของแปลงที่ถูกลบ — ไม่ใช้ระยะ — ยังรายงานได้ = ตรวจไม่ครบ) · ชั้นของกรมเป็น EPSG:32647 ไม่โดนทางนี้
            if any(_l.crs().isValid() and _l.crs().mapUnits() == QgsUnitTypes.DistanceDegrees
                   for _l in (poly_lyr, point_lyr)):
                if n_orph:
                    _part = 'partial-degrees'
                    return _done(n_orph, 0, [_orph_line], dict(missing=0, stacked=0, stray=0, near=0, near_utms=[]))
                return self._why('no-metric-crs')
            # ★ rc2 (audit A4-09) — ชั้นแปลงกับชั้นหมุดคนละ CRS ⇒ เทียบพิกัดมุมกับหมุดตรง ๆ ไม่ได้ (เดิมรายงาน "มุมไม่มีหมุด" ทุกมุมหลอก
            #   เช่นหมุด 24047 กับแปลง 32647) · เครื่องมือของปลั๊กอินปฏิเสธคู่นี้อยู่แล้ว (_pair_crs_ok) ⇒ ไม่ตรวจมุม/หมุด แล้วบอกว่า
            #   "ตรวจไม่ได้" แบบชั้นพิกัดองศา (หมุดของแปลงที่ถูกลบ — ไม่ใช้ระยะ — ยังรายงานได้ = ตรวจไม่ครบ)
            try:
                _crs_diff = (poly_lyr.crs().isValid() and point_lyr.crs().isValid() and poly_lyr.crs() != point_lyr.crs())
            except Exception:
                _crs_diff = False
            if _crs_diff:
                if n_orph:
                    _part = 'partial-crs'
                    return _done(n_orph, 0, [_orph_line], dict(missing=0, stacked=0, stray=0, near=0, near_utms=[]))
                return self._why('crs-mismatch')
            # ★ rc2 (audit A2 · ผู้ตรวจทานพบเพิ่ม) — แปลงแฝด (UTM เดียวกับแปลงที่แก้ แต่ตัวเองไม่ถูกแก้) ต้องอยู่ในการตรวจด้วย
            #   หมุดของคีย์หนึ่งใช้ร่วมกันทุกแปลงของคีย์นั้น ⇒ เดิมตรวจเฉพาะมุมของแปลงที่แก้:
            #   · ลบมุมร่วมของแฝด (หมุดเก็บไว้ถูกต้องเพราะแฝดยังใช้) ⇒ เตือนผิด "หมุดไม่อยู่บนมุมแปลง" (ปุ่มตั้งต้น No)
            #   · มุมของแฝดเปลือยจริง ⇒ ด่านไม่เห็น
            #   ดึงเฉพาะแปลงในกรอบของแปลงที่แก้ (ขยาย 1 ม. · แบบเดียวกับคิวรีหมุดข้างล่าง) — แฝดไกลออกไปใช้หมุดคนละชุดอยู่แล้ว
            try:
                _eu = {u for u, _g in polys.values()}
                if _eu and len(polys) <= cap:
                    _bb = QgsRectangle()
                    for _u, _g in polys.values():
                        if _g is not None and not _g.isNull() and not _g.isEmpty():
                            _bb.combineExtentWith(_g.boundingBox())
                    _e1 = (f"{QgsExpression.quotedColumnRef(pu)} IN ("
                           + ",".join(QgsExpression.quotedValue(u) for u in _eu) + ")")
                    _rq = QgsFeatureRequest().setFilterExpression(_e1).setSubsetOfAttributes([pu], poly_lyr.fields())
                    if not _bb.isNull() and max(_bb.width(), _bb.height()) <= 5000.0:
                        _bb.grow(1.0)
                        _rq.setFilterRect(_bb)
                    _itw = poly_lyr.getFeatures(_rq)
                    try:
                        for f in _itw:
                            if f.id() in polys:
                                continue
                            u = f[pu]
                            if _txt(u) and _norm_utm(u) in _eu:
                                polys[f.id()] = (_norm_utm(u), f.geometry())
                            if len(polys) > cap:
                                _part = 'partial-markers'
                                break
                    finally:
                        _itw.close()
            except Exception as e:
                _part = 'partial-markers'
                self._pairing_last_err = repr(e)[:300]
            utms = {u for u, _g in polys.values()}
            qs = ",".join(QgsExpression.quotedValue(u) for u in utms)
            expr = f"{QgsExpression.quotedColumnRef(tu)} IN ({qs})"
            # ★ จำกัดด้วยกรอบพื้นที่ของแปลงที่กำลังแก้ ก่อนกรองด้วย UTM
            #   คอลัมน์ UTM ไม่มี index -> WHERE "UTM" IN (...) เป็น seq scan ทั้งตาราง
            #   (วัดจริงบน Pathum_POINT 1.18 ล้านจุด: 27,204 buffers / 63-155 ms ต่อการกด Save 1 ครั้ง)
            #   ใส่ bbox ด้วย -> PostGIS ใช้ GiST index ที่มีอยู่แล้ว: 1,227 buffers / 4 ms
            #   วัดผ่าน QGIS จริง 157.5 -> 6.3 ms = เร็วขึ้น 25 เท่า และได้ผลลัพธ์เท่าเดิมทุกจุด
            #   ปลอดภัย: หมุดที่เราสนใจคือหมุดที่ทับ "มุมของแปลงที่แก้" ซึ่งอยู่ในกรอบแปลงเสมอ
            #   หมุด UTM เดียวกันที่อยู่นอกกรอบ ไม่มีทางทับมุมแปลงนั้นได้ -> ตัดทิ้งไม่กระทบคำตอบ
            #   ต้องใช้คู่กับ expression เสมอ (bbox อย่างเดียวจะกวาดหมุดแปลงอื่นมาด้วย)
            # ★ 2.4.0 (review PF-07) — ใช้แค่ UTM + รูปของหมุด ⇒ ไม่ดึงคอลัมน์อื่น
            req = (QgsFeatureRequest().setFilterExpression(expr)
                   .setSubsetOfAttributes([tu], point_lyr.fields()))
            try:
                bbox = QgsRectangle()
                for _f, (_u, _g) in polys.items():
                    if _g is not None and not _g.isNull() and not _g.isEmpty():
                        bbox.combineExtentWith(_g.boundingBox())
                # ★ ใช้ bbox เฉพาะตอนที่กรอบ "แคบพอ" เท่านั้น
                #   ถ้าแปลงที่แก้กระจายทั่วอำเภอ กรอบจะกว้างจน GiST คัดอะไรแทบไม่ได้ แล้วกลับช้ากว่าเดิม
                #   (วัดจริง: กรอบ 19 กม. -> 220 ms เทียบกับไม่ใช้ bbox 78 ms = แย่ลง 2.8 เท่า)
                #   ข้อมูลการบันทึกจริง 422 ครั้ง: กรอบเฉลี่ย 163 ม. / p95 625 ม. / สูงสุด 1,358 ม.
                #   -> เกณฑ์ 5 กม. เผื่อไว้เกือบ 4 เท่าของเคสแย่สุดที่เคยเกิดจริง
                if not bbox.isNull() and max(bbox.width(), bbox.height()) <= 5000.0:
                    bbox.grow(1.0)               # เผื่อ 1 เมตร กันปัดเศษที่ขอบกรอบ
                    req.setFilterRect(bbox)
            except Exception:
                pass                             # หา bbox ไม่ได้ -> ใช้ expression อย่างเดียวเหมือนเดิม
            mk = {}                              # {utm: [QgsPointXY ของหมุด]}
                                                 # ★ 28 ส.ค. 69 เก็บ "จำนวน" ไม่ใช่แค่ตำแหน่ง
                                                 #   เพราะกติกาคือ "1 node ต้องมี 1 หมุด" — หมุดซ้อนกันก็ผิด
                                                 # ★ 2.4.0 (review DU-02) เก็บทุกดวง (เดิมนับตามคีย์ round(x, 3) ที่ต้องตรงเป๊ะ)
                                                 #   แล้วนับด้วย `_corner_n` (= ค่าแรกของ `_corner_mark` ที่ไฮไลต์ Add Node ใช้ · ระยะชุดเดียวกัน)
            _n = 0
            _fit5233 = point_lyr.getFeatures(req)
            try:
                for f in _fit5233:
                    _n += 1
                    if (_n & 1023) == 0 and time.monotonic() - _t0 > budget:
                        return self._why('skip-budget')                  # เกินเพดานเวลา -> ข้ามการเตือน อย่าขวางการบันทึก
                    u = f[tu]; g = f.geometry()
                    if not _txt(u) or g is None or g.isEmpty():          # ★ 2.3.7 DI-08
                        continue
                    mk.setdefault(_norm_utm(u), []).append(QgsPointXY(g.asPoint()))
            finally:
                _fit5233.close()
            bad = 0; checked = 0; sample = []
            n_miss = n_stk = n_stray = 0          # ★ 2.3.7 (review UX-39) นับแยกชนิด (bad = ผลรวม — เงื่อนไขเตือนเดิม)
            bare, strays = {}, {}                # ★ 2.3.7 (review DI-48) utm -> [(x,y)] มุมเปลือย / จุดที่หมุดไม่อยู่บนมุม
            pts = []                             # ★ 2.4.0 (review UX-09) ทุกจุดที่นับใน bad (sample เก็บแค่ 5 บรรทัดแรก)
            vtx = {}                             # utm -> {(x,y) ปัดมิลลิเมตร: QgsPointXY} ของมุมแปลงที่กำลังจะบันทึก
            grids = {}                           # ★ 2.4.0 (DU-02) utm -> _กริดจุด ของหมุด (สร้างครั้งเดียวต่อ UTM)
            for _fid, (u, g) in polys.items():
                if g is None or g.isNull():
                    continue
                if time.monotonic() - _t0 > budget:
                    return self._why('skip-budget')                  # เกินเพดานเวลา -> ข้ามการเตือน
                S = grids.get(u)
                if S is None:
                    # ★ 2.4.0 (review DU-02) — ด่านนี้ดูแค่ ≤ 1 มม. ⇒ ช่องละ 2 มม. (_กริดจุด.นับ ดูไม่เกิน 2×2 ช่อง · เร็วกว่าช่อง 1 ซม. 3×3)
                    S = grids[u] = _กริดจุด(mk.get(u, ()), 2 * self._MK_AT_CORNER_TOL)
                V = vtx.setdefault(u, {})
                for v in g.vertices():
                    _k = (round(v.x(), 3), round(v.y(), 3))
                    # ★ 28 ส.ค. 69 ข้ามจุดที่นับไปแล้ว — วงแหวนของ polygon ปิดด้วยการซ้ำจุดแรก
                    #   ถ้าไม่ข้าม จุดแรกจะถูกนับสองครั้ง -> ตัวเลข "เสีย/ตรวจ" เฟ้อ และข้อความซ้ำ
                    if _k in V:
                        continue
                    V[_k] = QgsPointXY(v.x(), v.y())
                    checked += 1
                    _c = self._corner_n(S, V[_k])                    # ★ 2.4.0 (DU-02) หมุดบนมุม ≤ 1 มม. (นับอย่างเดียว)
                    if _c == 0:
                        bad += 1
                        n_miss += 1
                        bare.setdefault(u, []).append(_k)
                        pts.append(('bare', v.x(), v.y(), 'poly', u))           # ★ 2.4.0 (review UX-09)
                        if len(sample) < 5:
                            sample.append(f"มุมไม่มีหมุด — ระวาง/UTM {u} ที่ {v.x():.2f}, {v.y():.2f}")
                    elif _c > 1:
                        # ★ 28 ส.ค. 69 กติกาคือ "1 node : 1 หมุด" -> หมุดซ้อนกันหลายตัวที่มุมเดียวก็ผิด
                        #   (เกิดได้จากกด Add Node ซ้ำจุดเดิม หรือ import ซ้ำ)
                        bad += 1
                        n_stk += 1
                        pts.append(('stacked', v.x(), v.y(), 'poly', u))        # ★ 2.4.0 (review UX-09)
                        if len(sample) < 5:
                            sample.append(f"มุมมีหมุดซ้อนกัน {_c} ตัว — ระวาง/UTM {u} ที่ {v.x():.2f}, {v.y():.2f}")
            # ★ ตรวจอีกด้านของกติกาเหล็ก (2026-08-06): "หมุดต้องอยู่บนมุมแปลงของตัวเอง"
            #   เดิมตรวจทางเดียว (มุม->หมุด) จึงมองไม่เห็น "หมุดลอย" ที่ผู้ใช้เพิ่ง เพิ่ม/ย้าย ผิดที่
            #   ★ ตรวจเฉพาะหมุดที่แตะรอบนี้ (ไม่ใช่ทั้งชั้น) เพื่อไม่ให้ข้อมูลเก่าที่เสียอยู่แล้ว
            #     มาทำให้กล่องเตือนเด้งทุกครั้งจนคนเลิกอ่าน · ใช้ข้อมูลในหน่วยความจำ ไม่มีคิวรีเพิ่ม
            #   ★ 28 ส.ค. 69 เปลี่ยนเป็นตรวจ "รายแปลง" ให้ครบ (เจ้าของงานสั่ง):
            #     เดิมดูเฉพาะหมุดที่ผู้ใช้ "เพิ่ง เพิ่ม/ย้าย" ในรอบนี้ (touched_mk)
            #     -> **หมุดที่กลายเป็นลอยเพราะ "มุมถูกลบ" จึงหลุดด่านไปเงียบ ๆ**
            #        (จำลองยืนยัน 28 ส.ค.: ลบมุมด้วยเครื่องมือ Vertex ของ QGIS -> เหลือหมุดลอย 1 ตัว
            #         แต่ด่านรายงาน 0 · ตรงกับข้อมูลจริงที่ปฏิบัติการ "ลบ Node" หลุดคู่ 60-72%
            #         และมีหมุดลอยค้างในฐาน 525 ตัวที่คลองหลวง)
            #     ตอนนี้ตรวจหมุด "ทุกตัวของแปลงที่กำลังจะบันทึก" ว่าต้องนั่งอยู่บนมุมของแปลงตัวเอง
            #   ⚠️ ผลข้างเคียงที่ตั้งใจ: แปลงที่ข้อมูลเดิมเสียอยู่แล้ว จะถูกเตือนด้วยเมื่อไปแตะมัน
            #      (เดิมตั้งใจเงียบเพื่อลด noise — เจ้าของงานเลือกให้เข้มขึ้นเพราะกติกาเป็นข้อบังคับ)
            #   ขอบเขต: เฉพาะหมุดที่อยู่ในกรอบพื้นที่ที่ดึงมาแล้ว (ไม่มีคิวรีเพิ่ม ไม่กระทบความเร็ว)
            #   ★ 2.4.0 (review DU-02) — "บนมุม" = ห่างมุมใดมุมหนึ่งของ UTM เดียวกันไม่เกิน _MK_AT_CORNER_TOL (ค่าเดียวกับด้านมุม→หมุด)
            #     เดิมเทียบคีย์ round(x, 3) ตรงเป๊ะ · ยังนับ/รายงานทีละจุดปัดมิลลิเมตรเหมือนเดิม (หมุดซ้อนที่ลอยนับเป็นจุดเดียว)
            for u, V in vtx.items():
                if time.monotonic() - _t0 > budget:
                    return self._why('skip-budget')
                VG = _กริดจุด(V.values(), 2 * self._MK_AT_CORNER_TOL)
                _seen = set()
                for m in mk.get(u, ()):
                    if VG.นับ(m, self._MK_AT_CORNER_TOL):
                        continue
                    mx, my = round(m.x(), 3), round(m.y(), 3)
                    if (mx, my) in _seen:
                        continue
                    _seen.add((mx, my))
                    bad += 1
                    n_stray += 1
                    strays.setdefault(u, []).append((mx, my))
                    pts.append(('stray', mx, my, 'point', u))                   # ★ 2.4.0 (review UX-09)
                    if len(sample) < 5:
                        sample.append(
                            f"หมุดไม่อยู่บนมุมแปลง — ระวาง/UTM {u} ที่ {mx:.2f}, {my:.2f}")
            # ★ 2.3.7 (review DI-48) — มุมเปลือยที่มี "หมุดของแปลงเดียวกัน" ลอยอยู่ใกล้ = หมุดของมุมนั้นเพี้ยนไป
            #   (มีคนอื่นบันทึกก่อน / ย้ายแปลงหรือหมุดไม่ครบคู่) ⇒ คำแนะนำต้องเป็น Move Node / ↺ ไม่ใช่ Add Node
            #   (Add Node ตรงมุมที่ไม่มีหมุดของตัวเองใน 1 ซม. จะเพิ่มหมุดอีกดวง ⇒ บันทึกครั้งหน้าเตือนซ้ำ)
            near, near_utms = 0, []
            _r2 = float(self._PAIR_NEAR_M) ** 2
            for u, bl in bare.items():
                sl = strays.get(u)
                if not sl or time.monotonic() - _t0 > budget:
                    continue
                if len(bl) * len(sl) > 200000:          # ทั้งแปลงเลื่อน (คู่มากเกินไล่) ⇒ ถือว่าใกล้
                    near += len(bl)
                    near_utms.append(u)
                    continue
                hit = sum(1 for (bx, by) in bl
                          if any((bx - sx) ** 2 + (by - sy) ** 2 <= _r2 for (sx, sy) in sl))
                if hit:
                    near += hit
                    near_utms.append(u)
            if n_orph:
                bad += n_orph
                sample.append(_orph_line)
            if n_nokey and bad:
                sample.append(f"(มีแปลงที่แก้แต่ไม่มีค่า UTM อีก {n_nokey:,} แปลง — ตรวจคู่หมุดไม่ได้ ตรวจด้วยตาเอง)")
            return _done(bad, checked, sample,
                         dict(missing=n_miss, stacked=n_stk, stray=n_stray, near=near, near_utms=near_utms), pts)
        except Exception as e:
            self._pairing_last_err = repr(e)[:300]   # ★ 2.3.7 (review ER-01) string เท่านั้น
            return self._why('skip-error')       # ตรวจไม่ได้ -> อย่าไปขวางการบันทึก

    def _marker_exists_here(self, point_lyr, poly_feat, xy, utm_fields, tol=None):
        """แปลงนี้มีหมุดของตัวเองอยู่ที่พิกัดนี้แล้วหรือยัง (ใช้กัน Add Node สร้างหมุดซ้อน)
        เทียบด้วย "ระวางเดียวกัน + อยู่ในระยะ tol" — ไม่ใช่แค่ตำแหน่ง เพราะมุมร่วมของแปลงข้างเคียง
        ต้องมีหมุดของตัวเองได้ (คนละ UTM = คนละหมุด ถือว่าไม่ซ้ำ)
        ★ 2.4.0 (review DU-02) — tol ปริยาย = `_MK_WELD_TOL` (1 ซม. เท่าเดิม · ค่าคงที่ชุดเดียวกับไฮไลต์และด่านก่อนบันทึก)"""
        tol = self._MK_WELD_TOL if tol is None else tol
        try:
            # 🔧 9 ก.ย. 69 — utm_fields เป็น "ชื่อคงที่" (UTMMAP1..) ⇒ indexOf ไวต่อตัวพิมพ์
            #   ถ้าชั้นข้อมูลใช้ตัวพิมพ์เล็ก key จะว่าง -> return False -> **ด่านกันหมุดซ้อนเปิดโล่ง**
            key = [f for f in utm_fields
                   if _fld_idx(point_lyr.fields(), f) >= 0 and _fld_idx(poly_feat.fields(), f) >= 0]
            if not key:
                return False                      # ไม่มีคีย์ให้เทียบ -> อย่าไปขวางการเพิ่ม
            rect = QgsRectangle(xy.x() - tol, xy.y() - tol, xy.x() + tol, xy.y() + tol)
            req = QgsFeatureRequest().setFilterRect(rect)
            _fit5664 = point_lyr.getFeatures(req)
            try:
                for f in _fit5664:
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    if g.asPoint().distance(xy) > tol:
                        continue
                    if all(str(f[k] or "") == str(poly_feat[k] or "") for k in key):
                        return True
            finally:
                _fit5664.close()
        except Exception:
            # ★ 2.3.7 (review ER-03) — ผลเหมือนเดิม (ถือว่ายังไม่มีหมุด ⇒ Add Node สร้างหมุด) แต่ต้องทิ้งร่องรอยไว้
            #   (ถ้าด่านนี้ล้มจริง จะได้หมุดซ้อน — ด่านก่อนบันทึกเตือน 'มุมแปลงที่มีหมุดซ้อนกัน' อีกชั้น)
            _log_exc("Add Node (_marker_exists_here): ตรวจหมุดเดิมที่จุดนี้ไม่ได้ — ถือว่ายังไม่มี")
            return False                          # เช็คไม่ได้ -> ทำงานเหมือนเดิม
        return False

    def _own_unnamed_markers_here(self, point_lyr, poly_feat, xy, utm_fields, name_field, tol=None, poly_lyr=None,
                                  ล็อก_out=None):
        """★ 2.3.9 — gid ของหมุด "ของแปลงนี้" (ระวางตรง · ≤ tol) ที่จุดนี้ซึ่ง **ชื่อว่าง** · ตรวจไม่ได้/ไม่มีคอลัมน์ชื่อ = []
        เกณฑ์เดียวกับ `_marker_exists_here` (ใช้ต่อจากมันในสาขา 'exists' ของ Add Node)
        ★ 2.4.0 (review DU-01) — ไม่เสนอหมุดที่ล็อก (_marker_locked: Type ของหมุด หรือ UTM ตรงแปลง L1 · poly_lyr = ใช้ตารางของชั้นนี้)
          เดิม Add Node ตั้งชื่อหมุด L1 ที่ชื่อว่างได้ ทั้งที่ปุ่มแก้ชื่อหมุดปฏิเสธ · สแกนตารางล็อกไม่สำเร็จ = ไม่เสนอเลย (fail-closed)
          ★ 2.4.0 (review DU-01 รอบตรวจทาน) ล็อก_out (ลิสต์) = gid ของหมุดชื่อว่างที่ถูกตัดเพราะล็อก ⇒ แถบสรุปบอกเหตุได้ตรง"""
        tol = self._MK_WELD_TOL if tol is None else tol        # ★ 2.4.0 (review DU-02) ค่าคงที่ชุดเดียวกับ _marker_exists_here
        if name_field is None:
            return []
        _lm = {}
        if poly_lyr is not None and not self._l1_unlocked():
            try:
                _lm = self._locked_utm_map(poly_lyr)
            except _LockScanError:
                return []
        try:
            key = [f for f in utm_fields
                   if _fld_idx(point_lyr.fields(), f) >= 0 and _fld_idx(poly_feat.fields(), f) >= 0]
            if not key:
                return []
            out = []
            rect = QgsRectangle(xy.x() - tol, xy.y() - tol, xy.x() + tol, xy.y() + tol)
            _it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect))
            try:
                for f in _it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or g.asPoint().distance(xy) > tol:
                        continue
                    if all(str(f[k] or "") == str(poly_feat[k] or "") for k in key) and not _txt(f[name_field]):
                        if self._marker_locked(f, _lm)[0]:
                            if ล็อก_out is not None:
                                ล็อก_out.append(f.id())
                            continue          # ★ 2.4.0 (DU-01) หมุดล็อก L1 — ตั้งชื่อไม่ได้ (แบบปุ่มแก้ชื่อหมุด)
                        out.append(f.id())
            finally:
                _it.close()
            return out
        except Exception:
            _log_exc("Add Node (_own_unnamed_markers_here): ตรวจชื่อหมุดเดิมไม่ได้ — ถือว่าไม่มีหมุดชื่อว่าง")
            return []

    def _corner_n(self, grid, q):
        """★ 2.4.0 (review DU-02) — จำนวนหมุดใน grid ที่ห่างมุม q ไม่เกิน `_MK_AT_CORNER_TOL` (หมุดบนมุม)
        นับอย่างเดียว ไม่เรียง ไม่ดูระยะเยื้อง ⇒ ด่านก่อนบันทึกใช้ตัวนี้ (ทุกมุมของทุกแปลงที่แก้ · ต้องเร็ว)
        grid = `_กริดจุด` ช่องขนาดใดก็ได้ (ด่านก่อนบันทึกใช้ 2 มม. · ไฮไลต์ใช้ `_MK_WELD_TOL`)"""
        return grid.นับ(q, self._MK_AT_CORNER_TOL)

    def _corner_mark(self, grid, q):
        """★ 2.4.0 (review DU-02) — เพรดิเคตเดียวของ "หมุดของแปลงนี้ที่มุมนี้" (ระยะ · คีย์ "ของแปลงนี้" ผู้เรียกกรองเอง)
        grid = `_กริดจุด` ของหมุดแปลงเดียวกัน (ช่องละ `_MK_WELD_TOL`) · q = มุม (CRS เดียวกับ grid)
        คืน (จำนวนหมุดบนมุม ≤ 1 มม., เยื้อง) · เยื้อง = ไม่มีหมุดบนมุม แต่มีหมุดของแปลงนี้ห่างไม่เกิน 1 ซม.
        ด่านก่อนบันทึก (_corner_n = ค่าแรก): 0 = มุมไม่มีหมุด · > 1 = หมุดซ้อน
        ไฮไลต์: 0 + ไม่เยื้อง = กากบาทเขียว · 0 + เยื้อง = หมุดเยื้องมุม"""
        n = self._corner_n(grid, q)
        return n, (n == 0 and grid.มี(q, self._MK_WELD_TOL))

    def _ring_points(self, geom):
        """คืน [[QgsPointXY,...], ...] ทีละวง โดย **ตัดจุดปิดวงออกแล้ว**

        🔴 ทุกวงปิดด้วยการซ้ำจุดแรก — ถ้าไม่ตัดออกจะนับเป็น "มุมซ้อน" ทุกแปลง
           (กับดักเดียวกับที่ตัวตรวจเชิงพื้นที่ต้องลบ ST_NRings ออกก่อน)
        """
        rings = []
        try:
            if geom.isMultipart():
                for poly in geom.asMultiPolygon():
                    rings.extend(poly)
            else:
                rings.extend(geom.asPolygon())
        except Exception:
            return []
        out = []
        for r in rings:
            if len(r) > 1 and abs(r[0].x() - r[-1].x()) < 1e-9 and abs(r[0].y() - r[-1].y()) < 1e-9:
                r = r[:-1]
            out.append(r)
        return out

    def _dup_vertex_nrs(self, geom, pt, tol=None):
        """เลข vertex (global) ของมุมที่อยู่ที่พิกัด `pt` **ในวงเดียวกับมุมที่คลิก**

        คืนลิสต์เรียงตามเลข vertex · len() > 1 = มุมซ้อนกันจริงในวงนั้น

        🔴🔴 18 ก.ย. 69 — ผู้ตรวจ Windows จับได้ว่ารุ่นแรกไล่ `geom.vertices()` **ทั้งก้อน**
           คีย์ `(part, ring, idx)` กันคีย์ชนกันก็จริง แต่ผลลัพธ์ถูกรวมเป็นลิสต์เดียว
           ⇒ มุมของ **คนละวง / คนละ part** ที่บังเอิญอยู่พิกัดเดียวกัน ถูกนับเป็น "ซ้อนกัน"
           แล้ว `_delete_dup_vertex` ลบ `dups[-1]` ทิ้ง ⇒ **รูปแปลงเปลี่ยนจริง**
           ทั้งที่กล่องยืนยันบอกว่า "รูปแปลงและเนื้อที่ไม่เปลี่ยน"
           วัดซ้ำเองแล้ว: multipart สองส่วนแตะกันที่มุมเดียว **4,100 -> 3,300 ตร.ม. (หาย 800)**
           🔑 และมันใช้ **คนละเกณฑ์กับ `_stacked_points`** (ตัววาดกรอบม่วง) ซึ่งนับแยกต่อวงอยู่แล้ว
              ⇒ ไฮไลต์บอกว่าไม่มีของซ้อน แต่ถ้าบังเอิญคลิกมุมนั้น ปุ่มกลับทำงาน
        ⇒ รับเฉพาะมุมที่อยู่ **(part, ring) เดียวกับมุมที่คลิก** เท่านั้น
          ถ้าระบุวงของมุมที่คลิกไม่ได้ ให้คืนลิสต์ว่าง (ปฏิเสธ) — ปลอดภัยกว่าเดาแล้วลบผิด
        """
        tol = self._DUP_TOL if tol is None else tol
        out, seen = [], set()
        try:
            # ① วงของ "มุมที่คลิก" คือวงเดียวที่อนุญาต
            home = None
            cv = geom.closestVertex(pt)
            if cv[1] is not None and cv[1] >= 0:
                ok0, vid0 = geom.vertexIdFromVertexNr(cv[1])
                if ok0:
                    home = (vid0.part, vid0.ring)
            if home is None:
                return []
            i = 0
            for v in geom.vertices():
                if abs(v.x() - pt.x()) <= tol and abs(v.y() - pt.y()) <= tol:
                    ok, vid = geom.vertexIdFromVertexNr(i)
                    if not ok or (vid.part, vid.ring) != home:
                        i += 1
                        continue          # คนละวง = คนละมุม ไม่ใช่ของซ้อน
                    n = geom.constGet().vertexCount(vid.part, vid.ring)
                    # จุดแรกกับจุดปิดวงคือ "มุมเดียวกัน" -> ยุบให้เป็นคีย์เดียว
                    idx = 0 if vid.vertex in (0, n - 1) else vid.vertex
                    key = (vid.part, vid.ring, idx)
                    if key not in seen:
                        seen.add(key)
                        out.append(i)
                i += 1
        except Exception:
            return []
        return out

    def _marker_candidates(self, poly_lyr, point_lyr, poly_feat, xy, tol=0.05):
        """หมุด "ของแปลงนี้" ที่อยู่ในกรอบ ±tol รอบ xy — คืนลิสต์ dict (อาจว่าง)

        ★ 2.2.9 — แยกออกมาจาก `_admin_find_marker` เพื่อให้ตัวนับ "หมุดซ้อน" ใช้ชุดเดียวกันเป๊ะ
          (ไม่งั้นด่านตอนลบกับกล่องให้เลือก จะเห็นหมุดคนละชุด)
        """
        self._marker_l1_filtered = 0     # ★ 2.3.6 (audit) — ล้างก่อนทางออกทุกทาง ไม่ให้ค่าของคลิกก่อนค้าง
        # ★ 2.4.0 (review DU-01 รอบตรวจทาน) — ธงแยก "สแกนตารางล็อกไม่สำเร็จ" (แจ้งบนแถบแล้วใน _locked_map_or_block)
        #   เดิมผู้เรียกเห็นแค่ _marker_l1_filtered > 0 ⇒ ขึ้นข้อความซ้ำว่า "เป็นหมุดของแปลง L1" (เหตุผิด) · ลบ Node เรียกสองครั้ง
        #   ⇒ สแกนซ้ำ + แถบแดงสองแถบ ⇒ ผู้เรียกเห็นธงนี้แล้วหยุดเงียบ ๆ
        self._marker_lock_scan_failed = False
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        if not pu or not tu:
            return []
        target = _norm_utm(poly_feat[pu])
        rect = QgsRectangle(xy.x() - tol, xy.y() - tol, xy.x() + tol, xy.y() + tol)
        nfld = self._addnode_name_field(point_lyr)
        # ★★ 2.3.5 — **ด่านชนิดของ "ตัวหมุด" เอง** (ผู้ตรวจ Windows ยืนยันช่องนี้ 24 ก.ย. 69)
        #   เดิมคัดหมุดด้วยค่า `UTM` อย่างเดียว · ด่าน L1 ที่มีอยู่ดูชนิดของ **แปลง** ไม่ใช่ของหมุด
        #   ⇒ ถ้าแปลงที่ไม่ใช่ L1 มี `UTM` ตรงกับหมุด L1 (ไม่ต้องว่างก็เกิด — ผู้ตรวจพิสูจน์แล้ว)
        #     พนักงานธรรมดา **ลบ/เปลี่ยนชื่อหมุด L1-RTK/L1-TS ได้**
        #   วัดจากฐานจริง 24 ก.ย.: ค่า UTM ที่ใช้ร่วมกัน 42 ค่า · หมุด L1 ที่เข้าเงื่อนไข 203 ดวง
        #   (วันนี้ยังไม่มีใครใช้ช่องนี้ได้จริงเพราะไม่มีหมุดซ้อน — แต่จะเปิดทันทีที่นำเข้า L2-LM)
        #   ⇒ ปิดที่ต้นทางจุดเดียว **ครอบทั้งช่องใหม่ของ L2-LM และช่องเดิมที่มีมาตั้งแต่ 2.2.9**
        # ★★ 2.3.5 รอบ 2 — **ต้องบอกกลับว่ากรองไปกี่ดวง** (ผู้ตรวจ Windows ข้อ 4.1 · 24 ก.ย. 69)
        #   2.3.5 ใช้วิธี "กรองออก" ⇒ ในสายตาโค้ดคือ "ไม่มีหมุดตรงนี้" ไม่ใช่ "ห้ามทำ"
        #   ⇒ เส้นทางที่เหลือเดินต่อ: ลบมุมแปลงไปแล้วหมุดค้าง = **หมุดกำพร้า** ขัดกติกาเหล็กของเราเอง
        #     (วัดจริง: มุม 5→4 · หมุด 4→4 · กล่องเขียนว่า "หมุดที่จะลบด้วย: ไม่มี" เหมือนกรณีปกติ)
        #   ⇒ 2.3.5 รอบ 2 จดไว้ที่ `self._marker_l1_filtered` ให้ผู้เรียก **ปฏิเสธทั้งการกระทำ**
        self._marker_l1_filtered = 0
        tt = self._field_index(point_lyr.fields(), 'type')
        ปลดล็อก = self._l1_unlocked()
        # ★ 2.4.0 (review DU-01) — กติกาเดียวกับ Move/Score/Move Node/Align (_marker_locked):
        #   Type ของหมุดเอง **หรือ** UTM ตรงกับแปลง L1 (ตาราง _locked_utm_map — cache ทั้ง session · อ่านเมื่อเจอหมุดดวงแรก)
        #   สแกนตารางล็อกไม่สำเร็จ ⇒ ถือว่าหมุดทุกดวงล็อก (fail-closed · แจ้งเหตุบนแถบแล้ว)
        _lm = []                      # [ตาราง] หลังอ่านแล้ว (None = สแกนไม่สำเร็จ)
        out = []
        for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            if _norm_utm(f[tu]) != target:
                continue
            if not ปลดล็อก:
                if not _lm:
                    _lm.append(self._locked_map_or_block(poly_lyr, "MLEP Lock"))
                    if _lm[0] is None:
                        self._marker_lock_scan_failed = True     # ★ 2.4.0 (review DU-01)
                if _lm[0] is None or self._marker_locked(f, _lm[0], tu, tt)[0]:
                    self._marker_l1_filtered += 1
                    continue          # หมุด L1 — แตะได้ต่อเมื่อเปิดโหมดผู้ดูแลแล้วกดปลดล็อก
            nm = _txt(f[nfld]) if nfld else ""
            out.append({'id': f.id(), 'name': (nm or "ไม่มีชื่อ"), 'nm': nm, 'utm': target,
                        'feature': f, 'layer_type': 'point'})
        return out

    def _bare_nodes(self, poly_lyr, point_lyr, poly_feat, offset_out=None):
        """มุมของแปลงนี้ที่ **ยังไม่มีหมุดของแปลงตัวเอง** -> [QgsPointXY ใน CRS ชั้นแปลง]
        ★ 2.4.0 (review DU-02) — เพรดิเคตเดียวกับด่านก่อนบันทึก (`_corner_mark`): ส่ง list มาที่ `offset_out`
          ⇒ เติม "มุมที่หมุดของแปลงเยื้อง 1 มม.–1 ซม." (ด่านก่อนบันทึกเตือนว่ามุมไม่มีหมุด แต่ Add Node ไม่สร้างหมุดซ้ำ
          ⇒ ต้องใช้ Move Node) · ค่าที่คืน (กากบาทเขียว) = มุมที่ไม่มีหมุดของแปลงในระยะ 1 ซม. เหมือนเดิม
          ⇒ ค่าที่คืน + offset_out = มุมที่ด่านก่อนบันทึกนับว่า "มุมไม่มีหมุด" พอดี **เมื่อหมุดตรงแปลงทุกฟิลด์ระวาง**
          ⚠️ (review DU-02) ระยะชุดเดียวกัน แต่คีย์ "หมุดของแปลงนี้" ยังต่าง: ด่านก่อนบันทึกจับกลุ่มด้วย UTM อย่างเดียว
             ส่วนตรงนี้ (= `_marker_exists_here`) เทียบ 7 ฟิลด์ระวาง ⇒ หมุดเยื้องที่ LANDNO/UTMMAP ฯลฯ ไม่ตรงแปลง
             ด่านนับเป็นมุมไม่มีหมุด + หมุดลอย แต่ตรงนี้เป็นกากบาทเขียว (Add Node จะสร้างหมุดใหม่ หมุดเยื้องยังค้าง) — ยังไม่แก้

        ★ 2.2.9 — เจ้าของงานสั่ง: "ปุ่ม Add Node ให้ไฮไลต์มุมที่ไม่มีหมุดบน node ด้วย
          เวลาคลิกแปลง" ⇒ พนักงานเห็นทันทีว่าต้องไปเติมหมุดตรงไหน
        🔑 เกณฑ์ต้องตรงกับ `_marker_exists_here` **เป๊ะ** (ตัวที่ Add Node ใช้กันหมุดซ้อน)
           = ระวางเดียวกันทุกฟิลด์คีย์ + ระยะ ≤ 1 ซม. — ถ้าคนละเกณฑ์ ไฮไลต์จะชี้จุดที่กดแล้วไม่เกิดอะไร
        🔴🔴 17 ก.ย. — ผู้ตรวจ Windows วัดบนฐานจริง: รุ่นแรกเรียก `_marker_exists_here` **ทีละมุม**
           = **ยิงคิวรีหนึ่งครั้งต่อหนึ่งมุม** (20 มุม -> 20 · 600 มุม -> 600 · ยืนยันซ้ำเองแล้ว)
           แปลง `gid 162464` 1,407 มุม **ค้าง 2.3-2.7 วินาทีทุกครั้งที่คลิกเลือกแปลง** ไม่ขึ้นกับการซูม
           ⇒ เปลี่ยนเป็น **คิวรีเดียว** ด้วยกรอบของทุกมุม แล้วเทียบในหน่วยความจำด้วยตารางแฮชช่องละ 1 ซม.
           (แบบเดียวกับ `_stacked_points` และ `_movenodes_stack_ok` ของ 2.2.6)
           ถ้าทางเร็วพังด้วยเหตุใดก็ตาม ⇒ ถอยไปวิธีเดิมทีละมุม ⇒ **ผลเหมือนเดิมเสมอ**
        🔑 อ่านอย่างเดียว ไม่แตะข้อมูล
        """
        out = []
        geom = poly_feat.geometry()
        if geom is None or geom.isEmpty():
            return out
        utm_fields = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO", "UTM"]
        to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), QgsProject.instance())
                 if poly_lyr.crs() != point_lyr.crs() else None)
        # ① มุมไม่ซ้ำของแปลง (CRS ชั้นแปลง) + พิกัดใน CRS ชั้นหมุด
        verts, seen = [], set()
        for ring in self._ring_points(geom):
            for p in ring:
                k = (round(p.x() / self._DUP_TOL), round(p.y() / self._DUP_TOL))
                if k in seen:
                    continue
                seen.add(k)
                q = p
                if to_pt is not None:
                    try:
                        q = to_pt.transform(p)
                    except Exception:
                        continue            # วิธีเดิมก็ข้ามมุมนี้เหมือนกัน
                verts.append((QgsPointXY(p), QgsPointXY(q)))
        if not verts:
            return out
        TOL = self._MK_WELD_TOL             # = ค่าปริยายของ `_marker_exists_here` (★ 2.4.0 DU-02 ค่าคงที่ชุดเดียว)
        try:
            key = [f for f in utm_fields
                   if _fld_idx(point_lyr.fields(), f) >= 0 and _fld_idx(poly_feat.fields(), f) >= 0]
            if not key:
                # `_marker_exists_here` คืน False เมื่อไม่มีคีย์ -> ทุกมุมถือว่าไม่มีหมุด
                return [p for p, _q in verts]
            want = [str(poly_feat[k] or "") for k in key]
            xs = [q.x() for _p, q in verts]
            ys = [q.y() for _p, q in verts]
            rect = QgsRectangle(min(xs) - TOL, min(ys) - TOL, max(xs) + TOL, max(ys) + TOL)
            mks = []
            _fitbare = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect))
            try:
                for f in _fitbare:
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    if [str(f[k] or "") for k in key] != want:
                        continue
                    mks.append(QgsPointXY(g.asPoint()))
            finally:
                _fitbare.close()
            # ★ 2.4.0 (review DU-02) — ตาราง + เพรดิเคตชุดเดียวกับด่านก่อนบันทึก (เดิมเขียนลูป 3×3 เองที่ 1 ซม. อย่างเดียว)
            grid = _กริดจุด(mks, TOL)
            off = []
            for p, q in verts:
                n_at, เยื้อง = self._corner_mark(grid, q)
                if n_at:
                    continue
                (off if เยื้อง else out).append(p)
            if offset_out is not None:
                offset_out.extend(off)
            return out
        except Exception as e:
            # ทางถอย: วิธีเดิมทีละมุม (ช้าแต่ผลเหมือนเดิมแน่นอน)
            # ★ 2.3.0 — เดิมเงียบสนิท: ถ้าทางเร็วพัง "ทุกครั้ง" ผู้ใช้จะเจอความช้าเดิม
            #   โดยไม่มีใครรู้สาเหตุ (ข้อเสนอจากผู้ตรวจฝั่ง Windows)
            QgsMessageLog.logMessage(
                "_bare_nodes: ทางเร็วล้ม ใช้ทางถอยทีละมุม — %s" % e, "MLEP", Qgis.Warning)
            out = []
            for p, q in verts:
                if not self._marker_exists_here(point_lyr, poly_feat, q, utm_fields):
                    out.append(p)
                elif offset_out is not None and not self._marker_exists_here(      # ★ 2.4.0 (DU-02) หมุดเยื้องมุม
                        point_lyr, poly_feat, q, utm_fields, tol=self._MK_AT_CORNER_TOL):
                    offset_out.append(p)
            return out

    def _stacked_points(self, poly_lyr, point_lyr, poly_feat):
        """จุดที่ "ซ้อนกัน" ในแปลงนี้ -> [(QgsPointXY ใน CRS ชั้นแปลง, 'marker'|'node')]

        ★ 2.2.9 — ใช้ไฮไลต์ให้พนักงานเห็นว่าต้องไปคลิกตรงไหน (เจ้าของงานสั่ง)
        🔑 อ่านอย่างเดียว · ไม่แก้ข้อมูลใด ๆ
        """
        res = []
        geom = poly_feat.geometry()
        if geom is None or geom.isEmpty():
            return res
        # ★ 2.3.7 (review DI-32) — เกณฑ์เดียวกับปุ่มลบ (ทางพนักงาน) เป๊ะ: "ห่างกันไม่เกิน 1 มม. ต่อแกน"
        #   เดิมจัดถังด้วยการปัดเศษ (round) ⇒ คู่ที่ห่างกัน 0.2 มม. แต่คร่อมเส้นแบ่งถังถูกแยกเป็นคนละถัง (ไม่ไฮไลต์ ทั้งที่คลิกแล้วทำงาน)
        #   ⇒ ตารางแฮชช่องละ 2 มม. + ดูช่องข้างเคียง แล้วเทียบระยะจริง (คู่ที่ ≤ 1 มม. ต่อแกน อยู่ช่องติดกันเสมอ)
        T = self._DUP_TOL
        C = 2 * T

        def _ช่อง(q):
            return (math.floor(q.x() / C), math.floor(q.y() / C))

        def _ใกล้(grid, pts, q):
            cx, cy = _ช่อง(q)
            return [j for dx in (-1, 0, 1) for dy in (-1, 0, 1) for j in grid.get((cx + dx, cy + dy), ())
                    if abs(pts[j].x() - q.x()) <= T and abs(pts[j].y() - q.y()) <= T]
        rings = self._ring_points(geom)
        # ── node ซ้อน: มุมของวงเดียวกันที่ห่างกันไม่เกิน 1 มม. ต่อแกน (ตัดจุดปิดวงออกแล้ว · เกณฑ์ของ `_dup_vertex_nrs`) ──
        for ring in rings:
            grid = {}
            for i, q in enumerate(ring):
                grid.setdefault(_ช่อง(q), []).append(i)
            done = set()
            for i, q in enumerate(ring):
                if i in done:
                    continue
                near = [j for j in _ใกล้(grid, ring, q) if j != i]
                if near:
                    done.add(i)
                    done.update(near)
                    res.append((QgsPointXY(q), 'node'))
        # ── หมุดซ้อน: หมุด "ของแปลงนี้" ≥ 2 ดวง ห่าง **มุมของแปลง** ไม่เกิน 1 มม. ต่อแกน (ทางลัดหมุดซ้อนของพนักงาน) ──
        #   ★ 2.3.7 (review DI-32) — เดิมนับหมุดที่ทับกันเองที่ไหนก็ได้ในกรอบแปลง ไม่สนว่าอยู่บนมุมไหม
        #   ★ 2.4.0 (review DU-02) — ตั้งใจใช้ "≤ 1 มม. ต่อแกน" (กรอบ) ไม่ใช่ระยะตรง ≤ 1 มม. ของด่านก่อนบันทึก (_corner_n)
        #     เพราะต้องตรงกับทางลัดลบหมุดซ้อนของพนักงาน (เจ้าของงานคงพฤติกรรม DI-14) ⇒ หมุดที่สองห่าง (0.9, 0.9) มม.
        #     ไฮไลต์เป็น "หมุดซ้อน" (คลิกแล้วลบได้ = แก้คำเตือนได้) แต่ด่านก่อนบันทึกรายงานเป็น "หมุดไม่อยู่บนมุม" (1.27 มม.)
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        if tu and pu:
            target = _norm_utm(poly_feat[pu])
            to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(),
                                              QgsProject.instance())
                       if poly_lyr.crs() != point_lyr.crs() else None)
            bb = geom.boundingBox()
            if to_poly is not None:
                try:
                    bb = QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(),
                                                QgsProject.instance()).transformBoundingBox(bb)
                except Exception:
                    pass
            bb.grow(0.5)
            # ★★ 2.3.5 รอบ 2 — ไฮไลต์ต้องใช้ตัวกรองชุดเดียวกับการกระทำ (ผู้ตรวจ Windows ข้อ 4.3)
            #   2.3.5 ตัวนี้ยังคัดด้วย UTM อย่างเดียว ⇒ ไฮไลต์ว่า "มีหมุดซ้อน" แต่คลิกแล้วไม่มีอะไรเกิดขึ้น
            _tt = self._field_index(point_lyr.fields(), 'type')
            _ปลด = self._l1_unlocked()
            # ★ 2.4.0 (review DU-01) — กติกาเดียวกับการกระทำ (_marker_candidates → _marker_locked): Type ของหมุด หรือ UTM ตรงแปลง L1
            #   สแกนตารางล็อกไม่สำเร็จ ⇒ ไม่ไฮไลต์หมุดซ้อน (เงียบ · เป็นแค่ตัวช่วยมอง · การกระทำเองก็ปฏิเสธ)
            _lm = {}
            if not _ปลด:
                try:
                    _lm = self._locked_utm_map(poly_lyr)
                except _LockScanError:
                    _lm = None
            _หมุด = []
            for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(bb)):
                if _norm_utm(f[tu]) != target:
                    continue
                if not _ปลด and (_lm is None or self._marker_locked(f, _lm, tu, _tt)[0]):
                    continue          # หมุด L1 — การกระทำแตะไม่ได้ ไฮไลต์ก็ต้องไม่ชี้
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                p = g.asPoint()
                if to_poly is not None:
                    try:
                        p = to_poly.transform(p)
                    except Exception:
                        continue
                _หมุด.append(QgsPointXY(p))
            if len(_หมุด) > 1:
                grid = {}
                for j, q in enumerate(_หมุด):
                    grid.setdefault(_ช่อง(q), []).append(j)
                _แล้ว = set()
                for ring in rings:
                    for v in ring:
                        near = _ใกล้(grid, _หมุด, v)
                        if len(near) > 1 and frozenset(near) not in _แล้ว:
                            _แล้ว.add(frozenset(near))
                            res.append((QgsPointXY(v), 'marker'))
        return res

    def _marker_name_dups(self, poly_lyr, point_lyr, pf, name, skip_fid):
        """★ 2.3.7 (review DI-49) — gid ของหมุดอื่น "ของแปลงนี้" (UTM เดียวกัน · ในกรอบแปลง ±0.5 ม.) ที่ชื่อตรงกับ name
        ใช้เตือนก่อนตั้งชื่อซ้ำ (แก้ชื่อหมุด · Add Node ใช้ต่อได้) · คีย์ว่าง/ตรวจไม่ได้ ⇒ [] (แค่เตือน ไม่ได้กันข้อมูลพัง) · อ่านอย่างเดียว"""
        try:
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            nf = self._addnode_name_field(point_lyr)
            if not pu or not tu or nf is None or not _txt(pf[pu]) or not name:
                return []
            target = _norm_utm(pf[pu])
            bb = QgsRectangle(pf.geometry().boundingBox())
            if poly_lyr.crs() != point_lyr.crs():
                bb = QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(),
                                            QgsProject.instance()).transformBoundingBox(bb)
            bb.grow(0.5)
            req = QgsFeatureRequest().setFilterRect(bb).setSubsetOfAttributes([tu, nf], point_lyr.fields())
            out = []
            it = point_lyr.getFeatures(req)
            try:
                for f in it:
                    if f.id() != skip_fid and _norm_utm(f[tu]) == target and _txt(f[nf]) == name:
                        out.append(f.id())
            finally:
                it.close()
            return out
        except Exception as e:
            QgsMessageLog.logMessage("_marker_name_dups: ตรวจชื่อซ้ำไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            return []

    def _corner_neighbours(self, poly_lyr, pf, fid, pts, tol=0.01):
        """★ 2.3.7 (review DI-51) — แปลงข้างเคียงที่ใช้มุมนี้ร่วม = แปลงอื่น (ไม่นับแปลงนี้และแปลงแฝด UTM เดียวกัน) ที่มีมุม
        ห่างจุดใน pts ไม่เกิน tol ต่อแกน -> (จำนวน, จำนวนที่เป็น L1) · ตรวจไม่ได้ -> None
        🔑 อ่านอย่างเดียว — ลบ Node แก้เฉพาะแปลงนี้ (กติกาเจ้าของงาน) ไม่แตะแปลงข้างเคียง แค่บอกให้รู้ก่อนยืนยัน"""
        try:
            pts = [QgsPointXY(q) for q in pts]
            if not pts:
                return (0, 0)
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            mine = _norm_utm(pf[pu]) if pu else None
            r = QgsRectangle(min(q.x() for q in pts) - tol, min(q.y() for q in pts) - tol,
                             max(q.x() for q in pts) + tol, max(q.y() for q in pts) + tol)
            n = n_l1 = 0
            it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r))
            try:
                for f in it:
                    if f.id() == fid or (pu and _norm_utm(f[pu]) == mine):
                        continue
                    g = f.geometry()
                    if g is None or g.isEmpty():
                        continue
                    if any(abs(v.x() - q.x()) <= tol and abs(v.y() - q.y()) <= tol for v in g.vertices() for q in pts):
                        n += 1
                        if self._poly_type_str(poly_lyr, f) in L1_TYPES:      # ★ 2.4.0 (DU-01) lock_rules
                            n_l1 += 1
            finally:
                it.close()
            return (n, n_l1)
        except Exception as e:
            QgsMessageLog.logMessage("_corner_neighbours: ตรวจไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            return None

    def _twin_vertices(self, poly_lyr, pf, fid, pts, pad=0.01):
        """★ 2.3.7 — มุมของแปลงที่ใช้ UTM เดียวกัน (แปลงแฝด) ในกรอบรอบจุด pts ±pad (CRS ชั้นแปลง) ให้ `_delnode_iron_after`
        (หมุดที่อยู่บนมุมแปลงแฝดไม่ใช่หมุดหลุดมุม — ★ รอบ 9e) · แยกจากโค้ดในตัวของ `_delete_dup_vertex` เพื่อใช้กับทางลัดหมุดซ้อนด้วย
        ล้ม ⇒ ส่ง exception ให้ผู้เรียก (ผู้เรียกขึ้นบรรทัด "ตรวจไม่ได้")"""
        out = []
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        if not pu or not pts:
            return out
        k = _norm_utm(pf[pu])
        r = QgsRectangle(min(q.x() for q in pts) - pad, min(q.y() for q in pts) - pad,
                         max(q.x() for q in pts) + pad, max(q.y() for q in pts) + pad)
        it = poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r))
        try:
            for f in it:
                if f.id() == fid or _norm_utm(f[pu]) != k:
                    continue
                g = f.geometry()
                if g is not None and not g.isEmpty():
                    out.extend(QgsPointXY(v.x(), v.y()) for v in g.vertices())
        finally:
            it.close()
        return out

    def _dup_vertex_marked(self, poly_lyr, point_lyr, pf, pts, tol=0.001):
        """★ 2.3.7 (review DI-31) — มุมไหนในกองมุมซ้อน "มีหมุดของแปลงนี้อยู่" -> [bool,...] ตามลำดับ pts
        หมุด (UTM เดียวกัน) ที่ห่างกองไม่เกิน tol เป็นของ **มุมที่ใกล้ที่สุดในกอง** (มุมในกองห่างกันไม่ถึง 1 มม. ⇒ หมุดบนมุมหนึ่ง
        ก็อยู่ ≤ 1 มม. จากอีกมุมด้วย — นับทุกมุมที่ ≤ tol จะได้ "มีหมุดทุกมุม" แล้วเลือกตามหมุดไม่ได้) · ระยะเท่ากัน (มุมทับเป๊ะ) = ทุกมุม
        ใช้เลือกมุมที่ลบ (เก็บมุมที่หมุดอยู่) · คีย์ว่าง/ตรวจไม่ได้ -> None (ผู้เรียกใช้ทางเดิม: ตามเลข) · อ่านอย่างเดียว"""
        try:
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if not pu or not tu or not pts or not _txt(pf[pu]):
                return None
            target = _norm_utm(pf[pu])
            to_pt = (QgsCoordinateTransform(poly_lyr.crs(), point_lyr.crs(), QgsProject.instance())
                     if poly_lyr.crs() != point_lyr.crs() else None)
            qs = [to_pt.transform(q) if to_pt else QgsPointXY(q) for q in pts]
            r = QgsRectangle(min(q.x() for q in qs) - tol, min(q.y() for q in qs) - tol,
                             max(q.x() for q in qs) + tol, max(q.y() for q in qs) + tol)
            ms = []
            it = point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(r))
            try:
                for f in it:
                    g = f.geometry()
                    if g is None or g.isEmpty() or _norm_utm(f[tu]) != target:
                        continue
                    ms.append(QgsPointXY(g.asPoint()))
            finally:
                it.close()
            out = [False] * len(qs)
            for m in ms:
                d = [q.distance(m) for q in qs]
                if min(d) <= tol:
                    for i, di in enumerate(d):
                        if di <= min(d) + 1e-9:
                            out[i] = True
            return out
        except Exception as e:
            QgsMessageLog.logMessage("_dup_vertex_marked: ตรวจไม่ได้ — %s" % e, "MLEP", Qgis.Warning)
            return None

    @staticmethod
    def _neighbour_line(nb):
        """บรรทัดในกล่องยืนยันลบ Node จากผลของ `_corner_neighbours` ("" = ไม่มีแปลงข้างเคียงใช้มุมนี้)"""
        if nb is None:
            return "\n⚠️ ตรวจไม่ได้ว่ามุมนี้ใช้ร่วมกับแปลงข้างเคียงหรือไม่ — ตรวจเองก่อนยืนยัน"
        n, k = nb
        if not n:
            return ""
        return ("\n⚠️ มุมนี้ใช้ร่วมกับแปลงข้างเคียง %d แปลง%s — ลบแล้วจะเกิดช่องว่าง/ทับกับแปลงเหล่านั้น "
                "(แปลงข้างเคียงไม่ถูกแก้ตาม)" % (n, (" (เป็นแปลง L1 %d แปลง)" % k) if k else ""))
