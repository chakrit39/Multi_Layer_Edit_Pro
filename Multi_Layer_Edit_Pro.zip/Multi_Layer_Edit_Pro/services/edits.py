# -*- coding: utf-8 -*-
"""edit session: ติดตามการแก้ไข, Undo ของปลั๊กอิน, บันทึกทั้งคู่ชั้น และงานบันทึกครึ่งคู่

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import os
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import Qgis, QgsFeatureRequest, QgsMessageLog, QgsProject
from ..core.util import _log_exc, _norm_utm, _scrub, _txt, _UTM_FIELD_NAMES
from ..lock_rules import L1_TYPES
from ..ui.qt_helpers import _HALF_PROP, _half_rb_text, _half_save_orphans_pop


class EditsMixin:
    """edit session: ติดตามการแก้ไข, Undo ของปลั๊กอิน, บันทึกทั้งคู่ชั้น และงานบันทึกครึ่งคู่"""

    # ============ ระบบ Undo: นับ undo-command ต่อเลเยอร์ ต่อ operation ============
    def _watch_layer_editing(self, lyr):
        """ต่อ signal commit/rollback ของเลเยอร์ (ครั้งเดียวต่อเลเยอร์) เพื่อรู้ว่าตอนปิด edit
        กด Save (commit) หรือ Discard (rollback) — ใช้ตัดสินตอน undo เจอเลเยอร์ที่ถูกปิด"""
        if lyr is None:
            return
        lid = lyr.id()
        # ★ 31 ส.ค. 69 — เดิมกันซ้ำด้วย layer id อย่างเดียว ซึ่งพังเมื่อ "เปิดโปรเจกต์เดิม
        #   ซ้ำในเซสชันเดียว": QGIS ให้ layer id เดิมแต่เป็นวัตถุใหม่ signal เก่าตายไปกับ
        #   วัตถุเก่า แล้วโค้ดนี้ไม่ต่อใหม่เพราะเห็นว่า id ซ้ำ -> ด่าน "มุมแปลงไม่มีหมุด"
        #   และการเขียนล็อกเปลี่ยน Type ตายเงียบทั้งเซสชัน
        #   เทียบตัววัตถุด้วย จึงต่อใหม่เมื่อเป็นคนละวัตถุ
        # ★ 2.3.7 (review LC-02 · P1) — "ตัววัตถุ" เดิมเทียบด้วย id() ของ Python wrapper ซึ่งไม่คงที่:
        #   _arm_pair_watch ได้ wrapper ชั่วคราวจาก mapLayer() ทุกครั้งที่ชั้นในโปรเจกต์เพิ่ม/หาย/สลับคอมโบ
        #   ⇒ ต่อ slot ซ้อน (ผู้ตรวจวัดได้: ด่านก่อนบันทึกรัน 7 รอบต่อการกด Save ของ QGIS 1 ครั้ง)
        #   หรือ wrapper ใหม่ได้ address เดิม ⇒ ไม่ต่อเลย (ด่าน/ล็อก Type ตายเงียบ)
        #   ⇒ ทำเครื่องหมายบน "วัตถุ C++ ของเลเยอร์" เองด้วย dynamic property: ตายไปกับเลเยอร์ · ไม่ถูกเขียนลง .qgz
        #     · ปลั๊กอินที่โหลดใหม่ได้ token ใหม่จึงต่อเอง · เปิดโปรเจกต์เดิมซ้ำ = วัตถุใหม่ไม่มีเครื่องหมาย = ต่อใหม่ (คงการแก้ 31 ส.ค.)
        _tok = getattr(self, "_watch_token", None)
        try:
            if _tok and lyr.property("_mlep_watch") == _tok:
                return
            lyr.setProperty("_mlep_watch", _tok)
        except Exception:
            if self._signal_layers.get(lid) == id(lyr):
                return
            self._signal_layers[lid] = id(lyr)

        # cache ตาราง UTM ล็อก (_locked_utm_map) ล้างเฉพาะ on_fields (คอลัมน์เปลี่ยน) — ★ ไม่ล้างตอน commit/rollback/start
        #   (แก้ freeze ~1s หลังทุก Save · 2026-08-04): ชุดแปลงล็อก L1-RTK/L1-TS เปลี่ยนได้เฉพาะเมื่อคอลัมน์
        #   Type เปลี่ยน ซึ่งพนักงานแก้ไม่ได้ (GRANT เฉพาะ geom/SCORE/REMARK/cluster_id) -> cache ใช้ได้ทั้ง
        #   session · เดิมล้างทุก commit ทำให้ op ถัดไปดึงแปลง L1 ~90k ใหม่ = ค้าง ~1s หลัง Save ทุกครั้ง
        #   (วัดจริง execute_tool 925-997ms ครั้งแรก/หลัง Save -> 46-75ms เมื่อ cache ร้อน) · การสลับเลเยอร์
        #   จัดการด้วย lid-check ใน _locked_utm_map อยู่แล้ว ไม่ต้องพึ่ง signal นี้
        # ★ ทุก slot ต้องรับ *_a ทิ้ง: QGIS 3.32+ ส่ง argument มากับ beforeCommitChanges(bool)
        #   ถ้าไม่รับ PyQt จะยัดเป็น positional แรก -> ทับ default _lid (กลายเป็น True) -> guard พังเงียบ ๆ
        def on_commit(*_a, _lid=lid):
            self._edit_end[_lid] = 'commit'
            (getattr(self, "_nullgeom_tool", None) or {}).pop(_lid, None)     # ★ 2.4.2 E10 ลงฐานแล้ว ⇒ ล้างที่จำไว้
            (getattr(self, "_nullgeom_done", None) or {}).pop(_lid, None)     # ★ audit rc3 หมุดที่ E7 ลบ ลงฐานแล้ว
            # ★ rc2 (audit A3-10) — แถวของชั้นหมุด (F2 · layer 'POINT') ไม่เปลี่ยนตารางแปลงล็อก (_locked_utm_map อ่าน Type ของแปลง)
            #   เดิมนับด้วย ⇒ บันทึกชั้นหมุดหลัง F2 แล้วล้างแคช ⇒ งานถัดไปสแกนแปลง L1 ทั้งสาขาใหม่ (~1 วิ บน PostGIS) โดยไม่จำเป็น
            _had_type = any(e['lid'] == _lid and e.get('layer') != 'POINT' for e in self._pending_type_log)
            # ★ 2.3.7 (audit F8) — แถวที่เหลือผ่านด่าน _type_log_prune ตอน beforeCommitChanges แล้ว และตอนนี้ลงฐานแล้ว
            #   (QGIS ล้าง undo stack แล้ว) ⇒ เลิกผูกกับคำสั่ง · แถวที่เขียนไม่สำเร็จรอรอบหน้าโดยไม่ถูกตรวจซ้ำกับ stack ใหม่
            for _e in self._pending_type_log:
                if _e.get('lid') == _lid:
                    _e['ux'] = None
            self._flush_type_log(_lid)       # เขียนล็อกเมื่อบันทึกสำเร็จจริงเท่านั้น
            # ★ 2.3.7 b17 (audit R2-D2) — แถวที่เขียนไม่สำเร็จ (รอรอบหน้า) ลงฐานไปแล้ว ⇒ เลิกตรวจผล (ไม่เทียบกับงานที่แก้ต่อภายหลัง)
            for _e in self._pending_type_log:
                if _e.get('lid') == _lid:
                    _e['fx'] = None
                    _e['saved'] = True       # ★ rc2 (audit A3 · ผู้ตรวจทานพบเพิ่ม) ลงฐานแล้ว ⇒ ย้อน/ทิ้งงานรอบหลังไม่ทิ้งแถวนี้
            if _had_type or _lm_dirty.pop(_lid, False):
                # Type เปลี่ยนลงฐานจริงแล้ว -> ตารางแปลงล็อกเปลี่ยนตาม ต้องอ่านใหม่
                # ★ rc2 (audit A4-10) — + งานที่แก้ Type/UTM ของแปลงเดิม หรือเพิ่มแปลง L1 โดยไม่ผ่านคิว Type (ตาราง attribute /
                #   Identify ของผู้ดูแล · ➕ แปลง L1) — เดิมไม่ล้าง ⇒ ตารางเก่าใช้ทั้งวัน
                self._locked_cache = None
            # นับ commit — commitChanges reset undo index เป็น 0 แล้วนับใหม่
            # เทียบ index อย่างเดียวมองไม่เห็นว่ามี Save แทรก (index อาจวนกลับมาเท่าเดิมพอดี)
            self._commit_seq[_lid] = self._commit_seq.get(_lid, 0) + 1
            # (ไม่ล้าง _locked_cache — ดูเหตุผลด้านบน)
            # ★ 2.3.7 (review UX-23) — บันทึกด้วยปุ่มของ QGIS ก็เริ่มนับเวลางานค้างใหม่ (เดิมรีเซ็ตเฉพาะ 💾 ของปลั๊กอิน
            #   ⇒ แก้ต่อก่อนรอบตรวจถัดไป แล้วโดนเตือน "ค้างมา N นาที" ทันทีหลังบันทึก)
            self._unsaved_since = None
            # ★ 2.3.7 (review DI-05) — ชั้นนี้ลงฐานแล้ว ⇒ ไม่ "ค้างครึ่งคู่" อีกต่อไป ⇒ เก็บป้ายเตือนของชั้นนี้
            self._half_save_clear(_lid)
            self._l1_ok.pop(_lid, None)         # ★ 2.4.0 (review DI-11) งานที่จดไว้ลงฐานแล้ว
            try:
                self._l1_round()['done'].add(_lid)     # ★ rc2 (audit A4-02 · A4-03) ชั้นนี้ลงฐานสำเร็จในรอบบันทึกนี้
            except Exception:
                pass

        def on_rollback(*_a, _lid=lid):
            self._edit_end[_lid] = 'rollback'
            (getattr(self, "_nullgeom_tool", None) or {}).pop(_lid, None)     # ★ 2.4.2 E10 ทิ้งงาน ⇒ ล้างที่จำไว้
            (getattr(self, "_nullgeom_done", None) or {}).pop(_lid, None)     # ★ audit rc3
            (getattr(self, "_pending_nullgeom", None) or {}).pop(_lid, None)
            # ★ 31 ส.ค. 69 — _change_type_execute ล้างแคชตอนค่ายังอยู่ใน buffer
            #   ถ้ามีการอ่านแคชใหม่ก่อน rollback ค่าที่ได้มาจากของที่กำลังจะถูกทิ้ง
            #   -> ล้างอีกครั้งตอน rollback ให้กลับไปอ่านจากฐานจริง
            if any(e['lid'] == _lid and e.get('layer') != 'POINT' for e in self._pending_type_log):   # ★ rc2 (A3-10)
                self._locked_cache = None
            # ยกเลิกการแก้ -> ทิ้งคิวล็อก ห้ามบันทึกสิ่งที่ไม่ได้เกิดขึ้นจริง
            #   ★ rc2 (audit A3 · ผู้ตรวจทานพบเพิ่ม) — ยกเว้นแถวที่ลงฐานแล้ว (`saved` · รอเขียน Move_Log ซ้ำ) ซึ่งเกิดขึ้นจริง
            self._pending_type_log = [e for e in self._pending_type_log if e['lid'] != _lid or e.get('saved')]
            # (ไม่ล้าง _locked_cache — Type ไม่เปลี่ยนตอน rollback)
            self._unsaved_since = None          # ★ 2.3.7 (review UX-23) งานค้างถูกทิ้งแล้ว ⇒ เริ่มนับใหม่
            self._l1_ok.pop(_lid, None)         # ★ 2.4.0 (review DI-11) งานที่จดไว้ถูกทิ้งแล้ว (ฟีเจอร์ที่ลบกลับมา)

        def on_before_rb(*_a, _lid=lid):
            # ★ 2.3.7 (review DI-05) — จำ UTM ของงานที่กำลังจะถูกทิ้ง (หลัง rollback อ่านจาก buffer ไม่ได้แล้ว)
            #   ทำเฉพาะชั้นที่อีกชั้นของคู่ลงฐานไปแล้วแต่ยังไม่รู้ว่า UTM ไหน (บันทึกบางส่วนจากปุ่ม 💾)
            try:
                rec = self._half_saved.get(_lid)
                if rec is not None and rec.get("keys") is None:
                    rec["rb_keys"] = self._buffer_utms(QgsProject.instance().mapLayer(_lid))
            except Exception:
                pass

        def on_after_rb(*_a, _lid=lid):
            # ★ 2.3.7 (review UX-38) — นับ rollback ต่อชั้น (ยิงครั้งเดียวต่อการ rollback — เดิม on_rollback ต่อทั้ง before/after)
            self._rollback_seq[_lid] = self._rollback_seq.get(_lid, 0) + 1
            # ★ 2.3.7 (review DI-05) — ทิ้งงานของชั้นที่อีกชั้นลงฐานไปแล้ว = แปลงกับหมุดในฐานไม่ตรงกันถาวร ⇒ แจ้ง (ไม่ใช่ modal
            #   — อาจเกิดตอน QGIS กำลังปิดและถาม Save/Discard ทีละชั้น)
            try:
                self._half_save_rolled_back(_lid)
            except Exception:
                pass

        def on_start(*_a, _lid=lid):
            self._edit_end.pop(_lid, None)   # เปิด edit ใหม่ -> ล้างสถานะเก่า
            # ★ ไม่ล้าง _locked_cache ที่นี่ (แก้ freeze ~1s หลังทุก Save · 2026-08-04):
            #   save_all_changes commit แล้วเรียก lyr.startEditing() ทันที (main.py ~2470) -> fire on_start
            #   ทุก Save · ถ้าล้าง cache ที่นี่ op ถัดไปจะดึงแปลง L1 ~90k ใหม่ = ค้าง ~1s (เท่ากับล้างตอน commit)
            #   · Type เปลี่ยนไม่ได้จากพนักงาน -> cache ใช้ต่อได้ · เหลือล้างเฉพาะ on_fields (โครงสร้างคอลัมน์เปลี่ยน)
            self._pending_pair_warn = None

        def on_fields(*_a, _lid=lid):
            # field ของเลเยอร์เปลี่ยน (เพิ่ม/ลบคอลัมน์) -> cache ชื่อ field / ตาราง lock ใช้ต่อไม่ได้
            self._field_cache = {k: v for k, v in self._field_cache.items() if k[0] != _lid}
            self._locked_cache = None

        # ---- เฝ้า "มุมแปลงไม่มีหมุด" ทุกช่องทางที่บันทึก ----
        # ปุ่ม Save ของปลั๊กอินถามก่อนบันทึกได้ (ยับยั้งได้จริง) แต่ Save Layer Edits /
        # ปิดโหมดแก้ไข ของ QGIS เอง ไม่ผ่านโค้ดเรา -> เดิมข้ามด่านไปทั้งหมด
        # QGIS ไม่มีกลไกให้ปลั๊กอิน "ยกเลิก" การ commit (beforeCommitChanges เป็น signal เปล่า
        # ยับยั้งไม่ได้ และไม่มี setAllowCommit) -> ทำได้ดีที่สุดคือ "ตรวจก่อน เตือนทันทีหลัง"
        # ★ 2.4.0 (review DI-11) — setAllowCommit มีใน C++ แต่ PyQGIS ไม่ export ⇒ ด่านล็อก L1 เรียกผ่าน ctypes (_allow_commit_api)
        #   ใช้เฉพาะด่าน L1 (ถามก่อน · ตอบไม่บันทึก = ระงับ commit นี้) · ด่านจับคู่ยังเป็น "ตรวจก่อน เตือนทันทีหลัง" ตามเดิม
        def on_before_commit_check(*_a, _lid=lid):
            """ตรวจตอน buffer ยังอยู่ แต่ยังไม่เปิด dialog (ห้ามเด้ง UI ระหว่าง commit)
            ★ 2.4.0 (review DI-11) — ยกเว้นคำถามด่าน L1 (_l1_native_gate) ซึ่งเปิดก่อน QGIS เริ่มเขียน (ยังไม่มีอะไรลงฐาน)"""
            self._pending_pair_warn = None
            self._pending_pair_skip = None      # ★ 2.3.7 (review ER-01)
            self._pending_half = None           # ★ 2.3.7 (review DI-05)
            self._pending_pair_hl = False       # ★ 2.4.0 (review UX-09) commit นี้เป็น "การบันทึกคู่ชั้นทำงาน" ด้วยปุ่มของ QGIS
            self._pending_l1_gap = None         # ★ rc2 (audit A4-07) ด่าน L1 ตรวจไม่ครบ (บอกหลังบันทึก)
            # ★ rc2 (audit A4-03) — Save All Edits: ชั้นคู่เริ่มบันทึกในรอบนี้แต่ไม่สำเร็จ ⇒ ระงับชั้นนี้ด้วย (ไม่ลงฐานครึ่งคู่)
            try:
                if self._l1_round_gate(_lid):
                    return
            except Exception:
                _log_exc("ด่านบันทึกครึ่งคู่ (Save All Edits ของ QGIS)")
            # ★ 2.4.0 (review DI-11) — ด่านล็อก L1 ก่อนเช็ค _pair_warn_ack (ปุ่ม 💾 ของปลั๊กอินถามเรื่อง L1 ไปแล้วข้ามเองด้วย _l1_save_ack)
            try:
                if self._l1_native_gate(_lid):
                    return                      # ผู้ใช้ตอบ "ยังไม่บันทึก" ⇒ commit นี้ถูกระงับ ไม่ต้องตรวจคู่
            except Exception:
                _log_exc("ด่าน L1 ก่อนบันทึก (ปุ่มของ QGIS)")
            try:
                if self._pair_warn_ack:
                    return                      # ปุ่มปลั๊กอินถามไปแล้ว ผู้ใช้ตอบ "บันทึกต่อ"
                if getattr(self, "poly_cb", None) is None:
                    # ★ 2.4.0 (review DI-11) — ยังไม่เคยเปิดแผง (ชั้นถูกเฝ้าเพื่อด่าน L1 ตั้งแต่เปิดโปรเจกต์ · _l1_arm_all)
                    #   ⇒ ไม่มีคู่ชั้นทำงานในคอมโบ = ด่านจับคู่ไม่เกี่ยว (ไม่ให้ตกไปเป็น "ตรวจไม่ได้" แล้วขึ้นแถบทุกครั้งที่บันทึก)
                    return
                poly = QgsProject.instance().mapLayer(self.poly_cb.currentData())
                point = QgsProject.instance().mapLayer(self.point_cb.currentData())
                # ★ รับ commit ของ "ชั้นหมุด" ด้วย — เดิมเช็คเฉพาะชั้นแปลง
                #   -> เซฟที่แก้แต่หมุด (ย้าย/ลบด้วยเครื่องมือ QGIS) ไม่ถูกตรวจเลย
                if _lid not in {l.id() for l in (poly, point) if l is not None}:
                    return                      # ไม่ใช่ชั้นทำงานที่เลือกอยู่ -> ไม่เกี่ยว
                self._pending_pair_hl = True    # ★ 2.4.0 (review UX-09) หลัง commit: ล้าง/ทำเครื่องหมายจุดที่ต้องแก้ชุดใหม่
                # ★ 2.3.7 (review DI-05) — UTM ที่ชั้นนี้กำลังจะลงฐาน (หลัง commit เทียบกับงานค้างของอีกชั้น)
                _me = poly if (poly is not None and poly.id() == _lid) else point
                self._pending_half = (_lid, self._buffer_utms(_me))
                # ★ rc2 (audit A4-02) — Save All Edits บันทึกชั้นหมุดแล้วต่อด้วยชั้นแปลงในรอบเดียวกัน ⇒ ชั้นแรกตรวจคู่ (งานค้างของทั้งสอง
                #   ชั้น) และเตือนหลังบันทึกไปแล้ว · ชั้นที่สองได้ผลเดียวกัน ⇒ ไม่ตรวจ/ไม่เตือนซ้ำ (เดิมกล่อง "บันทึกแล้ว แต่พบ…" 2 ใบ
                #   + แถบแดง 2 แถบ + ด่าน 2 รอบ) · ตรวจซ้ำถ้าชั้นแรกบันทึกไม่สำเร็จ (คำเตือนของมันไม่ได้ขึ้น)
                _rs = self._l1_round()
                _rk = tuple(l.id() if l is not None else None for l in (poly, point))
                _oth = point if _me is poly else poly
                if _rk in _rs['checked'] and _oth is not None and _oth.id() in _rs['done']:
                    return
                _rs['checked'].add(_rk)
                iss = self._pairing_issues(poly, point)
                if iss and iss[0]:
                    self._pending_pair_warn = iss
                # ★ 2.3.7 (review ER-01) — ตรวจไม่ได้/ไม่ครบ ต้องไม่ดูเหมือน "ไม่พบปัญหา" ⇒ จำเหตุไว้บอกหลังบันทึก
                _g = self._pairing_gap()
                if _g:
                    self._pending_pair_skip = (_g, getattr(self, "_pairing_last_n", None))
            except Exception as e:
                # ตรวจไม่ได้ -> อย่าไปขวางการบันทึก · ★ 2.3.7 (ER-01) แต่ต้องบอกว่าไม่ได้ตรวจ (เดิมเงียบ)
                self._pairing_last_err = repr(e)[:300]
                self._pending_pair_skip = ('skip-error', None)

        def on_before_commit_nullgeom(*_a, _lid=lid):
            """★ 2.4.2 E7 — หมุดที่ถูกทำให้ "ไม่มีตำแหน่ง" (ลบจุดของหมุดด้วย Vertex Tool) ⇒ ลบหมุดจริงก่อนลงฐาน
            ต่อเป็น slot แรกของ beforeCommitChanges ⇒ ด่านจับคู่/ด่าน L1 ที่ตามมาเห็นงานหลังแปลงแล้ว"""
            try:
                self._nullgeom_points_to_delete(_lid)
            except Exception:
                _log_exc("ด่านหมุดไม่มีตำแหน่ง (Vertex Tool) ก่อนบันทึก")

        def on_after_commit_nullgeom(*_a, _lid=lid):
            """★ 2.4.2 E7 — บอกพนักงานหลังบันทึกว่าหมุดที่ไม่มีตำแหน่งถูกลบแทน (หรือบันทึกไปทั้งที่ว่างเพราะไม่มีสิทธิ์ลบ)
            ★ 2.4.2 E10 — + กล่องเตือนเด้ง (เจ้าของงาน 20 ต.ค. 69 "ให้เด้งเตือนตอนเซฟด้วยว่าพบการใช้ vertex tool ตอนบันทึก
              พนักงานจะได้รู้ตัว") · บอกชื่อเครื่องมือตามที่จับได้ตอนหมุดเสียตำแหน่ง (on_geom_changed_nullgeom)"""
            rec = self._pending_nullgeom.pop(_lid, None) if hasattr(self, "_pending_nullgeom") else None
            if not rec:
                return
            n_del, n_keep = rec[0], rec[1]
            tools = rec[2] if len(rec) > 2 else {}
            try:
                if n_del:
                    self.iface.messageBar().pushMessage(
                        "ลบหมุดที่ไม่มีตำแหน่ง %d จุด" % n_del,
                        "หมุดไม่มีตำแหน่ง (ถูกลบจุดออก/ไม่มีรูป) — ปลั๊กอินลบหมุดนั้นให้แทนการเก็บหมุดว่างไว้ในฐาน · "
                        "ครั้งหน้าเลือกหมุดแล้วกด Delete Selected", level=1, duration=15)
                if n_keep:
                    self.iface.messageBar().pushMessage(
                        "บันทึกหมุดที่ไม่มีตำแหน่ง %d จุด" % n_keep,
                        "บัญชีนี้ไม่มีสิทธิ์ลบหมุด จึงบันทึกเป็นหมุดว่างไว้ — แจ้งผู้ดูแลให้ลบ", level=1, duration=0)
            except Exception:
                pass
            try:
                title, text = self._nullgeom_popup_text(n_del, n_keep, tools)
                # ห้ามเปิด modal "ระหว่าง" afterCommitChanges (commitChanges ยังอยู่บน stack) ⇒ เลื่อนไปหลัง event loop ว่าง (แบบ on_after_commit_warn)
                QtCore.QTimer.singleShot(0, lambda: self._ask_when_free(QtWidgets.QMessageBox.Warning, title, text))
            except Exception:
                _log_exc("กล่องเตือนหมุดไม่มีตำแหน่งหลังบันทึก (E10)")

        def on_geom_changed_nullgeom(fid, geom=None, *_a, _lid=lid):
            """★ 2.4.2 E10 — หมุด/ฟีเจอร์ถูกทำให้ "ไม่มีตำแหน่ง" ⇒ จำเครื่องมือบนแผนที่ที่ใช้อยู่ตอนนั้น (เช่น QgsVertexTool)
            ให้กล่องหลังบันทึกบอกได้แน่ว่าเป็นเครื่องมืออะไร (ฐานบอกไม่ได้ — เห็นแค่ UPDATE geom = NULL) · ได้ตำแหน่งคืน = ลบที่จำไว้"""
            try:
                empty = geom is None or geom.isNull() or geom.isEmpty()
            except Exception:
                return
            if not hasattr(self, "_nullgeom_tool"):
                self._nullgeom_tool = {}
            if empty:
                self._nullgeom_tool.setdefault(_lid, {})[fid] = self._map_tool_class()
            else:
                d = self._nullgeom_tool.get(_lid)
                if d:
                    d.pop(fid, None)

        def on_after_commit_warn(*_a, _lid=lid):
            """บันทึกไปแล้ว (ยับยั้งไม่ได้) -> เตือนทันทีพร้อมบอกวิธีแก้"""
            iss = self._pending_pair_warn
            self._pending_pair_warn = None
            skip, self._pending_pair_skip = getattr(self, "_pending_pair_skip", None), None
            half, self._pending_half = getattr(self, "_pending_half", None), None
            # ★ 2.4.0 (review UX-09) — บันทึกคู่ชั้นทำงานด้วยปุ่มของ QGIS ⇒ ล้างเครื่องหมายชุดเดิม + ทำชุดใหม่ถ้าพบปัญหา
            #   (เลื่อนออกนอก commitChanges · ปุ่ม 💾 ของปลั๊กอินทำเองใน save_all_changes — hook ข้ามด้วย _pair_warn_ack)
            hl, self._pending_pair_hl = getattr(self, "_pending_pair_hl", False), False
            # ★ rc2 (audit A4-07) — ด่าน L1 ตรวจไม่ครบ (สแกนแปลง L1 ล้ม / ด่านล้ม) ⇒ บอกบนแถบ (เดิมลงแค่ Log แล้วบันทึกเงียบ)
            l1g, self._pending_l1_gap = getattr(self, "_pending_l1_gap", None), None
            if l1g and l1g[0] == _lid:
                try:
                    self.iface.messageBar().pushMessage(
                        "บันทึกแล้ว — ตรวจการแก้แปลง/หมุด L1 ไม่ครบ", l1g[1], level=1, duration=15)
                except Exception:
                    pass
            if hl:
                try:
                    self._pair_hl_after_commit(iss)
                except Exception:
                    pass
            # ★ 2.3.7 (review DI-05) — บันทึกไปชั้นเดียวด้วยปุ่มของ QGIS ⇒ ป้ายค้างพร้อมปุ่มบันทึกอีกชั้น (ไม่ใช่ modal)
            if half and half[0] == _lid:
                try:
                    self._half_save_check(_lid, half[1])
                except Exception:
                    pass
            # ★ 2.3.7 (review ER-01) — ด่านถูกข้าม/ตรวจไม่ครบ ⇒ บอกบนแถบข้อความ (ไม่บล็อก ไม่ modal)
            if skip and not iss:
                try:
                    _h, _r = self._pairing_gap_th(skip[0], skip[1])
                    self.iface.messageBar().pushMessage(f"บันทึกแล้ว — {_h}", _r, level=1, duration=15)
                except Exception:
                    pass
            if not iss:
                return
            try:
                # ★ 2.3.7 (review UX-39 · DI-48) — นับ/ตั้งชื่อแยกชนิด + วิธีแก้ตามชนิด (ข้อความเดียวกับกล่องก่อนบันทึก)
                _title, _summ, _txt = self._pairing_text(iss, saved=True, why=skip[0] if skip else None)
                self.iface.messageBar().pushMessage(
                    "⚠️ " + _title, f"บันทึกไปแล้ว — {_summ} — ดูรายละเอียดในหน้าต่างที่เด้งขึ้น", level=2, duration=0)
                # ★ ห้ามเปิด modal "ระหว่าง" สัญญาณ afterCommitChanges (commitChanges ยังอยู่บน stack)
                #   -> เลื่อนออกไปหลัง event loop กลับมาว่าง + ใช้ _ask ให้กล่องขึ้นหน้าสุดเสมอ (2026-08-05)
                QtCore.QTimer.singleShot(0, lambda: self._ask_when_free(
                    QtWidgets.QMessageBox.Warning, "บันทึกแล้ว แต่พบ" + _title, _txt))
            except Exception:
                pass

        _tl_tmp = {}                     # ★ rc2 (audit A3-04) fid ชั่วคราวของฟีเจอร์ใหม่ (เรียงแบบที่ QGIS ส่ง) ที่แถวคิวอ้างถึง
        _lm_dirty = {}                   # ★ rc2 (audit A4-10) commit นี้เปลี่ยนตารางแปลงล็อก (ล้าง _locked_cache เมื่อลงฐานสำเร็จ)

        def on_before_commit_log(*_a, _lid=lid):
            """★ 2.3.7 (audit F8) — ก่อน commit (undo stack ยังอยู่): ทิ้งแถวคิว Move_Log ของการแก้ที่ถูกย้อนด้วย Undo ของ QGIS"""
            try:
                self._type_log_prune(_lid)
            except Exception:
                pass
            # ★ rc2 (audit A3-04 + ผู้ตรวจทานพบเพิ่ม) — แถวคิวของฟีเจอร์ที่ยังไม่เคยบันทึก (➕ แล้ว 🏷/🍩/📝 · Add Node แล้ว F2)
            #   จด fid ชั่วคราว (ติดลบ) ⇒ เดิมเขียน gid ติดลบลง Move_Log · จำลำดับ fid ชั่วคราวไว้ แล้วแปลงเป็น fid จริงตอน
            #   committedFeaturesAdded (★ S_close review R3-01: QGIS ส่งตามคีย์ของ addedFeatures กลับด้าน · ตรวจซ้ำด้วยกรอบรูป)
            # ★ rc2 (audit A4-10) — งานที่จะลงฐานเปลี่ยนตารางแปลงล็อกไหม: แก้ Type/UTM ของแปลงเดิม · เพิ่มแปลง Type L1
            #   (ลบแปลง = ตารางเดิมล็อกเกิน = ทางปลอดภัย ไม่ต้องอ่านใหม่ — คงการแก้ค้าง ~1 วิหลัง Save ของ 4 ส.ค.)
            try:
                _lm_dirty.pop(_lid, None)
                _l = QgsProject.instance().mapLayer(_lid)
                _b = _l.editBuffer() if _l is not None and _l.isEditable() else None
                if _b is not None and self._geom_role(_l) == 0:
                    _fl = _l.fields()
                    _ti = self._field_index(_fl, 'type')
                    _ui = self._field_index(_fl, _UTM_FIELD_NAMES)
                    _w = {i for i in (_ti, _ui) if i >= 0}
                    if _w and (any(_w & set(a) for a in _b.changedAttributeValues().values())
                               or (_ti >= 0 and any(_txt(f.attribute(_ti)).upper() in L1_TYPES
                                                    for f in _b.addedFeatures().values()))):
                        _lm_dirty[_lid] = True
            except Exception:
                _lm_dirty[_lid] = True
            try:
                _tl_tmp.pop(_lid, None)
                if any(e.get('lid') == _lid and int(e.get('gid', 0)) < 0 for e in self._pending_type_log):
                    _l = QgsProject.instance().mapLayer(_lid)
                    _b = _l.editBuffer() if _l is not None else None
                    if _b is not None:
                        _add = _b.addedFeatures()
                        # ★ rc2 S_close (review R3-01 ④) — แถวคิวของฟีเจอร์ใหม่ที่ถูกลบทิ้งก่อนบันทึก (➕ แล้ว 🏷 แล้วลบ)
                        #   ฟีเจอร์ไม่ลงฐาน ⇒ ไม่เขียนแถวของมัน (เดิมเขียนแถว retyped ด้วย gid NULL ของแปลงที่ไม่มีอยู่)
                        _orph = [e for e in self._pending_type_log
                                 if e.get('lid') == _lid and int(e.get('gid', 0)) < 0 and int(e['gid']) not in _add]
                        if _orph:
                            self._pending_type_log = [x for x in self._pending_type_log if not any(x is o for o in _orph)]
                            try:
                                QgsMessageLog.logMessage("Move_Log: ไม่เขียน %d รายการ — ฟีเจอร์ใหม่ถูกลบก่อนบันทึก"
                                                         % len(_orph), "MLEP", Qgis.Info)
                            except Exception:
                                pass
                        # ★ rc2 S_close (review R3-01) — QGIS ส่ง committedFeaturesAdded ตามลำดับ "คีย์ QMap กลับด้าน"
                        #   (mapToReversedLists: -2,-3 = ลำดับที่เพิ่ม) ⇒ เรียงจากมากไปน้อย (เดิม sorted น้อยไปมาก = สลับ gid
                        #   เมื่อมีฟีเจอร์ใหม่ ≥2 ตัว) · จำกรอบรูปไว้ตรวจซ้ำตอนจับคู่ (กรอบไม่เปลี่ยนแม้ provider แปลงเป็น multi)
                        _tl_tmp[_lid] = [(k, self._tl_bbox(_add[k])) for k in sorted(_add.keys(), reverse=True)]
            except Exception:
                _tl_tmp.pop(_lid, None)

        def on_committed_added(_layer_id, feats, _lid=lid):
            """★ rc2 (audit A3-04) — fid ชั่วคราว → fid จริงในแถวคิว Move_Log (ก่อน afterCommitChanges ที่เขียนล็อก)"""
            try:
                olds = _tl_tmp.pop(_lid, None)
                feats = list(feats)
                if not olds or len(olds) != len(feats):
                    return
                m = self._tl_match(olds, feats)
                for e in self._pending_type_log:
                    if e.get('lid') == _lid and e.get('gid') in m:
                        e['gid'] = m[e['gid']]
            except Exception:
                pass

        _sigs = [("beforeCommitChanges", on_before_commit_nullgeom),  # ★ 2.4.2 E7 (ต้องเป็นตัวแรก)
                 ("beforeCommitChanges", on_before_commit_check),
                 ("beforeCommitChanges", on_before_commit_log),      # ★ 2.3.7 (audit F8)
                 ("committedFeaturesAdded", on_committed_added),     # ★ rc2 (audit A3-04)
                 ("afterCommitChanges", on_after_commit_nullgeom),   # ★ 2.4.2 E7
                 ("afterCommitChanges", on_after_commit_warn)]
        try:
            if self._geom_role(lyr) == 1:
                # ★ 2.4.2 E10 — เฉพาะชั้นหมุด (audit rc3: เดิมต่อทุกชั้น ⇒ ทุกการลากมุมแปลงเรียก slot นี้เปล่า ๆ)
                _sigs.append(("geometryChanged", on_geom_changed_nullgeom))
        except Exception:
            pass
        for sig_name, slot in _sigs:
            sig = getattr(lyr, sig_name, None)
            if sig is None:
                continue
            try:
                sig.connect(slot)
                self._signal_conns.append((lid, sig_name, slot))
            except Exception:
                pass

        # ต่อแยกทีละ signal (try ของใครของมัน) — ถ้าชื่อ signal ใดต่างใน QGIS บางรุ่น
        # ตัวที่เหลือยังทำงาน (อย่างน้อย degrade เป็น "บล็อกเมื่อเลเยอร์ปิด" ซึ่งปลอดภัย)
        # ★ ห้ามต่อ on_commit กับ beforeCommitChanges (2026-08-06): QGIS ยิง signal นั้น "ก่อน" เขียนจริง
        #   ยิงแม้การบันทึกจะล้มเหลวในภายหลัง -> _commit_seq เพิ่มทั้งที่ไม่ได้เซฟ = ระบบเข้าใจว่า
        #   "มี Save แทรกหลังงานนี้" แล้วบล็อกปุ่ม Undo ของปลั๊กอิน ทั้งที่ผู้ใช้ยิ่งต้องใช้ Undo ตอนนั้น
        #   (afterCommitChanges ยิงเฉพาะตอน commit สำเร็จจริง จึงเป็นตัวนับที่ถูกต้อง)
        for sig_name, slot in (("afterCommitChanges", on_commit),
                               ("afterRollBack", on_rollback),
                               ("beforeRollBack", on_rollback),
                               ("beforeRollBack", on_before_rb),     # ★ 2.3.7 DI-05
                               ("afterRollBack", on_after_rb),       # ★ 2.3.7 UX-38 · DI-05
                               ("editingStarted", on_start),
                               ("updatedFields", on_fields)):
            sig = getattr(lyr, sig_name, None)
            if sig is None:
                continue
            try:
                sig.connect(slot)
                self._signal_conns.append((lid, sig_name, slot))
            except Exception:
                pass

    def _ensure_editing(self, *layers, title="MLEP", what="ยังไม่ได้แก้อะไร", warn=True):
        """★ 2.4.0 (review DI-15 · MT-16) — เปิดโหมดแก้ไขให้ทุกชั้นที่ส่งมา (เฉพาะชั้นที่ยังไม่เปิด · None = ข้าม)
        แล้วตรวจ isEditable() ซ้ำ — ไม่เชื่อค่าที่ startEditing() คืน (ชั้นใน transaction group ที่เปิด transaction ไม่สำเร็จ
        ยังไม่เข้าโหมดแก้ไขทั้งที่คืน True)
        คืน True = ทุกชั้นพร้อมเขียน · False = หยุดที่ชั้นแรกที่เปิดไม่ได้ + แจ้งแถบแดงหนึ่งข้อความบอกชื่อชั้น
        (warn=False = ไม่แจ้ง ผู้เรียกบอกเอง) · ผู้เรียกต้องเรียก "ก่อน" _op_begin / beginEditCommand ⇒ ล้ม = ยังไม่ได้เขียนอะไร
        เดิมเครื่องมือเรียก startEditing() แล้วไม่ดูผล ⇒ ชั้นอ่านอย่างเดียว / provider แก้ไม่ได้ / การเชื่อมต่อหลุด
        = beginEditCommand ไม่ทำอะไร การเขียนล้มเงียบ หรือลงได้ชั้นเดียว (Score ลงแปลงแต่หมุดไม่ลง · Align ย้ายหมุดแต่มุมแปลงไม่ตาม)"""
        for l in layers:
            if l is None:
                continue
            nm = "?"
            try:
                nm = l.name()
                if not l.isEditable():
                    l.startEditing()
                if l.isEditable():
                    continue
            except Exception:
                _log_exc(f"เปิดโหมดแก้ไขชั้น '{nm}' ไม่ได้")
            # ★ rc1 (F8 · §5.1 DI-15) — ลง Log ระดับ Warning พร้อมเหตุจาก provider (เดิมไม่มีร่องรอยให้ผู้ดูแลที่พนักงานถูกบอกให้แจ้งตามต่อ)
            try:
                _pe = ""
                try:
                    _dp = l.dataProvider()
                    _pe = _dp.error().summary() if _dp is not None and _dp.error() is not None else ""
                except Exception:
                    _pe = ""
                QgsMessageLog.logMessage(_scrub(f"{title}: เปิดโหมดแก้ไขชั้น '{nm}' ไม่ได้ — {what}"
                                                + (f" · provider: {_pe}" if _pe else "")), "MLEP", Qgis.Warning)
            except Exception:
                pass
            if warn:
                self.iface.messageBar().pushMessage(
                    title, f"เปิดโหมดแก้ไขชั้น '{nm}' ไม่ได้ (สิทธิ์ไม่พอ / ชั้นอ่านอย่างเดียว / การเชื่อมต่อฐานข้อมูลหลุด) "
                           f"— {what}", level=2, duration=10)
            return False
        return True

    def _op_begin(self, layers, l1_ok=False, l1_only=None):
        """บันทึกตำแหน่ง undo-stack ปัจจุบันของแต่ละเลเยอร์ ก่อนเริ่ม operation (ไว้คำนวณ delta)
        + ต่อ signal ดักการปิด edit (Save/Discard) ของเลเยอร์เหล่านั้น
        ★ rc1 (F6) l1_ok=True = งานนี้แก้ L1 ตามข้อยกเว้นที่ปลั๊กอินอนุญาตเอง (Transform 2 จุด L1-TS ไปต่อ L1-RTK)
          ⇒ จดเหมือนงานตอนปลดล็อก (ด่าน L1 ตอนบันทึกไม่ถาม)
        ★ rc1 S5 (review R3-01) l1_only = {layer id: {fid}} ฟีเจอร์ที่ผ่านข้อยกเว้น ⇒ จดเฉพาะชุดนี้ และข้ามฟีเจอร์ที่มีงาน L1
          ค้างอยู่ก่อน op ที่ยังไม่ได้อนุญาต (_l1_note_ok) · ปลดล็อก L1 อยู่ = ไม่จำกัด (ทางผู้ดูแลเดิม)"""
        baseline = {}
        for lyr in layers:
            if lyr is None:
                continue
            try:
                baseline[lyr.id()] = (lyr, lyr.undoStack().index())
                self._watch_layer_editing(lyr)
            except Exception:
                pass
        self._op_baseline = baseline
        # ★ 2.4.0 (review DI-11) — ปลดล็อก L1 อยู่ ⇒ จำสภาพ buffer ก่อนงานของปลั๊กอิน (_op_commit จดส่วนที่ op นี้แก้ไว้ใน _l1_ok)
        #   ⇒ งานของเครื่องมือปลั๊กอินตอนปลดล็อกไม่โดนด่าน L1 ตอนบันทึก แม้ล็อกกลับก่อนกดบันทึก · ล็อกอยู่ = ไม่ทำอะไรเพิ่ม
        self._l1_op_pre = None
        self._l1_op_pre_a = None
        self._l1_op_only = (l1_only or {}) if (l1_ok and not self._l1_unlocked()) else None
        if l1_ok or self._l1_unlocked():
            try:
                self._l1_op_pre = {lid: self._l1_buf_state(l) for lid, (l, _i) in baseline.items()}
            except Exception:
                self._l1_op_pre = None
            try:
                # ★ rc2 (audit A4-04) — ค่าที่แก้ค้างก่อน op (ด่านตอนบันทึกดูการแก้ค่าของแปลง/หมุด L1 ด้วย)
                self._l1_op_pre_a = {lid: self._l1_buf_attrs(l) for lid, (l, _i) in baseline.items()}
            except Exception:
                self._l1_op_pre_a = None

    def _op_commit(self):
        """ปิด operation: เลเยอร์ไหนถูก push undo-command เพิ่ม (delta>0) เก็บเป็น 1 รายการในประวัติ
        delta คำนวณจาก index ของ QUndoStack

        ★ 2.3.7 (review DI-28) — คำอธิบายเดิม "empty command (ไม่ถูก push) จะได้ delta=0 อัตโนมัติ" ไม่จริง:
          beginEditCommand → endEditCommand ที่ไม่มีการแก้เลย QGIS ก็ push คำสั่งเปล่าลง stack (index +1 และชั้นกลายเป็น
          "มีการแก้ไข" · วัดบน QGIS 3.44) ⇒ ผู้เรียกต้องใช้ destroyEditCommand() เมื่อไม่ได้เขียนอะไร
          ตาข่ายกันพลาดที่นี่ (_op_drop_empty): ทุกคำสั่งที่ op push บนชั้นหนึ่งเป็นคำสั่งเปล่า ⇒ ย้อนทิ้ง + ล้าง Redo
          แล้วไม่นับชั้นนั้น (เดิมได้ขั้น ↺ ปลอมที่ย้อนแล้วไม่มีอะไรเปลี่ยน แต่ขึ้นว่า "สำเร็จ" และไปบังงานจริงก่อนหน้า)"""
        base = self._op_baseline
        self._op_baseline = None
        _pre, self._l1_op_pre = getattr(self, "_l1_op_pre", None), None      # ★ 2.4.0 (review DI-11)
        _pre_a, self._l1_op_pre_a = getattr(self, "_l1_op_pre_a", None), None   # ★ rc2 (audit A4-04)
        _only, self._l1_op_only = getattr(self, "_l1_op_only", None), None   # ★ rc1 S5 (review R3-01)
        if _pre and base:
            self._l1_note_ok(base, _pre, only=_only, pre_a=_pre_a)
        if not base:
            return
        op = []
        for lyr, before in base.values():
            try:
                after = lyr.undoStack().index()
                if after > before and self._op_drop_empty(lyr, before, after):
                    after = lyr.undoStack().index()
                delta = after - before
            except Exception:
                delta, after = 0, None
            if delta > 0:
                # เก็บ "ชื่อ" + "index ปลายทาง" ไว้ด้วย:
                #   ชื่อ  -> ใช้ในข้อความเมื่อเลเยอร์ถูกถอดออกจากโปรเจกต์แล้ว
                #            (เรียก .name() บน object ที่ C++ ลบไปแล้ว = RuntimeError)
                #   index -> ใช้ตรวจว่ามี edit อื่นแทรกหลัง operation หรือไม่ (ถ้ามี ห้ามย้อนแบบตาบอด)
                try:
                    _nm = lyr.name()
                except Exception:
                    _nm = "?"
                # seq = จำนวน commit ตอนจบ op (เปลี่ยน = มี Save แทรกหลัง op)
                # cmd = pointer ของ undo command บนสุด (เปลี่ยนทั้งที่ index เท่าเดิม =
                #        stack ถูก truncate แล้วแทนด้วยงานอื่น — undo k ครั้งแล้วแก้ใหม่ k งาน)
                _seq = self._commit_seq.get(lyr.id(), 0)
                _cmd = None
                _ctx = None
                try:
                    if after and after > 0:
                        from qgis.PyQt import sip as _sip
                        _c = lyr.undoStack().command(after - 1)
                        if _c is not None:
                            _cmd = _sip.unwrapinstance(_c)
                            _ctx = _c.text()       # ★ 2.3.7 (review LC-02) เทียบคู่กับ pointer ในด่าน (3) ของ ↺
                except Exception:
                    _cmd = None
                # ★ 2.3.7 (review UX-38) rb = จำนวน rollback ตอนจบ op (เปลี่ยน = งานของ op ถูกทิ้งด้วย Discard/Rollback)
                _rb = self._rollback_seq.get(lyr.id(), 0)
                op.append((lyr, delta, _nm, after, _seq, _cmd, _rb, _ctx))
        if op:
            self.op_history.append(op)
            if len(self.op_history) > 100:   # กันโตไม่จำกัด
                self.op_history.pop(0)
            self.last_layers = [e[0] for e in op]   # เผื่อโค้ดอื่นอ้างอิง

    def undo_transform(self):
        """ย้อน operation ล่าสุดของปลั๊กอิน — ย้อนแต่ละเลเยอร์ตามจำนวน step ที่มัน push จริง
        Guard: ถ้ามีเลเยอร์ในรายการถูกปิด edit ไปแล้ว (ประวัติหาย) จะแยกเคส
          • Save  -> บล็อก (popup เตือน) เพราะย้อนเลเยอร์เดียวจะทำให้ไม่ตรงกัน
          • Discard -> popup ถามว่าจะย้อนเลเยอร์ที่ยังเปิดอยู่กลับ "จุดเริ่มเปิดแก้ไข" ให้ตรงกันไหม"""
        if not self.op_history:
            # ★ 2.3.7 (review UX-35) — ไม่ใช่ความล้มเหลว ⇒ เหลือง (เดิมแดง level 2)
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการล่าสุดให้ย้อนกลับ", level=1, duration=10)
            return

        op = self.op_history[-1]   # ยังไม่ pop เผื่อบล็อก/ยกเลิก
        live, saved_gone, disc_gone, unknown_gone = [], [], [], []
        stale = []   # เลเยอร์ที่มี edit "อื่น" แทรกหลัง operation ของปลั๊กอิน
        for entry in op:
            lyr, n = entry[0], entry[1]
            nm  = entry[2] if len(entry) > 2 else None
            end = entry[3] if len(entry) > 3 else None
            seq = entry[4] if len(entry) > 4 else None
            cmd = entry[5] if len(entry) > 5 else None
            rbs = entry[6] if len(entry) > 6 else None     # ★ 2.3.7 (UX-38) จำนวน rollback ตอนจบ op
            ctx = entry[7] if len(entry) > 7 else None     # ★ 2.3.7 (LC-02) ข้อความของคำสั่งบนสุดตอนจบ op
            if lyr is None:
                continue
            try:
                if nm is None:
                    nm = lyr.name()
                _lid = lyr.id()
                # ★ 2.3.7 (review UX-38) — ตัดสิน "มี Save/Discard แทรกหลัง op" ด้วยตัวนับก่อน ไม่ว่าชั้นยังเปิดแก้ไขอยู่ไหม
                #   เดิมต้อง isEditable() และ canUndo() พร้อมกันจึงจะตรวจ ⇒ ย้อนด้วย QGIS จนหมด (index 0) ทั้งที่ยังเปิดแก้ไข
                #   หรือ Discard แล้วเปิดแก้ไขใหม่ ตกไปเป็น "ไม่รู้สถานะ" ⇒ กล่อง "ถูกปิดแก้ไข/บันทึกไปแล้ว" ทั้งที่ไม่ใช่
                # ★ ด่านก่อนยอมย้อน (เดิมย้อน top-n แบบตาบอด):
                # (1) มี Save แทรกหลัง op ไหม — commitChanges reset index เป็น 0 แล้วนับใหม่
                #     index อาจกลับมาเท่า end พอดี -> ต้องเทียบตัวนับ commit ไม่ใช่ index
                if seq is not None and self._commit_seq.get(_lid, 0) != seq:
                    saved_gone.append(nm)      # op ถูกบันทึกลง DB ไปแล้ว ย้อนใน stack ไม่ได้
                    continue
                # (1b) มี Discard/Rollback แทรกหลัง op (รวม Rollback ที่ยังเปิดแก้ไขต่อ) ⇒ งานของ op ถูกทิ้งไปแล้ว
                if rbs is not None and self._rollback_seq.get(_lid, 0) != rbs:
                    disc_gone.append(nm)
                    continue
                if lyr.isEditable():
                    cur = lyr.undoStack().index()
                    # (2) index ไม่ตรง = มีงานแทรก (บวก) หรือถูกย้อนไปแล้วด้วย QGIS (ลบ — รวมย้อนจนหมดถึง 0)
                    if end is not None and cur != end:
                        stale.append((nm, cur - end))
                        continue
                    if lyr.undoStack().canUndo():
                        # (3) index ตรง แต่ command บนสุดถูกแทนที่ (undo k ครั้ง + แก้ใหม่ k งาน
                        #     -> QUndoStack ตัดของเดิมทิ้งแล้วแทน index กลับมาเท่าเดิมพอดี)
                        #     ★ 2.3.7 (review LC-02) — เทียบข้อความของคำสั่งด้วย (address อาจถูก allocator ใช้ซ้ำ)
                        if cmd is not None or ctx is not None:
                            try:
                                from qgis.PyQt import sip as _sip
                                _c = lyr.undoStack().command(end - 1) if end and end > 0 else None
                                if _c is None or (cmd is not None and _sip.unwrapinstance(_c) != cmd) \
                                        or (ctx is not None and _c.text() != ctx):
                                    stale.append((nm, 0))
                                    continue
                            except Exception:
                                pass
                        live.append((lyr, n))          # ยังย้อนผ่าน stack ได้อย่างปลอดภัย
                        continue
                # ปิดแก้ไขไปแล้วโดยตัวนับไม่เปลี่ยน (หรือรายการรุ่นเก่าที่ไม่มีตัวนับ) — ใช้สถานะตอนปิดแบบเดิม
                ev = self._edit_end.get(_lid)
                if ev == 'rollback':
                    disc_gone.append(nm)       # ปิดแบบ Discard
                elif ev == 'commit':
                    saved_gone.append(nm)      # ปิดแบบ Save
                else:
                    unknown_gone.append(nm)    # ไม่รู้สถานะ -> กันไว้เหมือน Save
            except RuntimeError:
                # เลเยอร์ถูกถอดออกจากโปรเจกต์ไปแล้ว (C++ object ตาย) — เดิมตรงนี้ทำให้ Undo crash
                unknown_gone.append(nm or "เลเยอร์ที่ถูกถอดออกแล้ว")
            except Exception:
                unknown_gone.append(nm or "?")

        if stale:
            fwd = [(n, d) for n, d in stale if d >= 0]     # มีงานอื่นแทรก/แทนที่
            back = [(n, d) for n, d in stale if d < 0]     # ผู้ใช้ย้อนด้วย QGIS ไปแล้ว
            if fwd:
                _names = ", ".join(f"{n} (แทรก {d} ขั้น)" if d > 0 else f"{n} (งานถูกแทนที่)"
                                   for n, d in fwd)
                self._ask(
                    QtWidgets.QMessageBox.Warning, "ย้อนกลับไม่ได้",
                    f"มีการแก้ไขอื่นเกิดขึ้นหลังงานล่าสุดของปลั๊กอิน ({_names})\n\n"
                    "ถ้าย้อนตอนนี้จะไปย้อน 'งานอื่น' แทนงานของปลั๊กอิน และทำให้ชั้นแปลง/หมุดไม่ตรงกัน\n"
                    "ให้ใช้ Undo ของ QGIS (เมนู Edit → Undo) ย้อนงานล่าสุดออกก่อน แล้วกดปุ่มนี้อีกครั้ง")
            else:
                _names = ", ".join(f"{n} ({-d} ขั้น)" for n, d in back)
                self._ask(
                    QtWidgets.QMessageBox.Information, "ย้อนไปแล้วด้วย QGIS",
                    f"งานล่าสุดของปลั๊กอินถูกย้อนด้วย Undo ของ QGIS ไปแล้วบางส่วน ({_names})\n\n"
                    "ใช้ Edit → Undo/Redo ของ QGIS จัดการส่วนที่เหลือ\n"
                    "หรือกด Redo กลับมาให้ครบก่อน แล้วค่อยใช้ Undo ของปลั๊กอิน")
            return

        # ---- เคสปกติ: ทุกเลเยอร์ยังเปิดอยู่ -> ย้อนตาม step ----
        if not (saved_gone or disc_gone or unknown_gone):
            self.op_history.pop()
            for lyr, n in live:
                stack = lyr.undoStack()
                for _ in range(n):
                    if not stack.canUndo():
                        break
                    stack.undo()
                # ★ 2.3.7 (review DI-33) — ล้าง Redo ที่เหลือจากการย้อน: Redo ของ QGIS ทำทีละชั้น
                #   ⇒ กด Redo ชั้นเดียวได้งานคู่แปลง-หมุดกลับมาครึ่งเดียว (แปลงขยับ หมุดไม่ตาม)
                self._purge_redo(lyr)
                # ★ 31 ส.ค. 69 — ปุ่ม ↺ Undo ย้อนค่า Type ผ่าน undo stack โดยไม่ผ่าน
                #   afterRollBack คิวล็อกจึงค้าง แล้วพอกดบันทึกจะได้ล็อก 'retyped'
                #   ของการเปลี่ยนที่ถูกย้อนไปแล้ว = ล็อกปลอม
                #   ทิ้งคิวของเลเยอร์ที่ถูกย้อน — จดน้อยไปดีกว่าจดสิ่งที่ไม่เคยเกิด
                # ★ rc2 (audit A3-01 + ผู้ตรวจทานพบเพิ่ม) — ทิ้งเฉพาะแถวของคำสั่งที่ถูกย้อน (ux/fx · _type_log_prune) ไม่ใช่ทั้งชั้น
                #   เดิมทิ้งทุกแถวของชั้น ⇒ F2 แปลง A แล้ว F2 แปลง B แล้ว ↺ (ย้อนเฉพาะ B) = แถวของ A ที่ยังมีผลหาย
                #   (บันทึกแล้ว Type เปลี่ยนจริงแต่ไม่มีแถว 'retyped') · แถวที่ลงฐานแล้วรอเขียนซ้ำก็หาย
                #   ยังล้างแคชล็อกเมื่อชั้นนี้มีแถวคิว (ข้อควรระวัง DI-20: ค่า Type ใน buffer อาจถูกย้อน)
                if any(e.get('lid') == lyr.id() and e.get('layer') != 'POINT' for e in self._pending_type_log):   # A3-10
                    self._locked_cache = None
                self._type_log_prune(lyr.id())
            self.iface.mapCanvas().refresh()
            # ★ 2.3.7 (review UX-35) — ยังไม่ลงฐาน (ต้องกด 💾) ⇒ ข้อมูล (ฟ้า) ไม่ใช่คำเตือน (เหลือง)
            self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดเรียบร้อยแล้ว", level=0, duration=8)
            return

        # ---- มีเลเยอร์ปิด+Save (หรือไม่รู้สถานะ) -> บล็อก (popup เตือน) ----
        if saved_gone or unknown_gone:
            names = ", ".join(saved_gone + unknown_gone)
            self._ask(
                QtWidgets.QMessageBox.Warning, "ย้อนกลับไม่ได้",
                f"เลเยอร์ '{names}' ถูกปิดแก้ไข/บันทึกไปแล้ว — ประวัติ undo หายไป\n\n"
                "ย้อนอัตโนมัติไม่ได้ เพราะจะทำให้ 2 เลเยอร์ไม่ตรงกัน\n"
                "ให้เปิด Toggle Editing ของเลเยอร์นั้นก่อน แล้วแก้ด้วยตนเอง")
            return   # ไม่ pop ไม่ย้อนอะไร

        # ---- เลเยอร์ที่หายเป็น Discard ทั้งหมด ----
        disc_names = ", ".join(disc_gone)
        if not live:
            # ทั้ง op เป็น Discard -> ทุกเลเยอร์กลับจุดเริ่มอยู่แล้ว ไม่ต้องทำอะไร
            self.op_history.pop()
            for _e in list(op):
                if _e[0] is not None:
                    try:
                        self._drop_type_log(_e[0].id())
                    except Exception:
                        pass
            self.iface.messageBar().pushMessage(
                "Undo", f"เลเยอร์ '{disc_names}' ถูกปิดแบบไม่เซฟ — ข้อมูลกลับจุดเริ่มแล้ว ไม่ต้องย้อนเพิ่ม",
                level=0, duration=10)          # ★ 2.3.7 (review UX-35) เดิม level 1
            return

        # มีทั้ง Discard และเลเยอร์ที่ยังเปิด -> ถามว่าจะย้อนเลเยอร์ที่เปิดกลับจุดเริ่มให้ตรงกันไหม
        live_names = ", ".join(l.name() for l, _ in live)
        # ★ 2.3.7 (review DI-05) — "ย้อนกลับจุดเริ่มเปิดแก้ไข" ทำให้คู่ตรงกันได้จริงเฉพาะเมื่อไม่มีชั้นไหนในงานนี้ถูกบันทึกลงฐาน
        #   หลังงานแรกของมันที่ยังอยู่ในประวัติ ↺ — ถ้ามี Save แทรก ส่วนที่ลงฐานแล้วย้อนไม่ได้ ⇒ ข้อความ "ย้อนทั้งสองเลเยอร์
        #   กลับจุดเริ่มแล้ว" ไม่จริง ⇒ ไม่เสนอ บอกตรง ๆ ว่าต้องจับคู่เอง (ไม่เปลี่ยนอะไร)
        _mixed = self._saved_since_first_op([e[0] for e in op if e[0] is not None])
        if _mixed:
            self._ask(
                QtWidgets.QMessageBox.Warning, "ย้อนให้ตรงกันอัตโนมัติไม่ได้",
                f"เลเยอร์ '{disc_names}' ถูกทิ้งการแก้ไข (ไม่บันทึก) แต่ระหว่างงานเหล่านี้มีการบันทึกลงฐานข้อมูลแทรกไปแล้ว "
                f"('{', '.join(_mixed)}')\n\n"
                "ส่วนที่ลงฐานแล้วย้อนไม่ได้ จึงย้อนให้แปลงกับหมุดกลับมาตรงกันอัตโนมัติไม่ได้ — ระบบไม่ได้เปลี่ยนอะไร\n"
                "ให้ตรวจแปลงกับหมุดบริเวณที่แก้ แล้วจับคู่ให้ตรงกันเอง (Move Node / Add Node) จากนั้นกด 💾 บันทึก")
            return
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "เลเยอร์ถูกปิดแบบไม่เซฟ",
            f"เลเยอร์ '{disc_names}' ถูกปิดแก้ไขแบบไม่บันทึก → ข้อมูลกลับไป "
            "'จุดเริ่มเปิดแก้ไข' แล้ว (ไม่ใช่แค่ครั้งล่าสุด)\n\n"
            f"ต้องการย้อนเลเยอร์ที่ยังเปิดอยู่ ('{live_names}') กลับไปจุดเริ่มด้วย "
            "เพื่อให้ทั้งสองตรงกันไหม?\n"
            "⚠️ งานทั้งหมดที่ทำไว้ในเลเยอร์นี้ (ตั้งแต่เปิดแก้ไข) จะถูกย้อนทิ้ง",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No)
        if ans == QtWidgets.QMessageBox.Yes:
            for lyr, _n in live:
                stack = lyr.undoStack()
                while stack.canUndo():      # ย้อนสุด -> จุดเริ่ม session
                    stack.undo()
                self._purge_redo(lyr)       # ★ 2.3.7 (review DI-33)
            self.op_history.clear()          # ทุกอย่างถูกย้อนหมดแล้ว
            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage(
                "Undo", "ย้อนทั้งสองเลเยอร์กลับจุดเริ่มเปิดแก้ไขแล้ว", level=0, duration=8)   # ★ 2.3.7 UX-35
        # No -> ไม่ทำอะไร (คงสถานะไว้)

    @staticmethod
    def _purge_redo(lyr):
        """★ 2.3.7 (review DI-33) — ล้างขั้น Redo ของชั้นนี้ (หลังปลั๊กอินย้อนงานของตัวเอง)
        QGIS Redo ทำทีละชั้น ⇒ ถ้าเหลือไว้ กด Redo ชั้นเดียวได้งานคู่แปลง-หมุดกลับมาครึ่งเดียว
        วิธีเดียวกับ QgsVectorLayer::destroyEditCommand: push คำสั่ง obsolete ⇒ Qt ลบทุกขั้นเหนือ index แล้วทิ้งคำสั่งนั้น
        (index/สถานะ "มีการแก้ไข" ไม่เปลี่ยน) · ห้ามเรียกระหว่างมีคำสั่งแก้ไขเปิดค้าง (beginEditCommand)"""
        try:
            try:
                from qgis.PyQt.QtWidgets import QUndoCommand
            except ImportError:                       # Qt6 ย้ายไป QtGui
                from qgis.PyQt.QtGui import QUndoCommand
            st = lyr.undoStack()
            if st is None or not st.canRedo():
                return
            c = QUndoCommand()
            c.setObsolete(True)
            st.push(c)
        except Exception:
            pass

    def _op_drop_empty(self, lyr, before, after):
        """★ 2.3.7 (review DI-28) — ตาข่ายของ _op_commit: ทุกคำสั่งที่ op นี้ push บนชั้นนี้ (index before..after-1)
        เป็น "คำสั่งเปล่า" (beginEditCommand → endEditCommand โดยไม่มีการแก้ = มีชื่อแต่ไม่มีคำสั่งย่อย)
        ⇒ ย้อนทิ้ง + ล้าง Redo แล้วคืน True (ชั้นนี้ไม่นับใน op) · ย้อนคำสั่งที่ไม่มีคำสั่งย่อยไม่แตะข้อมูลเลย
        ไม่แตะเมื่อ: มีคำสั่งไหนมีคำสั่งย่อย/ชื่อว่าง (การแก้จริงของ QGIS ที่ไม่ได้ห่อด้วย beginEditCommand มีชื่อว่าง)
        · ยังมีคำสั่งเปิดค้าง · โปรเจกต์เปิด transaction group (คำสั่ง passthrough มีชื่อและไม่มีลูกทั้งที่แก้จริง)"""
        try:
            if before is None or after is None or after <= before:
                return False
            try:
                _prj = QgsProject.instance()
                if hasattr(_prj, "transactionMode"):          # 3.26+ (autoTransaction() เลิกใช้แล้ว)
                    if _prj.transactionMode() != Qgis.TransactionMode.Disabled:
                        return False
                elif _prj.autoTransaction():
                    return False
            except Exception:
                return False
            _act = getattr(lyr, "isEditCommandActive", None)
            if _act is not None and _act():
                return False
            st = lyr.undoStack()
            for i in range(before, after):
                c = st.command(i)
                if c is None or c.childCount() != 0 or not c.text():
                    return False
            for _ in range(after - before):
                if not st.canUndo():
                    break
                st.undo()
            self._purge_redo(lyr)
            return st.index() == before
        except Exception:
            return False

    @staticmethod
    def _layer_token(lyr):
        """★ 2.3.7 (review LC-02) — ตัวระบุ "วัตถุ C++ ของเลเยอร์" ที่คงที่ตลอดอายุวัตถุ (ไม่ขึ้นกับ Python wrapper ที่
        mapLayer() สร้างใหม่ได้ทุกครั้ง) · เลเยอร์ที่ถูกสร้างใหม่ (เปิดโปรเจกต์เดิมซ้ำ = layer id เดิม) ได้ค่าใหม่เอง"""
        try:
            t = lyr.property("_mlep_obj")
            if not t:
                t = "%s:%s" % (lyr.id(), os.urandom(6).hex())
                lyr.setProperty("_mlep_obj", t)
            return t
        except Exception:
            return id(lyr)

    def _saved_since_first_op(self, layers):
        """★ 2.3.7 (review DI-05) — ชื่อชั้นที่ถูกบันทึก (commit) หลังงานแรกของชั้นนั้นที่ยังอยู่ในประวัติ ↺
        (เทียบตัวนับ commit ตอนจบงานนั้นกับตอนนี้) — ตัดสินว่า "ย้อนกลับจุดเริ่มเปิดแก้ไข" ทำให้คู่ตรงกันจริงไหม"""
        out = []
        for lyr in layers:
            try:
                lid, nm = lyr.id(), lyr.name()
            except Exception:
                continue
            first = None
            for _op in self.op_history:
                for e in _op:
                    try:
                        if e[0] is not None and len(e) > 4 and e[4] is not None and e[0].id() == lid:
                            first = e[4]
                            break
                    except Exception:
                        continue
                if first is not None:
                    break
            if first is not None and self._commit_seq.get(lid, 0) != first and nm not in out:
                out.append(nm)
        return out

    def _dirty_layers_outside(self, pair):
        """★ 2.3.7 (review UX-40) — ชื่อชั้นนอกคู่ที่เลือกในคอมโบ ที่ยังมีงานแก้ค้างไม่บันทึก (แบบเดียวกับ _reload_blocker)
        ไม่นับชั้นชั่วคราวของปลั๊กอินเอง (เส้นที่วาด / จุดที่กรอกพิกัด)"""
        skip = set()
        for l in pair:
            try:
                if l is not None:
                    skip.add(l.id())
            except Exception:
                pass
        for _x in (getattr(self, "_line_layer_id", None), getattr(self, "_line_pt_layer_id", None)):
            if _x:
                skip.add(_x)
        own = {getattr(self, "LINE_LAYER_NAME", None), getattr(self, "LINE_PT_LAYER_NAME", None)}
        out = []
        try:
            for l in QgsProject.instance().mapLayers().values():
                try:
                    if l.id() in skip or l.name() in own:
                        continue
                    if hasattr(l, "isModified") and l.isEditable() and l.isModified():
                        out.append(l.name())
                except Exception:
                    continue
        except Exception:
            return []
        return sorted(out)

    def _buffer_utms(self, lyr, cap=2000):
        """★ 2.3.7 (review DI-05) — ชุด UTM (normalize) ของงาน "ที่กระทบคู่แปลง-หมุด" ที่ค้างใน edit buffer ของชั้นนี้:
        แก้รูป · เพิ่ม · ลบ · แก้ค่า UTM (ค่าเก่า+ค่าใหม่) — แก้คอลัมน์อื่น (SCORE/REMARK) ไม่นับ เพราะไม่ทำให้คู่พัง
        ค่าเดิมของที่ถูกลบ/ถูกเปลี่ยน UTM อ่านจาก provider · คืน None = ตรวจไม่ได้ (เกินเพดาน / ไม่มีคอลัมน์ UTM / ล้ม)"""
        try:
            if lyr is None or not lyr.isEditable():
                return set()
            b = lyr.editBuffer()
            if b is None:
                return set()
            uf = self._resolve_field(lyr, _UTM_FIELD_NAMES)
            if not uf:
                return None
            ui = lyr.fields().indexOf(uf)
            ch_u = [fid for fid, amap in b.changedAttributeValues().items() if ui in amap]
            now = set(b.changedGeometries().keys()) | set(b.addedFeatures().keys()) | set(ch_u)
            old = set(b.deletedFeatureIds()) | {fid for fid in ch_u if fid >= 0}
            if len(now) + len(old) > cap:
                return None
            out = set()
            for src, ids in ((lyr, sorted(now)), (lyr.dataProvider(), sorted(old))):
                if not ids:
                    continue
                it = src.getFeatures(QgsFeatureRequest().setFilterFids(ids)
                                     .setFlags(QgsFeatureRequest.NoGeometry))
                try:
                    for f in it:
                        u = f[uf]
                        if _txt(u):
                            out.add(_norm_utm(u))
                finally:
                    it.close()
            return out
        except Exception:
            return None

    def _half_save_pop(self, lid):
        it = self._half_save_items.pop(lid, None)
        if it is not None:
            try:
                self.iface.messageBar().popWidget(it)
            except Exception:
                pass
        # ★ 2.3.7 b17 (audit nit) — + ป้ายของชั้นนี้ที่ instance ก่อนโหลดใหม่ทิ้งไว้ · คืนบันทึกของมัน (ใช้ต่อใน _half_save_rolled_back)
        try:
            return _half_save_orphans_pop(self.iface.messageBar(), lid, keep=it)
        except Exception:
            return []

    def _half_save_clear(self, lid):
        """ชั้นนี้ลงฐานแล้ว (commit สำเร็จ) ⇒ ไม่ค้างครึ่งคู่ ⇒ ลืมบันทึก + เก็บป้าย"""
        self._half_saved.pop(lid, None)
        self._half_save_pop(lid)

    def _half_save_check(self, lid, keys):
        """★ 2.3.7 (review DI-05 · P1) — ชั้นหนึ่งของคู่เพิ่งลงฐานด้วยปุ่มของ QGIS (Save Layer Edits / ปิดแก้ไขแบบบันทึก /
        ตอบ Save ตอนปิดโปรแกรม) แต่อีกชั้นยังมีงานค้างของ UTM เดียวกัน ⇒ ในฐานตอนนี้แปลงกับหมุดไม่ตรงกัน
        (ด่านจับคู่ก่อน commit มองไม่เห็น เพราะเทียบ buffer กับ buffer) ⇒ ป้ายค้างบนแถบข้อความพร้อมปุ่มบันทึกอีกชั้น
        🔴 ห้ามเปิด modal จากทางนี้ (อาจเกิดระหว่าง QGIS ถาม Save/Discard ตอนปิดโปรแกรม)"""
        poly = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if poly is None or point is None:
            return
        if lid == poly.id():
            done, other = poly, point
        elif lid == point.id():
            done, other = point, poly
        else:
            return
        if not (other.isEditable() and other.isModified()):
            return
        okeys = self._buffer_utms(other)
        if okeys is not None and not okeys:
            return                              # อีกชั้นค้างแค่ค่าคอลัมน์อื่น (SCORE/REMARK) ⇒ คู่ไม่พัง
        common = None                           # None = พิสูจน์ไม่ได้ว่าเป็นคนละแปลง ⇒ เตือนไว้ก่อน
        if keys is not None and okeys is not None:
            common = keys & okeys
            if not common:
                return                          # งานค้างของอีกชั้นเป็นคนละแปลง ⇒ คู่ไม่พัง
        olid, oname, dname = other.id(), other.name(), done.name()
        self._half_saved[olid] = {"saved": dname, "keys": common}
        smp = ""
        if common:
            ks = sorted(common)
            smp = " (UTM " + ", ".join(ks[:5]) + (" …" if len(ks) > 5 else "") + ")"
        self._half_save_pop(olid)
        self._half_save_items[olid] = self._push_with_button(
            "⚠️ บันทึกไปชั้นเดียว",
            f"ชั้น '{dname}' ลงฐานแล้ว แต่ชั้น '{oname}' ยังมีงานค้างของแปลงเดียวกัน{smp} — "
            "แปลงกับหมุดในฐานยังไม่ตรงกันจนกว่าจะบันทึกอีกชั้น · อย่ากด Discard ชั้นนั้น",
            1, 0, f"💾 บันทึก '{oname}' ด้วย", lambda _l=olid: self._half_save_button(_l))
        # ★ 2.3.7 b17 (audit nit) — ป้าย + บันทึกติดตัวแถบ: instance หลังโหลดใหม่ (หรือตัวเฝ้าที่ unload ผูกไว้) เก็บป้ายนี้ได้
        _hs = self._half_save_items.get(olid)
        if _hs is not None:
            try:
                _hs.setProperty(_HALF_PROP, olid)
                _hs._mlep_half_rec = dict(self._half_saved[olid])
            except Exception:
                pass

    def _half_save_button(self, olid):
        """ปุ่ม "บันทึก <อีกชั้น> ด้วย" บนป้าย DI-05 — บันทึกคู่ในคอมโบผ่าน 💾 ปกติ (ด่านสิทธิ์/ด่านจับคู่ครบ)"""
        if not getattr(self, "_alive", True):
            return
        try:
            if QtWidgets.QApplication.activeModalWidget() is not None:
                return                          # มีกล่องเปิดอยู่ (เช่น QGIS กำลังถาม Save/Discard) ⇒ ไม่ซ้อนกล่อง
            ids = {l.id() for l in (QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                                    QgsProject.instance().mapLayer(self.point_cb.currentData())) if l is not None}
        except Exception:
            return
        if olid not in ids:
            self.iface.messageBar().pushMessage(
                "MLEP", "ชั้นนั้นไม่ได้เลือกอยู่ในกล่องด้านบนแล้ว — เลือกคู่ชั้นเดิมแล้วกด 💾 บันทึก", level=1, duration=8)
            return
        self.save_all_changes()

    def _half_save_rolled_back(self, lid):
        """★ 2.3.7 (review DI-05) — ทิ้งงาน (Discard/Rollback) ของชั้นที่อีกชั้นของคู่ลงฐานไปแล้ว
        ⇒ แปลงกับหมุดในฐานไม่ตรงกันถาวร ⇒ แถบแดงค้าง + บรรทัดใน Log (แท็บ MLEP) บอก UTM · ไม่ใช่ modal"""
        rec = self._half_saved.pop(lid, None)
        _orph = self._half_save_pop(lid)
        if rec is None and _orph:
            rec = _orph[0]          # ★ 2.3.7 b17 — ป้ายที่ instance ก่อนโหลดใหม่ทิ้งไว้ (บันทึกติดมากับป้าย)
        if rec is None:
            return
        try:
            nm = QgsProject.instance().mapLayer(lid).name()
        except Exception:
            nm = lid
        msg = _half_rb_text(nm, rec)            # ★ b17 ข้อความเดียวกับตัวเฝ้าป้ายที่ค้างหลังโหลดใหม่
        try:
            QgsMessageLog.logMessage("บันทึกไม่ครบคู่: " + msg, "MLEP", Qgis.Critical)
        except Exception:
            pass
        self.iface.messageBar().pushMessage("⚠️ แปลงกับหมุดไม่ตรงกันในฐาน", msg, level=2, duration=0)

    def save_all_changes(self):
        """commit ทั้งสองเลเยอร์ — เช็คผลจริงจาก provider (บน PostgreSQL commit ล้มเหลวได้:
        สิทธิ์ไม่พอ / constraint / connection หลุด) เดิมไม่เช็คเลยขึ้น 'สำเร็จ' เสมอ
        + ก่อน commit เตือนถ้าสิ่งที่จะบันทึกมี node ที่ไม่มีหมุดคู่ (ดู _pairing_issues)"""
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        self._pair_hl_reset()       # ★ 2.4.0 (review UX-09) บันทึกครั้งใหม่ ⇒ ล้างเครื่องหมาย "จุดที่ต้องแก้" ของรอบก่อน
        # ★ 2.3.7 (review DI-13) — สิทธิ์รายคอลัมน์ของทุกค่าที่แก้ใน buffer ต้องผ่านก่อน commit ชั้นแรก
        #   (QGIS commit ทีละชั้น: ชั้นแปลงลงฐานแล้วชั้นหมุดล้มเพราะสิทธิ์ = คู่แปลง-หมุดพังถาวร) · ตรวจก่อนด่านจับคู่
        #   เพราะถ้าบันทึกไม่ได้อยู่แล้ว ไม่ต้องถามเรื่องมุมไม่มีหมุดให้เสียเวลา
        _deny = self._commit_preflight([poly_lyr, point_lyr])
        if _deny:
            # ★ 2.4.0 (review DI-13) — หลังบันทึกได้ครึ่งเดียว (ชั้นหนึ่งของคู่ลงฐานแล้ว · _half_saved) ข้อความเดิม
            #   "ยังไม่ได้บันทึกอะไรเลย … ↺ Undo ของปลั๊กอิน" ไม่จริง (ชั้นนั้นลงฐานแล้ว · ประวัติ ↺ ถูกล้าง) และการย้อนทีละขั้น
            #   ของชั้นที่ค้างจะพาขั้นหลัง ๆ (เช่น หมุดที่ย้ายคู่กับแปลงที่ลงฐานแล้ว) ย้อนไปด้วย ⇒ ทางแก้เดียว = ขอสิทธิ์
            _hs = {}
            for _l in (poly_lyr, point_lyr):
                try:
                    if _l is not None and _l.id() in (getattr(self, "_half_saved", None) or {}):
                        _hs[_l.name()] = self._half_saved[_l.id()].get("saved") or ""
                except Exception:
                    continue
            if _hs:
                _sv = ", ".join(dict.fromkeys(v for v in _hs.values() if v)) or "อีกชั้นของคู่"
                _tail = (f"\n\nชั้น '{_sv}' ลงฐานข้อมูลไปแล้วตอนบันทึกครั้งก่อน (ย้อนไม่ได้) — "
                         f"งานที่ยังไม่ลงของชั้น '{', '.join(_hs)}' ยังอยู่ครบในเครื่อง (ยังไม่หาย)\n"
                         "ตอนนี้ข้อมูล 'แปลง' กับ 'หมุด' ในฐานข้อมูลยังไม่ตรงกันจนกว่าจะบันทึกส่วนที่เหลือได้\n"
                         "ให้ติดต่อผู้ดูแลบัญชีผู้ใช้ฐานข้อมูลทันที (แจ้งชื่อชั้น/คอลัมน์ข้างบน) ให้เพิ่มสิทธิ์ แล้วค่อยกด 💾 บันทึก\n"
                         "⚠️ ระหว่างนี้อย่ากด Discard / อย่าปิดโปรแกรม (ถ้าปิด งานส่วนที่ยังไม่ลงจะหาย และข้อมูลจะไม่ตรงกันถาวร)")
            else:
                _tail = ("\n\nยังไม่ได้บันทึกอะไรเลย (งานที่แก้ไว้ทั้งแปลงและหมุดยังอยู่ครบ ไม่หาย)\n"     # ★ 2.3.7 (audit C-08) เดิม "edit buffer"
                         # ★ 2.4.0 (review DI-13) — เดิมอ้าง "Edit ▸ Undo History" ซึ่งไม่มีในหน้าต่างหลักของ QGIS
                         "ให้ย้อนการแก้ไขนั้นก่อน (↺ Undo ของปลั๊กอิน หรือ Edit ▸ Undo ของ QGIS / แผง View ▸ Panels ▸ Undo/Redo) "
                         "แล้วบันทึกใหม่ · หรือแจ้งผู้ดูแลฐานข้อมูล\n"
                         + self._UNDO_LATER_WARN)
            self._ask(
                QtWidgets.QMessageBox.Warning, "บันทึกไม่ได้ — สิทธิ์ไม่พอ",
                "งานที่ค้างมีการแก้ไขที่บัญชีนี้ไม่มีสิทธิ์ทำในฐานข้อมูล:\n"          # ★ 2.3.7 (audit F7) รวมลบ/เพิ่มแถว
                + "\n".join("• " + x for x in _deny[:8])
                + _tail)
            return
        # ★ 2.4.0 (review DI-11) — ด่านล็อก L1: งานค้างย้าย/ลบแปลง L1 หรือหมุดล็อก (มักมาจากเครื่องมือของ QGIS ที่ไม่ผ่านด่านของปลั๊กอิน)
        #   ⇒ ถามก่อน (ค่าตั้งต้น = ไม่บันทึก) · ไม่บันทึก = ไม่ commit ชั้นใดเลย งานยังอยู่ใน buffer ให้ย้อนได้ · บันทึก = ไหลต่อตามเดิม
        #   ตรวจไม่ได้ ⇒ ลง Log แล้วไม่ขวาง (แบบด่านจับคู่)
        try:
            _l1 = self._l1_commit_hits([poly_lyr, point_lyr], poly_lyr)
            _l1_gap = getattr(self, "_l1_gap", None)     # ★ rc2 (audit A4-07) ตรวจไม่ครบ ⇒ บอกหลังบันทึก (ไม่ขวาง)
        except Exception:
            _l1 = None
            _l1_gap = "ตรวจไม่ได้ (เกิดข้อผิดพลาด — รายละเอียดใน Log Messages แท็บ MLEP)"
            _log_exc("ด่าน L1 ก่อนบันทึก (ปุ่ม 💾) ตรวจไม่ได้")
        if _l1 and any(_l1.values()):
            _t, _b = self._l1_hits_text(_l1)
            if self._ask(QtWidgets.QMessageBox.Question, _t, _b,
                         QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                         QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
                return
        # ★ ระหว่างตรวจกติกาเหล็ก อาจใช้เวลาสักครู่บนงานก้อนใหญ่ -> ขึ้น cursor นาฬิกาทราย
        #   ให้เห็นว่า "กำลังทำงาน" ไม่ใช่ "ค้าง" (2026-08-05)
        try:
            QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
            iss = self._pairing_issues(poly_lyr, point_lyr)
        finally:
            try:
                QtWidgets.QApplication.restoreOverrideCursor()
            except Exception:
                pass
        # ★ 2.3.7 (review ER-01) — อ่านเหตุ "ไม่ได้ตรวจ/ตรวจไม่ครบ" ทันทีหลังตรวจ (เดิมดูเหมือน "ไม่พบปัญหา")
        _gap = self._pairing_gap()
        _gap_n = getattr(self, "_pairing_last_n", None)
        if iss and iss[0]:
            # ★ ใช้ _ask (parent = หน้าต่างหลัก + ยกขึ้นหน้าสุด) — เดิมผูกกับ self.dlg
            #   แล้วกล่องไปโผล่หลังจอ = ผู้ใช้เห็นเป็นโปรแกรมค้าง (เหตุ 19:03 น. 5 ส.ค. 69)
            # ★ 2.3.7 (review UX-39 · DI-48 · DI-47) — นับ/ตั้งชื่อแยกชนิด + สาเหตุ/คำแนะนำตามชนิด (ปุ่มตั้งต้นยัง No)
            _title, _summ, _body = self._pairing_text(iss, saved=False, why=_gap)
            ans = self._ask(
                QtWidgets.QMessageBox.Question, "ตรวจพบ" + _title, _body,
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if ans != QtWidgets.QMessageBox.Yes:
                try:
                    self._pair_hl_offer([iss])  # ★ 2.4.0 (review UX-09) ไม่บันทึก ⇒ ทำเครื่องหมายทุกจุดให้ไล่แก้
                except Exception:
                    _log_exc("ทำเครื่องหมายจุดที่ต้องแก้ (UX-09)")
                return
        failed = []   # [(ชื่อเลเยอร์, ข้อความ error)]
        saved = []    # ชื่อเลเยอร์ที่ "ลงฐานข้อมูลจริงแล้ว" (ย้อนกลับไม่ได้)
        partial = []  # ★ 2.3.7 (review DI-29) [(ชื่อเลเยอร์, "ลงแล้ว", "ยังไม่ลง")] commit ที่ล้มแต่บางขั้นลงฐานไปแล้ว
        _reopen = []  # ★ 2.4.0 (review MT-16) ชื่อชั้นที่ commit แล้วเปิดโหมดแก้ไขกลับไม่ได้
        # ปุ่มนี้ตรวจ+ถามไปแล้ว -> กัน hook beforeCommitChanges เตือนซ้ำ (reset เสมอใน finally)
        self._pair_warn_ack = True
        self._l1_save_ack = True            # ★ 2.4.0 (review DI-11) ด่าน L1 ถาม/ผ่านไปแล้ว ⇒ hook ไม่ถามซ้ำ
        progress = QtWidgets.QProgressDialog("กำลังบันทึกข้อมูลและซิงค์กับฐานข้อมูล...", None, 0, 0, self.iface.mainWindow())
        progress.setWindowTitle("Multi-Layer Edit Pro")
        progress.setWindowModality(QtCore.Qt.WindowModal)
        progress.setCancelButton(None)
        progress.show()
        QtCore.QCoreApplication.processEvents()
        try:
            for lyr in [poly_lyr, point_lyr]:
                if lyr and lyr.isEditable():
                    # ★ นับเป็น "ลง DB จริง (ย้อนไม่ได้)" เฉพาะเลเยอร์ที่มีการแก้ค้างอยู่จริง
                    #   (commit เลเยอร์ที่ไม่มีอะไรแก้ = no-op สำเร็จเสมอ — ไม่ควรไปโผล่ใน
                    #    dialog "บันทึกบางส่วน" ให้คนตกใจ + ลบประวัติ undo ฟรี)
                    try:
                        had_changes = lyr.isModified()
                    except Exception:
                        had_changes = True          # ไม่รู้ = ถือว่ามี (ระวังไว้ก่อน)
                    _cnt0 = self._buf_counts(lyr)       # ★ 2.3.7 (review DI-29)
                    if lyr.commitChanges():
                        if had_changes:
                            saved.append(lyr.name())
                        # ★ 2.4.0 (review MT-16) — เปิดโหมดแก้ไขกลับแล้วตรวจผล (เดิมไม่ดู ⇒ ชั้นค้างนอกโหมดแก้ไขเงียบ ๆ)
                        #   แจ้งครั้งเดียวหลังปิดกล่องความคืบหน้า (ดู _reopen ด้านล่าง)
                        if not self._ensure_editing(lyr, warn=False):
                            _reopen.append(lyr.name())
                    else:
                        failed.append((lyr.name(), "\n".join(lyr.commitErrors())))
                        # ★ 2.3.7 (review DI-29) — QGIS commit เป็นขั้น ๆ (แก้รูป/ค่า · ลบ · เพิ่ม) แต่ละขั้นเป็น transaction ของ
                        #   provider เอง และล้างขั้นที่สำเร็จออกจาก buffer ⇒ "ล้ม" ไม่ได้แปลว่า "ยังไม่มีอะไรลงฐาน"
                        #   ⇒ เทียบจำนวนใน buffer ก่อน/หลัง: ลดลง = ลงฐานไปแล้วบางขั้น (ไม่แกะข้อความ SUCCESS: ที่แปลตามภาษา)
                        _pt = self._buf_partial(_cnt0, self._buf_counts(lyr))
                        if _pt:
                            partial.append((lyr.name(),) + _pt)
                        # ★ หยุดทันที — อย่า commit เลเยอร์ถัดไป (2026-08-05)
                        #   เดิมไหลไป commit ตัวที่สอง = สร้าง desync ถาวรที่หลีกเลี่ยงได้ (หมุดลงแต่แปลงไม่ลง)
                        #   (★ 2.3.7 DI-29 — คอมเมนต์เดิม "ตอนตัวแรกล้ม ยังไม่มีอะไรลง DB เลย" ไม่จริงเสมอ: ดูด้านบน)
                        break
        finally:
            progress.close()
            # ★ 2.3.7 (review LC-11) — เดิมแค่ close() ⇒ กล่องค้างเป็นลูกของหน้าต่างหลักทุกครั้งที่กด 💾 (~110 KB/ครั้ง ·
            #   พนักงานกดบันทึกหลายร้อยครั้งต่อวัน ⇒ หน่วยความจำของ QGIS โตเรื่อย ๆ จนปิดโปรแกรม)
            progress.deleteLater()
            self._pair_warn_ack = False
            self._l1_save_ack = False
        if iss and iss[0]:
            # ★ 2.4.0 (review UX-09) ตอบบันทึกต่อ ⇒ ทำเครื่องหมายหลัง commit กลับมาแล้ว (ไม่สร้าง canvas item ระหว่าง commit)
            try:
                self._pair_hl_offer([iss])
            except Exception:
                _log_exc("ทำเครื่องหมายจุดที่ต้องแก้ (UX-09)")
        if _reopen:
            # ★ 2.4.0 (review MT-16) — แจ้งก่อนกล่อง/ข้อความผลบันทึกทุกทาง (แถบค้างจนปิดเอง ⇒ ยังเห็นหลังปิดกล่อง)
            _rn = ", ".join("'%s'" % n for n in _reopen)
            # ★ rc1 (F8 · §5.1 MT-16) — แถบเดิมค้างไม่มีกำหนด (duration 0) แม้เปิดได้ภายหลัง ⇒ เวลาจำกัด + ถ้อยคำอดีต ("ตอนบันทึก")
            #   + ลง Log ไว้ให้ตามต่อ (ปิดแถบแล้วยังมีร่องรอย)
            _rmsg = (f"ตอนบันทึก เปิดโหมดแก้ไขชั้น {_rn} กลับไม่ได้ — "
                     "สิ่งที่บันทึกแล้วไม่หาย · ถ้าเครื่องมือของปลั๊กอินยังแก้ชั้นนี้ไม่ได้ ให้ตรวจการเชื่อมต่อฐานข้อมูลแล้วลองอีกครั้ง "
                     "ถ้ายังเปิดไม่ได้ให้แจ้งผู้ดูแล")
            try:
                QgsMessageLog.logMessage("Save: " + _rmsg, "MLEP", Qgis.Warning)
            except Exception:
                pass
            self.iface.messageBar().pushMessage("Save", _rmsg, level=1, duration=30)
        if failed:
            names = ", ".join(n for n, _ in failed)
            # ★ 2.3.7 (review ER-03/SE-03) — ข้อความจากฐาน (commitErrors) ปิดรหัสผ่านก่อนแสดง + ลง Log ระดับ Critical
            #   (เดิมขึ้นแค่ในกล่อง — ปิดกล่องแล้วไม่เหลือร่องรอยให้ผู้ดูแลตามเรื่อง)
            detail = _scrub("\n\n".join(f"• {n}:\n{e}" for n, e in failed))
            try:
                QgsMessageLog.logMessage("บันทึกไม่สำเร็จ (commitErrors):\n" + detail, "MLEP", Qgis.Critical)
            except Exception:
                pass
            # ★ 2.4.0 (review DI-13) — สาเหตุกำหนดคำแนะนำ: สิทธิ์ไม่พอ = กดบันทึกซ้ำไม่มีวันผ่าน (ค่านั้นยังค้างใน buffer)
            #   ⇒ บอกว่าตาราง/คอลัมน์ไหน + ให้ติดต่อผู้ดูแลบัญชีผู้ใช้ฐานข้อมูล · อย่างอื่น (เน็ตหลุด/ฐานไม่ตอบ) ⇒ ลองบันทึกใหม่ได้ตามเดิม
            _perm, _perm_items = self._commit_fail_perm(failed, (poly_lyr, point_lyr))
            _perm_txt = ""
            if _perm:
                _perm_txt = ("ฐานข้อมูลแจ้งว่าบัญชีที่ใช้อยู่ไม่มีสิทธิ์แก้ไขตาราง/คอลัมน์นี้"
                             + (":\n" + "\n".join("  – " + x for x in _perm_items[:8]) if _perm_items else "")
                             + "\n")
            if saved or partial:
                # ★ บันทึกสำเร็จ "ครึ่งเดียว" (2026-08-04): QGIS commit ทีละเลเยอร์ ไม่มี transaction ร่วม
                #   ⇒ ย้อนเลเยอร์ที่ลงไปแล้วอัตโนมัติไม่ได้ · เดิมข้อความบอกว่า "ข้อมูลยังไม่ถูกเซฟ" ทุกกรณี
                #   = หลอก เพราะอีกเลเยอร์ลง DB ถาวรไปแล้ว ⇒ แปลงกับหมุดไม่ตรงกันโดยไม่มีใครรู้
                #   undo ของเลเยอร์ที่ commit ไปแล้วถูก QGIS ล้าง ⇒ ประวัติ undo ใช้ต่อไม่ได้ ต้องเคลียร์
                self.op_history.clear()
                self._op_baseline = None
                # ★ 2.3.7 (review DI-29) — บอกตามจริงทีละชั้น: ลงทั้งชั้น / ลงบางส่วน (ขั้นไหนลงแล้ว ขั้นไหนยัง) / ไม่ลงเลย
                _pn = {x[0] for x in partial}
                _fail_only = [n for n, _ in failed if n not in _pn]
                _head = (([f"✅ ลงฐานข้อมูลแล้ว (ย้อนไม่ได้): {', '.join(saved)}"] if saved else [])
                         + [f"⚠️ ลงฐานข้อมูลบางส่วน (ย้อนไม่ได้): {n} — {d} ลงแล้ว · {l} ยังไม่ลง" for n, d, l in partial]
                         + ([f"❌ บันทึกไม่สำเร็จ: {', '.join(_fail_only)}"] if _fail_only else []))
                # ★ 2.3.7 (review DI-05) — ชั้นในคู่ที่ยังมีงานค้าง: ถ้าภายหลังถูก Discard ⇒ แจ้งแดง + log บอก UTM
                self._half_save_mark_pending((poly_lyr, point_lyr), saved + [x[0] for x in partial])
                self._ask(
                    QtWidgets.QMessageBox.Critical, "⚠️ บันทึกสำเร็จเพียงบางส่วน",
                    "\n".join(_head) + "\n\n"
                    "ตอนนี้ข้อมูล 'แปลง' กับ 'หมุด' ในฐานข้อมูลอาจไม่ตรงกัน\n"
                    + ((f"• {_perm_txt}"            # ★ 2.4.0 (review DI-13) สิทธิ์ไม่พอ: ไม่บอกให้กดบันทึกซ้ำ (ไม่มีวันผ่าน)
                        "• งานส่วนที่ยังไม่ลงยังอยู่ครบในเครื่อง (ยังไม่หาย) แต่กด 💾 บันทึก ซ้ำจะไม่สำเร็จจนกว่าบัญชีนี้จะได้สิทธิ์\n"
                        "• ให้ติดต่อผู้ดูแลบัญชีผู้ใช้ฐานข้อมูลทันที (แจ้งชื่อตาราง/คอลัมน์ข้างบน) ให้เพิ่มสิทธิ์ แล้วค่อยกด 💾 บันทึก\n"
                        # ★ 2.4.0 (review DI-13) — ตัดคำแนะนำ "ย้อนการแก้ค่านั้น (Edit ▸ Undo History) แล้วบันทึกส่วนที่เหลือ":
                        #   เมนูนั้นไม่มีในหน้าต่างหลัก และ undo ของชั้นย้อนทีละขั้นจากล่าสุด ⇒ ขั้นหลัง ๆ (หมุดที่ย้ายคู่กับแปลง
                        #   ที่ลงฐานแล้ว) ถูกย้อนไปด้วย แล้วบันทึกต่อ = แปลงกับหมุดไม่ตรงกันถาวรโดยไม่มีด่านไหนจับได้
                        "• ⚠️ ระหว่างนี้อย่ากด Discard / อย่าปิดโปรแกรม / อย่าย้อนงานของชั้นที่ค้าง\n") if _perm else
                       ("• งานส่วนที่ยังไม่ลงยังอยู่ครบในเครื่อง (ยังไม่หาย) — กด 💾 บันทึก อีกครั้ง\n"
                        "• ถ้ายังไม่สำเร็จ ให้แจ้งผู้ดูแลทันที และ ⚠️ อย่ากด Discard / อย่าปิดโปรแกรม\n"))     # ★ 2.3.7 UX-29
                    + f"  (ถ้าปิด งานส่วนที่ยังไม่ลงจะหาย และข้อมูลจะไม่ตรงกันถาวร)\n\n{detail}")
            else:
                # ไม่มีเลเยอร์ไหนลงเลย -> buffer ครบทั้งคู่ ปลอดภัย ไม่ต้องเคลียร์ประวัติ undo
                # (★ 2.3.7 DI-29 — "ไม่มีขั้นไหนลง" ตรวจจากจำนวนใน buffer ก่อน/หลังแล้ว ไม่ได้เดาจากผล True/False)
                self._ask(
                    QtWidgets.QMessageBox.Critical, "บันทึกไม่สำเร็จ",
                    f"เลเยอร์ '{names}' บันทึกลงฐานข้อมูลไม่สำเร็จ — ข้อมูลยังไม่ถูกเซฟ!\n"
                    f"งานที่แก้ไว้ยังอยู่ครบในเครื่อง (ยังไม่หาย)\n"
                    # ★ 2.4.0 (review DI-13) สิทธิ์ไม่พอ ⇒ บอกตาราง/คอลัมน์ + ทางแก้ (บันทึกซ้ำไม่ช่วย)
                    + (f"\n{_perm_txt}กดบันทึกซ้ำจะไม่สำเร็จจนกว่าบัญชีนี้จะได้สิทธิ์ — ติดต่อผู้ดูแลบัญชีผู้ใช้ฐานข้อมูลให้เพิ่มสิทธิ์ "
                       "หรือย้อนการแก้ค่านั้น (↺ Undo ของปลั๊กอิน หรือ Edit ▸ Undo ของ QGIS / แผง View ▸ Panels ▸ Undo/Redo) "
                       "แล้วบันทึกใหม่\n" + self._UNDO_LATER_WARN + "\n" if _perm else "")
                    + f"\n{detail}")
            return
        if not saved:
            # ไม่มีเลเยอร์ไหนถูก commit จริง (ไม่ได้อยู่ในโหมดแก้ไข / ไม่มีการแก้ค้าง)
            # -> อย่ารายงานว่า "บันทึกสำเร็จ" และอย่าล้างประวัติ undo (2026-08-05)
            # ★ 2.3.7 (review UX-40) — เดิมดูแค่สองชั้นในคอมโบ ⇒ งานค้างในคู่ชั้นอื่น (สาขาอื่น) ได้ "ไม่มีอะไรต้องบันทึก"
            #   ⇒ บอกชื่อชั้นที่ยังค้าง · ไม่ commit ให้เอง (ด่านจับคู่ผูกกับคู่ที่เลือกในคอมโบ)
            _others = self._dirty_layers_outside((poly_lyr, point_lyr))
            if _others:
                self.iface.messageBar().pushMessage(
                    "Save", "ชั้นที่เลือกไม่มีงานค้าง แต่ยังมีงานค้างใน: "
                    + ", ".join(_others[:5]) + (" ..." if len(_others) > 5 else "")
                    + " — เลือกคู่ชั้นนั้นในกล่องด้านบนแล้วกดบันทึก", level=1, duration=10)
                return
            self.iface.messageBar().pushMessage(
                "Save", "ไม่มีการแก้ไขค้างอยู่ — ไม่มีอะไรต้องบันทึก", level=0, duration=4)
            return
        # commitChanges ล้าง undo-stack ของ QGIS -> ประวัติเก่าย้อนไม่ได้แล้ว เคลียร์ทิ้ง
        self.op_history.clear()
        self._op_baseline = None
        self._unsaved_since = None      # บันทึกแล้ว -> เริ่มนับเวลางานค้างใหม่
        if _l1_gap:
            # ★ rc2 (audit A4-07) — ด่าน L1 ตรวจไม่ครบ ⇒ ไม่ขึ้น "บันทึกสำเร็จ" เฉย ๆ (เดิมลงแค่ Log)
            self.iface.messageBar().pushMessage("Save", f"บันทึกแล้ว แต่ตรวจการแก้แปลง/หมุด L1 ไม่ครบ — {_l1_gap}",
                                                level=1, duration=15)
            if not _gap:
                return
        if _gap:
            # ★ 2.3.7 (review ER-01) — ด่านจับคู่ถูกข้าม/ตรวจไม่ครบ ⇒ ไม่ขึ้น "บันทึกสำเร็จ" เฉย ๆ (ไม่บล็อกการบันทึก)
            _h, _r = self._pairing_gap_th(_gap, _gap_n)
            self.iface.messageBar().pushMessage("Save", f"บันทึกแล้ว แต่{_h} — {_r}", level=1, duration=12)
            return
        if _reopen:
            return      # ★ 2.4.0 (review MT-16) แถบเตือน "หลังบันทึก เปิดโหมดแก้ไข…กลับไม่ได้" ขึ้นแล้วด้านบน — ไม่ทับด้วยแถบเขียว
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3, duration=3)

    @staticmethod
    def _buf_counts(lyr):
        """★ 2.3.7 (review DI-29) — จำนวนงานใน edit buffer แยกขั้น (แก้รูป, แก้ค่า, ลบ, เพิ่ม) · None = อ่านไม่ได้"""
        try:
            b = lyr.editBuffer()
            if b is None:
                return None
            return (len(b.changedGeometries()), len(b.changedAttributeValues()),
                    len(b.deletedFeatureIds()), len(b.addedFeatures()))
        except Exception:
            return None

    @staticmethod
    def _buf_partial(c0, c1):
        """★ 2.3.7 (review DI-29) — commit ที่ล้มได้ลงฐานไปแล้วบางขั้นไหม (จำนวนใน buffer ลดลง)
        คืน ("ลงแล้ว", "ยังไม่ลง") เป็นข้อความ หรือ None = ไม่มีขั้นไหนลง/อ่านไม่ได้"""
        if not c0 or not c1:
            return None
        names = ("แก้รูป", "แก้ค่า", "ลบ", "เพิ่ม")
        done = [f"{n} {a - b:,} รายการ" for n, a, b in zip(names, c0, c1) if b < a]
        if not done:
            return None
        left = [f"{n} {b:,} รายการ" for n, b in zip(names, c1) if b]
        return " · ".join(done), (" · ".join(left) or "ไม่มี")

    def _half_save_mark_pending(self, pair, saved_names):
        """★ 2.3.7 (review DI-05/DI-29) — 💾 บันทึกได้ครึ่งเดียว: จำชั้นในคู่ที่ยังมีงานค้าง (UTM ไม่รู้ ⇒ จดตอน Discard)"""
        for l in pair:
            try:
                if l is not None and l.isEditable() and l.isModified():
                    self._half_saved[l.id()] = {"saved": ", ".join(saved_names), "keys": None}
            except Exception:
                continue
