# -*- coding: utf-8 -*-
"""QThread สำหรับงาน network ที่ใช้เวลานาน (ไม่ให้ QGIS ค้าง)

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore
from qgis.core import Qgis, QgsMessageLog
from ..core.util import _log_exc, _net_err_text, _scrub


# ============================================================
#  DOL iLands — เครื่องมือคลิกเลือกแปลง + worker เรียก API
# ============================================================

class _FnWorker(QtCore.QThread):
    """รัน callable (blocking network/IO) ใน thread แยก — done(result) / fail(exception)
    ใช้ผ่าน MultiLayerEditPro._run_net เพื่อไม่ให้ QGIS ค้างระหว่างรอ server"""
    done = QtCore.pyqtSignal(object)
    fail = QtCore.pyqtSignal(object)

    def __init__(self, fn):
        super().__init__()
        self._fn = fn

    def run(self):
        try:
            self.done.emit(self._fn())
        except Exception as e:
            self.fail.emit(e)


class ParcelLookupWorker(QtCore.QThread):
    """ระวาง(attribute) -> PARCEL_SEQ ผ่าน ArcGIS + UDM (public, ไม่ต้อง login)
    ★ 2.4.2 (audit rc3) — lis_more=True = E8: ค้นทะเบียน iLands ต่อเมื่อแผนที่บอกไม่มีทะเบียน/ยืนยันไม่ได้/คีย์อยู่ชั้นรอจด
      ★ rc4 (เจ้าของงาน 21 ต.ค. 69) ทุกปุ่มที่ถามทะเบียนใช้ True (🔍 📐 📝 ➕) · ค่าปริยาย False = แบบ rc2 (เครื่องมือ/เทส)
      · need_area=False = ไม่เปิดหน้ารายละเอียดของทะเบียน (📐 ไม่ใช้เนื้อที่)"""
    done = QtCore.pyqtSignal(object)   # dict หรือ None
    fail = QtCore.pyqtSignal(str)

    def __init__(self, attrs, zone=47, lis_more=False, need_area=True):
        super().__init__()
        self.attrs = attrs
        self.zone = zone
        self.lis_more = bool(lis_more)
        self.need_area = bool(need_area)

    def run(self):
        from .. import dol_api
        try:
            a = self.attrs
            if a.get("utmdoc"):
                # ★ 2.4.8 ขั้น E1 — โฉนดตราจอง/ตราจองฯ ⇒ ทะเบียน iLands หน้าของชนิดนั้นด้วยคีย์ UTM (แผนที่กรมผูกทะเบียนชนิดนี้ไม่ได้)
                res = dol_api.lookup_utm_doc(a.get("doc"), a["m1"], a["m2"], a["m3"], a["m4"], a["scale"], a["landno"],
                                             office_seq=a.get("office_seq"), need_area=self.need_area,
                                             seq=a.get("seq") or None, row=a.get("row") or None)
            elif a.get("docsearch"):
                # ★ 2.4.8 ขั้น E — เอกสารกลุ่ม ข ⇒ ทะเบียน iLands หน้าของชนิดนั้นด้วยเลขที่ (+ หมู่/ตำบล) · seq/row = ฉบับที่เลือกจากรายการ
                res = dol_api.lookup_doc_by_no(a.get("doc"), a.get("no"), a.get("moo"), a.get("tambol"),
                                               office_seq=a.get("office_seq"), need_area=self.need_area,
                                               seq=a.get("seq") or None, row=a.get("row") or None,
                                               amphur=a.get("amphur") or None)       # ★ 2.4.8 อำเภอ (สาขาที่มีหลายอำเภอ)
            elif a.get("air"):
                # ★ 2.4.8 ขั้น D — น.ส.3 ก (คีย์ระวางรูปถ่าย) ⇒ ทะเบียน iLands หน้า QNS3K ตรง (แผนที่กรมผูกกับรูปแปลงไม่ได้)
                res = dol_api.lookup_parcel_ns3k(a["m1"], a["m2"], a["m4"], a["scale"], a["landno"],
                                                 office_seq=a.get("office_seq"), need_area=self.need_area,
                                                 seq=a.get("seq") or None, row=a.get("row") or None)    # ★ ขั้น E3 ฉบับที่เลือก
            else:
                res = dol_api.lookup_parcel_by_rawang(
                    a["m1"], a["m2"], a["m3"], a["m4"], a["scale"], a["landno"],
                    zone=self.zone, near_xy=a.get("near_xy"), probe_xy=a.get("probe_xy"),
                    office_seq=a.get("office_seq"),                             # ★ 2.3.10 ล็อกสาขา
                    lis_more=self.lis_more, need_area=self.need_area)           # ★ 2.4.2 E8 เฉพาะ 🔍/📐
            self.done.emit(res)
        except Exception as e:
            # ★ 2.3.7 (review ER-06) — เหตุสั้นภาษาไทย (เดิมข้อความดิบของ requests/KeyError/ValueError ในกล่อง "DOL ผิดพลาด")
            from .. import dol_api
            if not isinstance(e, dol_api.DOLError):
                _log_exc("ค้นแปลงจากระบบกรม (ระวาง → PARCEL_SEQ) ล้ม")
            elif getattr(e, "detail", ""):
                # ★ 2.3.7 b19 (doc-verify E8) — คำตอบดิบจากระบบกรม (เช่น error ของ ArcGIS) ลง Log ให้ผู้ดูแล ไม่ใส่ในข้อความของพนักงาน
                try:
                    QgsMessageLog.logMessage("ค้นแปลงจากระบบกรม (ระวาง → PARCEL_SEQ) ไม่สำเร็จ: %s — คำตอบจากระบบกรม: %s"
                                             % (e, _scrub(str(e.detail))[:2000]), "MLEP", Qgis.Warning)
                except Exception:
                    pass
            self.fail.emit(f"ค้นหาไม่สำเร็จ: {_net_err_text(e)}")
