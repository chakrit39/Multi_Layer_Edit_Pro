# -*- coding: utf-8 -*-
"""เช็กเวอร์ชันใหม่ ดาวน์โหลด ติดตั้ง และ reload ตัวเอง

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import os
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import Qgis, QgsMessageLog, QgsProject
from ..core.const import _MLEP_MAIN_FILE
from ..core.util import (_log_err, _log_exc, _meta_value, _parse_version, _reason_text, _resp_text, _scrub, _vkey)
from ..services.update_core import (_install_update_zip, _rollback_failed_update, _upd_check_disk, _upd_get, _upd_net_text,
                                    _UpdateInstallError, UPDATE_V_URL, UPDATE_Z_URL)
from ..services.workers import _FnWorker
from ..ui.qt_helpers import _mlep_debris_clear


class UpdaterMixin:
    """เช็กเวอร์ชันใหม่ ดาวน์โหลด ติดตั้ง และ reload ตัวเอง"""

    @staticmethod
    def _read_version(default="", path=None):
        """อ่านเลขรุ่นจาก metadata.txt (แหล่งเดียวกับที่ QGIS และตัวอัปเดตใช้)

        ★ 2.3.7 (review DI-42) — อ่านแบบ configparser (ยอม 'version = 2.3.7' · BOM) · อ่านไม่ได้ = '' + บันทึก Log
          เดิมรับแค่บรรทัดที่ขึ้นต้น 'version=' เป๊ะ ๆ แล้วถอยไป '2.1.0' ⇒ ปลั๊กอินเข้าใจว่าตัวเองเก่ามาก"""
        mp = path or os.path.join(os.path.dirname(_MLEP_MAIN_FILE), "metadata.txt")
        try:
            with open(mp, encoding="utf-8-sig") as fh:
                v = _meta_value(fh.read(), "version")
            if v:
                return v
            why = "ไม่มีค่า version"
        except Exception as e:
            why = str(e)
        try:
            QgsMessageLog.logMessage("อ่านเลขรุ่นจาก metadata.txt ไม่ได้ (%s)" % why, "MLEP", Qgis.Warning)
        except Exception:
            pass
        return default

    def _auto_check_update(self):
        """เช็คเวอร์ชันใหม่ให้อัตโนมัติ — ครั้งเดียวต่อการเปิด QGIS
        เงียบสนิทถ้าเป็นเวอร์ชันล่าสุดอยู่แล้ว หรือเน็ตไม่ถึง (ไม่มี dialog/progress ใด ๆ)
        เจอของใหม่เท่านั้นถึงจะถามว่าจะอัปเดตไหม
        (เดิมต้องกดปุ่ม 🚀 Check Update เอง -> ของใหม่ไม่ถึงพนักงานจนกว่าจะมีคนไล่บอกทีละคน)"""
        if getattr(self, "_auto_upd_done", False):
            return
        self._auto_upd_done = True

        def _check():
            res = _upd_get(UPDATE_V_URL, 8)          # ★ 2.3.7 b19 (doc-verify E6) ใบรับรองแบบระบบกรม (เดิม requests.get)
            res.raise_for_status()
            return _resp_text(res)           # ★ 2.3.7 (review DI-42) — ตัด BOM

        w = _FnWorker(_check)
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)      # กัน GC เก็บ worker ระหว่างรัน

        def _release(_w=w):
            # ★ 2.3.7 (review LC-01 · P0) — ปล่อยตอน finished เท่านั้น (เดิมลบใน slot done/fail = เสี่ยง qFatal
            #   โดยเฉพาะทางที่ "ไม่พบรุ่นใหม่" ซึ่งเกิดทุกครั้งที่เปิดปลั๊กอิน)
            try:
                self._net_workers.remove(_w)
            except ValueError:
                pass
            _w.deleteLater()

        def _ok(new_version, _tries=0):
            if not getattr(self, "_alive", True):
                return                       # ปลั๊กอินถูก unload/reload ระหว่างรอ — instance นี้ตายแล้ว
            try:
                # ★ 2.3.7 (review DI-42) — อ่านเลขรุ่นไม่ได้ = เงียบตามเดิม แต่บันทึก Log ไว้ให้ตามได้
                nv = _parse_version(new_version)
                if nv is None:
                    QgsMessageLog.logMessage(
                        "ตรวจอัปเดตอัตโนมัติ: อ่านเลขรุ่นจากเซิร์ฟเวอร์ไม่ได้ (%r)" % str(new_version)[:40],
                        "MLEP", Qgis.Warning)
                    return
                if nv <= _vkey(self.version):
                    return
                # ★ 2.3.7 (review DU-11-D) — ปุ่ม 🚀 กำลังตรวจ/ดาวน์โหลดอยู่ ⇒ ไม่ถามซ้อน
                #   (เดิมได้กล่องถาม 2 ใบ + ดาวน์โหลด 2 ตัวแข่งกันสลับโฟลเดอร์ปลั๊กอิน)
                if getattr(self, "_updating", False):
                    return
                # ★ 2.3.7 (review LC-08) — มีกล่อง modal เปิดค้าง (ยืนยันลบ · กล่องชื่อหมุด ฯลฯ) ⇒ รอให้ปิดก่อน
                #   เดิมถาม/ดาวน์โหลด/reload ซ้อนอยู่ใน loop ของกล่องนั้น ขณะที่โค้ดของกล่องยังค้างบน stack
                # ★ 2.3.7 (audit LIFE-07) — + กำลังกด/ลากเมาส์ (Move Node ลากหมุด · กล่องเลือก) ⇒ รอเหมือนมีกล่องเปิด
                #   กล่องถามที่เด้งกลางการลากกินการปล่อยเมาส์ ⇒ เครื่องมือค้าง "กำลังลาก" แล้วคลิกถัดไปย้ายหมุด
                if self._modal_open() or self._gesture_busy():
                    if _tries < 240:          # 0.5 วิ × 240 = 2 นาที แล้วเลิก (กด 🚀 เองได้เสมอ)
                        QtCore.QTimer.singleShot(500, lambda: _ok(new_version, _tries + 1))
                    return
                self._updating = True         # prompt_update คืนธงเองทุกทางออก (No / ดาวน์โหลดเสร็จ / ล้ม)
                self.prompt_update(new_version, UPDATE_Z_URL)
            except Exception:
                self._updating = False
                _log_exc("ตรวจอัปเดตอัตโนมัติ: ถามติดตั้งรุ่นใหม่ไม่สำเร็จ")      # ★ 2.3.7 (ER-03) เดิมกลืนเงียบ

        w.finished.connect(_release)
        w.done.connect(_ok)                  # เน็ตไม่ถึง/GitHub ล่ม (fail) = เงียบ ไม่กวนผู้ใช้
        # ★ 2.3.7 (review ER-03) — ล้ม = ยังเงียบกับผู้ใช้ แต่จดเหตุสั้น ๆ ลง Log (ระดับ Info · ไม่มี traceback ให้รก
        #   — เครื่องที่ไม่มีเน็ตจะเจอทุกครั้งที่เปิด) · ผู้ดูแลตามได้ว่าทำไมไม่เคยเห็นแจ้งรุ่นใหม่
        w.fail.connect(lambda e: QgsMessageLog.logMessage(
            "ตรวจอัปเดตอัตโนมัติไม่สำเร็จ — " + _upd_net_text(e), "MLEP", Qgis.Info))     # ★ b19 E6 ไม่ใช่ "ระบบกรม"
        w.start()

    def update_plugin(self):
        """เช็คเวอร์ชันใหม่จาก GitHub — ทำใน thread แยก (เดิม block UI บน main thread)"""
        if getattr(self, "_updating", False):
            return
        self._updating = True

        V_URL = UPDATE_V_URL
        Z_URL = UPDATE_Z_URL

        def _check():
            res = _upd_get(V_URL, 8)                 # ★ 2.3.7 b19 (doc-verify E6) ใบรับรองแบบระบบกรม (เดิม requests.get)
            res.raise_for_status()
            # ★ 2.3.7 (review DI-42) — เดิม BOM/'v'/ข้อความแปลก ⇒ (0,) ⇒ บอกว่า "ใช้รุ่นล่าสุดแล้ว" ทั้งที่ยังไม่ได้ตรวจจริง
            txt = _resp_text(res)
            if _parse_version(txt) is None:
                # ★ 2.3.7 (review ER-06) — ข้อความที่เซิร์ฟเวอร์ตอบ (อาจเป็น HTML) ไปที่ Log ไม่ใส่ในกล่องของพนักงาน
                QgsMessageLog.logMessage("ตรวจอัปเดต: อ่านเลขรุ่นไม่ได้ — เซิร์ฟเวอร์ตอบ %r" % _scrub(txt[:200]),
                                         "MLEP", Qgis.Warning)
                raise RuntimeError("อ่านเลขรุ่นจากเซิร์ฟเวอร์ไม่ได้")
            return txt

        def _got(new_version):
            if _vkey(new_version) > _vkey(self.version):
                self.prompt_update(new_version, Z_URL)
            else:
                self._updating = False
                self._ask(
                    QtWidgets.QMessageBox.Information, "Update", f"คุณใช้เวอร์ชันล่าสุดแล้ว (v{self.version})")

        def _err(e):
            self._updating = False
            # ★ 2.3.7 (review ER-06) — หัวข้อไทย + เหตุสั้น ๆ (เดิม 'Update Error' + ข้อความดิบของ requests) · ตัวจริงลง Log
            _log_err("ตรวจสอบอัปเดตไม่สำเร็จ", e)
            self._ask(QtWidgets.QMessageBox.Warning, "ตรวจสอบอัปเดต",
                      f"ไม่สามารถตรวจสอบอัปเดตได้ — {_upd_net_text(e)}\n"          # ★ b19 E6
                      f"ใช้รุ่นปัจจุบัน ({self.version}) ต่อได้ตามปกติ ลองกด 🚀 ใหม่ภายหลัง\n({self._LOG_HINT})")

        self._run_net("กำลังตรวจสอบเวอร์ชันใหม่...", _check, _got, _err)

    # ==================== 2.3.3 — โหลดปลั๊กอินใหม่หลังอัปเดต ====================
    def _reload_blocker(self):
        """คืนเหตุผลที่ "ยังไม่ควร" โหลดปลั๊กอินใหม่ตอนนี้ หรือ '' ถ้าปลอดภัย

        🔴 ห้ามโหลดใหม่เมื่อ
          ① มีชั้นที่แก้ค้างไม่บันทึก — การแก้ในชั้นไม่หาย (อยู่ที่ QGIS) แต่ของฝั่งปลั๊กอินหาย:
             ประวัติ ↺ Undo ของปลั๊กอิน · log เปลี่ยน Type ที่รอเขียนหลังบันทึก (`_pending_type_log`)
          ② มี thread เน็ตยังวิ่งอยู่ (ค้นหาภาพลักษณ์ / เช็คอัปเดต) — QThread ถูกทำลายระหว่างวิ่ง
             = Qt เรียก qFatal ⇒ QGIS เด้งทันที (เคยเจอจริง ดูคอมเมนต์ที่ `_dol_worker`)
          ③ QGIS รุ่นนี้ไม่มี `qgis.utils.reloadPlugin`"""
        try:
            import qgis.utils as _qu
            if not hasattr(_qu, "reloadPlugin"):
                return "QGIS รุ่นนี้โหลดปลั๊กอินใหม่เองไม่ได้"
        except Exception:
            return "QGIS รุ่นนี้โหลดปลั๊กอินใหม่เองไม่ได้"
        try:
            ค้าง = [l.name() for l in QgsProject.instance().mapLayers().values()
                    if hasattr(l, "isModified") and l.isEditable() and l.isModified()]
        except Exception:
            ค้าง = []
        # ★ 2.3.7 b17 (audit R2-D2 เสนอ) — แถวคิว Move_Log ของงานที่ถูกย้อนด้วย Undo ของ QGIS ไม่นับเป็น "งานค้าง"
        #   (เดิมบอก "ยังมีงานที่ยังไม่ได้บันทึก" ทั้งที่ไม่มีชั้นไหนค้าง จนกว่าจะบันทึก/ยกเลิก · ผู้ตรวจ r03 S8b)
        #   _type_log_prune(dry=True) = นับอย่างเดียว ไม่ทิ้งแถว (ถ้าสุดท้ายไม่ได้โหลดใหม่ แล้ว Redo กลับมา แถวต้องยังอยู่)
        _q = list(getattr(self, "_pending_type_log", None) or [])
        try:
            _q_live = len(_q) - sum(self._type_log_prune(_l, dry=True) for _l in {e.get('lid') for e in _q})
        except Exception:
            _q_live = len(_q)
        if ค้าง or _q_live > 0:
            return ("ตอนนี้ยังมีงานที่ยังไม่ได้บันทึก" +
                    (f" ({', '.join(ค้าง[:3])}{' ...' if len(ค้าง) > 3 else ''})" if ค้าง else ""))
        ws = list(getattr(self, "_net_workers", []) or [])
        _dw = getattr(self, "_dol_worker", None)
        if _dw is not None:
            ws.append(_dw)
        for w in ws:
            try:
                _run = w is not None and w.isRunning()
            except Exception:
                continue
            if _run:
                # ★ 2.3.7 — worker ถูกปล่อยตอน finished (b1 LC-01) ⇒ ตัวที่เพิ่งส่งผล (เช่นดาวน์โหลดอัปเดตที่เพิ่งเสร็จ)
                #   อาจยัง isRunning() อยู่เสี้ยววินาที ⇒ รอสั้น ๆ ก่อนตัดสิน (ไม่งั้นบล็อก reload หลอกเป็นบางครั้ง)
                try:
                    if w.wait(300):
                        continue
                except Exception:
                    pass
                return "ตอนนี้ยังมีงานดึงข้อมูลจากเน็ตค้างอยู่"
        # ★ 2.3.7 (review UX-10) — เส้นวัดระยะ/จุดจากพิกัดอยู่ในหน่วยความจำของปลั๊กอินเท่านั้น ⇒ โหลดใหม่ = หายเงียบ ๆ
        _it = getattr(self, "_line_item", None)
        try:
            _has_line = _it is not None and bool(_it.lines or _it.temp)
        except Exception:
            _has_line = False
        if _has_line or getattr(self, "_line_pts", None):
            return "ยังมีเส้นวัดระยะ/จุดจากพิกัดในหน้าต่างวาดเส้น (จะหายถ้าโหลดใหม่ตอนนี้)"
        return ""

    def _schedule_self_reload(self, zver):
        """สั่ง QGIS โหลดปลั๊กอินนี้ใหม่ — **เลื่อนไปทำหลังกล่องข้อความปิดแล้ว**
        🔑 ห้ามเรียก reloadPlugin ตรงจาก callback ของตัวเอง: unload() จะลบหน้าต่าง/ตัวแปรของ
           อินสแตนซ์ที่ยังอยู่บน stack · QTimer.singleShot พาไปทำตอนกลับถึง event loop
        🔑 lambda ห้ามอ้าง `self` — อินสแตนซ์เดิมจะถูกทิ้งระหว่าง reload
        ★ 2.3.7 (review LC-08) — มีกล่อง modal เปิดค้าง ⇒ รอให้ปิดก่อน · ตรวจ _reload_blocker ซ้ำตอนจะโหลดจริง
        ★ 2.3.7 (review ER-02 · audit C-01) — ตัดสินผลจากสถานะจริง (active_plugins + ตัวปลั๊กอินเป็นตัวใหม่ · ไม่เชื่อค่าที่คืน)
        · รุ่นใหม่โหลดไม่ขึ้น ⇒ คืนรุ่นเดิมจาก mlep_backup/<ชื่อ>_prev (★ b17 คอมเมนต์เดิมยังพูดถึง .mlep_prev)"""
        here = os.path.dirname(_MLEP_MAIN_FILE)
        name = os.path.basename(here)
        plugins_dir = os.path.dirname(here)
        _iface = self.iface

        def _say(text, level=1):
            try:
                _iface.messageBar().pushMessage("Update", text, level=level, duration=0)
            except Exception:
                pass

        def _do(_tries=0):
            try:
                import qgis.utils as _qu
                # มีกล่อง modal เปิดค้าง (ยืนยันลบ · กล่องชื่อหมุด · หน้าต่างของ QGIS) ⇒ ยังไม่ reload
                #   unload() จะรื้อ instance ขณะที่โค้ดของกล่องนั้นยังค้างอยู่บน stack แล้วทำงานต่อบน instance ที่ตายแล้ว
                try:
                    _busy = QtWidgets.QApplication.activeModalWidget() is not None
                    # ★ 2.3.7 rc3 (Windows audit 🔴1 · ตรวจทางที่ถอดเลเยอร์แบบเลื่อนเวลา) — เมนู popup เปิดอยู่ (QMenu::exec = ลูปซ้อน
                    #   เช่นเมนูคลิกขวาของชั้นเส้นเราในแผง Layers) ⇒ รอเหมือนกล่อง modal: unload ถอดชั้นเส้น/ชั้นจุดของเรา (_line_cleanup)
                    _busy = _busy or QtWidgets.QApplication.activePopupWidget() is not None
                    # ★ 2.3.7 (audit LIFE-07) — กำลังกด/ลากเมาส์อยู่ (เช่นลากหมุด Move Node) ⇒ รอปล่อยก่อน
                    #   unload กลางการลาก = เครื่องมือหายไปพร้อมสถานะ "กำลังลาก" · รุ่นใหม่ไม่เห็นการปล่อยเมาส์ครั้งนั้น
                    _busy = _busy or QtWidgets.QApplication.mouseButtons() != QtCore.Qt.NoButton
                except Exception:
                    _busy = False
                if _busy:
                    if _tries < 1200:                        # 0.5 วิ × 1200 = 10 นาที
                        QtCore.QTimer.singleShot(500, lambda: _do(_tries + 1))
                    else:
                        _say(f"ติดตั้ง {zver} แล้ว แต่ยังโหลดใหม่ไม่ได้ (มีหน้าต่างเปิดค้าง) — "
                             "กรุณาบันทึกงาน แล้วปิด QGIS และเปิดใหม่")
                    return
                # ตรวจด่านซ้ำ — เวลาผ่านไปแล้ว พนักงานอาจเริ่มแก้งาน/วาดเส้นใหม่ระหว่างกล่อง Done
                why = ""
                try:
                    _inst = (getattr(_qu, "plugins", None) or {}).get(name)
                    if _inst is not None and hasattr(_inst, "_reload_blocker"):
                        why = _inst._reload_blocker() or ""
                except Exception:
                    why = ""
                if why:
                    _say(f"ติดตั้ง {zver} แล้ว แต่ยังไม่โหลดใหม่ — {why} · กรุณาบันทึกงาน แล้วปิด QGIS และเปิดใหม่")
                    return
                _act = getattr(_qu, "active_plugins", None) or []
                was_active = name in _act
                # ★ 2.3.7 (audit C-01) — ไม่เชื่อค่าที่ reloadPlugin คืน: qgis.utils ของ 3.44 คืน bool แต่รุ่นก่อนหน้าคืน None แม้สำเร็จ
                #   ⇒ เดิมเครื่องเหล่านั้นอัปเดตสำเร็จแต่ขึ้น "โหลดใหม่เองไม่สำเร็จ — ปิด QGIS แล้วเปิดใหม่" ทุกเครื่อง
                #   ⇒ ตัดสินจากสถานะจริง: ชื่ออยู่ใน active_plugins และตัวปลั๊กอินใน qgis.utils.plugins เป็น "ตัวใหม่"
                #   (ถือตัวเดิมไว้เทียบด้วย `is` — ไม่ใช้ id() ที่อาจถูกใช้ซ้ำหลังตัวเดิมถูกเก็บ)
                _old_obj = (getattr(_qu, "plugins", None) or {}).get(name)
                # ★ (audit LIFE-04) คีย์ที่ Undo ของ QGIS ควรมี (จำจากตัวเดิม) — ใช้คืนคีย์ถ้ารุ่นใหม่ล้มกลาง initGui
                _undo_keep = getattr(_old_obj, "_qgis_undo_keys", None)
                _ret = _qu.reloadPlugin(name)
                # ★ 2.3.7 b17 (audit R2-LIFE-02) — unload ของตัวเดิมรับคีย์ Undo ที่ผู้ใช้เปลี่ยนระหว่างโหลดอยู่ ⇒ อ่านซ้ำหลังโหลดใหม่
                _undo_keep = getattr(_old_obj, "_qgis_undo_keys", _undo_keep)
                _new_obj = (getattr(_qu, "plugins", None) or {}).get(name)
                _now_active = name in (getattr(_qu, "active_plugins", None) or [])
                _ok = _now_active and _new_obj is not None and _new_obj is not _old_obj
                _old_obj = _new_obj = None
                if _ok:
                    return
                try:
                    QgsMessageLog.logMessage("โหลดปลั๊กอินใหม่หลังอัปเดต %s ไม่สำเร็จ — reloadPlugin คืน %r · ก่อนหน้าเปิดอยู่ %s · "
                                             "ตอนนี้เปิดอยู่ %s" % (zver, _ret, was_active, _now_active), "MLEP", Qgis.Info)
                except Exception:
                    pass
                if not was_active or _now_active:
                    # QGIS ไม่ได้ถอดรุ่นเดิมออกจริง ⇒ รุ่นใหม่ยังไม่ได้พิสูจน์ว่าเสีย ⇒ แค่ให้ปิด-เปิด QGIS
                    _say(f"ติดตั้ง {zver} แล้ว แต่โหลดใหม่เองไม่สำเร็จ — กรุณาปิด QGIS แล้วเปิดใหม่")
                    return
                # รุ่นใหม่โหลดไม่ขึ้น (QGIS แสดง error ของมันแล้ว) ⇒ คืนรุ่นเดิมแล้วเปิดใหม่ทันที
                back, detail = _rollback_failed_update(plugins_dir, name)
                # ★ 2.3.7 (audit LIFE-04) — รุ่นที่ล้มกลาง initGui ไม่ถูก unload (QGIS ทิ้ง instance เฉย ๆ) ⇒ ไอคอน/คีย์ลัดของมันค้าง
                #   (Ctrl+Z ซ้อน 2 ตัว ⇒ ไม่ทำงานทั้งคู่ · ไอคอน 2 อัน) + คีย์ Undo ของ QGIS ถูกยึดค้าง ⇒ เก็บก่อนเปิดรุ่นเดิม (ทำแม้คืนไฟล์ไม่ได้)
                try:
                    _debris = _mlep_debris_clear(_iface, _undo_keep)
                except Exception:
                    _debris = -1
                detail = "%s · เก็บของค้างของรุ่นที่ล้ม %s ชิ้น" % (detail, _debris)
                started = False
                if back:
                    try:
                        _qu._unloadPluginModules(name)
                    except Exception:
                        pass
                    # ★ 2.3.7 b17 (audit nit · แบบ C-01) — ไม่เชื่อค่าที่ loadPlugin/startPlugin คืน ⇒ ตัดสินจาก active_plugins
                    _ld = _st = None
                    try:
                        _ld = _qu.loadPlugin(name)
                        if _ld is not False:
                            _st = _qu.startPlugin(name)
                    except Exception as _e:
                        _st = "%s" % type(_e).__name__
                    started = name in (getattr(_qu, "active_plugins", None) or [])
                    detail = "%s · loadPlugin คืน %r · startPlugin คืน %r" % (detail, _ld, _st)
                try:
                    QgsMessageLog.logMessage(
                        "อัปเดต %s โหลดไม่ขึ้น — คืนรุ่นเดิม: %s · เปิดรุ่นเดิม: %s · %s" % (zver, back, started, detail),
                        "MLEP", Qgis.Critical)
                except Exception:
                    pass
                if back and started:
                    _say(f"รุ่น {zver} โหลดไม่ขึ้น — คืนรุ่นเดิมให้แล้ว ใช้งานต่อได้ (แจ้งผู้ดูแล)", level=1)
                elif back:
                    _say(f"รุ่น {zver} โหลดไม่ขึ้น — คืนไฟล์รุ่นเดิมแล้ว กรุณาปิด QGIS แล้วเปิดใหม่ (แจ้งผู้ดูแล)", level=2)
                else:
                    # ★ 2.3.7 (review ER-06) — รายละเอียดดิบ (ชนิด exception · path) อยู่ใน Log บรรทัดข้างบนแล้ว ไม่ใส่ในแถบ
                    _say(f"รุ่น {zver} โหลดไม่ขึ้น และคืนรุ่นเดิมไม่ได้ — กรุณาปิด QGIS แล้วแจ้งผู้ดูแล "
                         "(รายละเอียดอยู่ในแผง Log Messages แท็บ MLEP)",
                         level=2)
            except Exception as e:
                try:
                    QgsMessageLog.logMessage("reloadPlugin ล้ม — %s" % e, "MLEP", Qgis.Warning)
                except Exception:
                    pass
                _say(f"ติดตั้ง {zver} แล้ว แต่โหลดใหม่เองไม่สำเร็จ — กรุณาปิด QGIS แล้วเปิดใหม่")
        QtCore.QTimer.singleShot(300, _do)

    def prompt_update(self, new_version, download_url):
        # ★ 2.3.7 (audit LIFE-03) — บนเครื่องมีรุ่นที่ติดตั้งรอไว้แล้ว (โหลดใหม่ถูกเลื่อน · QGIS อีกหน้าต่างอัปเดตไปแล้ว) ⇒ ไม่ถาม
        #   ไม่ดาวน์โหลดซ้ำ (เดิมติดตั้งทับแล้วสำเนารุ่นเดิมถูกแทนด้วยรุ่นใหม่ ⇒ ถอยกลับไม่ได้) · บอกให้ปิด-เปิด QGIS
        try:
            _upd_check_disk(os.path.dirname(_MLEP_MAIN_FILE), new_version, self.version)
        except _UpdateInstallError as e:
            self._updating = False
            self._ask(QtWidgets.QMessageBox.Information, "อัปเดต", _reason_text(e))     # ข้อความไทยของตัวติดตั้งเอง
            return
        if self._ask(
                QtWidgets.QMessageBox.Question, "Update",
                f"พบเวอร์ชันใหม่ {new_version} ต้องการอัปเดตไหม?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            self._updating = False
            return

        def _download():
            """โหลด -> ตรวจของในซิปก่อน -> แตกลง temp -> สลับทับของเดิม (มีสำเนาเดิมไว้กู้)
            เดิม: extractall ทับของจริงสด ๆ โดยไม่ตรวจอะไรเลย ->
              (ก) วันไหนอัปซิปผิดตัว จะ downgrade ทั้งกรมโดยไม่มีอะไรดัก
              (ข) เน็ตหลุดกลางคัน = ปลั๊กอินเหลือครึ่ง ๆ กู้เองไม่ได้"""
            here = os.path.dirname(_MLEP_MAIN_FILE)                 # .../plugins/Multi_Layer_Edit_Pro
            plugins_dir = os.path.dirname(here)
            name = os.path.basename(here)

            r = _upd_get(download_url, 120)          # ★ 2.3.7 b19 (doc-verify E6) ใบรับรองแบบระบบกรม (เดิม requests.get)
            r.raise_for_status()
            # ★ 2.3.7 (review ER-02) — ตรวจครบก่อนย้ายโฟลเดอร์ใด ๆ (เลขรุ่น · qgisMinimumVersion · metadata อ่านได้แบบ QGIS ·
            #   compile ทุกไฟล์ .py · ไฟล์ที่โค้ดเรียกใช้ครบ) · รุ่นเดิมเก็บไว้ที่ mlep_backup/<ชื่อ>_prev จนอัปเดตครั้งถัดไป
            return _install_update_zip(r.content, plugins_dir, name, new_version, self.version)

        def _ok(zver):
            self._updating = False
            # ★ 2.3.3 (22 ก.ย. 69) เจ้าของงานถาม "ถ้ามีการอัปเดตและกด ok จะ reload ปลั๊กอินให้อัตโนมัติได้ไหม"
            #   ⇒ โหลดปลั๊กอินใหม่ให้เองเมื่อปลอดภัย · ไม่ปลอดภัยก็ถอยไปบอกให้ปิด-เปิด QGIS แบบเดิม
            #   🔑 มีผลกับการอัปเดต "ที่สั่งจากรุ่นนี้ขึ้นไป" (โค้ดของรุ่นที่ติดตั้งอยู่เป็นคนทำ)
            why = self._reload_blocker()
            if why:
                self._ask(QtWidgets.QMessageBox.Information, "Done",
                          f"อัปเดตเป็นเวอร์ชัน {zver} เรียบร้อยแล้ว\n\n{why}\n"
                          "กรุณาบันทึกงานให้เรียบร้อย แล้วปิด QGIS และเปิดใหม่")
                return
            self._ask(QtWidgets.QMessageBox.Information, "Done",
                      f"อัปเดตเป็นเวอร์ชัน {zver} เรียบร้อยแล้ว\n\n"
                      "กด OK เพื่อโหลดปลั๊กอินรุ่นใหม่ทันที (ไม่ต้องปิด QGIS)")
            self._schedule_self_reload(zver)

        def _err(e):
            self._updating = False
            # ★ 2.3.7 (review ER-02) — แยก "ติดตั้งไม่สำเร็จ" (ซิปไม่ผ่านด่าน/ย้ายไฟล์ไม่ได้) ออกจาก "ดาวน์โหลดไม่สำเร็จ"
            #   (เดิมทุกอย่างขึ้นว่า 'การดาวน์โหลดล้มเหลว')
            if isinstance(e, _UpdateInstallError) and (getattr(e, "already", False) or getattr(e, "same", False)):
                # ★ 2.3.7 (audit LIFE-03) รุ่นติดตั้งรอไว้แล้ว · ★ 2.4.1 ซิปรุ่นเดียวกับที่ใช้อยู่ — ไม่ใช่ความล้มเหลว (ไม่ลง Log แบบข้อผิดพลาด)
                self._ask(QtWidgets.QMessageBox.Information, "อัปเดต", _reason_text(e))
                return
            if isinstance(e, _UpdateInstallError):
                _log_err("ติดตั้งอัปเดตไม่สำเร็จ", e)          # ★ 2.3.7 (audit LIFE-06) — เหตุจริง (OSError ที่ซ้อนอยู่) ลง Log
                self._ask(QtWidgets.QMessageBox.Critical, "ติดตั้งอัปเดตไม่สำเร็จ",
                          f"ติดตั้งรุ่น {new_version} ไม่สำเร็จ"
                          + (f" — ยังใช้รุ่นเดิม ({self.version}) ได้ตามปกติ" if getattr(e, "intact", True) else "")
                          + f"\n\n{e}")
                return
            # ★ 2.3.7 (review ER-06) — หัวข้อไทย + เหตุสั้น ๆ (เดิม 'Update Error' + ข้อความดิบ) · ตัวจริงลง Log
            _log_err("ดาวน์โหลดรุ่นใหม่ไม่สำเร็จ", e)
            self._ask(QtWidgets.QMessageBox.Critical, "ดาวน์โหลดอัปเดต",
                      f"ดาวน์โหลดรุ่นใหม่ไม่สำเร็จ — {_upd_net_text(e)}\n"          # ★ b19 E6
                      f"ยังใช้รุ่นเดิม ({self.version}) ได้ตามปกติ · ตรวจการเชื่อมต่ออินเทอร์เน็ต แล้วกด 🚀 อีกครั้ง\n"
                      f"({self._LOG_HINT})")

        self._run_net(f"กำลังดาวน์โหลดเวอร์ชัน {new_version}...", _download, _ok, _err)
