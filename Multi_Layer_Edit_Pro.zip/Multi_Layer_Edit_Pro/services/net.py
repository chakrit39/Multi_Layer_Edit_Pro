# -*- coding: utf-8 -*-
"""รันงาน network ใน thread แยก (_run_net)

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
from qgis.PyQt import QtCore, QtWidgets
from ..services.workers import _FnWorker
from ..ui.qt_helpers import _lift_dlg


class NetMixin:
    """รันงาน network ใน thread แยก (_run_net)"""

    # ---------- ตัวช่วยรัน network ใน thread แยก (กัน QGIS ค้างเมื่อ server ช้า) ----------
    def _run_net(self, msg, fn, on_done, on_fail, req=None):
        """รัน fn (blocking network) ใน QThread + โชว์ progress dialog
        on_done(result) / on_fail(exception) ถูกเรียกบน main thread
        ★ 2.3.7 (review DI-21/UX-22) — req = คำขอ DOL ที่งานนี้เป็นขั้นหนึ่ง: กล่องรอมีปุ่ม "ยกเลิก" ·
          ผลของคำขอที่ถูกยกเลิก/เก่าแล้วถูกทิ้ง (ไม่เรียก on_done/on_fail) · ไม่ส่ง req = เหมือนเดิมทุกอย่าง"""
        # ★ 2.4.3 (ผลตรวจ Windows rc4 ⚪6) — มีกล่อง modal เปิดอยู่ (เช่น ➕ สร้างรูปแปลงที่ค้นทะเบียน iLands ต่อ) ⇒ กล่องรอเป็นลูกของกล่องนั้น
        #   + ยกขึ้นหน้าสุด (เดิมผูกกับแผงปลั๊กอิน ⇒ บน Windows ถูกกล่องที่เปิดอยู่บัง · กล่องนั้นคลิกไม่ได้ ~25 วิ โดยไม่เห็นว่ารออะไร)
        busy = QtWidgets.QProgressDialog(msg, None, 0, 0, QtWidgets.QApplication.activeModalWidget() or self.dlg)
        busy.setWindowTitle("Multi-Layer Edit Pro")
        busy.setCancelButton(None)
        busy.setWindowModality(QtCore.Qt.WindowModal)
        if req is not None:
            self._dol_wait_arm(busy, req)
        busy.show()
        _lift_dlg(busy)
        w = _FnWorker(fn)
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)   # กัน GC เก็บ worker ระหว่างรัน

        def _cleanup():
            try:
                busy.close()
                busy.deleteLater()
            except Exception:
                pass

        def _release(_w=w):
            # ★ 2.3.7 (review LC-01 · P0) — ปล่อย worker ตอน finished เท่านั้น (ยิงหลัง QThread จบจริง)
            #   เดิม deleteLater() จาก slot done/fail ซึ่งอาจทำงานก่อน thread จบ ⇒ "QThread: Destroyed while
            #   thread is still running" = qFatal QGIS ดับ งานที่ยังไม่บันทึกหาย (แบบเดียวกับ ParcelLookupWorker ที่ปลอดภัยอยู่แล้ว)
            try:
                self._net_workers.remove(_w)
            except ValueError:
                pass
            _w.deleteLater()

        def _live():
            # ★ 2.3.7 — ตัดสินก่อนปิดกล่อง: close() ยิง canceled ⇒ ถ้ายังนับว่ารออยู่จะกลายเป็น "ยกเลิก"
            return True if req is None else self._dol_step_done(req)

        def _ok(res):
            live = _live()
            _cleanup()
            if live and getattr(self, "_alive", True):
                on_done(res)

        def _err(e):
            live = _live()
            _cleanup()
            if live and getattr(self, "_alive", True):
                on_fail(e)

        w.finished.connect(_release)
        w.done.connect(_ok)
        w.fail.connect(_err)
        w.start()
