# -*- coding: utf-8 -*-
"""ด่านล็อก L1 ตอนบันทึก (review DI-11): งานค้างที่ย้าย/ลบแปลงหรือหมุด L1 ต้องถามก่อน ทั้งปุ่ม 💾 ของปลั๊กอินและปุ่มบันทึกของ QGIS

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import os
import re
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import Qgis, QgsFeatureRequest, QgsMessageLog, QgsProject
from ..core.util import _fld_idx, _LockScanError, _log_exc, _natkey, _norm_utm, _scrub, _txt, _UTM_FIELD_NAMES
from ..lock_rules import is_l1_type, L1_TYPES, marker_lock_type


_ALLOW_COMMIT_API = []     # ★ 2.4.0 (review DI-11) แคชผลหา: [] = ยังไม่หา · [None] = ไม่มี · [(set, get)]


def _l1_exact(v):
    """★ rc9 (agent A rc8 ⚪3) ค่า Type ที่ trigger ในฐานนับเป็น L1 — ตรงตัว 'L1-TS' / 'L1-RTK' เท่านั้น (ฐานเทียบ "Type" IN ('L1-TS','L1-RTK')
    ⇒ 'l1-ts' / ' L1-TS' ไม่ใช่ L1 ในฐาน · rc8 นับด้วย is_l1_type (upper/strip) ⇒ แก้หมุดเป็น 'l1-ts' ไม่ถูกนับว่าลด แต่ฐานปฏิเสธ)"""
    try:
        return v is not None and str(v) in L1_TYPES_EXACT
    except Exception:
        return False


L1_TYPES_EXACT = ("L1-TS", "L1-RTK")


def _bkey(v):
    """คีย์ UTM แบบที่ trigger รอบสามเทียบ (btrim ช่องว่าง U+0020) · NULL/ว่าง = ''"""
    try:
        if v is None or (hasattr(v, "isNull") and v.isNull()):
            return ""
        t = str(v)
        return "" if t == "NULL" else t.strip(" ")
    except Exception:
        return ""


def _allow_commit_api():
    """★ 2.4.0 (review DI-11) — QgsVectorLayer::setAllowCommit(bool) / allowCommit() ของ C++ (มีตั้งแต่ QGIS 3.4)
    QGIS เช็คค่านี้ "ทันทีหลังยิง beforeCommitChanges" ⇒ ทางเดียวที่ปลั๊กอินระงับการบันทึกด้วยปุ่มของ QGIS ได้
    แต่ PyQGIS ไม่ export สองเมธอดนี้ (SIP_SKIP — ตรวจบน 3.40.6 แล้ว: ไม่มีทั้งเมธอดและ Q_PROPERTY)
    ⇒ เรียกสัญลักษณ์ที่ qgis_core export ไว้โดยตรงด้วย ctypes · ชื่อ mangled เข้ารหัสชนิดพารามิเตอร์ไว้ ⇒ หาเจอ = signature ตรง
    หาไม่เจอ (ระบบ/รุ่นอื่น) = None ⇒ ผู้เรียกถอยไปแค่เตือน (ไม่ถามคำถามที่ตอบ "ไม่" แล้วหยุดไม่ได้)"""
    if _ALLOW_COMMIT_API:
        return _ALLOW_COMMIT_API[0]
    api = None
    try:
        import ctypes
        import ctypes.util
        if os.name == "nt":       # MSVC x64
            names = ("?setAllowCommit@QgsVectorLayer@@QEAAX_N@Z", "?allowCommit@QgsVectorLayer@@QEBA_NXZ")
            libs = ["qgis_core.dll"]          # โหลดอยู่แล้วในโปรเซส ⇒ ได้ handle ตัวเดิม
        else:                     # Itanium (Linux / macOS)
            names = ("_ZN14QgsVectorLayer14setAllowCommitEb", "_ZNK14QgsVectorLayer11allowCommitEv")
            libs = [None, ctypes.util.find_library("qgis_core")]
        for ln in libs:
            try:
                lib = ctypes.CDLL(ln)
                s, g = getattr(lib, names[0]), getattr(lib, names[1])
            except (OSError, AttributeError, TypeError):
                continue
            s.argtypes, s.restype = (ctypes.c_void_p, ctypes.c_bool), None
            g.argtypes, g.restype = (ctypes.c_void_p,), ctypes.c_bool
            api = (s, g)
            break
    except Exception:
        api = None
    _ALLOW_COMMIT_API.append(api)
    return api


class L1CommitGateMixin:
    """ด่านล็อก L1 ตอนบันทึก (review DI-11): งานค้างที่ย้าย/ลบแปลงหรือหมุด L1 ต้องถามก่อน ทั้งปุ่ม 💾 ของปลั๊กอินและปุ่มบันทึกของ QGIS"""

    # ---------- ★ 2.4.0 (review DI-11) ด่านล็อก L1 ตอนบันทึก ----------
    #   เดิมล็อก L1 มีแค่ตอน "เริ่มเครื่องมือของปลั๊กอิน" · Vertex Tool / Move Feature / Delete Selected ของ QGIS
    #   (รวมแก้แบบ topological ที่ลากมุมของแปลงข้างเคียงไปด้วย) ย้าย/ลบแปลง L1 และหมุดล็อกแล้วบันทึกได้โดยไม่มีคำเตือน
    #   ⇒ ตรวจจาก edit buffer ตอนบันทึกทั้งสองทาง (ปุ่ม 💾 ของปลั๊กอิน · ปุ่มบันทึกของ QGIS) แล้วถาม (เจ้าของงานตัดสิน "เตือนแล้วถาม")
    @staticmethod
    def _l1_buf_state(lyr, wkb=True):
        """ฟีเจอร์ "ที่มีอยู่แล้วในฐาน" ที่ buffer จะเปลี่ยนรูป/ลบ -> ({fid: wkb | None}, {fid})
        fid ติดลบ = เพิ่มใน buffer นี้ (ยังไม่มีในฐาน) ⇒ ข้าม · wkb=False ไม่แปลงรูปเป็น WKB (ได้ None — ใช้เมื่อไม่ต้องเทียบ)"""
        eb = lyr.editBuffer() if lyr is not None and lyr.isEditable() else None
        if eb is None:
            return {}, set()
        g = {fid: (bytes(geom.asWkb()) if wkb else None)
             for fid, geom in eb.changedGeometries().items() if fid >= 0}
        return g, {fid for fid in eb.deletedFeatureIds() if fid >= 0}

    @staticmethod
    def _l1_buf_attrs(lyr):
        """★ rc2 (audit A4-04) — ค่าที่ buffer แก้ของฟีเจอร์ "ที่มีอยู่แล้วในฐาน" -> {fid: ((index, ค่าเป็นข้อความ), ...)} (fid ≥ 0)"""
        eb = lyr.editBuffer() if lyr is not None and lyr.isEditable() else None
        if eb is None:
            return {}
        out = {}
        for fid, amap in eb.changedAttributeValues().items():
            if fid >= 0 and amap:
                out[fid] = tuple(sorted((int(i), _txt(v)) for i, v in amap.items()))
        return out

    def _l1_attr_watch(self, fields, is_poly):
        """★ rc2 (audit A4-04) — คอลัมน์ที่ด่าน L1 ตอนบันทึกดู "การแก้ค่า" (ชื่อ ไม่สนตัวพิมพ์) -> {index: ชื่อ}
        แปลง L1: SCORE · Type · คีย์ (UTM / UTMMAP1-4 / UTMSCALE / LANDNO) · หมุดล็อก: + BND_NAME
        (เครื่องมือของปลั๊กอินที่เขียนคอลัมน์เหล่านี้ปฏิเสธแปลง/หมุด L1 ทั้งหมดจนกว่าจะปลดล็อก — ✏️ ชื่อหมุด · Score · 🏷 · 📝)"""
        want = {n.upper() for n in self._L1_ATTR_COLS} | {n.upper() for n in _UTM_FIELD_NAMES}
        if not is_poly:
            want.add("BND_NAME")
        out = {}
        for i in range(fields.count()):
            nm = fields.at(i).name()
            if nm.upper() in want:
                out[i] = nm
        return out

    def _l1_note_ok(self, base, pre, only=None, pre_a=None):
        """จดงานของเครื่องมือปลั๊กอินที่ทำตอนปลดล็อก L1 (เรียกจาก _op_commit) ⇒ ด่านตอนบันทึกไม่ถาม แม้ล็อกกลับก่อนกดบันทึก
        จดรูปหลังทำไว้ด้วย: ถ้าภายหลังมีเครื่องมืออื่นแก้ฟีเจอร์เดิมต่อ (รูปไม่ตรงที่จด) ด่านถามตามปกติ
        base = _op_baseline {lid: (lyr, index)} · pre = {lid: สภาพ buffer ก่อน op} จาก _op_begin
        ★ 2.4.0 (review DI-11) — จดตัวตนคำสั่งของ op บน undo stack (_ux_mark) คู่กับทุกรายการ ⇒ ย้อน op นั้นแล้ว (Undo ของ QGIS /
          ↺ ของปลั๊กอิน) รายการหมดผล (_l1_commit_hits เช็คด้วย _ux_live) · เดิมรายการ "ลบ" อยู่จนบันทึก/ทิ้งงาน ⇒ ย้อนการลบแล้ว
          ล็อกกลับ แล้วลบฟีเจอร์เดิมด้วย Delete Selected ของ QGIS = ไม่ถาม
        ★ rc1 S5 (review R3-01) — only = {layer id: {fid}} (ข้อยกเว้น Transform 2 จุดของ L1-TS · ไม่ได้ปลดล็อก) ⇒ จดเฉพาะฟีเจอร์ในชุด
          และข้ามฟีเจอร์ที่รูปใน buffer "ก่อน op" ต่างจากฐานโดยไม่มีรายการอนุญาตที่ยังมีผลตรงรูปนั้น (งานจาก Vertex Tool /
          Move Feature ของ QGIS ที่ยังไม่ได้อนุญาต) ⇒ ด่านตอนบันทึกยังถาม (เดิมรูปที่บิดติดไปกับผล Transform แล้วถูกจดว่าอนุญาต)
          · เก็บรายการต่อฟีเจอร์เป็นลิสต์ ⇒ ทำซ้ำแล้วย้อนครั้งหลัง รูปกลับไปเท่าผลครั้งก่อนที่ยังมีผล = ไม่ถาม (เดิมถามเกิน)"""
        for lid, (lyr, _i) in base.items():
            if lid not in pre:
                continue
            try:
                g0, d0 = pre[lid]
                g1, d1 = self._l1_buf_state(lyr)
            except Exception:
                continue
            ux = self._ux_mark(lyr)
            ok = self._l1_ok.setdefault(lid, {'g': {}, 'd': {}})     # {'g': {fid: [(wkb, ux), ...]}, 'd': {fid: ux}}
            allow = None if only is None else only.get(lid, set())
            for fid, w in g1.items():
                if g0.get(fid) == w:
                    continue
                if allow is not None:
                    if fid not in allow:
                        continue
                    if fid in g0 and not any(w0 == g0[fid] and self._ux_live(lyr, u0)
                                             for w0, u0 in ok['g'].get(fid, ())):
                        continue                    # มีงาน L1 ที่ยังไม่อนุญาตค้างอยู่ก่อน op ⇒ ไม่จด (บันทึกแล้วถาม)
                ok['g'].setdefault(fid, []).append((w, ux))
            if allow is None:
                for fid in d1 - d0:
                    ok['d'][fid] = ux
            # ★ rc2 (audit A4-04) — ค่าที่ op นี้แก้ (ด่านตอนบันทึกดูการแก้ค่าของแปลง/หมุด L1 ด้วยแล้ว) · กติกาเดียวกับรูป
            if pre_a is not None and lid in pre_a:
                try:
                    a0, a1 = pre_a[lid] or {}, self._l1_buf_attrs(lyr)
                except Exception:
                    a0, a1 = None, {}
                if a0 is not None:
                    oka = ok.setdefault('a', {})
                    for fid, it in a1.items():
                        if a0.get(fid) == it:
                            continue
                        if allow is not None:
                            if fid not in allow:
                                continue
                            if fid in a0 and not any(x0 == a0[fid] and self._ux_live(lyr, u0)
                                                     for x0, u0 in oka.get(fid, ())):
                                continue
                        oka.setdefault(fid, []).append((it, ux))

    def _l1_saved_lock_map(self, poly_lyr):
        """ตาราง {UTM: ชนิด L1} สำหรับตัดสินหมุดตอนบันทึก = _locked_utm_map (แคชทั้งเซสชัน · ไม่สแกนใหม่ทุกครั้งที่บันทึก)
        + แปลงที่ "บันทึกแล้ว" เป็น L1 แต่ถูกแก้ Type ใน buffer นี้ (อ่านค่าที่บันทึกแล้วจาก provider คิวรีเดียว เฉพาะเมื่อมี)
        ⇒ แก้ Type ของแปลง L1 ใน buffer เดียวกันไม่ทำให้หมุดของมันหลุดด่าน · สแกนไม่สำเร็จ = ดูแค่ Type ของหมุด (ลง Log แล้ว)
        ★ 2.4.0 (review DI-11) — + แปลงที่ถูก "ลบ" หรือแก้ UTM ใน buffer (_locked_utm_map อ่านผ่าน buffer ⇒ ไม่เห็น UTM เดิมของแปลงพวกนี้
          ⇒ หมุดของแปลง L1 ที่ถูกลบใน buffer ย้าย/ลบได้ไม่ถาม · Save All Edits บันทึกชั้นหมุดก่อนชั้นแปลงตามลำดับในสารบัญ)
          อ่านค่าที่บันทึกแล้วในคิวรีเดียวกันกับแปลงที่แก้ Type"""
        if poly_lyr is None:
            return {}
        eb = poly_lyr.editBuffer() if poly_lyr.isEditable() else None
        _lf = poly_lyr.fields()                                # index ใน buffer = index ของ fields() ของชั้น
        _w = {i for i in (self._field_index(_lf, 'type'), self._field_index(_lf, _UTM_FIELD_NAMES)) if i >= 0}
        tf = (sorted({fid for fid, ch in eb.changedAttributeValues().items() if fid >= 0 and _w.intersection(ch)}
                     | {fid for fid in eb.deletedFeatureIds() if fid >= 0})
              if eb is not None else [])
        _c0 = getattr(self, "_locked_cache", None)
        try:
            lm = dict(self._locked_utm_map(poly_lyr))
        except _LockScanError:
            lm = {}
            # ★ rc2 (audit A4-07) — ตรวจไม่ครบต้องไม่เงียบ (เดิมลงแค่ Log) ⇒ ผู้เรียกบอกบนแถบหลังบันทึก
            self._l1_gap = "อ่านรายการแปลง L1 จากฐานไม่สำเร็จ — ตัดสินหมุดจาก Type ของหมุดอย่างเดียว"
        if tf and getattr(self, "_locked_cache", None) is not _c0:
            # แคชเพิ่งถูกสร้างตอน buffer มีการแก้ Type/UTM หรือลบแปลง (_locked_utm_map อ่านผ่าน buffer) ⇒ ไม่ทิ้งไว้ใช้ทั้งเซสชัน
            #   (เดิมแคชที่ขาด UTM ของแปลงที่ถูกลบค้างทั้งเซสชัน ⇒ ทิ้งงานแล้วเครื่องมือของปลั๊กอินไม่ล็อกหมุดของแปลงนั้น)
            self._locked_cache = _c0
        pf = poly_lyr.dataProvider().fields()
        ti, ui = self._field_index(pf, 'type'), self._field_index(pf, _UTM_FIELD_NAMES)
        if not tf or ti < 0 or ui < 0:
            return lm
        req = (QgsFeatureRequest().setFilterFids(tf).setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([ti, ui]))
        it = poly_lyr.dataProvider().getFeatures(req)
        try:
            for f in it:
                t, u = _txt(f.attribute(ti)).upper(), f.attribute(ui)
                if t in L1_TYPES and _txt(u):
                    k = _norm_utm(u)
                    if t == "L1-RTK" or k not in lm:
                        lm[k] = t
        finally:
            it.close()
        return lm

    def _l1_commit_hits(self, layers, poly_lyr):
        """แปลง/หมุด L1 ที่งานค้างใน buffer ของ layers จะ "ย้าย/แก้รูป" หรือ "ลบ" ลงฐาน
        -> {'pg': แปลงย้าย, 'pd': แปลงลบ, 'mg': หมุดย้าย, 'md': หมุดลบ, 'pa': แปลงแก้ค่า, 'ma': หมุดแก้ชื่อ/ค่า}
        (ป้ายชื่อ: แปลง = UTM · หมุด = BND_NAME/UTM · แก้ค่า + ชื่อคอลัมน์) · ว่างทุกช่อง = ไม่มี
        ★ rc2 (audit A4-04) — + การแก้ค่าคอลัมน์ใน _l1_attr_watch (ชื่อหมุด · SCORE · Type · คีย์) ที่ต่างจากค่าในฐาน
        ตัดสินจาก "สถานะที่บันทึกแล้ว" (dataProvider + setFilterFids คิวรีเดียวต่อชั้น) ⇒ แก้ Type ใน buffer เดียวกันซ่อนไม่ได้
        แปลง = Type เป็น L1-RTK/L1-TS · หมุด = กติกาเดียวของ DU-01 (lock_rules.marker_lock_type: Type ของหมุด หรือ UTM ตรงแปลง L1)
        ข้าม: ฟีเจอร์ที่เพิ่มใน buffer นี้ (fid ติดลบ) · งานของเครื่องมือปลั๊กอินตอนปลดล็อก L1 (_l1_ok) · ปลดล็อก L1 อยู่ = ไม่ตรวจเลย"""
        out = {'pg': [], 'pd': [], 'mg': [], 'md': [], 'pa': [], 'ma': []}
        self._l1_gap = None                     # ★ rc2 (audit A4-07) เหตุที่ตรวจไม่ครบของรอบนี้ (_l1_saved_lock_map ตั้ง)
        if self._l1_unlocked():
            return out
        lm = None
        done = set()
        for lyr in layers:
            if lyr is None or lyr.id() in done:
                continue
            done.add(lyr.id())
            ok = self._l1_ok.get(lyr.id())
            g, d = self._l1_buf_state(lyr, wkb=bool(ok))      # WKB เฉพาะเมื่อต้องเทียบกับงานที่จดไว้
            is_poly = poly_lyr is not None and lyr.id() == poly_lyr.id()
            # ★ rc2 (audit A4-04) — การแก้ค่า (ตาราง attribute / Identify ของ QGIS): ชื่อหมุด · SCORE · Type · คีย์ ของแปลง/หมุดล็อก
            #   เดิมด่านดูแค่ย้าย/ลบ ⇒ แก้ BND_NAME ของหมุด L1 / ใส่ SCORE ให้แปลง L1 แล้วบันทึกได้โดยไม่ถาม
            #   ขณะที่ ✏️ แก้ชื่อหมุดและ Score ของปลั๊กอินปฏิเสธ L1 (กติกาล็อกสองมาตรฐาน)
            try:
                _wa = self._l1_attr_watch(lyr.fields(), is_poly)
                a = self._l1_buf_attrs(lyr) if _wa else {}
            except Exception:
                _wa, a = {}, {}
            if ok:
                # ★ 2.4.0 (review DI-11) — ใช้เฉพาะรายการที่คำสั่งของ op ยังมีผลบน undo stack (ย้อน op แล้ว = ถามตามปกติ)
                _live = {ux: self._ux_live(lyr, ux)
                         for ux in ({u for _l in ok['g'].values() for _w, u in _l} | set(ok['d'].values())
                                    | {u for _l in ok.get('a', {}).values() for _x, u in _l})}
                okg = {fid: {w for w, ux in _l if _live[ux]} for fid, _l in ok['g'].items()}   # ★ rc1 S5 ลิสต์ต่อฟีเจอร์
                g = {fid: w for fid, w in g.items() if w not in okg.get(fid, ())}
                d = d - {fid for fid, ux in ok['d'].items() if _live[ux]}
                # ★ rc2 S_close (review R3-03) — เทียบเฉพาะคอลัมน์ที่ด่านดู (_wa) · เดิมเทียบทูเพิลทุกคอลัมน์ที่แก้ ⇒ แก้ REMARK/NAME
                #   ของแปลงเดียวกันภายหลัง ทำให้ SCORE ที่ผู้ดูแลแก้ตอนปลดล็อก (งานของปลั๊กอินที่จดไว้) ถูกถามตอนบันทึก
                def _pj(x):
                    return tuple((i, v) for i, v in x if i in _wa)
                oka = {fid: {_pj(x) for x, ux in _l if _live[ux]} for fid, _l in ok.get('a', {}).items()}
                a = {fid: x for fid, x in a.items() if _pj(x) not in oka.get(fid, ())}
            a = {fid: [(i, v) for i, v in x if i in _wa] for fid, x in a.items() if fid not in d}
            a = {fid: x for fid, x in a.items() if x}
            if not g and not d and not a:
                continue
            dp = lyr.dataProvider()
            pf = dp.fields()
            ti, ui = self._field_index(pf, 'type'), self._field_index(pf, _UTM_FIELD_NAMES)
            ni = -1 if is_poly else _fld_idx(pf, "BND_NAME")
            if is_poly and ti < 0:
                continue                                    # ชั้นแปลงไม่มีคอลัมน์ Type = ไม่มีแปลง L1
            if not is_poly and lm is None:
                lm = self._l1_saved_lock_map(poly_lyr)
            _pa = {i: pf.indexOf(nm) for i, nm in _wa.items()}           # index ของชั้น → index ของ provider (ตามชื่อ)
            _sub = {i for i in (ti, ui, ni) if i >= 0} | {j for j in _pa.values() if j >= 0}
            req = (QgsFeatureRequest().setFilterFids(sorted(set(g) | d | set(a)))
                   .setFlags(QgsFeatureRequest.NoGeometry)
                   .setSubsetOfAttributes(sorted(_sub)))
            it = dp.getFeatures(req)
            try:
                for f in it:
                    tp = f.attribute(ti) if ti >= 0 else None
                    u = _txt(f.attribute(ui)) if ui >= 0 else ""
                    if is_poly:
                        if not is_l1_type(tp):
                            continue
                        lab = f"UTM {u}" if u else f"gid {f.id()}"
                    else:
                        if not marker_lock_type(tp, _norm_utm(u), lm):
                            continue
                        nm = _txt(f.attribute(ni)) if ni >= 0 else ""
                        lab = f"หมุด {nm}" if nm else (f"หมุด UTM {u}" if u else f"หมุด gid {f.id()}")
                    if f.id() in d:
                        out['pd' if is_poly else 'md'].append(lab)
                        continue
                    if f.id() in g:
                        out['pg' if is_poly else 'mg'].append(lab)
                    # ค่าที่แก้แล้วเท่าค่าในฐาน (แก้แล้วแก้กลับ) ไม่นับ
                    _ch = [_wa[i] for i, v in a.get(f.id(), ()) if _pa.get(i, -1) >= 0 and _txt(f.attribute(_pa[i])) != v]
                    if _ch:
                        out['pa' if is_poly else 'ma'].append(f"{lab} ({', '.join(_ch)})")
            finally:
                it.close()
        return out

    def _l1_hits_text(self, hits, native=None, pair=None):
        """(หัวข้อ, ข้อความ) ของคำถามก่อนบันทึก — ใช้ทั้งปุ่ม 💾 และปุ่มบันทึกของ QGIS · จำนวน + ตัวอย่าง 3 รายการ (รายชื่อเต็มลง Log)
        ★ 2.4.0 (review DI-11) — native = ชื่อชั้นที่ QGIS กำลังบันทึก (ทางปุ่มของ QGIS): No ระงับได้แค่ชั้นนี้ — Save All Edits บันทึก
          ทีละชั้นตามลำดับในสารบัญ ชั้นที่ลงฐานไปก่อนแล้วย้อนไม่ได้ (เดิมบอก "ยังไม่บันทึกอะไร" ทั้งสองทาง)
          · วิธีย้อน: งานจากเครื่องมือของ QGIS ใช้ Edit ▸ Undo / แผง Undo/Redo ของ QGIS (↺ ของปลั๊กอินย้อนได้แค่งานของปลั๊กอิน)
          · เดิมอ้าง "Edit ▸ Undo History" ซึ่งไม่มีใน QGIS 3.40 (ประวัติอยู่ที่ View ▸ Panels ▸ Undo/Redo)"""
        rows = (('pg', "แปลง L1 ถูกย้าย/แก้รูป", "แปลง"), ('pd', "แปลง L1 ถูกลบ", "แปลง"),
                ('mg', "หมุดล็อก (หมุด L1 / หมุดของแปลง L1) ถูกย้าย", "หมุด"), ('md', "หมุดล็อกถูกลบ", "หมุด"),
                ('pa', "แปลง L1 ถูกแก้ค่า", "แปลง"), ('ma', "หมุดล็อกถูกแก้ชื่อ/ค่า", "หมุด"))     # ★ rc2 (audit A4-04)
        lines, full = [], []
        for k, head, unit in rows:
            labs = sorted(hits.get(k) or [], key=_natkey)
            if not labs:
                continue
            ex = " · ".join(labs[:3]) + (f" · อีก {len(labs) - 3:,} {unit}" if len(labs) > 3 else "")
            lines.append(f"• {head} {len(labs):,} {unit} — {ex}")
            full.append(f"{head}: " + " · ".join(labs))
        try:
            QgsMessageLog.logMessage("ด่าน L1 ก่อนบันทึก — " + " | ".join(full), "MLEP", Qgis.Info)
        except Exception:
            pass
        body = ("งานที่กำลังจะบันทึกมีการแก้แปลง/หมุด L1 (L1-RTK / L1-TS = พิกัดอ้างอิงที่รังวัดแล้ว ถูกล็อกห้ามขยับ):\n"
                + "\n".join(lines) + "\n\n"
                "มักเกิดจากเครื่องมือของ QGIS เอง (Vertex Tool · Move Feature · Delete Selected · "
                "แก้แบบ topological ที่ลากมุมของแปลงข้างเคียงไปด้วย · แก้ค่าในตาราง attribute / Identify) "
                "ซึ่งไม่ผ่านด่านล็อกของปลั๊กอิน\n\n"
                + (f"• No (ค่าตั้งต้น) = ชั้น '{native}' และชั้นคู่ '{pair}' ยังไม่ถูกบันทึก งานที่แก้ไว้ยังอยู่ครบ "
                   "(ถ้ากด Save All Edits ชั้นอื่นที่ QGIS บันทึกไปก่อนหน้านี้ในรอบเดียวกันลงฐานแล้ว)"
                   if native and pair else
                   f"• No (ค่าตั้งต้น) = ชั้น '{native}' ยังไม่ถูกบันทึก งานที่แก้ไว้ยังอยู่ครบ "
                   "(ถ้ากด Save All Edits ชั้นที่ QGIS บันทึกไปก่อนหน้านี้ในรอบเดียวกันลงฐานแล้ว)"
                   if native else "• No (ค่าตั้งต้น) = ยังไม่บันทึกอะไร งานที่แก้ไว้ยังอยู่ครบ")
                + " — ย้อนส่วนที่ไม่ได้ตั้งใจด้วย Edit ▸ Undo ของ QGIS หรือแผง View ▸ Panels ▸ Undo/Redo "
                "(ถ้าแก้ด้วยเครื่องมือของปลั๊กอิน ใช้ ↺ Undo ของปลั๊กอินได้) แล้วบันทึกใหม่\n"
                "• Yes = บันทึกทั้งหมดรวมการแก้ L1 ข้างต้น (เลือกเมื่อตั้งใจแก้จริงเท่านั้น)\n\n"
                "บันทึกต่อหรือไม่?")
        return "พบการแก้ไขแปลง/หมุด L1 ที่ถูกล็อก", body

    def _set_allow_commit(self, lyr, allow):
        """QgsVectorLayer::setAllowCommit ของ C++ (ดู _allow_commit_api) -> True = ค่าในชั้นเป็นตามสั่งแล้ว (อ่านกลับยืนยัน)"""
        fn = getattr(lyr, "setAllowCommit", None)          # PyQGIS รุ่นหน้าอาจ export ให้เอง
        if fn is not None:
            fn(bool(allow))
            return True
        api = _allow_commit_api()
        if api is None:
            return False
        from qgis.PyQt import sip as _sip
        ptr = _sip.unwrapinstance(lyr)
        api[0](ptr, bool(allow))
        return bool(api[1](ptr)) == bool(allow)

    def _get_allow_commit(self, lyr):
        """★ 2.4.0 (review DI-11) — QgsVectorLayer::allowCommit() ของ C++ -> True/False · อ่านไม่ได้ = None"""
        try:
            fn = getattr(lyr, "allowCommit", None)
            if fn is not None:
                return bool(fn())
            api = _allow_commit_api()
            if api is None:
                return None
            from qgis.PyQt import sip as _sip
            return bool(api[1](_sip.unwrapinstance(lyr)))
        except Exception:
            return None

    def _l1_block(self, lyr):
        """ระงับ commit ที่กำลังจะเกิดของชั้นนี้ (setAllowCommit(False)) แล้วคืนให้บันทึกได้ทันทีที่กลับ event loop
        (QGIS เช็คค่านี้ครั้งเดียวหลังยิง beforeCommitChanges ⇒ การบันทึกครั้งถัดไปต้องผ่านได้ตามปกติ) -> True = commit นี้ไม่เกิด
        ★ 2.4.0 (review DI-11) — allowCommit มีเจ้าของอื่น (QgsGeometryValidationService ของ QGIS ตั้ง False ตอนมีข้อผิดพลาดของรูป/
          รอตรวจ topology) ⇒ อ่านก่อน: False อยู่แล้ว = commit นี้ไม่เกิดอยู่แล้ว ไม่แตะและไม่คืน (เดิมคืน True ทับ = ปลดด่านของ QGIS)
          ⇒ ชั้นที่ระงับเองมีค่าเดิม True เสมอ _l1_release จึงคืน True = คืนค่าเดิม"""
        try:
            if self._get_allow_commit(lyr) is False:
                return True
            if not self._set_allow_commit(lyr, False):
                return False
        except Exception:
            return False
        self._l1_blocked.append(lyr.id())
        if len(self._l1_blocked) == 1:
            # ★ rc2 (audit A5-05 · ผู้ตรวจทานพบเพิ่ม) — lambda ถือตัวปลั๊กอินแบบ strong ref: PyQt ถือ bound method ใน singleShot
            #   แบบ weak ref ⇒ instance ถูกเก็บขยะก่อนกลับ event loop (โหลดปลั๊กอินใหม่) = ไม่คืน allowCommit ชั้นนั้นค้าง False ทั้งเซสชัน
            QtCore.QTimer.singleShot(0, lambda _s=self: _s._l1_release())
        return True

    def _l1_pass_round(self, ids):
        """★ rc1 (F3) — จำชั้นของคู่ที่ตอบ "บันทึก" แล้วในรอบบันทึกนี้ (Save All Edits บันทึกทีละชั้นต่อกันโดยไม่กลับ event loop)
        ล้างเมื่อกลับ event loop ⇒ การบันทึกครั้งถัดไปถามตามปกติ
        ★ rc1 S5 (review R3-02) — รวมชุด (เดิมแทนที่) + ตั้งตัวจับเวลาครั้งเดียว · กล่องคำถามของด่าน L1 เป็น modal (event loop ซ้อน)
          ⇒ ตัวจับเวลาทำงานระหว่างกล่องของคู่ถัดไปเปิดอยู่ได้ — ระหว่างนั้นไม่ล้าง (_l1_pass_clear เลื่อนไปหลังกล่องปิด)
          เดิมคำตอบของคู่แรกหายกลางรอบ Save All ของโปรเจกต์หลายสาขา ⇒ ถามซ้ำ และตอบสลับกันได้คู่ครึ่งเดียว"""
        self._l1_pass = set(getattr(self, "_l1_pass", None) or ()) | set(ids)
        if not self._l1_round_arm():
            self._l1_pass = set()

    def _l1_round_arm(self):
        """★ rc2 (audit A4-02 · A4-03) — ตั้งตัวจับเวลาล้าง "สถานะของรอบบันทึก" (ครั้งเดียวต่อรอบ) ใช้ร่วมกันทั้ง _l1_pass
        และ _l1_round · คืน False = ตั้งไม่ได้ (ผู้เรียกไม่จำอะไรข้ามรอบ)
        ตัวจับเวลาถือตัวปลั๊กอินแบบ strong ref (lambda) — PyQt ถือ bound method ใน QTimer.singleShot แบบ weak ref"""
        if getattr(self, "_l1_pass_armed", False):
            return True
        try:
            QtCore.QTimer.singleShot(0, lambda _s=self: _s._l1_pass_clear())
            self._l1_pass_armed = True
            return True
        except Exception:
            return False

    def _l1_round(self):
        """★ rc2 (audit A4-02 · A4-03) — สถานะของ "รอบบันทึก" (Save All Edits ของ QGIS บันทึกทีละชั้นต่อกันโดยไม่กลับ event loop)
        วงจรเดียวกับ _l1_pass / _l1_hold: ล้างใน _l1_pass_clear / _l1_release เมื่อกลับ event loop (เลื่อนเมื่อกล่องด่าน L1 เปิดอยู่)
        {'begun': id ชั้นที่ beforeCommitChanges ยิงแล้ว · 'done': id ชั้นที่ลงฐานสำเร็จ (afterCommitChanges)
         · 'checked': คู่ (id ชั้นแปลง, id ชั้นหมุด) ที่ด่านจับคู่ตรวจแล้วในรอบนี้}"""
        st = getattr(self, "_l1_rnd", None)
        if st is None:
            st = self._l1_rnd = {'begun': set(), 'done': set(), 'checked': set()}
        self._l1_round_arm()
        return st

    def _l1_round_gate(self, lid):
        """★ rc2 (audit A4-03) — Save All Edits ของ QGIS ไม่หยุดเมื่อชั้นหนึ่งบันทึกไม่สำเร็จ (สิทธิ์ไม่พอ / trigger ปฏิเสธ /
        การเชื่อมต่อหลุด / QGIS ระงับเพราะรูปผิด) แล้วบันทึกชั้นคู่ต่อในรอบเดียวกัน ⇒ แปลงกับหมุดลงฐานครึ่งคู่ (ป้าย DI-05 เตือนได้
        แค่หลังเกิด และถ้าล้มเพราะสิทธิ์ ปุ่มบันทึกอีกชั้นก็ล้มซ้ำ) ⇒ จดชั้นที่เริ่มบันทึกในรอบนี้ (_l1_round) · ชั้นคู่ "เริ่มแล้วแต่
        ไม่สำเร็จ" ⇒ ระงับชั้นนี้ด้วย (_l1_block) · คืน True = ระงับ commit นี้แล้ว
        ไม่ทำ: ปุ่ม 💾 ของปลั๊กอิน (หยุดเองเมื่อชั้นแรกล้ม) · ชั้นที่อยู่ใน _l1_hold (ผู้ใช้ตอบ "ยังไม่บันทึก" — ด่าน L1 ระงับพร้อม
        ข้อความของมันเอง) · โปรเจกต์ที่เปิด transaction groups (QGIS บันทึกทั้งกลุ่มพร้อมกันเอง) · ชั้นคู่ลงฐานไปก่อนแล้ว"""
        st = self._l1_round()
        st['begun'].add(lid)
        if getattr(self, "_l1_save_ack", False) or lid in (getattr(self, "_l1_hold", None) or ()):
            return False
        try:
            if QgsProject.instance().transactionMode() != Qgis.TransactionMode.Disabled:
                return False
        except Exception:
            pass
        try:
            me = QgsProject.instance().mapLayer(lid)
            pr = self._l1_pair_of(me)
        except Exception:
            return False
        if pr is None:
            return False
        other = next((l for l in pr if l is not None and l.id() != lid), None)
        if other is None or other.id() not in st['begun'] or other.id() in st['done']:
            return False
        if not self._l1_block(me):
            return False                        # ระงับไม่ได้ (ไม่มี allowCommit บนเครื่องนี้) ⇒ ป้าย DI-05 เตือนหลังบันทึกตามเดิม
        _msg = (f"ชั้น '{me.name()}' ยังไม่ถูกบันทึก — ชั้นคู่ '{other.name()}' บันทึกไม่สำเร็จในรอบเดียวกัน "
                "(กันแปลงกับหมุดลงฐานไม่พร้อมกัน) · งานที่แก้ไว้ยังอยู่ครบทั้งสองชั้น — "
                f"ดูสาเหตุที่ชั้น '{other.name()}' บันทึกไม่ได้ แล้วบันทึกใหม่")
        try:
            QgsMessageLog.logMessage("บันทึกคู่ชั้น: " + _msg, "MLEP", Qgis.Warning)
        except Exception:
            pass
        try:
            self.iface.messageBar().pushMessage("ยังไม่ได้บันทึก", _msg, level=1, duration=20)
        except Exception:
            pass
        return True

    def _l1_lowering_pending(self, poly):
        """★ rc7 — จำนวนแปลงในงานค้างของชั้นแปลงที่ Type ในฐานเป็น L1 แต่ค่าใหม่ไม่ใช่ L1 (ลดจาก L1 ที่ยังไม่บันทึก) · อ่านค่าเดิมจาก provider
        ★ rc8 (ผลตรวจ Windows rc7 ⚪6) อ่านค่าเดิมด้วยเลขช่องของ provider (เดิมใช้เลขช่องของชั้น ⇒ ลบคอลัมน์ใน buffer แล้วอ่านผิดช่อง/นับ 0) ·
        นับแปลง L1 ที่ถูกลบในงานค้างด้วย (ลบแปลง L1 แล้วสร้างคีย์เดิมใหม่ + ลดหมุด ⇒ ต้องลงชั้นแปลงก่อน ไม่งั้นฐานปฏิเสธชั้นหมุดทุกรอบ)"""
        return self._l1_lowered_count(poly, with_deleted=True)

    def _l1_point_lowering_pending(self, pt):
        """★ rc8 (ผลตรวจ Windows rc7 ⚪2) จำนวนหมุดในงานค้างที่ Type ในฐานเป็น L1 แต่ค่าใหม่ไม่ใช่ L1 — ฐานกันด้วย trg_l1_point_guard ขณะแปลง
        คีย์เดียวกันยัง L1 · ชั้นหมุดที่ไม่มีงานแบบนี้บันทึกก่อนชั้นแปลงได้ (ไม่ต้องรอรอบสอง)"""
        return self._l1_lowered_count(pt, with_deleted=False)

    def _l1_lowered_count(self, lyr, with_deleted):
        tf = self._resolve_field(lyr, {'type'})
        eb = lyr.editBuffer() if tf else None
        if eb is None:
            return 0
        idx = lyr.fields().indexOf(tf)
        pidx = lyr.dataProvider().fields().indexOf(tf)
        if pidx < 0:
            return 0
        chg = {fid: a[idx] for fid, a in eb.changedAttributeValues().items() if idx >= 0 and idx in a}
        dels = set(eb.deletedFeatureIds()) if with_deleted else set()
        ids = set(chg) | dels
        if not ids:
            return 0
        req = QgsFeatureRequest().setFilterFids(list(ids)).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([pidx])
        # ★ rc9 (agent A rc8 ⚪3) เทียบตรงตัวแบบ trigger (_l1_exact) — เดิม is_l1_type
        return sum(1 for f in lyr.dataProvider().getFeatures(req)
                   if _l1_exact(f[pidx]) and (f.id() in dels or not _l1_exact(chg.get(f.id()))))

    def _l1_lowered_rows(self, poly):
        """★ rc9 (ผลตรวจ Windows rc8 🟡2 · agent B ⚪3) แปลงในงานค้างของชั้นแปลงที่ลด/ลบจาก L1 -> [{'fid', 'keys', 'deleted', 'bad'}]
        keys = คีย์ UTM เดิม (ในฐาน) + คีย์ใหม่ (ใน buffer) แบบ btrim · bad = เหตุที่ฐานจะปฏิเสธการลด ('' = ฐานรับ): ไม่ใช่ L2-TS ·
        REMARK ไม่ขึ้นต้นด้วยชนิดเหตุ (อ่านแบบ trigger: _l1_remark_split) · 'อื่นๆ' ไม่มีหมายเหตุ (ตัดแบบ trigger) · แปลงที่ลบ = ไม่ตัดสินเหตุ"""
        tf = self._resolve_field(poly, {'type'})
        eb = poly.editBuffer() if tf else None
        if eb is None:
            return []
        fl, pfl = poly.fields(), poly.dataProvider().fields()
        idx, pidx = fl.indexOf(tf), pfl.indexOf(tf)
        if idx < 0 or pidx < 0:
            return []
        uf = self._resolve_field(poly, {'utm'})
        rf = self._resolve_field(poly, {'remark'})
        uidx, puidx = (fl.indexOf(uf), pfl.indexOf(uf)) if uf else (-1, -1)
        ridx, pridx = (fl.indexOf(rf), pfl.indexOf(rf)) if rf else (-1, -1)
        chg_all = eb.changedAttributeValues()
        dels = set(eb.deletedFeatureIds())
        ids = {i for i in (set(fid for fid, a in chg_all.items() if idx in a) | dels) if i >= 0}
        if not ids:
            return []
        req = QgsFeatureRequest().setFilterFids(list(ids)).setFlags(QgsFeatureRequest.NoGeometry)
        req.setSubsetOfAttributes([i for i in (pidx, puidx, pridx) if i >= 0])
        kinds, out = None, []
        for f in poly.dataProvider().getFeatures(req):
            if not _l1_exact(f[pidx]):
                continue
            fid = f.id()
            a = chg_all.get(fid, {})
            deleted = fid in dels
            if not deleted and _l1_exact(a.get(idx)):
                continue
            keys = {_bkey(f[puidx])} if puidx >= 0 else set()
            if uidx >= 0 and uidx in a:
                keys.add(_bkey(a[uidx]))
            keys.discard("")
            bad = ""
            if not deleted:
                nt = a.get(idx)
                if str(nt) != "L2-TS":
                    bad = f"ลดเป็น {_txt(nt) or '(ว่าง)'} — ฐานยอมแค่ L2-TS"
                elif ridx < 0:
                    bad = "ชั้นแปลงไม่มีคอลัมน์ REMARK"
                else:
                    rm = a[ridx] if ridx in a else (f[pridx] if pridx >= 0 else None)
                    if kinds is None:
                        try:
                            kinds = [k for k, _t in self._l1_kinds_for(poly)]
                        except Exception:
                            kinds = [k for k, _t in self._L1_ISSUE_KINDS]
                    k, rest = self._l1_remark_split(rm, kinds)
                    if k is None:
                        bad = "REMARK ไม่ขึ้นต้นด้วยชนิดเหตุ"
                    elif k == "อื่นๆ" and not self._l1_db_note(rest):
                        bad = "เหตุ อื่นๆ ไม่มีหมายเหตุ"
            out.append({'fid': fid, 'keys': keys, 'deleted': deleted, 'bad': bad})
        return out

    def _l1_point_touched_keys(self, pt):
        """★ rc9 (ผลตรวจ Windows rc8 🟡2) คีย์ของหมุดที่มีงานค้างใด ๆ ในชั้นหมุด (ขยับ · ลบ · เพิ่ม · แก้ช่อง) — คีย์เดิมในฐาน + คีย์ใหม่ใน buffer
        (btrim) · ชั้นหมุดไม่มีคอลัมน์คีย์ / อ่านไม่ได้ = None (ผู้เรียกถือว่าแตะ ⇒ ระงับไว้ก่อน)"""
        eb = pt.editBuffer()
        if eb is None:
            return set()
        uf = self._resolve_field(pt, {'utm'})
        if not uf:
            return None
        fl, pfl = pt.fields(), pt.dataProvider().fields()
        uidx, puidx = fl.indexOf(uf), pfl.indexOf(uf)
        if uidx < 0 or puidx < 0:
            return None
        chg = eb.changedAttributeValues()
        old = [i for i in (set(eb.changedGeometries()) | set(chg) | set(eb.deletedFeatureIds())) if i >= 0]
        keys = set()
        if old:
            req = QgsFeatureRequest().setFilterFids(old).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([puidx])
            keys |= {_bkey(f[puidx]) for f in pt.dataProvider().getFeatures(req)}
        keys |= {_bkey(a[uidx]) for a in chg.values() if uidx in a}
        for f in eb.addedFeatures().values():
            try:
                keys.add(_bkey(f.attributes()[uidx]))
            except Exception:
                return None
        keys.discard("")
        return keys

    def _l1_order_gate(self, lid):
        """★ rc7 (ผลตรวจ Windows rc6 🟡A) Save All Edits / Save Layer Edits ของ QGIS บันทึกชั้นหมุดก่อนชั้นแปลง (ชั้นหมุดอยู่บนในโปรเจกต์ V7) ⇒
        ฐานปฏิเสธการลดแปลง L1 (ไม่มีเหตุ) แต่หมุดลงไปแล้ว = หมุด L2-TS · แปลง L1 · ⇒ ชั้นแปลงคู่กันมีการลด Type จาก L1 ที่ยังไม่บันทึก
        ⇒ ระงับชั้นหมุดรอบนี้ (_l1_block) + บอกวิธี · ลดแปลงลงฐานแล้ว trigger ในฐานลด Type หมุดตามแปลงเอง ⇒ บันทึกชั้นหมุดรอบถัดไปได้
        (ฐานมีด่านชั้นหมุด trg_l1_point_guard แล้ว 31 ต.ค. — ด่านนี้ให้ข้อความที่บอกวิธีแก้ และกันกับฐานที่ยังไม่มีด่าน)
        ชั้นหมุดที่ระงับ ⇒ ไม่นับว่า "เริ่มบันทึกแล้ว" (_l1_round_gate จะระงับชั้นแปลงต่อ = Save All ติดตายทั้งคู่)
        ไม่ทำ: ปุ่ม 💾 ของปลั๊กอิน (_l1_save_ack · บันทึกแปลงก่อนหมุดอยู่แล้ว) · transaction groups · ชั้นแปลงไม่มีงานลด L1 · คืน True = ระงับแล้ว"""
        if getattr(self, "_l1_save_ack", False):
            return False
        try:
            if QgsProject.instance().transactionMode() != Qgis.TransactionMode.Disabled:
                return False
        except Exception:
            pass
        me = QgsProject.instance().mapLayer(lid)
        if me is None or self._geom_role(me) != 1:
            return False
        pr = self._l1_pair_of(me)
        poly = pr[0] if pr else None
        if poly is None or poly.id() == lid or not poly.isEditable() or not poly.isModified():
            return False
        # ★ rc9 (ผลตรวจ Windows rc8 🟡2 — ถดถอยจาก rc7) rc8 ระงับชั้นหมุดเฉพาะเมื่อลด Type หมุด L1 ค้าง ⇒ ลด Type แปลง L1 ในตาราง (ไม่แตะ Type หมุด)
        #   + ขยับ/ลบหมุดของแปลงนั้น + Save All ⇒ หมุดลงก่อน ⇒ สำเนา "หมุดเดิม" ในตาราง L1 มีปัญหาเป็นตำแหน่งที่แก้แล้ว (คืน L1 คืนหมุดไม่ครบ)
        #   ⇒ ระงับเมื่อ: ① ลด Type หมุด L1 ค้าง (แบบ rc8) ② มีงานหมุดใด ๆ ของคีย์ที่แปลงกำลังลด/ลบ L1 (คีย์เดิม + คีย์ใหม่)
        #   ③ แปลงที่ลดจะถูกฐานปฏิเสธ (agent B ⚪3 — กันหมุดของแปลงอื่นลงไปก่อนแล้วแปลงล้ม = ครึ่งคู่ระหว่างรอบ)
        #   งานหมุดของคีย์อื่นยังบันทึกรอบเดียวกับแปลงได้ตามเจตนา rc8 (K3)
        # ★ rc11 (ผลตรวจ Windows rc10 · agent B ⚪9) ระหว่างด่านกลางรอบบันทึก: ค่าที่จำไว้ (ปลดล็อก L1 — _l1_prefetch · เปิด 📝) ของชนิดเหตุ/trigger
        #   ใช้ได้แม้เกินเวลา ⇒ ไม่ต่อฐานในเธรดหน้าจอกลางรอบ Save All (ไม่มีค่าที่จำ = ถามแบบเดิม) · ธงแทนพารามิเตอร์ (เทสจำลองแทนฟังก์ชันได้ตามเดิม)
        self._l1_stale_ok = True
        try:
            rows = self._l1_lowered_rows(poly)
            # ★ rc10 (ผลตรวจ Windows rc9 ⚪3 · agent A ⚪5) ชั้นแปลงที่ไม่มี trigger capture (ฐานที่ยังไม่ลง · GPKG/ไฟล์ที่ไม่มี trigger) ⇒ ฐานไม่คัดสำเนา
            #   ไม่ปฏิเสธการลด ⇒ ลำดับบันทึกไม่มีผล · rc9 ระงับ + "แก้เหตุก่อนบันทึก" ค้างผิด · ตรวจไม่ได้ (None) ⇒ ทำแบบเดิม (ระงับไว้ก่อน)
            cap = self._l1_capture_on(poly) if rows else None
        finally:
            self._l1_stale_ok = False
        if not rows:
            return False
        if cap is False:
            return False
        npt = self._l1_point_lowering_pending(me)
        # ★ rc10 (ผลตรวจ Windows rc9 ⚪3) แปลง L1 ที่ลบ: trigger capture ไม่ทำงานตอนลบ (ไม่มีสำเนาให้ผิด) และด่านหมุดกันแค่การลด Type หมุด L1
        #   ⇒ งานหมุดของคีย์ที่ลบ (ลบ/ขยับหมุด) บันทึกก่อนได้ — rc9 ระงับ ⇒ ลบแปลง L1 พร้อมหมุดต้องกด Save All 2 รอบ ·
        #   ลด Type หมุด L1 ค้าง (npt) ยังระงับตามเดิม (ฐานปฏิเสธถ้าแปลง L1 ยังอยู่ในฐาน)
        lk = set().union(*(r['keys'] for r in rows if not r['deleted']))
        tk = self._l1_point_touched_keys(me) if lk else set()
        touch = (tk & lk) if tk is not None else set(lk or {"?"})
        bad = [r for r in rows if r['bad']]
        if not npt and not touch and not bad:
            return False
        if not self._l1_block(me):
            return False
        self._l1_round()['begun'].discard(lid)
        pid, mid = poly.id(), me.id()
        self._l1_order_rel_set(mid, pid)
        if bad:
            self._l1_order_why_set(mid, "แปลงที่ลดยังไม่มีเหตุตอนกดบันทึก")
            # ★ rc9 (ผลตรวจ Windows rc8 ⚪3 · agent B ⚪4) ฐานจะปฏิเสธชั้นแปลงทุกรอบ ⇒ ไม่บอก "กด Save All อีกครั้ง" (กดกี่ครั้งก็ไม่ผ่าน) · ไม่มีปุ่ม
            # ★ rc10 (ผลตรวจ Windows rc9 ⚪7 · agent B) วิธีแก้ที่ใช้ได้จริง — 📝 อ่าน Type จากงานค้าง ⇒ แปลงที่ลด Type ในตารางไปแล้ว แถวเหตุไม่โผล่
            #   (rc9 บอกแค่ "ใช้ 📝 แล้วบันทึกใหม่") ⇒ บอกสองทาง: พิมพ์เหตุลง REMARK ของแปลงในตาราง หรือคืน Type เป็น L1 แล้วลดด้วย 📝
            _why = " · ".join(dict.fromkeys(r['bad'] for r in bad))
            _msg = (f"แก้เหตุก่อนบันทึก — ชั้นแปลง '{poly.name()}' จะถูกฐานปฏิเสธ: แปลง L1 ที่ลด Type {len(bad)} แปลง ({_why}) · "
                    "ต้องลดเป็น L2-TS และ REMARK ขึ้นต้นด้วยชนิดเหตุ เช่น \"ผิดตำแหน่ง: …\" ('อื่นๆ' ต้องมีหมายเหตุ) — "
                    "แก้ช่อง REMARK ของแปลงนั้นในตาราง หรือคืน Type ในตารางเป็นค่าเดิม (L1) แล้วลดใหม่ด้วย 📝 (เลือกเหตุในกล่อง) · "
                    f"ชั้นหมุด '{me.name()}' รอไว้ก่อน (กันแปลงกับหมุดลงฐานไม่พร้อมกัน) · งานที่แก้ไว้ยังอยู่ครบ")
            try:
                QgsMessageLog.logMessage("ลำดับบันทึก (ลด L1): " + _msg, "MLEP", Qgis.Warning)
            except Exception:
                pass
            self._l1_order_bar(mid, "ยังไม่ได้บันทึกชั้นหมุด", _msg, None)
            return True
        _why = " · ".join(x for x in ((f"ลด Type หมุด L1 {npt} จุด" if npt else ""),
                                       (f"มีงานหมุดของแปลงที่ลด L1 {len(touch)} คีย์" if touch else "")) if x)
        self._l1_order_why_set(mid, _why)
        # ★ rc9 (ผลตรวจ Windows rc8 ⚪3 · agent A ⚪4) ข้อความตัดสินหลังรอบบันทึกจบ (กลับ event loop) — rc8 บอก "รอบนี้บันทึกชั้นแปลงก่อน"
        #   ทันที ทั้งที่ผู้ใช้อาจกด Save Layer Edits ของชั้นหมุดอย่างเดียว (ชั้นแปลงไม่ถูกบันทึกรอบนั้น)
        _rb = self._l1_rb_gen_of(pid)       # ★ rc11 เลขรุ่น Rollback ของชั้นแปลงตอนระงับ (ตัดสินแล้วต่าง ⇒ ชั้นแปลงถูกทิ้งงานระหว่างรอ)
        try:
            QtCore.QTimer.singleShot(0, lambda _p=pid, _m=mid, _w=_why, _g=_rb: self._l1_order_notice(_p, _m, _w, _rb=_g))
        except Exception:
            self._l1_order_notice(pid, mid, _why, _rb=_rb)
        return True

    _L1_NOTICE_WAIT_MS = 250        # ★ rc10 ช่วงตรวจซ้ำระหว่างรอกล่อง modal ปิด
    _L1_NOTICE_WAIT_N = 2400        #   ไม่เกิน ~10 นาที แล้วตัดสินตามที่เห็น

    def _l1_rb_gen_of(self, lid):
        """★ rc11 เลขรุ่น Rollback ของชั้น (เพิ่มทุกครั้งที่ทิ้งงาน — _l1_order_rolled_back)"""
        return (getattr(self, "_l1_rb_gen", None) or {}).get(lid, 0)

    def _l1_order_notice(self, pid, mid, why, _tries=0, _rb=None):
        """★ rc9 ข้อความของด่านลำดับบันทึก หลังรอบบันทึกจบ: ชั้นแปลงยังมีการลด L1 ค้าง (ผู้ใช้บันทึกเฉพาะชั้นหมุด / ชั้นแปลงล้ม) ⇒ บอกให้บันทึก
        ชั้นแปลงก่อน (ปุ่มบันทึกทั้งคู่ตามลำดับ) · ชั้นแปลงลงฐานแล้ว ⇒ "กด Save All อีกครั้ง" · ชั้นหมุดไม่มีงานค้างแล้ว ⇒ ไม่แสดง
        ★ rc10 (ผลตรวจ Windows rc9 ⚪2 · agent A ⚪1) มีกล่อง modal เปิดอยู่ (เช่น กล่องถามของด่าน L1 ของชั้นแปลงในรอบเดียวกัน) ⇒ ตัวจับเวลานี้
        ทำงานใน event loop ของกล่อง ก่อนชั้นแปลงลงฐาน ⇒ rc9 แถบค้าง "บันทึกชั้นแปลง … ก่อน" ทั้งที่ลงแล้ว ⇒ รอจนกล่องปิดแล้วค่อยตัดสิน
        ★ rc11 (ผลตรวจ Windows rc10 ⚪8 · agent A ⚪10) _rb = เลขรุ่น Rollback ของชั้นแปลงตอนตั้งข้อความ — ต่างตอนตัดสิน (ชั้นแปลงถูก Rollback ระหว่าง
        รอกล่อง) ⇒ ไม่ขึ้นแถบ (rc10 ถือว่า "ชั้นแปลงไม่ค้าง = ลงฐานแล้ว" ⇒ บอก "รอบนี้บันทึกชั้นแปลงแล้ว" ไม่จริง · แถบอื่นของคู่นี้ปิดตอน Rollback แล้ว)"""
        if not getattr(self, "_alive", True):
            return
        try:
            busy = QtWidgets.QApplication.activeModalWidget() is not None or getattr(self, "_l1_prompting", 0) > 0
        except Exception:
            busy = False
        if busy and _tries < self._L1_NOTICE_WAIT_N:
            try:
                QtCore.QTimer.singleShot(self._L1_NOTICE_WAIT_MS,
                                         lambda _s=self, _p=pid, _m=mid, _w=why, _n=_tries + 1, _g=_rb:
                                         _s._l1_order_notice(_p, _m, _w, _n, _g))
                return
            except Exception:
                pass
        if _rb is not None and self._l1_rb_gen_of(pid) != _rb:
            return
        try:
            poly = QgsProject.instance().mapLayer(pid)
            me = QgsProject.instance().mapLayer(mid)
            if poly is None or me is None or not (me.isEditable() and me.isModified()):
                return
            try:
                pending = bool(poly.isEditable() and poly.isModified() and self._l1_lowered_rows(poly))
            except Exception:
                pending = True
        except RuntimeError:
            return
        if pending:
            _msg = (f"บันทึกชั้นแปลง '{poly.name()}' ก่อน (กดปุ่มทางขวา = บันทึกแปลงแล้วตามด้วยหมุด) — ชั้นหมุด '{me.name()}' ยังไม่บันทึก "
                    f"เพราะ{why} · ฐานลด Type หมุดตามแปลงให้เอง · งานที่แก้ไว้ยังอยู่ครบ")
        else:
            _msg = (f"กด Save All อีกครั้ง (หรือปุ่มทางขวา) เพื่อบันทึกชั้นหมุด '{me.name()}' — รอบนี้บันทึกชั้นแปลง '{poly.name()}' แล้ว "
                    f"(ชั้นหมุดรอเพราะ{why}) · ฐานลด Type หมุดตามแปลงให้เอง")
        try:
            QgsMessageLog.logMessage("ลำดับบันทึก (ลด L1): " + _msg, "MLEP", Qgis.Warning)
        except Exception:
            pass
        self._l1_order_bar(mid, "ยังไม่ได้บันทึกชั้นหมุด", _msg, pid)

    def _l1_order_bar(self, mid, title, msg, pid):
        """★ rc9 (ผลตรวจ Windows rc8 ⚪2) แถบของด่านลำดับบันทึก (pid = ชั้นแปลงของปุ่ม "บันทึกทั้งคู่" · None = ไม่มีปุ่ม) — จำไว้ต่อชั้นหมุด
        ⇒ แถบเดิมของชั้นเดียวกันถูกแทน · ชั้นหมุดบันทึกสำเร็จ ⇒ _half_save_clear ปิดแถบ (rc8 แถบกลับมาแสดงหลังแถบ "บันทึกสำเร็จ" หมดเวลา)"""
        items = getattr(self, "_l1_order_items", None)
        if items is None:
            items = self._l1_order_items = {}
        # ★ rc10 ชั้นแปลงที่แถบอ้างถึง (ปิดแถบเมื่อชั้นแปลงนั้น Rollback) — _l1_order_bar_pop ล้างไปด้วย ⇒ จำไว้แล้วตั้งคืน (pid มาก่อน)
        _rel = pid if pid is not None else (getattr(self, "_l1_order_rels", None) or {}).get(mid)
        self._l1_order_bar_pop(mid)
        if _rel is not None:
            self._l1_order_rel_set(mid, _rel)
        it = None
        try:
            if pid is not None:
                it = self._push_with_button(title, msg, 1, 30, "💾 บันทึกทั้งคู่ (แปลงก่อน)",
                                            lambda _p=pid: self._half_save_button(_p))
            else:
                from qgis.gui import QgsMessageBar
                it = QgsMessageBar.createMessage(title, msg)
                self.iface.messageBar().pushWidget(it, 1, 30)
                try:
                    self._bar_track(it)     # unload ถอดแถบที่ค้าง (แบบแถบมีปุ่ม)
                except Exception:
                    pass
        except Exception:
            it = None
            try:
                self.iface.messageBar().pushMessage(title, msg, level=1, duration=30)
            except Exception:
                pass
        if it is not None:
            items[mid] = it

    def _l1_order_bar_pop(self, mid):
        it = (getattr(self, "_l1_order_items", None) or {}).pop(mid, None)
        (getattr(self, "_l1_order_rels", None) or {}).pop(mid, None)
        if it is not None:
            try:
                self.iface.messageBar().popWidget(it)
            except (RuntimeError, Exception):
                pass

    def _l1_order_why_set(self, mid, why):
        """★ rc10 เหตุที่ระงับชั้นหมุด mid ไว้ (ข้อความของ _l1_order_notice เมื่อตัดสินใหม่)"""
        whys = getattr(self, "_l1_order_whys", None)
        if whys is None:
            whys = self._l1_order_whys = {}
        whys[mid] = why

    def _l1_order_poly_saved(self, pid):
        """★ rc10 (ต่อจากผลตรวจ Windows rc9 ⚪2) ชั้นแปลงที่แถบของด่านลำดับบันทึกอ้างถึงลงฐานแล้ว (เช่น กด Save Layer Edits ของชั้นแปลงเอง
        หลังแถบ 'บันทึกชั้นแปลง … ก่อน' / แก้ REMARK แล้วบันทึกชั้นแปลง) ⇒ ข้อความเดิมไม่จริงแล้ว ⇒ ปิดแถบ แล้วตัดสินข้อความใหม่หลังรอบ
        (ชั้นหมุดยังค้าง ⇒ 'กด Save All อีกครั้ง' · ไม่ค้างแล้ว ⇒ ไม่แสดง) · เรียกจาก _half_save_clear (afterCommitChanges ⇒ เลื่อนไปหลังรอบ)"""
        rels = getattr(self, "_l1_order_rels", None) or {}
        whys = getattr(self, "_l1_order_whys", None) or {}
        items = getattr(self, "_l1_order_items", None) or {}
        for mid in [m for m, p_ in list(rels.items()) if p_ == pid and m in items]:
            why = whys.get(mid) or "รอชั้นแปลง"
            # ★ rc11 (ผลตรวจ Windows rc10 ⚪8 · agent B ⚪6) แถบที่หมดเวลา/ผู้ใช้ปิดไปแล้ว ⇒ ไม่ปลุกขึ้นใหม่ (rc10 จำแถบที่ QGIS ปิดแล้วไว้ ⇒ บันทึกชั้น
            #   แปลงรอบหลัง = แถบเดิมโผล่อีก 30 วิ) · ล้างที่จำไว้ของแถบนั้น
            alive = self._l1_bar_alive(items.get(mid))
            self._l1_order_bar_pop(mid)
            if not alive:
                whys.pop(mid, None)
                continue
            try:
                QtCore.QTimer.singleShot(0, lambda _s=self, _p=pid, _m=mid, _w=why, _g=self._l1_rb_gen_of(pid):
                                         _s._l1_order_notice(_p, _m, _w, _rb=_g))
            except Exception:
                pass

    def _l1_bar_alive(self, it):
        """★ rc11 แถบยังอยู่บนแถบข้อความของ QGIS ไหม (หมดเวลา/ผู้ใช้ปิด ⇒ QGIS ถอดแล้วลบทิ้ง) · ตรวจไม่ได้ = ถือว่ายังอยู่ (แบบ rc10)"""
        if it is None:
            return False
        try:
            from qgis.PyQt import sip
            if sip.isdeleted(it):
                return False
        except Exception:
            pass
        try:
            bar = self.iface.messageBar()
            if bar.currentItem() is it:
                return True
            return any(x is it for x in bar.items())
        except Exception:
            return True

    def _l1_order_rel_set(self, mid, pid):
        """★ rc10 ชั้นแปลงที่แถบของด่านลำดับบันทึก (ของชั้นหมุด mid) อ้างถึง — ใช้ปิดแถบเมื่อชั้นแปลงนั้น Rollback"""
        rels = getattr(self, "_l1_order_rels", None)
        if rels is None:
            rels = self._l1_order_rels = {}
        rels[mid] = pid

    def _l1_order_rolled_back(self, lid):
        """★ rc10 (ผลตรวจ Windows rc9 ⚪7 · agent B) Rollback/ทิ้งงานของชั้นหมุดที่ถูกระงับ หรือของชั้นแปลงที่ถูกอ้าง ⇒ ปิดแถบของด่านลำดับบันทึก
        (rc9 แถบค้างจนหมดเวลา 30 วิ ทั้งที่งานที่ต้องบันทึกถูกทิ้งไปแล้ว)"""
        gen = getattr(self, "_l1_rb_gen", None)
        if gen is None:
            gen = self._l1_rb_gen = {}
        gen[lid] = gen.get(lid, 0) + 1          # ★ rc11 ข้อความที่รอกล่อง modal อยู่ของชั้นนี้ ⇒ ไม่ขึ้น (_l1_order_notice _rb)
        rels = getattr(self, "_l1_order_rels", None) or {}
        for mid in [m for m in list((getattr(self, "_l1_order_items", None) or {}).keys()) if m == lid or rels.get(m) == lid]:
            self._l1_order_bar_pop(mid)

    _L1_CAPTURE_TTL = 300           # ★ rc10 วินาทีที่จำผลตรวจ trigger capture ของชั้นแปลง

    def _l1_capture_on(self, poly):
        """★ rc10 (ผลตรวจ Windows rc9 ⚪3 · agent A ⚪5) ชั้นแปลงนี้มี trigger ที่คัดสำเนา/บังคับเหตุตอนลด L1 ไหม -> True / False / None (ตรวจไม่ได้)
        PostGIS: trigger trg_l1_issue_capture บนตาราง (จำ _L1_CAPTURE_TTL วิ · ด่าน TCP + เพดานต่อฐานแบบ _l1_kinds_for) ·
        GeoPackage: มี trigger บนตาราง (sqlite_master · เปิดอ่านอย่างเดียว) · ชนิดอื่น (shp ฯลฯ) = False
        ★ rc11 ระหว่างด่านลำดับบันทึก (self._l1_stale_ok) มีค่าที่จำไว้ (เช่น ถามตอนปลดล็อก L1 — _l1_prefetch) ⇒ ใช้ค่านั้นแม้เกินเวลา"""
        try:
            pv = poly.providerType()
        except Exception:
            return None
        if pv == "postgres":
            return self._l1_capture_pg(poly)
        if pv == "ogr":
            return self._l1_capture_gpkg(poly)
        return False

    def _l1_capture_pg(self, poly):
        import time as _time
        try:
            from qgis.core import QgsDataSourceUri
            uri = QgsDataSourceUri(poly.dataProvider().dataSourceUri())
            schema, table = uri.schema() or "public", uri.table()
            if not table:
                return None
            key = (uri.host(), uri.port(), uri.database(), uri.service(), schema, table)
        except Exception:
            return None
        cache = getattr(self, "_l1_capture_cache", None)
        if cache is None:
            cache = self._l1_capture_cache = {}
        now = _time.monotonic()
        hit = cache.get(key)
        # ★ rc11 (ผลตรวจ Windows rc10 ⚪5 · agent A ⚪9) เวลา None = จำจนปิด QGIS (ต่อเครื่องได้แต่เข้าฐานไม่ได้ ⇒ ไม่ต่อซ้ำ = ไม่เด้งกล่องรหัส)
        if hit is not None and (getattr(self, "_l1_stale_ok", False) or hit[0] is None or now - hit[0] <= self._L1_CAPTURE_TTL):
            return hit[1]
        val = None
        _t = now
        try:
            _dead = self._role_tcp_dead(uri) if hasattr(self, "_role_tcp_dead") else None
            if _dead:
                raise ConnectionError(_dead)
            if hasattr(self, "_pg_connect_timeout") and hasattr(self, "_ROLE_CONNECT_TIMEOUT_S"):
                with self._pg_connect_timeout(self._ROLE_CONNECT_TIMEOUT_S):
                    rows = self._l1_capture_query(uri, schema, table)
            else:
                rows = self._l1_capture_query(uri, schema, table)
            val = self._l1_capture_val(rows)
        except Exception as e:
            if not isinstance(e, ConnectionError) and hasattr(self, "_pg_login_failed") and self._pg_login_failed(e):
                _t = None
            try:
                QgsMessageLog.logMessage(_scrub("ตรวจ trigger ลด L1 ของชั้น '%s' ไม่ได้ — ด่านลำดับบันทึกทำงานตามเดิม%s: %s: %s"
                                                % (poly.name(), "" if _t is not None else " (เข้าฐานไม่ได้ — ไม่ถามซ้ำจนปิด QGIS)",
                                                   type(e).__name__, str(e).splitlines()[0] if str(e) else ""))[:300],
                                         "MLEP", Qgis.Warning)
            except Exception:
                pass
        cache[key] = (_t, val)
        return val

    @staticmethod
    def _l1_capture_query(uri, schema, table):
        """★ rc10 มี trigger trg_l1_issue_capture (ไม่ปิด) บนตารางนี้ไหม (แยกออกมาให้ _l1_capture_pg ครอบด้วยเพดานต่อฐาน)
        ★ rc11 (ผลตรวจ Windows rc10 ⚪7 · agent A ⚪8) -> แถว (relkind, trigger บนตัวเอง, trigger บนตารางที่ view อ้าง) · ไม่มีชื่อนี้ = ไม่มีแถว
        (rc10 to_regclass ของ view/SQL query ได้ NULL ⇒ False ⇒ ปิดด่านทั้งที่ตารางจริงมี trigger) — ตัดสินใน _l1_capture_val"""
        from qgis.core import QgsProviderRegistry
        conn = QgsProviderRegistry.instance().providerMetadata("postgres").createConnection(uri.connectionInfo(True), {})
        q = lambda s: "'" + str(s).replace("'", "''") + "'"           # noqa: E731 — ค่าคงที่จาก URI ของชั้น (ไม่ใช่ข้อความผู้ใช้)
        _t = "t.tgname = 'trg_l1_issue_capture' AND t.tgenabled <> 'D'"
        return conn.executeSql("SET LOCAL statement_timeout = 3000; "
                               "SELECT c.relkind::text, "
                               "EXISTS (SELECT 1 FROM pg_trigger t WHERE t.tgrelid = c.oid AND " + _t + "), "
                               "EXISTS (SELECT 1 FROM pg_rewrite rw JOIN pg_depend dp ON dp.classid = 'pg_rewrite'::regclass "
                               "AND dp.objid = rw.oid AND dp.refclassid = 'pg_class'::regclass "
                               "JOIN pg_trigger t ON t.tgrelid = dp.refobjid AND " + _t + " WHERE rw.ev_class = c.oid) "
                               "FROM pg_class c WHERE c.oid = to_regclass(format('%I.%I', " + q(schema) + ", " + q(table) + "))")

    @staticmethod
    def _l1_capture_val(rows):
        """★ rc11 แถวของ _l1_capture_query -> True / False / None — ตาราง (r/p) = มี trigger บนตัวเองไหม · view ที่ตารางที่อ้างมี trigger = True ·
        view อื่น / ชนิดอื่น / ไม่มีชื่อนี้ (ชั้น SQL query) = None (ตรวจไม่ได้ ⇒ ด่านทำงานแบบเดิม · ระมัดระวัง)"""
        if not rows or not rows[0]:
            return None
        r = rows[0]

        def _tb(x):
            return str(x).lower() in ("true", "t", "1")

        kind = str(r[0] or "")
        if kind in ("r", "p") and len(r) > 1:
            return _tb(r[1])
        if kind == "v" and len(r) > 2 and _tb(r[2]):
            return True
        return None

    _TRG_HEAD = re.compile(r"\bUPDATE\s+(?:OF\s+(?P<cols>.+?)\s+)?ON\s", re.I | re.S)
    _TRG_TYPE = re.compile(r'(?<![\w$])(?:"type"|`type`|\[type\]|type)(?![\w$])', re.I)
    _TRG_NEWOLD_TYPE = re.compile(r'\b(?:NEW|OLD)\s*\.\s*(?:"type"|`type`|\[type\]|type)(?![\w$])', re.I)

    @classmethod
    def _sqlite_trg_type(cls, sql):
        """★ rc11 (ผลตรวจ Windows rc10 ⚪7 · agent A ⚪7) trigger ของ SQLite นี้ทำงานตอนแก้ Type ไหม (แบบ trg_l1_issue_capture): หัว trigger
        (ก่อน BEGIN) เป็น UPDATE OF <คอลัมน์> ที่มี Type · หรือ UPDATE ทุกคอลัมน์ ที่ WHEN/เนื้อ trigger อ้าง NEW/OLD.Type — rc10 นับ '%update%' +
        '%type%' ทั้งข้อความ ⇒ ตารางที่ชื่อมี type (Landtype_POLYGON) + trigger นับแถวของ GDAL = นับว่ามี (ระงับเกินแบบ rc9)"""
        s = str(sql or "")
        b = re.search(r"\bBEGIN\b", s, re.I)
        m = cls._TRG_HEAD.search(s[:b.start()] if b else s)
        if not m:
            return False
        if m.group("cols") is not None:
            return bool(cls._TRG_TYPE.search(m.group("cols")))
        return bool(cls._TRG_NEWOLD_TYPE.search(s[m.end():]))

    @staticmethod
    def _sqlite_ro_uri(path, nt=None):
        """★ rc11 (ผลตรวจ Windows rc10 ⚪7 · agent B ⚪5) URI อ่านอย่างเดียวของไฟล์ SQLite: file:// + พาธเต็มแบบ / (authority ว่าง) — ไดรฟ์ Windows
        = file:///C:/… · แชร์ UNC = file:////server/share/… · เข้ารหัส % # ? ช่องว่าง ไทย · rc10 ใช้ pathname2url ⇒ พาธ UNC ที่ QGIS เก็บด้วย /
        กลายเป็น file://server/… ⇒ sqlite ปฏิเสธ 'invalid uri authority' ⇒ None (ด่านระงับแบบ rc9) · nt = ทดสอบแบบ Windows บนเครื่องอื่น"""
        import ntpath
        import posixpath
        from urllib.parse import quote
        nt = (os.name == "nt") if nt is None else bool(nt)
        p = (ntpath if nt else posixpath).abspath(path)
        if nt:
            p = p.replace("\\", "/")
            if p.startswith("//?/UNC/"):
                p = "//" + p[8:]
            elif p.startswith("//?/"):
                p = p[4:]
            if not p.startswith("/"):
                p = "/" + p
        return "file://" + quote(p, safe="/:") + "?mode=ro"

    @staticmethod
    def _gpkg_layer_name(path, idx):
        """★ rc11 (ผลตรวจ Windows rc10 ⚪7 · agent A ⚪7) ชื่อตารางของชั้นลำดับ idx ใน GeoPackage ตามที่ OGR นับ (URI แบบ |layerid=N · ไม่บอกชั้น =
        ชั้นแรก) — rc10 ไม่มีชื่อชั้น ⇒ นับ trigger ทั้งไฟล์ (trigger ของชั้นหมุดทำให้ชั้นแปลงถือว่ามี) · ไม่ได้ = None"""
        try:
            import warnings
            from osgeo import ogr
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                ds = ogr.Open(path, 0)
                if ds is None:
                    return None
                try:
                    lyr = ds.GetLayerByIndex(int(idx))
                    return lyr.GetName() if lyr is not None else None
                finally:
                    ds = None
        except Exception:
            return None

    def _l1_capture_gpkg(self, poly):
        try:
            src = poly.dataProvider().dataSourceUri()
            path, _sep, rest = src.partition("|")
            if not path.lower().endswith(".gpkg") or not os.path.isfile(path):
                return False
            m = re.search(r"layername=([^|]+)", rest)
            tbl = m.group(1) if m else None
            if not tbl:
                mi = re.search(r"layerid=(\d+)", rest)
                tbl = self._gpkg_layer_name(path, int(mi.group(1)) if mi else 0)
                if not tbl:
                    return None
            import sqlite3
            con = sqlite3.connect(self._sqlite_ro_uri(path), uri=True, timeout=1.0)    # พาธที่มี % # ? / ไดรฟ์ Windows / แชร์ UNC
            try:
                rows = con.execute("SELECT name, sql FROM sqlite_master WHERE type = 'trigger' AND tbl_name = ? COLLATE NOCASE",
                                   (tbl,)).fetchall()
            finally:
                con.close()
            # trigger ที่ทำงานตอนแก้ Type (แบบ trg_l1_issue_capture) — ไม่นับ trigger ของ GeoPackage/GDAL เอง (rtree_* · gpkg_* · นับจำนวนแถว)
            return any(self._sqlite_trg_type(r[1]) for r in rows
                       if r and r[1] and not str(r[0]).lower().startswith(("rtree_", "gpkg_", "trigger_insert_feature_count",
                                                                          "trigger_delete_feature_count")))
        except Exception:
            return None

    def _l1_pass_clear(self):
        self._l1_pass_armed = False
        if getattr(self, "_l1_prompting", 0) > 0:
            self._l1_after_prompt = True        # ★ rc1 S5 (R3-02) กล่องด่าน L1 เปิดอยู่ = ยังอยู่ในรอบบันทึกเดิม ⇒ ล้างหลังกล่องปิด
            return
        self._l1_pass = set()
        self._l1_rnd = None                     # ★ rc2 (audit A4-02 · A4-03) สถานะของรอบเดียวกัน

    def _l1_release(self):
        """คืนสิทธิ์ commit ให้ชั้นที่ _l1_block ระงับไว้ + ลืมคำตอบ "ยังไม่บันทึก" ของรอบนี้
        (หาชั้นใหม่จากโปรเจกต์ด้วย id — ชั้นที่ถูกถอดออกไปแล้วไม่แตะ ไม่เรียก C++ บนวัตถุที่อาจถูกลบ)
        ★ rc1 S5 (review R3-02) — กล่องคำถามของด่าน L1 เปิดอยู่ (ตัวจับเวลาทำงานใน event loop ซ้อนของกล่อง) ⇒ ยังไม่ลืม
          (เลื่อนไปหลังกล่องปิด) · ชั้นที่ระงับไว้ QGIS ตัดสินไปแล้ว คืนสิทธิ์ช้าลงไม่มีผลกับ commit ที่ผ่านไป"""
        if getattr(self, "_l1_prompting", 0) > 0:
            self._l1_after_prompt = True
            return
        blocked, self._l1_blocked = list(getattr(self, "_l1_blocked", None) or ()), []   # ★ rc2 (A5-05) ทนกับ instance ที่ยังไม่ครบ
        self._l1_hold = set()
        self._l1_pass = set()
        self._l1_rnd = None                     # ★ rc2 (audit A4-02 · A4-03)
        for lid in blocked:
            try:
                lyr = QgsProject.instance().mapLayer(lid)
                if lyr is not None:
                    self._set_allow_commit(lyr, True)
            except Exception:
                pass

    def _l1_pair_of(self, lyr):
        """คู่ (ชั้นแปลง, ชั้นหมุด) ที่ lyr เป็นสมาชิก สำหรับด่าน L1 ตอนบันทึก · ไม่ใช่ชั้นทำงาน = None
        ① คู่ในคอมโบ (แผงเปิดแล้ว) ② ชื่อ <สาขา>_POLYGON / <สาขา>_POINT (ชนิดรูปตรง) + อีกข้างของสาขาเดียวกัน
        (ช่องในคอมโบถ้าเป็นสาขานั้น ไม่งั้นชั้นแรกตามชื่อ) ③ ชั้นที่เปิดจากตารางเดียวกับชั้นใน ①/② (_layer_source_key
        — ชั้นซ้ำ / Duplicate Layer ที่ชื่อไม่ตรงรูปแบบ) ได้คู่ของชั้นนั้น · อีกข้างหาไม่เจอ = None ในช่องนั้น
        (ชั้นหมุดที่ไม่มีชั้นแปลง ⇒ _l1_commit_hits ตัดสินหมุดจาก Type ของหมุดเอง)"""
        if lyr is None:
            return None
        combo = self._combo_pair()
        lid = lyr.id()
        if lid in {l.id() for l in combo if l is not None}:
            return combo
        r = self._geom_role(lyr)
        if r is None:
            return None
        sfx = ("_POLYGON", "_POINT")
        lyrs = list(QgsProject.instance().mapLayers().values())
        b = self._branch_of(lyr.name(), sfx[r])
        if b is None:
            key = self._layer_source_key(lyr)
            if key is None:
                return None
            if combo[r] is not None and self._layer_source_key(combo[r]) == key:
                return (lyr, combo[1]) if r == 0 else (combo[0], lyr)
            b = next((self._branch_of(l.name(), sfx[r]) for l in lyrs
                      if l.id() != lid and self._geom_role(l) == r and self._branch_of(l.name(), sfx[r]) is not None
                      and self._layer_source_key(l) == key), None)
            if b is None:
                # ★ rc2 (audit A5-04) — ④ ชื่อในสารบัญไม่ตรงรูปแบบ (ผู้ใช้ตั้งชื่อเอง เช่น 'แปลง องครักษ์') และไม่มีชั้นอื่นของตารางเดียวกัน
                #   ⇒ ใช้ชื่อตารางของ provider (<สาขา>_POLYGON / <สาขา>_POINT) · เดิมได้ None ⇒ ด่าน L1 ของปุ่มบันทึก QGIS
                #   ไม่ถูกติดให้ชั้นนั้นจนกว่าจะเปิดแผงแล้วเลือกคอมโบ
                b = self._branch_of(self._layer_table_name(lyr), sfx[r])
            if b is None:
                return None
        other = combo[1 - r]
        if other is None or self._layer_branch(other, sfx[1 - r]) != b:
            # ชื่อในสารบัญตรงรูปแบบก่อน (พฤติกรรมเดิม) แล้วค่อยชื่อตาราง (★ rc2 A5-04)
            other = next((l for l in lyrs
                          if self._geom_role(l) == 1 - r and self._branch_of(l.name(), sfx[1 - r]) == b), None)
            if other is None:
                other = next((l for l in lyrs
                              if self._geom_role(l) == 1 - r and self._branch_of(self._layer_table_name(l), sfx[1 - r]) == b),
                             None)
        return (lyr, other) if r == 0 else (other, lyr)

    def _l1_arm_soon(self, *_a):
        """เฝ้าชั้นทำงานทุกชั้นที่รอบ event ถัดไป (รวบหลายสัญญาณ layersAdded ระหว่างโหลดโปรเจกต์เป็นครั้งเดียว)"""
        if not getattr(self, "_alive", True) or getattr(self, "_l1_arm_pending", False):
            return
        self._l1_arm_pending = True
        try:
            QtCore.QTimer.singleShot(0, self._l1_arm_all)
        except Exception:
            self._l1_arm_pending = False

    def _l1_arm_all(self):
        """ต่อ hook commit/rollback (_watch_layer_editing — ครั้งเดียวต่อวัตถุชั้น) ให้ทุกชั้นที่ _l1_pair_of หาคู่ได้
        ⇒ ด่าน L1 ของปุ่มบันทึก QGIS ทำงานตั้งแต่เปิดโปรเจกต์ ไม่ต้องรอเปิดแผง · ไม่เพิ่ม/ลบเลเยอร์ (ทำระหว่างโหลดโปรเจกต์ได้)
        + เตือน Buffered transaction groups ซึ่งข้าม hook นี้ (_check_transaction_mode)"""
        self._l1_arm_pending = False
        if not getattr(self, "_alive", True):
            return
        try:
            lyrs = list(QgsProject.instance().mapLayers().values())
        except Exception:
            return
        for _l in lyrs:
            try:
                if self._geom_role(_l) is not None and self._l1_pair_of(_l) is not None:
                    self._watch_layer_editing(_l)
            except Exception:
                pass
        try:
            self._check_transaction_mode(l1_only=True)
        except Exception:
            pass

    def _l1_native_gate(self, lid):
        """ด่าน L1 ของการบันทึกด้วยปุ่มของ QGIS (Save Layer Edits · ปิดโหมดแก้ไข · Save All Edits) — เรียกจาก on_before_commit_check
        คืน True = ผู้ใช้ตอบ "ยังไม่บันทึก" และระงับ commit นี้แล้ว (งานยังอยู่ใน buffer พร้อมประวัติ Undo ครบ)
        ไม่ถาม: ปุ่ม 💾 ของปลั๊กอินกำลังบันทึก (ถามไปแล้ว) · ปลดล็อก L1 อยู่ · ไม่ใช่ชั้นทำงาน · ไม่มีการแก้ L1
        ★ 2.4.0 (review DI-11) — ชั้นทำงาน = ทุกชั้นที่ _l1_pair_of หาคู่ได้ (ไม่ต้องเปิดแผง · ทุกสาขา · ชั้นซ้ำของตารางเดียวกัน)
          ไม่ใช่แค่คู่ในคอมโบ · allowCommit เป็น False อยู่แล้ว (เจ้าของอื่นระงับ) = ไม่ถาม
        ⚠️ กล่องคำถามเปิด "ก่อน" QGIS เริ่มเขียน (beforeCommitChanges ยิงก่อนแตะ buffer) — จุดเดียวที่ยังหยุดการบันทึกของ QGIS ได้"""
        if self._l1_save_ack or self._l1_unlocked():
            return False
        try:
            me = QgsProject.instance().mapLayer(lid)
            pr = self._l1_pair_of(me)
        except Exception:
            return False
        if pr is None:
            return False
        poly, point = pr
        # ★ rc1 S5 (review R3-02) — ดู "ยังไม่บันทึก" ก่อน "บันทึก" (ชั้นที่อยู่ในสองคู่ — ชั้นซ้ำของตารางเดียวกัน — ตอบไม่บันทึกชนะ)
        if lid in self._l1_hold:
            # อีกชั้นของคู่เพิ่งตอบ "ยังไม่บันทึก" ในรอบเดียวกัน (Save All Edits) ⇒ ระงับด้วย ไม่ถามซ้ำ (กันบันทึกครึ่งคู่)
            if not self._l1_block(me):
                return False
            try:
                # ★ 2.4.0 (review DI-11) — เดิมไม่บอก (แถบข้อความบอกแค่ชั้นแรก)
                self.iface.messageBar().pushMessage(
                    "ยังไม่ได้บันทึก",
                    f"ชั้น '{me.name()}' ยังไม่ถูกบันทึกด้วย — เป็นคู่ของชั้นที่เพิ่งตอบไม่บันทึก "
                    "(กันแปลงกับหมุดลงฐานไม่พร้อมกัน) · งานที่แก้ไว้ยังอยู่ครบ",
                    level=1, duration=15)
            except Exception:
                pass
            return True
        if lid in getattr(self, "_l1_pass", ()):
            # ★ rc1 (F3) — อีกชั้นของคู่เพิ่งตอบ "บันทึก" ในรอบเดียวกัน (Save All Edits) โดยเห็นงานของทั้งคู่แล้ว ⇒ ไม่ถามซ้ำ
            return False
        if self._get_allow_commit(me) is False:
            # ★ 2.4.0 (review DI-11) — commit นี้ไม่เกิดอยู่แล้ว (เช่น geometry validation ของ QGIS ระงับไว้) ⇒ ไม่ถาม
            #   (ตอบ Yes ก็บันทึกไม่ได้) · บันทึกครั้งที่ผ่านได้จริงจะถามเอง
            return False
        # ★ rc1 (F3 · review B1-03) — ตรวจงานของ "ทั้งคู่" ตั้งแต่ชั้นแรกของคู่ที่ QGIS บันทึก
        #   เดิมตรวจแค่ชั้นที่กำลังบันทึก ⇒ Save All Edits บันทึกตามลำดับในสารบัญ (ไฟล์ V3 ทั้ง 5 สาขาวาง _POINT เหนือ _POLYGON):
        #   ชั้นหมุดไม่มีงาน L1 = ลงฐานเงียบ แล้วชั้นแปลงถาม → No (ค่าตั้งต้น) ⇒ หมุดลงฐานแต่แปลงไม่ลง = คู่ครึ่งเดียว (ทำซ้ำแล้ว)
        #   ⇒ ถามตั้งแต่ชั้นแรก · No = ระงับชั้นนี้ + ชั้นคู่ (_l1_hold) · Yes = ชั้นคู่ไม่ถามซ้ำในรอบเดียวกัน (_l1_pass)
        other = next((l for l in (poly, point) if l is not None and l.id() != lid), None)
        try:
            hits = self._l1_commit_hits([me] + ([other] if other is not None else []), poly)
        except Exception:
            _log_exc("ด่าน L1 ก่อนบันทึก (ปุ่มของ QGIS) ตรวจไม่ได้")
            self._pending_l1_gap = (lid, "ตรวจไม่ได้ (เกิดข้อผิดพลาด — รายละเอียดใน Log Messages แท็บ MLEP)")   # ★ rc2 (A4-07)
            return False
        if getattr(self, "_l1_gap", None):
            self._pending_l1_gap = (lid, self._l1_gap)      # ★ rc2 (audit A4-07) บอกหลังบันทึก (ไม่ขวาง · แบบด่านจับคู่ ER-01)
        if not any(hits.values()):
            return False
        _pair_nm = other.name() if (other is not None and other.isEditable() and other.isModified()) else None
        title, body = self._l1_hits_text(hits, native=me.name(), pair=_pair_nm)
        if getattr(me, "setAllowCommit", None) is None and _allow_commit_api() is None:
            # เครื่องนี้ระงับการบันทึกของ QGIS ไม่ได้ ⇒ เตือนอย่างเดียว (ไม่ถามคำถามที่ตอบ "ไม่" แล้วหยุดไม่ได้)
            try:
                self.iface.messageBar().pushMessage(
                    "⚠️ " + title,
                    f"ชั้น '{me.name()}' กำลังบันทึกการแก้แปลง/หมุด L1 — ปุ่มบันทึกของ QGIS บนเครื่องนี้หยุดให้ไม่ได้ · "
                    "ถ้าไม่ได้ตั้งใจ ให้แจ้งผู้ดูแล (รายชื่ออยู่ใน Log Messages แท็บ MLEP) · บันทึกด้วย 💾 ของปลั๊กอินจะถามก่อนเสมอ",
                    level=2, duration=0)
            except Exception:
                pass
            return False
        # ★ 2.4.0 (review DI-11) — Toggle Editing ▸ Save / ปิดโปรเจกต์ / ปิด QGIS เรียก commit ใต้ cursor นาฬิกาทราย (QGIS ตั้งเอง)
        #   ⇒ คำถามขึ้นใต้นาฬิกาทราย = ดูเหมือนโปรแกรมค้าง (กติกาเดียวกับ _Busy) ⇒ ลูกศรปกติระหว่างถาม แล้วคืนของเดิม
        _cur = False
        try:
            QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.ArrowCursor)
            _cur = True
        except Exception:
            pass
        # ★ rc1 S5 (review R3-02) — นับกล่องด่าน L1 ที่เปิดอยู่ ⇒ ตัวจับเวลาล้างคำตอบของรอบ (_l1_pass_clear / _l1_release)
        #   ที่ทำงานใน event loop ซ้อนของกล่องไม่ลืมคำตอบกลางรอบ · กล่องปิดแล้วค่อยตั้งตัวจับเวลาใหม่ (ครั้งเดียว)
        self._l1_prompting = getattr(self, "_l1_prompting", 0) + 1
        try:
            ans = self._ask(QtWidgets.QMessageBox.Question, title, body,
                            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        finally:
            self._l1_prompting = max(0, getattr(self, "_l1_prompting", 1) - 1)
            if self._l1_prompting == 0 and getattr(self, "_l1_after_prompt", False):
                self._l1_after_prompt = False
                try:
                    QtCore.QTimer.singleShot(0, lambda _s=self: _s._l1_release())   # ★ rc2 (A5-05) strong ref
                except Exception:
                    pass
            if _cur:
                try:
                    QtWidgets.QApplication.restoreOverrideCursor()
                except Exception:
                    pass
        if ans == QtWidgets.QMessageBox.Yes:
            self._l1_pass_round({l.id() for l in (poly, point, me) if l is not None})
            return False
        if not self._l1_block(me):
            # ★ 2.4.0 (review DI-11) — ผู้ใช้ตอบไม่บันทึก แต่ระงับไม่สำเร็จ (อ่านค่ากลับไม่ตรง/เรียก C++ ล้ม) ⇒ QGIS บันทึกต่อ
            #   เดิมเงียบ ⇒ แถบแดงค้าง + Log ระดับ Warning (รายชื่อเต็มลง Log แล้วใน _l1_hits_text)
            try:
                QgsMessageLog.logMessage(
                    f"ด่าน L1: ผู้ใช้ตอบไม่บันทึก แต่ระงับการบันทึกของชั้น '{me.name()}' ไม่สำเร็จ — "
                    "การแก้แปลง/หมุด L1 ข้างบนถูกบันทึกลงฐาน", "MLEP", Qgis.Warning)
            except Exception:
                pass
            try:
                self.iface.messageBar().pushMessage(
                    "⚠️ หยุดการบันทึกไม่สำเร็จ",
                    f"ชั้น '{me.name()}' ถูกบันทึกต่อ รวมการแก้แปลง/หมุด L1 ที่ถามไป — ปลั๊กอินหยุดการบันทึกของ QGIS ไม่ได้ · "
                    "รายชื่ออยู่ใน Log Messages แท็บ MLEP · ถ้าไม่ได้ตั้งใจ ให้แจ้งผู้ดูแลฐานข้อมูล",
                    level=2, duration=0)
            except Exception:
                pass
            return False
        self._l1_hold = set(self._l1_hold or ()) | {l.id() for l in (poly, point, me) if l is not None}   # ★ rc1 S5 (R3-02) รวมชุด
        try:
            self.iface.messageBar().pushMessage(
                "ยังไม่ได้บันทึก",
                f"ชั้น '{me.name()}' ยังไม่ถูกบันทึก — งานที่แก้ไว้ยังอยู่ครบ · ย้อนการแก้แปลง/หมุด L1 ที่ไม่ได้ตั้งใจ "
                "(Edit ▸ Undo ของ QGIS หรือแผง View ▸ Panels ▸ Undo/Redo) แล้วบันทึกใหม่",
                level=1, duration=15)
        except Exception:
            pass
        return True
