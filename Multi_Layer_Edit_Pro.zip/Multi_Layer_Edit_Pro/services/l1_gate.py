# -*- coding: utf-8 -*-
"""ด่านล็อก L1 ตอนบันทึก (review DI-11): งานค้างที่ย้าย/ลบแปลงหรือหมุด L1 ต้องถามก่อน ทั้งปุ่ม 💾 ของปลั๊กอินและปุ่มบันทึกของ QGIS

2.4.0: แยกจาก main.py แบบย้ายตรงตัว (devtools/split_main.py) — เนื้อโค้ดเหมือนเดิมทุกบรรทัด"""
import os
from qgis.PyQt import QtCore, QtWidgets
from qgis.core import Qgis, QgsFeatureRequest, QgsMessageLog, QgsProject
from ..core.util import _fld_idx, _LockScanError, _log_exc, _natkey, _norm_utm, _txt, _UTM_FIELD_NAMES
from ..lock_rules import is_l1_type, L1_TYPES, marker_lock_type


_ALLOW_COMMIT_API = []     # ★ 2.4.0 (review DI-11) แคชผลหา: [] = ยังไม่หา · [None] = ไม่มี · [(set, get)]


def _allow_commit_api():
    """★ 2.4.0 (review DI-11) — QgsVectorLayer::setAllowCommit(bool) / allowCommit() ของ C++ (มีตั้งแต่ QGIS 3.4)
    QGIS เช็คค่านี้ "ทันทีหลังยิง beforeCommitChanges" ⇒ ทางเดียวที่ปลั๊กอินระงับการบันทึกด้วยปุ่มของ QGIS ได้
    แต่ PyQGIS ไม่ export สองเมธอดนี้ (SIP_SKIP — ตรวจบน 3.40.6 แล้ว: ไม่มีทั้งเมธอดและ Q_PROPERTY)
    ⇒ เรียกสัญลักษณ์ที่ qgis_core export ไว้โดยตรงด้วย ctypes · ชื่อ mangled เข้ารหัสชนิดพารามิเตอร์ไว้ ⇒ หาเจอ = signature ตรง
    หาไม่เจอ (ระบบ/รุ่นอื่น) = None ⇒ ผู้เรียกถอยไปแค่เตือน (ไม่ถามคำถามที่ตอบ "ไม่" แล้วหยุดไม่ได้)"""
    if _ALLOW_COMMIT_API:
        return _ALLOW_COMMIT_API[0]
    api = None
    try:
        import ctypes
        import ctypes.util
        if os.name == "nt":       # MSVC x64
            names = ("?setAllowCommit@QgsVectorLayer@@QEAAX_N@Z", "?allowCommit@QgsVectorLayer@@QEBA_NXZ")
            libs = ["qgis_core.dll"]          # โหลดอยู่แล้วในโปรเซส ⇒ ได้ handle ตัวเดิม
        else:                     # Itanium (Linux / macOS)
            names = ("_ZN14QgsVectorLayer14setAllowCommitEb", "_ZNK14QgsVectorLayer11allowCommitEv")
            libs = [None, ctypes.util.find_library("qgis_core")]
        for ln in libs:
            try:
                lib = ctypes.CDLL(ln)
                s, g = getattr(lib, names[0]), getattr(lib, names[1])
            except (OSError, AttributeError, TypeError):
                continue
            s.argtypes, s.restype = (ctypes.c_void_p, ctypes.c_bool), None
            g.argtypes, g.restype = (ctypes.c_void_p,), ctypes.c_bool
            api = (s, g)
            break
    except Exception:
        api = None
    _ALLOW_COMMIT_API.append(api)
    return api


class L1CommitGateMixin:
    """ด่านล็อก L1 ตอนบันทึก (review DI-11): งานค้างที่ย้าย/ลบแปลงหรือหมุด L1 ต้องถามก่อน ทั้งปุ่ม 💾 ของปลั๊กอินและปุ่มบันทึกของ QGIS"""

    # ---------- ★ 2.4.0 (review DI-11) ด่านล็อก L1 ตอนบันทึก ----------
    #   เดิมล็อก L1 มีแค่ตอน "เริ่มเครื่องมือของปลั๊กอิน" · Vertex Tool / Move Feature / Delete Selected ของ QGIS
    #   (รวมแก้แบบ topological ที่ลากมุมของแปลงข้างเคียงไปด้วย) ย้าย/ลบแปลง L1 และหมุดล็อกแล้วบันทึกได้โดยไม่มีคำเตือน
    #   ⇒ ตรวจจาก edit buffer ตอนบันทึกทั้งสองทาง (ปุ่ม 💾 ของปลั๊กอิน · ปุ่มบันทึกของ QGIS) แล้วถาม (เจ้าของงานตัดสิน "เตือนแล้วถาม")
    @staticmethod
    def _l1_buf_state(lyr, wkb=True):
        """ฟีเจอร์ "ที่มีอยู่แล้วในฐาน" ที่ buffer จะเปลี่ยนรูป/ลบ -> ({fid: wkb | None}, {fid})
        fid ติดลบ = เพิ่มใน buffer นี้ (ยังไม่มีในฐาน) ⇒ ข้าม · wkb=False ไม่แปลงรูปเป็น WKB (ได้ None — ใช้เมื่อไม่ต้องเทียบ)"""
        eb = lyr.editBuffer() if lyr is not None and lyr.isEditable() else None
        if eb is None:
            return {}, set()
        g = {fid: (bytes(geom.asWkb()) if wkb else None)
             for fid, geom in eb.changedGeometries().items() if fid >= 0}
        return g, {fid for fid in eb.deletedFeatureIds() if fid >= 0}

    @staticmethod
    def _l1_buf_attrs(lyr):
        """★ rc2 (audit A4-04) — ค่าที่ buffer แก้ของฟีเจอร์ "ที่มีอยู่แล้วในฐาน" -> {fid: ((index, ค่าเป็นข้อความ), ...)} (fid ≥ 0)"""
        eb = lyr.editBuffer() if lyr is not None and lyr.isEditable() else None
        if eb is None:
            return {}
        out = {}
        for fid, amap in eb.changedAttributeValues().items():
            if fid >= 0 and amap:
                out[fid] = tuple(sorted((int(i), _txt(v)) for i, v in amap.items()))
        return out

    def _l1_attr_watch(self, fields, is_poly):
        """★ rc2 (audit A4-04) — คอลัมน์ที่ด่าน L1 ตอนบันทึกดู "การแก้ค่า" (ชื่อ ไม่สนตัวพิมพ์) -> {index: ชื่อ}
        แปลง L1: SCORE · Type · คีย์ (UTM / UTMMAP1-4 / UTMSCALE / LANDNO) · หมุดล็อก: + BND_NAME
        (เครื่องมือของปลั๊กอินที่เขียนคอลัมน์เหล่านี้ปฏิเสธแปลง/หมุด L1 ทั้งหมดจนกว่าจะปลดล็อก — ✏️ ชื่อหมุด · Score · 🏷 · 📝)"""
        want = {n.upper() for n in self._L1_ATTR_COLS} | {n.upper() for n in _UTM_FIELD_NAMES}
        if not is_poly:
            want.add("BND_NAME")
        out = {}
        for i in range(fields.count()):
            nm = fields.at(i).name()
            if nm.upper() in want:
                out[i] = nm
        return out

    def _l1_note_ok(self, base, pre, only=None, pre_a=None):
        """จดงานของเครื่องมือปลั๊กอินที่ทำตอนปลดล็อก L1 (เรียกจาก _op_commit) ⇒ ด่านตอนบันทึกไม่ถาม แม้ล็อกกลับก่อนกดบันทึก
        จดรูปหลังทำไว้ด้วย: ถ้าภายหลังมีเครื่องมืออื่นแก้ฟีเจอร์เดิมต่อ (รูปไม่ตรงที่จด) ด่านถามตามปกติ
        base = _op_baseline {lid: (lyr, index)} · pre = {lid: สภาพ buffer ก่อน op} จาก _op_begin
        ★ 2.4.0 (review DI-11) — จดตัวตนคำสั่งของ op บน undo stack (_ux_mark) คู่กับทุกรายการ ⇒ ย้อน op นั้นแล้ว (Undo ของ QGIS /
          ↺ ของปลั๊กอิน) รายการหมดผล (_l1_commit_hits เช็คด้วย _ux_live) · เดิมรายการ "ลบ" อยู่จนบันทึก/ทิ้งงาน ⇒ ย้อนการลบแล้ว
          ล็อกกลับ แล้วลบฟีเจอร์เดิมด้วย Delete Selected ของ QGIS = ไม่ถาม
        ★ rc1 S5 (review R3-01) — only = {layer id: {fid}} (ข้อยกเว้น Transform 2 จุดของ L1-TS · ไม่ได้ปลดล็อก) ⇒ จดเฉพาะฟีเจอร์ในชุด
          และข้ามฟีเจอร์ที่รูปใน buffer "ก่อน op" ต่างจากฐานโดยไม่มีรายการอนุญาตที่ยังมีผลตรงรูปนั้น (งานจาก Vertex Tool /
          Move Feature ของ QGIS ที่ยังไม่ได้อนุญาต) ⇒ ด่านตอนบันทึกยังถาม (เดิมรูปที่บิดติดไปกับผล Transform แล้วถูกจดว่าอนุญาต)
          · เก็บรายการต่อฟีเจอร์เป็นลิสต์ ⇒ ทำซ้ำแล้วย้อนครั้งหลัง รูปกลับไปเท่าผลครั้งก่อนที่ยังมีผล = ไม่ถาม (เดิมถามเกิน)"""
        for lid, (lyr, _i) in base.items():
            if lid not in pre:
                continue
            try:
                g0, d0 = pre[lid]
                g1, d1 = self._l1_buf_state(lyr)
            except Exception:
                continue
            ux = self._ux_mark(lyr)
            ok = self._l1_ok.setdefault(lid, {'g': {}, 'd': {}})     # {'g': {fid: [(wkb, ux), ...]}, 'd': {fid: ux}}
            allow = None if only is None else only.get(lid, set())
            for fid, w in g1.items():
                if g0.get(fid) == w:
                    continue
                if allow is not None:
                    if fid not in allow:
                        continue
                    if fid in g0 and not any(w0 == g0[fid] and self._ux_live(lyr, u0)
                                             for w0, u0 in ok['g'].get(fid, ())):
                        continue                    # มีงาน L1 ที่ยังไม่อนุญาตค้างอยู่ก่อน op ⇒ ไม่จด (บันทึกแล้วถาม)
                ok['g'].setdefault(fid, []).append((w, ux))
            if allow is None:
                for fid in d1 - d0:
                    ok['d'][fid] = ux
            # ★ rc2 (audit A4-04) — ค่าที่ op นี้แก้ (ด่านตอนบันทึกดูการแก้ค่าของแปลง/หมุด L1 ด้วยแล้ว) · กติกาเดียวกับรูป
            if pre_a is not None and lid in pre_a:
                try:
                    a0, a1 = pre_a[lid] or {}, self._l1_buf_attrs(lyr)
                except Exception:
                    a0, a1 = None, {}
                if a0 is not None:
                    oka = ok.setdefault('a', {})
                    for fid, it in a1.items():
                        if a0.get(fid) == it:
                            continue
                        if allow is not None:
                            if fid not in allow:
                                continue
                            if fid in a0 and not any(x0 == a0[fid] and self._ux_live(lyr, u0)
                                                     for x0, u0 in oka.get(fid, ())):
                                continue
                        oka.setdefault(fid, []).append((it, ux))

    def _l1_saved_lock_map(self, poly_lyr):
        """ตาราง {UTM: ชนิด L1} สำหรับตัดสินหมุดตอนบันทึก = _locked_utm_map (แคชทั้งเซสชัน · ไม่สแกนใหม่ทุกครั้งที่บันทึก)
        + แปลงที่ "บันทึกแล้ว" เป็น L1 แต่ถูกแก้ Type ใน buffer นี้ (อ่านค่าที่บันทึกแล้วจาก provider คิวรีเดียว เฉพาะเมื่อมี)
        ⇒ แก้ Type ของแปลง L1 ใน buffer เดียวกันไม่ทำให้หมุดของมันหลุดด่าน · สแกนไม่สำเร็จ = ดูแค่ Type ของหมุด (ลง Log แล้ว)
        ★ 2.4.0 (review DI-11) — + แปลงที่ถูก "ลบ" หรือแก้ UTM ใน buffer (_locked_utm_map อ่านผ่าน buffer ⇒ ไม่เห็น UTM เดิมของแปลงพวกนี้
          ⇒ หมุดของแปลง L1 ที่ถูกลบใน buffer ย้าย/ลบได้ไม่ถาม · Save All Edits บันทึกชั้นหมุดก่อนชั้นแปลงตามลำดับในสารบัญ)
          อ่านค่าที่บันทึกแล้วในคิวรีเดียวกันกับแปลงที่แก้ Type"""
        if poly_lyr is None:
            return {}
        eb = poly_lyr.editBuffer() if poly_lyr.isEditable() else None
        _lf = poly_lyr.fields()                                # index ใน buffer = index ของ fields() ของชั้น
        _w = {i for i in (self._field_index(_lf, 'type'), self._field_index(_lf, _UTM_FIELD_NAMES)) if i >= 0}
        tf = (sorted({fid for fid, ch in eb.changedAttributeValues().items() if fid >= 0 and _w.intersection(ch)}
                     | {fid for fid in eb.deletedFeatureIds() if fid >= 0})
              if eb is not None else [])
        _c0 = getattr(self, "_locked_cache", None)
        try:
            lm = dict(self._locked_utm_map(poly_lyr))
        except _LockScanError:
            lm = {}
            # ★ rc2 (audit A4-07) — ตรวจไม่ครบต้องไม่เงียบ (เดิมลงแค่ Log) ⇒ ผู้เรียกบอกบนแถบหลังบันทึก
            self._l1_gap = "อ่านรายการแปลง L1 จากฐานไม่สำเร็จ — ตัดสินหมุดจาก Type ของหมุดอย่างเดียว"
        if tf and getattr(self, "_locked_cache", None) is not _c0:
            # แคชเพิ่งถูกสร้างตอน buffer มีการแก้ Type/UTM หรือลบแปลง (_locked_utm_map อ่านผ่าน buffer) ⇒ ไม่ทิ้งไว้ใช้ทั้งเซสชัน
            #   (เดิมแคชที่ขาด UTM ของแปลงที่ถูกลบค้างทั้งเซสชัน ⇒ ทิ้งงานแล้วเครื่องมือของปลั๊กอินไม่ล็อกหมุดของแปลงนั้น)
            self._locked_cache = _c0
        pf = poly_lyr.dataProvider().fields()
        ti, ui = self._field_index(pf, 'type'), self._field_index(pf, _UTM_FIELD_NAMES)
        if not tf or ti < 0 or ui < 0:
            return lm
        req = (QgsFeatureRequest().setFilterFids(tf).setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([ti, ui]))
        it = poly_lyr.dataProvider().getFeatures(req)
        try:
            for f in it:
                t, u = _txt(f.attribute(ti)).upper(), f.attribute(ui)
                if t in L1_TYPES and _txt(u):
                    k = _norm_utm(u)
                    if t == "L1-RTK" or k not in lm:
                        lm[k] = t
        finally:
            it.close()
        return lm

    def _l1_commit_hits(self, layers, poly_lyr):
        """แปลง/หมุด L1 ที่งานค้างใน buffer ของ layers จะ "ย้าย/แก้รูป" หรือ "ลบ" ลงฐาน
        -> {'pg': แปลงย้าย, 'pd': แปลงลบ, 'mg': หมุดย้าย, 'md': หมุดลบ, 'pa': แปลงแก้ค่า, 'ma': หมุดแก้ชื่อ/ค่า}
        (ป้ายชื่อ: แปลง = UTM · หมุด = BND_NAME/UTM · แก้ค่า + ชื่อคอลัมน์) · ว่างทุกช่อง = ไม่มี
        ★ rc2 (audit A4-04) — + การแก้ค่าคอลัมน์ใน _l1_attr_watch (ชื่อหมุด · SCORE · Type · คีย์) ที่ต่างจากค่าในฐาน
        ตัดสินจาก "สถานะที่บันทึกแล้ว" (dataProvider + setFilterFids คิวรีเดียวต่อชั้น) ⇒ แก้ Type ใน buffer เดียวกันซ่อนไม่ได้
        แปลง = Type เป็น L1-RTK/L1-TS · หมุด = กติกาเดียวของ DU-01 (lock_rules.marker_lock_type: Type ของหมุด หรือ UTM ตรงแปลง L1)
        ข้าม: ฟีเจอร์ที่เพิ่มใน buffer นี้ (fid ติดลบ) · งานของเครื่องมือปลั๊กอินตอนปลดล็อก L1 (_l1_ok) · ปลดล็อก L1 อยู่ = ไม่ตรวจเลย"""
        out = {'pg': [], 'pd': [], 'mg': [], 'md': [], 'pa': [], 'ma': []}
        self._l1_gap = None                     # ★ rc2 (audit A4-07) เหตุที่ตรวจไม่ครบของรอบนี้ (_l1_saved_lock_map ตั้ง)
        if self._l1_unlocked():
            return out
        lm = None
        done = set()
        for lyr in layers:
            if lyr is None or lyr.id() in done:
                continue
            done.add(lyr.id())
            ok = self._l1_ok.get(lyr.id())
            g, d = self._l1_buf_state(lyr, wkb=bool(ok))      # WKB เฉพาะเมื่อต้องเทียบกับงานที่จดไว้
            is_poly = poly_lyr is not None and lyr.id() == poly_lyr.id()
            # ★ rc2 (audit A4-04) — การแก้ค่า (ตาราง attribute / Identify ของ QGIS): ชื่อหมุด · SCORE · Type · คีย์ ของแปลง/หมุดล็อก
            #   เดิมด่านดูแค่ย้าย/ลบ ⇒ แก้ BND_NAME ของหมุด L1 / ใส่ SCORE ให้แปลง L1 แล้วบันทึกได้โดยไม่ถาม
            #   ขณะที่ ✏️ แก้ชื่อหมุดและ Score ของปลั๊กอินปฏิเสธ L1 (กติกาล็อกสองมาตรฐาน)
            try:
                _wa = self._l1_attr_watch(lyr.fields(), is_poly)
                a = self._l1_buf_attrs(lyr) if _wa else {}
            except Exception:
                _wa, a = {}, {}
            if ok:
                # ★ 2.4.0 (review DI-11) — ใช้เฉพาะรายการที่คำสั่งของ op ยังมีผลบน undo stack (ย้อน op แล้ว = ถามตามปกติ)
                _live = {ux: self._ux_live(lyr, ux)
                         for ux in ({u for _l in ok['g'].values() for _w, u in _l} | set(ok['d'].values())
                                    | {u for _l in ok.get('a', {}).values() for _x, u in _l})}
                okg = {fid: {w for w, ux in _l if _live[ux]} for fid, _l in ok['g'].items()}   # ★ rc1 S5 ลิสต์ต่อฟีเจอร์
                g = {fid: w for fid, w in g.items() if w not in okg.get(fid, ())}
                d = d - {fid for fid, ux in ok['d'].items() if _live[ux]}
                # ★ rc2 S_close (review R3-03) — เทียบเฉพาะคอลัมน์ที่ด่านดู (_wa) · เดิมเทียบทูเพิลทุกคอลัมน์ที่แก้ ⇒ แก้ REMARK/NAME
                #   ของแปลงเดียวกันภายหลัง ทำให้ SCORE ที่ผู้ดูแลแก้ตอนปลดล็อก (งานของปลั๊กอินที่จดไว้) ถูกถามตอนบันทึก
                def _pj(x):
                    return tuple((i, v) for i, v in x if i in _wa)
                oka = {fid: {_pj(x) for x, ux in _l if _live[ux]} for fid, _l in ok.get('a', {}).items()}
                a = {fid: x for fid, x in a.items() if _pj(x) not in oka.get(fid, ())}
            a = {fid: [(i, v) for i, v in x if i in _wa] for fid, x in a.items() if fid not in d}
            a = {fid: x for fid, x in a.items() if x}
            if not g and not d and not a:
                continue
            dp = lyr.dataProvider()
            pf = dp.fields()
            ti, ui = self._field_index(pf, 'type'), self._field_index(pf, _UTM_FIELD_NAMES)
            ni = -1 if is_poly else _fld_idx(pf, "BND_NAME")
            if is_poly and ti < 0:
                continue                                    # ชั้นแปลงไม่มีคอลัมน์ Type = ไม่มีแปลง L1
            if not is_poly and lm is None:
                lm = self._l1_saved_lock_map(poly_lyr)
            _pa = {i: pf.indexOf(nm) for i, nm in _wa.items()}           # index ของชั้น → index ของ provider (ตามชื่อ)
            _sub = {i for i in (ti, ui, ni) if i >= 0} | {j for j in _pa.values() if j >= 0}
            req = (QgsFeatureRequest().setFilterFids(sorted(set(g) | d | set(a)))
                   .setFlags(QgsFeatureRequest.NoGeometry)
                   .setSubsetOfAttributes(sorted(_sub)))
            it = dp.getFeatures(req)
            try:
                for f in it:
                    tp = f.attribute(ti) if ti >= 0 else None
                    u = _txt(f.attribute(ui)) if ui >= 0 else ""
                    if is_poly:
                        if not is_l1_type(tp):
                            continue
                        lab = f"UTM {u}" if u else f"gid {f.id()}"
                    else:
                        if not marker_lock_type(tp, _norm_utm(u), lm):
                            continue
                        nm = _txt(f.attribute(ni)) if ni >= 0 else ""
                        lab = f"หมุด {nm}" if nm else (f"หมุด UTM {u}" if u else f"หมุด gid {f.id()}")
                    if f.id() in d:
                        out['pd' if is_poly else 'md'].append(lab)
                        continue
                    if f.id() in g:
                        out['pg' if is_poly else 'mg'].append(lab)
                    # ค่าที่แก้แล้วเท่าค่าในฐาน (แก้แล้วแก้กลับ) ไม่นับ
                    _ch = [_wa[i] for i, v in a.get(f.id(), ()) if _pa.get(i, -1) >= 0 and _txt(f.attribute(_pa[i])) != v]
                    if _ch:
                        out['pa' if is_poly else 'ma'].append(f"{lab} ({', '.join(_ch)})")
            finally:
                it.close()
        return out

    def _l1_hits_text(self, hits, native=None, pair=None):
        """(หัวข้อ, ข้อความ) ของคำถามก่อนบันทึก — ใช้ทั้งปุ่ม 💾 และปุ่มบันทึกของ QGIS · จำนวน + ตัวอย่าง 3 รายการ (รายชื่อเต็มลง Log)
        ★ 2.4.0 (review DI-11) — native = ชื่อชั้นที่ QGIS กำลังบันทึก (ทางปุ่มของ QGIS): No ระงับได้แค่ชั้นนี้ — Save All Edits บันทึก
          ทีละชั้นตามลำดับในสารบัญ ชั้นที่ลงฐานไปก่อนแล้วย้อนไม่ได้ (เดิมบอก "ยังไม่บันทึกอะไร" ทั้งสองทาง)
          · วิธีย้อน: งานจากเครื่องมือของ QGIS ใช้ Edit ▸ Undo / แผง Undo/Redo ของ QGIS (↺ ของปลั๊กอินย้อนได้แค่งานของปลั๊กอิน)
          · เดิมอ้าง "Edit ▸ Undo History" ซึ่งไม่มีใน QGIS 3.40 (ประวัติอยู่ที่ View ▸ Panels ▸ Undo/Redo)"""
        rows = (('pg', "แปลง L1 ถูกย้าย/แก้รูป", "แปลง"), ('pd', "แปลง L1 ถูกลบ", "แปลง"),
                ('mg', "หมุดล็อก (หมุด L1 / หมุดของแปลง L1) ถูกย้าย", "หมุด"), ('md', "หมุดล็อกถูกลบ", "หมุด"),
                ('pa', "แปลง L1 ถูกแก้ค่า", "แปลง"), ('ma', "หมุดล็อกถูกแก้ชื่อ/ค่า", "หมุด"))     # ★ rc2 (audit A4-04)
        lines, full = [], []
        for k, head, unit in rows:
            labs = sorted(hits.get(k) or [], key=_natkey)
            if not labs:
                continue
            ex = " · ".join(labs[:3]) + (f" · อีก {len(labs) - 3:,} {unit}" if len(labs) > 3 else "")
            lines.append(f"• {head} {len(labs):,} {unit} — {ex}")
            full.append(f"{head}: " + " · ".join(labs))
        try:
            QgsMessageLog.logMessage("ด่าน L1 ก่อนบันทึก — " + " | ".join(full), "MLEP", Qgis.Info)
        except Exception:
            pass
        body = ("งานที่กำลังจะบันทึกมีการแก้แปลง/หมุด L1 (L1-RTK / L1-TS = พิกัดอ้างอิงที่รังวัดแล้ว ถูกล็อกห้ามขยับ):\n"
                + "\n".join(lines) + "\n\n"
                "มักเกิดจากเครื่องมือของ QGIS เอง (Vertex Tool · Move Feature · Delete Selected · "
                "แก้แบบ topological ที่ลากมุมของแปลงข้างเคียงไปด้วย · แก้ค่าในตาราง attribute / Identify) "
                "ซึ่งไม่ผ่านด่านล็อกของปลั๊กอิน\n\n"
                + (f"• No (ค่าตั้งต้น) = ชั้น '{native}' และชั้นคู่ '{pair}' ยังไม่ถูกบันทึก งานที่แก้ไว้ยังอยู่ครบ "
                   "(ถ้ากด Save All Edits ชั้นอื่นที่ QGIS บันทึกไปก่อนหน้านี้ในรอบเดียวกันลงฐานแล้ว)"
                   if native and pair else
                   f"• No (ค่าตั้งต้น) = ชั้น '{native}' ยังไม่ถูกบันทึก งานที่แก้ไว้ยังอยู่ครบ "
                   "(ถ้ากด Save All Edits ชั้นที่ QGIS บันทึกไปก่อนหน้านี้ในรอบเดียวกันลงฐานแล้ว)"
                   if native else "• No (ค่าตั้งต้น) = ยังไม่บันทึกอะไร งานที่แก้ไว้ยังอยู่ครบ")
                + " — ย้อนส่วนที่ไม่ได้ตั้งใจด้วย Edit ▸ Undo ของ QGIS หรือแผง View ▸ Panels ▸ Undo/Redo "
                "(ถ้าแก้ด้วยเครื่องมือของปลั๊กอิน ใช้ ↺ Undo ของปลั๊กอินได้) แล้วบันทึกใหม่\n"
                "• Yes = บันทึกทั้งหมดรวมการแก้ L1 ข้างต้น (เลือกเมื่อตั้งใจแก้จริงเท่านั้น)\n\n"
                "บันทึกต่อหรือไม่?")
        return "พบการแก้ไขแปลง/หมุด L1 ที่ถูกล็อก", body

    def _set_allow_commit(self, lyr, allow):
        """QgsVectorLayer::setAllowCommit ของ C++ (ดู _allow_commit_api) -> True = ค่าในชั้นเป็นตามสั่งแล้ว (อ่านกลับยืนยัน)"""
        fn = getattr(lyr, "setAllowCommit", None)          # PyQGIS รุ่นหน้าอาจ export ให้เอง
        if fn is not None:
            fn(bool(allow))
            return True
        api = _allow_commit_api()
        if api is None:
            return False
        from qgis.PyQt import sip as _sip
        ptr = _sip.unwrapinstance(lyr)
        api[0](ptr, bool(allow))
        return bool(api[1](ptr)) == bool(allow)

    def _get_allow_commit(self, lyr):
        """★ 2.4.0 (review DI-11) — QgsVectorLayer::allowCommit() ของ C++ -> True/False · อ่านไม่ได้ = None"""
        try:
            fn = getattr(lyr, "allowCommit", None)
            if fn is not None:
                return bool(fn())
            api = _allow_commit_api()
            if api is None:
                return None
            from qgis.PyQt import sip as _sip
            return bool(api[1](_sip.unwrapinstance(lyr)))
        except Exception:
            return None

    def _l1_block(self, lyr):
        """ระงับ commit ที่กำลังจะเกิดของชั้นนี้ (setAllowCommit(False)) แล้วคืนให้บันทึกได้ทันทีที่กลับ event loop
        (QGIS เช็คค่านี้ครั้งเดียวหลังยิง beforeCommitChanges ⇒ การบันทึกครั้งถัดไปต้องผ่านได้ตามปกติ) -> True = commit นี้ไม่เกิด
        ★ 2.4.0 (review DI-11) — allowCommit มีเจ้าของอื่น (QgsGeometryValidationService ของ QGIS ตั้ง False ตอนมีข้อผิดพลาดของรูป/
          รอตรวจ topology) ⇒ อ่านก่อน: False อยู่แล้ว = commit นี้ไม่เกิดอยู่แล้ว ไม่แตะและไม่คืน (เดิมคืน True ทับ = ปลดด่านของ QGIS)
          ⇒ ชั้นที่ระงับเองมีค่าเดิม True เสมอ _l1_release จึงคืน True = คืนค่าเดิม"""
        try:
            if self._get_allow_commit(lyr) is False:
                return True
            if not self._set_allow_commit(lyr, False):
                return False
        except Exception:
            return False
        self._l1_blocked.append(lyr.id())
        if len(self._l1_blocked) == 1:
            # ★ rc2 (audit A5-05 · ผู้ตรวจทานพบเพิ่ม) — lambda ถือตัวปลั๊กอินแบบ strong ref: PyQt ถือ bound method ใน singleShot
            #   แบบ weak ref ⇒ instance ถูกเก็บขยะก่อนกลับ event loop (โหลดปลั๊กอินใหม่) = ไม่คืน allowCommit ชั้นนั้นค้าง False ทั้งเซสชัน
            QtCore.QTimer.singleShot(0, lambda _s=self: _s._l1_release())
        return True

    def _l1_pass_round(self, ids):
        """★ rc1 (F3) — จำชั้นของคู่ที่ตอบ "บันทึก" แล้วในรอบบันทึกนี้ (Save All Edits บันทึกทีละชั้นต่อกันโดยไม่กลับ event loop)
        ล้างเมื่อกลับ event loop ⇒ การบันทึกครั้งถัดไปถามตามปกติ
        ★ rc1 S5 (review R3-02) — รวมชุด (เดิมแทนที่) + ตั้งตัวจับเวลาครั้งเดียว · กล่องคำถามของด่าน L1 เป็น modal (event loop ซ้อน)
          ⇒ ตัวจับเวลาทำงานระหว่างกล่องของคู่ถัดไปเปิดอยู่ได้ — ระหว่างนั้นไม่ล้าง (_l1_pass_clear เลื่อนไปหลังกล่องปิด)
          เดิมคำตอบของคู่แรกหายกลางรอบ Save All ของโปรเจกต์หลายสาขา ⇒ ถามซ้ำ และตอบสลับกันได้คู่ครึ่งเดียว"""
        self._l1_pass = set(getattr(self, "_l1_pass", None) or ()) | set(ids)
        if not self._l1_round_arm():
            self._l1_pass = set()

    def _l1_round_arm(self):
        """★ rc2 (audit A4-02 · A4-03) — ตั้งตัวจับเวลาล้าง "สถานะของรอบบันทึก" (ครั้งเดียวต่อรอบ) ใช้ร่วมกันทั้ง _l1_pass
        และ _l1_round · คืน False = ตั้งไม่ได้ (ผู้เรียกไม่จำอะไรข้ามรอบ)
        ตัวจับเวลาถือตัวปลั๊กอินแบบ strong ref (lambda) — PyQt ถือ bound method ใน QTimer.singleShot แบบ weak ref"""
        if getattr(self, "_l1_pass_armed", False):
            return True
        try:
            QtCore.QTimer.singleShot(0, lambda _s=self: _s._l1_pass_clear())
            self._l1_pass_armed = True
            return True
        except Exception:
            return False

    def _l1_round(self):
        """★ rc2 (audit A4-02 · A4-03) — สถานะของ "รอบบันทึก" (Save All Edits ของ QGIS บันทึกทีละชั้นต่อกันโดยไม่กลับ event loop)
        วงจรเดียวกับ _l1_pass / _l1_hold: ล้างใน _l1_pass_clear / _l1_release เมื่อกลับ event loop (เลื่อนเมื่อกล่องด่าน L1 เปิดอยู่)
        {'begun': id ชั้นที่ beforeCommitChanges ยิงแล้ว · 'done': id ชั้นที่ลงฐานสำเร็จ (afterCommitChanges)
         · 'checked': คู่ (id ชั้นแปลง, id ชั้นหมุด) ที่ด่านจับคู่ตรวจแล้วในรอบนี้}"""
        st = getattr(self, "_l1_rnd", None)
        if st is None:
            st = self._l1_rnd = {'begun': set(), 'done': set(), 'checked': set()}
        self._l1_round_arm()
        return st

    def _l1_round_gate(self, lid):
        """★ rc2 (audit A4-03) — Save All Edits ของ QGIS ไม่หยุดเมื่อชั้นหนึ่งบันทึกไม่สำเร็จ (สิทธิ์ไม่พอ / trigger ปฏิเสธ /
        การเชื่อมต่อหลุด / QGIS ระงับเพราะรูปผิด) แล้วบันทึกชั้นคู่ต่อในรอบเดียวกัน ⇒ แปลงกับหมุดลงฐานครึ่งคู่ (ป้าย DI-05 เตือนได้
        แค่หลังเกิด และถ้าล้มเพราะสิทธิ์ ปุ่มบันทึกอีกชั้นก็ล้มซ้ำ) ⇒ จดชั้นที่เริ่มบันทึกในรอบนี้ (_l1_round) · ชั้นคู่ "เริ่มแล้วแต่
        ไม่สำเร็จ" ⇒ ระงับชั้นนี้ด้วย (_l1_block) · คืน True = ระงับ commit นี้แล้ว
        ไม่ทำ: ปุ่ม 💾 ของปลั๊กอิน (หยุดเองเมื่อชั้นแรกล้ม) · ชั้นที่อยู่ใน _l1_hold (ผู้ใช้ตอบ "ยังไม่บันทึก" — ด่าน L1 ระงับพร้อม
        ข้อความของมันเอง) · โปรเจกต์ที่เปิด transaction groups (QGIS บันทึกทั้งกลุ่มพร้อมกันเอง) · ชั้นคู่ลงฐานไปก่อนแล้ว"""
        st = self._l1_round()
        st['begun'].add(lid)
        if getattr(self, "_l1_save_ack", False) or lid in (getattr(self, "_l1_hold", None) or ()):
            return False
        try:
            if QgsProject.instance().transactionMode() != Qgis.TransactionMode.Disabled:
                return False
        except Exception:
            pass
        try:
            me = QgsProject.instance().mapLayer(lid)
            pr = self._l1_pair_of(me)
        except Exception:
            return False
        if pr is None:
            return False
        other = next((l for l in pr if l is not None and l.id() != lid), None)
        if other is None or other.id() not in st['begun'] or other.id() in st['done']:
            return False
        if not self._l1_block(me):
            return False                        # ระงับไม่ได้ (ไม่มี allowCommit บนเครื่องนี้) ⇒ ป้าย DI-05 เตือนหลังบันทึกตามเดิม
        _msg = (f"ชั้น '{me.name()}' ยังไม่ถูกบันทึก — ชั้นคู่ '{other.name()}' บันทึกไม่สำเร็จในรอบเดียวกัน "
                "(กันแปลงกับหมุดลงฐานไม่พร้อมกัน) · งานที่แก้ไว้ยังอยู่ครบทั้งสองชั้น — "
                f"ดูสาเหตุที่ชั้น '{other.name()}' บันทึกไม่ได้ แล้วบันทึกใหม่")
        try:
            QgsMessageLog.logMessage("บันทึกคู่ชั้น: " + _msg, "MLEP", Qgis.Warning)
        except Exception:
            pass
        try:
            self.iface.messageBar().pushMessage("ยังไม่ได้บันทึก", _msg, level=1, duration=20)
        except Exception:
            pass
        return True

    def _l1_pass_clear(self):
        self._l1_pass_armed = False
        if getattr(self, "_l1_prompting", 0) > 0:
            self._l1_after_prompt = True        # ★ rc1 S5 (R3-02) กล่องด่าน L1 เปิดอยู่ = ยังอยู่ในรอบบันทึกเดิม ⇒ ล้างหลังกล่องปิด
            return
        self._l1_pass = set()
        self._l1_rnd = None                     # ★ rc2 (audit A4-02 · A4-03) สถานะของรอบเดียวกัน

    def _l1_release(self):
        """คืนสิทธิ์ commit ให้ชั้นที่ _l1_block ระงับไว้ + ลืมคำตอบ "ยังไม่บันทึก" ของรอบนี้
        (หาชั้นใหม่จากโปรเจกต์ด้วย id — ชั้นที่ถูกถอดออกไปแล้วไม่แตะ ไม่เรียก C++ บนวัตถุที่อาจถูกลบ)
        ★ rc1 S5 (review R3-02) — กล่องคำถามของด่าน L1 เปิดอยู่ (ตัวจับเวลาทำงานใน event loop ซ้อนของกล่อง) ⇒ ยังไม่ลืม
          (เลื่อนไปหลังกล่องปิด) · ชั้นที่ระงับไว้ QGIS ตัดสินไปแล้ว คืนสิทธิ์ช้าลงไม่มีผลกับ commit ที่ผ่านไป"""
        if getattr(self, "_l1_prompting", 0) > 0:
            self._l1_after_prompt = True
            return
        blocked, self._l1_blocked = list(getattr(self, "_l1_blocked", None) or ()), []   # ★ rc2 (A5-05) ทนกับ instance ที่ยังไม่ครบ
        self._l1_hold = set()
        self._l1_pass = set()
        self._l1_rnd = None                     # ★ rc2 (audit A4-02 · A4-03)
        for lid in blocked:
            try:
                lyr = QgsProject.instance().mapLayer(lid)
                if lyr is not None:
                    self._set_allow_commit(lyr, True)
            except Exception:
                pass

    def _l1_pair_of(self, lyr):
        """คู่ (ชั้นแปลง, ชั้นหมุด) ที่ lyr เป็นสมาชิก สำหรับด่าน L1 ตอนบันทึก · ไม่ใช่ชั้นทำงาน = None
        ① คู่ในคอมโบ (แผงเปิดแล้ว) ② ชื่อ <สาขา>_POLYGON / <สาขา>_POINT (ชนิดรูปตรง) + อีกข้างของสาขาเดียวกัน
        (ช่องในคอมโบถ้าเป็นสาขานั้น ไม่งั้นชั้นแรกตามชื่อ) ③ ชั้นที่เปิดจากตารางเดียวกับชั้นใน ①/② (_layer_source_key
        — ชั้นซ้ำ / Duplicate Layer ที่ชื่อไม่ตรงรูปแบบ) ได้คู่ของชั้นนั้น · อีกข้างหาไม่เจอ = None ในช่องนั้น
        (ชั้นหมุดที่ไม่มีชั้นแปลง ⇒ _l1_commit_hits ตัดสินหมุดจาก Type ของหมุดเอง)"""
        if lyr is None:
            return None
        combo = self._combo_pair()
        lid = lyr.id()
        if lid in {l.id() for l in combo if l is not None}:
            return combo
        r = self._geom_role(lyr)
        if r is None:
            return None
        sfx = ("_POLYGON", "_POINT")
        lyrs = list(QgsProject.instance().mapLayers().values())
        b = self._branch_of(lyr.name(), sfx[r])
        if b is None:
            key = self._layer_source_key(lyr)
            if key is None:
                return None
            if combo[r] is not None and self._layer_source_key(combo[r]) == key:
                return (lyr, combo[1]) if r == 0 else (combo[0], lyr)
            b = next((self._branch_of(l.name(), sfx[r]) for l in lyrs
                      if l.id() != lid and self._geom_role(l) == r and self._branch_of(l.name(), sfx[r]) is not None
                      and self._layer_source_key(l) == key), None)
            if b is None:
                # ★ rc2 (audit A5-04) — ④ ชื่อในสารบัญไม่ตรงรูปแบบ (ผู้ใช้ตั้งชื่อเอง เช่น 'แปลง องครักษ์') และไม่มีชั้นอื่นของตารางเดียวกัน
                #   ⇒ ใช้ชื่อตารางของ provider (<สาขา>_POLYGON / <สาขา>_POINT) · เดิมได้ None ⇒ ด่าน L1 ของปุ่มบันทึก QGIS
                #   ไม่ถูกติดให้ชั้นนั้นจนกว่าจะเปิดแผงแล้วเลือกคอมโบ
                b = self._branch_of(self._layer_table_name(lyr), sfx[r])
            if b is None:
                return None
        other = combo[1 - r]
        if other is None or self._layer_branch(other, sfx[1 - r]) != b:
            # ชื่อในสารบัญตรงรูปแบบก่อน (พฤติกรรมเดิม) แล้วค่อยชื่อตาราง (★ rc2 A5-04)
            other = next((l for l in lyrs
                          if self._geom_role(l) == 1 - r and self._branch_of(l.name(), sfx[1 - r]) == b), None)
            if other is None:
                other = next((l for l in lyrs
                              if self._geom_role(l) == 1 - r and self._branch_of(self._layer_table_name(l), sfx[1 - r]) == b),
                             None)
        return (lyr, other) if r == 0 else (other, lyr)

    def _l1_arm_soon(self, *_a):
        """เฝ้าชั้นทำงานทุกชั้นที่รอบ event ถัดไป (รวบหลายสัญญาณ layersAdded ระหว่างโหลดโปรเจกต์เป็นครั้งเดียว)"""
        if not getattr(self, "_alive", True) or getattr(self, "_l1_arm_pending", False):
            return
        self._l1_arm_pending = True
        try:
            QtCore.QTimer.singleShot(0, self._l1_arm_all)
        except Exception:
            self._l1_arm_pending = False

    def _l1_arm_all(self):
        """ต่อ hook commit/rollback (_watch_layer_editing — ครั้งเดียวต่อวัตถุชั้น) ให้ทุกชั้นที่ _l1_pair_of หาคู่ได้
        ⇒ ด่าน L1 ของปุ่มบันทึก QGIS ทำงานตั้งแต่เปิดโปรเจกต์ ไม่ต้องรอเปิดแผง · ไม่เพิ่ม/ลบเลเยอร์ (ทำระหว่างโหลดโปรเจกต์ได้)
        + เตือน Buffered transaction groups ซึ่งข้าม hook นี้ (_check_transaction_mode)"""
        self._l1_arm_pending = False
        if not getattr(self, "_alive", True):
            return
        try:
            lyrs = list(QgsProject.instance().mapLayers().values())
        except Exception:
            return
        for _l in lyrs:
            try:
                if self._geom_role(_l) is not None and self._l1_pair_of(_l) is not None:
                    self._watch_layer_editing(_l)
            except Exception:
                pass
        try:
            self._check_transaction_mode(l1_only=True)
        except Exception:
            pass

    def _l1_native_gate(self, lid):
        """ด่าน L1 ของการบันทึกด้วยปุ่มของ QGIS (Save Layer Edits · ปิดโหมดแก้ไข · Save All Edits) — เรียกจาก on_before_commit_check
        คืน True = ผู้ใช้ตอบ "ยังไม่บันทึก" และระงับ commit นี้แล้ว (งานยังอยู่ใน buffer พร้อมประวัติ Undo ครบ)
        ไม่ถาม: ปุ่ม 💾 ของปลั๊กอินกำลังบันทึก (ถามไปแล้ว) · ปลดล็อก L1 อยู่ · ไม่ใช่ชั้นทำงาน · ไม่มีการแก้ L1
        ★ 2.4.0 (review DI-11) — ชั้นทำงาน = ทุกชั้นที่ _l1_pair_of หาคู่ได้ (ไม่ต้องเปิดแผง · ทุกสาขา · ชั้นซ้ำของตารางเดียวกัน)
          ไม่ใช่แค่คู่ในคอมโบ · allowCommit เป็น False อยู่แล้ว (เจ้าของอื่นระงับ) = ไม่ถาม
        ⚠️ กล่องคำถามเปิด "ก่อน" QGIS เริ่มเขียน (beforeCommitChanges ยิงก่อนแตะ buffer) — จุดเดียวที่ยังหยุดการบันทึกของ QGIS ได้"""
        if self._l1_save_ack or self._l1_unlocked():
            return False
        try:
            me = QgsProject.instance().mapLayer(lid)
            pr = self._l1_pair_of(me)
        except Exception:
            return False
        if pr is None:
            return False
        poly, point = pr
        # ★ rc1 S5 (review R3-02) — ดู "ยังไม่บันทึก" ก่อน "บันทึก" (ชั้นที่อยู่ในสองคู่ — ชั้นซ้ำของตารางเดียวกัน — ตอบไม่บันทึกชนะ)
        if lid in self._l1_hold:
            # อีกชั้นของคู่เพิ่งตอบ "ยังไม่บันทึก" ในรอบเดียวกัน (Save All Edits) ⇒ ระงับด้วย ไม่ถามซ้ำ (กันบันทึกครึ่งคู่)
            if not self._l1_block(me):
                return False
            try:
                # ★ 2.4.0 (review DI-11) — เดิมไม่บอก (แถบข้อความบอกแค่ชั้นแรก)
                self.iface.messageBar().pushMessage(
                    "ยังไม่ได้บันทึก",
                    f"ชั้น '{me.name()}' ยังไม่ถูกบันทึกด้วย — เป็นคู่ของชั้นที่เพิ่งตอบไม่บันทึก "
                    "(กันแปลงกับหมุดลงฐานไม่พร้อมกัน) · งานที่แก้ไว้ยังอยู่ครบ",
                    level=1, duration=15)
            except Exception:
                pass
            return True
        if lid in getattr(self, "_l1_pass", ()):
            # ★ rc1 (F3) — อีกชั้นของคู่เพิ่งตอบ "บันทึก" ในรอบเดียวกัน (Save All Edits) โดยเห็นงานของทั้งคู่แล้ว ⇒ ไม่ถามซ้ำ
            return False
        if self._get_allow_commit(me) is False:
            # ★ 2.4.0 (review DI-11) — commit นี้ไม่เกิดอยู่แล้ว (เช่น geometry validation ของ QGIS ระงับไว้) ⇒ ไม่ถาม
            #   (ตอบ Yes ก็บันทึกไม่ได้) · บันทึกครั้งที่ผ่านได้จริงจะถามเอง
            return False
        # ★ rc1 (F3 · review B1-03) — ตรวจงานของ "ทั้งคู่" ตั้งแต่ชั้นแรกของคู่ที่ QGIS บันทึก
        #   เดิมตรวจแค่ชั้นที่กำลังบันทึก ⇒ Save All Edits บันทึกตามลำดับในสารบัญ (ไฟล์ V3 ทั้ง 5 สาขาวาง _POINT เหนือ _POLYGON):
        #   ชั้นหมุดไม่มีงาน L1 = ลงฐานเงียบ แล้วชั้นแปลงถาม → No (ค่าตั้งต้น) ⇒ หมุดลงฐานแต่แปลงไม่ลง = คู่ครึ่งเดียว (ทำซ้ำแล้ว)
        #   ⇒ ถามตั้งแต่ชั้นแรก · No = ระงับชั้นนี้ + ชั้นคู่ (_l1_hold) · Yes = ชั้นคู่ไม่ถามซ้ำในรอบเดียวกัน (_l1_pass)
        other = next((l for l in (poly, point) if l is not None and l.id() != lid), None)
        try:
            hits = self._l1_commit_hits([me] + ([other] if other is not None else []), poly)
        except Exception:
            _log_exc("ด่าน L1 ก่อนบันทึก (ปุ่มของ QGIS) ตรวจไม่ได้")
            self._pending_l1_gap = (lid, "ตรวจไม่ได้ (เกิดข้อผิดพลาด — รายละเอียดใน Log Messages แท็บ MLEP)")   # ★ rc2 (A4-07)
            return False
        if getattr(self, "_l1_gap", None):
            self._pending_l1_gap = (lid, self._l1_gap)      # ★ rc2 (audit A4-07) บอกหลังบันทึก (ไม่ขวาง · แบบด่านจับคู่ ER-01)
        if not any(hits.values()):
            return False
        _pair_nm = other.name() if (other is not None and other.isEditable() and other.isModified()) else None
        title, body = self._l1_hits_text(hits, native=me.name(), pair=_pair_nm)
        if getattr(me, "setAllowCommit", None) is None and _allow_commit_api() is None:
            # เครื่องนี้ระงับการบันทึกของ QGIS ไม่ได้ ⇒ เตือนอย่างเดียว (ไม่ถามคำถามที่ตอบ "ไม่" แล้วหยุดไม่ได้)
            try:
                self.iface.messageBar().pushMessage(
                    "⚠️ " + title,
                    f"ชั้น '{me.name()}' กำลังบันทึกการแก้แปลง/หมุด L1 — ปุ่มบันทึกของ QGIS บนเครื่องนี้หยุดให้ไม่ได้ · "
                    "ถ้าไม่ได้ตั้งใจ ให้แจ้งผู้ดูแล (รายชื่ออยู่ใน Log Messages แท็บ MLEP) · บันทึกด้วย 💾 ของปลั๊กอินจะถามก่อนเสมอ",
                    level=2, duration=0)
            except Exception:
                pass
            return False
        # ★ 2.4.0 (review DI-11) — Toggle Editing ▸ Save / ปิดโปรเจกต์ / ปิด QGIS เรียก commit ใต้ cursor นาฬิกาทราย (QGIS ตั้งเอง)
        #   ⇒ คำถามขึ้นใต้นาฬิกาทราย = ดูเหมือนโปรแกรมค้าง (กติกาเดียวกับ _Busy) ⇒ ลูกศรปกติระหว่างถาม แล้วคืนของเดิม
        _cur = False
        try:
            QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.ArrowCursor)
            _cur = True
        except Exception:
            pass
        # ★ rc1 S5 (review R3-02) — นับกล่องด่าน L1 ที่เปิดอยู่ ⇒ ตัวจับเวลาล้างคำตอบของรอบ (_l1_pass_clear / _l1_release)
        #   ที่ทำงานใน event loop ซ้อนของกล่องไม่ลืมคำตอบกลางรอบ · กล่องปิดแล้วค่อยตั้งตัวจับเวลาใหม่ (ครั้งเดียว)
        self._l1_prompting = getattr(self, "_l1_prompting", 0) + 1
        try:
            ans = self._ask(QtWidgets.QMessageBox.Question, title, body,
                            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        finally:
            self._l1_prompting = max(0, getattr(self, "_l1_prompting", 1) - 1)
            if self._l1_prompting == 0 and getattr(self, "_l1_after_prompt", False):
                self._l1_after_prompt = False
                try:
                    QtCore.QTimer.singleShot(0, lambda _s=self: _s._l1_release())   # ★ rc2 (A5-05) strong ref
                except Exception:
                    pass
            if _cur:
                try:
                    QtWidgets.QApplication.restoreOverrideCursor()
                except Exception:
                    pass
        if ans == QtWidgets.QMessageBox.Yes:
            self._l1_pass_round({l.id() for l in (poly, point, me) if l is not None})
            return False
        if not self._l1_block(me):
            # ★ 2.4.0 (review DI-11) — ผู้ใช้ตอบไม่บันทึก แต่ระงับไม่สำเร็จ (อ่านค่ากลับไม่ตรง/เรียก C++ ล้ม) ⇒ QGIS บันทึกต่อ
            #   เดิมเงียบ ⇒ แถบแดงค้าง + Log ระดับ Warning (รายชื่อเต็มลง Log แล้วใน _l1_hits_text)
            try:
                QgsMessageLog.logMessage(
                    f"ด่าน L1: ผู้ใช้ตอบไม่บันทึก แต่ระงับการบันทึกของชั้น '{me.name()}' ไม่สำเร็จ — "
                    "การแก้แปลง/หมุด L1 ข้างบนถูกบันทึกลงฐาน", "MLEP", Qgis.Warning)
            except Exception:
                pass
            try:
                self.iface.messageBar().pushMessage(
                    "⚠️ หยุดการบันทึกไม่สำเร็จ",
                    f"ชั้น '{me.name()}' ถูกบันทึกต่อ รวมการแก้แปลง/หมุด L1 ที่ถามไป — ปลั๊กอินหยุดการบันทึกของ QGIS ไม่ได้ · "
                    "รายชื่ออยู่ใน Log Messages แท็บ MLEP · ถ้าไม่ได้ตั้งใจ ให้แจ้งผู้ดูแลฐานข้อมูล",
                    level=2, duration=0)
            except Exception:
                pass
            return False
        self._l1_hold = set(self._l1_hold or ()) | {l.id() for l in (poly, point, me) if l is not None}   # ★ rc1 S5 (R3-02) รวมชุด
        try:
            self.iface.messageBar().pushMessage(
                "ยังไม่ได้บันทึก",
                f"ชั้น '{me.name()}' ยังไม่ถูกบันทึก — งานที่แก้ไว้ยังอยู่ครบ · ย้อนการแก้แปลง/หมุด L1 ที่ไม่ได้ตั้งใจ "
                "(Edit ▸ Undo ของ QGIS หรือแผง View ▸ Panels ▸ Undo/Redo) แล้วบันทึกใหม่",
                level=1, duration=15)
        except Exception:
            pass
        return True
