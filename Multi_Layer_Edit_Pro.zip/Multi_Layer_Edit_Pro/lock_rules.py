# -*- coding: utf-8 -*-
"""★ 2.4.0 (review DU-01) — กติกาล็อก L1 "ที่เดียว" ของ Multi-Layer Edit Pro

ฟังก์ชันล้วน (ไม่มี Qt widget · ไม่ import main) ⇒ ทั้ง main.py และ map_tools.py import ได้ตอนโหลดโมดูลโดยไม่วนกัน
เดิมทูเพิล ("L1-RTK", "L1-TS") ถูกพิมพ์มือราว 20 จุด และหมุดถูกตัดสินด้วยสองกติกาที่ไม่ตรงกัน:
  · ฝั่ง UTM (Move/Score/Move Node/Align) — ล็อกเมื่อ UTM ของหมุดตรงกับแปลง L1
  · ฝั่ง Type (แก้ชื่อ/ลบ/สลับหมุด · ไฮไลต์หมุดซ้อน) — ล็อกเมื่อ Type ของตัวหมุดเองเป็น L1
  ⇒ หมุด Type L1 ที่ UTM ว่าง/ไม่ตรงแปลง L1 ใด ยังถูกย้ายและใส่ Score ได้
⇒ ตอนนี้ "หมุดล็อก" = Type ของหมุดเองเป็น L1 **หรือ** คีย์ UTM อยู่ในตารางแปลง L1 (union · ไม่ผ่อนจุดใดเลย)
   ทางข้ามมีทางเดียวคือผู้ดูแลกดปลดล็อก L1 — ตัดสินใน MultiLayerEditPro._marker_locked (ไม่ใช่ที่นี่)
⚠️ CT-RTK ไม่ล็อก (ชั้นจุดสำรวจภาคสนามแยกต่างหาก) — ทูเพิลที่ตั้งใจรวม CT-RTK (คำเตือนเปลี่ยนชนิด ฯลฯ) ไม่ได้ใช้ค่าคงที่นี้
"""

# ชนิดที่ "ล็อก" (ชั้นอ้างอิง ห้ามขยับ/แก้) · L1-RTK มาก่อน = เข้มกว่า (ใช้ตัดสินเมื่อสองทางให้ชนิดต่างกัน)
L1_TYPES = ("L1-RTK", "L1-TS")


def norm_type(v):
    """ค่า Type -> ตัวพิมพ์ใหญ่ที่ trim แล้ว · None / NULL จาก provider (QVariant ที่ str() ได้ 'NULL') / สตริง 'NULL' / ว่าง = ''
    (กติกาเดียวกับ main._txt + upper — ห้ามใช้ `"" if v is None else str(v)` เพราะ NULL ของ provider ไม่ใช่ None)"""
    if v is None:
        return ""
    try:
        s = str(v).strip().upper()
    except Exception:
        return ""
    return "" if s == "NULL" else s


def is_l1_type(v):
    """ค่า Type เป็นชนิดล็อก (L1-RTK / L1-TS) ไหม · NULL-safe"""
    return norm_type(v) in L1_TYPES


def marker_lock_type(own_type, utm_key, locked_map):
    """ชนิด L1 ที่ทำให้หมุดถูกล็อก หรือ None = ไม่ล็อก (ยังไม่ดูการปลดล็อกของผู้ดูแล — ผู้เรียกตัดสินเอง)

    own_type   = ค่า Type ของตัวหมุดเอง (ดิบจาก provider ได้ · NULL = ไม่มี)
    utm_key    = คีย์ UTM ของหมุดที่ normalise แล้ว (main._norm_utm · UTM ว่างได้ค่าตัวแทนที่ไม่ตรงกับใคร) หรือ None
    locked_map = {คีย์ UTM: ชนิด} ของแปลง L1 ทั้งชั้น (main._locked_utm_map — คิวรีเดียวต่อ operation) หรือ {} / None
    ล็อกเมื่อ (Type ของหมุดเป็น L1) หรือ (คีย์ UTM อยู่ใน locked_map) · สองทางให้ชนิดต่างกัน ⇒ L1-RTK (เข้มกว่า)"""
    found = set()
    own = norm_type(own_type)
    if own in L1_TYPES:
        found.add(own)
    if locked_map and utm_key is not None:
        try:
            t = norm_type(locked_map.get(utm_key))
        except Exception:
            t = ""
        if t in L1_TYPES:
            found.add(t)
    for t in L1_TYPES:
        if t in found:
            return t
    return None
