import os
import re
import math
import requests
import zipfile
import io
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import (QgsProject, QgsPointXY, QgsGeometry,
                       QgsSnappingConfig, QgsTolerance, QgsLineString, QgsWkbTypes, QgsFeatureRequest)
from qgis.gui import QgsMapToolEmitPoint, QgsVertexMarker, QgsRubberBand
from qgis.utils import iface

class MultiLayerEditPro:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = [] 
        self.temp_tool = None
        self.last_layers = []
        self.mode = "" 
        self.version = "1.0.9"
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล
        
        self.rubber_band = None
        self.markers = []
        self.src_pts = []
        
    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", self.action)
        self.clear_markers()

    def run(self):
        if self.dlg is None: self.create_dialog()
        self.dlg.show()

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro v{self.version}")
        self.dlg.setMinimumWidth(480)
        layout = QtWidgets.QVBoxLayout(self.dlg)
        
        layout.addWidget(QtWidgets.QLabel("<b>1. ตั้งค่าชั้นข้อมูล</b>"))
        self.poly_cb = QtWidgets.QComboBox(); self.point_cb = QtWidgets.QComboBox()
        layout.addWidget(QtWidgets.QLabel("เลเยอร์แปลง (Polygon):")); layout.addWidget(self.poly_cb)
        layout.addWidget(QtWidgets.QLabel("เลเยอร์หมุด (Point):")); layout.addWidget(self.point_cb)
        btn_refresh = QtWidgets.QPushButton("Refresh Layers"); btn_refresh.clicked.connect(self.refresh_layers); layout.addWidget(btn_refresh)
        self.refresh_layers()
        layout.addSpacing(10)
        
        layout.addWidget(QtWidgets.QLabel("<b>2. เลือกกลุ่มข้อมูล</b>"))
        h_sel = QtWidgets.QHBoxLayout()
        btn_c = QtWidgets.QPushButton("By Cluster ID"); btn_c.clicked.connect(lambda: self.process_selection('cluster'))
        btn_u = QtWidgets.QPushButton("By UTM"); btn_u.clicked.connect(lambda: self.process_selection('utm'))
        h_sel.addWidget(btn_c); h_sel.addWidget(btn_u); layout.addLayout(h_sel)
        layout.addSpacing(10)

        layout.addWidget(QtWidgets.QLabel("<b>3. เครื่องมือปรับแต่งทั่วไป</b>"))
        grid_tools = QtWidgets.QGridLayout()
        btn_move = QtWidgets.QPushButton("Move"); btn_move.clicked.connect(lambda: self.start_interactive('move'))
        btn_rot = QtWidgets.QPushButton("Rotate"); btn_rot.clicked.connect(lambda: self.start_interactive('rotate'))
        btn_scale = QtWidgets.QPushButton("Scale"); btn_scale.clicked.connect(lambda: self.start_interactive('scale'))
        grid_tools.addWidget(btn_move, 0, 0); grid_tools.addWidget(btn_rot, 0, 1); grid_tools.addWidget(btn_scale, 0, 2)
        layout.addLayout(grid_tools); layout.addSpacing(10)

        h_row_45 = QtWidgets.QHBoxLayout()
        v_col4 = QtWidgets.QVBoxLayout(); v_col4.addWidget(QtWidgets.QLabel("<b>4. Transform (2 Pts)</b>"))
        btn_t = QtWidgets.QPushButton("Start Transform"); btn_t.setStyleSheet("background-color: #ffccbc; font-weight: bold; padding: 10px;")
        btn_t.clicked.connect(lambda: self.start_interactive('transform')); v_col4.addWidget(btn_t); h_row_45.addLayout(v_col4)
        v_col5 = QtWidgets.QVBoxLayout(); v_col5.addWidget(QtWidgets.QLabel("<b>5. Move Node (Sync)</b>"))
        btn_node = QtWidgets.QPushButton("Move Node"); btn_node.setStyleSheet("background-color: #e8f5e9; font-weight: bold; padding: 10px;")
        btn_node.clicked.connect(lambda: self.start_interactive('modify_node')); v_col5.addWidget(btn_node); h_row_45.addLayout(v_col5)
        layout.addLayout(h_row_45); layout.addSpacing(10)

        h_row_67 = QtWidgets.QHBoxLayout()
        v_col6 = QtWidgets.QVBoxLayout(); v_col6.addWidget(QtWidgets.QLabel("<b>6. จัดกลุ่ม Cluster</b>"))
        btn_group_id = QtWidgets.QPushButton("Sync Cluster ID"); btn_group_id.setStyleSheet("background-color: #e3f2fd; padding: 10px;")
        btn_group_id.clicked.connect(self.group_cluster_ids); v_col6.addWidget(btn_group_id); h_row_67.addLayout(v_col6)
        
        v_col7 = QtWidgets.QVBoxLayout()
        v_col7.addWidget(QtWidgets.QLabel("<b>7. ตั้งค่า Score</b>"))
        h_score_layout = QtWidgets.QHBoxLayout()
        # ปุ่ม Score 1 สีเขียว
        btn_score_1 = QtWidgets.QPushButton("Score = 1")
        btn_score_1.setStyleSheet("""
            QPushButton {
                background-color: #c8e6c9; 
                font-weight: bold; 
                color: #1b5e20;
                padding: 10px;
            }
            QPushButton:hover { background-color: #a5d6a7; }
        """)
        btn_score_1.clicked.connect(lambda: self.set_score_value(1))
        
        # ปุ่ม Score 0 สีแดง
        btn_score_0 = QtWidgets.QPushButton("Score = 0")
        btn_score_0.setStyleSheet("""
            QPushButton {
                background-color: #ffcdd2; 
                font-weight: bold; 
                color: #b71c1c;
                padding: 10px;
            }
            QPushButton:hover { background-color: #ef9a9a; }
        """)
        btn_score_0.clicked.connect(lambda: self.set_score_value(0))
        h_score_layout.addWidget(btn_score_1)
        h_score_layout.addWidget(btn_score_0)
        v_col7.addLayout(h_score_layout)
        h_row_67.addLayout(v_col7)
        layout.addLayout(h_row_67)
        
        
        layout.addSpacing(10)
        btn_align = QtWidgets.QPushButton("📏 Align Selected Points to Line"); btn_align.setStyleSheet("padding: 10px;")
        btn_align.clicked.connect(self.start_align_tool)
        layout.addWidget(btn_align)

        layout.addSpacing(10)
        h_ctrl = QtWidgets.QHBoxLayout()
        btn_rs = QtWidgets.QPushButton("✖ Reset / Cancel"); btn_rs.setStyleSheet("padding: 10px;"); btn_rs.clicked.connect(self.cancel_transform) 
        btn_un = QtWidgets.QPushButton("↺ Undo Last"); btn_un.setStyleSheet("padding: 10px;"); btn_un.clicked.connect(self.undo_transform) 
        h_ctrl.addWidget(btn_rs); h_ctrl.addWidget(btn_un); layout.addLayout(h_ctrl)
        
        btn_s = QtWidgets.QPushButton("💾 Save Changes (Commit)"); btn_s.setStyleSheet("background-color: #c8e6c9; font-weight: bold; padding: 10px; color: #1b5e20;")
        btn_s.clicked.connect(self.save_all_changes); layout.addWidget(btn_s)

        layout.addSpacing(5)
        line = QtWidgets.QFrame(); line.setFrameShape(QtWidgets.QFrame.HLine); layout.addWidget(line)
        layout.addSpacing(5)
        btn_upd = QtWidgets.QPushButton("🚀 Check Update"); btn_upd.clicked.connect(self.update_plugin); layout.addWidget(btn_upd)
        lbl_author = QtWidgets.QLabel("จัดทำโดย: ชาคฤตย์ จันทรสุกศรี"); lbl_dept = QtWidgets.QLabel("กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        font = QtGui.QFont(); font.setPointSize(9); lbl_author.setFont(font); lbl_dept.setFont(font)
        lbl_author.setAlignment(QtCore.Qt.AlignCenter)
        lbl_dept.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(lbl_author); layout.addWidget(lbl_dept)
    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                lyr.selectByIds(ids)
        self.iface.mapCanvas().refresh()

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def refresh_layers(self):
        self.poly_cb.clear(); self.point_cb.clear()
        for lyr in QgsProject.instance().mapLayers().values():
            self.poly_cb.addItem(lyr.name(), lyr.id()); self.point_cb.addItem(lyr.name(), lyr.id())

    def start_interactive(self, mode):
        self.cancel_transform(); self.mode = mode
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        config = QgsProject.instance().snappingConfig()
        config.setEnabled(True); config.setMode(QgsSnappingConfig.AdvancedConfiguration)
        for lyr in [poly_lyr, point_lyr]:
            if lyr: config.setIndividualLayerSettings(lyr, QgsSnappingConfig.IndividualLayerSettings(True, QgsSnappingConfig.Vertex, 35, QgsTolerance.Pixels))
        QgsProject.instance().setSnappingConfig(config)
        self.snap_utils = self.iface.mapCanvas().snappingUtils()
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_click(self, point, button):
        match = self.snap_utils.snapToMap(point)
        pt = match.point() if match.isValid() else QgsPointXY(point.x(), point.y())
        m = QgsVertexMarker(self.iface.mapCanvas()); m.setCenter(pt); m.setPenWidth(4)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        self.markers.append(m); self.src_pts.append(pt)
        limit = {'move': 2, 'modify_node': 2, 'rotate': 3, 'scale': 3, 'transform': 4}[self.mode]
        if len(self.src_pts) == limit: self.execute_tool()

    def execute_tool(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        if not layers:
            self.cancel_transform(); return
            
        # 1. Lock Selection ไว้ก่อนเริ่มแก้
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        
        self.last_layers = layers
        p = self.src_pts
        angle_deg = 0; scale_factor = 1.0
        
        if self.mode == 'rotate':
            a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
            a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
            angle_deg = -math.degrees(a2 - a1)
        elif self.mode == 'scale':
            d1 = math.sqrt(p[0].sqrDist(p[1])); d2 = math.sqrt(p[0].sqrDist(p[2]))
            if d1 > 0: scale_factor = d2/d1

        for lyr in layers:
            lyr.beginEditCommand(self.mode.capitalize())
            if not lyr.isEditable(): lyr.startEditing()
            
            for f in lyr.selectedFeatures():
                geom = f.geometry()
                if self.mode == 'transform': self.apply_similarity_single(lyr, f)
                elif self.mode == 'modify_node': self.apply_node_modify_single(lyr, f, p[0], p[1])
                elif self.mode == 'move': 
                    geom.translate(p[1].x()-p[0].x(), p[1].y()-p[0].y())
                    lyr.changeGeometry(f.id(), geom)
                elif self.mode == 'rotate': 
                    geom.rotate(angle_deg, QgsPointXY(p[0].x(), p[0].y()))
                    lyr.changeGeometry(f.id(), geom)
                elif self.mode == 'scale':
                    geom.translate(-p[0].x(), -p[0].y())
                    matrix = QtGui.QTransform(); matrix.scale(scale_factor, scale_factor)
                    geom.transform(matrix)
                    geom.translate(p[0].x(), p[0].y())
                    lyr.changeGeometry(f.id(), geom)
            
            lyr.endEditCommand()

        # 2. ปล่อยให้ QGIS เคลียร์บัฟเฟอร์ 100ms แล้วค่อยสั่งเลือกใหม่
        QtCore.QTimer.singleShot(100, self.restore_selection)
        
        self.cancel_transform()

    def apply_node_modify_single(self, lyr, f, old_pt, new_pt):
        th = 0.001; geom = f.geometry()
        if geom.type() == 0 and geom.asPoint().sqrDist(old_pt) < th:
            lyr.changeGeometry(f.id(), QgsGeometry.fromPointXY(new_pt))
        elif geom.type() == 2:
            cp = re.compile(r'([-+]?\d*\.\d+|[-+]?\d+)\s+([-+]?\d*\.\d+|[-+]?\d+)')
            new_wkt = cp.sub(lambda m: f"{new_pt.x():.8f} {new_pt.y():.8f}" if math.sqrt((float(m.group(1))-old_pt.x())**2 + (float(m.group(2))-old_pt.y())**2) < th else m.group(0), geom.asWkt())
            lyr.changeGeometry(f.id(), QgsGeometry.fromWkt(new_wkt))

    def apply_similarity_single(self, lyr, f):
        p = self.src_pts; s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dx_s, dy_s = s2.x()-s1.x(), s2.y()-s1.y(); dx_d, dy_d = d2.x()-d1.x(), d2.y()-d1.y()
        den = dx_s**2 + dy_s**2
        if den == 0: return
        a, b = (dx_s*dx_d + dy_s*dy_d)/den, (dx_s*dy_d - dy_s*dx_d)/den
        tx, ty = d1.x()-(a*s1.x()-b*s1.y()), d1.y()-(b*s1.x()+a*s1.y())
        cp = re.compile(r'([-+]?\d*\.\d+|[-+]?\d+)\s+([-+]?\d*\.\d+|[-+]?\d+)')
        new_wkt = cp.sub(lambda m: f"{a*float(m.group(1))-b*float(m.group(2))+tx:.8f} {b*float(m.group(1))+a*float(m.group(2))+ty:.8f}", f.geometry().asWkt())
        lyr.changeGeometry(f.id(), QgsGeometry.fromWkt(new_wkt))

    def set_score_value(self, value):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return

        # เก็บรายชื่อเลเยอร์ไว้ให้ปุ่ม Undo รู้ว่าจะต้องไปย้อนที่เลเยอร์ไหน
        self.last_layers = layers 
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        for lyr in layers:
            # ตรวจสอบว่าเลเยอร์อยู่ในโหมดแก้ไขหรือไม่
            if not lyr.isEditable(): 
                lyr.startEditing()
            
            # เริ่มบันทึกคำสั่งสำหรับ Undo
            lyr.beginEditCommand(f"Change Score to {value}")
            
            idx = lyr.fields().indexFromName('Score')
            if idx == -1: idx = lyr.fields().indexFromName('score')
            
            if idx != -1:
                for f in lyr.selectedFeatures():
                    lyr.changeAttributeValue(f.id(), idx, value)
                lyr.endEditCommand() # ปิดคำสั่ง (จะถูกส่งเข้า Undo Stack ของ QGIS)
            else:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"ไม่พบฟิลด์ Score ใน {lyr.name()}", level=3, duration=10)

        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def group_cluster_ids(self):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        fields = [f.name() for f in poly_layer.fields()]
        target_field = next((f for f in fields if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
        if not target_field: return
        main_val = poly_layer.selectedFeatures()[0][target_field]
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        for lyr in layers:
            lyr.beginEditCommand("Group Cluster ID")
            lyr_f = [f.name() for f in lyr.fields()]
            lyr_t = next((f for f in lyr_f if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
            if lyr_t:
                idx = lyr.fields().indexFromName(lyr_t)
                for f in lyr.selectedFeatures(): lyr.changeAttributeValue(f.id(), idx, main_val)
            lyr.endEditCommand()
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        self.clear_rubber_band()
        self.iface.mapCanvas().refresh()
        self.iface.actionSelect().trigger()
        
        self.src_pts = []; self.clear_markers()
        self.set_select_tool()

    def undo_transform(self):
        """ย้อนกลับการกระทำล่าสุด (รองรับทั้งตำแหน่งและ Score)"""
        if not self.last_layers:
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการที่สามารถย้อนกลับได้", level=2, duration=3)
            return

        for lyr in self.last_layers:
            if lyr and lyr.isEditable():
                # ใช้คำสั่ง undo ของตัวเลเยอร์เอง
                lyr.undoStack().undo() 
        
        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดแล้ว", level=1, duration=3)

    def save_all_changes(self):
        for lyr in [QgsProject.instance().mapLayer(self.poly_cb.currentData()), QgsProject.instance().mapLayer(self.point_cb.currentData())]:
            if lyr and lyr.isEditable(): lyr.commitChanges(); lyr.startEditing()
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3, duration=3)

    def update_plugin(self):
        V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
        Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"
        try:
            res = requests.get(V_URL, timeout=5)
            if res.text.strip() > self.version:
                if QtWidgets.QMessageBox.question(self.dlg, "Update", "พบเวอร์ชันใหม่ ต้องการอัปเดตไหม?") == QtWidgets.QMessageBox.Yes:
                    r = requests.get(Z_URL); z = zipfile.ZipFile(io.BytesIO(r.content))
                    z.extractall(os.path.dirname(os.path.dirname(__file__)))
                    QtWidgets.QMessageBox.information(self.dlg, "Done", "อัปเดตแล้ว! กรุณา Restart QGIS")
            else: QtWidgets.QMessageBox.information(self.dlg, "Update", "คุณใช้เวอร์ชันล่าสุดแล้ว")
        except: pass

    def process_selection(self, mode):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        sel = poly_layer.selectedFeatures()
        if not sel: return
        fields = [f.name() for f in poly_layer.fields()]
        target = next((f for f in fields if f.lower() in (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])), None)
        if not target: return
        v_list = [f"'{f[target]}'" if isinstance(f[target], str) else str(f[target]) for f in sel if f[target] is not None]
        if v_list:
            expr = f'"{target}" IN ({",".join(list(set(v_list)))})'
            poly_layer.selectByExpression(expr)
            if point_layer: point_layer.selectByExpression(expr)
            self.iface.mapCanvas().refresh()
            
    def start_align_tool(self):
        """เรียกใช้เครื่องมือพร้อมเปิดระบบ Snapping"""
        self.cancel_transform()
        self.mode = 'align_point_driven'
        
        # ตั้งค่า Snapping Utils
        self.snap_utils = self.iface.mapCanvas().snappingUtils()
        
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_align_click)
        self.temp_tool.canvasMoveEvent = self.handle_align_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_align_mouse_move(self, event):
        """วาด Rubber Band พร้อม Snap ตามเมาส์"""
        if self.rubber_band and len(self.src_pts) == 1:
            # ตรวจสอบการ Snap ขณะลากเมาส์
            match = self.snap_utils.snapToMap(event.mapPoint())
            curr_pt = match.point() if match.isValid() else event.mapPoint()
            
            self.rubber_band.removeLastPoint()
            self.rubber_band.addPoint(curr_pt)

    def handle_align_click(self, point, button):
        """จัดการการคลิกจุด p1 และ p2 พร้อม Snap และปรับเส้นให้ชัดขึ้น"""
        match = self.snap_utils.snapToMap(point)
        pt = match.point() if match.isValid() else point
        
        self.src_pts.append(pt)
        
        # Marker จุดคลิก (สีแดงสด ขนาดใหญ่ขึ้น)
        m = QgsVertexMarker(self.iface.mapCanvas())
        m.setCenter(pt)
        m.setColor(QtGui.QColor(255, 0, 0)) # สีแดง
        m.setPenWidth(5) # เส้นขอบหนาขึ้น
        m.setIconSize(10)
        self.markers.append(m)
        
        if len(self.src_pts) == 1:
            # ล้างค่าเก่าทิ้งก่อน (ถ้ามี)
            self.clear_rubber_band()
            
            # สร้าง Rubber Band เส้นแนวทาง
            self.rubber_band = QgsRubberBand(self.iface.mapCanvas(), QgsWkbTypes.LineGeometry)
            
            # --- ปรับความเข้มและสีที่นี่ ---
            self.rubber_band.setColor(QtGui.QColor(255, 0, 0)) # สีแดงสด (ไม่โปร่งแสง)
            self.rubber_band.setWidth(3) # เส้นหนาขึ้นเป็น 3
            self.rubber_band.setLineStyle(QtCore.Qt.SolidLine) # เปลี่ยนเป็นเส้นทึบเพื่อให้เห็นชัดเจน
            
            self.rubber_band.addPoint(pt)
            self.rubber_band.addPoint(pt)

        if len(self.src_pts) == 2:
            # ประมวลผล
            self.execute_point_node_alignment()
            # ล้างค่าและลบเส้นออกจากหน้าจอทันที
            self.cancel_transform()
            
    def clear_rubber_band(self):
        """ลบ Rubber Band ออกจากหน้าจอและหน่วยความจำอย่างเด็ดขาด"""
        if self.rubber_band:
            self.rubber_band.hide() # ซ่อนทันที
            self.iface.mapCanvas().scene().removeItem(self.rubber_band) # ลบออกจาก Scene
            self.rubber_band = None # คืนค่าว่าง
            
    def execute_point_node_alignment(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        if not point_lyr or point_lyr.selectedFeatureCount() == 0:
            return
        # --- ส่วนที่เพิ่ม: เก็บ Selection ไว้ก่อนเริ่มทำงาน ---
        layers_to_restore = []
        if point_lyr: layers_to_restore.append(point_lyr)
        if poly_lyr: layers_to_restore.append(poly_lyr)
        
        # เก็บ ID ของฟีเจอร์ที่เลือกไว้ใน Dictionary
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers_to_restore}
        
        # จุดอ้างอิงที่คลิกบนหน้าจอ
        p1, p2 = self.src_pts[0], self.src_pts[1]
        
        # --- สูตรคณิตศาสตร์สำหรับ Infinite Line ---
        # หา vector ของเส้นอ้างอิง
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag_sq = dx*dx + dy*dy
        
        if mag_sq == 0: return # ป้องกันกรณีคลิกจุดเดียวกัน

        if not point_lyr.isEditable(): point_lyr.startEditing()
        if poly_lyr and not poly_lyr.isEditable(): poly_lyr.startEditing()

        point_lyr.beginEditCommand("Align to Infinite Line")
        if poly_lyr: poly_lyr.beginEditCommand("Align Nodes to Infinite Line")

        precision = 0.005 

        try:
            for pt_feat in point_lyr.selectedFeatures():
                old_pt = pt_feat.geometry().asPoint()
                
                # คำนวณหา Projection Point บนเส้นตรงที่ยืดยาวออกไป (Infinite Line)
                # สูตร: P_proj = P1 + u * (P2 - P1)
                u = ((old_pt.x() - p1.x()) * dx + (old_pt.y() - p1.y()) * dy) / mag_sq
                
                # สร้างพิกัดใหม่ (จุดนี้จะอยู่บนแนวเส้น p1-p2 เสมอ ไม่ว่าจะอยู่ข้างนอกหรือไม่)
                new_x = p1.x() + u * dx
                new_y = p1.y() + u * dy
                new_pt = QgsPointXY(new_x, new_y)
                new_pt_geom = QgsGeometry.fromPointXY(new_pt)
                
                # ย้าย Point
                point_lyr.changeGeometry(pt_feat.id(), new_pt_geom)
                
                # ย้าย Node Polygon ที่สัมพันธ์กัน
                if poly_lyr:
                    request = QgsFeatureRequest().setFilterRect(pt_feat.geometry().buffer(0.1, 5).boundingBox())
                    for poly_feat in poly_lyr.getFeatures(request):
                        wkt = poly_feat.geometry().asWkt()
                        cp = re.compile(r'([-+]?\d*\.\d+|[-+]?\d+)\s+([-+]?\d*\.\d+|[-+]?\d+)')
                        
                        def update_matching_node(match):
                            vx, vy = float(match.group(1)), float(match.group(2))
                            if math.sqrt((vx - old_pt.x())**2 + (vy - old_pt.y())**2) < precision:
                                return f"{new_pt.x():.10f} {new_pt.y():.10f}"
                            return match.group(0)
                        
                        new_wkt = cp.sub(update_matching_node, wkt)
                        poly_lyr.changeGeometry(poly_feat.id(), QgsGeometry.fromWkt(new_wkt))
                
            if poly_lyr: poly_lyr.endEditCommand()
            point_lyr.endEditCommand()
            self.iface.messageBar().pushMessage("Success", "จัดแนว Point และ Node เรียบร้อย", level=1, duration=3)
        except Exception as e:
            if poly_lyr: poly_lyr.destroyEditCommand()
            point_lyr.destroyEditCommand()
            print(f"Infinite Align Error: {e}")

        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)