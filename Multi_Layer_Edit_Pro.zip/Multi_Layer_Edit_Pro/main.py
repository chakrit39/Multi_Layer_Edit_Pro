import os
import re
import math
import requests
import zipfile
import io
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import (QgsProject, QgsPointXY, QgsGeometry,
                       QgsSnappingConfig, QgsTolerance)
from qgis.gui import QgsMapToolEmitPoint, QgsVertexMarker
from qgis.utils import iface

class MultiLayerEditPro:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = [] 
        self.temp_tool = None
        self.last_layers = []
        self.mode = "" 
        self.version = "1.0.8"
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", self.action)
        self.clear_markers()

    def run(self):
        if self.dlg is None: self.create_dialog()
        self.dlg.show()

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro v{self.version}")
        self.dlg.setMinimumWidth(480)
        layout = QtWidgets.QVBoxLayout(self.dlg)
        
        layout.addWidget(QtWidgets.QLabel("<b>1. ตั้งค่าชั้นข้อมูล</b>"))
        self.poly_cb = QtWidgets.QComboBox(); self.point_cb = QtWidgets.QComboBox()
        layout.addWidget(QtWidgets.QLabel("เลเยอร์แปลง (Polygon):")); layout.addWidget(self.poly_cb)
        layout.addWidget(QtWidgets.QLabel("เลเยอร์หมุด (Point):")); layout.addWidget(self.point_cb)
        btn_refresh = QtWidgets.QPushButton("Refresh Layers"); btn_refresh.clicked.connect(self.refresh_layers); layout.addWidget(btn_refresh)
        self.refresh_layers()
        layout.addSpacing(10)
        
        layout.addWidget(QtWidgets.QLabel("<b>2. เลือกกลุ่มข้อมูล</b>"))
        h_sel = QtWidgets.QHBoxLayout()
        btn_c = QtWidgets.QPushButton("By Cluster ID"); btn_c.clicked.connect(lambda: self.process_selection('cluster'))
        btn_u = QtWidgets.QPushButton("By UTM"); btn_u.clicked.connect(lambda: self.process_selection('utm'))
        h_sel.addWidget(btn_c); h_sel.addWidget(btn_u); layout.addLayout(h_sel)
        layout.addSpacing(10)

        layout.addWidget(QtWidgets.QLabel("<b>3. เครื่องมือปรับแต่งทั่วไป</b>"))
        grid_tools = QtWidgets.QGridLayout()
        btn_move = QtWidgets.QPushButton("Move"); btn_move.clicked.connect(lambda: self.start_interactive('move'))
        btn_rot = QtWidgets.QPushButton("Rotate"); btn_rot.clicked.connect(lambda: self.start_interactive('rotate'))
        btn_scale = QtWidgets.QPushButton("Scale"); btn_scale.clicked.connect(lambda: self.start_interactive('scale'))
        grid_tools.addWidget(btn_move, 0, 0); grid_tools.addWidget(btn_rot, 0, 1); grid_tools.addWidget(btn_scale, 0, 2)
        layout.addLayout(grid_tools); layout.addSpacing(10)

        h_row_45 = QtWidgets.QHBoxLayout()
        v_col4 = QtWidgets.QVBoxLayout(); v_col4.addWidget(QtWidgets.QLabel("<b>4. Transform (2 Pts)</b>"))
        btn_t = QtWidgets.QPushButton("Start Transform"); btn_t.setStyleSheet("background-color: #ffccbc; font-weight: bold; padding: 10px;")
        btn_t.clicked.connect(lambda: self.start_interactive('transform')); v_col4.addWidget(btn_t); h_row_45.addLayout(v_col4)
        v_col5 = QtWidgets.QVBoxLayout(); v_col5.addWidget(QtWidgets.QLabel("<b>5. Move Node (Sync)</b>"))
        btn_node = QtWidgets.QPushButton("Move Node"); btn_node.setStyleSheet("background-color: #e8f5e9; font-weight: bold; border: 1px solid #4caf50; padding: 10px;")
        btn_node.clicked.connect(lambda: self.start_interactive('modify_node')); v_col5.addWidget(btn_node); h_row_45.addLayout(v_col5)
        layout.addLayout(h_row_45); layout.addSpacing(10)

        h_row_67 = QtWidgets.QHBoxLayout()
        v_col6 = QtWidgets.QVBoxLayout(); v_col6.addWidget(QtWidgets.QLabel("<b>6. จัดกลุ่ม Cluster</b>"))
        btn_group_id = QtWidgets.QPushButton("Sync Cluster ID"); btn_group_id.setStyleSheet("background-color: #e3f2fd; border: 1px solid #2196f3; padding: 10px;")
        btn_group_id.clicked.connect(self.group_cluster_ids); v_col6.addWidget(btn_group_id); h_row_67.addLayout(v_col6)
        v_col7 = QtWidgets.QVBoxLayout(); v_col7.addWidget(QtWidgets.QLabel("<b>7. ตั้งค่า Score</b>"))
        btn_set_score = QtWidgets.QPushButton("Set Score = 1"); btn_set_score.setStyleSheet("background-color: #fff9c4; border: 1px solid #fbc02d; padding: 10px; font-weight: bold;")
        btn_set_score.clicked.connect(self.set_score_to_one); v_col7.addWidget(btn_set_score); h_row_67.addLayout(v_col7)
        layout.addLayout(h_row_67)

        layout.addSpacing(15)
        h_ctrl = QtWidgets.QHBoxLayout()
        btn_rs = QtWidgets.QPushButton("✖ Reset / Cancel"); btn_rs.clicked.connect(self.cancel_transform) 
        btn_un = QtWidgets.QPushButton("↺ Undo Last"); btn_un.clicked.connect(self.undo_transform) 
        h_ctrl.addWidget(btn_rs); h_ctrl.addWidget(btn_un); layout.addLayout(h_ctrl)
        
        btn_s = QtWidgets.QPushButton("💾 Save Changes (Commit)"); btn_s.setStyleSheet("background-color: #c8e6c9; font-weight: bold; padding: 10px; color: #1b5e20;")
        btn_s.clicked.connect(self.save_all_changes); layout.addWidget(btn_s)
        

        
        btn_upd = QtWidgets.QPushButton("🚀 Check Update"); btn_upd.clicked.connect(self.update_plugin); layout.addWidget(btn_upd)

    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                lyr.selectByIds(ids)
        self.iface.mapCanvas().refresh()

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def refresh_layers(self):
        self.poly_cb.clear(); self.point_cb.clear()
        for lyr in QgsProject.instance().mapLayers().values():
            self.poly_cb.addItem(lyr.name(), lyr.id()); self.point_cb.addItem(lyr.name(), lyr.id())

    def start_interactive(self, mode):
        self.cancel_transform(); self.mode = mode
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        config = QgsProject.instance().snappingConfig()
        config.setEnabled(True); config.setMode(QgsSnappingConfig.AdvancedConfiguration)
        for lyr in [poly_lyr, point_lyr]:
            if lyr: config.setIndividualLayerSettings(lyr, QgsSnappingConfig.IndividualLayerSettings(True, QgsSnappingConfig.Vertex, 35, QgsTolerance.Pixels))
        QgsProject.instance().setSnappingConfig(config)
        self.snap_utils = self.iface.mapCanvas().snappingUtils()
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_click(self, point, button):
        match = self.snap_utils.snapToMap(point)
        pt = match.point() if match.isValid() else QgsPointXY(point.x(), point.y())
        m = QgsVertexMarker(self.iface.mapCanvas()); m.setCenter(pt); m.setPenWidth(4)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        self.markers.append(m); self.src_pts.append(pt)
        limit = {'move': 2, 'modify_node': 2, 'rotate': 3, 'scale': 3, 'transform': 4}[self.mode]
        if len(self.src_pts) == limit: self.execute_tool()

    def execute_tool(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        if not layers:
            self.cancel_transform(); return
            
        # 1. Lock Selection ไว้ก่อนเริ่มแก้
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        
        self.last_layers = layers
        p = self.src_pts
        angle_deg = 0; scale_factor = 1.0
        
        if self.mode == 'rotate':
            a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
            a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
            angle_deg = -math.degrees(a2 - a1)
        elif self.mode == 'scale':
            d1 = math.sqrt(p[0].sqrDist(p[1])); d2 = math.sqrt(p[0].sqrDist(p[2]))
            if d1 > 0: scale_factor = d2/d1

        for lyr in layers:
            lyr.beginEditCommand(self.mode.capitalize())
            if not lyr.isEditable(): lyr.startEditing()
            
            for f in lyr.selectedFeatures():
                geom = f.geometry()
                if self.mode == 'transform': self.apply_similarity_single(lyr, f)
                elif self.mode == 'modify_node': self.apply_node_modify_single(lyr, f, p[0], p[1])
                elif self.mode == 'move': 
                    geom.translate(p[1].x()-p[0].x(), p[1].y()-p[0].y())
                    lyr.changeGeometry(f.id(), geom)
                elif self.mode == 'rotate': 
                    geom.rotate(angle_deg, QgsPointXY(p[0].x(), p[0].y()))
                    lyr.changeGeometry(f.id(), geom)
                elif self.mode == 'scale':
                    geom.translate(-p[0].x(), -p[0].y())
                    matrix = QtGui.QTransform(); matrix.scale(scale_factor, scale_factor)
                    geom.transform(matrix)
                    geom.translate(p[0].x(), p[0].y())
                    lyr.changeGeometry(f.id(), geom)
            
            lyr.endEditCommand()

        # 2. ปล่อยให้ QGIS เคลียร์บัฟเฟอร์ 100ms แล้วค่อยสั่งเลือกใหม่
        QtCore.QTimer.singleShot(100, self.restore_selection)
        
        self.cancel_transform()

    def apply_node_modify_single(self, lyr, f, old_pt, new_pt):
        th = 0.001; geom = f.geometry()
        if geom.type() == 0 and geom.asPoint().sqrDist(old_pt) < th:
            lyr.changeGeometry(f.id(), QgsGeometry.fromPointXY(new_pt))
        elif geom.type() == 2:
            cp = re.compile(r'([-+]?\d*\.\d+|[-+]?\d+)\s+([-+]?\d*\.\d+|[-+]?\d+)')
            new_wkt = cp.sub(lambda m: f"{new_pt.x():.8f} {new_pt.y():.8f}" if math.sqrt((float(m.group(1))-old_pt.x())**2 + (float(m.group(2))-old_pt.y())**2) < th else m.group(0), geom.asWkt())
            lyr.changeGeometry(f.id(), QgsGeometry.fromWkt(new_wkt))

    def apply_similarity_single(self, lyr, f):
        p = self.src_pts; s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dx_s, dy_s = s2.x()-s1.x(), s2.y()-s1.y(); dx_d, dy_d = d2.x()-d1.x(), d2.y()-d1.y()
        den = dx_s**2 + dy_s**2
        if den == 0: return
        a, b = (dx_s*dx_d + dy_s*dy_d)/den, (dx_s*dy_d - dy_s*dx_d)/den
        tx, ty = d1.x()-(a*s1.x()-b*s1.y()), d1.y()-(b*s1.x()+a*s1.y())
        cp = re.compile(r'([-+]?\d*\.\d+|[-+]?\d+)\s+([-+]?\d*\.\d+|[-+]?\d+)')
        new_wkt = cp.sub(lambda m: f"{a*float(m.group(1))-b*float(m.group(2))+tx:.8f} {b*float(m.group(1))+a*float(m.group(2))+ty:.8f}", f.geometry().asWkt())
        lyr.changeGeometry(f.id(), QgsGeometry.fromWkt(new_wkt))

    def set_score_to_one(self):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        for lyr in layers:
            lyr.beginEditCommand("Set Score to 1")
            idx = lyr.fields().indexFromName('Score')
            if idx == -1: idx = lyr.fields().indexFromName('score')
            if idx != -1:
                for f in lyr.selectedFeatures(): lyr.changeAttributeValue(f.id(), idx, 1)
            lyr.endEditCommand()
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def group_cluster_ids(self):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        fields = [f.name() for f in poly_layer.fields()]
        target_field = next((f for f in fields if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
        if not target_field: return
        main_val = poly_layer.selectedFeatures()[0][target_field]
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        for lyr in layers:
            lyr.beginEditCommand("Group Cluster ID")
            lyr_f = [f.name() for f in lyr.fields()]
            lyr_t = next((f for f in lyr_f if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
            if lyr_t:
                idx = lyr.fields().indexFromName(lyr_t)
                for f in lyr.selectedFeatures(): lyr.changeAttributeValue(f.id(), idx, main_val)
            lyr.endEditCommand()
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        self.src_pts = []; self.clear_markers()
        self.set_select_tool()

    def undo_transform(self):
        if not self.last_layers: return
        for lyr in self.last_layers: 
            if lyr and lyr.isEditable(): lyr.rollBack(); lyr.startEditing()
        self.iface.mapCanvas().refresh()

    def save_all_changes(self):
        for lyr in [QgsProject.instance().mapLayer(self.poly_cb.currentData()), QgsProject.instance().mapLayer(self.point_cb.currentData())]:
            if lyr and lyr.isEditable(): lyr.commitChanges(); lyr.startEditing()
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3)

    def update_plugin(self):
        V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
        Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"
        try:
            res = requests.get(V_URL, timeout=5)
            if res.text.strip() > self.version:
                if QtWidgets.QMessageBox.question(self.dlg, "Update", "พบเวอร์ชันใหม่ ต้องการอัปเดตไหม?") == QtWidgets.QMessageBox.Yes:
                    r = requests.get(Z_URL); z = zipfile.ZipFile(io.BytesIO(r.content))
                    z.extractall(os.path.dirname(os.path.dirname(__file__)))
                    QtWidgets.QMessageBox.information(self.dlg, "Done", "อัปเดตแล้ว! กรุณา Restart QGIS")
            else: QtWidgets.QMessageBox.information(self.dlg, "Update", "คุณใช้เวอร์ชันล่าสุดแล้ว")
        except: pass

    def process_selection(self, mode):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        sel = poly_layer.selectedFeatures()
        if not sel: return
        fields = [f.name() for f in poly_layer.fields()]
        target = next((f for f in fields if f.lower() in (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])), None)
        if not target: return
        v_list = [f"'{f[target]}'" if isinstance(f[target], str) else str(f[target]) for f in sel if f[target] is not None]
        if v_list:
            expr = f'"{target}" IN ({",".join(list(set(v_list)))})'
            poly_layer.selectByExpression(expr)
            if point_layer: point_layer.selectByExpression(expr)
            self.iface.mapCanvas().refresh()