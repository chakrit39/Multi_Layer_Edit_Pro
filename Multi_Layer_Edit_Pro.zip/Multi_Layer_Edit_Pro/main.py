# -*- coding: utf-8 -*-
"""Multi-Layer Edit Pro — คลาสหลักของปลั๊กอิน (composition root)

2.4.0: เมธอดแยกไปอยู่ใน mixin ตามพื้นที่งาน (features/ services/ ui/) แบบย้ายตรงตัวด้วย devtools/split_main.py
ไฟล์นี้เหลือ: ค่าคงที่ระดับคลาส, __init__, initGui/unload/run และการผูกสัญญาณตอนเริ่ม
main.py กับ metadata.txt ต้องอยู่ที่รากโฟลเดอร์ปลั๊กอินเสมอ (ตัวอัปเดตรุ่นก่อนตรวจสองไฟล์นี้)"""
import os
import time
from qgis.PyQt import QtCore, QtGui, QtWidgets
from qgis.core import Qgis, QgsFeatureRequest, QgsMessageLog, QgsProject, QgsVectorLayer
from qgis.gui import QgsVertexMarker
from .changelog import CHANGELOG
from .core.const import _CLICK_LIMIT, _PREVIEW_MODES, _PREVIEW_VERTEX_BUDGET
from .core.util import (_area_num, _branch_office_of, _DATE_COLS, _date_txt, _date_val, _dol_area_m2,
                        _dol_doc_code, _DOL_DOC_RULES, _dol_here_hint, _dol_lis_hint, _dol_more_hint, _dol_via_note,
                        _EP_MAP4_MAX, _ep_normalize, _EP_SCALES,
                        _fld_idx, _is_chor, _is_l1, _is_sql_null, _LockScanError, _log_err, _log_exc,
                        _log_msg_once, _LOG_ONCE, _log_sql_val, _marker_type_from_parcel, _meta_value, _name_key,
                        _natkey, _net_err_text, _newest_name, _norm_utm, _osa, _parse_version, _PERM_DENIED_RE,
                        _PERM_OBJ_RE, _probe_xy_24047, _public_landno, _PW_RE, _reason_text, _resp_text, _rngw,
                        _ROMAN, _scrub, _sheet_label, _sheet_str, _TH_NO_LINE_START, _TH_RE, _txt,
                        _TYPE_NOT_ON_MARKER, _UTM_FIELD_NAMES, _UTM_ตัวนับ, _VER_RE, _vkey, _wrap_th, _กริดจุด)
from .features.access import AccessMixin
from .features.align import AlignMixin
from .features.attributes import AttributesMixin
from .features.create_parcel import CreateParcelMixin
from .features.dol import DolMixin
from .features.donut import DonutMixin
from .features.edit_parcel import EditParcelMixin
from .features.layers import LayersMixin
from .features.line import LineToolMixin
from .features.locks import LocksMixin
from .features.move_nodes import MoveNodesMixin
from .features.nodes import NodesMixin
from .features.pair_highlight import PairHighlightMixin
from .features.parcels import ParcelsMixin
from .features.project import ProjectHooksMixin
from .features.selection import SelectionMixin
from .features.transform import TransformMixin
from .lock_rules import is_l1_type, L1_TYPES, marker_lock_type, norm_type
from .map_tools import (_MlepKeys, AddNodeTool, BoxSelectTool, CreateParcelTool, DeleteNodeTool, PolygonPickTool,
                        RenameNodeTool, SwapNodeTool, SyncVertexTool)
from .services.edits import EditsMixin
from .services.l1_gate import _ALLOW_COMMIT_API, _allow_commit_api, L1CommitGateMixin
from .services.net import NetMixin
from .services.pairing import PairingMixin
from .services.type_log import TypeLogMixin
from .services.update_core import (_check_update_zip, _disk_version, _guarded_imports, _install_update_zip,
                                   _missing_relative_imports, _os_reason, _qgis_version_tuple, _rename_retry, _rmtree_quiet,
                                   _rollback_failed_update, _UPD_BACKUP, _upd_check_disk, _UPD_FAILED, _upd_get,
                                   _upd_migrate_legacy, _upd_net_text, _upd_paths, _UPD_PREV, _UpdateInstallError,
                                   UPDATE_V_URL, UPDATE_Z_URL)
from .services.updater import UpdaterMixin
from .services.workers import _FnWorker, ParcelLookupWorker
from .ui.dialog import DialogMixin
from .ui.qt_helpers import (_EmitClickTool, _EscWatch, _HALF_PROP, _half_rb_text, _half_save_orphan_watch,
                            _half_save_orphans_pop, _lift_dlg, _mlep_debris_clear, _MLEP_MENU, _OWN_PROP,
                            _qobj_dispose, _whats_new_rows)
from .ui.shortcuts import ShortcutsMixin
from .features import line as _late_0
from .features import donut as _late_1

# ชื่อระดับโมดูลเดิมของ main.py ยัง import จาก main ได้ (map_tools / สคริปต์เดิม / ตัวอัปเดตรุ่นก่อน)
__all__ = ['MultiLayerEditPro', 'AddNodeTool', 'BoxSelectTool', 'CHANGELOG', 'CreateParcelTool',
           'DeleteNodeTool', 'L1_TYPES', 'ParcelLookupWorker', 'PolygonPickTool', 'RenameNodeTool',
           'SwapNodeTool', 'SyncVertexTool', 'UPDATE_V_URL', 'UPDATE_Z_URL', '_ALLOW_COMMIT_API',
           '_CLICK_LIMIT', '_DATE_COLS', '_DOL_DOC_RULES',
           '_EP_MAP4_MAX', '_EP_SCALES', '_EmitClickTool', '_EscWatch', '_FnWorker', '_HALF_PROP',
           '_LOG_ONCE', '_LockScanError', '_MLEP_MENU', '_MlepKeys', '_OWN_PROP', '_PERM_DENIED_RE',
           '_PERM_OBJ_RE', '_PREVIEW_MODES', '_PREVIEW_VERTEX_BUDGET', '_PW_RE', '_ROMAN',
           '_TH_NO_LINE_START', '_TH_RE', '_TYPE_NOT_ON_MARKER', '_UPD_BACKUP', '_UPD_FAILED',
           '_UPD_PREV', '_UTM_FIELD_NAMES', '_UTM_ตัวนับ', '_UpdateInstallError', '_VER_RE',
           '_allow_commit_api', '_area_num', '_branch_office_of', '_check_update_zip', '_date_txt',
           '_date_val', '_disk_version', '_dol_area_m2', '_dol_doc_code', '_dol_here_hint',
           '_dol_lis_hint', '_dol_more_hint', '_dol_via_note', '_ep_normalize',
           '_fld_idx', '_guarded_imports', '_half_rb_text', '_half_save_orphan_watch',
           '_half_save_orphans_pop', '_install_update_zip', '_is_chor', '_is_l1', '_is_sql_null',
           '_lift_dlg', '_log_err', '_log_exc', '_log_msg_once', '_log_sql_val',
           '_marker_type_from_parcel', '_meta_value', '_missing_relative_imports',
           '_mlep_debris_clear', '_name_key', '_natkey', '_net_err_text', '_newest_name',
           '_norm_utm', '_os_reason', '_osa', '_parse_version', '_probe_xy_24047', '_public_landno',
           '_qgis_version_tuple', '_qobj_dispose', '_reason_text', '_rename_retry', '_resp_text',
           '_rmtree_quiet', '_rngw', '_rollback_failed_update', '_scrub', '_sheet_label',
           '_sheet_str', '_txt', '_upd_check_disk', '_upd_get', '_upd_migrate_legacy',
           '_upd_net_text', '_upd_paths', '_vkey', '_whats_new_rows', '_wrap_th', '_กริดจุด',
           'is_l1_type', 'marker_lock_type', 'norm_type']


class MultiLayerEditPro(ProjectHooksMixin, ShortcutsMixin, AccessMixin, TypeLogMixin, DialogMixin,
                        DolMixin, NetMixin, LayersMixin, TransformMixin, LocksMixin, AttributesMixin,
                        LineToolMixin, EditsMixin, L1CommitGateMixin, PairingMixin,
                        PairHighlightMixin, UpdaterMixin, SelectionMixin, NodesMixin, MoveNodesMixin,
                        ParcelsMixin, DonutMixin, EditParcelMixin, CreateParcelMixin, AlignMixin):
    # ★ 2.3.7 (review LC-03c / LC-05) — ทุกเครื่องมือที่ปลั๊กอินสร้างผ่าน self.temp_tool ⇒ ติดป้าย '_mlep_tool' ตอนกำหนดค่า
    #   ใช้แยก "เครื่องมือของเรา" บนแคนวาสได้แม้ temp_tool ถูกเปลี่ยน/ล้างไปแล้ว (เช่น _line_restore_tool คืนเครื่องมือเดิม
    #   ให้แล้วตั้ง temp_tool=None) · ป้ายเป็น dynamic property ของ Qt — ตายไปพร้อมตัวเครื่องมือ
    @property
    def temp_tool(self):
        return getattr(self, "_temp_tool_obj", None)

    @temp_tool.setter
    def temp_tool(self, tool):
        if tool is not None:
            try:
                tool.setProperty("_mlep_tool", True)
            except Exception:
                pass
        old = getattr(self, "_temp_tool_obj", None)
        self._temp_tool_obj = tool
        # ★ rc2 (audit A2-04) — เครื่องมือตัวเก่า (parent = แคนวาส) ไม่เคยถูกลบ ⇒ สะสมเป็นลูกของแคนวาสทุกครั้งที่กดปุ่ม
        #   และค้ำอินสแตนซ์ปลั๊กอินเก่าหลัง unload/reload ⇒ ลบทีหลัง (ดู _tool_reap_later — ไม่ลบตัวที่ยังใช้อยู่/ยังถูกอ้างถึง)
        if old is not None and old is not tool:
            try:
                self._tool_reap_later(old)
            except Exception:
                pass

    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = []
        self.temp_tool = None
        self.last_layers = []   # เลเยอร์ที่แก้ล่าสุด (ใช้ refer ทั่วไป — undo ใช้ op_history แทน)
        # ประวัติการแก้ไขของปลั๊กอินสำหรับ Undo: แต่ละรายการ = [(layer, n_steps), ...] ใหม่สุดท้าย
        self.op_history = []
        self._op_baseline = None   # snapshot index ของ undo-stack ก่อนเริ่ม operation ปัจจุบัน
        # ดักสถานะตอนปิด edit ของแต่ละเลเยอร์ (รู้ว่ากด Save หรือ Discard) สำหรับ guard ตอน undo
        self._edit_end = {}        # layer_id -> 'commit' | 'rollback'
        self._commit_seq = {}      # layer_id -> จำนวนครั้งที่ commit (ใช้จับ 'Save แทรกหลัง op')
        # ★ 2.3.7 (review UX-38) layer_id -> จำนวนครั้งที่ rollback (afterRollBack · รวม Rollback ที่ยังเปิดแก้ไขต่อ
        #   ซึ่งไม่ยิง editingStarted) — ใช้จับ "Discard แทรกหลัง op" แทนการเดาจาก isEditable()/canUndo()
        self._rollback_seq = {}
        # ★ 2.4.3 (review 🔴1) layer_id -> {pointer ของคำสั่งใน undo stack: ข้อความ} ที่ op ของปลั๊กอิน push (จดใน _op_commit)
        #   คีย์ Undo ใช้ตัดสินว่าคำสั่งบนสุดของชั้นเป็นงานของปลั๊กอินไหม (ประวัติ ↺ ถูกล้างแล้วแต่คำสั่งยังค้างใน stack)
        self._own_cmds = {}
        # ★ 2.3.7 (review LC-02) เครื่องหมาย "instance นี้ต่อ signal ของเลเยอร์นี้แล้ว" (dynamic property บนวัตถุ C++)
        self._watch_token = "mlep-" + os.urandom(8).hex()
        # ★ 2.3.7 (review DI-05) ชั้นที่ "อีกชั้นของคู่ลงฐานไปแล้วแต่ตัวเองยังค้าง" {layer id: {...}} + ป้ายเตือนบนแถบข้อความ
        self._half_saved = {}
        self._half_save_items = {}
        self._pending_half = None
        self._pending_pair_skip = None      # ★ 2.3.7 (review ER-01) เหตุที่ด่านก่อนบันทึก (ทาง QGIS) ตรวจไม่ได้/ไม่ครบ
        self._admin_on = False          # โหมดพิเศษเปิดอยู่ไหม (Ctrl+Shift+F12 · ต้องเป็น mlep_mod ขึ้นไป)
        self._mode_tier = self.TIER_STAFF   # ★ 2.3.0 ชั้นที่โหมดให้อยู่ตอนนี้ (0/1/2)
        self._admin_unlock_l1 = False   # ปลดล็อก L1-RTK/L1-TS ชั่วคราว (เฉพาะตอน admin)
        self._admin_shortcuts = []      # ★ 2.3.7 rc3 QShortcut ของปุ่มโหมดผู้ดูแล — มีเฉพาะตอนอยู่ในโหมด (ดู _load_admin_shortcuts)
        self._signal_layers = {}   # {layer id: id(object)} ดู _watch_layer_editing
        # [(layer_id | None, ชื่อ signal, slot)] ไว้ disconnect ตอน unload
        # ★★ 2 ก.ย. 69 — เดิมเก็บ "ตัว signal" ตรง ๆ ซึ่งทำให้ QGIS ดับทั้งตัวได้
        #   signal ของเลเยอร์ผูกกับวัตถุ C++ ของเลเยอร์นั้น พอพนักงานลบเลเยอร์ออกจาก
        #   สารบัญ วัตถุถูกทำลาย แล้ว unload ไปเรียก sig.disconnect(slot) บนของที่ตายแล้ว
        #   = SIGSEGV ซึ่ง try/except ดักไม่ได้ (วัดเองแล้ว exit 139 core dumped)
        #   ลำดับจริงที่เกิดได้: ลบชั้นหมุดออกแล้วลากกลับเข้ามาใหม่ (มีบันทึกว่าเกิดจริง)
        #   -> ปิด QGIS/อัปเดตปลั๊กอิน -> unload -> ดับพร้อมงานที่ยังไม่ได้บันทึก
        #   จึงเก็บแค่ "ชื่อ" แล้วค่อยหาตัวเลเยอร์ตอน unload ถ้าไม่เจอ = ข้ามไป
        self._signal_conns = []
        # เตือน "งานค้างยังไม่ได้บันทึก" — เหตุ 5 ส.ค. 69 พนักงานแก้สะสม 20 นาทีแล้วโปรแกรมค้าง
        # ต้อง kill = งานหายทั้งก้อน (ยังไม่เคยถึงฐานข้อมูล) -> เตือนแบบไม่บล็อก ทุก UNSAVED_NAG_MIN นาที
        self._unsaved_since = None      # เวลาที่เริ่มมีงานค้าง (monotonic)
        self._unsaved_last_nag = 0.0
        self._nag_timer = None
        self.mode = ""
        # ★ 31 ส.ค. 69 — เดิมพิมพ์เลขไว้ตรงนี้ แล้วรอบนี้บั๊มพ์ metadata.txt แต่ลืมบรรทัดนี้
        #   ผลคือ: พนักงานที่อัปเดตแล้วจะถูกถามอัปเดตซ้ำทุกครั้งที่เปิด QGIS ไม่มีวันจบ
        #   (เทียบ _vkey(เวอร์ชันบน GitHub) > _vkey(self.version) ใน _auto_check_update / update_plugin)
        #   และ What's New ของรุ่นใหม่จะไม่เด้ง = ได้ปุ่มใหม่มาโดยไม่มีคำอธิบาย
        #   -> อ่านจาก metadata.txt ให้เป็นแหล่งเดียว จะได้ไม่หลุดจากกันอีก
        self.version = self._read_version()
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล
        self.rubber_band = None
        # เงาตัวอย่าง Move/Rotate/Scale: [(layer, geom ต้นฉบับ, rubber band, gtype)]
        # geom snapshot ไว้ตอนคลิกแรก -> ทุกเฟรมแค่ copy+แปลง ไม่ต้องดึงข้อมูลใหม่
        self._preview_items = []
        self._preview_last = None   # key ของเฟรมล่าสุด (None = ไม่มีเงาบนจอ)
        self._preview_tool = None   # เครื่องมือที่เป็นเจ้าของเงารอบนี้ (ดู _map_tool_changed)
        self._preview_heavy = False # เงาถูกย่อเป็นกรอบรวมหรือไม่ (ไว้บอกผู้ใช้ที่แถบสถานะ)
        self._dol_highlight = None  # rubber band ไฮไลต์แปลงที่ค้นหา
        self._align_picked_ids = set()  # หมุดที่เลือกด้วยกล่อง (Align)
        self._align_markers = []
        self._shortcuts = []  # QShortcut ที่ผูกไว้
        self._field_cache = {}  # memoize การหา field ตามชื่อ (สำหรับ hover path ที่เรียกทุกเฟรม)
        # เฝ้า "มุมแปลงไม่มีหมุด" ตอน commit ทุกช่องทาง (รวมปุ่ม Save ของ QGIS เอง ไม่ใช่แค่ปุ่มปลั๊กอิน)
        self._pending_pair_warn = None   # ผลตรวจที่เก็บไว้ตอน beforeCommit -> เอาไปเตือนตอน afterCommit
        self._pair_warn_ack = False      # True = ปุ่ม Save ของปลั๊กอินถามไปแล้ว อย่าเตือนซ้ำ
        # ★ 2.4.0 (review DI-11) — ด่านล็อก L1 ตอนบันทึก (ดู _l1_commit_hits / _l1_native_gate)
        self._l1_save_ack = False        # True = ปุ่ม 💾 ของปลั๊กอินถามเรื่องแปลง/หมุด L1 ไปแล้ว ⇒ ด่าน beforeCommitChanges ไม่ถามซ้ำ
        self._l1_ok = {}                 # {layer id: {'g': {fid: [(wkb, ux)]}, 'd': {fid: ux}}} งานของเครื่องมือปลั๊กอินตอนปลดล็อก L1 / ข้อยกเว้น F6 (ไม่ถาม)
        self._l1_op_pre = None           # สภาพ buffer ก่อน op ของปลั๊กอิน (จดเฉพาะตอนปลดล็อก L1)
        self._l1_op_pre_a = None         # ★ rc2 (audit A4-04) ค่าที่แก้ค้างก่อน op (คู่กับ _l1_op_pre)
        self._l1_op_only = None          # ★ rc1 S5 (review R3-01) {layer id: {fid}} ข้อยกเว้น F6 ของ op ที่กำลังทำ (None = ไม่จำกัด)
        self._l1_hold = set()            # ชั้นคู่ที่ผู้ใช้ตอบ "ยังไม่บันทึก" ในรอบบันทึกนี้ (ล้างเมื่อกลับ event loop)
        self._l1_pass = set()            # ★ rc1 (F3) ชั้นคู่ที่ผู้ใช้ตอบ "บันทึก" แล้วในรอบนี้ ⇒ อีกชั้นของคู่ไม่ถามซ้ำ (ล้างเมื่อกลับ event loop)
        self._l1_blocked = []            # id ของชั้นที่ถูกระงับ commit อยู่ (คืนให้บันทึกได้ใน _l1_release)
        self._l1_prompting = 0           # ★ rc1 S5 (review R3-02) จำนวนกล่องคำถามของด่าน L1 ที่เปิดอยู่ (ระหว่างนั้นไม่ล้างคำตอบของรอบ)
        self._l1_after_prompt = False    # ★ rc1 S5 ตัวจับเวลาล้างคำตอบทำงานระหว่างกล่องเปิด ⇒ ล้างหลังกล่องปิด
        self._l1_pass_armed = False      # ★ rc1 S5 ตั้งตัวจับเวลาล้าง _l1_pass แล้ว (ตั้งครั้งเดียวต่อรอบ)
        self._l1_rnd = None              # ★ rc2 (audit A4-02 · A4-03) สถานะของรอบบันทึก (_l1_round · ล้างพร้อม _l1_pass)
        self._user_picked = False        # ผู้ใช้สลับชั้นเอง -> อย่าไปเลือกให้ใหม่ทับ
        self._refreshing = False         # กัน setCurrentIndex ของโค้ดเราเองไปนับเป็น "ผู้ใช้เลือก"
        # ★ 2.3.7 (review DI-02) — ชั้นที่ผู้ใช้ "เลือกเอง" รายช่อง [แปลง, หมุด] = (layer id, ที่มาของชั้น) | None
        #   เดิมธงเดียว _user_picked รวมสองช่องและติดค้างทั้งเซสชัน ⇒ เปลี่ยนอำเภอแล้วคอมโบค้างคู่ชั้นตัวแทน (LandsMaps_/CT_)
        self._pick = [None, None]
        self._layers_loading = False      # ระหว่างอ่านไฟล์โปรเจกต์ (loadingLayer → readProject) — สร้างคอมโบครั้งเดียวหลังโหลดเสร็จ
        self._layers_settle_pending = False
        # ★ 31 ส.ค. 69 — คิวล็อกการเปลี่ยน Type รอเขียนตอน commit สำเร็จจริง
        #   (trigger log_move เขียนล็อกให้ชั้นแปลงเฉพาะตอน geom เปลี่ยน · trg_audit_polygon
        #    เขียนเฉพาะตอน SCORE/geom เปลี่ยน -> เปลี่ยน Type อย่างเดียวไม่ถูกบันทึกที่ไหนเลย)
        self._pending_type_log = []

    def initGui(self):
        """★ 2.3.7 (audit LIFE-04) — ห่อ _init_gui: ล้มกลางทาง ⇒ unload() เก็บของที่สร้างไปแล้ว (ไอคอน · คีย์ลัด · คีย์ Undo ที่ยึด ·
        signal) ก่อนโยน error ต่อให้ QGIS · QGIS (qgis.utils.startPlugin) ทิ้ง instance ที่ initGui ล้มโดยไม่เรียก unload ให้
        ⇒ เดิมรุ่นที่ล้มทิ้ง Ctrl+Z ซ้อน 2 ตัว (ไม่ทำงานทั้งคู่ + TypeError ทุกครั้งที่กด) และไอคอน 2 อันไว้หลังคืนรุ่นเดิม"""
        try:
            self._init_gui()
        except Exception:
            _log_exc("initGui ล้ม — เก็บของที่สร้างไปแล้วก่อนแจ้ง QGIS")
            try:
                self.unload()
            except Exception:
                _log_exc("initGui ล้ม: unload เก็บของไม่สำเร็จ")
            raise

    def _init_gui(self):
        self._pg_timeout_recover()       # ★ rc1 (F4 · review B2-01) ค่าตั้ง default_timeout ที่ค้างจาก QGIS ดับระหว่างถามสิทธิ์
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        # ★ 2.3.7 b17 (audit R2-LIFE-01) — ห้ามตั้ง objectName ให้ action นี้: QAction ที่ไม่มีชื่อ QGIS เก็บคีย์ลัดไว้ใต้ "ข้อความ"
        #   (shortcuts/Multi-Layer Edit Pro — คีย์ลัดที่ผู้ใช้ผูกกับปุ่มนี้ไว้ตั้งแต่ 2.3.6 อยู่ที่นี่) · มีชื่อ ⇒ QGIS ≥3.30 ย้ายไปใช้
        #   objectName ⇒ คีย์ลัดเดิมหายหลังอัปเดต (ผู้ตรวจยืนยันบน 3.44.7) · ปัญหาคีย์ '/shortcuts/' ร่วมกันเป็นของ QShortcut ที่ไม่มีชื่อ
        #   เท่านั้น (QShortcut ไม่มีข้อความ ⇒ ตั้งชื่อ MLEP_sc_* ใน _load_shortcuts) · ป้ายของ MLEP (LIFE-04) ไม่ต้องใช้ชื่อ
        self._tag_own(self.action)
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)
        # ★ ผูก shortcut ตั้งแต่โหลดปลั๊กอิน — เดิมผูกเฉพาะตอนเปิดหน้าต่าง (create_dialog)
        #   ★ 2.3.7 b13 (UX-03) — คีย์ Undo ของ QGIS ถูกยึดเฉพาะตอนปลั๊กอินโหลดอยู่ (_undo_capture ใน _load_shortcuts)
        #   ⇒ ต้องผูกคีย์ของปลั๊กอินตั้งแต่ตอนนี้ ไม่งั้นหลังเปิด QGIS Ctrl+Z ไม่ทำอะไรจนกว่าจะเปิดหน้าต่าง MLEP
        try:
            self._load_shortcuts()
        except Exception:
            pass
        # ★ 2.3.7 b13 (UX-03) — ตอนเปิด QGIS ปลั๊กอินอาจโหลดก่อน QGIS ตั้งคีย์ลัดจากโปรไฟล์ (QgsShortcutsManager) ซึ่งตั้ง Ctrl+Z
        #   คืนให้ Undo ของ QGIS ทับที่ยึดไว้ ⇒ ยึดซ้ำเมื่อ QGIS เปิดเสร็จ (ไม่งั้นคีย์ชนกัน = Ctrl+Z เงียบทั้งคู่)
        try:
            self.iface.initializationCompleted.connect(self._on_qgis_ready)
        except Exception:
            pass
        # ★ โหมดผู้ดูแล: คีย์ลัดซ่อน (ไม่อยู่ในรายการตั้งค่า shortcut ที่พนักงานเห็น)
        #   กดสลับเข้า/ออก — ตัวล็อกจริงคือ "role ที่ต่อ DB ต้องเป็นสมาชิก mlep_admin/superuser"
        try:
            self._make_admin_sc()           # ★ 2.3.7 (audit LIFE-02) ชื่อเฉพาะ + ป้าย · สร้างใหม่ตอน QGIS เปิดเสร็จ (_on_qgis_ready)
        except Exception:
            pass
        # กันเงา/หมุดค้างจอ: ผู้ใช้กดเครื่องมืออื่นของ QGIS (Pan/Select) กลางคัน = เลิกใช้เครื่องมือเรา
        # แต่ไม่มีใครเก็บกวาดให้ (เส้นทางนี้ไม่ผ่าน cancel_transform) -> ดักที่ signal เปลี่ยนเครื่องมือ
        try:
            self.iface.mapCanvas().mapToolSet.connect(self._map_tool_changed)
        except Exception:
            pass
        # เปลี่ยน/เปิดโปรเจกต์ใหม่ต้องเก็บของ (ชั้นของโปรเจกต์เก่าไม่ควรตามไป)
        # ★ ต้องลอง aboutToBeCleared ก่อน — มันยิง "ก่อน" โปรเจกต์ถูกล้าง จึงยังเอาชั้นออกทัน
        #   ส่วน cleared ยิง "หลัง" ล้างเสร็จแล้ว = สายเกินไป (ใช้เป็นตัวสำรองเท่านั้น)
        for signame in ("aboutToBeCleared", "cleared"):
            try:
                getattr(QgsProject.instance(), signame).connect(self._on_project_reset)
                break
            except Exception:
                continue
        # ★★ 2 ก.ย. 69 — กวาด "ชั้นผี" ที่เคยหลุดติดไฟล์โปรเจกต์ไปแล้ว
        #   รุ่นก่อนหน้ามีช่องที่ทำให้ชั้นเส้นถูกเขียนฝังลง <อำเภอ>_V3.qgz ได้ (กด Ctrl+S
        #   ขณะหน้าต่างวาดเส้นเปิดอยู่) และสะสมเพิ่มทุกครั้งที่บันทึก โดยไม่มีอะไรลบมันเลย
        #   ⇒ ต้องมีตัวกวาดตอนเปิดโปรเจกต์
        #   (ชั้นผีที่โหลดกลับมาว่างเปล่าและอ่านอย่างเดียว จึงไม่ทำข้อมูลผิด แต่รกสารบัญ)
        #   ⚠️ ตัวกวาดนี้ลบ "ในหน่วยความจำ" อย่างเดียว และตั้งใจคืนค่า isDirty ด้วย
        #      ⇒ ไฟล์บนดิสก์ยังมีผีอยู่จนกว่าจะมีใครกดบันทึก (แล้วตอนนั้นจะได้ไฟล์สะอาด)
        #      จงใจไม่เขียนไฟล์กลางของอำเภอเองโดยพนักงานไม่ได้สั่ง
        try:
            QgsProject.instance().readProject.connect(self._on_project_read)
        except Exception:
            pass
        try:    # จำพาธของโปรเจกต์ที่เปิดอยู่ตอนโหลดปลั๊กอิน เป็นจุดตั้งต้นของการเทียบ
            self._line_project_path = QgsProject.instance().fileName()
        except Exception:
            self._line_project_path = None
        # ★★ 2 ก.ย. 69 — ธง "instance นี้ยังมีชีวิตอยู่"
        #   งานที่เลื่อนด้วย QTimer (กวาดชั้นผี / ตัดสินเปลี่ยนอำเภอ / จำพาธ) อาจยิงหลัง unload
        #   ⇒ instance เก่าที่ตายแล้วจะไปลบ "ชั้นเส้น" ของ instance ใหม่ทิ้ง
        #     (เกิดจริงตอนปลั๊กอินอัปเดตตัวเอง/reload กลางเซสชัน · ทำซ้ำได้ 2/2)
        #   ยกเลิก QTimer.singleShot ทีหลังไม่ได้ จึงต้องให้สล็อตตรวจธงนี้เองทุกตัว
        self._alive = True
        # ★★ 2 ก.ย. 69 — กัน "ตอนบันทึกโปรเจกต์" (Ctrl+S / Save As / บันทึกตอนปิด)
        #   นี่คือช่องที่ทำให้ชั้นเส้นหลุดลงไฟล์กลางของอำเภอตั้งแต่แรก
        #   วิธี: พอ QGIS กำลังจะเขียนไฟล์ ให้ถอดชั้นออกจากโปรเจกต์ก่อน แล้วสร้างคืนหลังเขียนเสร็จ
        try:
            QgsProject.instance().writeProject.connect(self._on_project_write)
            QgsProject.instance().projectSaved.connect(self._on_project_saved)
        except Exception:
            # ★ 2.4.0 (review ER-09) — ต่อไม่ได้ = ไม่มีใครตัดชั้นเส้น/จุดวัดระยะออกตอนบันทึกเลยทั้งเซสชัน
            _log_exc("initGui: ต่อสัญญาณ writeProject/projectSaved ไม่สำเร็จ — ชั้นเส้น/จุดวัดระยะจะติดลงไฟล์โปรเจกต์",
                     Qgis.Critical, once_key="ER-09:connect")
            self._qgz_leftover_warn("ปลั๊กอินเตรียมการกันชั้นชั่วคราวของหน้าต่างวาดเส้นติดลงไฟล์โปรเจกต์ไม่สำเร็จ"
                                    " — ปิดหน้าต่างวาดเส้นก่อนบันทึกโปรเจกต์ทุกครั้ง")
        # ★ 2.3.7 (review DI-19) — File > New ไม่มี readProject ตามมา ⇒ ปลดธงสลับโปรเจกต์ที่นี่
        #   (ไม่ล้างพาธที่จำไว้ · ไม่ทิ้งเส้น — New แล้วเปิดไฟล์เดิมกลับมา เส้นต้องยังอยู่)
        try:
            self.iface.newProjectCreated.connect(self._on_new_project)
        except Exception:
            pass
        # ★ 2.4.0 (review DI-11) — ด่านล็อก L1 ของปุ่มบันทึก QGIS ต้องทำงานตั้งแต่เปิดโปรเจกต์ ไม่ใช่หลังเปิดแผงปลั๊กอินครั้งแรก
        #   (เดิม hook beforeCommitChanges ต่อเฉพาะชั้นในคอมโบ ซึ่งสร้างตอนกดไอคอน ⇒ เปิด QGIS แล้วแก้แปลง L1 ด้วย Vertex Tool
        #   + Save ก่อนกดไอคอน = บันทึกเงียบ · โหลดปลั๊กอินใหม่/อัปเดตตัวเองก็เหมือนกัน) ⇒ เฝ้าชั้นทำงานทุกชั้นเมื่อมีชั้นเพิ่ม
        #   + หลังเปิดโปรเจกต์ (_on_project_read) + ตอนนี้ (ปลั๊กอินโหลดตอนโปรเจกต์เปิดอยู่แล้ว) — ดู _l1_arm_all · unload ถอดคู่กัน
        try:
            QgsProject.instance().layersAdded.connect(self._l1_arm_soon)
            self._signal_conns.append((None, "layersAdded", self._l1_arm_soon))
        except Exception:
            pass
        self._l1_arm_soon()
        # ★ 2.4.0 (review DI-03) — ตัวแปลงพิกัดจุดคลิก (_m2l_cache) ผูกกับ datum transformation ของโปรเจกต์ตอนสร้าง
        #   ⇒ เปลี่ยนระบบพิกัด/วิธีแปลง datum ของโปรเจกต์ (Project Properties) = ทิ้งตัวแปลงเก่า (unload ถอดคู่กัน)
        for _sig in ("crsChanged", "transformContextChanged"):
            try:
                getattr(QgsProject.instance(), _sig).connect(self._m2l_cache_drop)
            except Exception:
                pass
        # ★ 2.3.7 (audit LIFE-05) — สำเนาอัปเดตแบบเดิมใน plugins/ (.mlep_prev · .mlep_failed · .mlep_upd_*) ⇒ ย้ายไป mlep_backup/
        #   บน Windows ตัวจัดการปลั๊กอินเห็นเป็นปลั๊กอินซ้ำ/เสีย · ไม่มีของค้าง = ตรวจ 2-3 path แล้วจบ (ไม่แตะไฟล์)
        try:
            _here = os.path.dirname(__file__)
            _mv = _upd_migrate_legacy(os.path.dirname(_here), os.path.basename(_here))
            if _mv:
                QgsMessageLog.logMessage("ย้าย/ลบสำเนาอัปเดตแบบเดิมออกจากโฟลเดอร์ปลั๊กอิน: " + " · ".join(_mv),
                                         "MLEP", Qgis.Info)
        except Exception:
            pass

    def unload(self):
        # ★ ปลดธงก่อนอย่างอื่นทั้งหมด — งานที่ค้างอยู่ในคิว QTimer จะได้ไม่ทำงานต่อ
        self._alive = False
        # ★ 2.4.2 rc4 (ผลตรวจ Windows rc3 ข้อพบ 8) — ปิด/อัปเดต/reload ปลั๊กอิน ⇒ ออกจากระบบกรม: ลืมชื่อ/รหัสที่จำไว้ในหน่วยความจำ
        #   + ปิดเซสชัน (เดิมค้างจนปิด QGIS · rc3 ใช้รหัสที่จำไว้ซ้ำจาก 🔍/📝 ด้วย)
        try:
            from . import dol_api
            dol_api.logout()
        except Exception:
            pass
        # ★ rc2 (audit A5-05 + ผู้ตรวจทานพบเพิ่ม) — คืน allowCommit ของชั้นที่ด่าน L1/รอบบันทึกระงับไว้ "ทันที" ไม่พึ่งตัวจับเวลา
        #   (เดิม _l1_blocked ค้างตอน unload ⇒ ชั้นนั้นค้าง False · instance ใหม่ถือว่าเป็นของเจ้าของอื่น ไม่คืนให้ = บันทึกชั้นนั้นไม่ได้
        #   จนปิด QGIS) · กล่องด่าน L1 ที่ยังเปิดค้าง (_l1_prompting) ไม่ใช่เหตุให้เลื่อนแล้ว — instance นี้กำลังจะหายไป
        try:
            self._l1_prompting = 0
            self._l1_after_prompt = False
            self._l1_release()
        except Exception:
            pass
        try:
            _bt = getattr(self, "_locked_bg_task", None)       # ★ rc2 (audit A4-10) งานอ่านรายการแปลง L1 เบื้องหลัง
            if _bt is not None:
                _bt.cancel()
        except Exception:
            pass
        try:
            self._donut_clear_bands()      # 2.3.1 — กันไฮไลต์ส้มค้างข้ามการ reload
        except Exception:
            pass
        try:
            self._bar_items_pop()          # ★ 2.3.7 (audit LIFE-08) แถบข้อความที่มีปุ่ม/ค้างจนกดปิด ของ instance นี้
        except Exception:
            pass
        try:
            self._pair_hl_reset()          # ★ 2.4.0 (review UX-09) เครื่องหมาย/แถบ "จุดที่ต้องแก้" + ตัวดัก Esc บนแผนที่
            self._pair_hl_filter = None
        except Exception:
            pass
        # ★ getattr — เผื่อ unload ถูกเรียกก่อน initGui (reload กลางคันตอนพัฒนา / ฮาร์เนสทดสอบ)
        _act = getattr(self, 'action', None)
        if _act:
            self.iface.removeToolBarIcon(_act)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", _act)
            # ★★ 2.3.3 (23 ก.ย. 69 · ผู้ตรวจ Windows ชี้) — ทำลาย QAction ด้วย
            #   removeToolBarIcon/removePluginMenu เอาออกจากแถบ+เมนูแล้ว
            #   แต่ object ยังผูกกับ mainWindow() อยู่ ⇒ reload ทีไร QAction งอกขึ้น
            #   (วัดได้ 2 → 4 → 6) · ผู้ใช้ไม่เห็น เมนู/แถบคงที่ 1 ตลอด
            #   แต่เป็นหน่วยความจำที่ไม่ถูกคืน — ใช้ท่าเดียวกับ `_admin_sc` ข้างล่าง
            try:
                _act.triggered.disconnect()
            except Exception:
                pass
            try:
                _act.setParent(None)
                _act.deleteLater()
            except Exception:
                pass
            self.action = None
        try:
            self.iface.mapCanvas().mapToolSet.disconnect(self._map_tool_changed)
        except Exception:
            pass
        # ★★ 3 ก.ย. 69 — ทิ้งคีย์ลัดแอดมินด้วย เดิมสร้างใน initGui แต่ไม่เคยทำลาย
        #   ⇒ reload ปลั๊กอิน (Plugin Manager / Plugin Reloader / หลัง self-update)
        #     จะมี QShortcut ของ Ctrl+Shift+F12 ค้างอยู่สองตัวบนหน้าต่างหลัก
        #     Qt ถือเป็น "ambiguous shortcut" แล้วเลิกยิงทั้งคู่ = โหมดแอดมินเปิดไม่ได้
        #     จนกว่าจะปิด-เปิด QGIS ใหม่ (วัดได้: ก่อน reload 1 ตัว หลัง reload 2 ตัว)
        _sc = getattr(self, "_admin_sc", None)
        if _sc is not None:
            _qobj_dispose(_sc)              # ★ 2.3.7 (audit LIFE-02) ปิด · ตัด signal · ถอดจาก QgsShortcutsManager · ลบ
            self._admin_sc = None
        # ★ 2.3.7 rc3 (เจ้าของงานสั่ง 4 ต.ค.: คีย์ลัดโหมดผู้ดูแล) — ทิ้งคีย์ลัดของปุ่มโหมดพิเศษ (ปกติทิ้งไปแล้วตอนปิดแผง = ออกจากโหมด
        #   แต่ unload อาจมาตอนยังอยู่ในโหมด เช่นอัปเดตตัวเอง/โหลดปลั๊กอินใหม่) ⇒ instance ใหม่ไม่มีคีย์ค้างแย่งคีย์ของพนักงาน
        try:
            self._drop_admin_shortcuts()
        except Exception:
            pass
        # หยุดตัวเตือนงานค้าง (กัน timer ยิงเข้า instance เก่าหลัง unload/self-update)
        _t = getattr(self, "_nag_timer", None)
        if _t is not None:
            try:
                _t.stop(); _t.deleteLater()
            except Exception:
                pass
            self._nag_timer = None
        # ★ ปิดหน้าต่างปลั๊กอินด้วย — เดิมไม่ปิด ทำให้หลัง reload/self-update มี "หน้าต่างผี"
        #   ที่ปุ่มยังผูกกับ instance เก่า ค้างอยู่บนจอ
        if getattr(self, "dlg", None) is not None:
            try:
                self.dlg.close(); self.dlg.deleteLater()
            except Exception:
                pass
            self.dlg = None
        # ★ 2.3.7 — หน้าต่าง ℹ️ ข้อมูลแปลง (ไม่ modal · parent = หน้าต่างหลัก) ต้องปิด/ลบเอง ไม่งั้นค้างข้าม reload
        _idlg = getattr(self, "_info_dlg", None)
        if _idlg is not None:
            try:
                _idlg.close(); _idlg.deleteLater()
            except Exception:
                pass
            self._info_dlg = None
        # ★ 2 ก.ย. 69 — ต้องครอบ try ทั้งสามตัว
        #   ถ้าตัวใดโยน exception ตอน unload บล็อก "ตัดสัญญาณ" ข้างล่างจะไม่ได้ทำงานเลย
        #   ⇒ สล็อตของ instance ที่ตายแล้วยังค้างอยู่กับ QgsProject (โรค "หน้าต่างผี")
        #     และรอบนี้เพิ่งเพิ่มสล็อตที่ "สร้างเลเยอร์ได้" (projectSaved) เข้าไปในชุดนั้นด้วย
        # ★ 2.3.7 (review LC-03d) — + หมุด/เส้นนำของ Align + ตัวบอก snap (เดิมค้างบนแผนที่ข้าม reload)
        for _fn in (self.clear_markers, self._preview_clear, self._dol_clear_highlight,
                    self._align_clear_highlight, self.clear_rubber_band, self._clear_snap_indicator):
            try:
                _fn()
            except Exception:
                pass
        # แผงวาดเส้น: เก็บของบนแคนวาส ปิด dock และคืนค่า snapping ที่ยืมไว้
        try:
            self._line_cleanup()
        except Exception:
            pass
        # ★ ตัด signal ของโปรเจกต์ทุกเส้น — ถ้าไม่ตัด ทุกครั้งที่ปลั๊กอินอัปเดตตัวเอง/reload
        #   สล็อตของ instance เก่าจะยังถูกเรียกอยู่ (โรคเดียวกับ "หน้าต่างผี" ที่แก้ไป 31 ส.ค.)
        for _sig in ("aboutToBeCleared", "cleared"):
            try:
                getattr(QgsProject.instance(), _sig).disconnect(self._on_project_reset)
            except Exception:
                pass
        try:
            QgsProject.instance().readProject.disconnect(self._on_project_read)
        except Exception:
            pass
        for _sig, _slot in (("writeProject", self._on_project_write),
                            ("projectSaved", self._on_project_saved)):
            try:
                getattr(QgsProject.instance(), _sig).disconnect(_slot)
            except Exception:
                pass
        try:
            self.iface.newProjectCreated.disconnect(self._on_new_project)      # ★ 2.3.7 (review DI-19)
        except Exception:
            pass
        for _sig in ("crsChanged", "transformContextChanged"):                  # ★ 2.4.0 (review DI-03)
            try:
                getattr(QgsProject.instance(), _sig).disconnect(self._m2l_cache_drop)
            except Exception:
                pass
        for sc in getattr(self, "_shortcuts", []):
            _qobj_dispose(sc)               # ★ 2.3.7 (audit LIFE-02) ปิด · ตัด signal · ถอดจาก QgsShortcutsManager · ลบ
        self._shortcuts = []
        # ★ 2.3.7 b13 (review UX-03 ทาง ข) — คืนคีย์ Undo ให้ QGIS (ถอด/ปิด/ถอนปลั๊กอิน · อัปเดตตัวเองจะยึดใหม่ตอน initGui)
        try:
            self.iface.initializationCompleted.disconnect(self._on_qgis_ready)
        except Exception:
            pass
        self._undo_release()
        # ตัด signal commit/rollback ที่ต่อไว้ (กัน slot ทำงานหลัง unload)
        # 🔴 ต้องหาตัวเจ้าของ signal "สด" ทุกครั้ง — ห้ามเก็บตัว signal ไว้ใช้ทีหลัง
        #    เลเยอร์ที่ถูกลบไปแล้ว วัตถุ C++ ตายไปด้วย การแตะ signal ของมัน = SIGSEGV
        #    ที่ try/except ดักไม่ได้ (ดูเหตุผลเต็มที่ตอนประกาศ _signal_conns)
        _prj = QgsProject.instance()
        for _lid, _sname, _slot in getattr(self, "_signal_conns", []):
            try:
                _owner = (_prj if _lid is None else _prj.layerTreeRoot() if _lid == "__tree__"      # ★ rc5 ⚪1 แผงชั้น
                          else _prj.mapLayer(_lid))
                if _owner is None:
                    continue                 # เลเยอร์ถูกลบไปแล้ว — signal ตายไปกับมัน
                _sig = getattr(_owner, _sname, None)
                if _sig is None:
                    continue
                _sig.disconnect(_slot)
            except Exception:
                pass
        self._signal_conns = []
        self._signal_layers = {}   # {layer id: id(object)} ดู _watch_layer_editing
        # ★ 2.3.7 (review LC-03c) — ถอดเครื่องมือของปลั๊กอิน "ทุกตัว" ที่ค้างบนแคนวาส (เดิมเฉพาะตัวที่ == temp_tool ⇒ เครื่องมือ
        #   ที่ _line_restore_tool คืนให้ค้างอยู่พร้อม instance เก่า) · ยังคืนเครื่องมือมาตรฐานให้เหมือนเดิม (ดู _drop_plugin_tool)
        #   ลำดับเดิมคงไว้: _alive=False ก่อน · ถอด mapToolSet ก่อนถอดเครื่องมือ · เครื่องมือมาตรฐานท้ายสุด
        try:
            self._drop_plugin_tool()
        except Exception:
            pass
        # ★ rc2 (audit A2-04) — เครื่องมือของปลั๊กอินทุกตัวที่ยังเป็นลูกของแคนวาส (ไม่ได้ใช้งาน) ⇒ ลบ
        #   (ถือ self.plugin / bound method ของอินสแตนซ์นี้ ⇒ ค้างอยู่ = อินสแตนซ์เก่าไม่ถูกเก็บกวาดหลังตัวอัปเดตโหลดใหม่)
        try:
            from qgis.gui import QgsMapTool as _QMT
            _c = self.iface.mapCanvas()
            if _c is not None:
                for _t in _c.findChildren(_QMT):
                    if _c.mapTool() is not _t and self._is_plugin_tool(_t):
                        _t.deleteLater()
            self._temp_tool_obj = None
            for _n in ("_line_prev_tool", "_xform_tool", "_align_tool"):
                if hasattr(self, _n):
                    setattr(self, _n, None)
        except Exception:
            pass

    ADDNODE_MAX_DIST = 2.0        # เมตร: ระยะสูงสุดจากจุดที่คลิกถึงขอบแปลง ที่ยอมให้แทรกมุมได้
    ADDNODE_FAR_MUPP = 0.5        # ★ rc2 (audit A1-02) ผู้ช่วย/ผู้ดูแลซูมออกเกินนี้ (ม./px) + ห่างขอบเกิน ADDNODE_MAX_DIST ⇒ ถามก่อน
    ALIGN_MAX_PICK  = 800         # จำนวนหมุดสูงสุดที่เลือกด้วยกล่องใน Align (เท่ากับ Move Node)

    # ============ เตือนงานค้างยังไม่บันทึก (ไม่บล็อก) ============
    UNSAVED_NAG_MIN = 10.0        # เตือนเมื่อค้างเกินกี่นาที (แล้วเตือนซ้ำทุกช่วงเท่านี้)

    def run(self):
        if self.dlg is None:
            self.create_dialog()
        # ★ 2.3.7 (review UX-24) — หน้าต่างเปิดอยู่แล้วแต่ถูกย่อ/ถูกตารางข้อมูลหรือหน้าต่างอื่นบัง ⇒ เดิมกดไอคอนแล้ว
        #   ไม่มีอะไรเกิดขึ้นเลย (ดูเหมือนค้าง) ⇒ คืนขนาดถ้าย่ออยู่ แล้วยกขึ้นหน้าสุด + ให้โฟกัส
        try:
            if self.dlg.isMinimized():
                self.dlg.showNormal()
        except Exception:
            pass
        self.dlg.show()
        try:
            self.dlg.raise_()
            self.dlg.activateWindow()
        except Exception:
            pass
        self._start_unsaved_watch()
        # ★ กันคีย์แอดมินว่าง (2026-08-03): QShortcut ที่สร้างตอน initGui บางเครื่องได้ key ว่าง เพราะ
        #   main window ยังไม่พร้อมตอน QGIS เพิ่งเปิด -> Ctrl+Shift+F12 เลยไม่ยิง. setKey ซ้ำตอนเปิด
        #   หน้าต่างปลั๊กอิน (ถึงตอนนี้ทุกอย่างพร้อมแล้ว) ให้คีย์ผูกติดแน่นอน. (headless พิสูจน์ว่าคีย์นี้ใช้ได้)
        try:
            _asc = getattr(self, "_admin_sc", None)
            if _asc is not None and not _asc.key().toString():
                _asc.setKey(QtGui.QKeySequence("Ctrl+Shift+F12"))
                _asc.setEnabled(True)
        except Exception:
            pass
        self._check_transaction_mode()
        self._show_whats_new()
        self._auto_check_update()   # เช็คของใหม่ให้เอง ครั้งเดียวต่อการเปิด QGIS

    # ============ ★ 2.3.7 b13 (review UX-03 ทาง ข) คีย์ Undo: ยึดจาก QGIS เฉพาะตอนปลั๊กอินโหลดอยู่ ============
    #   เจ้าของงานตัดสิน 3 ต.ค. 69: MLEP ใช้ Ctrl+Z ทั้งแอปเฉพาะตอนโหลดอยู่ (คงคีย์ลัดแบบ ApplicationShortcut — กดบนแผนที่ก็ได้)
    #   ถอด/ปิด/ถอนปลั๊กอิน ⇒ Undo ของ QGIS ได้คีย์คืน · ไม่เขียนการยึดลงโปรไฟล์ QGIS อีก (ทำที่ตัว QAction ตรง ๆ)
    #   อัปเดตตัวเอง (unload → initGui ในเซสชันเดียว) = คืนแล้วยึดใหม่ · DI-25 (วัดระยะ = ถอยจุด) อยู่ใน _guarded เหมือนเดิม
    _UNDO_LEGACY_KEY = "MultiLayerEditPro/ShortcutUndoInit"     # ธงของ 2.3.5/2.3.6 = "ปลดคีย์ Undo ของ QGIS ถาวรแล้ว"
    # ★ 2.3.7 rc3 (Windows audit 🟡3 · เจ้าของงานตัดสิน 4 ต.ค. 69) — ธงของ GPKG_Editor (1.5.1) = ปลด Ctrl+Z ของ QGIS ถาวรแล้ว
    #   และใช้ Ctrl+Z เอง (QShortcut ทั้งแอป) ⇒ มีธงนี้ = ไม่ซ่อมคีย์ Undo ของ QGIS (ซ่อมแล้ว GPKG_Editor ที่เปิดลำพังกด Ctrl+Z
    #   ไม่ได้เลย — ชนกับ Undo ของ QGIS เงียบ ๆ) · GPKG_Editor จะแก้ฝั่งตัวเองภายหลัง · ★ rc3 ไม่มีธงแต่คีย์ ↺ ของมัน = Ctrl+Z
    #   ก็เหมือนกัน (ฉาก W · _undo_gpkg_claim)
    _UNDO_GPKG_KEY = "GPKGEditor/ShortcutUndoInit"
    _UNDO_GPKG_UNDO = "GPKGEditor/Shortcut/undo"   # ★ rc3 (ฉาก W) คีย์ ↺ ของ GPKG_Editor — ดู _undo_gpkg_claim
    _UNDO_GPKG_PROP = "_mlep_undo_gpkg_logged"     # ป้ายบน QApplication = ลง Log เหตุที่ไม่ซ่อมแล้วใน session นี้ (ครั้งเดียว)

    def _own_undo_top(self):
        """★ 2.4.3 (review 🔴1) ชื่อชั้นที่ใช้งาน ถ้าคำสั่งบนสุดใน undo stack ของชั้นนั้นเป็นงานของปลั๊กอิน (_own_cmds) · ไม่ใช่ = None
        (Undo ของ QGIS ย้อน stack ของชั้นที่ใช้งาน) · ตรวจไม่ได้ = ถือว่าเป็นของปลั๊กอิน (ไม่ส่งต่อ)"""
        lyr = None
        try:
            lyr = self.iface.activeLayer()
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isEditable():
                return None
            st = lyr.undoStack()
            i = st.index()
            if i <= 0:
                return None
            c = st.command(i - 1)
            if c is None:
                return None
            from qgis.PyQt import sip as _sip
            own = self._own_cmds.get(lyr.id()) or {}
            _p = _sip.unwrapinstance(c)
            return lyr.name() if (_p in own and own[_p] == c.text()) else None
        except Exception:
            _log_exc("คีย์ Undo: ตรวจคำสั่งบนสุดของชั้นไม่สำเร็จ", once_key="_own_undo_top")
            try:
                return lyr.name() if lyr is not None else "ชั้นที่ใช้งาน"
            except Exception:
                return "ชั้นที่ใช้งาน"

    _RIVAL_PROP = "_mlep_undo_rival_warned"     # ★ b17 ป้ายบน QApplication = เตือนคีย์ชนแล้วใน session นี้ (อยู่ข้ามการโหลดปลั๊กอินใหม่)

    # ============ ★ 2.3.7 rc3 (เจ้าของงานสั่ง 4 ต.ค.: คีย์ลัดโหมดผู้ดูแล) ============
    #   ปุ่มที่มีเฉพาะในโหมดพิเศษ (กล่อง ADMIN ใน create_dialog) ตั้งคีย์ลัดได้ที่ ⌨ — เฉพาะตอนอยู่ในโหมด
    #   🔴 พนักงานต้องไม่เห็น/ไม่ได้ใช้: ไม่อยู่ในโหมด ⇒ ⌨ ไม่สร้างแถวเหล่านี้เลย (กล่องเหมือนเดิมทุกตัวอักษร) และไม่มี QShortcut ของมัน
    #      (สร้างตอนเข้าโหมด/บันทึก ⌨ ในโหมด · ทิ้งตอนออกจากโหมด/unload ⇒ ไม่แย่งคีย์ของพนักงานที่ใช้โปรไฟล์เดียวกัน)
    #   เก็บคนละกลุ่ม QSettings กับคีย์ของพนักงาน ⇒ บันทึก ⌨ ตอนไม่อยู่ในโหมด ไม่ลบ/ไม่เปลี่ยนคีย์ชุดนี้
    #   คีย์สลับโหมด (Ctrl+Shift+F12) ไม่อยู่ในชุดนี้ — ตั้งค่าไม่ได้เหมือนเดิม
    _ADMIN_SC_KEY = "MultiLayerEditPro/ShortcutMode/"
    _ADMIN_SC_NAME = "MLEP_scm_"        # objectName ของ QShortcut ชุดนี้ (ไม่ซ้ำกับ MLEP_sc_<id> ของพนักงาน)

    # ============ ชั้นสิทธิ์: พนักงาน / ผู้ช่วยผู้ดูแล / ผู้ดูแล ============
    #   ★ 2.3.0 — เจ้าของงานสั่งแบ่ง 3 ชั้น (18 ก.ย. 69) คู่กับ role ในฐานข้อมูล
    #     mlep_staff  ชั้น 0  งานปกติ · ลบ Node/แก้ชื่อหมุด "แบบจำกัด"
    #     mlep_mod    ชั้น 1  + ลบ Node แบบเต็ม · แก้ชื่อหมุดแบบเต็ม
    #     mlep_admin  ชั้น 2  + ลบแปลง · เปลี่ยน Type · มอบหมาย · ปลดล็อก L1
    #   🔴 เส้น mod↔staff บังคับที่ฐานไม่ได้ (ใช้สิทธิ์ตัวเดียวกัน — PostgreSQL แยก
    #      "ลบได้เฉพาะหมุดซ้อน" ออกจาก "ลบได้ทุกดวง" ไม่ได้) จึงเป็น **ราวกันตก/นโยบาย**
    #      ส่วนเส้น admin เป็นของจริง เพราะฐานไม่ให้ DELETE แปลง/UPDATE(Type)/UPDATE(NAME)
    #      ★ 2.4.0 (review DI-11) — ยกเว้น "ปลดล็อก L1" ซึ่งเป็นนโยบายแบบเดียวกับเส้น mod (พนักงานมี UPDATE(geom) ทั้งสองตาราง)
    #        ⇒ ด่านสุดท้ายฝั่งปลั๊กอินคือถามก่อนบันทึกเมื่องานค้างย้าย/ลบแปลงหรือหมุด L1 (_l1_commit_hits)
    TIER_STAFF, TIER_MOD, TIER_ADMIN = 0, 1, 2
    TIER_NAME = {0: "พนักงาน", 1: "ผู้ช่วยผู้ดูแล", 2: "ผู้ดูแล"}
    # ★ 2.4.0 (review DI-09-followup) — เพดานรอของคิวรีถามชั้นสิทธิ์ (รันบนเธรดหลัก ทุกครั้งที่ปลดล็อก L1/เข้าโหมด)
    #   ฐานล่ม/ค้าง/ช้า = QGIS ค้างไม่เกินราว ๆ นี้ แล้วไม่ปลดล็อก (fail-closed) แทนค้างตามค่าตั้งต้นของ QGIS (ต่อฐาน 30 วิ · คิวรีไม่มีเพดาน)
    _ROLE_CONNECT_TIMEOUT_S = 5     # libpq connect_timeout (ขั้นต่ำ 2 วิ · ต่อชื่อเครื่องที่มีหลายที่อยู่ = ต่อที่อยู่)
    _ROLE_STMT_TIMEOUT_MS = 5000    # statement_timeout ของคิวรีนี้คิวรีเดียว (SET LOCAL ⇒ ไม่ติดค้างในคอนเนกชันของ pool)
    # ★ 2.4.0 (review DI-09-followup) — เพดานฝั่งเครื่องเรา (วินาที) ครอบทั้งหมด: executeSql ใช้คอนเนกชันใน pool ของ QGIS ซ้ำได้
    #   (ชุดเดียวกับที่ชั้นแปลงใช้ดึงข้อมูล) ⇒ คอนเนกชันเดิมที่ฐาน/เครือข่ายเงียบไปกลางทาง ไม่ผ่าน connect_timeout
    #   และ statement_timeout (ฐานเป็นคนตัด) ⇒ รอในเธรดแยก เธรดหลักรอไม่เกินค่านี้ (ยาวกว่า 2 ชั้นแรกนิดหน่อย ให้ชั้นนั้นตอบเหตุผลก่อน)
    _ROLE_WAIT_S = 6.0
    # ★ rc1 2.4.0 (F8 · review B1-04) — ต่อ TCP ไปเครื่องฐานก่อน (เธรดหลัก ≤ ค่านี้) ⇒ ฐานปิด (20:20 ทุกวัน)/เครือข่ายหลุด = ตอบ None ทันที
    #   เดิมเธรดงานไปขอรหัสผ่านจาก QgsCredentials ซึ่งรอเธรดหลัก (ที่กำลังรอเธรดงาน) ⇒ QGIS ค้างครบ 6 วิ แล้วกล่อง Enter Credentials เด้งทีหลัง
    _ROLE_PROBE_S = 1.5
    # ★ rc1 2.4.0 (F8 · review B2-02) — เธรดถามสิทธิ์ที่ค้างเกินค่านี้ (วินาที) ⇒ ยอมถามใหม่ได้ (เดิมล็อกการถามซ้ำจน socket ตาย ต้องปิดเปิด QGIS)
    #   แต่เธรดค้างพร้อมกันไม่เกิน _ROLE_MAX_STUCK (แต่ละตัวถือคอนเนกชันของ pool ของ QGIS 1 ช่อง) · ครบแล้ว = บอกให้ปิดเปิด QGIS
    _ROLE_STUCK_RETRY_S = 20.0
    _ROLE_MAX_STUCK = 2
    # ★ rc2 (audit A4-10) — อายุของตาราง UTM แปลงล็อก (วินาที) ก่อนอ่านใหม่เบื้องหลัง (_locked_refresh_bg · ไม่ค้างหน้าจอ)
    _LOCK_TTL_S = 1200.0
    # ★ rc2 (audit A4-04) — คอลัมน์ที่ด่าน L1 ตอนบันทึกดู "การแก้ค่า" ของแปลง L1/หมุดล็อก (+ คอลัมน์ UTM · หมุด + BND_NAME)
    _L1_ATTR_COLS = ("SCORE", "Type", "UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO")
    # ★ rc2 (audit A5-01) — ถามสิทธิ์จากฐานไม่ได้ (ฐานเงียบ/เครือข่ายหลุด/เกินเพดาน) ⇒ พักถามชั้นนั้นกี่วินาที (ระหว่างนั้นตอบ None ทันที)
    _PERM_DOWN_S = 60.0
    # ★ rc1 2.4.0 (F7 · handoff §3.3 / §5.1 DI-13) — กล่อง "บันทึกไม่ได้/ไม่สำเร็จ" ที่ยังไม่มีชั้นใดลงฐานแนะนำให้ย้อนการแก้ค่านั้น
    #   (ปลอดภัย เพราะยังไม่มีอะไรลงฐาน) แต่ Undo ย้อนทีละขั้นจากงานล่าสุด ⇒ ต้องบอกว่าขั้นหลัง ๆ ของชั้นนั้นถูกย้อนไปด้วย
    _UNDO_LATER_WARN = ("⚠️ Undo ย้อนทีละขั้นจากงานล่าสุด — งานที่ทำหลังการแก้ไขนั้นบนชั้นเดียวกันจะถูกย้อนไปด้วย "
                        "(ถ้าไม่อยากเสียงานส่วนนั้น ให้ขอสิทธิ์เพิ่มแทน)")
    _PG_TO_FLAG = "MultiLayerEditPro/pgTimeoutPending"   # ★ rc1 (F4) ธง "ค่าเดิมของ default_timeout" ระหว่าง _pg_connect_timeout

    # ★★ 2.3.4 (23 ก.ย. 69 · เจ้าของงานสั่ง) — แปลง **L2-LM** คืออะไร
    #   = แปลงที่ **มีทะเบียน แต่ยังไม่มีในฐานเราเลย** (ไม่อยู่ทั้ง L1-RTK · L1-TS · L2-TS · L2-RO)
    #     จึงเติมรูปเข้ามาจาก LandsMaps
    #   ⇒ รูปและหมุดของชุดนี้ **ไม่ได้มาจากการรังวัด** เป็นของที่เติมให้เพื่อไม่ให้แปลงหาย
    #     จะแม่นเท่า L1/L2 ไม่ได้ และยังต้องให้พนักงานไล่จัดอีกมาก
    #   ⇒ เจ้าของงานให้ **พนักงานธรรมดาแก้ได้เต็มที่**: ลบหมุด · ลบมุมแปลง · แก้ชื่อหมุดที่มีชื่ออยู่แล้ว
    #     โดยไม่ต้องเปิดโหมดผู้ช่วยผู้ดูแล
    #   🔴 ผ่อนเฉพาะ "ด่านสิทธิ์" เท่านั้น — ด่านความสมบูรณ์ของรูป (วงเหลือ 3 มุม ฯลฯ)
    #     ยังทำงานเหมือนเดิมทุกกรณี · และ **ไม่แตะด่าน L1** (L2-LM ไม่ใช่ L1 อยู่แล้ว)
    LANDSMAPS_TYPES = ('L2-LM',)

    # ---------- ★ 2.4.2 E9 — 🔍 เนื้อที่ทะเบียนของกรมไม่ตรงกับ AREA ในฐาน ⇒ เด้งเตือน ----------
    #   เจ้าของงาน 20 ต.ค. 69: "อยากให้เวลากดค้นหาภาพลักษณ์แล้วเนื้อที่ทะเบียนไม่เหมือนในฐานของเรา อยากให้เด้ง popup เตือน
    #   และใส่ตามเนื้อที่จากทะเบียนที่ถูกได้ไหม" · คำตัดสิน: เตือนทุกกรณีที่ไม่เท่ากัน (รวม AREA ว่าง) · ใช้เฉพาะผลที่ยืนยันแปลงได้
    #   · ผู้ดูแล (โหมดผู้ดูแล + สิทธิ์แก้คอลัมน์) ใส่เนื้อที่ทะเบียนลงงานค้าง (กด 💾 ก่อนลงฐาน) · พนักงานเห็นเตือน + ใส่หมายเหตุให้ผู้ดูแล
    #   · ผลจากทะเบียน iLands ใช้เนื้อที่จากหน้ารายละเอียดแปลง (dol_api.lis_parcel_detail · คีย์ในหน้าตรงทุกท่อน)
    _E9_TITLE = "เนื้อที่ทะเบียนไม่ตรงกับในฐาน"
    _E9_REMARK = "เนื้อที่ทะเบียนไม่ตรงกรม"
    _E9_TOL = 0.01                        # ตร.ม. — ต่างไม่ถึงนี้ = เศษจากการปัด (AREA เก็บทศนิยม 2 ตำแหน่ง)

    # ชื่อชั้นที่ปลั๊กอิน "Line Draw & Measure (วาดเส้น & วัดระยะ)" สร้าง
    #   (CHK_Node-Topo-main/line_tools.py:39  LINE_LAYER_NAME)
    # ตัวมันเก็บชั้นด้วย layer id ภายในตัวเอง เราอ่านไม่ได้ -> จับด้วย "ชื่อชั้น"
    LINE_TOOL_LAYER = "เส้นที่วาด (Line)"
    LINE_TOOL_LABEL = "ระยะเส้น (Label)"      # ชั้นป้ายระยะ — ไม่ใช่เส้นจริง ไม่เอามา snap

    _XFORM_STEPS = {'move': ("จุดอ้างอิง", "จุดปลายทาง"),
                    'rotate': ("จุดหมุน", "จุดอ้างอิง", "จุดยืนยันมุม"),
                    'scale': ("จุดหมุน", "จุดอ้างอิง", "จุดยืนยันขนาด"),
                    'transform': ("ต้นทาง 1", "ปลายทาง 1", "ต้นทาง 2", "ปลายทาง 2")}

    _BAR_LEVEL = {0: "Info", 1: "Warning", 2: "Critical", 3: "Success"}

    # ---------- ★ 2.3.7 ตัวช่วยของเครื่องมือ attribute (Score · หมายเหตุ · Cluster · มอบหมาย · Audit · ล้าง Score) ----------
    _SHEET_COLS = ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "LANDNO")

    # ข้อความหมายเหตุที่พนักงานใช้บ่อย — ดึงจากค่าจริงในฐานข้อมูล (ปทุม+องครักษ์ รวม ~2,950 แถว)
    # ★ ที่ทำเป็นรายการให้เลือก เพราะของเดิมพิมพ์มือแล้วความหมายเดียวกันเขียนได้หลายแบบ
    #   ("ซ้อน RTK / ทับ RTK / ทับซ้อนกับ RTK / แปลงทับ RTK / แปลงซ้ำ RTK") ทำให้สรุปยอดทีหลังไม่ได้
    REMARK_PRESETS = [
        "ซ้อน RTK",
        "ซ้อน L1",
        "เนื้อที่ผิด",
        "เนื้อที่เกินเกณฑ์",
        "เนื้อที่ทะเบียนไม่ตรงกรม",        # ★ 2.4.2 E9 (= _E9_REMARK · 🔍 เตือนเนื้อที่ทะเบียนไม่ตรง)
        "ขึ้นรูปแปลงผิด",
        "หมุดไม่ครบ",
        "หมุดสลับตำแหน่ง",
        "แปลงพิพาท",
        "เป็น L1 แล้ว",
        "ไม่ได้ขึ้นรูปแปลงใบต่อ",
        "รอตรวจสอบ",
    ]

    REMARK_KEEP = "(ไม่เปลี่ยน)"     # ★ 2.3.7 (review DI-12) ตัวเลือกแรกเมื่อหมายเหตุเดิมไม่เหมือนกัน/ว่าง

    ASSIGN_BLANK = "(ว่าง — ยกเลิกการมอบหมาย)"

    AUDIT_PASS = "✅ ผ่าน — ยืนยันว่าแปลงนี้ใช้ได้"
    AUDIT_FAIL = "❌ ไม่ผ่าน — ให้กลับไปแก้"
    AUDIT_NONE = "(ว่าง — ยังไม่ตรวจ)"

    # ==================================================================
    #  วาดเส้น / วัดระยะ — หน้าต่างลอยแยกต่างหาก   ★ 31 ส.ค. 69
    # ==================================================================
    #  จัดกลุ่มตามหน้าต่างของปลั๊กอิน "วาดเส้น & วัดระยะ" เดิม เพื่อให้พนักงาน
    #  ที่เคยใช้อยู่แล้วไม่ต้องเรียนรู้ใหม่
    #
    #  ทำไมเป็นแคนวาสล้วน ไม่สร้างเลเยอร์:
    #    เส้นวัดระยะเป็นของชั่วคราวระหว่างทำงาน ไม่ใช่ข้อมูลที่ต้องส่งมอบ
    #    ถ้าสร้างเลเยอร์ในโปรเจกต์ โปรเจกต์จะกลายเป็น "มีการแก้ไข" ทันที
    #    -> ตอนปิด QGIS พนักงานจะโดนถามว่าจะบันทึกไหม แล้วเผลอกด Save
    #       ทับค่าที่ตั้งไว้ให้ทั้งทีม (ปัญหาเดียวกับที่เจอในปลั๊กอินวาดเส้นตัวเดิม)

    LINE_DOCK_TITLE = "วาดเส้น & วัดระยะ"

    # ★ 1 ก.ย. 69 — ชื่อชั้นของเราต้อง "ขึ้นต้นด้วย" LINE_TOOL_LAYER แต่ไม่ตรงเป๊ะ
    #   เพราะพนักงานบางคนยังใช้ปลั๊กอินวาดเส้นตัวเดิม (CHK_Node-Topo) ซึ่งสร้างชั้น
    #   ชื่อ "เส้นที่วาด (Line)" เป๊ะ ๆ อยู่แล้ว
    #   ถ้าใช้ชื่อเดียวกัน: ① เกิดสองชั้นชื่อซ้ำกันในสารบัญ พนักงานสับสน
    #                      ② เราอาจไปลบชั้นของปลั๊กอินตัวอื่นทิ้งตอนปิดหน้าต่าง
    #   _line_tool_layers ของ setup_snapping จับแบบ startswith อยู่แล้ว -> snap ยังติดเหมือนเดิม
    LINE_LAYER_NAME = "เส้นที่วาด (Line) — MLEP"
    # ★ 2.3.6 (25 ก.ย. 69 เจ้าของงานขอ) — "เครื่องมือวาดเส้นขอตัวกรอกค่าพิกัดแล้วขึ้น point ให้ด้วย"
    #   จุดที่กรอกเก็บใน **ชั้นจุดชั่วคราวแยกต่างหาก** (ชนิด geometry ต่างจากชั้นเส้น ใช้ชั้นเดียวกันไม่ได้)
    #   ได้กันชนชุดเดียวกับชั้นเส้นทุกข้อ: ไม่ติดไปกับไฟล์โปรเจกต์ (_on_project_write) ·
    #   ไม่ทำให้โปรเจกต์ขึ้นว่า "มีการแก้ไข" · ปิดหน้าต่าง = เอาชั้นออก · เปลี่ยนสาขา = ทิ้ง ·
    #   snap ติด (อยู่ใน _line_tool_layers) · ไม่เข้าลายเซ็นแม่เหล็ก (_snap_sig)
    LINE_PT_LAYER_NAME = "จุดที่กรอกพิกัด (Point) — MLEP"

    # ★ 2.3.7 (review DI-26) — ขีดจำกัด miter ของเส้นขนาน: มุมภายในแคบสุดที่ยังคม = 2·asin(1/10) ≈ 11.5°
    #   (เดิม 2.0 ⇒ มุมที่แหลมกว่า 60° ถูกตัดมุม ได้จุดเกินมา 1 จุดและมุมจริงหาย ทั้งที่ docstring สัญญาว่ามุมคม)
    LINE_OFFSET_MITRE = 10.0

    # ★ 2.3.7 rc3 (Windows audit 🔴1) — งานชั้นเส้นที่เลื่อนออกไป ลองใหม่ทุกเท่านี้ (มิลลิวินาที) ระหว่างรอกล่อง modal/เมนูปิด
    LINE_BUSY_RETRY_MS = 200

    def _nullgeom_points_to_delete(self, lid):
        """★ 2.4.2 E7 (เจ้าของงาน 15–16 ต.ค. 69: "ด่านในปลั๊กอิน" · ทำใน 2.4.2 rc2) — ก่อนลงฐาน: หมุดในงานค้างที่ "ไม่มีตำแหน่ง"
        ⇒ ลบหมุดนั้นจริงใน buffer (งานเดียวกับ Delete Selected) แทนการเขียน geom ว่างลงฐาน
        ที่มา: Vertex Tool ลบจุดเดียวของหมุด ⇒ QGIS เปลี่ยนรูปเป็นค่าว่าง (changeGeometry) ⇒ ลงฐานเป็น UPDATE geom = NULL
          (ฐานจริงสะสม 19,108 ดวง ลบไป 15 ต.ค. แล้วงอกใหม่ 77 ดวงในเช้า 16 ต.ค.) — หมุดว่างมองไม่เห็นบนแผนที่และทำให้ตัวนับ/ด่านเพี้ยน
        ขอบเขต: ชั้นหมุด (point) เท่านั้น · รูปที่แก้เป็นค่าว่าง + ฟีเจอร์ใหม่ที่ไม่มีรูป · ชั้นแปลงไม่แตะ
        ไม่มีสิทธิ์ DELETE (ฐานตอบ False) ⇒ ไม่ลบ (ลบไม่ได้ = การบันทึกจะล้มทั้งชุด) แต่บอกหลังบันทึก · ถามสิทธิ์ไม่ได้ (None) = ลบตามปกติ
        ชั้นใน transaction group (แก้ตรงลงฐาน ไม่มี buffer) ⇒ ไม่มีรายการให้ตรวจ = ไม่ทำอะไร
        คืน (ลบแล้ว, คงไว้เพราะไม่มีสิทธิ์)"""
        if not hasattr(self, "_pending_nullgeom"):
            self._pending_nullgeom = {}
        self._pending_nullgeom.pop(lid, None)
        lyr = QgsProject.instance().mapLayer(lid)
        if lyr is None or not lyr.isEditable() or self._geom_role(lyr) != 1:
            return (0, 0)
        buf = lyr.editBuffer()
        if buf is None:
            return (0, 0)

        def _empty(g):
            try:
                return g is None or g.isNull() or g.isEmpty()
            except Exception:
                return False
        bad = [fid for fid, g in buf.changedGeometries().items() if _empty(g)]
        bad += [fid for fid, f in buf.addedFeatures().items() if not f.hasGeometry() or _empty(f.geometry())]
        bad = list(dict.fromkeys(bad))
        # ★ 2.4.2 (audit rc3) — หมุดที่ด่านนี้ลบไปแล้วในการกดบันทึกครั้งก่อนที่ "ไม่สำเร็จ" (ยังถูกลบอยู่ในงานค้าง) ⇒ นับรวมในรายงาน
        #   เดิมรอบหลังหาไม่เจอแล้ว (ไม่อยู่ใน changedGeometries) ⇒ บันทึกผ่านแล้วไม่มีแถบ/กล่องบอกเลย
        if not hasattr(self, "_nullgeom_done"):
            self._nullgeom_done = {}
        prev = self._nullgeom_done.get(lid) or {}
        if prev:
            try:
                _gone, _added = set(buf.deletedFeatureIds()), buf.addedFeatures()
                prev = {fid: k for fid, k in prev.items() if (fid in _gone if fid >= 0 else fid not in _added)}
            except Exception:
                prev = {}
        if not bad and not prev:
            self._nullgeom_done.pop(lid, None)
            return (0, 0)
        if any(fid >= 0 for fid in bad) and self._can_table_priv(lyr, "DELETE") is False:
            keep = [fid for fid in bad if fid >= 0]       # แถวในฐานลบไม่ได้ · ฟีเจอร์ใหม่ (fid ติดลบ) ทิ้งได้ไม่ต้องใช้สิทธิ์
            bad = [fid for fid in bad if fid < 0]
        else:
            keep = []
        # ★ 2.4.2 E10 — เครื่องมือที่ทำให้หมุดเสียตำแหน่ง (จับไว้ตอนเกิด) → นับตามชื่อที่พนักงานรู้จัก · ไม่รู้ = ''
        #   หมุดใหม่ที่ไม่เคยมีตำแหน่ง (เพิ่มแถวโดยไม่มีรูป) = _E10_NEW
        seen = (getattr(self, "_nullgeom_tool", None) or {}).get(lid) or {}

        def _tool(fid):
            if fid in seen:
                return self._E10_TOOL_NAMES.get(seen.get(fid, ""), "")
            return self._E10_NEW if fid < 0 else ""
        done = []
        if bad:
            # ★ 2.4.2 (audit rc3) — ลบทั้งชุดเป็นคำสั่งเดียว (บันทึกไม่สำเร็จแล้ว Undo ทีเดียวได้หมุดคืนครบ)
            lyr.beginEditCommand("ลบหมุดที่ไม่มีตำแหน่ง")
            try:
                done = [fid for fid in bad if lyr.deleteFeature(fid)]
            finally:
                try:
                    (lyr.endEditCommand if done else lyr.destroyEditCommand)()
                except Exception:
                    pass
        allk = dict(prev)
        allk.update({fid: _tool(fid) for fid in done})
        self._nullgeom_done[lid] = allk
        n = len(allk)
        if n or keep:
            tools = {}
            for k in list(allk.values()) + [_tool(fid) for fid in keep]:
                tools[k] = tools.get(k, 0) + 1
            self._pending_nullgeom[lid] = (n, len(keep), tools)
            try:
                QgsMessageLog.logMessage("E7 หมุดไม่มีตำแหน่ง: ลบแทน %d · คงไว้ (ไม่มีสิทธิ์ลบ) %d · ชั้น %s · เครื่องมือ %s"
                                         % (n, len(keep), lyr.name(), tools), "MLEP", Qgis.Info)
            except Exception:
                pass
        return (n, len(keep))

    def _nullgeom_polys_to_delete(self, lid):
        """★ 2.4.10 (เจ้าของงาน 29 ต.ค. 69 "ขึ้นเตือนและลบออก" · ฐานจริงสะสมแปลงรูป NULL 25 แปลง — ลบแล้วเช้า 29 ต.ค.) ก่อนลงฐาน:
        แปลงในงานที่รูปว่าง (ลบจุดจนหมด · เพิ่มแถวโดยไม่มีรูป) ⇒ ลบแปลงนั้นใน buffer แบบหมุด E7 (คำสั่งเดียว 'ลบแปลงที่ไม่มีรูป' · Undo ได้)
        · บัญชีที่ลบแถวในฐานไม่ได้ (ไม่มีสิทธิ์ DELETE) ⇒ คืนรูปเดิมจากฐานแทน (ไม่ลงรูปว่าง) · หมุดของแปลงไม่แตะ ·
        กล่องเตือนหลังบันทึก (on_after_commit_nullgeom · _nullgeom_poly_text) -> (ลบ, คืนรูป)"""
        lyr = QgsProject.instance().mapLayer(lid)
        if lyr is None or not lyr.isEditable() or self._geom_role(lyr) != 0:
            return (0, 0)
        buf = lyr.editBuffer()
        if buf is None:
            return (0, 0)

        def _empty(g):
            try:
                return g is None or g.isNull() or g.isEmpty()
            except Exception:
                return False
        bad = [fid for fid, g in buf.changedGeometries().items() if _empty(g)]
        bad += [fid for fid, f in buf.addedFeatures().items() if not f.hasGeometry() or _empty(f.geometry())]
        bad = list(dict.fromkeys(bad))
        if not bad:
            return (0, 0)
        can_del = self._can_table_priv(lyr, "DELETE") is not False
        pu = self._resolve_field(lyr, _UTM_FIELD_NAMES)

        def _lab(fid):
            if fid < 0:
                return "แปลงใหม่ที่ยังไม่มีรูป"
            try:
                u = _txt(lyr.getFeature(fid)[pu]) if pu else ""
            except Exception:
                u = ""
            return f"gid {fid}" + (f" · UTM {u}" if u else "")
        gone, back, labs = [], [], []
        lyr.beginEditCommand("ลบแปลงที่ไม่มีรูป")
        try:
            for fid in bad:
                lab = _lab(fid)
                if fid < 0 or can_del:
                    if lyr.deleteFeature(fid):
                        gone.append(fid)
                        labs.append(lab)
                    continue
                _it = lyr.dataProvider().getFeatures(QgsFeatureRequest(fid))
                try:
                    f0 = next(_it, None)
                finally:
                    _it.close()
                g0 = f0.geometry() if f0 is not None and f0.hasGeometry() else None
                if g0 is not None and not g0.isEmpty() and lyr.changeGeometry(fid, g0):
                    back.append(fid)
                    labs.append(lab + " (คืนรูปเดิม)")
        finally:
            try:
                (lyr.endEditCommand if (gone or back) else lyr.destroyEditCommand)()
            except Exception:
                pass
        if gone or back:
            if not hasattr(self, "_pending_nullgeom"):
                self._pending_nullgeom = {}
            self._pending_nullgeom[lid] = (len(gone), len(back), {}, "แปลง", labs)
            try:
                QgsMessageLog.logMessage("2.4.10 แปลงไม่มีรูป: ลบ %d · คืนรูปเดิม (ไม่มีสิทธิ์ลบ) %d · ชั้น %s · %s"
                                         % (len(gone), len(back), lyr.name(), " / ".join(labs[:20])), "MLEP", Qgis.Info)
            except Exception:
                pass
        return (len(gone), len(back))

    def _nullgeom_poly_text(self, n_del, n_back, labs):
        """★ 2.4.10 (หัวกล่อง, ข้อความ) เตือนหลังบันทึกเมื่อพบแปลงที่ไม่มีรูป (_nullgeom_polys_to_delete)"""
        lines = [f"พบแปลงที่ไม่มีรูป {n_del + n_back:,} แปลง ในงานที่เพิ่งบันทึก (ลบจุดของแปลงจนหมด หรือเพิ่มแถวโดยไม่มีรูป)"]
        if n_del:
            lines.append(f"ปลั๊กอินลบแปลงที่ไม่มีรูป {n_del:,} แปลงให้แล้วก่อนลงฐาน (ไม่ลงแปลงว่าง)")
        if n_back:
            lines.append(f"⚠️ บัญชีนี้ไม่มีสิทธิ์ลบแปลง จึงคืนรูปเดิมให้ {n_back:,} แปลงแทน — ถ้าต้องการลบแปลงจริง แจ้งผู้ดูแล")
        if labs:
            lines += ["", "แปลงที่เกี่ยวข้อง:"] + [f"• {x}" for x in labs[:20]] + ([f"… อีก {len(labs) - 20:,} แปลง"] if len(labs) > 20 else [])
        lines += ["", "ครั้งต่อไป: ลบแปลง → เลือกแปลงแล้วกด Delete Selected · หมุดของแปลงที่ลบยังอยู่ (ลบเองถ้าไม่ใช้แล้ว)"]
        return "พบแปลงที่ไม่มีรูป", "\n".join(lines)

    # ★ 2.4.2 E10 — ชื่อคลาส C++ ของเครื่องมือบนแผนที่ (metaObject · ไม่ขึ้นกับภาษาของ QGIS) → ชื่อที่พนักงานเห็นในแถบเครื่องมือ
    _E10_TOOL_NAMES = {"QgsVertexTool": "Vertex Tool", "QgsMapToolDeletePart": "Delete Part"}
    _E10_NEW = "หมุดใหม่ที่ไม่มีตำแหน่ง"       # ★ audit rc3 — เพิ่มแถวหมุดโดยไม่มีรูป (ไม่ใช่การลบตำแหน่ง)

    def _map_tool_class(self):
        """★ 2.4.2 E10 — ชื่อคลาสของเครื่องมือบนแผนที่ที่ใช้อยู่ (เช่น 'QgsVertexTool') · ไม่รู้ = ''"""
        try:
            t = self.iface.mapCanvas().mapTool()
            return str(t.metaObject().className()) if t is not None else ""
        except Exception:
            return ""

    def _nullgeom_popup_text(self, n_del, n_keep, tools):
        """★ 2.4.2 E10 — (หัวกล่อง, ข้อความ) เตือนหลังบันทึกเมื่อพบหมุดที่ถูกลบตำแหน่ง · tools = {ชื่อเครื่องมือ: จำนวน} ('' = ไม่รู้)
        ข้อมูลฐานจริง 16–20 ต.ค. 69: 5,650 ดวง · 86% ลบมุมแปลงพร้อมหมุดในการบันทึกเดียวกัน · 11% หมุดซ้ำ · 97% หมุดของแปลง L2-LM"""
        n_all = n_del + n_keep
        vt = tools.get("Vertex Tool", 0)
        named = [f"{k} {v:,} จุด" for k, v in sorted(tools.items()) if k and v]
        stay = "(มองไม่เห็นบนแผนที่ และทำให้การตรวจหมุดกับมุมแปลงเพี้ยน)"
        if n_all and vt == n_all:
            title = "พบการใช้ Vertex Tool ลบหมุด"
            head = f"พบการใช้ Vertex Tool ลบจุดของหมุด {n_all:,} จุด ในงานที่เพิ่งบันทึก"
            why = f"Vertex Tool ลบได้แค่ตำแหน่งของหมุด — ถ้าปลั๊กอินไม่ลบให้ แถวหมุดจะค้างอยู่ในฐานแบบไม่มีตำแหน่ง {stay}"
        else:
            # ★ 2.4.2 (audit rc3) — ไม่ใช่ Vertex Tool ทั้งหมด ⇒ ไม่ฟันธงว่าเป็น Vertex Tool (บอกตามที่จับได้)
            new_all = bool(n_all) and tools.get(self._E10_NEW, 0) == n_all
            title = "พบหมุดใหม่ที่ไม่มีตำแหน่ง" if new_all else "พบหมุดที่ถูกลบตำแหน่ง"
            other = n_all - sum(v for k, v in tools.items() if k)
            head = ((f"พบหมุดใหม่ที่ไม่มีตำแหน่ง {n_all:,} จุด ในงานที่เพิ่งบันทึก" if new_all else
                     f"พบหมุดที่ถูกลบตำแหน่งออก {n_all:,} จุด ในงานที่เพิ่งบันทึก ")
                    + ("" if new_all else
                       f"({' · '.join(named + ([f'ไม่ทราบเครื่องมือ {other:,} จุด'] if other else []))})" if named
                       else "(มักเกิดจากใช้ Vertex Tool ของ QGIS ลบจุดของหมุด)"))
            why = f"หมุดที่ไม่มีตำแหน่ง — ถ้าปลั๊กอินไม่ลบให้ แถวหมุดจะค้างอยู่ในฐาน {stay}"
        lines = [head, why]
        if n_del:
            lines.append(f"ปลั๊กอินลบหมุดที่ไม่มีตำแหน่ง {n_del:,} จุดให้แล้วก่อนลงฐาน")
        if n_keep:
            lines.append(f"⚠️ บัญชีนี้ไม่มีสิทธิ์ลบหมุด จึงบันทึกเป็นหมุดไม่มีตำแหน่งไว้ {n_keep:,} จุด — แจ้งผู้ดูแลให้ลบ")
        lines += ["", "ครั้งต่อไป:",
                  "• ลบมุมแปลงพร้อมหมุด → ใช้ปุ่ม 🗑 ลบ Node ของปลั๊กอิน (แปลงที่ไม่ใช่ L2-LM ให้ผู้ช่วยผู้ดูแลลบให้)",
                  "• ลบเฉพาะหมุด → เลือกหมุดแล้วกด Delete Selected"]
        return title, "\n".join(lines)

    # ============ ★ 2.3.7 (review ER-06) แจ้งความล้มเหลวเป็นภาษาไทย ============
    _LOG_HINT = "รายละเอียดอยู่ในแผง Log Messages แท็บ MLEP"

    # ==================== 2.3.3 (22 ก.ย. 69) — จับเวลาด่านตรวจก่อนบันทึก ====================
    # 🔑 ที่มา: ตรวจโค้ด 22 ก.ย. พบว่าด่านนี้วิ่งบน UI thread ทุกครั้งที่กด 💾 (~96,000 ครั้ง/วัน)
    #    มีเพดาน 8 วินาที แต่ **ข้ามไปแล้วเงียบ ไม่มีร่องรอย** ⇒ ถ้ามันช้าจริง พนักงานจะเห็น QGIS
    #    ค้างตอนบันทึกแล้วฟื้นเอง = ตรงกับอาการ ① "ค้างแล้วฟื้น" ที่ยังหาต้นตอไม่เจอ
    #    ⇒ บันทึกเวลาไว้ แล้วเทียบกับ FREEZE-END ที่ Client_Collect เก็บอยู่แล้ว
    # 🔑 ไฟล์ลง C:\QGIS_Debug\logs\ **เฉพาะเครื่องที่มีโฟลเดอร์นี้อยู่แล้ว** (= ติดตั้งตัวเก็บแล้ว)
    #    ตัวเก็บคัดลอกทั้งโฟลเดอร์ logs ลงซิปอยู่แล้ว ⇒ ข้อมูลมาถึงเราเองโดยไม่ต้องแก้ตัวเก็บ
    #    เครื่องอื่นเขียนแค่แผง Log ของ QGIS · ไม่สร้างโฟลเดอร์ให้ใคร
    # 🔴 ห้ามทำให้การบันทึกล้ม — ทุกอย่างในนี้ห่อ try ทั้งหมด
    _PERF_SLOW_S = 0.3        # บันทึกลงไฟล์เมื่อใช้เวลาตั้งแต่เท่านี้ (หรือถูกข้าม)
    _PERF_WARN_S = 1.0        # ขึ้นเป็นคำเตือนในแผง Log เมื่อเกินเท่านี้
    _PERF_MAX_BYTES = 2000000 # ไฟล์ใหญ่เกินนี้ย้ายไปเป็น .1 (เก็บไว้รุ่นเดียว)
    _PERF_SKIP = ('skip-cap', 'skip-budget', 'skip-error')

    class _PairIssues(tuple):
        """★ 2.3.7 (review UX-39) ผลด่านจับคู่ = tuple 3 ค่าเดิม (bad, checked, sample) — ผู้เรียกเดิมแกะ 3 ค่าได้เหมือนเดิม
        + .kinds = นับแยกชนิด: missing (มุมไม่มีหมุด) · stacked (มุมมีหมุดซ้อน) · stray (จุดที่หมุดไม่อยู่บนมุม)
          · orphan (หมุดของแปลงที่ถูกลบ · DI-47) · near (มุมเปลือยที่มีหมุดแปลงเดียวกันลอยอยู่ ≤ 2 ม. · DI-48) · nokey
          (bad = missing + stacked + stray + orphan เสมอ)
        ★ 2.4.0 (review UX-09) — + .points = ทุกจุดที่นับใน bad (ไม่ใช่แค่ตัวอย่าง 5 จุดใน sample):
          [(ชนิด 'bare'/'stacked'/'stray'/'orphan', x, y, 'poly'/'point' = พิกัดของชั้นไหน, UTM)]
          · .crs = (CRS ชั้นแปลง, CRS ชั้นหมุด) — ไว้ทำเครื่องหมาย/พาไปดูบนแผนที่ (_pair_hl_offer)"""
        kinds = None
        points = ()
        crs = None

    _PAIR_NEAR_M = 2.0        # ★ 2.3.7 (DI-48) หมุดลอยห่างมุมเปลือยไม่เกินเท่านี้ = "หมุดของมุมนี้ที่เพี้ยนไป" (เท่าเพดาน Add Node)

    class _Busy:
        """★ 2.3.7 (review PF-03) — นาฬิกาทรายระหว่างงานข้อมูลบน UI thread ที่อาจนาน (สแกนแปลง L1 · เลือกตาม UTM ·
        ค้นหมุดของแปลง · ถามสิทธิ์จากฐาน) + จดเวลาเมื่อช้า (mlep_perf.log รูปแบบเดียวกับ save-check + แผง Log)
        ให้เห็นว่า "กำลังทำงาน" ไม่ใช่ "ค้าง" และให้เทียบกับ FREEZE-END ได้ · ไม่เปลี่ยนพฤติกรรมอื่น
        🔴 ห้ามมีกล่องข้อความ / QInputDialog / processEvents ข้างในบล็อก (cursor จะค้างทับกล่อง)
        ใช้ `with self._busy(tag):` หรือ `b = self._busy(tag).begin()` … `b.end()` ใน finally"""

        def __init__(self, plugin, tag):
            self.p, self.tag, self.on, self.t0, self.done = plugin, tag, False, 0.0, False

        def begin(self):
            try:
                QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
                self.on = True
            except Exception:
                self.on = False
            self.t0 = time.monotonic()
            return self

        def end(self):
            if self.done:
                return
            self.done = True
            if self.on:
                try:
                    QtWidgets.QApplication.restoreOverrideCursor()
                except Exception:
                    pass
            try:
                self.p._perf_slow(self.tag, time.monotonic() - self.t0)
            except Exception:
                pass

        def __enter__(self):
            return self.begin()

        def __exit__(self, *exc):
            self.end()
            return False

    # ★ 2.4.0 (review UX-09) — คำเตือนจับคู่สั่งให้ซ่อมมุม แต่เดิมให้พิกัดเป็นข้อความอย่างมาก 5 จุด ไม่มีทางพาไปหาบนแผนที่
    #   ⇒ หลังกล่องถามก่อนบันทึก (ตอบ No = ทันที · ตอบ Yes = หลังบันทึกเสร็จ) และหลังบันทึกด้วยปุ่มของ QGIS (เลื่อนออกนอก
    #     commitChanges) ทำเครื่องหมาย "ทุกจุด" ที่ด่านนับ ด้วยรูป/สีเดียวกับไฮไลต์ของ Add Node (DU-02) + แถบข้อความ
    #     [🔍 ดูทั้งหมด] [◀ ก่อนหน้า] [ถัดไป ▶] [ซ่อน]
    #   วงจรชีวิต: บันทึกครั้งถัดไป · เปลี่ยน/โหลดโปรเจกต์ · unload · ซ่อน/ปิดแถบ = ล้างทั้งเครื่องหมาย แถบ และรายการจุด
    #     Esc (แผนที่/แผงหลัก) · เปลี่ยนเครื่องมือ · ✖ Reset = เก็บเฉพาะเครื่องหมายบนแผนที่ — แถบยังอยู่ กด ◀ ▶ แสดงใหม่ได้
    #     (ไปใช้ Add Node/Move Node แก้ทีละจุดแล้วกลับมาไล่จุดถัดไปต่อ)
    #   จุดมาจากลูปเดิมของ _pairing_issues_impl (ไม่มีคิวรีเพิ่ม) · คำถาม/ปุ่มตั้งต้นของการบันทึกเหมือนเดิมทุกอย่าง
    _PAIR_HL_MAX_MARKS = 500     # วาดเครื่องหมายพร้อมกันไม่เกินเท่านี้ (กันแคนวาสหน่วง) · ◀ ▶ ยังไล่ได้ครบทุกจุด
    _PAIR_HL_STYLE = {           # ชนิด -> (รูป, สี) — ชุดเดียวกับ AddNodeTool._show_dups (map_tools)
        'bare': (QgsVertexMarker.ICON_X, (0, 150, 60)),          # กากบาทเขียว = มุมไม่มีหมุด
        'stacked': (QgsVertexMarker.ICON_BOX, (255, 140, 0)),    # กรอบส้ม = มุมมีหมุดซ้อน
        'stray': (QgsVertexMarker.ICON_CIRCLE, (220, 30, 30)),   # วงแดง = หมุดไม่อยู่บนมุมแปลง
        'orphan': (QgsVertexMarker.ICON_CIRCLE, (220, 30, 30)),  # วงแดง = หมุดของแปลงที่ถูกลบ
    }
    _PAIR_HL_WHAT = {'bare': "มุมไม่มีหมุด", 'stacked': "มุมมีหมุดซ้อน",
                     'stray': "หมุดไม่อยู่บนมุมแปลง", 'orphan': "หมุดของแปลงที่ถูกลบ"}

    # ★ 2.3.7 (DI-07) เมตร — มุมเดิมห่างจุดที่จะแทรก / หมุดของแปลงเองเยื้องจากมุม ไม่เกินนี้ ⇒ ถามก่อน (ปริยาย "ไม่")
    ADDNODE_NEAR_CORNER = 0.5

    _ADMIN_PICK_TIE = 0.005      # ระยะที่ถือว่า "เสมอกัน" (เมตร) -> ต้องให้ผู้ใช้ชี้เอง
    _DUP_TOL = 0.001             # ★ 2.2.9 — "ซ้อนกัน" = ห่างกันไม่เกิน 1 มม. (เกณฑ์เดียวกับตัวตรวจบนเว็บ)
    # ★ 2.4.3 rc2 (ผลตรวจ Windows rc1 🟠1) — จุดห่าง 1 มม. พอดีบนกริด 1 มม. (ฐานปัดพิกัดแล้ว) คำนวณแบบ double ได้
    #   1.0000000475 หรือ 0.9999999311 มม. ตามเศษของพิกัด (ที่ X ราว 700,000 พลาด 59%) ⇒ การนับมุมของรูเผื่อ 1 ไมครอน
    _DUP_EPS = 1e-6
    # ★ 2.4.0 (review DU-02) — เกณฑ์ "หมุดของแปลงนี้ที่มุมนี้" ชุดเดียว (ด่านก่อนบันทึก · ไฮไลต์ Add Node · ด่านกันหมุดซ้ำ · Sync)
    #   เดิมด่านก่อนบันทึกเทียบ round(x, 3) ตรงเป๊ะ แต่ไฮไลต์มุมเปลือยใช้ 1 ซม. ⇒ หมุดห่างมุม 1 มม.–1 ซม. ถูกเตือนตอนบันทึก
    #   แต่ไม่มีไฮไลต์ชี้
    #   ★ 2.4.0 (review DU-02) — จุดที่ใช้สองค่านี้จริง (ไม่ใช่ "ทุกจุด"): ด่านก่อนบันทึก (_pairing_issues_impl → _corner_n)
    #     · ไฮไลต์ Add Node (_bare_nodes → _corner_mark) · _marker_exists_here / _own_unnamed_markers_here / _addnode_own_stray
    #     · has_vertex ของ Add Node · นับ "มุมที่มีหมุด" ในกล่องยืนยันลบแปลง (_parcel_markers) · SyncVertexTool (แผนที่เมตร)
    #     ⚠️ ยังพิมพ์ 0.01 / 1e-7 เองอีกหลายที่ (Move Node/Align/Score ฯลฯ — ค่าเท่ากับ _MK_WELD_TOL) · ยังไม่ได้ย้ายมาใช้ค่านี้
    #     ⚠️ ค่าเป็นเมตร — ชั้นพิกัดองศาด่านก่อนบันทึกข้าม (why='no-metric-crs') ไม่เทียบ 0.001° (≈ 110 ม.)
    #     ⚠️ "หมุดของแปลงนี้" ยังมี 2 คีย์: ด่านก่อนบันทึกจับกลุ่มด้วย UTM อย่างเดียว · ไฮไลต์/Add Node เทียบ 7 ฟิลด์ระวาง
    #        (UTMMAP1-4 · UTMSCALE · LANDNO · UTM) ⇒ หมุดเยื้องที่ฟิลด์อื่นไม่ตรงแปลง ด่านนับเป็นมุมไม่มีหมุด + หมุดลอย
    #        แต่ไฮไลต์เป็นกากบาทเขียว (ระยะชุดเดียวกัน · คีย์ยังต่างกัน)
    _MK_AT_CORNER_TOL = 0.001    # หมุดอยู่ "บนมุม" = ห่างไม่เกิน 1 มม. (กติกาเหล็ก · เกณฑ์เดียวกับตัวตรวจบนเว็บ)
    _MK_WELD_TOL = 0.01          # หมุดของแปลงนี้ห่างมุมไม่เกิน 1 ซม. = หมุดของมุมนี้ (ถ้าเกิน 1 มม. = "หมุดเยื้องมุม")

    # ---------- ผู้รับผิดชอบ (ตัวแปร @owner_name ใช้ในสัญลักษณ์ของโปรเจกต์) ----------
    OWNER_VAR = "owner_name"
    OWNER_ALL = "*"          # ค่าพิเศษ = แสดงของทุกคน

    # เครื่องหมายคั่นในป้าย rule — ใช้ 👤 เพราะไม่มีทางโผล่ในป้ายปกติ
    # ทำให้ตัดชื่อเดิมออกแล้วเติมใหม่ได้ซ้ำ ๆ โดยไม่ต้องเก็บป้ายต้นฉบับไว้ที่ไหน
    _OWNER_TAG = "👤"

    # ---------- ★ 2.3.7 (b12 · เจ้าของงานขอ 3 ต.ค. ~22:30) 🍩 ซ่อมรูปแปลงที่เสียก่อนแบ่งหัก ----------
    _REPAIR_TOL_M2 = 0.05        # ซ่อมได้เมื่อเนื้อที่เปลี่ยนไม่เกิน max(0.05 ตร.ม., 0.1% ของเนื้อที่) — เกินนั้น = รูปเสียจริง ต้องแก้เอง
    _REPAIR_TOL_FRAC = 0.001
    _GEOS_TH = (("ring self-intersection", "วงขอบแตะ/พับทับตัวเอง (หนาม หรือขอบวนกลับ)"),
                ("self-intersection", "เส้นขอบตัดกันเอง (เส้นไขว้)"),
                ("too few", "มีส่วนที่มีมุมไม่พอเป็นรูป"),
                ("hole lies outside shell", "รูอยู่นอกขอบแปลง"),
                ("holes are nested", "รูซ้อนกันเอง"),
                ("interior is disconnected", "พื้นที่ภายในขาดออกจากกัน"),
                ("nested shells", "ก้อนของแปลงซ้อนกัน"),
                ("duplicate rings", "มีวงซ้ำกัน"),
                ("invalid coordinate", "พิกัดผิด (ไม่ใช่ตัวเลข)"),
                ("not closed", "วงขอบไม่ปิด"),
                ("repeated point", "มุมซ้ำ"))

    # ★ audit รอบ 4 — เกณฑ์เศษบาง: กว้างเฉลี่ย < 2 ซม. (เดิม) · หรือ < 10 ซม. ในก้อนที่เล็กกว่า 2 ตร.ม. (ใหม่)
    _DN_บาง, _DN_บาง_เล็ก, _DN_เล็ก = 0.02, 0.10, 2.0

    # ★ 2.3.7 (review DI-01) ตัวเลือกแรกของแปลงที่ Type เดิมว่าง — เลือกแล้ว = ไม่ทำอะไร
    TYPE_KEEP = "(ว่าง — ไม่เปลี่ยน)"
    DOC_KEEP = "(ว่าง — ไม่เปลี่ยน)"       # ★ 2.4.3 แบบเดียวกันของชนิดเอกสารใน 📝 (ล้างค่าที่มีเป็นว่างไม่ได้)
    # ★ 2.3.7 (review DI-55) ชนิดแปลงอ้างอิงที่สะกดต่างไม่ได้ (เทียบแบบตัดขีด/ช่องว่างออก)
    _TYPE_REF = {"L1RTK": "L1-RTK", "L1TS": "L1-TS", "CTRTK": "CT-RTK"}

    # ============ ℹ️ สอบถามข้อมูลแปลง (★ 2.3.7 · เจ้าของงานสั่ง 3 ต.ค. 69 · พนักงานทุกคน) ============
    _INFO_TITLE = "สอบถามข้อมูลแปลง"
    _INFO_CAPTION = ("เนื้อที่ทะเบียนอาจมีการเปลี่ยนแปลงหรือฐานข้อมูลทะเบียนกรอกผิด กรณีที่เนื้อที่ต่างกันเยอะ "
                     "ให้ตรวจสอบเนื้อที่ในภาพลักษณ์เอกสารสิทธิ์หรือสารบัญจดทะเบียน จากเว็บโครงการพัฒฯ")

    # ============ 📝 แก้ไขข้อมูลรูปแปลง (★ 2.3.7 · เจ้าของงานสั่ง 3 ต.ค. 69 · ผู้ดูแลเท่านั้น) ============
    _EP_TITLE = "แก้ไขข้อมูลรูปแปลง"
    _EP_KEYS = ("UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO")

    # ============ ➕ สร้างรูปแปลง (★ 2.3.9 · เจ้าของงานสั่ง 11 ต.ค. 69) ============
    #   "เพิ่มปุ่มสร้างรูปแปลง ด้านขวาของปุ่มแก้ไขข้อมูลรูปแปลง สร้างรูปแปลง ตามหมุดหรือคลิกที่ว่างได้
    #    และกรอกคีย์เพื่อหาทะเบียน เลือก type แปลง และ doc type และมอบหมายได้" · "ผู้ช่วยสามารถใช้ได้"
    #   คำตัดสิน 11 ต.ค.: ผู้ช่วยผู้ดูแลสร้างได้เฉพาะ L2 (L1 = ผู้ดูแล) · มุมที่คลิกที่ว่าง = หมุดไม่มีชื่อ (ตั้งชื่อทีหลัง)
    #   สิทธิ์ฐาน: ต้องมี INSERT บนชั้นแปลง (ผู้ดูแลมี · ผู้ช่วยต้องได้ GRANT ก่อน — ปุ่มตรวจให้และบอกตรง ๆ)
    _CP_TITLE = "สร้างรูปแปลง"
    # รหัสชนิดเอกสารสิทธิ์ = ตาราง doc_type_codes ของฐาน (อ่านจากฐานจริง 11 ต.ค. 69 · มี FK ⇒ ค่านอกตารางบันทึกไม่ได้)
    _CP_DOC_CODES = ("โฉนดที่ดิน", "โฉนดตราจอง", "ตราจองที่ทำประโยชน์แล้ว", "น.ส.3 ก", "น.ส.3", "ใบจอง", "ส.ค.1",
                     "น.ส.ล.", "อื่นๆ", "ทางสาธารณประโยชน์ (ทางน้ำ)", "ทางสาธารณประโยชน์ (ทางบก)",
                     "ที่มีการครอบครอง (ท.ค.)", "ที่สาธารณประโยชน์",
                     "ที่ราชพัสดุ")     # ★ rc5 (เจ้าของงาน 31 ต.ค. 69 "เพิ่ม ที่ราชพัสดุ ไปในชนิดเอกสารด้วย" · "ให้การกรอกเหมือนที่สาธารณะ")
    _CP_TYPES_ALL = ("L1-RTK", "L1-TS", "L2-TS", "L2-RO", "L2-LM")
    _CP_REGIS = ("", "มีทะเบียน", "รอจดทะเบียน", "ไม่มีทะเบียน")
    _CP_EDIT_SRC = "newparcel"          # ป้ายของหมุดที่สร้างจากปุ่มนี้ (ไม่ใช่ 'added' ของ Add Node)
    # ★ 2.4.3 ด่านโฉนดที่ดิน (➕/📝) — ชนิดเอกสารที่ต้องค้นทะเบียนและได้เนื้อที่ก่อน · ดู _ep_deed_block
    _DEED = "โฉนดที่ดิน"
    # ★ 2.4.7 (เจ้าของงาน 26 ต.ค. 69 16:50 "คีย์กลุ่ม ข ให้ปลั๊กอินคิดเลข ≤ 0 ให้เอง … ได้ครับ" · 17:57 เลือกทาง "ค" = ใส่ 0 เสมอ) คีย์กลุ่ม ข
    #   (แผน เอกสาร/แผน_2.4.7_ปุ่มสร้างแก้ไข_ค้นทะเบียนตามชนิดเอกสาร_20261026.md ข้อ 1.2–1.4) — ทะเบียนชนิดนี้ไม่มีระวาง UTM + เลขที่ดิน
    #   ⇒ คีย์ = ระวางที่รูปตั้งอยู่ + เลขที่ดิน ≤ 0 คิดให้เองแบบที่สาธารณะ · เลขบวกใหม่ใส่ไม่ได้ (แปลงเดิมที่เลขบวกอยู่แล้วแก้อย่างอื่นได้) ·
    #   น.ส.3 ก = คีย์ระวางรูปถ่าย (กลุ่ม ก) · ท.ค./อื่นๆ = แบบที่สาธารณะ (_DOC_LIKE_PUB) ⇒ ไม่อยู่ในรายการนี้
    _DOC_NOKEY = ("น.ส.3", "ใบจอง", "ส.ค.1")
    # ★ 2.4.10 (เจ้าของงาน 29 ต.ค. 69 "เปลี่ยนข้อความ ชนิดเอกสารจาก นส.3 เป็น นส.3/นส3ข") ข้อความที่แสดงของชนิดเอกสาร —
    #   ค่าในฐานคงเดิม (doc_type_codes · FK) ⇒ ใช้กับรายการเลือก/ข้อความเท่านั้น ห้ามใช้เป็นค่าที่เขียน
    _DOC_LABEL = {"น.ส.3": "น.ส.3/น.ส.3 ข"}
    # ★ 2.4.8 (เจ้าของงาน 26 ต.ค. 69 17:16 "นส3ก ใช้ utmmap1 2 4 มาตรส่วนระวาง เลขที่ดิน" · 18:1x บังคับคีย์ระวางรูปถ่าย) — น.ส.3 ก ใช้คีย์
    #   ระวางรูปถ่ายทางอากาศ (UTMMAP3 ว่าง · UTMMAP4 = แผ่นที่ 3 หลัก · มาตราส่วน _AIR_SCALES · เลขที่ดิน > 0) · ดู _ep_normalize(airphoto) · _key_mode_sync
    _DOC_AIR = "น.ส.3 ก"
    # ★ 2.4.10 (เจ้าของงาน 27 ต.ค. 69 15:03 "นสล/นส3ก ค้นหาด้วย เลขที่ … ให้เลือกระหว่างค้นหาด้วย UTM หรือเลขที่(เหมือน นส3)")
    #   ชนิดที่เลือกค้นทะเบียนด้วยเลขที่เอกสารได้ (หน้า QNSL/QNS3K) · ผลบอกคีย์ตามทะเบียน ⇒ กล่องเติมช่องคีย์ให้
    _DOC_BYNO = ("น.ส.ล.", "น.ส.3 ก", "โฉนดที่ดิน")   # ★ 2.4.10 โฉนด (เจ้าของงาน 29 ต.ค. 69 "ทำกับโฉนดที่ดินด้วย")
    # ★ 2.4.8 ขั้น E1 — ทะเบียนมีระวาง UTM แต่อยู่คนละหน้ากับโฉนด (แผนที่กรมผูกทะเบียนไม่ได้) ⇒ 🔍 ค้นหน้าของชนิดนั้นด้วยคีย์ UTM
    _DOC_UTMDOC = ("โฉนดตราจอง", "ตราจองที่ทำประโยชน์แล้ว")
    # ★ 2.4.5 rc2 (เจ้าของงาน 23 ต.ค. 69 "อยากให้มีคอลัม parcel_name ที่ไว้เก็บชื่อของทางสาธารณะ บก/น้ำ" · 24 ต.ค. "ทำใน 2.4.5 เลย")
    #   คอลัมน์ชื่อทางสาธารณะของชั้นแปลง — ช่องเปิดเฉพาะชนิดเอกสารในรายการนี้ (ทางน้ำ/ทางบก + ที่สาธารณประโยชน์ · ตัดสิน 24 ต.ค.) ·
    #   ไม่บังคับกรอก · ช่องเดียว (เลือกจากรายการแนะนำแล้วพิมพ์ต่อได้) · ไม่เกิน 100 ตัวอักษร · ชนิดอื่น = ว่าง (➕) / ล้างเมื่อเปลี่ยนชนิด (📝)
    _PN_FIELD = "parcel_name"
    _PN_MAX = 100
    _PN_SUGGEST = {"ทางสาธารณประโยชน์ (ทางน้ำ)": ("ลำรางสาธารณะ", "ลำเหมืองสาธารณะ", "คลองสาธารณะ", "ลำห้วยสาธารณะ"),
                   "ทางสาธารณประโยชน์ (ทางบก)": ("ทางสาธารณะ", "ถนนสาธารณะ", "ทางเดินสาธารณะ"),
                   "ที่สาธารณประโยชน์": ("หนองน้ำสาธารณะ", "บึงสาธารณะ", "ป่าช้าสาธารณะ"),
                   "ที่มีการครอบครอง (ท.ค.)": (), "อื่นๆ": (), "ที่ราชพัสดุ": ()}       # ★ rc5 ที่ราชพัสดุ ใส่ชื่อแปลงได้แบบที่สาธารณะ
    # ★ 2.4.7 (เจ้าของงาน 26 ต.ค. 69 17:2x "ทค ให้ไม่มีทะเบียนและใส่เหมือนที่สาธารณะ และใส่ parcel name" · 17:3x "อื่นๆ เหมือนสาธารณะ")
    #   ท.ค. + อื่นๆ ใส่ชื่อแปลงได้ (ไม่มีรายการคงที่ · แนะนำเฉพาะชื่อของชนิดนั้นที่มีในชั้น) · ➕ REGIS 'ไม่มีทะเบียน' เสมอ ·
    #   เลขที่ดิน 0 = คิดเลข ≤ 0 ให้แบบที่สาธารณะ (ทางเดิมของทุกชนิด)
    _DOC_LIKE_PUB = ("ที่มีการครอบครอง (ท.ค.)", "อื่นๆ")
    # ★ rc6 (ผลตรวจ Windows rc5 ⚪4) ชนิดที่ช่อง parcel_name เป็น "ชื่อแปลง" (ไม่ใช่ชื่อทางสาธารณะ · ไม่มีรายการแนะนำแบบลำราง) —
    #   ท.ค./อื่นๆ + ที่ราชพัสดุ · ใช้เฉพาะป้าย/ตัวอย่างของช่อง (ที่ราชพัสดุยังกรอกแบบที่สาธารณะทุกอย่าง ไม่เข้า _DOC_LIKE_PUB)
    _PN_NAME_DOCS = _DOC_LIKE_PUB + ("ที่ราชพัสดุ",)
    # ★ rc6 ชนิดปัญหาของแปลง L1 (ตรงกับตาราง l1_issue_kinds ในฐาน · db_admin/ตาราง_L1มีปัญหา_20261031/l1_issue.sql) — 📝 ลด Type จาก L1
    _L1_ISSUE_KINDS = (("ผิดตำแหน่ง", "ทั้งแปลงเลื่อนจากตำแหน่งจริง"), ("วัดผิดล็อค", "รูปเป็นของแปลงอื่น / วัดผิดแปลง"),
                       ("รูปผิด", "ขนาด/มุมไม่ตรงหลักฐาน"), ("อื่นๆ", "ต้องใส่หมายเหตุ"))
    # ★ 2.5.0 (ผลตรวจ Windows 2.4.8 rc2 ⚪5/⚪6 · เจ้าของงาน 29 ต.ค. 69 "ลองทำ ⚪5/⚪6 + 2.7") ทาง/ที่สาธารณะ — ไม่มีทะเบียนให้ค้น:
    #   📝 ไม่ถามระบบกรมทุกเลข (เลขบวกเดิม 647 แปลง) · เปลี่ยนเป็นชนิดนี้ ⇒ REGIS 'ไม่มีทะเบียน' + ล้าง AREA/DIFF_AREA (แบบ ➕ · แบบ ท.ค./อื่นๆ)
    #   ★ rc5 (เจ้าของงาน 31 ต.ค. 69 "เพิ่ม ที่ราชพัสดุ ไปในชนิดเอกสารด้วย" · "ให้การกรอกเหมือนที่สาธารณะ") ที่ราชพัสดุ = กลุ่มนี้ ·
    #   ต้องมีรหัสในตาราง doc_type_codes ของฐานก่อน (FK) — ไม่งั้นบันทึกแปลงชนิดนี้ไม่ได้
    _DOC_PUBLIC = ("ทางสาธารณประโยชน์ (ทางน้ำ)", "ทางสาธารณประโยชน์ (ทางบก)", "ที่สาธารณประโยชน์", "ที่ราชพัสดุ")

    _WELD_MK_TOL = 0.001        # ★ 2.3.7 (audit F5) หมุดของมุม = UTM เดียวกัน ห่างไม่เกิน 1 มม. (กติกาหมุด 1 มม.)

    ALIGN_EDGE_MAX_PAR = 0.9     # ★ 2.3.9 — |cos| ของขอบกับเส้นแนว เกินนี้ (ขอบเอียงจากเส้น < ~26°) = ฉายตั้งฉากแทน
    ALIGN_RUN_STRAIGHT = 0.9     # ★ 2.4.5 rc4 — |cos| ของขอบไปมุมที่ไม่ได้เลือกกับขอบไปหมุดที่เลือก เกินนี้ (เบน ≤ ~26°) = ต่อตรงกับแถว ไม่ใช่ขอบข้าง


# ★ 2.4.0 — ผูกชื่อ MultiLayerEditPro ให้โมดูลที่โค้ดเรียกคลาสหลักตรง ๆ (ดูหัวไฟล์ของโมดูลนั้น)
_late_0.MultiLayerEditPro = MultiLayerEditPro
_late_1.MultiLayerEditPro = MultiLayerEditPro
