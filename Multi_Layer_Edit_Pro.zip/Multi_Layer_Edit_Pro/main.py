import os
import math
import requests
import zipfile
import io
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import (QgsProject, QgsPointXY, QgsGeometry, QgsPointLocator,
                       QgsSnappingConfig, QgsTolerance, QgsWkbTypes,
                       QgsFeatureRequest, QgsVectorLayer, QgsFeature,
                       QgsExpression, QgsSpatialIndex)
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsVertexMarker, QgsRubberBand, QgsSnapIndicator
from qgis.core import QgsRectangle, QgsCoordinateTransform, QgsCoordinateReferenceSystem
from qgis.utils import iface


# ประวัติการอัปเดต (ใหม่สุดอยู่บน) — ใช้เด้ง "What's New" หลังอัปเดตเวอร์ชัน
CHANGELOG = [
    ("1.9.2", ["Snap ติดชั้นหมุดหลักฐาน CT ด้วยแล้ว — ลากมุมแปลง/หมุด เข้าหาหมุดหลักฐานได้ตรง ๆ",
               "หาชั้น CT ให้อัตโนมัติจากชื่อ (CT_<สาขา>) ไม่ต้องตั้งค่าเพิ่ม",
               "Add Node: ถ้าแปลงนั้นมีหมุดอยู่ตรงจุดนั้นแล้ว จะไม่เพิ่มซ้ำ (เดิมคลิกซ้ำจุดเดิม = ได้หมุดซ้อนกัน)",
               "  • มุมร่วมกับแปลงข้างเคียงยังเพิ่มได้ปกติ (คนละระวาง = คนละหมุด) และจะบอกว่าข้ามไปกี่จุด",
               "อัปเดต: ตรวจเวอร์ชันในไฟล์ที่โหลดมาก่อนติดตั้ง + ปฏิเสธถ้าไม่ใหม่กว่าของเดิม (กันโดน downgrade)",
               "อัปเดต: แตกไฟล์ที่พักก่อนแล้วค่อยสลับ + สำรองของเดิมไว้ ถ้าพลาดกลางคันคืนให้อัตโนมัติ"]),
    ("1.9.1", ["เช็คเวอร์ชันใหม่ให้อัตโนมัติตอนเปิดปลั๊กอิน",
               "ตัวเตือน \"มุมแปลงไม่มีหมุด\" ครอบทุกวิธีบันทึกแล้ว — เดิมเตือนเฉพาะตอนกดปุ่ม \"💾 บันทึก\" ของปลั๊กอิน",
               "ถ้ากด Save ของ QGIS เอง (Save Layer Edits / ปิดโหมดแก้ไข) จะเตือนทันทีหลังบันทึก พร้อมบอกวิธีแก้",
               "⚠️ ย้ำ: เพิ่มมุมแปลงต้องใช้ปุ่ม \"➕ Add Node\" เท่านั้น — Vertex Tool ของ QGIS ไม่สร้างหมุดให้"]),
    ("1.9.0", ["บันทึก (Commit): เตือนถ้ามีมุมแปลงที่ไม่มีหมุด — กันหมุดหายโดยไม่รู้ตัว (กด \"บันทึกต่อ\" ได้ ไม่บังคับ)",
               "⚠️ อย่าเพิ่มมุมแปลงด้วยเครื่องมือ Vertex Tool ของ QGIS — มันไม่สร้างหมุดให้ ใช้ปุ่ม \"➕ Add Node\" เท่านั้น",
               "ค้นหาภาพลักษณ์/หลักฐานรังวัด: คลิกจุดที่มีแปลงซ้อนกัน → มี popup ให้เลือกแปลง (ระวาง • มาตราส่วน • เลขที่ดิน)",
               "Add Node: หมุดที่เพิ่มใหม่ติดป้าย EDIT_SRC='added' + ฐานข้อมูลบันทึกชื่อผู้แก้/เวลาให้เอง (ตรวจย้อนหลังได้)",
               "เร็วขึ้นบนฐานข้อมูลผ่าน network: เช็คล็อก L1-RTK/L1-TS จำผลไว้ทั้ง session (เดิมยิงคิวรีใหม่ทุกครั้งที่ขยับ)",
               "Snap: จำกัดเฉพาะชั้นแปลง+หมุดที่เลือกไว้ได้จริง แม้เปิด snapping ค้างไว้ก่อนเปิดปลั๊กอิน"]),
    ("1.8.0", ["Move/Rotate/Scale: เห็น \"เงาตัวอย่าง\" (สีฟ้า) ว่าแปลง+หมุดจะไปตกที่ไหน ก่อนคลิกยืนยัน",
               "Move/Rotate/Scale: มีตัวเลขบอกระยะ/มุม/สเกล ตามเมาส์ที่แถบสถานะด้านล่าง",
               "เงาตัวอย่างใช้สูตรเดียวกับตอนแก้จริง — เห็นอย่างไรได้อย่างนั้น",
               "เลือกทั้งระวาง (แปลงเยอะ) เงาจะย่อเป็นกรอบรวมอัตโนมัติ เพื่อไม่ให้หน่วง",
               "เลือกแปลง L1-RTK/L1-TS จะเตือนตั้งแต่คลิกแรกว่าขยับไม่ได้ (เดิมรู้ตอนคลิกจบ)",
               "เก็บกวาดเงา/หมุดที่ค้างบนจอ เมื่อสลับไปใช้เครื่องมืออื่นของ QGIS"]),
    ("1.7.0", ["PostgreSQL: ลด query ข้าม network ครั้งใหญ่ — เช็คล็อก L1-RTK/L1-TS เหลือคิวรีเดียวต่อรอบ, Align/Move Node ดึงข้อมูลแบบ batch",
               "Hover (ค้นหาภาพลักษณ์/Add Node) ไม่ยิง query ทุกเฟรม — ลื่นขึ้นมากบนฐานข้อมูลผ่าน network",
               "บันทึก (Commit): เช็คผลจริงจากฐานข้อมูล — บันทึกไม่ผ่านจะเตือนพร้อมสาเหตุ (เดิมขึ้น 'สำเร็จ' เสมอ)",
               "ค้นหลักฐานรังวัด/เข้าสู่ระบบ/Check Update ทำงานเบื้องหลัง — QGIS ไม่ค้างเมื่อ server ช้า",
               "Snap เฉพาะชั้นแปลง+หมุดที่เลือกไว้ (เดิม AllLayers ทำ index ทุกชั้น)",
               "รายชื่อเลเยอร์อัปเดตอัตโนมัติเมื่อเพิ่ม/ลบเลเยอร์ + จำเลเยอร์ที่เลือกไว้ตอน Refresh",
               "กันค่า attribute ที่มีอักขระพิเศษ (') ทำ expression เลือกกลุ่ม/เช็คล็อกพัง",
               "เตือนเมื่อโปรเจกต์เปิด Automatic transaction groups (กระทบระบบ Undo ของปลั๊กอิน)"]),
    ("1.6.3", ["Fix: เพิ่มระบบป้องกันคืนคิวฐานข้อมูล (Lock) เมื่อเกิด Error ใน Change Score และ Group Cluster ID ป้องกันปัญหาหน้าจอ QGIS ค้าง"]),
    ("1.6.2", ["Align: หมุดที่เลือกวิ่งไปหาเส้นแบบ 'ตามแนวขอบ' → ขอบที่ต่อหมุดที่ไม่ได้เลือกไม่เบี้ยวตาม (เดิมฉายตั้งฉากแล้วขอบเอียง)",
               "Align: weld มุมแปลงแบบ junction-aware — มุมร่วมรวมให้, มุมไม่ snap เด้งถาม, แปลงข้างเคียงที่ไม่เกี่ยวไม่โดนลาก (เดิมเหวี่ยง 5ซม.)"]),
    ("1.6.1", ["Undo: ย้อนทั้งเลเยอร์แปลง+หมุดให้ตรงกันเสมอ + กดซ้อนหลายครั้งได้ถูกต้อง (แก้ Sync Cluster ID ที่เดิม undo ไม่ติด)",
               "Undo: ถ้าเผลอปิดแก้ไขเลเยอร์ไป — ปิดแบบ Save จะเตือน • ปิดแบบ Discard จะถามว่าย้อนอีกเลเยอร์กลับจุดเริ่มให้ตรงกันไหม",
               "เพิ่มประสิทธิภาพ Move Node/Align ตอนเลือกหมุดเยอะ และ hover ค้นหาภาพลักษณ์ให้ลื่นขึ้น"]),
    ("1.6.0", ["Move Node โหมดใหม่: คลิกหมุดเดียว → คลิกตำแหน่งใหม่เพื่อย้าย (มีเส้นนำ)",
               "Move Node: ลากกล่องเลือกหลายหมุดแล้วลากย้าย (Shift+ลาก = เลือกเพิ่ม)",
               "แก้ค้นหาภาพลักษณ์/หลักฐานรังวัดขึ้น \"ข้อมูลแปลงไม่ครบ\" (อ่าน attribute แปลงที่คลิกไม่ครบบนบางชนิดข้อมูล)",
               "เพิ่มประสิทธิภาพการทำงาน (cache การหา field, ลดการ query ซ้ำ)"]),
    ("1.5.6", ["เพิ่มประสิทธิภาพการทำงานและความลื่นไหล"]),
    ("1.5.5", ["แก้ไข Move Node ดึงหมุดแปลงข้างเคียงตาม (หากมีการ Select แปลงเอาไว้ จะย้ายแค่แปลงที่ Select จริงๆ เท่านั้น)"]),
    ("1.5.4", ["เพิ่มเงื่อนไขเครื่องมือ Move Node: หากมีการ Select แปลงอยู่ จะจำกัดให้ย้ายได้เฉพาะมุมของแปลงที่ Select ไว้เท่านั้น"]),
    ("1.5.3", ["เพิ่มกันชน L1-RTK/L1-TS กลับเข้าไปในเครื่องมือ Move Node เพื่อป้องกันไม่ให้ถูกตีกรอบครอบไปขยับพิกัด"]),
    ("1.5.2", ["ปรับปรุงเครื่องมือ Move Node ให้รองรับการเลือกหมุดแบบสะสม (ตีกรอบเพิ่มได้เรื่อยๆ โดยไม่ต้องกดคีย์บอร์ด)"]),
    ("1.5.1", ["แก้บั๊กมุมแปลง (Polygon Node) ไม่ขยับตามหมุดตอนใช้ Move Node", "เพิ่มประสิทธิภาพการทำงานและความลื่นไหล"]),
    ("1.5.0", ["เพิ่มปุ่ม \"ค้นหาหลักฐานการรังวัด\" (ต้อง login — ใส่รหัสตอนใช้ ไม่เก็บถาวร)",
               "คลิกแปลง -> เปิดหลักฐานรังวัด • หลายรายการมี popup ให้เลือก",
               "ปรับปรุงประสิทธิภาพเครื่องมือ Align และเครื่องมืออื่นๆ (แก้ปัญหาค้าง/หน่วง)"]),
    ("1.4.4", ["เพิ่มระบบเด้ง \"มีอะไรใหม่\" สรุปการเปลี่ยนแปลงหลังอัปเดต"]),
    ("1.4.3", ["กันชน L1-RTK/L1-TS ในเครื่องมือ Add Node (hover แดง • เลือก/เพิ่มไม่ได้)"]),
    ("1.4.2", ["Add Node: เลือกได้ทีละ 1 แปลง",
               "เพิ่ม hover highlight แปลงใต้เมาส์"]),
    ("1.4.1", ["Add Node: ตัดคลิกขวา ใช้ snap เลือกหมุด (วงกลมแดง)"]),
    ("1.4.0", ["เพิ่มเครื่องมือ Add Node: เพิ่ม node + หมุด (ระวางจากแปลง, ชื่อจากหมุดเดิม, หลายชื่อมี popup เลือก)",
               "เปลี่ยนชื่อปุ่ม Align Points to Line → Align Points"]),
    ("1.3.7", ["Shortcut: ปลดคีย์เดิมของ QGIS ที่ชนได้ (ถามก่อนทำ)"]),
    ("1.3.6", ["ค้นหาภาพลักษณ์: แก้ปัญหาขึ้นผิดสาขา (ระวางคร่อมสาขา เลือกแปลงใกล้จุดคลิก)",
               "Shortcut: เตือนเมื่อคีย์ชนกับ QGIS"]),
    ("1.3.5", ["Align Points: ปรับระยะเชื่อม node เป็น 0.05 ม."]),
    ("1.3.4", ["Align Points: แก้หมุดที่ซ้อนกันกระเด็นแยก (คำนวณตำแหน่งก่อนแก้ไข)"]),
    ("1.3.3", ["Align Points: เพิ่มระยะเชื่อม node ของแปลงข้างเคียง"]),
    ("1.3.2", ["Clean/optimize โค้ด", "เอาเครื่องมือ Auto/Semi-Auto Transform ออก"]),
    ("1.3.1", ["Reset: เคลียร์ feature ที่เลือกทั้งหมดใน QGIS",
               "ปรับเวลาแสดง message bar (error ค้าง, อื่นๆ หายเอง)"]),
    ("1.3.0", ["UI หน้าเดียวกระทัดรัด", "ค้นหาภาพลักษณ์ DOL",
               "Align แบบ box-select", "ตั้งค่า Shortcut"]),
]


# ที่อยู่ไฟล์อัปเดตบน GitHub — ใช้ร่วมกันทั้งปุ่ม 🚀 Check Update และการเช็คอัตโนมัติตอนเปิด
UPDATE_V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
UPDATE_Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"


def _vkey(v):
    """แปลงเลขเวอร์ชัน '1.4.3' -> (1,4,3) เพื่อเทียบเชิงตัวเลข"""
    try:
        return tuple(int(x) for x in str(v).strip().split("."))
    except Exception:
        return (0,)


_UTM_FIELD_NAMES = {'utm', 'utm_code', 'utm_id'}


def _norm_utm(v):
    """normalize ค่า UTM เป็น string สำหรับเทียบข้ามเลเยอร์
    (กันเคส provider คนละชนิดคืน 123 กับ 123.0 แล้วเทียบไม่ตรงกัน)"""
    s = str(v).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s


# ============ เงาตัวอย่าง (preview) ของ Move/Rotate/Scale ============
# จำนวนคลิกที่แต่ละโหมดต้องใช้ — ใช้ร่วมกันทั้ง handle_click และเงาตัวอย่าง
# (เดิมตารางนี้อยู่ใน handle_click ที่เดียว — แยกออกมากัน "จำนวนคลิก" ของสองฝั่งหลุดจากกัน)
_CLICK_LIMIT = {'move': 2, 'modify_node': 2, 'rotate': 3, 'scale': 3, 'transform': 4}

# โหมดที่มีเงาตัวอย่าง — transform/modify_node ไม่มี:
#   transform: กฎปลดล็อก L1-TS ตัดสินจากจุดที่ 4 ซึ่งก็คือเมาส์ -> เงาจะพลิกไปมาทุกเฟรม
#   modify_node: ขยับ vertex เดียว ไม่ใช่ทั้งแปลง
_PREVIEW_MODES = ('move', 'rotate', 'scale')

# เกินจำนวนจุดนี้ -> ย่อเงาแปลงเป็นกรอบรวม (convex hull) กันเฟรมตกตอนเลือกทั้งระวาง
# hull ไม่ทำให้เงาโกหก: move/rotate/scale เป็น similarity ทั้งหมด -> hull(T(g)) == T(hull(g))
_PREVIEW_VERTEX_BUDGET = 20000


class MultiLayerEditPro:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = []
        self.temp_tool = None
        self.last_layers = []   # เลเยอร์ที่แก้ล่าสุด (ใช้ refer ทั่วไป — undo ใช้ op_history แทน)
        # ประวัติการแก้ไขของปลั๊กอินสำหรับ Undo: แต่ละรายการ = [(layer, n_steps), ...] ใหม่สุดท้าย
        self.op_history = []
        self._op_baseline = None   # snapshot index ของ undo-stack ก่อนเริ่ม operation ปัจจุบัน
        # ดักสถานะตอนปิด edit ของแต่ละเลเยอร์ (รู้ว่ากด Save หรือ Discard) สำหรับ guard ตอน undo
        self._edit_end = {}        # layer_id -> 'commit' | 'rollback'
        self._signal_layers = set()
        self._signal_conns = []    # [(signal, slot)] ไว้ disconnect ตอน unload
        self.mode = ""
        self.version = "1.9.2"
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล
        self.rubber_band = None
        # เงาตัวอย่าง Move/Rotate/Scale: [(layer, geom ต้นฉบับ, rubber band, gtype)]
        # geom snapshot ไว้ตอนคลิกแรก -> ทุกเฟรมแค่ copy+แปลง ไม่ต้องดึงข้อมูลใหม่
        self._preview_items = []
        self._preview_last = None   # key ของเฟรมล่าสุด (None = ไม่มีเงาบนจอ)
        self._preview_tool = None   # เครื่องมือที่เป็นเจ้าของเงารอบนี้ (ดู _map_tool_changed)
        self._preview_heavy = False # เงาถูกย่อเป็นกรอบรวมหรือไม่ (ไว้บอกผู้ใช้ที่แถบสถานะ)
        self._dol_highlight = None  # rubber band ไฮไลต์แปลงที่ค้นหา
        self._align_picked_ids = set()  # หมุดที่เลือกด้วยกล่อง (Align)
        self._align_markers = []
        self._shortcuts = []  # QShortcut ที่ผูกไว้
        self._field_cache = {}  # memoize การหา field ตามชื่อ (สำหรับ hover path ที่เรียกทุกเฟรม)
        # เฝ้า "มุมแปลงไม่มีหมุด" ตอน commit ทุกช่องทาง (รวมปุ่ม Save ของ QGIS เอง ไม่ใช่แค่ปุ่มปลั๊กอิน)
        self._pending_pair_warn = None   # ผลตรวจที่เก็บไว้ตอน beforeCommit -> เอาไปเตือนตอน afterCommit
        self._pair_warn_ack = False      # True = ปุ่ม Save ของปลั๊กอินถามไปแล้ว อย่าเตือนซ้ำ

    # ============ ตัวช่วยหา field (memoize ตาม layer.id) — ใช้ใน hover ที่เรียกถี่ ============
    def _resolve_field(self, layer, candidates):
        """คืนชื่อ field แรกที่ตรงกับ candidates (เทียบ lowercase) หรือ None — cache ตาม layer.id()
        ใช้กับ hot path เช่น _poly_type_str ที่ถูกเรียกทุก mouse-move
        (call site แบบครั้งเดียวต่อคลิกใช้ _field_index ได้ ไม่ต้องผ่าน cache นี้)"""
        ckey = (layer.id(), frozenset(candidates))
        if ckey in self._field_cache:
            return self._field_cache[ckey]
        name = next((f.name() for f in layer.fields()
                     if f.name().lower() in candidates), None)
        self._field_cache[ckey] = name
        return name

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)
        # กันเงา/หมุดค้างจอ: ผู้ใช้กดเครื่องมืออื่นของ QGIS (Pan/Select) กลางคัน = เลิกใช้เครื่องมือเรา
        # แต่ไม่มีใครเก็บกวาดให้ (เส้นทางนี้ไม่ผ่าน cancel_transform) -> ดักที่ signal เปลี่ยนเครื่องมือ
        try:
            self.iface.mapCanvas().mapToolSet.connect(self._map_tool_changed)
        except Exception:
            pass

    def _map_tool_changed(self, new_tool=None, *_a):
        """เปลี่ยนเครื่องมือ -> เก็บกวาดเงา + หมุดของรอบที่ค้างไว้

        เทียบกับ "เจ้าของเงา" (_preview_tool ที่บันทึกตอน arm) ไม่ใช่ self.temp_tool ปัจจุบัน:
        ทุก start_* ตั้ง self.temp_tool = ตัวใหม่ "ก่อน" setMapTool เสมอ ถ้าเทียบกับ temp_tool
        จังหวะ setMapTool จะ early-return ทุกครั้งที่สลับข้ามเครื่องมือของปลั๊กอินเอง
        (เช่น กด Move คลิกแรกแล้วไปกด Move Node ต่อ) -> เงารอบก่อนค้างจอ
        เทียบกับเจ้าของเงาแทน = เก็บกวาดตอน setMapTool ตรงๆ ไม่ต้องพึ่งจังหวะที่ Python
        คืนหน่วยความจำเครื่องมือตัวเก่า (ซึ่งเป็นกลไกที่มองไม่เห็นจากโค้ดและพึ่งพาไม่ได้)
        เทียบด้วย is (ไม่ใช่ ==) และไม่แตะ oldTool เลย — oldTool อาจกำลังถูกทำลายอยู่
        รับ *_a เพราะ signal นี้มีทั้งแบบ 1 และ 2 อาร์กิวเมนต์ตามรุ่น QGIS

        กัน instance เก่าค้าง: signal นี้ผูกกับ canvas ซึ่งอายุยืนกว่าตัวปลั๊กอิน ถ้า unload
        ของ instance ก่อนหน้าไม่ได้ทำงาน (เช่น reload ปลั๊กอินกลางคันตอนแก้โค้ด) slot จะยัง
        ถูกเรียกบน object เก่าที่โครงไม่ครบ -> ใช้ getattr + try กันพ่น error ทุกครั้งที่
        สลับเครื่องมือ (งานในนี้เป็นแค่การเก็บกวาด ล้มเหลวอย่างมากคือเงาค้าง ไม่กระทบข้อมูล)"""
        if new_tool is not None and new_tool is getattr(self, "_preview_tool", None):
            return
        try:
            self._preview_clear()
            self.clear_markers()
        except Exception:
            pass

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", self.action)
        try:
            self.iface.mapCanvas().mapToolSet.disconnect(self._map_tool_changed)
        except Exception:
            pass
        self.clear_markers()
        self._preview_clear()
        self._dol_clear_highlight()
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None); sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        # ตัด signal commit/rollback ที่ต่อไว้ (กัน slot ทำงานหลัง unload)
        for sig, slot in getattr(self, "_signal_conns", []):
            try:
                sig.disconnect(slot)
            except Exception:
                pass
        self._signal_conns = []
        self._signal_layers = set()
        if hasattr(self, 'temp_tool') and self.temp_tool:
            canvas = self.iface.mapCanvas()
            if canvas and canvas.mapTool() == self.temp_tool:
                canvas.unsetMapTool(self.temp_tool)

    def run(self):
        if self.dlg is None: self.create_dialog()
        self.dlg.show()
        self._check_transaction_mode()
        self._show_whats_new()
        self._auto_check_update()   # เช็คของใหม่ให้เอง ครั้งเดียวต่อการเปิด QGIS

    def _check_transaction_mode(self):
        """เตือน (ครั้งเดียวต่อ session) ถ้าโปรเจกต์เปิด Automatic transaction groups
        — เลเยอร์ PostgreSQL ที่ใช้ connection เดียวกันจะแชร์ edit session ทำให้การนับ
        undo ต่อเลเยอร์ของปลั๊กอิน (_op_begin/_op_commit) ไม่ตรงกับความเป็นจริง"""
        if getattr(self, "_txn_warned", False):
            return
        try:
            on = bool(QgsProject.instance().autoTransaction())
        except Exception:
            on = False
        if on:
            self._txn_warned = True
            self.iface.messageBar().pushMessage(
                "MLEP", "โปรเจกต์นี้เปิด Automatic transaction groups — ระบบ Undo ของปลั๊กอิน"
                        "อาจนับไม่ตรงสำหรับเลเยอร์ PostgreSQL ที่ใช้ connection เดียวกัน "
                        "แนะนำปิดที่ Project Properties → Data Sources",
                level=1, duration=15)

    def _show_whats_new(self):
        """เด้ง popup สรุปสิ่งที่เปลี่ยน เมื่อเปิดปลั๊กอินครั้งแรกหลังเวอร์ชันใหม่
        (เทียบกับเวอร์ชันที่เคยเห็นใน QSettings; ติดตั้งครั้งแรกจะเงียบ ตั้ง baseline ไว้)"""
        s = QtCore.QSettings()
        key = "MultiLayerEditPro/lastSeenVersion"
        last = s.value(key, "", str)
        if _vkey(self.version) <= _vkey(last):
            return                      # เคยเห็นแล้ว / ไม่ใช่เวอร์ชันใหม่
        s.setValue(key, self.version)   # บันทึกทันทีกันเด้งซ้ำ
        if last:
            # หา index ของเวอร์ชันล่าสุดที่เคยเห็น
            last_idx = next((i for i, (v, _) in enumerate(CHANGELOG) if _vkey(v) <= _vkey(last)), len(CHANGELOG))
            # โชว์สิ่งที่ใหม่กว่าทั้งหมด + ขอย้อนดูอดีตด้วยให้รวมเป็น 3 เวอร์ชันเป็นอย่างน้อย
            show_count = max(last_idx, 3)
            new_entries = CHANGELOG[:show_count]
            head = f"อัปเดตเป็นเวอร์ชัน {self.version} แล้ว 🎉"
        else:
            # ครั้งแรก -> โชว์ 3 เวอร์ชันล่าสุด
            new_entries = CHANGELOG[:3]
            head = f"ยินดีต้อนรับสู่เวอร์ชัน {self.version} 🎉"
        if not new_entries:
            return
        rows = []
        for v, items in new_entries:
            rows.append(f"<b>v{v}</b>")
            rows += [f"&nbsp;&nbsp;• {it}" for it in items]
            rows.append("")
        box = QtWidgets.QMessageBox(self.dlg or self.iface.mainWindow())
        box.setWindowTitle("Multi-Layer Edit Pro — มีอะไรใหม่ ✨")
        box.setTextFormat(QtCore.Qt.RichText)
        box.setText(head)
        box.setInformativeText("<br>".join(rows))
        box.setStandardButtons(QtWidgets.QMessageBox.Ok)
        box.exec_()

    # ============ Shortcut ปุ่มต่าง ๆ ============
    def _shortcut_actions(self):
        """รายการ action ที่ตั้ง shortcut ได้: (id, label, callable)"""
        return [
            ("dol_search", "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image')),
            ("dol_survey", "📐 ค้นหาหลักฐานการรังวัด", lambda: self.start_dol_search('survey')),
            ("by_cluster", "By Cluster ID", lambda: self.process_selection('cluster')),
            ("by_utm", "By UTM", lambda: self.process_selection('utm')),
            ("move", "Move", lambda: self.start_interactive('move')),
            ("rotate", "Rotate", lambda: self.start_interactive('rotate')),
            ("scale", "Scale", lambda: self.start_interactive('scale')),
            ("transform", "Transform (2 จุด)", lambda: self.start_interactive('transform')),
            ("modify_node", "Move Node (Sync)", self.start_sync_vertex_tool),
            ("align", "Align Points", self.start_align_tool),
            ("add_node", "Add Node", self.start_add_node),
            ("sync_cluster", "Sync Cluster ID", self.group_cluster_ids),
            ("score1", "Score = 1", lambda: self.set_score_value(1)),
            ("score0", "Score = 0", lambda: self.set_score_value(0)),
            ("reset", "Reset", self.cancel_transform),
            ("undo", "Undo", self.undo_transform),
            ("save", "บันทึก (Commit)", self.save_all_changes),
        ]

    def _load_shortcuts(self):
        """อ่าน QSettings -> สร้าง QShortcut ผูกกับ main window (ทำงานทั้งแอปขณะใช้ QGIS)"""
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None); sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        mw = self.iface.mainWindow()
        # ตั้งค่า Ctrl+Z เป็น Undo ของปลั๊กอิน (และปลดของ QGIS ออก) อัตโนมัติ 1 ครั้ง
        if not s.contains("MultiLayerEditPro/ShortcutUndoInit"):
            s.setValue("MultiLayerEditPro/ShortcutUndoInit", True)
            s.setValue(k + "undo", "Ctrl+Z")
            self._release_qgis_shortcuts(["Ctrl+Z"])
            
        for aid, label, slot in self._shortcut_actions():
            seq = s.value(k + aid, "", str)
            if not seq:
                continue
            sc = QtWidgets.QShortcut(QtGui.QKeySequence(seq), mw)
            sc.setContext(QtCore.Qt.ApplicationShortcut)
            sc.activated.connect(slot)
            self._shortcuts.append(sc)

    def open_shortcut_settings(self):
        """popup ตั้งค่า shortcut แต่ละปุ่ม"""
        dlg = QtWidgets.QDialog(self.dlg)
        dlg.setWindowTitle("⌨ ตั้งค่า Shortcut")
        dlg.setMinimumWidth(380)
        v = QtWidgets.QVBoxLayout(dlg)
        v.addWidget(QtWidgets.QLabel(
            "คลิกในช่องแล้วกดคีย์ที่ต้องการ (เว้นว่าง = ไม่ใช้)\nทำงานทั้งแอปขณะใช้ QGIS"))
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        form = QtWidgets.QFormLayout()
        editors = {}
        for aid, label, slot in self._shortcut_actions():
            ed = QtWidgets.QKeySequenceEdit(QtGui.QKeySequence(s.value(k + aid, "", str)))
            editors[aid] = ed
            btn_clr = QtWidgets.QPushButton("✖"); btn_clr.setFixedWidth(28)
            btn_clr.clicked.connect(ed.clear)
            row = QtWidgets.QHBoxLayout(); row.addWidget(ed, 1); row.addWidget(btn_clr, 0)
            w = QtWidgets.QWidget(); w.setLayout(row)
            form.addRow(label + ":", w)
        inner = QtWidgets.QWidget(); inner.setLayout(form)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(inner)
        v.addWidget(scroll)
        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        v.addWidget(btns)
        btns.accepted.connect(dlg.accept); btns.rejected.connect(dlg.reject)
        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            qgis_keys = self._qgis_shortcut_keys()
            seen, dup, conflict = {}, set(), set()
            for aid, ed in editors.items():
                seq = ed.keySequence().toString()
                if seq:
                    if seq in seen:
                        dup.add(seq)
                    seen[seq] = aid
                    if seq in qgis_keys:
                        conflict.add(seq)
                s.setValue(k + aid, seq)
            self._load_shortcuts()
            msg = "บันทึก shortcut แล้ว ✅"
            if dup:
                msg += f"\n⚠️ คีย์ซ้ำกันเองในปลั๊กอิน: {', '.join(sorted(dup))}"
            if conflict:
                ck = ", ".join(sorted(conflict))
                ans = QtWidgets.QMessageBox.question(
                    self.dlg, "คีย์ชนกับ QGIS",
                    f"คีย์เหล่านี้ QGIS ใช้อยู่: {ck}\n"
                    "ถ้าปล่อยไว้ Qt จะถือว่ากำกวม → ปุ่มลัดอาจไม่ทำงาน\n\n"
                    "ต้องการให้ปลดคีย์เดิมของ QGIS ออก เพื่อให้ปลั๊กอินใช้คีย์นี้ได้ไหม?\n"
                    "(เปลี่ยนคีย์ลัด QGIS ถาวร — ย้อนคืนได้ที่ Settings → Keyboard Shortcuts)",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No)
                if ans == QtWidgets.QMessageBox.Yes:
                    released = self._release_qgis_shortcuts(conflict)
                    self._load_shortcuts()   # โหลดใหม่ให้คีย์ปลั๊กอินจับได้หลังปลดคีย์ QGIS
                    if released:
                        msg += f"\n✅ ปลดคีย์ QGIS แล้ว: {', '.join(sorted(released))}"
                    left = conflict - released
                    if left:
                        msg += (f"\n⚠️ ปลดไม่ได้: {', '.join(sorted(left))} "
                                "(แก้เองที่ Settings → Keyboard Shortcuts)")
                else:
                    msg += f"\n⚠️ ยังชนกับ QGIS: {ck} (ปุ่มลัดอาจไม่ทำงาน)"
            QtWidgets.QMessageBox.information(self.dlg, "Shortcut", msg)

    def _release_qgis_shortcuts(self, keys):
        """ปลดคีย์เดิมของ QGIS ที่ชน ผ่าน QgsShortcutsManager (บันทึกถาวร) -> set คีย์ที่ปลดได้"""
        released = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
        except Exception:
            return released
        for key in keys:
            seq = QtGui.QKeySequence(key)
            obj = None
            for getter in ("objectForSequence", "actionForSequence", "shortcutForSequence"):
                if hasattr(mgr, getter):
                    try:
                        obj = getattr(mgr, getter)(seq)
                    except Exception:
                        obj = None
                    if obj is not None:
                        break
            if obj is not None:
                try:
                    if mgr.setKeySequence(obj, ""):
                        released.add(key)
                except Exception:
                    pass
        return released

    def _qgis_shortcut_keys(self):
        """รวมคีย์ลัดที่ QGIS ใช้อยู่ (ไว้เตือนเมื่อตั้งคีย์ชนกันจน Qt ถือว่ากำกวม)"""
        keys = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
            for a in mgr.listActions():
                t = a.shortcut().toString()
                if t:
                    keys.add(t)
            for sc in mgr.listShortcuts():
                t = sc.key().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        try:
            for a in self.iface.mainWindow().findChildren(QtWidgets.QAction):
                t = a.shortcut().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        return keys

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.dlg.setWindowIcon(QtGui.QIcon(icon_path))
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro {self.version}")
        self.dlg.setMinimumWidth(360)
        root = QtWidgets.QVBoxLayout(self.dlg)
        root.setSpacing(6)

        def mkbtn(text, slot, style="", tip=""):
            b = QtWidgets.QPushButton(text)
            b.setStyleSheet(style or "padding:5px;")
            b.setFixedHeight(34)   # สูงเท่ากันทุกปุ่ม (กันไทย/Latin/emoji เรนเดอร์สูงไม่เท่า)
            if tip:
                b.setToolTip(tip)
            b.clicked.connect(slot)
            return b

        # ---------- ชั้นข้อมูล (กระทัดรัด) ----------
        grp_layer = QtWidgets.QGroupBox("ชั้นข้อมูล")
        gl = QtWidgets.QGridLayout(grp_layer)
        gl.setHorizontalSpacing(6)
        gl.setVerticalSpacing(4)
        gl.setColumnStretch(0, 0)   # label ชิดซ้าย ไม่ยืด
        gl.setColumnStretch(1, 1)   # combo ดูดพื้นที่ว่างทั้งหมด -> label ชิด combo
        self.poly_cb = QtWidgets.QComboBox()
        self.point_cb = QtWidgets.QComboBox()
        gl.addWidget(QtWidgets.QLabel("แปลง:"), 0, 0)
        gl.addWidget(self.poly_cb, 0, 1)
        gl.addWidget(QtWidgets.QLabel("หมุด:"), 1, 0)
        gl.addWidget(self.point_cb, 1, 1)
        btn_refresh = mkbtn("🔄", self.refresh_layers, tip="Refresh Layers")
        btn_refresh.setFixedWidth(36)
        gl.addWidget(btn_refresh, 0, 2, 2, 1)
        root.addWidget(grp_layer)
        self.refresh_layers()
        # สลับชั้นแปลง -> ติดตัวเฝ้ากับชั้นใหม่ด้วย
        try:
            self.poly_cb.currentIndexChanged.connect(self._arm_pair_watch)
        except Exception:
            pass

        # ---------- DOL search (คลิกแปลง -> เปิดเอกสาร) ----------
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn(
            "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image'),
            "background-color:#fff3e0; font-weight:bold; padding:8px; color:#e65100;"))
        r.addWidget(mkbtn(
            "📐 หลักฐานการรังวัด", lambda: self.start_dol_search('survey'),
            "background-color:#e3f2fd; font-weight:bold; padding:8px; color:#0d47a1;"))
        root.addLayout(r)

        # ---------- เลือก & ปรับแต่ง (หน้าเดียว) ----------
        grp_edit = QtWidgets.QGroupBox("เลือก / ปรับแต่ง")
        ve = QtWidgets.QVBoxLayout(grp_edit)
        ve.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("By Cluster ID", lambda: self.process_selection('cluster')))
        r.addWidget(mkbtn("By UTM", lambda: self.process_selection('utm')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Move", lambda: self.start_interactive('move')))
        r.addWidget(mkbtn("Rotate", lambda: self.start_interactive('rotate')))
        r.addWidget(mkbtn("Scale", lambda: self.start_interactive('scale')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Transform (2 จุด)", lambda: self.start_interactive('transform'),
                          "background-color:#ffccbc; font-weight:bold; padding:6px;"))
        r.addWidget(mkbtn("Move Node (Sync)", self.start_sync_vertex_tool,
                          "background-color:#e8f5e9; font-weight:bold; padding:6px;"))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("📏 Align Points", self.start_align_tool))
        r.addWidget(mkbtn("➕ Add Node", self.start_add_node,
                          "background-color:#e8f5e9; font-weight:bold; color:#1b5e20;"))
        ve.addLayout(r)
        root.addWidget(grp_edit)

        # ---------- จัดกลุ่ม / Score ----------
        grp_grp = QtWidgets.QGroupBox("จัดกลุ่ม / Score")
        vg = QtWidgets.QVBoxLayout(grp_grp)
        vg.setSpacing(5)
        vg.addWidget(mkbtn("🔗 Sync Cluster ID", self.group_cluster_ids,
                           "background-color:#e3f2fd; padding:6px;"))
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Score = 1", lambda: self.set_score_value(1),
                          "background-color:#c8e6c9; font-weight:bold; color:#1b5e20; padding:6px;"))
        r.addWidget(mkbtn("Score = 0", lambda: self.set_score_value(0),
                          "background-color:#ffcdd2; font-weight:bold; color:#b71c1c; padding:6px;"))
        vg.addLayout(r)
        root.addWidget(grp_grp)

        # ---------- แถบ action (เห็นตลอด) ----------
        r = QtWidgets.QHBoxLayout()
        btn_reset = mkbtn("✖ Reset", self.cancel_transform)
        btn_undo = mkbtn("↺ Undo", self.undo_transform)
        for _b in (btn_reset, btn_undo):
            _b.setFixedHeight(34)   # บังคับสูงเท่ากัน (กัน emoji เรนเดอร์ไม่เท่า)
            r.addWidget(_b, 1)
        root.addLayout(r)
        root.addWidget(mkbtn("💾 บันทึก (Commit)", self.save_all_changes,
                             "background-color:#c8e6c9; font-weight:bold; padding:8px; color:#1b5e20;"))

        # ---------- footer ----------
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        root.addWidget(line)
        rf = QtWidgets.QHBoxLayout()
        btn_sc = mkbtn("⌨ ตั้งค่า Shortcut", self.open_shortcut_settings)
        btn_up = mkbtn("🚀 Check Update", self.update_plugin)
        for _b in (btn_sc, btn_up):
            _b.setFixedHeight(34)   # สูงเท่ากัน
            rf.addWidget(_b, 1)     # stretch เท่ากัน -> กว้างเท่ากัน
        root.addLayout(rf)
        lbl = QtWidgets.QLabel("ชาคฤตย์ จันทรสุกศรี · กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        f = QtGui.QFont()
        f.setPointSize(8)
        lbl.setFont(f)
        lbl.setAlignment(QtCore.Qt.AlignCenter)
        root.addWidget(lbl)
        self._load_shortcuts()   # ผูก shortcut ที่บันทึกไว้

        # refresh combo เลเยอร์อัตโนมัติเมื่อโปรเจกต์เพิ่ม/ลบเลเยอร์ (disconnect ใน unload)
        proj = QgsProject.instance()
        for sig in (proj.layersAdded, proj.layersRemoved):
            try:
                sig.connect(self._project_layers_changed)
                self._signal_conns.append((sig, self._project_layers_changed))
            except Exception:
                pass

    # ============ DOL iLands: ค้นหาเอกสารจากแปลง ============
    def start_dol_search(self, mode='image'):
        """เปิด map tool คลิกเลือกแปลง -> mode 'image'=ภาพลักษณ์(public) / 'survey'=หลักฐานรังวัด(login)"""
        self._dol_mode = mode
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if lyr is None:
            QtWidgets.QMessageBox.warning(
                self.dlg, "ไม่พบเลเยอร์", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        try:
            if lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
                QtWidgets.QMessageBox.warning(
                    self.dlg, "เลเยอร์ไม่ถูกต้อง", f"เลเยอร์ '{lyr.name()}' ไม่ใช่ Polygon")
                return
        except Exception:
            pass
        self._dol_clear_highlight()
        canvas = self.iface.mapCanvas()
        # ล็อกให้คลิก/ไฮไลต์ได้เฉพาะแปลงในเลเยอร์ที่เลือกในปลั๊กอินเท่านั้น
        self.temp_tool = PolygonPickTool(
            canvas, lyr, self._on_polygon_picked, self._dol_on_hover)
        canvas.setMapTool(self.temp_tool)
        what = "ภาพลักษณ์" if mode == 'image' else "หลักฐานการรังวัด"
        self.iface.messageBar().pushInfo(
            "DOL", f"คลิกบนแปลงในเลเยอร์ '{lyr.name()}' เพื่อค้นหา{what} (Esc เพื่อยกเลิก)")

    def _on_polygon_picked(self, feat, layer):
        """อ่าน attribute UTM ของแปลงที่คลิก (จากเลเยอร์ที่เลือก) แล้วยิงค้นหา"""
        def gv(name):
            try:
                if feat.fields().indexOf(name) < 0:
                    return ""
                v = feat[name]
                return "" if v is None else str(v).strip()
            except Exception:
                return ""

        m1, m2, m3 = gv("UTMMAP1"), gv("UTMMAP2"), gv("UTMMAP3")
        m4 = gv("UTMMAP4") or "00"
        scale = gv("UTMSCALE")
        landno = gv("LANDNO")
        self.iface.actionSelect().trigger()  # คืน cursor ปกติ

        # ไฮไลต์แปลงที่คลิกทันที (กรอบแดง)
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

        if not m1 or not m2 or not m3 or not scale or not landno:
            self._dol_clear_highlight()
            QtWidgets.QMessageBox.warning(
                self.dlg, "ข้อมูลแปลงไม่ครบ",
                f"แปลงนี้ไม่มี attribute ระวางครบ\n"
                f"UTMMAP={m1} {m2} {m3} {m4} | SCALE={scale} | LANDNO={landno}")
            return

        # centroid ของแปลงที่คลิก (แปลงเป็น datum 24047) -> ใช้แก้ปัญหา "ระวางคร่อมสาขา"
        # ที่ LAND_NO ซ้ำข้ามสาขา (เลือกแปลงที่ใกล้จุดคลิกสุด แทนการหยิบตัวแรกมั่ว)
        near_xy = None
        try:
            c = feat.geometry().centroid().asPoint()
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            if layer.crs() != dst:
                c = QgsCoordinateTransform(layer.crs(), dst, QgsProject.instance()).transform(c)
            near_xy = (c.x(), c.y())
        except Exception:
            near_xy = None

        attrs = {"m1": m1, "m2": m2, "m3": m3, "m4": m4,
                 "scale": scale, "landno": landno, "near_xy": near_xy}
        self._dol_attrs = attrs   # เก็บไว้ใช้ค้นหลักฐานรังวัด (ต้องใช้ utmmap เดิม)

        self._dol_busy = QtWidgets.QProgressDialog(
            f"กำลังค้นหา PARCEL_SEQ...\nระวาง {m1} {m2} {m3}-{m4} ที่ดิน {landno}",
            None, 0, 0, self.dlg)
        self._dol_busy.setWindowTitle("DOL")
        self._dol_busy.setCancelButton(None)
        self._dol_busy.setWindowModality(QtCore.Qt.WindowModal)
        self._dol_busy.show()

        self._dol_worker = ParcelLookupWorker(attrs, zone=47)
        self._dol_worker.done.connect(self._on_dol_done)
        self._dol_worker.fail.connect(self._on_dol_fail)
        self._dol_worker.start()

    def _on_dol_done(self, res):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()  # รันเสร็จ -> ลบไฮไลต์
        if not res:
            QtWidgets.QMessageBox.information(
                self.dlg, "ไม่พบแปลง", "ไม่พบแปลงในระบบ (ตรวจเลขระวาง / zone UTM)")
            return

        if getattr(self, "_dol_mode", "image") == "survey":
            self._open_survey(res)
            return

        # ภาพลักษณ์ -> เปิดทันที (ไม่เด้ง popup)
        if res.get("doc_url"):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(res["doc_url"]))
        warn = "" if res.get("verified") else "  ⚠️ MAP_PARCEL_SEQ ไม่ตรง"
        if res.get("match_count", 1) > 1:
            warn += f"  🔀 ระวางคร่อม {res['match_count']} สาขา (เลือกใกล้จุดคลิกสุด)"
        self.iface.messageBar().pushMessage(
            "DOL", f"โฉนด {res.get('parcel_no')} | {res.get('office','')} "
                   f"({res.get('city','')}) — เปิดภาพลักษณ์แล้ว{warn}", level=3, duration=8)

    # ---------- ตัวช่วยรัน network ใน thread แยก (กัน QGIS ค้างเมื่อ server ช้า) ----------
    def _run_net(self, msg, fn, on_done, on_fail):
        """รัน fn (blocking network) ใน QThread + โชว์ progress dialog
        on_done(result) / on_fail(exception) ถูกเรียกบน main thread"""
        busy = QtWidgets.QProgressDialog(msg, None, 0, 0, self.dlg)
        busy.setWindowTitle("Multi-Layer Edit Pro")
        busy.setCancelButton(None)
        busy.setWindowModality(QtCore.Qt.WindowModal)
        busy.show()
        w = _FnWorker(fn)
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)   # กัน GC เก็บ worker ระหว่างรัน

        def _cleanup():
            busy.close()
            try:
                self._net_workers.remove(w)
            except ValueError:
                pass
            w.deleteLater()

        def _ok(res):
            _cleanup()
            on_done(res)

        def _err(e):
            _cleanup()
            on_fail(e)

        w.done.connect(_ok)
        w.fail.connect(_err)
        w.start()

    # ---------- หลักฐานการรังวัด (ต้อง login) ----------
    def _dol_ask_credentials(self):
        """popup ขอ user/pass (UI อย่างเดียว — network ไปทำใน thread แยก)
        -> (user, pass) หรือ None ถ้ายกเลิก/กรอกไม่ครบ"""
        dlg = QtWidgets.QDialog(self.dlg)
        dlg.setWindowTitle("เข้าสู่ระบบ DOL iLands")
        dlg.setMinimumWidth(320)
        form = QtWidgets.QFormLayout(dlg)
        ed_user = QtWidgets.QLineEdit()
        ed_pass = QtWidgets.QLineEdit()
        ed_pass.setEchoMode(QtWidgets.QLineEdit.Password)
        form.addRow("ผู้ใช้:", ed_user)
        form.addRow("รหัสผ่าน:", ed_pass)
        note = QtWidgets.QLabel("🔒 ไม่เก็บรหัสถาวร — ปิด QGIS แล้วต้องเข้าสู่ระบบใหม่")
        note.setStyleSheet("color:#666; font-size:11px;")
        form.addRow(note)
        bb = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        form.addRow(bb)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        ed_user.setFocus()
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return None
        u, p = ed_user.text().strip(), ed_pass.text()
        if not u or not p:
            return None
        return (u, p)

    def _cadastral_label(self, rec, i):
        """สร้างข้อความบรรยาย 1 รายการรังวัด (โชว์ field ที่มี)"""
        parts = []
        for k in ("CADASTRAL_NO", "CADASTRALNO", "SURVEY_NO", "SURVEYNO",
                  "TYPE_OF_SURVEY", "TYPEOFSURVEY", "SCALE", "SHEET_CODE",
                  "SHEETCODE", "SURVEY_DATE", "SURVEYDATE", "UTMMAP4"):
            v = rec.get(k)
            if v not in (None, "", "null"):
                parts.append(f"{k}={v}")
        label = " | ".join(parts) if parts else "(ไม่มีรายละเอียด)"
        return f"{i + 1}. {label}  [seq {rec.get('CADASTRAL_SEQ')}]"

    def _choose_cadastral(self, recs):
        """หลายรายการรังวัด -> popup ให้เลือก (คืน record หรือ None)"""
        items = [self._cadastral_label(rec, i) for i, rec in enumerate(recs)]
        item, ok = QtWidgets.QInputDialog.getItem(
            self.dlg, "เลือกหลักฐานการรังวัด",
            f"แปลงนี้มี {len(recs)} รายการ — เลือกที่ต้องการเปิด:", items, 0, False)
        if not ok:
            return None
        return recs[items.index(item)]

    def _open_survey(self, res):
        """ค้นหลักฐานรังวัดจากแปลงที่คลิก (login ถ้าจำเป็น) แล้วเปิด viewer; หลายรายการ -> ให้เลือก
        network ทั้งหมด (login + ค้นหา) รันใน thread แยกผ่าน _run_net — เดิม block UI สูงสุด 30 วิ"""
        from . import dol_api
        attrs = getattr(self, "_dol_attrs", {}) or {}
        prov = dol_api.province_code_from_city(res.get("city", ""))
        office = res.get("office_seq")
        if not prov or not office:
            known = " ".join(dol_api.PROVINCE_CODE.keys())
            QtWidgets.QMessageBox.warning(
                self.dlg, "หลักฐานการรังวัด",
                f"ยังไม่รองรับจังหวัดของแปลงนี้ ({res.get('city','')})\n"
                f"ปัจจุบันรองรับ: {known}\n"
                "(รหัสจังหวัดภายในระบบ DOL ไม่ตรงรหัสมาตรฐาน ต้องเก็บเพิ่มจากระบบจริง)")
            return
        self._survey_ctx = {"attrs": attrs, "prov": prov, "office": office, "retried": False}
        self._survey_step()

    def _survey_step(self):
        """ขั้น login: ถ้ายังไม่ login -> ขอรหัส (UI) แล้ว login ใน thread แยก จากนั้นค่อยค้นหา"""
        from . import dol_api
        if dol_api.is_logged_in():
            self._survey_search()
            return
        creds = self._dol_ask_credentials()
        if not creds:
            return
        u, p = creds
        self._run_net("กำลังเข้าสู่ระบบ DOL...",
                      lambda: dol_api.login(u, p),
                      lambda _s: self._survey_search(),
                      self._survey_login_failed)

    def _survey_login_failed(self, e):
        from . import dol_api
        if isinstance(e, dol_api.DOLAuthError):
            QtWidgets.QMessageBox.warning(self.dlg, "เข้าสู่ระบบไม่สำเร็จ", str(e))
        else:
            QtWidgets.QMessageBox.critical(self.dlg, "เข้าสู่ระบบผิดพลาด", str(e))

    def _survey_search(self):
        from . import dol_api
        ctx = self._survey_ctx
        a = ctx["attrs"]
        self._run_net(
            "กำลังค้นหาหลักฐานการรังวัด...",
            lambda: dol_api.search_cadastral(
                a.get("m1"), a.get("m2"), a.get("m3"), a.get("m4"),
                a.get("scale"), a.get("landno"), ctx["prov"], ctx["office"], zone=47),
            self._survey_show, self._survey_failed)

    def _survey_failed(self, e):
        from . import dol_api
        if isinstance(e, dol_api.DOLAuthError):
            dol_api.logout()
            ctx = self._survey_ctx
            if not ctx["retried"]:
                ctx["retried"] = True
                QtWidgets.QMessageBox.information(self.dlg, "เข้าสู่ระบบใหม่", str(e))
                self._survey_step()   # ขอ login ใหม่ แล้วค้นอีกครั้ง (retry ครั้งเดียวเหมือนเดิม)
                return
            QtWidgets.QMessageBox.warning(self.dlg, "หลักฐานการรังวัด", str(e))
        else:
            QtWidgets.QMessageBox.critical(self.dlg, "ค้นหารังวัดผิดพลาด", str(e))

    def _survey_show(self, recs):
        from . import dol_api
        ctx = self._survey_ctx
        a = ctx["attrs"]
        if not recs:
            QtWidgets.QMessageBox.information(
                self.dlg, "ไม่พบหลักฐานการรังวัด",
                "ไม่พบหลักฐานการรังวัดของแปลงนี้\n"
                f"(ค้นด้วยระวาง {a.get('m1')} {a.get('m2')} {a.get('m3')}-"
                f"{a.get('m4')} ที่ดิน {a.get('landno')} • สนง.{ctx['office']})")
            return
        rec = recs[0] if len(recs) == 1 else self._choose_cadastral(recs)
        if rec is None:
            return
        url = dol_api.survey_doc_url(rec.get("CADASTRAL_SEQ"), "1")
        QtGui.QDesktopServices.openUrl(QtCore.QUrl(url))
        self.iface.messageBar().pushMessage(
            "DOL", f"เปิดหลักฐานการรังวัด (พบ {len(recs)} รายการ) — "
                   f"CADASTRAL_SEQ {rec.get('CADASTRAL_SEQ')}", level=3, duration=8)

    def _on_dol_fail(self, msg):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()
        QtWidgets.QMessageBox.critical(self.dlg, "DOL ผิดพลาด", msg)

    def _dol_highlight_feature(self, geom, layer):
        """ไฮไลต์แปลงบนแผนที่ด้วยกรอบแดง"""
        self._dol_clear_highlight()
        if geom is None or geom.isEmpty():
            return
        canvas = self.iface.mapCanvas()
        rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(255, 0, 0))
        rb.setFillColor(QtGui.QColor(255, 0, 0, 50))
        rb.setWidth(3)
        rb.setToGeometry(geom, layer)
        rb.show()
        self._dol_highlight = rb
        # ไม่เรียก canvas.refresh() — rubber band วาดตัวเองอยู่แล้ว (เดิม refresh ทั้งแมพทุกครั้งที่ hover แปลง = หน่วง)

    def _dol_clear_highlight(self):
        rb = getattr(self, "_dol_highlight", None)
        if rb is not None:
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
            self._dol_highlight = None

    def _dol_on_hover(self, feat, layer):
        """ไฮไลต์แปลงใต้เมาส์ก่อนคลิก (ตัวช่วยตัดสินใจ)"""
        if feat is None:
            self._dol_clear_highlight()
            return
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                lyr.selectByIds(ids)
        self.iface.mapCanvas().refresh()

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def refresh_layers(self):
        # แปลง = เฉพาะเลเยอร์ Polygon, หมุด = เฉพาะเลเยอร์ Point
        prev = (self.poly_cb.currentData(), self.point_cb.currentData())
        self.poly_cb.clear(); self.point_cb.clear()
        self._field_cache.clear()   # รายชื่อเลเยอร์เปลี่ยน -> ล้าง cache field กันชื่อค้าง
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                gt = lyr.geometryType()   # มีเฉพาะ vector layer (raster -> error -> ข้าม)
            except Exception:
                continue
            if gt == QgsWkbTypes.PolygonGeometry:
                self.poly_cb.addItem(lyr.name(), lyr.id())
            elif gt == QgsWkbTypes.PointGeometry:
                self.point_cb.addItem(lyr.name(), lyr.id())
        # คงเลเยอร์ที่เลือกไว้เดิม (เดิม refresh แล้วเด้งกลับตัวแรกเสมอ)
        for cb, pid in zip((self.poly_cb, self.point_cb), prev):
            if pid:
                i = cb.findData(pid)
                if i >= 0:
                    cb.setCurrentIndex(i)
        self._arm_pair_watch()

    def _arm_pair_watch(self, *_a):
        """ติดตัวเฝ้า "มุมแปลงไม่มีหมุด" กับชั้นแปลงที่เลือก ตั้งแต่เปิดปลั๊กอิน
        (เดิม _watch_layer_editing ถูกเรียกเฉพาะตอนใช้เครื่องมือของปลั๊กอิน -> คนที่ใช้
        Vertex Tool ของ QGIS ล้วน ๆ แล้วกด Save ของ QGIS ไม่เคยถูกเฝ้าเลย = ช่องโหว่ตัวจริง)"""
        try:
            self._watch_layer_editing(
                QgsProject.instance().mapLayer(self.poly_cb.currentData()))
        except Exception:
            pass

    def _project_layers_changed(self, *_a):
        """เลเยอร์ในโปรเจกต์เพิ่ม/หาย -> refresh combo อัตโนมัติ (เดิมต้องกดปุ่ม 🔄 เอง)"""
        # เงาอ้างถึง layer ที่ cache ไว้ตอนคลิกแรก — ถ้าเลเยอร์นั้นเพิ่งถูกลบ
        # การวาดเฟรมถัดไปจะพังทุกครั้งที่ขยับเมาส์ (C++ object ถูกลบไปแล้ว) -> ทิ้งเงาก่อน
        self._preview_clear()
        if self.dlg is not None:
            try:
                self.refresh_layers()
            except Exception:
                pass
    def _ct_layers(self, exclude=()):
        """ชั้นหมุดหลักฐาน (CT / control point) ในโปรเจกต์ — เอาไว้ให้ snap ติดตอนแก้ไข
        หาแบบอัตโนมัติจากชื่อชั้น (ชั้นที่ส่งมอบชื่อ CT_<สาขา>; ต้นทางชื่อ <สาขา>_PointXY)
        เอาเฉพาะชั้นจุด และไม่ซ้ำกับชั้นที่เลือกไว้ในกล่องปลั๊กอินอยู่แล้ว
        (จำกัดด้วยชื่อ ไม่ใช่เอาทุกชั้นจุด — ไม่งั้นจะเสียประโยชน์ของการจำกัด snap เฉพาะชั้นทำงาน)"""
        out = []
        ex = {l.id() for l in exclude if l}
        try:
            for l in QgsProject.instance().mapLayers().values():
                if l.id() in ex:
                    continue
                try:
                    if l.geometryType() != QgsWkbTypes.PointGeometry:
                        continue
                except Exception:
                    continue        # raster/ชั้นที่ไม่มี geometryType
                n = l.name().strip().upper()
                if n.startswith("CT_") or n == "CT" or "POINTXY" in n.replace("_", ""):
                    out.append(l)
        except Exception:
            pass
        return out

    def setup_snapping(self):
        self.canvas = self.iface.mapCanvas()
        config = QgsProject.instance().snappingConfig()
        if not config.enabled():
            config.setEnabled(True)
            # ปรับความแรงในการดูด (Tolerance) เป็น 15-20 pixels
            config.setTolerance(20)
            config.setUnits(QgsTolerance.Pixels)
            # ให้ Snap ทั้งจุด (Vertex) และเส้น (Segment)
            config.setType(QgsSnappingConfig.VertexAndSegment)
        # จำกัด snap เฉพาะชั้นแปลง+หมุดที่เลือกในปลั๊กอิน — ต้องตั้ง "ทุกครั้ง" ไม่ใช่เฉพาะตอน snapping เริ่มปิด
        # (เดิมโค้ดก้อนนี้อยู่ใน `if not config.enabled():` -> ถ้าโปรเจกต์/ผู้ใช้เปิด snapping ค้างไว้อยู่แล้ว
        #  (ปกติเป็น AllLayers) จะถูกข้ามทั้งก้อน -> QGIS สร้าง snap index ทุกชั้นในวิว = ช้ามากบนชั้น
        #  PostgreSQL ใหญ่ และไม่ re-target เมื่อผู้ใช้สลับ combo เลเยอร์)
        work = [l for l in (QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                            QgsProject.instance().mapLayer(self.point_cb.currentData())) if l]
        work += self._ct_layers(exclude=work)   # + ชั้นหมุดหลักฐาน CT ให้ snap ติดด้วย
        try:
            if not work:
                raise ValueError("no working layers")
            config.setMode(QgsSnappingConfig.AdvancedConfiguration)
            ils = QgsSnappingConfig.IndividualLayerSettings(
                True, QgsSnappingConfig.VertexAndSegment, 20, QgsTolerance.Pixels)
            config.clearIndividualLayerSettings()   # ล้างชั้นของรอบก่อน (กันชั้นเก่าค้างเมื่อสลับ combo)
            for l in work:
                config.setIndividualLayerSettings(l, ils)
        except Exception:
            config.setMode(QgsSnappingConfig.AllLayers)   # fallback API รุ่นเก่า/ไม่มีเลเยอร์
        QgsProject.instance().setSnappingConfig(config)

        self.snap_utils = self.canvas.snappingUtils()
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        
    def start_interactive(self, mode):
        # 0. ล้างเงาตัวอย่างของรอบก่อน (ต้องอยู่ก่อน early-return ข้อ 2 ไม่งั้นเงาค้างจอ)
        self._preview_clear()

        # 1. เลือก UTM ก่อน
        self.process_selection('utm')

        # 2. เช็คว่ามีอะไรถูกเลือกไหม
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_lyr or poly_lyr.selectedFeatureCount() == 0:
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกแปลงที่ต้องการก่อน", level=2, duration=10)
            return

        # 3. เคลียร์ Marker เก่า (แต่ไม่เคลียร์ Selection!)
        self.clear_markers()
        self.src_pts = []
        
        # 4. ตั้งค่า Tool
        self.mode = mode
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.temp_tool.canvasMoveEvent = self.handle_generic_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

        # 5. บอกวิธีใช้ + บอกว่ามีเงาตัวอย่างให้ดูก่อนยืนยัน
        hint = {
            'move': "คลิกจุดอ้างอิง → เลื่อนเมาส์ดูเงาว่าแปลงจะไปตกที่ไหน → คลิกจุดปลายทางเพื่อยืนยัน",
            'rotate': "คลิกจุดหมุน → คลิกจุดอ้างอิง → เลื่อนเมาส์ดูเงา → คลิกยืนยันมุม",
            'scale': "คลิกจุดหมุน → คลิกจุดอ้างอิง → เลื่อนเมาส์ดูเงา → คลิกยืนยันขนาด",
        }.get(mode)
        if hint:
            self.iface.messageBar().pushInfo(mode.capitalize(), f"{hint} (คลิกขวา = ยกเลิก)")

    def handle_click(self, point, button):
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        
        # 2. เลือกพิกัด: ถ้า Snap ติดใช้จุด Snap ถ้าไม่ติดใช้ point (ที่ว่าง) ตรงๆ
        pt = match.point() if match.isValid() and match.point().x() != 0 else point
        
        # กำหนดสี Marker: Snap=แดง, ที่ว่าง=น้ำเงิน
        color = QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255)

        # 3. วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setPenWidth(4)
        m.setColor(color)
        m.setIconType(QgsVertexMarker.ICON_X)
        self.markers.append(m)
        self.src_pts.append(QgsPointXY(pt.x(), pt.y())) # บังคับเป็น PointXY

        # 3.5 คลิกแรกของรอบ = จังหวะเตรียมเงาตัวอย่าง (ดึง geometry ครั้งเดียวจบ)
        #     ดึงตอนนี้ ไม่ใช่ตอนกดปุ่ม: selection ณ ตอนนี้คือของจริงแน่นอน
        #     (หลัง execute_tool มี restore_selection ตาม timer 100ms — กว่าคนจะคลิกใหม่ก็คืนค่าแล้ว)
        if len(self.src_pts) == 1 and not self._preview_items:
            self._preview_arm()

        # 4. ตรวจสอบจำนวนจุดตามโหมด
        limit = _CLICK_LIMIT.get(self.mode, 2)

        if len(self.src_pts) >= limit:
            self.execute_tool()
            
    def handle_generic_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือทั่วไป (แก้ไข Error) + ขยับเงาตัวอย่าง Move/Rotate/Scale"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return

        match = self.snap_utils.snapToMap(event.mapPoint())
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            # แทนที่จะใส่ None ให้ใช้ Match ว่างๆ แทนครับ
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # จุดของเงา = สูตรเดียวกับ handle_click เป๊ะ (รวม .x() != 0) -> เงาอยู่ตรงที่คลิกจะลงจริง
        pt = match.point() if match.isValid() and match.point().x() != 0 else event.mapPoint()
        self._preview_update(QgsPointXY(pt.x(), pt.y()))

    # ============ เงาตัวอย่าง (preview) ของ Move/Rotate/Scale ============
    def _preview_arm(self):
        """เตรียมเงาของรอบนี้: ดึง geometry ที่เลือก "ครั้งเดียว" + สร้าง rubber band ต่อเลเยอร์

        เก็บ geom เป็น CRS ของเลเยอร์ดิบๆ ไม่แปลง เพราะ execute_tool ก็ไม่แปลง —
        เงาต้องเหมือนของจริงเป๊ะ ไม่ใช่ "ถูกกว่าของจริง" (ดู _preview_geom)
        ห้ามย้ายการดึงนี้ไปไว้ใน mouse-move: บน PostgreSQL = 1 query ต่อเฟรมต่อเลเยอร์
        ซึ่งเป็นปัญหาที่ 1.7.0 เพิ่งไล่แก้ทั้งรุ่น"""
        self._preview_clear()
        if self.mode not in _PREVIEW_MODES:
            return
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in (poly_lyr, point_lyr) if l and l.selectedFeatureCount() > 0]
        if not layers:
            return

        # แปลงล็อกตัดจบตั้งแต่คลิกแรก: execute_tool ปฏิเสธ L1-RTK/L1-TS แน่นอนอยู่แล้ว
        # -> โชว์เงาว่าขยับได้ทั้งที่สุดท้ายมันไม่ขยับ = เงาโกหก จึงไม่โชว์แล้วบอกเหตุผลไปเลย
        # (แค่บอกล่วงหน้า ไม่บล็อก — คนตัดสินใจจริงยังเป็น execute_tool เหมือนเดิมทุกประการ)
        locked = self._preview_locked_type(poly_lyr)
        if locked:
            self.iface.messageBar().pushMessage(
                "MLEP Lock",
                f"แปลงที่เลือกมีประเภท {locked} ซึ่งเป็นพิกัดอ้างอิง ขยับไม่ได้ — "
                "จะไม่มีเงาตัวอย่างให้ (คลิกครบจุดแล้วระบบจะปฏิเสธ)", level=1, duration=8)
            return

        canvas = self.iface.mapCanvas()
        proj_crs = QgsProject.instance().crs()
        srcs, total, warn_crs = [], 0, False
        for lyr in layers:
            # request ชุดเดียวกับ execute_tool -> เงาครอบ feature ชุดเดียวกับที่จะถูกแก้จริง
            req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
            parts = []
            for f in lyr.getFeatures(req):
                g = f.geometry()
                if g.isNull():
                    continue                    # ข้ามแบบเดียวกับ execute_tool
                # แตก multipart ให้เหลือชิ้นเดี่ยวล้วน -> ของที่ส่งเข้า collectGeometry ชนิดเดียวกันหมด
                parts.extend(g.asGeometryCollection() if g.isMultipart() else [QgsGeometry(g)])
            if not parts:
                continue
            if lyr.crs() != proj_crs:
                warn_crs = True
            # รวมเป็นก้อนเดียวต่อเลเยอร์ -> ต่อเฟรมเรียก C++ ครั้งเดียว ไม่ว่าจะเลือกกี่แปลง
            coll = QgsGeometry.collectGeometry(parts)
            if coll is None or coll.isNull():
                continue
            total += sum(1 for _ in coll.vertices())   # นับครั้งเดียวตอนนี้ ไม่ใช่ทุกเฟรม
            srcs.append((lyr, coll))

        # เลือกทั้งระวางแล้ว vertex บานปลาย -> ย่อเฉพาะ "ชั้นแปลง" เป็นกรอบรวม (convex hull)
        # ชั้นหมุดไม่ย่อ: 1 หมุด = 1 vertex ไม่ใช่ต้นเหตุความหน่วง และ hull ของหมุดจะกลายเป็นแผ่นทึบ
        heavy = total > _PREVIEW_VERTEX_BUDGET
        self._preview_heavy = heavy
        for lyr, coll in srcs:
            src = (coll.convexHull() if heavy and lyr.geometryType() == QgsWkbTypes.PolygonGeometry
                   else coll)
            if src is None or src.isNull():
                continue
            gtype = src.type()          # อ่านชนิดจาก geometry ตรงๆ -> band กับของที่ใส่ตรงกันเสมอ
            # ฟ้า (cyan) = สีเดียวที่ยังว่าง (แดง=Snap/DOL • น้ำเงิน=คลิกที่ว่าง • เหลือง=hover
            #  • แดงเข้ม=ล็อก • เขียว=เลือกแล้ว • ส้ม=vertex • ม่วง=snap หมุด)
            rb = QgsRubberBand(canvas, gtype)
            rb.setColor(QtGui.QColor(0, 200, 200))
            rb.setFillColor(QtGui.QColor(0, 200, 200, 45))
            rb.setWidth(2)
            if gtype == QgsWkbTypes.PointGeometry:
                rb.setIcon(QgsRubberBand.ICON_X)    # กากบาทให้เข้าชุดกับ Marker ตอนคลิก
                rb.setIconSize(8)
            rb.show()
            self._preview_items.append((lyr, src, rb, gtype))

        # จดว่าเงารอบนี้เป็นของเครื่องมือตัวไหน — ต้องอยู่หลัง setMapTool ของ start_interactive
        # (ตอนนี้ถูกเรียกจากคลิกแรกอยู่แล้ว จึงพ้นจังหวะนั้นแน่นอน) ดู _map_tool_changed
        if self._preview_items:
            self._preview_tool = self.temp_tool

        if warn_crs:
            # เงาจะลอยหลุดจอ — ไม่ใช่บั๊กของเงา แต่เป็นของ execute_tool ที่เอาค่าพิกัดโปรเจกต์
            # ไปบวกกับ geometry ของเลเยอร์ตรงๆ โดยไม่แปลง CRS (ของจริงก็จะเหวี่ยงแบบเดียวกัน)
            # ห้าม "แก้" ด้วยการใส่ QgsCoordinateTransform แค่ในเงา -> เงาถูก ของจริงผิด = แย่กว่าเดิม
            self.iface.messageBar().pushMessage(
                "MLEP", "เลเยอร์กับโปรเจกต์คนละระบบพิกัด (CRS) — เครื่องมือชุดนี้ไม่แปลง CRS "
                        "ทั้งเงาตัวอย่างและผลจริงจะคลาดเคลื่อนเหมือนกัน ควรตั้ง CRS ให้ตรงกันก่อน",
                level=1, duration=15)

    def _preview_locked_type(self, poly_lyr):
        """คืน 'L1-RTK' / 'L1-TS' ถ้าแปลงที่เลือกมีตัวที่ถูกล็อก • '' ถ้าไม่มี
        คิวรีเดียว NoGeometry ชุดเดียวกับ execute_tool — ยิงตอนคลิกแรกเท่านั้น ไม่ใช่ทุกเฟรม"""
        if not poly_lyr:
            return ""
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        ids = poly_lyr.selectedFeatureIds()
        if type_idx == -1 or not ids:
            return ""
        req = (QgsFeatureRequest().setFilterFids(ids)
               .setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([type_idx]))
        found = ""
        for f in poly_lyr.getFeatures(req):
            val = f.attribute(type_idx)
            if val is None:
                continue
            v = str(val).strip().upper()
            if v == "L1-RTK":
                return v            # เข้มสุด -> ตัดจบเลย
            if v == "L1-TS":
                found = v
        return found

    def _preview_geom(self, src, cur):
        """คำนวณ geometry ของเงา 1 ก้อน: copy จาก src แล้วแปลงตามตำแหน่งเมาส์ cur

        สูตรทุกบรรทัดลอกจาก execute_tool มาทั้งดุ้น รวมถึง "การไม่แปลง CRS" ด้วย —
        ตั้งใจให้เหมือนของจริงทุกกรณี ไม่ใช่ให้ถูกตามหลักการ ถ้าของจริงเพี้ยน เงาต้องเพี้ยนตาม
        ไม่งั้นเงาจะโกหกว่าผลลัพธ์จะออกมาดี"""
        p = self.src_pts
        g = QgsGeometry(src)   # copy ก่อนแตะ — QgsGeometry เป็น copy-on-write ต้นฉบับใน cache ไม่กระทบ

        # --- 1. Move ---
        if self.mode == 'move':
            g.translate(cur.x() - p[0].x(), cur.y() - p[0].y())

        # --- 2. Rotate (ลบหน้ามุมตามของจริง) ---
        #     ห้ามแก้เครื่องหมาย และห้ามเขียนใหม่ด้วย QTransform:
        #     QgsGeometry.rotate บวก = ตามเข็ม แต่ QTransform.rotate บวก = ทวนเข็ม (ตรงข้ามกัน)
        #     -> ถ้าเปลี่ยนมาใช้ QTransform โดยไม่พลิกเครื่องหมาย เงาจะหมุนกลับทางกับของจริง
        elif self.mode == 'rotate':
            a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
            a2 = math.atan2(cur.y()-p[0].y(), cur.x()-p[0].x())
            g.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))

        # --- 3. Scale ---
        elif self.mode == 'scale':
            d1 = math.sqrt(p[0].sqrDist(p[1]))
            d2 = math.sqrt(p[0].sqrDist(cur))
            if d1 > 0:      # d1 == 0 -> ของจริงข้าม changeGeometry ทั้งก้อน -> เงาต้องนิ่งที่เดิม
                s = d2 / d1
                # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                g.translate(-p[0].x(), -p[0].y())
                matrix = QtGui.QTransform(); matrix.scale(s, s)
                g.transform(matrix)
                g.translate(p[0].x(), p[0].y())
                # s == 0 (เมาส์ทับ p0) ของจริงยุบแปลงเป็นจุด -> เงาต้องยุบตาม ห้ามใส่ guard เพิ่ม
        return g

    def _preview_update(self, cur):
        """ขยับเงาตามเมาส์ — ถูกเรียกทุกเฟรม
        ห้ามยิง query และห้ามเรียก canvas.refresh() ในนี้ (rubber band วาดตัวเองอยู่แล้ว)
        ใช้แต่ geometry ที่ cache ไว้ตอน _preview_arm"""
        if not self._preview_items:
            return                       # ยังไม่คลิกแรก / โหมดไม่มีเงา / แปลงล็อก
        need = _CLICK_LIMIT.get(self.mode, 2) - 1
        if self.mode not in _PREVIEW_MODES or len(self.src_pts) != need:
            self._preview_hide()         # คลิกยังไม่พอ -> ไม่มีเงา
            return
        # snap ดูดในรัศมี 20 px -> เมาส์ขยับหลายพิกเซลแล้วได้จุดเดิม ไม่ต้องวาดซ้ำ
        key = (self.mode, cur.x(), cur.y())
        if key == self._preview_last:
            return
        self._preview_last = key
        for lyr, src, rb, _gt in self._preview_items:
            # ส่ง lyr เข้าไปด้วย -> band แปลง CRS เลเยอร์->จอ แบบเดียวกับที่ renderer ทำตอน commit
            rb.setToGeometry(self._preview_geom(src, cur), lyr)
        self._preview_msg(cur)

    def _preview_hide(self):
        """ซ่อนเงาชั่วคราว (คลิกยังไม่ครบ) โดยไม่ทิ้ง band/cache -> ไม่ต้องดึง geometry ใหม่
        _preview_last is None = ไม่มีเงาบนจออยู่แล้ว -> ออกเลย (กันทำงานซ้ำทุกเฟรมก่อนคลิกแรก)"""
        if self._preview_last is None:
            return
        for _lyr, _src, rb, gt in self._preview_items:
            try:
                rb.reset(gt)
            except Exception:
                pass
        self._preview_last = None
        self._preview_msg(None)

    def _preview_clear(self):
        """ลบเงาออกจากจอ + ทิ้ง cache — เรียกซ้ำได้เสมอ ปลอดภัยแม้ยังไม่เคยมีเงา
        ไม่แตะ layer ที่ cache ไว้เลย (แตะแค่ rubber band) -> เรียกตอนเลเยอร์ถูกลบไปแล้วก็ปลอดภัย"""
        had = bool(getattr(self, "_preview_items", [])) or self._preview_last is not None
        for _lyr, _src, rb, _gt in getattr(self, "_preview_items", []):
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
        self._preview_items = []
        self._preview_last = None
        self._preview_tool = None
        self._preview_heavy = False
        # ล้างแถบสถานะเฉพาะตอนที่เราเคยเขียนไว้จริง — สลับเครื่องมือตอนไม่ได้ใช้ปลั๊กอิน
        # ไม่ควรไปลบข้อความของ QGIS/ปลั๊กอินอื่นที่ค้างอยู่
        if had:
            self._preview_msg(None)

    def _preview_msg(self, cur):
        """ตัวเลขกำกับเงา (ระยะ/มุม/สเกล) -> แถบสถานะ • cur=None = ล้างข้อความ
        ไม่ใช้ message bar เพราะจะเด้ง widget ใหม่ทุกเฟรม — bar สงวนไว้ให้ตอนคลิก/จบงาน/error"""
        try:
            bar = self.iface.statusBarIface()
            if bar is None:
                return
            p = self.src_pts
            txt = ""
            if cur is None:
                pass
            elif self.mode == 'move' and len(p) >= 1:
                txt = f"Move: เลื่อน {math.sqrt(p[0].sqrDist(cur)):.3f} ม."
            elif self.mode == 'rotate' and len(p) >= 2:
                a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                a2 = math.atan2(cur.y()-p[0].y(), cur.x()-p[0].x())
                deg = (math.degrees(a2 - a1) + 180) % 360 - 180   # คุมช่วงเป็น -180..180 อ่านง่าย
                txt = f"Rotate: หมุน {deg:+.4f}° (+ = ทวนเข็มนาฬิกา)"
            elif self.mode == 'scale' and len(p) >= 2:
                d1 = math.sqrt(p[0].sqrDist(p[1]))
                d2 = math.sqrt(p[0].sqrDist(cur))
                txt = (f"Scale: สเกล {d2/d1:.6f} ({d1:.3f} → {d2:.3f} ม.)" if d1 > 0
                       else "Scale: จุดอ้างอิงทับจุดหมุน — ปรับสเกลไม่ได้ (คลิกขวา = ยกเลิก)")
            # เงาถูกย่อ -> บอกไปตรงๆ ไม่งั้นผู้ใช้เห็นกรอบแทนแปลงแล้วนึกว่าเสีย
            if txt and self._preview_heavy:
                txt += "  •  เงาย่อเป็นกรอบรวม (แปลงเยอะ) — ผลจริงยังแก้ครบทุกแปลง"
            bar.showMessage(txt)
        except Exception:
            pass   # แถบสถานะเป็นของแถม — หายไปได้ ขอแค่เงายังทำงาน

    def execute_tool(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        
        if not layers:
            self.cancel_transform()
            return
            
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self.last_layers = layers
        p = self.src_pts

        # ─── ตรวจสอบกฎการล็อกแปลง L1-RTK / L1-TS ───
        if poly_lyr:
            type_idx = self._field_index(poly_lyr.fields(), 'type')
            if type_idx != -1:
                poly_ids = poly_lyr.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_lyr.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str == "L1-RTK":
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-RTK ซึ่งเป็นพิกัดอ้างอิงหลัก ไม่สามารถขยับได้!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return
                            elif val_str == "L1-TS":
                                # ยกเว้นกรณีใช้ปุ่ม transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                                if self.mode == 'transform' and len(p) >= 4:
                                    p2, p4 = p[1], p[3]
                                    if self._is_point_on_rtk_node(poly_lyr, p2) and self._is_point_on_rtk_node(poly_lyr, p4):
                                        continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                                        
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-TS ไม่สามารถขยับได้ ยกเว้นใช้โหมด Transform (2 Pts) ไปต่อกับ L1-RTK เท่านั้น!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return

        # ตรวจสอบสิทธิ์การขยับพิกัดผ่านจุดหมุด (กรณีจุดหมุดถูกเลือก)
        if point_lyr and point_lyr.selectedFeatureCount() > 0 and poly_lyr:
            # ตาราง UTM ล็อกทั้งหมดในคิวรีเดียว (เดิม query ต่อค่า UTM — N round-trips บน PostgreSQL)
            locked_map = self._locked_utm_map(poly_lyr)
            for pt_f in (point_lyr.selectedFeatures() if locked_map else []):
                is_locked, type_str = self._is_point_feature_locked(pt_f, locked_map)
                if is_locked:
                    # ข้อยกเว้นเฉพาะโหมด transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                    if type_str == "L1-TS" and self.mode == 'transform' and len(p) >= 4:
                        p2, p4 = p[1], p[3]
                        if self._is_point_on_rtk_node(poly_lyr, p2) and self._is_point_on_rtk_node(poly_lyr, p4):
                            continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                            
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return
                    else:
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return

        # เปิด edit ทั้งเลเยอร์แปลง+หมุดที่ตั้งค่าไว้ แยกจากเงื่อนไข selection
        # (แก้: บางทีหมุดไม่ถูกเลือก -> point layer ไม่ขึ้น edit)
        for _l in (poly_lyr, point_lyr):
            if _l and not _l.isEditable():
                _l.startEditing()

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            lyr.beginEditCommand(f"MLEP {self.mode}")
            
            try:
                # Optimize: ดึงเฉพาะ Geometry และรวบรวมเป็น list ก่อนวนลูปแก้ไข เพื่อป้องกันปัญหา cursor ล็อกขณะเขียนข้อมูล
                req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
                features = list(lyr.getFeatures(req))
                for f in features:
                    geom = f.geometry()
                    if geom.isNull(): continue

                    # --- 1. Move ---
                    if self.mode == 'move' and len(p) >= 2:
                        dx, dy = p[1].x() - p[0].x(), p[1].y() - p[0].y()
                        geom.translate(dx, dy)
                        lyr.changeGeometry(f.id(), geom)

                    # --- 2. Rotate (ใส่ลบหน้ามุมตามที่ตกลงกัน) ---
                    elif self.mode == 'rotate' and len(p) >= 3:
                        a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                        a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
                        geom.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))
                        lyr.changeGeometry(f.id(), geom)

                    # --- 3. Scale (ปรับใหม่ให้ชัวร์) ---
                    elif self.mode == 'scale' and len(p) >= 3:
                        d1 = math.sqrt(p[0].sqrDist(p[1]))
                        d2 = math.sqrt(p[0].sqrDist(p[2]))
                        if d1 > 0:
                            s = d2 / d1
                            # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                            geom.translate(-p[0].x(), -p[0].y())
                            matrix = QtGui.QTransform(); matrix.scale(s, s)
                            geom.transform(matrix)
                            geom.translate(p[0].x(), p[0].y())
                            lyr.changeGeometry(f.id(), geom)

                    # --- 4. Transform ---
                    elif self.mode == 'transform' and len(p) >= 4:
                        self.apply_similarity_direct(lyr, f, p)

                    # --- 5. Move Node (Optimized via C++ closestVertex) ---
                    elif self.mode == 'modify_node' and len(p) >= 2:
                        closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(p[0])
                        if sqr_dist < 0.000001:  # threshold 0.001 (sqrDist = 0.001 ** 2)
                            if vertex_idx >= 0:
                                lyr.moveVertex(p[1].x(), p[1].y(), f.id(), vertex_idx)
                
                lyr.endEditCommand()
            except Exception as e:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("MLEP Error", f"เกิดข้อผิดพลาดใน {lyr.name()}: {e}", level=2, duration=0)
                print(f"Error in execute_tool for layer {lyr.name()}: {e}")

        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        self.iface.mapCanvas().refresh()
        self.clear_markers()
        # ทิ้งเงา (geometry ใน cache เป็นของก่อนแก้ = ล้าสมัยแล้ว)
        # ไม่ขยับ cache ตามสูตรที่เพิ่งแก้ เพราะถ้า changeGeometry ล้มเหลวเงียบๆ เงาจะโกหกทันที
        # -> คลิกแรกของรอบหน้าไปดึงของจริงมาใหม่ ช้ากว่านิดเดียว (1 คิวรีต่อรอบ) แต่ไม่มีทางโกหก
        self._preview_clear()
        self.src_pts = []
        if self.mode == 'transform' :
            self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def apply_similarity_direct(self, lyr, f, p):
        """คำนวณ Transform แบบ Matrix (Similarity)"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        # x' = ax - by + tx , y' = bx + ay + ty
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        lyr.changeGeometry(f.id(), geom)

    @staticmethod
    def _field_index(fields, names):
        """index ของฟิลด์แรกที่ชื่อ (ตัวพิมพ์เล็ก) อยู่ใน names; -1 ถ้าไม่พบ
        names = str (ชื่อเดียว) หรือ set ของชื่อ"""
        if isinstance(names, str):
            names = {names}
        for i, f in enumerate(fields):
            if f.name().lower() in names:
                return i
        return -1

    def _is_point_on_rtk_node(self, poly_lyr, point_xy):
        """ตรวจสอบว่าพิกัด point_xy อยู่บน Node ของแปลงประเภท L1-RTK หรือไม่"""
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        if type_idx == -1:
            return False

        # สี่เหลี่ยมตรงๆ (เลี่ยง buffer() ที่สร้าง geometry วงกลมทิ้ง)
        search_rect = QgsRectangle(point_xy.x() - 0.05, point_xy.y() - 0.05,
                                   point_xy.x() + 0.05, point_xy.y() + 0.05)
        # ดึง geometry มาในคิวรีเดียว (เดิม query แบบ NoGeometry แล้วค่อย getFeature ซ้ำต่อ candidate)
        req = QgsFeatureRequest().setFilterRect(search_rect).setSubsetOfAttributes([type_idx])
        for feat in poly_lyr.getFeatures(req):
            val = feat.attribute(type_idx)
            if val is not None and str(val).strip().upper() == "L1-RTK":
                geom = feat.geometry()
                if geom and not geom.isNull():
                    _cp, vertex_idx, _pi, _ni, sqr_dist = geom.closestVertex(point_xy)
                    if sqr_dist < 0.0025:  # 0.05 ** 2
                        return True
        return False

    def _locked_utm_map(self, poly_lyr):
        """ดึงค่า UTM ของแปลงล็อก (L1-RTK/L1-TS) ทั้งเลเยอร์ใน "คิวรีเดียว" -> dict {utm: type}
        filter ฝั่ง server + NoGeometry — แทนการยิง query เทียบ UTM ต่อหมุด/ต่อค่า
        (บน PostgreSQL เดิมคือ 1 round-trip ต่อค่า UTM ที่ไม่ซ้ำ → เหลือ 1 ครั้งต่อ operation)
        ถ้า UTM เดียวกันมีทั้ง L1-RTK และ L1-TS จะเก็บ L1-RTK (เข้มกว่า)

        CACHE ต่อ edit-session: คิวรีนี้ดึงแปลงล็อก "ทั้งอำเภอ" (ปทุม 90,691 / คลองหลวง 69,284 แถว) และถูกเรียกใหม่
        ทุก gesture — ทุกครั้งที่ลากกล่อง Move Node, ทุก commit Move/Rotate/Scale, ทุก commit Align — บน PostgreSQL
        คือ scan ตารางใหญ่ + ส่งข้ามเน็ตซ้ำๆ. ตาราง UTM ล็อกจะเปลี่ยนได้ก็ต่อเมื่อคอลัมน์ Type เปลี่ยน ซึ่ง
        พนักงานไม่มีสิทธิ์แก้ (GRANT UPDATE เฉพาะ geom/SCORE/REMARK/cluster_id) และมีแต่ pipeline ที่เขียน
        -> ดึงครั้งเดียวพอ. ล้าง cache เมื่อเลเยอร์ commit/rollback/เปิดแก้ใหม่ (ดู _watch_layer_editing)"""
        _lid = poly_lyr.id() if poly_lyr else None
        _c = getattr(self, "_locked_cache", None)
        if _c is not None and _c.get("lid") == _lid:
            return _c["map"]
        utm_field = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        type_field = self._resolve_field(poly_lyr, {'type'})
        if not utm_field or not type_field:
            return {}
        fields = poly_lyr.fields()
        u_idx = fields.indexFromName(utm_field)
        t_idx = fields.indexFromName(type_field)
        expr = (f"upper(trim({QgsExpression.quotedColumnRef(type_field)})) "
                "IN ('L1-RTK','L1-TS')")
        req = (QgsFeatureRequest().setFilterExpression(expr)
               .setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([u_idx, t_idx]))
        locked = {}
        for f in poly_lyr.getFeatures(req):
            u, t = f.attribute(u_idx), f.attribute(t_idx)
            if u is None or t is None:
                continue
            key = _norm_utm(u)
            t_str = str(t).strip().upper()
            if t_str == "L1-RTK" or key not in locked:
                locked[key] = t_str
        self._locked_cache = {"lid": _lid, "map": locked}   # ใช้ซ้ำทั้ง session (ล้างตอน commit/rollback/เริ่มแก้)
        self._watch_layer_editing(poly_lyr)                 # ให้แน่ใจว่ามี signal มาล้าง cache
        return locked

    def _is_point_feature_locked(self, point_f, locked_map):
        """ตรวจสอบว่าหมุดนี้เชื่อมโยงกับแปลงที่ถูกล็อก (L1-RTK/L1-TS) ผ่านฟิลด์ UTM
        locked_map: dict {utm: type} จาก _locked_utm_map (prefetch คิวรีเดียวต่อ operation)"""
        if not locked_map:
            return False, None
        point_utm_field = next(
            (f.name() for f in point_f.fields()
             if f.name().lower() in _UTM_FIELD_NAMES),
            None
        )
        if not point_utm_field:
            return False, None
        utm_val = point_f[point_utm_field]
        if utm_val is None:
            return False, None
        t = locked_map.get(_norm_utm(utm_val))
        return (True, t) if t else (False, None)

    def set_score_value(self, value):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย score จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())

        # ตรวจสอบกฎการห้ามใส่ Score ให้กับแปลง L1-RTK และ L1-TS
        if poly_layer:
            type_idx = self._field_index(poly_layer.fields(), 'type')
            if type_idx != -1:
                poly_ids = poly_layer.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_layer.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str in ("L1-RTK", "L1-TS"):
                                self.iface.messageBar().pushMessage(
                                    "Score Blocked", 
                                    f"แปลง {f.id()} เป็นประเภท {val_str} ไม่อนุญาตให้ตั้งค่า Score!", 
                                    level=2, duration=10
                                )
                                return
                                
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return

        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            # ตรวจสอบว่าเลเยอร์อยู่ในโหมดแก้ไขหรือไม่
            if not lyr.isEditable():
                lyr.startEditing()
            
            # เริ่มบันทึกคำสั่งสำหรับ Undo
            lyr.beginEditCommand(f"Change Score to {value}")
            try:
                # ค้นหา index ของฟิลด์ Score
                idx = -1
                for i, field in enumerate(lyr.fields()):
                    if field.name().lower() == 'score':
                        idx = i
                        break
                
                if idx != -1:
                    # Optimize: วนลูปแก้เฉพาะค่า Attribute ผ่าน ID โดยตรงเพื่อความรวดเร็วและใช้แรมน้อย
                    for fid in lyr.selectedFeatureIds():
                        lyr.changeAttributeValue(fid, idx, value)
                    lyr.endEditCommand() # ปิดคำสั่ง (จะถูกส่งเข้า Undo Stack ของ QGIS)
                else:
                    lyr.destroyEditCommand()
                    self.iface.messageBar().pushMessage("Error", f"ไม่พบฟิลด์ Score ใน {lyr.name()}", level=2, duration=0)
            except Exception as e:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"Error Change Score: {e}", level=2, duration=0)

        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def group_cluster_ids(self):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย cluster id จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        fields = [f.name() for f in poly_layer.fields()]
        target_field = next((f for f in fields if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
        if not target_field: return
        
        # Optimize: ดึงค่าเฉพาะ Attribute ฟิลด์แรกที่เลือกโดยไม่ต้องดึงพิกัดเพื่อประหยัดหน่วยความจำ
        first_id = poly_layer.selectedFeatureIds()[0]
        f_idx = poly_layer.fields().indexFromName(target_field)
        req = QgsFeatureRequest().setFilterFid(first_id).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([f_idx])
        first_feat = next(poly_layer.getFeatures(req), None)
        if not first_feat: return
        main_val = first_feat[target_field]

        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์ (เดิมไม่ track -> undo เพี้ยน)
        for lyr in layers:
            if not lyr.isEditable():
                lyr.startEditing()
            lyr.beginEditCommand("Group Cluster ID")
            try:
                lyr_f = [f.name() for f in lyr.fields()]
                lyr_t = next((f for f in lyr_f if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
                if lyr_t:
                    idx = lyr.fields().indexFromName(lyr_t)
                    # Optimize: แก้ไขเฉพาะค่า Attribute ผ่าน IDs โดยตรง
                    for fid in lyr.selectedFeatureIds():
                        lyr.changeAttributeValue(fid, idx, main_val)
                lyr.endEditCommand()
            except Exception as e:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"Error Group Cluster ID: {e}", level=2, duration=0)
        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        """ล้างค่าหน้าจอและทำลายตัวช่วย Snap อย่างปลอดภัย"""
        if hasattr(self, 'snap_indicator') and self.snap_indicator:
            # ล้างสัญลักษณ์บนหน้าจอก่อนทำลาย Object
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            self.snap_indicator = None

        self.clear_rubber_band()
        self._preview_clear()
        self._dol_clear_highlight()
        self._align_picked_ids = set()
        self._align_clear_highlight()
        
        # รีเซ็ตเครื่องมือ Semi-Auto (ถ้ามี)
        if hasattr(self, 'temp_tool') and self.temp_tool:
            if hasattr(self.temp_tool, 'reset_tool'):
                try:
                    self.temp_tool.reset_tool()
                except Exception:
                    pass

        if hasattr(self, 'markers'):
            for m in self.markers:
                if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []
        self.src_pts = []

        # ล้าง feature ที่ถูกเลือกไว้ในทุกเลเยอร์ของ QGIS
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if isinstance(lyr, QgsVectorLayer) and lyr.selectedFeatureCount():
                    lyr.removeSelection()
            except Exception:
                pass

        self.iface.mapCanvas().refresh()
        self.iface.actionSelect().trigger()

    # ============ ระบบ Undo: นับ undo-command ต่อเลเยอร์ ต่อ operation ============
    def _watch_layer_editing(self, lyr):
        """ต่อ signal commit/rollback ของเลเยอร์ (ครั้งเดียวต่อเลเยอร์) เพื่อรู้ว่าตอนปิด edit
        กด Save (commit) หรือ Discard (rollback) — ใช้ตัดสินตอน undo เจอเลเยอร์ที่ถูกปิด"""
        if lyr is None:
            return
        lid = lyr.id()
        if lid in self._signal_layers:
            return
        self._signal_layers.add(lid)

        # ทุก signal ล้าง cache ตาราง UTM ล็อกด้วย (_locked_utm_map) — กันค่าค้างข้าม session แก้ไข
        # ★ ทุก slot ต้องรับ *_a ทิ้ง: QGIS 3.32+ ส่ง argument มากับ beforeCommitChanges(bool)
        #   ถ้าไม่รับ PyQt จะยัดเป็น positional แรก -> ทับ default _lid (กลายเป็น True) -> guard พังเงียบ ๆ
        def on_commit(*_a, _lid=lid):
            self._edit_end[_lid] = 'commit'
            self._locked_cache = None

        def on_rollback(*_a, _lid=lid):
            self._edit_end[_lid] = 'rollback'
            self._locked_cache = None

        def on_start(*_a, _lid=lid):
            self._edit_end.pop(_lid, None)   # เปิด edit ใหม่ -> ล้างสถานะเก่า
            self._locked_cache = None
            self._pending_pair_warn = None

        # ---- เฝ้า "มุมแปลงไม่มีหมุด" ทุกช่องทางที่บันทึก ----
        # ปุ่ม Save ของปลั๊กอินถามก่อนบันทึกได้ (ยับยั้งได้จริง) แต่ Save Layer Edits /
        # ปิดโหมดแก้ไข ของ QGIS เอง ไม่ผ่านโค้ดเรา -> เดิมข้ามด่านไปทั้งหมด
        # QGIS ไม่มีกลไกให้ปลั๊กอิน "ยกเลิก" การ commit (beforeCommitChanges เป็น signal เปล่า
        # ยับยั้งไม่ได้ และไม่มี setAllowCommit) -> ทำได้ดีที่สุดคือ "ตรวจก่อน เตือนทันทีหลัง"
        def on_before_commit_check(*_a, _lid=lid):
            """ตรวจตอน buffer ยังอยู่ แต่ยังไม่เปิด dialog (ห้ามเด้ง UI ระหว่าง commit)"""
            self._pending_pair_warn = None
            try:
                if self._pair_warn_ack:
                    return                      # ปุ่มปลั๊กอินถามไปแล้ว ผู้ใช้ตอบ "บันทึกต่อ"
                poly = QgsProject.instance().mapLayer(self.poly_cb.currentData())
                if poly is None or poly.id() != _lid:
                    return                      # ไม่ใช่ชั้นแปลงที่เลือกอยู่ -> ไม่เกี่ยว
                point = QgsProject.instance().mapLayer(self.point_cb.currentData())
                iss = self._pairing_issues(poly, point)
                if iss and iss[0]:
                    self._pending_pair_warn = iss
            except Exception:
                pass                            # ตรวจไม่ได้ -> อย่าไปขวางการบันทึก

        def on_after_commit_warn(*_a, _lid=lid):
            """บันทึกไปแล้ว (ยับยั้งไม่ได้) -> เตือนทันทีพร้อมบอกวิธีแก้"""
            iss = self._pending_pair_warn
            self._pending_pair_warn = None
            if not iss:
                return
            try:
                bad, checked, sample = iss
                self.iface.messageBar().pushMessage(
                    "⚠️ มุมแปลงไม่มีหมุด",
                    f"บันทึกไปแล้ว {bad:,} มุม (จาก {checked:,} ที่ตรวจ) ไม่มีหมุดของแปลงเดียวกันทับอยู่ "
                    "— ดูรายละเอียดในหน้าต่างที่เด้งขึ้น", level=2, duration=0)
                lines = "\n".join("• " + s for s in sample)
                QtWidgets.QMessageBox.warning(
                    self.dlg or self.iface.mainWindow(), "บันทึกแล้ว แต่พบมุมแปลงที่ไม่มีหมุด",
                    f"บันทึกลงฐานข้อมูลเรียบร้อยแล้ว แต่ตรวจพบ {bad:,} มุม "
                    f"(จาก {checked:,} มุมที่ตรวจ) ที่ไม่มีหมุดของแปลงเดียวกันทับอยู่\n\n{lines}\n\n"
                    "สาเหตุที่พบบ่อยที่สุด:\n"
                    "• ใช้เครื่องมือ Vertex Tool / แก้รูปร่าง ของ QGIS เพิ่มมุมแปลงโดยตรง\n"
                    "  → เครื่องมือของ QGIS ไม่สร้างหมุดให้ ต้องใช้ปุ่ม \"➕ Add Node\" ของปลั๊กอินเท่านั้น\n"
                    "• กด Undo ของ QGIS (เมนู Edit / แถบเครื่องมือ) ซึ่งย้อนแค่ชั้นเดียว\n\n"
                    "วิธีแก้: ใช้ \"➕ Add Node\" เพิ่มหมุดที่มุมเหล่านั้น แล้วบันทึกอีกครั้ง")
            except Exception:
                pass

        for sig_name, slot in (("beforeCommitChanges", on_before_commit_check),
                               ("afterCommitChanges", on_after_commit_warn)):
            sig = getattr(lyr, sig_name, None)
            if sig is None:
                continue
            try:
                sig.connect(slot)
                self._signal_conns.append((sig, slot))
            except Exception:
                pass

        # ต่อแยกทีละ signal (try ของใครของมัน) — ถ้าชื่อ signal ใดต่างใน QGIS บางรุ่น
        # ตัวที่เหลือยังทำงาน (อย่างน้อย degrade เป็น "บล็อกเมื่อเลเยอร์ปิด" ซึ่งปลอดภัย)
        for sig_name, slot in (("afterCommitChanges", on_commit),
                               ("beforeCommitChanges", on_commit),
                               ("afterRollBack", on_rollback),
                               ("beforeRollBack", on_rollback),
                               ("editingStarted", on_start)):
            sig = getattr(lyr, sig_name, None)
            if sig is None:
                continue
            try:
                sig.connect(slot)
                self._signal_conns.append((sig, slot))
            except Exception:
                pass

    def _op_begin(self, layers):
        """บันทึกตำแหน่ง undo-stack ปัจจุบันของแต่ละเลเยอร์ ก่อนเริ่ม operation (ไว้คำนวณ delta)
        + ต่อ signal ดักการปิด edit (Save/Discard) ของเลเยอร์เหล่านั้น"""
        baseline = {}
        for lyr in layers:
            if lyr is None:
                continue
            try:
                baseline[lyr.id()] = (lyr, lyr.undoStack().index())
                self._watch_layer_editing(lyr)
            except Exception:
                pass
        self._op_baseline = baseline

    def _op_commit(self):
        """ปิด operation: เลเยอร์ไหนถูก push undo-command เพิ่ม (delta>0) เก็บเป็น 1 รายการในประวัติ
        delta คำนวณจาก index ของ QUndoStack -> empty command (ไม่ถูก push) จะได้ delta=0 อัตโนมัติ"""
        base = self._op_baseline
        self._op_baseline = None
        if not base:
            return
        op = []
        for lyr, before in base.values():
            try:
                delta = lyr.undoStack().index() - before
            except Exception:
                delta = 0
            if delta > 0:
                op.append((lyr, delta))
        if op:
            self.op_history.append(op)
            if len(self.op_history) > 100:   # กันโตไม่จำกัด
                self.op_history.pop(0)
            self.last_layers = [lyr for lyr, _ in op]   # เผื่อโค้ดอื่นอ้างอิง

    def undo_transform(self):
        """ย้อน operation ล่าสุดของปลั๊กอิน — ย้อนแต่ละเลเยอร์ตามจำนวน step ที่มัน push จริง
        Guard: ถ้ามีเลเยอร์ในรายการถูกปิด edit ไปแล้ว (ประวัติหาย) จะแยกเคส
          • Save  -> บล็อก (popup เตือน) เพราะย้อนเลเยอร์เดียวจะทำให้ไม่ตรงกัน
          • Discard -> popup ถามว่าจะย้อนเลเยอร์ที่ยังเปิดอยู่กลับ "จุดเริ่มเปิดแก้ไข" ให้ตรงกันไหม"""
        if not self.op_history:
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการล่าสุดให้ย้อนกลับ", level=2, duration=10)
            return

        op = self.op_history[-1]   # ยังไม่ pop เผื่อบล็อก/ยกเลิก
        live, saved_gone, disc_gone, unknown_gone = [], [], [], []
        for lyr, n in op:
            if lyr is None:
                continue
            try:
                if lyr.isEditable() and lyr.undoStack().canUndo():
                    live.append((lyr, n))          # ยังย้อนผ่าน stack ได้
                else:
                    ev = self._edit_end.get(lyr.id())
                    if ev == 'rollback':
                        disc_gone.append(lyr)      # ปิดแบบ Discard
                    elif ev == 'commit':
                        saved_gone.append(lyr)     # ปิดแบบ Save
                    else:
                        unknown_gone.append(lyr)   # ไม่รู้สถานะ -> กันไว้เหมือน Save
            except Exception:
                unknown_gone.append(lyr)

        # ---- เคสปกติ: ทุกเลเยอร์ยังเปิดอยู่ -> ย้อนตาม step ----
        if not (saved_gone or disc_gone or unknown_gone):
            self.op_history.pop()
            for lyr, n in live:
                stack = lyr.undoStack()
                for _ in range(n):
                    if not stack.canUndo():
                        break
                    stack.undo()
            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดเรียบร้อยแล้ว", level=1, duration=8)
            return

        # ---- มีเลเยอร์ปิด+Save (หรือไม่รู้สถานะ) -> บล็อก (popup เตือน) ----
        if saved_gone or unknown_gone:
            names = ", ".join(l.name() for l in (saved_gone + unknown_gone))
            QtWidgets.QMessageBox.warning(
                self.dlg, "ย้อนกลับไม่ได้",
                f"เลเยอร์ '{names}' ถูกปิดแก้ไข/บันทึกไปแล้ว — ประวัติ undo หายไป\n\n"
                "ย้อนอัตโนมัติไม่ได้ เพราะจะทำให้ 2 เลเยอร์ไม่ตรงกัน\n"
                "ให้เปิด Toggle Editing ของเลเยอร์นั้นก่อน แล้วแก้ด้วยตนเอง")
            return   # ไม่ pop ไม่ย้อนอะไร

        # ---- เลเยอร์ที่หายเป็น Discard ทั้งหมด ----
        disc_names = ", ".join(l.name() for l in disc_gone)
        if not live:
            # ทั้ง op เป็น Discard -> ทุกเลเยอร์กลับจุดเริ่มอยู่แล้ว ไม่ต้องทำอะไร
            self.op_history.pop()
            self.iface.messageBar().pushMessage(
                "Undo", f"เลเยอร์ '{disc_names}' ถูกปิดแบบไม่เซฟ — ข้อมูลกลับจุดเริ่มแล้ว ไม่ต้องย้อนเพิ่ม",
                level=1, duration=10)
            return

        # มีทั้ง Discard และเลเยอร์ที่ยังเปิด -> ถามว่าจะย้อนเลเยอร์ที่เปิดกลับจุดเริ่มให้ตรงกันไหม
        live_names = ", ".join(l.name() for l, _ in live)
        ans = QtWidgets.QMessageBox.question(
            self.dlg, "เลเยอร์ถูกปิดแบบไม่เซฟ",
            f"เลเยอร์ '{disc_names}' ถูกปิดแก้ไขแบบไม่บันทึก → ข้อมูลกลับไป "
            "'จุดเริ่มเปิดแก้ไข' แล้ว (ไม่ใช่แค่ครั้งล่าสุด)\n\n"
            f"ต้องการย้อนเลเยอร์ที่ยังเปิดอยู่ ('{live_names}') กลับไปจุดเริ่มด้วย "
            "เพื่อให้ทั้งสองตรงกันไหม?\n"
            "⚠️ งานทั้งหมดที่ทำไว้ในเลเยอร์นี้ (ตั้งแต่เปิดแก้ไข) จะถูกย้อนทิ้ง",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No)
        if ans == QtWidgets.QMessageBox.Yes:
            for lyr, _n in live:
                stack = lyr.undoStack()
                while stack.canUndo():      # ย้อนสุด -> จุดเริ่ม session
                    stack.undo()
            self.op_history.clear()          # ทุกอย่างถูกย้อนหมดแล้ว
            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage(
                "Undo", "ย้อนทั้งสองเลเยอร์กลับจุดเริ่มเปิดแก้ไขแล้ว", level=1, duration=8)
        # No -> ไม่ทำอะไร (คงสถานะไว้)

    def _pairing_issues(self, poly_lyr, point_lyr, cap=2000):
        """ตรวจกติกาเหล็ก "ทุก node ต้องมีหมุดของแปลงเดียวกันทับ" เฉพาะแปลงที่ค้างอยู่ใน edit buffer
        (ยังไม่ commit) -> คืน (n_bad, n_checked, ตัวอย่าง) หรือ None ถ้าตรวจไม่ได้/ข้าม.

        ตรวจ "ผลลัพธ์" ไม่ใช่ "สาเหตุ" จึงดักได้ทุกทางที่ทำแปลงกับหมุดหลุดคู่กัน:
          • กด Ctrl+Z ของ QGIS (undo แค่เลเยอร์ที่ active -> อีกชั้นยังค้างใน buffer)
          • Align ดึงมุมแปลงข้างเคียงตามเส้น แต่หมุดของแปลงนั้นไม่ได้ถูกเลือกให้ย้ายด้วย
          • เพิ่ม node แล้วหมุดใหม่เข้าไม่ได้ (เช่นสิทธิ์ INSERT ไม่พอ)
          • ใช้เครื่องมือแก้ไขของ QGIS ตรงๆ โดยไม่ผ่านปลั๊กอิน
        คิวรีเดียว (ดึงหมุดของ UTM ที่เกี่ยวทั้งชุด) แล้วเทียบในหน่วยความจำ -> ไม่ยิง DB ต่อแปลง"""
        try:
            if not poly_lyr or not point_lyr or not poly_lyr.isEditable():
                return None
            buf = poly_lyr.editBuffer()
            if buf is None:
                return None
            fids = set(buf.changedGeometries().keys()) | set(buf.addedFeatures().keys())
            if not fids or len(fids) > cap:
                return None                      # ไม่มีอะไรแก้ / แก้เยอะเกิน -> ข้าม (กันหน่วงตอน Save)
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if not pu or not tu:
                return None
            polys = {}
            for f in poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(fids))):
                u = f[pu]
                if u is None:
                    continue
                polys[f.id()] = (_norm_utm(u), f.geometry())
            if not polys:
                return None
            utms = {u for u, _g in polys.values()}
            qs = ",".join(QgsExpression.quotedValue(u) for u in utms)
            expr = f"{QgsExpression.quotedColumnRef(tu)} IN ({qs})"
            mk = {}                              # {utm: {(x,y) ปัดมิลลิเมตร}} — สถานะรวม buffer ที่ยังไม่ commit
            for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(expr)):
                u = f[tu]; g = f.geometry()
                if u is None or g is None or g.isEmpty():
                    continue
                p = g.asPoint()
                mk.setdefault(_norm_utm(u), set()).add((round(p.x(), 3), round(p.y(), 3)))
            bad = 0; checked = 0; sample = []
            for _fid, (u, g) in polys.items():
                if g is None or g.isNull():
                    continue
                S = mk.get(u, set())
                for v in g.vertices():
                    checked += 1
                    if (round(v.x(), 3), round(v.y(), 3)) not in S:
                        bad += 1
                        if len(sample) < 5:
                            sample.append(f"ระวาง/UTM {u} ที่ {v.x():.2f}, {v.y():.2f}")
            return bad, checked, sample
        except Exception:
            return None                          # ตรวจไม่ได้ -> อย่าไปขวางการบันทึก

    def save_all_changes(self):
        """commit ทั้งสองเลเยอร์ — เช็คผลจริงจาก provider (บน PostgreSQL commit ล้มเหลวได้:
        สิทธิ์ไม่พอ / constraint / connection หลุด) เดิมไม่เช็คเลยขึ้น 'สำเร็จ' เสมอ
        + ก่อน commit เตือนถ้าสิ่งที่จะบันทึกมี node ที่ไม่มีหมุดคู่ (ดู _pairing_issues)"""
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        iss = self._pairing_issues(poly_lyr, point_lyr)
        if iss and iss[0]:
            bad, checked, sample = iss
            lines = "\n".join("• " + s for s in sample)
            ans = QtWidgets.QMessageBox.question(
                self.dlg, "ตรวจพบมุมแปลงที่ไม่มีหมุด",
                f"ในงานที่กำลังจะบันทึก พบ {bad:,} มุม (จาก {checked:,} มุมที่ตรวจ) "
                f"ที่ไม่มีหมุดของแปลงเดียวกันทับอยู่\n\n{lines}\n\n"
                "สาเหตุที่พบบ่อย:\n"
                "• กด Ctrl+Z ของ QGIS (ย้อนแค่ชั้นที่เลือกอยู่ อีกชั้นไม่ย้อนตาม) — ใช้ปุ่ม Undo ของปลั๊กอินแทน\n"
                "• Align ดึงมุมแปลงข้างเคียงไปตามเส้น แต่หมุดของแปลงนั้นไม่ได้ถูกเลือกให้ย้ายด้วย\n"
                "• เพิ่ม node แล้วหมุดใหม่เข้าไม่สำเร็จ\n\n"
                "ยังต้องการบันทึกต่อหรือไม่?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if ans != QtWidgets.QMessageBox.Yes:
                return
        failed = []   # [(ชื่อเลเยอร์, ข้อความ error)]
        # ปุ่มนี้ตรวจ+ถามไปแล้ว -> กัน hook beforeCommitChanges เตือนซ้ำ (reset เสมอใน finally)
        self._pair_warn_ack = True
        try:
            for lyr in [poly_lyr, point_lyr]:
                if lyr and lyr.isEditable():
                    if lyr.commitChanges():
                        lyr.startEditing()
                    else:
                        failed.append((lyr.name(), "\n".join(lyr.commitErrors())))
        finally:
            self._pair_warn_ack = False
        if failed:
            # เลเยอร์ที่พลาดยังอยู่ในโหมดแก้ไข + edit buffer เดิมยังอยู่ครบ -> ไม่เคลียร์ประวัติ undo
            names = ", ".join(n for n, _ in failed)
            detail = "\n\n".join(f"• {n}:\n{e}" for n, e in failed)
            QtWidgets.QMessageBox.critical(
                self.dlg, "บันทึกไม่สำเร็จ",
                f"เลเยอร์ '{names}' บันทึกลงฐานข้อมูลไม่สำเร็จ — ข้อมูลยังไม่ถูกเซฟ!\n"
                f"งานที่แก้ไว้ยังอยู่ใน edit buffer (ยังไม่หาย)\n\n{detail}")
            return
        # commitChanges ล้าง undo-stack ของ QGIS -> ประวัติเก่าย้อนไม่ได้แล้ว เคลียร์ทิ้ง
        self.op_history.clear()
        self._op_baseline = None
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3, duration=3)

    def _auto_check_update(self):
        """เช็คเวอร์ชันใหม่ให้อัตโนมัติ — ครั้งเดียวต่อการเปิด QGIS
        เงียบสนิทถ้าเป็นเวอร์ชันล่าสุดอยู่แล้ว หรือเน็ตไม่ถึง (ไม่มี dialog/progress ใด ๆ)
        เจอของใหม่เท่านั้นถึงจะถามว่าจะอัปเดตไหม
        (เดิมต้องกดปุ่ม 🚀 Check Update เอง -> ของใหม่ไม่ถึงพนักงานจนกว่าจะมีคนไล่บอกทีละคน)"""
        if getattr(self, "_auto_upd_done", False):
            return
        self._auto_upd_done = True

        def _check():
            res = requests.get(UPDATE_V_URL, timeout=8)
            res.raise_for_status()
            return res.text.strip()

        w = _FnWorker(_check)
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)      # กัน GC เก็บ worker ระหว่างรัน

        def _cleanup():
            try:
                self._net_workers.remove(w)
            except ValueError:
                pass
            w.deleteLater()

        def _ok(new_version):
            _cleanup()
            try:
                if _vkey(new_version) > _vkey(self.version):
                    self.prompt_update(new_version, UPDATE_Z_URL)
            except Exception:
                pass

        w.done.connect(_ok)
        w.fail.connect(lambda _e: _cleanup())    # เน็ตไม่ถึง/GitHub ล่ม = เงียบ ไม่กวนผู้ใช้
        w.start()

    def update_plugin(self):
        """เช็คเวอร์ชันใหม่จาก GitHub — ทำใน thread แยก (เดิม block UI บน main thread)"""
        V_URL = UPDATE_V_URL
        Z_URL = UPDATE_Z_URL

        def _check():
            res = requests.get(V_URL, timeout=8)
            res.raise_for_status()
            return res.text.strip()

        def _got(new_version):
            if _vkey(new_version) > _vkey(self.version):
                self.prompt_update(new_version, Z_URL)
            else:
                QtWidgets.QMessageBox.information(
                    self.dlg, "Update", f"คุณใช้เวอร์ชันล่าสุดแล้ว (v{self.version})")

        def _err(e):
            QtWidgets.QMessageBox.warning(self.dlg, "Update Error", f"ไม่สามารถตรวจสอบอัปเดตได้:\n{e}")

        self._run_net("กำลังตรวจสอบเวอร์ชันใหม่...", _check, _got, _err)

    def prompt_update(self, new_version, download_url):
        if QtWidgets.QMessageBox.question(
                self.dlg, "Update",
                f"พบเวอร์ชันใหม่ {new_version} ต้องการอัปเดตไหม?") != QtWidgets.QMessageBox.Yes:
            return

        def _download():
            """โหลด -> ตรวจของในซิปก่อน -> แตกลง temp -> สลับทับของเดิม (มีสำเนาเดิมไว้กู้)
            เดิม: extractall ทับของจริงสด ๆ โดยไม่ตรวจอะไรเลย ->
              (ก) วันไหนอัปซิปผิดตัว จะ downgrade ทั้งกรมโดยไม่มีอะไรดัก
              (ข) เน็ตหลุดกลางคัน = ปลั๊กอินเหลือครึ่ง ๆ กู้เองไม่ได้"""
            here = os.path.dirname(__file__)                 # .../plugins/Multi_Layer_Edit_Pro
            plugins_dir = os.path.dirname(here)
            name = os.path.basename(here)

            r = requests.get(download_url, timeout=120)
            r.raise_for_status()
            z = zipfile.ZipFile(io.BytesIO(r.content))       # ซิปเสีย -> โยน error ตั้งแต่ตรงนี้
            bad = z.testzip()
            if bad:
                raise RuntimeError(f"ไฟล์ในซิปเสีย: {bad}")

            # ---- ตรวจว่าซิปเป็นเวอร์ชันที่โฆษณาไว้จริง ----
            meta_path = f"{name}/metadata.txt"
            if meta_path not in z.namelist():
                raise RuntimeError(f"ซิปไม่มี {meta_path} — โครงไฟล์ไม่ถูกต้อง")
            zver = ""
            for line in z.read(meta_path).decode("utf-8", "replace").splitlines():
                if line.strip().startswith("version="):
                    zver = line.split("=", 1)[1].strip()
                    break
            if _vkey(zver) != _vkey(new_version):
                raise RuntimeError(
                    f"ซิปเป็นเวอร์ชัน {zver} แต่ประกาศไว้ว่า {new_version} — ยกเลิกการติดตั้ง")
            if _vkey(zver) <= _vkey(self.version):
                raise RuntimeError(
                    f"ซิปเป็นเวอร์ชัน {zver} ซึ่งไม่ใหม่กว่าของที่ใช้อยู่ ({self.version}) — ยกเลิก กัน downgrade")

            # ---- แตกลง temp ก่อน แล้วค่อยสลับ ----
            import shutil, tempfile
            tmp = tempfile.mkdtemp(prefix=".mlep_upd_", dir=plugins_dir)
            try:
                z.extractall(tmp)
                src = os.path.join(tmp, name)
                if not os.path.isdir(src) or not os.path.exists(os.path.join(src, "main.py")):
                    raise RuntimeError("ซิปแตกออกมาไม่ครบ (ไม่พบ main.py)")
                backup = os.path.join(plugins_dir, name + "_bak_update")
                if os.path.exists(backup):
                    shutil.rmtree(backup, ignore_errors=True)
                os.rename(here, backup)                      # เก็บของเดิมไว้ก่อน
                try:
                    os.rename(src, here)                     # สลับของใหม่เข้าที่
                except Exception:
                    os.rename(backup, here)                  # สลับไม่สำเร็จ -> คืนของเดิมทันที
                    raise
                shutil.rmtree(backup, ignore_errors=True)
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            return zver

        def _ok(zver):
            QtWidgets.QMessageBox.information(
                self.dlg, "Done", f"อัปเดตเป็นเวอร์ชัน {zver} เรียบร้อยแล้ว\n\nกรุณาปิด QGIS แล้วเปิดใหม่")

        def _err(e):
            QtWidgets.QMessageBox.critical(self.dlg, "Update Error", f"การดาวน์โหลดล้มเหลว:\n{e}")

        self._run_net(f"กำลังดาวน์โหลดเวอร์ชัน {new_version}...", _download, _ok, _err)

    def process_selection(self, mode):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        selected_ids = poly_layer.selectedFeatureIds()
        if not selected_ids: return
        
        fields = poly_layer.fields()
        target_names = (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])
        target = None
        target_idx = -1
        for i, field in enumerate(fields):
            if field.name().lower() in target_names:
                target = field.name()
                target_idx = i
                break
        if target_idx == -1: return
        
        # Optimize: ดึงเฉพาะข้อมูล Attribute ของฟิลด์ที่กำหนดโดยไม่ดึงพิกัดเพื่อประหยัดหน่วยความจำ
        req = QgsFeatureRequest().setFilterFids(selected_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([target_idx])
        vals = set()
        for f in poly_layer.getFeatures(req):
            val = f.attribute(target_idx)
            if val is not None:
                # quotedValue escape ค่าให้ถูกต้อง (เดิมต่อ string เอง -> ค่าที่มี ' ทำ expression พัง)
                vals.add(QgsExpression.quotedValue(val))

        if vals:
            expr = f'{QgsExpression.quotedColumnRef(target)} IN ({",".join(sorted(vals))})'
            poly_layer.selectByExpression(expr)
            if point_layer: point_layer.selectByExpression(expr)
            self.iface.mapCanvas().refresh()

    # ============ Add Node: เพิ่ม node ให้แปลง + เพิ่มหมุด (ระวางจากแปลง, ชื่อจากหมุดเดิม) ============
    def start_add_node(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_lyr or poly_lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            QtWidgets.QMessageBox.warning(self.dlg, "Add Node", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        if not point_lyr or point_lyr.geometryType() != QgsWkbTypes.PointGeometry:
            QtWidgets.QMessageBox.warning(self.dlg, "Add Node", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        self.cancel_transform()
        self.temp_tool = AddNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Add Node", f"คลิกเลือกแปลงใน '{poly_lyr.name()}' (เลือก 1 แปลง • คลิกแปลงอื่น = เปลี่ยน) "
                        "แล้วคลิกที่หมุด (snap ให้อัตโนมัติ) เพื่อเพิ่ม node • คลิกขวา/Esc = ยกเลิก")

    def _marker_exists_here(self, point_lyr, poly_feat, xy, utm_fields, tol=0.01):
        """แปลงนี้มีหมุดของตัวเองอยู่ที่พิกัดนี้แล้วหรือยัง (ใช้กัน Add Node สร้างหมุดซ้อน)
        เทียบด้วย "ระวางเดียวกัน + อยู่ในระยะ tol" — ไม่ใช่แค่ตำแหน่ง เพราะมุมร่วมของแปลงข้างเคียง
        ต้องมีหมุดของตัวเองได้ (คนละ UTM = คนละหมุด ถือว่าไม่ซ้ำ)"""
        try:
            key = [f for f in utm_fields
                   if point_lyr.fields().indexOf(f) >= 0 and poly_feat.fields().indexOf(f) >= 0]
            if not key:
                return False                      # ไม่มีคีย์ให้เทียบ -> อย่าไปขวางการเพิ่ม
            rect = QgsRectangle(xy.x() - tol, xy.y() - tol, xy.x() + tol, xy.y() + tol)
            req = QgsFeatureRequest().setFilterRect(rect)
            for f in point_lyr.getFeatures(req):
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                if g.asPoint().distance(xy) > tol:
                    continue
                if all(str(f[k] or "") == str(poly_feat[k] or "") for k in key):
                    return True
        except Exception:
            return False                          # เช็คไม่ได้ -> ทำงานเหมือนเดิม
        return False

    def _addnode_name_field(self, point_lyr):
        """หา field ชื่อหมุด: ใช้ BND_NAME ก่อน ถ้าไม่มีหาฟิลด์ที่มีคำว่า NAME"""
        flds = point_lyr.fields()
        if flds.indexOf("BND_NAME") >= 0:
            return "BND_NAME"
        for f in flds:
            if "NAME" in f.name().upper():
                return f.name()
        return None

    def _poly_type_str(self, poly_lyr, feat):
        """คืนค่าฟิลด์ type (ตัวพิมพ์ใหญ่) ของแปลง หรือ '' ถ้าไม่มี — ใช้เช็ค L1-RTK/L1-TS
        เรียกทุก mouse-move ตอน hover (Add Node/Move Node) -> หา field ผ่าน cache"""
        name = self._resolve_field(poly_lyr, {'type'})
        if not name:
            return ""
        v = feat[name]
        return "" if v is None else str(v).strip().upper()

    def start_sync_vertex_tool(self):
        """เริ่มการทำงานของ SyncVertexTool (ย้ายหมุดทีละหลายอัน)"""
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        if not poly_lyr and not point_lyr:
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกเลเยอร์แปลงหรือหมุดก่อน", level=2, duration=5)
            return
            
        if self.temp_tool:
            try:
                self.temp_tool.deactivate()
            except Exception:
                pass
                
        # ถ้ามีแปลงถูก Select อยู่ ให้เรียกใช้ Select by UTM อัตโนมัติ เพื่อให้หมุดติด Select สีเหลืองไปด้วย
        if poly_lyr and poly_lyr.selectedFeatureCount() > 0:
            self.process_selection('utm')

        self.mode = 'modify_node'
        self.temp_tool = SyncVertexTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Move Node",
            "คลิกหมุด → คลิกตำแหน่งใหม่เพื่อย้าย • หลายหมุด: ลากกล่องเลือกแล้วลากย้าย (Shift+ลาก = เลือกเพิ่ม) • คลิกขวา = เสร็จ")

    def _movenodes_execute(self, selected_vertices, dx, dy):
        """ประมวลผลการย้ายพิกัดหมุดหลายเลเยอร์พร้อมกัน"""
        if not selected_vertices:
            return False
            
        layers = set()
        for v in selected_vertices:
            layers.add(v['layer'])

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            if not lyr.isEditable():
                lyr.startEditing()
            lyr.beginEditCommand("Move Nodes (Sync)")
            
        try:
            proj = QgsProject.instance()
            # สร้าง transform ครั้งเดียวต่อเลเยอร์ (เดิมสร้างใหม่ทุก vertex ในลูป)
            xform_cache = {}
            for _lyr in layers:
                xform_cache[_lyr.id()] = (QgsCoordinateTransform(proj.crs(), _lyr.crs(), proj)
                                          if _lyr.crs() != proj.crs() else None)
            # ดึง geometry ของ polygon/line ที่ต้องแก้ทั้งหมดใน "คิวรีเดียวต่อเลเยอร์"
            # (เดิมดึงทีละ feature — บน PostgreSQL = 1 round-trip ต่อ feature)
            geom_updates = {}
            need = {}
            for v in selected_vertices:
                if v['vidx'] >= 0:
                    need.setdefault(v['layer'], set()).add(v['fid'])
            for _lyr, _fids in need.items():
                req = QgsFeatureRequest().setFilterFids(list(_fids)).setNoAttributes()
                for f in _lyr.getFeatures(req):
                    geom_updates[(_lyr.id(), f.id())] = f.geometry()

            for v in selected_vertices:
                lyr = v['layer']
                fid = v['fid']
                vidx = v['vidx']
                pt = v['pt']

                # แปลงพิกัดใหม่กลับไปเป็น CRS ของเลเยอร์เป้าหมาย (ใช้ transform ที่ cache ไว้)
                to_lyr = xform_cache.get(lyr.id())
                new_map_pt = QgsPointXY(pt.x() + dx, pt.y() + dy)
                new_lyr_pt = to_lyr.transform(new_map_pt) if to_lyr else new_map_pt

                key = (lyr.id(), fid)

                if vidx >= 0:
                    # Polygon หรือ Line (ย้ายเฉพาะ vertex นั้นๆ)
                    geom = geom_updates.get(key)
                    if geom is None:
                        continue   # feature หายไประหว่างทำงาน (เดิมจะ crash ด้วย StopIteration)
                    geom.moveVertex(new_lyr_pt.x(), new_lyr_pt.y(), vidx)
                else:
                    # Point (ย้ายทั้ง geometry)
                    geom_updates[key] = QgsGeometry.fromPointXY(new_lyr_pt)

            # นำ geometry ที่แก้ไขแล้วไปอัปเดต โดยใช้ changeGeometry เพื่อข้ามระบบ Topological Editing ของ QGIS
            # (ป้องกันไม่ให้หมุดแปลงข้างเคียงขยับตาม หากไม่ได้ถูกเลือกไว้)
            for v in selected_vertices:
                lyr = v['layer']
                fid = v['fid']
                key = (lyr.id(), fid)
                if key in geom_updates:
                    lyr.changeGeometry(fid, geom_updates[key])
                    del geom_updates[key]  # ป้องกันการรันซ้ำ
                    
            for lyr in layers:
                lyr.endEditCommand()

            self._op_commit()   # ปิด operation -> เก็บประวัติ undo
            self.iface.mapCanvas().refresh()
            return True
        except Exception as e:
            for lyr in layers:
                lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline (delta=0 -> ไม่บันทึก)
            self.iface.messageBar().pushMessage("Error", f"Move Nodes Error: {e}", level=2, duration=0)
            return False

    def _addnode_execute(self, poly_lyr, fids, ins_xy):
        """เพิ่ม node ให้ทุกแปลงที่เลือก + สร้างหมุดใหม่ (ระวางจากแปลง, ชื่อจากหมุดเดิม ณ จุด snap)
        ins_xy = พิกัดหมุดที่ snap ติด (CRS เลเยอร์หมุด). คืน True ถ้าสำเร็จ"""
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            QtWidgets.QMessageBox.warning(self.dlg, "Add Node", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return False
        proj = QgsProject.instance()
        name_field = self._addnode_name_field(point_lyr)

        # รวมชื่อจากหมุดที่ตำแหน่งเดียวกัน (coincident กับจุด snap ≤5ซม.) -> หลายชื่อให้ popup เลือก
        COINC = 0.05
        rect = QgsRectangle(ins_xy.x() - COINC, ins_xy.y() - COINC,
                            ins_xy.x() + COINC, ins_xy.y() + COINC)
        names = []
        for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            nm = "" if name_field is None else str(f[name_field] or "").strip()
            if nm and nm not in names:
                names.append(nm)
        if len(names) <= 1:
            chosen = names[0] if names else ""
        else:
            chosen, ok = QtWidgets.QInputDialog.getItem(
                self.dlg, "เลือกชื่อหมุด",
                "ตำแหน่งนี้มีหลายหมุดหลายชื่อ — เลือกชื่อที่ต้องการ:", names, 0, False)
            if not ok:
                return False

        # พิกัดสำหรับแทรก node เข้า polygon (CRS เลเยอร์แปลง)
        to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj)
                   if poly_lyr.crs() != point_lyr.crs() else None)
        ins_poly = to_poly.transform(ins_xy) if to_poly else QgsPointXY(ins_xy)

        utm_fields = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO", "UTM"]
        if not poly_lyr.isEditable():
            poly_lyr.startEditing()
        if not point_lyr.isEditable():
            point_lyr.startEditing()
        self._op_begin([poly_lyr, point_lyr])   # เริ่มนับ undo-step ต่อเลเยอร์
        poly_lyr.beginEditCommand("Add Node")
        point_lyr.beginEditCommand("Add Marker")
        n_node = n_pt = n_skip = 0
        try:
            for fid in fids:
                pf = poly_lyr.getFeature(fid)
                if not pf.isValid():
                    continue
                # กันชน: ห้ามเพิ่ม node ให้แปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
                tp = self._poly_type_str(poly_lyr, pf)
                if tp in ("L1-RTK", "L1-TS"):
                    self.iface.messageBar().pushMessage(
                        "Add Node", f"ข้ามแปลง {fid}: เป็น {tp} (พิกัดอ้างอิง ห้ามเพิ่ม node)",
                        level=2, duration=6)
                    continue
                geom = pf.geometry()
                # ถ้าแปลงมี vertex ตรงนั้นแล้ว ไม่ต้องแทรกซ้ำ (แต่ยังเพิ่มหมุด)
                cv = geom.closestVertex(ins_poly)
                has_vertex = cv[4] is not None and cv[4] < 0.0001   # < 1 ซม.
                if not has_vertex:
                    seg = geom.closestSegmentWithContext(ins_poly)
                    if poly_lyr.insertVertex(ins_poly.x(), ins_poly.y(), fid, seg[2]):
                        n_node += 1
                # ★ กันหมุดซ้ำ: ถ้าแปลงนี้มีหมุดของตัวเองอยู่ตรงนั้นแล้ว อย่าเพิ่มอีก
                #   (เดิม has_vertex กันแค่ไม่ให้แทรก vertex ซ้ำ แต่ยัง addFeature เสมอ
                #    -> คลิก Add Node ซ้ำจุดเดิม/คลิกแปลงที่มีหมุดครบแล้ว = ได้หมุดซ้อนกัน)
                if self._marker_exists_here(point_lyr, pf, ins_xy, utm_fields):
                    n_skip += 1
                    continue
                # เพิ่มหมุดใหม่: ระวางจากแปลง + ชื่อที่เลือก
                nf = QgsFeature(point_lyr.fields())
                nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ins_xy)))
                for fld in utm_fields:
                    pi = point_lyr.fields().indexOf(fld)
                    qi = poly_lyr.fields().indexOf(fld)
                    if pi >= 0 and qi >= 0:
                        nf.setAttribute(pi, pf.attribute(qi))
                if name_field is not None and chosen:
                    nf.setAttribute(point_lyr.fields().indexOf(name_field), chosen)
                # provenance: ติดป้ายว่าหมุดนี้ "คนเพิ่ม" (addFeature() ไม่ผ่าน attribute form -> form default ไม่ยิง)
                # ตั้งแค่ EDIT_SRC เท่านั้น — "ใคร/เมื่อไหร่" ปล่อยให้ PG trigger tag_added_point() เขียนเอง:
                #   EDITED_BY = session_user  (PG role ของพนักงานจริง เช่น phuwanart_boo — แม่นกว่า OS login
                #                              ของเครื่องที่อาจเป็นบัญชีกลาง เช่น 'dol-workspace') ปลอมจาก client ไม่ได้
                #   EDITED_AT = now()         (เวลา server ไม่ใช่นาฬิกาเครื่อง client)
                # (indexOf: ไม่มีคอลัมน์ -> -1 -> ข้าม, ปลอดภัยกับเลเยอร์ที่ไม่มี provenance)
                _pidx = point_lyr.fields().indexOf("EDIT_SRC")
                if _pidx >= 0:
                    nf.setAttribute(_pidx, "added")
                if point_lyr.addFeature(nf):
                    n_pt += 1
            poly_lyr.endEditCommand()
            point_lyr.endEditCommand()
            self._op_commit()   # ปิด operation -> เก็บประวัติ undo (แปลงที่ vertex มีอยู่แล้ว delta=0 ข้ามเอง)
        except Exception as e:
            poly_lyr.destroyEditCommand()
            point_lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline
            self.iface.messageBar().pushMessage("Add Node Error", f"{e}", level=2, duration=0)
            return False

        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushMessage(
            "Add Node", f"เพิ่ม node {n_node} แปลง + หมุด {n_pt} จุด (ชื่อ '{chosen or '-'}')"
                        + (f" • ข้าม {n_skip} จุดที่มีหมุดอยู่แล้ว" if n_skip else ""),
            level=3, duration=8)
        return True

    def start_align_tool(self):
        self.cancel_transform()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            QtWidgets.QMessageBox.warning(self.dlg, "Align", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        self.mode = 'align_box'
        self.canvas = self.iface.mapCanvas()
        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.temp_tool = BoxSelectTool(self.iface.mapCanvas(), self._align_add_box,
                                       self.finish_align_selection, self._align_cancel)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", "ลากกล่องครอบหมุด (ครอบหลายรอบได้ • Ctrl+ลาก = เอาออก) แล้วคลิกขวาเพื่อเลือกเสร็จ")

    def _align_add_box(self, rect_map, remove):
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            return
        proj = QgsProject.instance()
        rect_lyr = rect_map
        if point_lyr.crs() != proj.crs():
            try:
                rect_lyr = QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj).transformBoundingBox(rect_map)
            except Exception:
                rect_lyr = rect_map
        ids = set(getattr(self, "_align_picked_ids", set()))
        req = QgsFeatureRequest().setFilterRect(rect_lyr).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            ids.discard(f.id()) if remove else ids.add(f.id())
        self._align_picked_ids = ids
        self._align_refresh_highlight()
        self.iface.messageBar().pushInfo("Align", f"เลือกหมุด {len(ids)} จุด (คลิกขวา = เสร็จ)")

    def _align_refresh_highlight(self):
        self._align_clear_highlight()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        ids = getattr(self, "_align_picked_ids", None)
        if not point_lyr or not ids:
            return
        proj = QgsProject.instance()
        xform = None
        if point_lyr.crs() != proj.crs():
            try:
                xform = QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
            except Exception:
                xform = None
        self._align_markers = []
        req = QgsFeatureRequest().setFilterFids(list(ids)).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            xy = f.geometry().asPoint()
            if xform is not None:
                try:
                    xy = xform.transform(xy)
                except Exception:
                    pass
            mk = QgsVertexMarker(self.iface.mapCanvas())
            mk.setCenter(QgsPointXY(xy))
            mk.setColor(QtGui.QColor(0, 120, 255))
            mk.setIconType(QgsVertexMarker.ICON_BOX)
            mk.setPenWidth(3)
            mk.setIconSize(10)
            self._align_markers.append(mk)

    def _align_clear_highlight(self):
        for mk in getattr(self, "_align_markers", []):
            try:
                self.iface.mapCanvas().scene().removeItem(mk)
            except Exception:
                pass
        self._align_markers = []

    def _align_cancel(self):
        """ยกเลิกโหมด Align (Esc): ล้างข้อความแนะนำที่ค้าง แล้วรีเซ็ต"""
        try:
            self.iface.messageBar().clearWidgets()
        except Exception:
            pass
        self.cancel_transform()

    def finish_align_selection(self):
        """คลิกขวา = จบการเลือกหมุด -> เข้าโหมดลากเส้น 2 จุด (หมุดที่เลือกจะวิ่งไปหาเส้นที่ลาก
        หมุด/มุมที่ไม่ได้เลือกอยู่กับที่ -> แปลงยังต่อกับของเดิม)"""
        if not getattr(self, "_align_picked_ids", None):
            self.iface.messageBar().pushMessage("Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน", level=1, duration=6)
            return
        self.mode = 'align_point_driven'
        self.src_pts = []
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.canvas)
        self.temp_tool.canvasClicked.connect(self.handle_align_click)
        self.temp_tool.canvasMoveEvent = self.handle_align_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", f"เลือกหมุด {len(self._align_picked_ids)} จุด → คลิก 2 จุดสร้างเส้นแนว (Esc = ยกเลิก)")

    def handle_align_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือ Align (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
        # แก้จาก self.snapping_utils เป็น self.snap_utils
        if not hasattr(self, 'snap_utils'):
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # Logic สำหรับวาด Rubber Band เส้นยางยืด (ถ้ามี)
        if hasattr(self, 'rubber_band') and self.rubber_band and len(self.src_pts) == 1:
            curr_pt = match.point() if match.isValid() else event.mapPoint()
            self.rubber_band.removeLastPoint()
            self.rubber_band.addPoint(curr_pt)
            
    def handle_align_click(self, point, button):
        """จัดการการคลิกจุด P1 และ P2 สำหรับสร้างแนวเส้น (รองรับที่ว่าง)"""
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        # 2. ถ้า Snap ไม่ติด ให้ใช้พิกัดที่คลิกจริง (point)
        pt = match.point() if match.isValid() else point
        
        self.src_pts.append(QgsPointXY(pt.x(), pt.y()))
        
        # วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        m.setPenWidth(5)
        self.markers.append(m)
        
        if len(self.src_pts) == 1:
            self.clear_rubber_band()
            self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            self.rubber_band.setColor(QtGui.QColor(255, 0, 0))
            self.rubber_band.setWidth(2)
            self.rubber_band.addPoint(pt)
            self.rubber_band.addPoint(pt)

        if len(self.src_pts) == 2:
            self.execute_point_node_alignment()
            # ทำความสะอาดหน้าจอหลังเสร็จงาน
            self.clear_markers()
            self.clear_rubber_band()
            self.src_pts = []
            
    def clear_rubber_band(self):
        """ลบ Rubber Band ออกจากหน้าจอและหน่วยความจำอย่างเด็ดขาด"""
        if self.rubber_band:
            self.rubber_band.hide() # ซ่อนทันที
            self.iface.mapCanvas().scene().removeItem(self.rubber_band) # ลบออกจาก Scene
            self.rubber_band = None # คืนค่าว่าง
            
    def _prefetch_align_polys(self, poly_lyr, target_points, pad):
        """ดึงแปลงรอบหมุดที่เลือกทั้งหมดใน "คิวรีเดียว" + สร้าง spatial index ในหน่วยความจำ
        -> {'index': QgsSpatialIndex, 'geoms': {fid: QgsGeometry}, 'types': {fid: TYPE upper}}
        (เดิม _side_edge_dir และ weld PASS 3 ยิง query ต่อหมุด — บน PostgreSQL = N round-trips)"""
        rect = None
        for pt_f in target_points:
            g = pt_f.geometry()
            if g is None or g.isNull():
                continue
            p = g.asPoint()
            r = QgsRectangle(p.x() - pad, p.y() - pad, p.x() + pad, p.y() + pad)
            if rect is None:
                rect = QgsRectangle(r)
            else:
                rect.combineExtentWith(r)
        cache = {'index': QgsSpatialIndex(), 'geoms': {}, 'types': {}}
        if rect is None:
            return cache
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        req = QgsFeatureRequest().setFilterRect(rect)
        req.setSubsetOfAttributes([type_idx] if type_idx != -1 else [])
        for f in poly_lyr.getFeatures(req):
            g = f.geometry()
            if g is None or g.isNull():
                continue
            cache['geoms'][f.id()] = QgsGeometry(g)
            if type_idx != -1:
                v = f.attribute(type_idx)
                cache['types'][f.id()] = "" if v is None else str(v).strip().upper()
            cache['index'].addFeature(f)
        return cache

    def _side_edge_dir(self, old_xy, poly_cache, line_dx, line_dy):
        """ทิศของขอบแปลงที่ vertex old_xy โดยเลือกขอบที่ไม่ขนานกับเส้นเป้าหมาย -> (ux,uy) หรือ None
        ค้นจาก poly_cache ที่ prefetch ไว้ (ไม่ยิง query ต่อหมุดแล้ว)"""
        if not poly_cache or not poly_cache['geoms']:
            return None
        lmag = math.hypot(line_dx, line_dy)
        if lmag == 0:
            return None
        lux, luy = line_dx / lmag, line_dy / lmag
        EPS = 0.05
        rect = QgsRectangle(old_xy.x() - 1.0, old_xy.y() - 1.0,
                            old_xy.x() + 1.0, old_xy.y() + 1.0)
        best = None  # (parallelness, ux, uy)
        for fid in poly_cache['index'].intersects(rect):
            g = poly_cache['geoms'].get(fid)
            if g is None:
                continue
            try:
                if g.isMultipart():
                    rings = [poly[0] for poly in g.asMultiPolygon() if poly]
                else:
                    pg = g.asPolygon()
                    rings = [pg[0]] if pg else []
            except Exception:
                rings = []
            for ring in rings:
                if len(ring) > 1 and ring[0] == ring[-1]:
                    ring = ring[:-1]
                n = len(ring)
                if n < 3:
                    continue
                vi = -1
                for idx, v in enumerate(ring):
                    if abs(v.x() - old_xy.x()) <= EPS and abs(v.y() - old_xy.y()) <= EPS:
                        vi = idx
                        break
                if vi < 0:
                    continue
                v = ring[vi]
                for nb in (ring[(vi - 1) % n], ring[(vi + 1) % n]):
                    ex, ey = nb.x() - v.x(), nb.y() - v.y()
                    emag = math.hypot(ex, ey)
                    if emag < 1e-9:
                        continue
                    ux, uy = ex / emag, ey / emag
                    par = abs(ux * lux + uy * luy)   # 1 = ขนานกับเส้นเป้าหมาย
                    if best is None or par < best[0]:
                        best = (par, ux, uy)
        return (best[1], best[2]) if best else None

    def _align_new_point(self, old_xy, poly_cache, p1, dx, dy, projfn):
        """ย้ายมุมไป 'ตามแนวขอบข้าง' (ขอบที่ต่อไปหมุดที่ไม่ได้เลือก) จนชนเส้นแนว -> ขอบนั้นคงมุมเดิม
        จะตามขอบ "เฉพาะตอนขอบตั้งฉากกับเส้นแนวพอควร" เท่านั้น (par ต่ำ) — ไม่งั้นตามขอบที่เอียงตื้น
        หมุดจะ 'ไถลออกข้าง' ไกล -> ใช้ฉายตั้งฉากแทน (ปลอดภัย ขยับน้อยสุด)"""
        perp = projfn(old_xy.x(), old_xy.y())
        lmag = math.hypot(dx, dy)
        if not poly_cache or lmag == 0:
            return perp
        sd = self._side_edge_dir(old_xy, poly_cache, dx, dy)   # ทิศขอบที่ตั้งฉากกับเส้นแนวที่สุด
        if sd is None:
            return perp
        ux, uy = sd
        lux, luy = dx / lmag, dy / lmag
        par = abs(ux * lux + uy * luy)   # 1 = ขนานเส้นแนว, 0 = ตั้งฉาก
        # ตามขอบเฉพาะขอบที่ตั้งฉากกับเส้นแนว >~60° (par<0.5) -> ไถลข้างไม่เกิน ~0.58 เท่าระยะตั้งฉาก
        max_par = QtCore.QSettings().value("MultiLayerEditPro/Align/EdgeFollowMaxPar", 0.5, float)
        if par >= max_par:
            return perp
        den = dx * uy - dy * ux
        if abs(den) < 1e-9:
            return perp
        s = ((old_xy.x() - p1.x()) * uy - (old_xy.y() - p1.y()) * ux) / den
        return QgsPointXY(p1.x() + s * dx, p1.y() + s * dy)

    def execute_point_node_alignment(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            return

        p1, p2 = self.src_pts[0], self.src_pts[1]
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag_sq = dx**2 + dy**2
        if mag_sq == 0:
            return

        def get_projected_pt(old_x, old_y):
            u = ((old_x - p1.x()) * dx + (old_y - p1.y()) * dy) / mag_sq
            return QgsPointXY(p1.x() + u * dx, p1.y() + u * dy)

        # ===== หมุดที่จะ align = หมุดที่เลือกด้วยกล่อง (box-select) =====
        picked = getattr(self, "_align_picked_ids", None)
        if picked:
            target_points = list(point_lyr.getFeatures(
                QgsFeatureRequest().setFilterFids(list(picked))))
        else:
            target_points = list(point_lyr.selectedFeatures())   # fallback: หมุดที่ select ไว้

        if not target_points:
            self.iface.messageBar().pushMessage(
                "Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน",
                level=1, duration=6)
            return

        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in (point_lyr, poly_lyr) if lyr}

        # weld node แปลงแบบ junction-aware (วัดระยะจาก "หมุดที่เลือก" -> node แปลง)
        #   ≤ AUTO_TOL      : ร่วมมุมแน่ -> รวมเข้าหมุดอัตโนมัติ (junction หลายแปลงรวมเป็นจุดเดียว)
        #   AUTO_TOL-ASK_TOL: น่าจะร่วมมุมแต่ไม่ snap -> เก็บไว้ถาม (popup ครั้งเดียว)
        #   > ASK_TOL       : คนละมุม/แปลงไม่เกี่ยว -> ไม่แตะ
        # (ค่า default จากการวัด data จริง: 74% ของมุมร่วม snap ≤2มม. • ปรับเป็น setting ได้ภายหลัง)
        s = QtCore.QSettings()
        AUTO_TOL = s.value("MultiLayerEditPro/Align/AutoMergeTol", 0.03, float)
        ASK_TOL = s.value("MultiLayerEditPro/Align/AskTol", 0.30, float)

        # ===== Prefetch ครั้งเดียว: แปลงรอบหมุดทั้งหมด + ตาราง UTM ล็อก =====
        # (เดิม _side_edge_dir + weld PASS 3 + เช็คล็อก ยิง query ต่อหมุด — บน PostgreSQL = N round-trips)
        poly_cache = (self._prefetch_align_polys(poly_lyr, target_points, max(1.0, ASK_TOL))
                      if poly_lyr else None)
        locked_map = self._locked_utm_map(poly_lyr) if poly_lyr else {}

        self._op_begin([point_lyr, poly_lyr])   # เริ่มนับ undo-step ต่อเลเยอร์
        if not point_lyr.isEditable(): point_lyr.startEditing()
        point_lyr.beginEditCommand("Align Points to Line")
        if poly_lyr:
            if not poly_lyr.isEditable(): poly_lyr.startEditing()
            poly_lyr.beginEditCommand("Align Nodes to Line")

        try:
            # ===== PASS 1: คำนวณตำแหน่งใหม่ของทุกหมุดจาก geometry "เดิม" (ก่อนแก้ไขใดๆ) =====
            moves = []   # [(pt_id, old_xy, new_pt)]
            calc_cache = {}  # Cache เพื่อให้หมุดที่ซ้อนกัน (ห่างไม่เกินมิลลิเมตร) ได้ค่า new_pt เดียวกัน
            for pt_f in target_points:
                old_xy = pt_f.geometry().asPoint()
                # ข้ามถ้าหมุดเชื่อมโยงกับแปลงที่ล็อก
                if poly_lyr and locked_map:
                    is_locked, type_str = self._is_point_feature_locked(pt_f, locked_map)
                    if is_locked:
                        self.iface.messageBar().pushMessage(
                            "Align Warning",
                            f"ข้ามการย้ายจุดหมุด {pt_f.id()} เนื่องจากเชื่อมโยงกับแปลงประเภท {type_str} (ถูกล็อก)",
                            level=2, duration=5)
                        continue
                
                key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
                if key in calc_cache:
                    new_pt = calc_cache[key]
                else:
                    # ย้ายตามแนวขอบข้าง (คงมุมขอบที่ต่อหมุดที่ไม่ได้เลือก) -> ถ้าทำไม่ได้ฉายตั้งฉาก
                    new_pt = self._align_new_point(old_xy, poly_cache, p1, dx, dy, get_projected_pt)
                    calc_cache[key] = new_pt
                    
                moves.append((pt_f.id(), old_xy, new_pt))

            # ===== PASS 2: ขยับหมุดทั้งหมด =====
            for pt_id, old_xy, new_pt in moves:
                point_lyr.changeGeometry(pt_id, QgsGeometry.fromPointXY(new_pt))

            # ===== PASS 3: weld node ของ polygon (junction-aware) =====
            # ใช้ spatial index จาก poly_cache ที่ prefetch ไว้ (เดิมยิง query ต่อหมุด)
            if poly_lyr and poly_cache:
                # รวบรวมผู้สมัคร: node แปลง -> (จุดปลายทาง, ระยะถึงหมุดที่ใกล้สุด)
                cand = {}      # (poly_id, vidx) -> (new_pt, dist)
                seen = set()
                for pt_id, old_xy, new_pt in moves:
                    key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
                    if key in seen:
                        continue
                    seen.add(key)
                    search_rect = QgsRectangle(old_xy.x() - ASK_TOL, old_xy.y() - ASK_TOL,
                                               old_xy.x() + ASK_TOL, old_xy.y() + ASK_TOL)
                    for pid in poly_cache['index'].intersects(search_rect):
                        if poly_cache['types'].get(pid, "") in ("L1-RTK", "L1-TS"):
                            continue                      # ข้ามแปลงอ้างอิงที่ล็อก (เงียบ)
                        geom = poly_cache['geoms'].get(pid)
                        if geom is None or geom.isNull():
                            continue
                        _cp, vidx, _pi, _ni, sqr = geom.closestVertex(old_xy)
                        if vidx < 0 or sqr is None:
                            continue
                        d = math.sqrt(sqr)
                        if d > ASK_TOL:
                            continue
                        vk = (pid, vidx)
                        if vk not in cand or d < cand[vk][1]:   # เก็บหมุดที่ใกล้ node นี้สุด
                            cand[vk] = (new_pt, d)

                auto = [(pid, vi, npt) for (pid, vi), (npt, d) in cand.items() if d <= AUTO_TOL]
                ask = [(pid, vi, npt, d) for (pid, vi), (npt, d) in cand.items() if AUTO_TOL < d <= ASK_TOL]

                # 3a: รวมอัตโนมัติ (≤ AUTO_TOL) — junction หลายแปลงไปจุดเดียว ปิด gap
                for pid, vi, npt in auto:
                    poly_lyr.moveVertex(npt.x(), npt.y(), pid, vi)

                # 3b: มุมที่ใกล้แต่ไม่ snap -> popup ถามครั้งเดียว ว่าจะรวมให้ไหม
                if ask:
                    ds = [d for *_, d in ask]
                    msg = (f"พบ {len(ask)} มุมแปลงที่อยู่ใกล้หมุดแต่ไม่ snap "
                           f"(เหลื่อม {min(ds)*100:.1f}–{max(ds)*100:.1f} ซม.)\n\n"
                           "ต้องการ 'รวม' มุมเหล่านี้เข้ากับหมุดด้วยไหม?\n"
                           "• Yes = รวมให้ (ปิด gap ที่มุมร่วม)\n"
                           "• No = ปล่อยไว้ (ขยับเฉพาะมุมที่ snap สนิท)")
                    ans = QtWidgets.QMessageBox.question(
                        self.dlg, "พบมุมแปลงไม่ snap", msg,
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                        QtWidgets.QMessageBox.No)
                    if ans == QtWidgets.QMessageBox.Yes:
                        for pid, vi, npt, _d in ask:
                            poly_lyr.moveVertex(npt.x(), npt.y(), pid, vi)

            # ปิด Command ทั้งสองเลเยอร์
            point_lyr.endEditCommand()
            if poly_lyr:
                poly_lyr.endEditCommand()
            self._op_commit()   # ปิด operation -> เก็บประวัติ undo

        except Exception as e:
            point_lyr.destroyEditCommand()
            if poly_lyr: poly_lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline
            self.iface.messageBar().pushMessage("Align Error", f"เกิดข้อผิดพลาด: {e}", level=2, duration=0)
            print(f"Align Error: {e}")

        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.canvas.refresh()
        self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)


# ============================================================
#  DOL iLands — เครื่องมือคลิกเลือกแปลง + worker เรียก API
# ============================================================
from .map_tools import BoxSelectTool, PolygonPickTool, AddNodeTool, SyncVertexTool

class _FnWorker(QtCore.QThread):
    """รัน callable (blocking network/IO) ใน thread แยก — done(result) / fail(exception)
    ใช้ผ่าน MultiLayerEditPro._run_net เพื่อไม่ให้ QGIS ค้างระหว่างรอ server"""
    done = QtCore.pyqtSignal(object)
    fail = QtCore.pyqtSignal(object)

    def __init__(self, fn):
        super().__init__()
        self._fn = fn

    def run(self):
        try:
            self.done.emit(self._fn())
        except Exception as e:
            self.fail.emit(e)


class ParcelLookupWorker(QtCore.QThread):
    """ระวาง(attribute) -> PARCEL_SEQ ผ่าน ArcGIS + UDM (public, ไม่ต้อง login)"""
    done = QtCore.pyqtSignal(object)   # dict หรือ None
    fail = QtCore.pyqtSignal(str)

    def __init__(self, attrs, zone=47):
        super().__init__()
        self.attrs = attrs
        self.zone = zone

    def run(self):
        from . import dol_api
        try:
            a = self.attrs
            res = dol_api.lookup_parcel_by_rawang(
                a["m1"], a["m2"], a["m3"], a["m4"], a["scale"], a["landno"],
                zone=self.zone, near_xy=a.get("near_xy"))
            self.done.emit(res)
        except Exception as e:
            self.fail.emit(f"ค้นหาไม่สำเร็จ: {e}")
