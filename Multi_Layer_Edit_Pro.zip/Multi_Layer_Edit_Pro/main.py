import os
import math
import time
import requests
import zipfile
import io
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import (QgsProject, QgsPointXY, QgsGeometry, QgsPointLocator,
                       QgsSnappingConfig, QgsTolerance, QgsWkbTypes,
                       QgsFeatureRequest, QgsVectorLayer, QgsFeature,
                       QgsExpression, QgsSpatialIndex)
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsVertexMarker, QgsRubberBand, QgsSnapIndicator
from qgis.core import QgsRectangle, QgsCoordinateTransform, QgsCoordinateReferenceSystem
from qgis.utils import iface


# ประวัติการอัปเดต (ใหม่สุดอยู่บน) — ใช้เด้ง "What's New" หลังอัปเดตเวอร์ชัน
CHANGELOG = [
    ("2.0.0", ["🆕 Snap ติด \"เส้นที่วาด (Line)\" ของปลั๊กอิน วาดเส้น & วัดระยะ ด้วยแล้ว",
               "  วาดเส้นอ้างอิงไว้ก่อน แล้วลากมุมแปลง/หมุดเข้าไปเกาะเส้นนั้นได้ตรง ๆ",
               "  (เหมือนที่ snap ติดชั้นหมุดหลักฐาน CT อยู่แล้ว — ไม่ต้องตั้งค่าอะไรเพิ่ม)",
               "  ชั้นป้าย \"ระยะเส้น (Label)\" ไม่ถูกนำมา snap เพื่อไม่ให้ดูดผิดจุด"]),
    ("1.9.9", ["🆕 ปุ่มใหม่ \"📝 หมายเหตุ (REMARK)\" (อยู่ซ้ายปุ่ม Sync Cluster ID)",
               "  ใส่/แก้หมายเหตุให้แปลงที่เลือกทีเดียวทั้งกลุ่ม เลือกจากรายการที่ใช้บ่อยหรือพิมพ์เองก็ได้",
               "  ถ้าแปลงที่เลือกมีหมายเหตุเดิมเหมือนกัน จะเติมค่าเดิมไว้ให้แก้ต่อ • เว้นว่าง = ลบหมายเหตุ",
               "  (รายการที่ให้เลือกมาจากข้อความที่ใช้จริง เพื่อให้เขียนตรงกันทั้งกรม สรุปยอดทีหลังได้)",
               "เร็วขึ้นอีก — ลดการถามฐานข้อมูลซ้ำระหว่างทำงาน:",
               "  • Transform: เดิมตรวจ \"ปลายทางอยู่บนหมุด RTK ไหม\" ซ้ำทุกแปลง/ทุกหมุดที่เลือก",
               "    (กลุ่ม 50 แปลง 300 หมุด = ถามฐานข้อมูลราว 700 ครั้ง) ตอนนี้ถามครั้งเดียวแล้วใช้ซ้ำ",
               "  • Align: อ่านค่าตั้งค่าจากไฟล์ซ้ำทุกหมุด -> อ่านครั้งเดียวต่อการใช้งาน",
               "  • เงาตัวอย่างตอนเริ่มลาก: นับมุมแปลงเร็วขึ้น (ใช้ตัวนับภายในแทนการไล่ทีละมุม)",
               "  • ตรวจล็อกแปลงอ้างอิง: เลิกค้นหาชื่อคอลัมน์ซ้ำทุกหมุด"]),
    ("1.9.8", ["🔴 แก้หน้าต่าง \"มีอะไรใหม่\" ที่สูงเกินจอจนกดปิดไม่ได้",
               "  เวอร์ชันก่อนหน้ามีรายการเปลี่ยนแปลงยาว ทำให้กล่องยืดสูงกว่า 1,500 จุด = ปุ่ม OK หลุดใต้ขอบจอ",
               "  ตอนนี้เป็นหน้าต่างที่กำหนดขนาดตามจอ เลื่อนอ่านได้ และลากมุมปรับขนาดเองได้",
               "  (ถ้าเจอกล่องปิดไม่ได้ ให้กด Enter หรือ Esc ปิดได้เสมอ)"]),
    ("1.9.7", ["🔴 แก้อาการ \"กดบันทึกแล้วโปรแกรมค้าง\" — กล่องข้อความทุกกล่องจะเด้งอยู่หน้าสุดเสมอ",
               "  เดิมกล่องยืนยันผูกกับหน้าต่างปลั๊กอิน ถ้าหน้าต่างนั้นถูกย่อ/ถูกบัง กล่องจะไปซ่อนอยู่ข้างหลัง",
               "  แต่มันล็อก QGIS ไว้รอคำตอบ = เห็นเป็นโปรแกรมค้าง ทั้งที่แค่รอให้กดปุ่มในกล่องที่มองไม่เห็น",
               "  ★ ถ้าเคยต้องปิดโปรแกรมทิ้งเพราะอาการนี้แล้วงานหาย จะไม่เกิดอีก",
               "🔴 เพิ่มตัวเตือน \"ยังไม่ได้บันทึก\" — งานค้างเกิน 10 นาที จะเตือนบนแถบข้อความเป็นระยะ",
               "  (ไม่บล็อกการทำงาน แค่กันลืมบันทึกจนงานทั้งก้อนหายถ้าโปรแกรมปิดกะทันหัน)",
               "การตรวจ \"มุมแปลงไม่มีหมุด\" ก่อนบันทึก ไม่หน่วงการบันทึกอีกต่อไป — ขึ้นนาฬิกาทรายให้เห็นว่ากำลังทำงาน",
               "  ถ้าตรวจไม่ทันในเวลาที่กำหนด จะข้ามการตรวจแล้วให้บันทึกต่อ ไม่ปล่อยให้รอ",
               "  + ตรวจเพิ่มอีกด้าน: หมุดที่เพิ่งย้าย/เพิ่ม แต่ไม่ได้ทับมุมแปลง จะถูกเตือนด้วย",
               "บันทึกซื่อสัตย์ขึ้น: ถ้าชั้นแรกบันทึกไม่สำเร็จจะหยุดทันที ไม่บันทึกอีกชั้นต่อ",
               "  (กันหมุดลงฐานข้อมูลแต่แปลงไม่ลง) และบอกตรง ๆ ว่าอะไรลงไปแล้ว อะไรยังค้างอยู่",
               "  ถ้าไม่มีอะไรค้างให้บันทึก จะบอกว่า \"ไม่มีการแก้ไขค้างอยู่\" แทนคำว่าบันทึกสำเร็จ",
               "🔴 Move / Rotate / Scale / Transform: ถ้าเขียนข้อมูลไม่สำเร็จกลางคัน จะย้อนกลับให้ทั้งงาน",
               "  ทั้งชั้นแปลงและชั้นหมุด (เดิมย้อนเฉพาะชั้นที่พัง แล้วเดินหน้าทำอีกชั้นต่อ = แปลงกับหมุดหลุดคู่กัน)",
               "Align: เวลาเชื่อมมุมแปลงข้างเคียงเข้าเส้น จะลากหมุดของแปลงนั้นตามไปด้วย (ไม่ทิ้งมุมไร้หมุด/หมุดลอย)",
               "  + จำกัดการเลือกไม่เกิน 800 จุดต่อครั้ง เหมือน Move Node (กันเครื่องค้าง)",
               "  + ต้องเลือกทั้งชั้นแปลงและชั้นหมุดก่อน (เดิมมีแค่ชั้นหมุดก็ทำได้ แต่มุมแปลงจะไม่ถูกเชื่อม)",
               "Move Node: ต้องเลือกทั้งสองชั้นเช่นกัน (เดิมมีชั้นเดียวก็ทำได้ ทำให้ด่านล็อกแปลงอ้างอิงไม่ทำงาน)",
               "ลบ node: แปลงที่มี \"รู\" หรือหลายส่วน จะนับมุมเฉพาะวงที่คลิก (เดิมนับรวมทั้งแปลง เผลอลบทั้งวงได้)",
               "Add Node: ถ้าจุดที่คลิกห่างจากขอบแปลงเกิน 2 เมตร จะข้ามให้ (กันรูปแปลงบิดตามหมุดที่อยู่ไกล)",
               "ตั้ง Score / Cluster: กันไม่ให้ลงค่าทับแปลงอ้างอิง L1 (Cluster จะข้ามเฉพาะแปลง L1 แล้วทำแปลงอื่นต่อ)",
               "ค้นหาภาพลักษณ์: กดค้นซ้อนระหว่างที่ยังค้นอยู่ไม่ได้แล้ว (เดิมเป็นสาเหตุให้ QGIS ปิดตัวเองได้)",
               "  + ถ้าระบบ DOL ไม่มีพิกัดของแปลงนั้น จะแจ้งสาเหตุแทนการค้างหรือได้ผลมั่ว",
               "เร็วขึ้น: เริ่มเครื่องมือซ้ำบนกลุ่มเดิม ไม่ต้องเลือกกลุ่มใหม่ทุกครั้ง (ประหยัดราว 0.1-0.2 วินาที/ครั้ง)"]),
    ("1.9.6", ["🔴 แก้อาการค้าง ~1 วินาที ที่ยังเหลือ — หลังกดบันทึกแล้วเริ่มขยับงานถัดไป",
               "  เดิมทุกครั้งที่บันทึก ระบบจะลืมรายชื่อแปลงอ้างอิง (L1-RTK/L1-TS) ที่จำไว้ แล้วต้องไล่อ่านแปลง L1",
               "  ทั้งอำเภอใหม่ (~9 หมื่นแปลง) ตอนเริ่มงานถัดไป = ค้างราว 1 วินาทีทุกครั้งหลังบันทึก",
               "  ตอนนี้จำไว้ตลอดการเปิดโปรแกรม (แปลงอ้างอิงไม่เปลี่ยนระหว่างทำงานอยู่แล้ว) — จะหน่วงเฉพาะงานแรก",
               "  หลังเปิดโปรแกรมครั้งเดียว จากนั้นลื่นตลอด แม้กดบันทึกบ่อย"]),
    ("1.9.5", ["🔴 แก้อาการ QGIS ค้างตอนกดบันทึก — ตอนนี้เร็วขึ้นราว 25 เท่า",
               "  เดิมทุกครั้งที่บันทึก ระบบต้องไล่อ่านหมุดทั้งตาราง (ปทุมฯ 1.18 ล้านจุด) เพื่อตรวจว่ามุมแปลงมีหมุดครบไหม",
               "  ตอนนี้จำกัดให้ค้นเฉพาะบริเวณแปลงที่กำลังแก้ (ใช้ดัชนีเชิงพื้นที่ที่มีอยู่แล้ว) — ผลการตรวจเหมือนเดิมทุกจุด",
               "🔴 แก้บั๊กสำคัญ: Add Node ไม่ได้กันแปลง L1-RTK/L1-TS เลยตั้งแต่ต้น (ควรห้ามเลือก/ห้ามเพิ่ม แต่กลับทำได้)",
               "  สาเหตุ: ตอน hover ดึงข้อมูลแปลงแบบไม่เอา attribute เลย -> อ่านค่า Type ไม่ได้ -> ไม่รู้ว่าเป็นแปลงล็อก",
               "  ตอนนี้ hover จะขึ้นสีแดงและกดเลือกไม่ได้จริงตามที่ตั้งใจไว้",
               "🔴 Move Node: ถ้าเลือก \"เฉพาะหมุด\" ไว้ มุมแปลงที่ไม่ใช่ของหมุดนั้นจะไม่ถูกลากไปด้วยแล้ว",
               "  (เดิมกวาดทุกมุมในกรอบ -> มุมขยับแต่หมุดอยู่กับที่ = แปลงกับหมุดหลุดคู่กัน)",
               "Move Node: เปิด snapping ให้อัตโนมัติ + จำกัดการเลือกไม่เกิน 800 จุด (กันเครื่องค้าง)",
               "Undo ของปลั๊กอิน: ถ้ามีการแก้ไขอื่นแทรกหลังงานล่าสุด จะเตือนแทนที่จะย้อนผิดงาน",
               "  และไม่พังเมื่อชั้นข้อมูลถูกถอดออกจากโปรเจกต์ไปแล้ว",
               "ตัวเตือน \"มุมแปลงไม่มีหมุด\" ครอบการแก้ชั้นหมุดอย่างเดียวแล้ว (ย้าย/ลบหมุดด้วยเครื่องมือ QGIS ก็ตรวจเจอ)",
               "Ctrl+Z ของปลั๊กอินใช้ได้ทันทีหลังเปิด QGIS (เดิมต้องเปิดหน้าต่างปลั๊กอินก่อนหนึ่งครั้ง)",
               "By UTM/Cluster: เลือกหมุดตามชื่อคอลัมน์ของชั้นหมุดเอง (เดิมถ้าชื่อคอลัมน์ต่างจากชั้นแปลง หมุดจะไม่ถูกเลือกเงียบ ๆ)",
               "ค้นหาภาพลักษณ์: แจ้ง error จากระบบ DOL ตรง ๆ (เดิมระบบขัดข้องก็ขึ้นว่า \"ไม่พบแปลง\")"]),
    ("1.9.4", ["แก้: ถ้าลบชั้นหมุดออกแล้วเพิ่มกลับ (เช่นฐานข้อมูลหลุดแล้วต่อใหม่) กล่องเลือกชั้นเคยไปค้างที่ CT_<สาขา>",
               "  แล้วแก้เองไม่ได้ทั้ง session — ตอนนี้เลือกให้ใหม่อัตโนมัติ แต่ยังไม่ทับถ้าท่านเลือกเอง",
               "แจ้งบนแถบข้อความทุกครั้งที่เลือกชั้นให้อัตโนมัติ (เดิมเงียบเมื่อโปรเจกต์มีสาขาเดียว)"]),
    ("1.9.3", ["เปิดปลั๊กอินแล้วเลือกชั้น \"แปลง\" กับ \"หมุด\" ให้อัตโนมัติ (จับคู่จากชื่อ <สาขา>_POLYGON / <สาขา>_POINT)",
               "ไม่ทับสิ่งที่เลือกเอง — ถ้าเคยเลือกไว้แล้วจะคงของเดิม"]),
    ("1.9.2", ["Snap ติดชั้นหมุดหลักฐาน CT ด้วยแล้ว — ลากมุมแปลง/หมุด เข้าหาหมุดหลักฐานได้ตรง ๆ",
               "หาชั้น CT ให้อัตโนมัติจากชื่อ (CT_<สาขา>) ไม่ต้องตั้งค่าเพิ่ม",
               "Add Node: ถ้าแปลงนั้นมีหมุดอยู่ตรงจุดนั้นแล้ว จะไม่เพิ่มซ้ำ (เดิมคลิกซ้ำจุดเดิม = ได้หมุดซ้อนกัน)",
               "  • มุมร่วมกับแปลงข้างเคียงยังเพิ่มได้ปกติ (คนละระวาง = คนละหมุด) และจะบอกว่าข้ามไปกี่จุด",
               "อัปเดต: ตรวจเวอร์ชันในไฟล์ที่โหลดมาก่อนติดตั้ง + ปฏิเสธถ้าไม่ใหม่กว่าของเดิม (กันโดน downgrade)",
               "อัปเดต: แตกไฟล์ที่พักก่อนแล้วค่อยสลับ + สำรองของเดิมไว้ ถ้าพลาดกลางคันคืนให้อัตโนมัติ"]),
    ("1.9.1", ["เช็คเวอร์ชันใหม่ให้อัตโนมัติตอนเปิดปลั๊กอิน",
               "ตัวเตือน \"มุมแปลงไม่มีหมุด\" ครอบทุกวิธีบันทึกแล้ว — เดิมเตือนเฉพาะตอนกดปุ่ม \"💾 บันทึก\" ของปลั๊กอิน",
               "ถ้ากด Save ของ QGIS เอง (Save Layer Edits / ปิดโหมดแก้ไข) จะเตือนทันทีหลังบันทึก พร้อมบอกวิธีแก้",
               "⚠️ ย้ำ: เพิ่มมุมแปลงต้องใช้ปุ่ม \"➕ Add Node\" เท่านั้น — Vertex Tool ของ QGIS ไม่สร้างหมุดให้"]),
    ("1.9.0", ["บันทึก (Commit): เตือนถ้ามีมุมแปลงที่ไม่มีหมุด — กันหมุดหายโดยไม่รู้ตัว (กด \"บันทึกต่อ\" ได้ ไม่บังคับ)",
               "⚠️ อย่าเพิ่มมุมแปลงด้วยเครื่องมือ Vertex Tool ของ QGIS — มันไม่สร้างหมุดให้ ใช้ปุ่ม \"➕ Add Node\" เท่านั้น",
               "ค้นหาภาพลักษณ์/หลักฐานรังวัด: คลิกจุดที่มีแปลงซ้อนกัน → มี popup ให้เลือกแปลง (ระวาง • มาตราส่วน • เลขที่ดิน)",
               "Add Node: หมุดที่เพิ่มใหม่ติดป้าย EDIT_SRC='added' + ฐานข้อมูลบันทึกชื่อผู้แก้/เวลาให้เอง (ตรวจย้อนหลังได้)",
               "เร็วขึ้นบนฐานข้อมูลผ่าน network: เช็คล็อก L1-RTK/L1-TS จำผลไว้ทั้ง session (เดิมยิงคิวรีใหม่ทุกครั้งที่ขยับ)",
               "Snap: จำกัดเฉพาะชั้นแปลง+หมุดที่เลือกไว้ได้จริง แม้เปิด snapping ค้างไว้ก่อนเปิดปลั๊กอิน"]),
    ("1.8.0", ["Move/Rotate/Scale: เห็น \"เงาตัวอย่าง\" (สีฟ้า) ว่าแปลง+หมุดจะไปตกที่ไหน ก่อนคลิกยืนยัน",
               "Move/Rotate/Scale: มีตัวเลขบอกระยะ/มุม/สเกล ตามเมาส์ที่แถบสถานะด้านล่าง",
               "เงาตัวอย่างใช้สูตรเดียวกับตอนแก้จริง — เห็นอย่างไรได้อย่างนั้น",
               "เลือกทั้งระวาง (แปลงเยอะ) เงาจะย่อเป็นกรอบรวมอัตโนมัติ เพื่อไม่ให้หน่วง",
               "เลือกแปลง L1-RTK/L1-TS จะเตือนตั้งแต่คลิกแรกว่าขยับไม่ได้ (เดิมรู้ตอนคลิกจบ)",
               "เก็บกวาดเงา/หมุดที่ค้างบนจอ เมื่อสลับไปใช้เครื่องมืออื่นของ QGIS"]),
    ("1.7.0", ["PostgreSQL: ลด query ข้าม network ครั้งใหญ่ — เช็คล็อก L1-RTK/L1-TS เหลือคิวรีเดียวต่อรอบ, Align/Move Node ดึงข้อมูลแบบ batch",
               "Hover (ค้นหาภาพลักษณ์/Add Node) ไม่ยิง query ทุกเฟรม — ลื่นขึ้นมากบนฐานข้อมูลผ่าน network",
               "บันทึก (Commit): เช็คผลจริงจากฐานข้อมูล — บันทึกไม่ผ่านจะเตือนพร้อมสาเหตุ (เดิมขึ้น 'สำเร็จ' เสมอ)",
               "ค้นหลักฐานรังวัด/เข้าสู่ระบบ/Check Update ทำงานเบื้องหลัง — QGIS ไม่ค้างเมื่อ server ช้า",
               "Snap เฉพาะชั้นแปลง+หมุดที่เลือกไว้ (เดิม AllLayers ทำ index ทุกชั้น)",
               "รายชื่อเลเยอร์อัปเดตอัตโนมัติเมื่อเพิ่ม/ลบเลเยอร์ + จำเลเยอร์ที่เลือกไว้ตอน Refresh",
               "กันค่า attribute ที่มีอักขระพิเศษ (') ทำ expression เลือกกลุ่ม/เช็คล็อกพัง",
               "เตือนเมื่อโปรเจกต์เปิด Automatic transaction groups (กระทบระบบ Undo ของปลั๊กอิน)"]),
    ("1.6.3", ["Fix: เพิ่มระบบป้องกันคืนคิวฐานข้อมูล (Lock) เมื่อเกิด Error ใน Change Score และ Group Cluster ID ป้องกันปัญหาหน้าจอ QGIS ค้าง"]),
    ("1.6.2", ["Align: หมุดที่เลือกวิ่งไปหาเส้นแบบ 'ตามแนวขอบ' → ขอบที่ต่อหมุดที่ไม่ได้เลือกไม่เบี้ยวตาม (เดิมฉายตั้งฉากแล้วขอบเอียง)",
               "Align: weld มุมแปลงแบบ junction-aware — มุมร่วมรวมให้, มุมไม่ snap เด้งถาม, แปลงข้างเคียงที่ไม่เกี่ยวไม่โดนลาก (เดิมเหวี่ยง 5ซม.)"]),
    ("1.6.1", ["Undo: ย้อนทั้งเลเยอร์แปลง+หมุดให้ตรงกันเสมอ + กดซ้อนหลายครั้งได้ถูกต้อง (แก้ Sync Cluster ID ที่เดิม undo ไม่ติด)",
               "Undo: ถ้าเผลอปิดแก้ไขเลเยอร์ไป — ปิดแบบ Save จะเตือน • ปิดแบบ Discard จะถามว่าย้อนอีกเลเยอร์กลับจุดเริ่มให้ตรงกันไหม",
               "เพิ่มประสิทธิภาพ Move Node/Align ตอนเลือกหมุดเยอะ และ hover ค้นหาภาพลักษณ์ให้ลื่นขึ้น"]),
    ("1.6.0", ["Move Node โหมดใหม่: คลิกหมุดเดียว → คลิกตำแหน่งใหม่เพื่อย้าย (มีเส้นนำ)",
               "Move Node: ลากกล่องเลือกหลายหมุดแล้วลากย้าย (Shift+ลาก = เลือกเพิ่ม)",
               "แก้ค้นหาภาพลักษณ์/หลักฐานรังวัดขึ้น \"ข้อมูลแปลงไม่ครบ\" (อ่าน attribute แปลงที่คลิกไม่ครบบนบางชนิดข้อมูล)",
               "เพิ่มประสิทธิภาพการทำงาน (cache การหา field, ลดการ query ซ้ำ)"]),
    ("1.5.6", ["เพิ่มประสิทธิภาพการทำงานและความลื่นไหล"]),
    ("1.5.5", ["แก้ไข Move Node ดึงหมุดแปลงข้างเคียงตาม (หากมีการ Select แปลงเอาไว้ จะย้ายแค่แปลงที่ Select จริงๆ เท่านั้น)"]),
    ("1.5.4", ["เพิ่มเงื่อนไขเครื่องมือ Move Node: หากมีการ Select แปลงอยู่ จะจำกัดให้ย้ายได้เฉพาะมุมของแปลงที่ Select ไว้เท่านั้น"]),
    ("1.5.3", ["เพิ่มกันชน L1-RTK/L1-TS กลับเข้าไปในเครื่องมือ Move Node เพื่อป้องกันไม่ให้ถูกตีกรอบครอบไปขยับพิกัด"]),
    ("1.5.2", ["ปรับปรุงเครื่องมือ Move Node ให้รองรับการเลือกหมุดแบบสะสม (ตีกรอบเพิ่มได้เรื่อยๆ โดยไม่ต้องกดคีย์บอร์ด)"]),
    ("1.5.1", ["แก้บั๊กมุมแปลง (Polygon Node) ไม่ขยับตามหมุดตอนใช้ Move Node", "เพิ่มประสิทธิภาพการทำงานและความลื่นไหล"]),
    ("1.5.0", ["เพิ่มปุ่ม \"ค้นหาหลักฐานการรังวัด\" (ต้อง login — ใส่รหัสตอนใช้ ไม่เก็บถาวร)",
               "คลิกแปลง -> เปิดหลักฐานรังวัด • หลายรายการมี popup ให้เลือก",
               "ปรับปรุงประสิทธิภาพเครื่องมือ Align และเครื่องมืออื่นๆ (แก้ปัญหาค้าง/หน่วง)"]),
    ("1.4.4", ["เพิ่มระบบเด้ง \"มีอะไรใหม่\" สรุปการเปลี่ยนแปลงหลังอัปเดต"]),
    ("1.4.3", ["กันชน L1-RTK/L1-TS ในเครื่องมือ Add Node (hover แดง • เลือก/เพิ่มไม่ได้)"]),
    ("1.4.2", ["Add Node: เลือกได้ทีละ 1 แปลง",
               "เพิ่ม hover highlight แปลงใต้เมาส์"]),
    ("1.4.1", ["Add Node: ตัดคลิกขวา ใช้ snap เลือกหมุด (วงกลมแดง)"]),
    ("1.4.0", ["เพิ่มเครื่องมือ Add Node: เพิ่ม node + หมุด (ระวางจากแปลง, ชื่อจากหมุดเดิม, หลายชื่อมี popup เลือก)",
               "เปลี่ยนชื่อปุ่ม Align Points to Line → Align Points"]),
    ("1.3.7", ["Shortcut: ปลดคีย์เดิมของ QGIS ที่ชนได้ (ถามก่อนทำ)"]),
    ("1.3.6", ["ค้นหาภาพลักษณ์: แก้ปัญหาขึ้นผิดสาขา (ระวางคร่อมสาขา เลือกแปลงใกล้จุดคลิก)",
               "Shortcut: เตือนเมื่อคีย์ชนกับ QGIS"]),
    ("1.3.5", ["Align Points: ปรับระยะเชื่อม node เป็น 0.05 ม."]),
    ("1.3.4", ["Align Points: แก้หมุดที่ซ้อนกันกระเด็นแยก (คำนวณตำแหน่งก่อนแก้ไข)"]),
    ("1.3.3", ["Align Points: เพิ่มระยะเชื่อม node ของแปลงข้างเคียง"]),
    ("1.3.2", ["Clean/optimize โค้ด", "เอาเครื่องมือ Auto/Semi-Auto Transform ออก"]),
    ("1.3.1", ["Reset: เคลียร์ feature ที่เลือกทั้งหมดใน QGIS",
               "ปรับเวลาแสดง message bar (error ค้าง, อื่นๆ หายเอง)"]),
    ("1.3.0", ["UI หน้าเดียวกระทัดรัด", "ค้นหาภาพลักษณ์ DOL",
               "Align แบบ box-select", "ตั้งค่า Shortcut"]),
]


# ที่อยู่ไฟล์อัปเดตบน GitHub — ใช้ร่วมกันทั้งปุ่ม 🚀 Check Update และการเช็คอัตโนมัติตอนเปิด
UPDATE_V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
UPDATE_Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"


def _vkey(v):
    """แปลงเลขเวอร์ชัน '1.4.3' -> (1,4,3) เพื่อเทียบเชิงตัวเลข"""
    try:
        return tuple(int(x) for x in str(v).strip().split("."))
    except Exception:
        return (0,)


_UTM_FIELD_NAMES = {'utm', 'utm_code', 'utm_id'}


def _norm_utm(v):
    """normalize ค่า UTM เป็น string สำหรับเทียบข้ามเลเยอร์
    (กันเคส provider คนละชนิดคืน 123 กับ 123.0 แล้วเทียบไม่ตรงกัน)"""
    s = str(v).strip()
    if s.endswith(".0"):
        s = s[:-2]
    return s


# ============ เงาตัวอย่าง (preview) ของ Move/Rotate/Scale ============
# จำนวนคลิกที่แต่ละโหมดต้องใช้ — ใช้ร่วมกันทั้ง handle_click และเงาตัวอย่าง
# (เดิมตารางนี้อยู่ใน handle_click ที่เดียว — แยกออกมากัน "จำนวนคลิก" ของสองฝั่งหลุดจากกัน)
_CLICK_LIMIT = {'move': 2, 'modify_node': 2, 'rotate': 3, 'scale': 3, 'transform': 4}

# โหมดที่มีเงาตัวอย่าง — transform/modify_node ไม่มี:
#   transform: กฎปลดล็อก L1-TS ตัดสินจากจุดที่ 4 ซึ่งก็คือเมาส์ -> เงาจะพลิกไปมาทุกเฟรม
#   modify_node: ขยับ vertex เดียว ไม่ใช่ทั้งแปลง
_PREVIEW_MODES = ('move', 'rotate', 'scale')

# เกินจำนวนจุดนี้ -> ย่อเงาแปลงเป็นกรอบรวม (convex hull) กันเฟรมตกตอนเลือกทั้งระวาง
# hull ไม่ทำให้เงาโกหก: move/rotate/scale เป็น similarity ทั้งหมด -> hull(T(g)) == T(hull(g))
_PREVIEW_VERTEX_BUDGET = 20000


class MultiLayerEditPro:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = []
        self.temp_tool = None
        self.last_layers = []   # เลเยอร์ที่แก้ล่าสุด (ใช้ refer ทั่วไป — undo ใช้ op_history แทน)
        # ประวัติการแก้ไขของปลั๊กอินสำหรับ Undo: แต่ละรายการ = [(layer, n_steps), ...] ใหม่สุดท้าย
        self.op_history = []
        self._op_baseline = None   # snapshot index ของ undo-stack ก่อนเริ่ม operation ปัจจุบัน
        # ดักสถานะตอนปิด edit ของแต่ละเลเยอร์ (รู้ว่ากด Save หรือ Discard) สำหรับ guard ตอน undo
        self._edit_end = {}        # layer_id -> 'commit' | 'rollback'
        self._commit_seq = {}      # layer_id -> จำนวนครั้งที่ commit (ใช้จับ 'Save แทรกหลัง op')
        self._admin_on = False          # โหมดผู้ดูแล (เปิดด้วย Ctrl+Shift+F12 + เป็นสมาชิก mlep_admin)
        self._admin_unlock_l1 = False   # ปลดล็อก L1-RTK/L1-TS ชั่วคราว (เฉพาะตอน admin)
        self._signal_layers = set()
        self._signal_conns = []    # [(signal, slot)] ไว้ disconnect ตอน unload
        # เตือน "งานค้างยังไม่ได้บันทึก" — เหตุ 5 ส.ค. 69 พนักงานแก้สะสม 20 นาทีแล้วโปรแกรมค้าง
        # ต้อง kill = งานหายทั้งก้อน (ยังไม่เคยถึงฐานข้อมูล) -> เตือนแบบไม่บล็อก ทุก UNSAVED_NAG_MIN นาที
        self._unsaved_since = None      # เวลาที่เริ่มมีงานค้าง (monotonic)
        self._unsaved_last_nag = 0.0
        self._nag_timer = None
        self.mode = ""
        self.version = "2.0.0"
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล
        self.rubber_band = None
        # เงาตัวอย่าง Move/Rotate/Scale: [(layer, geom ต้นฉบับ, rubber band, gtype)]
        # geom snapshot ไว้ตอนคลิกแรก -> ทุกเฟรมแค่ copy+แปลง ไม่ต้องดึงข้อมูลใหม่
        self._preview_items = []
        self._preview_last = None   # key ของเฟรมล่าสุด (None = ไม่มีเงาบนจอ)
        self._preview_tool = None   # เครื่องมือที่เป็นเจ้าของเงารอบนี้ (ดู _map_tool_changed)
        self._preview_heavy = False # เงาถูกย่อเป็นกรอบรวมหรือไม่ (ไว้บอกผู้ใช้ที่แถบสถานะ)
        self._dol_highlight = None  # rubber band ไฮไลต์แปลงที่ค้นหา
        self._align_picked_ids = set()  # หมุดที่เลือกด้วยกล่อง (Align)
        self._align_markers = []
        self._shortcuts = []  # QShortcut ที่ผูกไว้
        self._field_cache = {}  # memoize การหา field ตามชื่อ (สำหรับ hover path ที่เรียกทุกเฟรม)
        # เฝ้า "มุมแปลงไม่มีหมุด" ตอน commit ทุกช่องทาง (รวมปุ่ม Save ของ QGIS เอง ไม่ใช่แค่ปุ่มปลั๊กอิน)
        self._pending_pair_warn = None   # ผลตรวจที่เก็บไว้ตอน beforeCommit -> เอาไปเตือนตอน afterCommit
        self._pair_warn_ack = False      # True = ปุ่ม Save ของปลั๊กอินถามไปแล้ว อย่าเตือนซ้ำ
        self._user_picked = False        # ผู้ใช้สลับชั้นเอง -> อย่าไปเลือกให้ใหม่ทับ
        self._refreshing = False         # กัน setCurrentIndex ของโค้ดเราเองไปนับเป็น "ผู้ใช้เลือก"

    # ============ ตัวช่วยหา field (memoize ตาม layer.id) — ใช้ใน hover ที่เรียกถี่ ============
    def _resolve_field(self, layer, candidates):
        """คืนชื่อ field แรกที่ตรงกับ candidates (เทียบ lowercase) หรือ None — cache ตาม layer.id()
        ใช้กับ hot path เช่น _poly_type_str ที่ถูกเรียกทุก mouse-move
        (call site แบบครั้งเดียวต่อคลิกใช้ _field_index ได้ ไม่ต้องผ่าน cache นี้)"""
        ckey = (layer.id(), frozenset(candidates))
        if ckey in self._field_cache:
            return self._field_cache[ckey]
        name = next((f.name() for f in layer.fields()
                     if f.name().lower() in candidates), None)
        self._field_cache[ckey] = name
        return name

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)
        # ★ ผูก shortcut ตั้งแต่โหลดปลั๊กอิน — เดิมผูกเฉพาะตอนเปิดหน้าต่าง (create_dialog)
        #   แต่คีย์ Ctrl+Z ของ QGIS ถูกปลดถาวรไปแล้ว -> หลังเปิด QGIS ใหม่ Ctrl+Z จะไม่ทำอะไรเลย
        #   จนกว่าผู้ใช้จะเปิดหน้าต่าง MLEP
        try:
            self._load_shortcuts()
        except Exception:
            pass
        # ★ โหมดผู้ดูแล: คีย์ลัดซ่อน (ไม่อยู่ในรายการตั้งค่า shortcut ที่พนักงานเห็น)
        #   กดสลับเข้า/ออก — ตัวล็อกจริงคือ "role ที่ต่อ DB ต้องเป็นสมาชิก mlep_admin/superuser"
        try:
            self._admin_sc = QtWidgets.QShortcut(
                QtGui.QKeySequence("Ctrl+Shift+F12"), self.iface.mainWindow())
            self._admin_sc.setContext(QtCore.Qt.ApplicationShortcut)
            self._admin_sc.activated.connect(self.toggle_admin_mode)
        except Exception:
            pass
        # กันเงา/หมุดค้างจอ: ผู้ใช้กดเครื่องมืออื่นของ QGIS (Pan/Select) กลางคัน = เลิกใช้เครื่องมือเรา
        # แต่ไม่มีใครเก็บกวาดให้ (เส้นทางนี้ไม่ผ่าน cancel_transform) -> ดักที่ signal เปลี่ยนเครื่องมือ
        try:
            self.iface.mapCanvas().mapToolSet.connect(self._map_tool_changed)
        except Exception:
            pass

    def _map_tool_changed(self, new_tool=None, *_a):
        """เปลี่ยนเครื่องมือ -> เก็บกวาดเงา + หมุดของรอบที่ค้างไว้

        เทียบกับ "เจ้าของเงา" (_preview_tool ที่บันทึกตอน arm) ไม่ใช่ self.temp_tool ปัจจุบัน:
        ทุก start_* ตั้ง self.temp_tool = ตัวใหม่ "ก่อน" setMapTool เสมอ ถ้าเทียบกับ temp_tool
        จังหวะ setMapTool จะ early-return ทุกครั้งที่สลับข้ามเครื่องมือของปลั๊กอินเอง
        (เช่น กด Move คลิกแรกแล้วไปกด Move Node ต่อ) -> เงารอบก่อนค้างจอ
        เทียบกับเจ้าของเงาแทน = เก็บกวาดตอน setMapTool ตรงๆ ไม่ต้องพึ่งจังหวะที่ Python
        คืนหน่วยความจำเครื่องมือตัวเก่า (ซึ่งเป็นกลไกที่มองไม่เห็นจากโค้ดและพึ่งพาไม่ได้)
        เทียบด้วย is (ไม่ใช่ ==) และไม่แตะ oldTool เลย — oldTool อาจกำลังถูกทำลายอยู่
        รับ *_a เพราะ signal นี้มีทั้งแบบ 1 และ 2 อาร์กิวเมนต์ตามรุ่น QGIS

        กัน instance เก่าค้าง: signal นี้ผูกกับ canvas ซึ่งอายุยืนกว่าตัวปลั๊กอิน ถ้า unload
        ของ instance ก่อนหน้าไม่ได้ทำงาน (เช่น reload ปลั๊กอินกลางคันตอนแก้โค้ด) slot จะยัง
        ถูกเรียกบน object เก่าที่โครงไม่ครบ -> ใช้ getattr + try กันพ่น error ทุกครั้งที่
        สลับเครื่องมือ (งานในนี้เป็นแค่การเก็บกวาด ล้มเหลวอย่างมากคือเงาค้าง ไม่กระทบข้อมูล)"""
        if new_tool is not None and new_tool is getattr(self, "_preview_tool", None):
            return
        try:
            self._preview_clear()
            self.clear_markers()
        except Exception:
            pass

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", self.action)
        try:
            self.iface.mapCanvas().mapToolSet.disconnect(self._map_tool_changed)
        except Exception:
            pass
        # หยุดตัวเตือนงานค้าง (กัน timer ยิงเข้า instance เก่าหลัง unload/self-update)
        _t = getattr(self, "_nag_timer", None)
        if _t is not None:
            try:
                _t.stop(); _t.deleteLater()
            except Exception:
                pass
            self._nag_timer = None
        # ★ ปิดหน้าต่างปลั๊กอินด้วย — เดิมไม่ปิด ทำให้หลัง reload/self-update มี "หน้าต่างผี"
        #   ที่ปุ่มยังผูกกับ instance เก่า ค้างอยู่บนจอ
        if getattr(self, "dlg", None) is not None:
            try:
                self.dlg.close(); self.dlg.deleteLater()
            except Exception:
                pass
            self.dlg = None
        self.clear_markers()
        self._preview_clear()
        self._dol_clear_highlight()
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None); sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        # ตัด signal commit/rollback ที่ต่อไว้ (กัน slot ทำงานหลัง unload)
        for sig, slot in getattr(self, "_signal_conns", []):
            try:
                sig.disconnect(slot)
            except Exception:
                pass
        self._signal_conns = []
        self._signal_layers = set()
        if hasattr(self, 'temp_tool') and self.temp_tool:
            canvas = self.iface.mapCanvas()
            if canvas and canvas.mapTool() == self.temp_tool:
                canvas.unsetMapTool(self.temp_tool)

    ADDNODE_MAX_DIST = 2.0        # เมตร: ระยะสูงสุดจากจุดที่คลิกถึงขอบแปลง ที่ยอมให้แทรกมุมได้
                                  # (กันคลิกหมุดไกลแล้วรูปแปลงบิดตาม · 2 ม. = ผ่อนให้แปลง L2-RO ที่หยาบ)
    ALIGN_MAX_PICK  = 800         # จำนวนหมุดสูงสุดที่เลือกด้วยกล่องใน Align (เท่ากับ Move Node)

    # ============ เตือนงานค้างยังไม่บันทึก (ไม่บล็อก) ============
    UNSAVED_NAG_MIN = 10.0        # เตือนเมื่อค้างเกินกี่นาที (แล้วเตือนซ้ำทุกช่วงเท่านี้)

    def _start_unsaved_watch(self):
        """ตัวเตือนเบา ๆ: ถ้ามีงานค้างใน edit buffer นานเกิน UNSAVED_NAG_MIN นาที ให้เตือนบนแถบข้อความ
        ★ ไม่ใช่ autosave และไม่บล็อกอะไรทั้งสิ้น (เช็คแค่ธง isModified ในหน่วยความจำ ไม่แตะฐานข้อมูล)
        ที่มา: 5 ส.ค. 69 พนักงานแก้งานสะสม ~20 นาทีโดยไม่บันทึก แล้ว QGIS ค้างจนต้องปิดโปรแกรม
              -> งานทั้งก้อนหาย เพราะยังไม่เคยถูกส่งถึงฐานข้อมูลเลย"""
        if self._nag_timer is not None:
            return
        try:
            t = QtCore.QTimer(self.dlg or self.iface.mainWindow())
            t.setInterval(60000)                     # เช็คนาทีละครั้ง (ถูกมาก)
            t.timeout.connect(self._unsaved_tick)
            t.start()
            self._nag_timer = t
        except Exception:
            self._nag_timer = None

    def _unsaved_tick(self):
        try:
            lyrs = [QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                    QgsProject.instance().mapLayer(self.point_cb.currentData())]
            dirty = any(l is not None and l.isEditable() and l.isModified() for l in lyrs)
            now = time.monotonic()
            if not dirty:
                self._unsaved_since = None
                return
            if self._unsaved_since is None:
                self._unsaved_since = now
                self._unsaved_last_nag = now
                return
            mins = (now - self._unsaved_since) / 60.0
            if mins >= self.UNSAVED_NAG_MIN and (now - self._unsaved_last_nag) / 60.0 >= self.UNSAVED_NAG_MIN:
                self._unsaved_last_nag = now
                self.iface.messageBar().pushMessage(
                    "ยังไม่ได้บันทึก",
                    f"มีงานค้างยังไม่บันทึกมาแล้วประมาณ {int(mins)} นาที — แนะนำกด 💾 บันทึก "
                    "(ถ้าโปรแกรมปิดกะทันหัน งานที่ยังไม่บันทึกจะหายทั้งหมด)",
                    level=1, duration=12)
        except Exception:
            pass

    def run(self):
        if self.dlg is None: self.create_dialog()
        self.dlg.show()
        self._start_unsaved_watch()
        # ★ กันคีย์แอดมินว่าง (2026-08-03): QShortcut ที่สร้างตอน initGui บางเครื่องได้ key ว่าง เพราะ
        #   main window ยังไม่พร้อมตอน QGIS เพิ่งเปิด -> Ctrl+Shift+F12 เลยไม่ยิง. setKey ซ้ำตอนเปิด
        #   หน้าต่างปลั๊กอิน (ถึงตอนนี้ทุกอย่างพร้อมแล้ว) ให้คีย์ผูกติดแน่นอน. (headless พิสูจน์ว่าคีย์นี้ใช้ได้)
        try:
            _asc = getattr(self, "_admin_sc", None)
            if _asc is not None and not _asc.key().toString():
                _asc.setKey(QtGui.QKeySequence("Ctrl+Shift+F12"))
                _asc.setEnabled(True)
        except Exception:
            pass
        self._check_transaction_mode()
        self._show_whats_new()
        self._auto_check_update()   # เช็คของใหม่ให้เอง ครั้งเดียวต่อการเปิด QGIS

    def _check_transaction_mode(self):
        """เตือน (ครั้งเดียวต่อ session) ถ้าโปรเจกต์เปิด Automatic transaction groups
        — เลเยอร์ PostgreSQL ที่ใช้ connection เดียวกันจะแชร์ edit session ทำให้การนับ
        undo ต่อเลเยอร์ของปลั๊กอิน (_op_begin/_op_commit) ไม่ตรงกับความเป็นจริง"""
        if getattr(self, "_txn_warned", False):
            return
        try:
            on = bool(QgsProject.instance().autoTransaction())
        except Exception:
            on = False
        if on:
            self._txn_warned = True
            self.iface.messageBar().pushMessage(
                "MLEP", "โปรเจกต์นี้เปิด Automatic transaction groups — ระบบ Undo ของปลั๊กอิน"
                        "อาจนับไม่ตรงสำหรับเลเยอร์ PostgreSQL ที่ใช้ connection เดียวกัน "
                        "แนะนำปิดที่ Project Properties → Data Sources",
                level=1, duration=15)

    def _show_whats_new(self):
        """เด้ง popup สรุปสิ่งที่เปลี่ยน เมื่อเปิดปลั๊กอินครั้งแรกหลังเวอร์ชันใหม่
        (เทียบกับเวอร์ชันที่เคยเห็นใน QSettings; ติดตั้งครั้งแรกจะเงียบ ตั้ง baseline ไว้)"""
        s = QtCore.QSettings()
        key = "MultiLayerEditPro/lastSeenVersion"
        last = s.value(key, "", str)
        if _vkey(self.version) <= _vkey(last):
            return                      # เคยเห็นแล้ว / ไม่ใช่เวอร์ชันใหม่
        s.setValue(key, self.version)   # บันทึกทันทีกันเด้งซ้ำ
        if last:
            # หา index ของเวอร์ชันล่าสุดที่เคยเห็น
            last_idx = next((i for i, (v, _) in enumerate(CHANGELOG) if _vkey(v) <= _vkey(last)), len(CHANGELOG))
            # โชว์สิ่งที่ใหม่กว่าทั้งหมด + ขอย้อนดูอดีตด้วยให้รวมเป็น 3 เวอร์ชันเป็นอย่างน้อย
            show_count = max(last_idx, 3)
            new_entries = CHANGELOG[:show_count]
            head = f"อัปเดตเป็นเวอร์ชัน {self.version} แล้ว 🎉"
        else:
            # ครั้งแรก -> โชว์ 3 เวอร์ชันล่าสุด
            new_entries = CHANGELOG[:3]
            head = f"ยินดีต้อนรับสู่เวอร์ชัน {self.version} 🎉"
        if not new_entries:
            return
        rows = []
        for v, items in new_entries:
            rows.append(f"<b>v{v}</b>")
            rows += [f"&nbsp;&nbsp;• {it}" for it in items]
            rows.append("")
        # ★ ใช้ "หน้าต่างมีขนาด + เลื่อนอ่านได้" แทน QMessageBox (2026-08-07)
        #   QMessageBox ยืดตามเนื้อหา: changelog ยาว ๆ (1.9.7 มี 24 บรรทัด) จะได้กล่องสูงเก้งก้าง
        #   ล้นจอ อ่านยาก และปรับขนาดเองไม่ได้ · QDialog + QTextBrowser = กำหนดขนาดได้ เลื่อนได้ ย่อ/ขยายได้
        #   ★ parent = หน้าต่างหลักเสมอ (self.dlg อาจถูกปิด/ย่อ -> กล่อง modal ไปซ่อน = ดูเหมือนค้าง)
        dlg = QtWidgets.QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("Multi-Layer Edit Pro — มีอะไรใหม่ ✨")
        dlg.setModal(True)
        dlg.setSizeGripEnabled(True)                       # ลากมุมปรับขนาดได้
        lay = QtWidgets.QVBoxLayout(dlg)
        lab = QtWidgets.QLabel(f"<h3 style='margin:0'>{head}</h3>")
        lab.setTextFormat(QtCore.Qt.RichText)
        lay.addWidget(lab)
        view = QtWidgets.QTextBrowser()
        view.setHtml("<div style='font-size:11pt; line-height:150%'>" + "<br>".join(rows) + "</div>")
        view.setOpenExternalLinks(True)
        lay.addWidget(view, 1)
        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok)
        bb.accepted.connect(dlg.accept)
        lay.addWidget(bb)
        # ขนาดเริ่มต้น: กว้าง 760 สูง 60% ของจอ (ไม่เกิน 640) — เล็กพอไม่ล้นจอเล็ก ใหญ่พออ่านสบาย
        try:
            _scr = QtWidgets.QApplication.primaryScreen().availableGeometry()
            _w = max(560, min(760, int(_scr.width() * 0.55)))
            _h = max(360, min(640, int(_scr.height() * 0.60)))
        except Exception:
            _w, _h = 720, 520
        dlg.resize(_w, _h)
        dlg.setMinimumSize(480, 320)
        dlg.show()
        try:
            dlg.raise_(); dlg.activateWindow()
            QtCore.QTimer.singleShot(0, lambda: (dlg.raise_(), dlg.activateWindow()))
        except Exception:
            pass
        dlg.exec_()

    # ============ Shortcut ปุ่มต่าง ๆ ============
    def _shortcut_actions(self):
        """รายการ action ที่ตั้ง shortcut ได้: (id, label, callable)"""
        return [
            ("dol_search", "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image')),
            ("dol_survey", "📐 ค้นหาหลักฐานการรังวัด", lambda: self.start_dol_search('survey')),
            ("by_cluster", "By Cluster ID", lambda: self.process_selection('cluster')),
            ("by_utm", "By UTM", lambda: self.process_selection('utm')),
            ("move", "Move", lambda: self.start_interactive('move')),
            ("rotate", "Rotate", lambda: self.start_interactive('rotate')),
            ("scale", "Scale", lambda: self.start_interactive('scale')),
            ("transform", "Transform (2 จุด)", lambda: self.start_interactive('transform')),
            ("modify_node", "Move Node (Sync)", self.start_sync_vertex_tool),
            ("align", "Align Points", self.start_align_tool),
            ("add_node", "Add Node", self.start_add_node),
            ("sync_cluster", "Sync Cluster ID", self.group_cluster_ids),
            ("set_remark", "หมายเหตุ (REMARK)", self.set_remark_value),
            ("score1", "Score = 1", lambda: self.set_score_value(1)),
            ("score0", "Score = 0", lambda: self.set_score_value(0)),
            ("reset", "Reset", self.cancel_transform),
            ("undo", "Undo", self.undo_transform),
            ("save", "บันทึก (Commit)", self.save_all_changes),
        ]

    def _load_shortcuts(self):
        """อ่าน QSettings -> สร้าง QShortcut ผูกกับ main window (ทำงานทั้งแอปขณะใช้ QGIS)"""
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None); sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        mw = self.iface.mainWindow()
        # ตั้งค่า Ctrl+Z เป็น Undo ของปลั๊กอิน (และปลดของ QGIS ออก) อัตโนมัติ 1 ครั้ง
        # ★ ติดธง "ทำแล้ว" เฉพาะเมื่อปลดคีย์ QGIS สำเร็จจริง — ฟังก์ชันนี้ถูกเรียกตั้งแต่
        #   initGui (QGIS กำลังเปิด) ซึ่ง ShortcutsManager อาจยังไม่พร้อม ถ้าติดธงทั้งที่ปลด
        #   ไม่ได้ Ctrl+Z จะกำกวม (ชนกับของ QGIS = เงียบทั้งคู่) ถาวรบนเครื่องติดตั้งใหม่
        if not s.contains("MultiLayerEditPro/ShortcutUndoInit"):
            s.setValue(k + "undo", "Ctrl+Z")
            self._release_qgis_shortcuts(["Ctrl+Z"])
            try:
                _still = "Ctrl+Z" in self._qgis_shortcut_keys()
            except Exception:
                _still = False
            if not _still:
                s.setValue("MultiLayerEditPro/ShortcutUndoInit", True)
            # ปลดไม่สำเร็จ -> ไม่ติดธง จะลองใหม่รอบหน้า (เช่นตอนเปิดหน้าต่างปลั๊กอิน)
            
        for aid, label, slot in self._shortcut_actions():
            seq = s.value(k + aid, "", str)
            if not seq:
                continue
            sc = QtWidgets.QShortcut(QtGui.QKeySequence(seq), mw)
            sc.setContext(QtCore.Qt.ApplicationShortcut)
            # ★ shortcut ทำงานได้ตั้งแต่ยังไม่เปิดหน้าต่างปลั๊กอิน (ผูกที่ initGui แล้ว)
            #   ทุก action ยกเว้น undo อ้าง widget ในหน้าต่าง (poly_cb ฯลฯ) -> ต้องกัน
            def _guarded(_slot=slot, _aid=aid):
                if _aid != "undo" and getattr(self, "dlg", None) is None:
                    self.iface.messageBar().pushMessage(
                        "MLEP", "เปิดหน้าต่างปลั๊กอินก่อน แล้วค่อยใช้คีย์ลัดนี้",
                        level=1, duration=4)
                    return
                _slot()
            sc.activated.connect(_guarded)
            self._shortcuts.append(sc)

    def open_shortcut_settings(self):
        """popup ตั้งค่า shortcut แต่ละปุ่ม"""
        dlg = QtWidgets.QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("⌨ ตั้งค่า Shortcut")
        dlg.setMinimumWidth(380)
        v = QtWidgets.QVBoxLayout(dlg)
        v.addWidget(QtWidgets.QLabel(
            "คลิกในช่องแล้วกดคีย์ที่ต้องการ (เว้นว่าง = ไม่ใช้)\nทำงานทั้งแอปขณะใช้ QGIS"))
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        form = QtWidgets.QFormLayout()
        editors = {}
        for aid, label, slot in self._shortcut_actions():
            ed = QtWidgets.QKeySequenceEdit(QtGui.QKeySequence(s.value(k + aid, "", str)))
            editors[aid] = ed
            btn_clr = QtWidgets.QPushButton("✖"); btn_clr.setFixedWidth(28)
            btn_clr.clicked.connect(ed.clear)
            row = QtWidgets.QHBoxLayout(); row.addWidget(ed, 1); row.addWidget(btn_clr, 0)
            w = QtWidgets.QWidget(); w.setLayout(row)
            form.addRow(label + ":", w)
        inner = QtWidgets.QWidget(); inner.setLayout(form)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(inner)
        v.addWidget(scroll)
        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        v.addWidget(btns)
        btns.accepted.connect(dlg.accept); btns.rejected.connect(dlg.reject)
        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            qgis_keys = self._qgis_shortcut_keys()
            seen, dup, conflict = {}, set(), set()
            for aid, ed in editors.items():
                seq = ed.keySequence().toString()
                if seq:
                    if seq in seen:
                        dup.add(seq)
                    seen[seq] = aid
                    if seq in qgis_keys:
                        conflict.add(seq)
                s.setValue(k + aid, seq)
            self._load_shortcuts()
            msg = "บันทึก shortcut แล้ว ✅"
            if dup:
                msg += f"\n⚠️ คีย์ซ้ำกันเองในปลั๊กอิน: {', '.join(sorted(dup))}"
            if conflict:
                ck = ", ".join(sorted(conflict))
                ans = self._ask(
                    QtWidgets.QMessageBox.Question, "คีย์ชนกับ QGIS",
                    f"คีย์เหล่านี้ QGIS ใช้อยู่: {ck}\n"
                    "ถ้าปล่อยไว้ Qt จะถือว่ากำกวม → ปุ่มลัดอาจไม่ทำงาน\n\n"
                    "ต้องการให้ปลดคีย์เดิมของ QGIS ออก เพื่อให้ปลั๊กอินใช้คีย์นี้ได้ไหม?\n"
                    "(เปลี่ยนคีย์ลัด QGIS ถาวร — ย้อนคืนได้ที่ Settings → Keyboard Shortcuts)",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No)
                if ans == QtWidgets.QMessageBox.Yes:
                    released = self._release_qgis_shortcuts(conflict)
                    self._load_shortcuts()   # โหลดใหม่ให้คีย์ปลั๊กอินจับได้หลังปลดคีย์ QGIS
                    if released:
                        msg += f"\n✅ ปลดคีย์ QGIS แล้ว: {', '.join(sorted(released))}"
                    left = conflict - released
                    if left:
                        msg += (f"\n⚠️ ปลดไม่ได้: {', '.join(sorted(left))} "
                                "(แก้เองที่ Settings → Keyboard Shortcuts)")
                else:
                    msg += f"\n⚠️ ยังชนกับ QGIS: {ck} (ปุ่มลัดอาจไม่ทำงาน)"
            self._ask(QtWidgets.QMessageBox.Information, "Shortcut", msg)

    def _release_qgis_shortcuts(self, keys):
        """ปลดคีย์เดิมของ QGIS ที่ชน ผ่าน QgsShortcutsManager (บันทึกถาวร) -> set คีย์ที่ปลดได้"""
        released = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
        except Exception:
            return released
        for key in keys:
            seq = QtGui.QKeySequence(key)
            obj = None
            for getter in ("objectForSequence", "actionForSequence", "shortcutForSequence"):
                if hasattr(mgr, getter):
                    try:
                        obj = getattr(mgr, getter)(seq)
                    except Exception:
                        obj = None
                    if obj is not None:
                        break
            if obj is not None:
                try:
                    if mgr.setKeySequence(obj, ""):
                        released.add(key)
                except Exception:
                    pass
        return released

    def _qgis_shortcut_keys(self):
        """รวมคีย์ลัดที่ QGIS ใช้อยู่ (ไว้เตือนเมื่อตั้งคีย์ชนกันจน Qt ถือว่ากำกวม)"""
        keys = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
            for a in mgr.listActions():
                t = a.shortcut().toString()
                if t:
                    keys.add(t)
            for sc in mgr.listShortcuts():
                t = sc.key().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        try:
            for a in self.iface.mainWindow().findChildren(QtWidgets.QAction):
                t = a.shortcut().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        return keys

    # ============ โหมดผู้ดูแล (ADMIN) ============
    def _admin_role_ok(self):
        """role ที่ต่อ DB เป็นแอดมินไหม (สมาชิก mlep_admin หรือ superuser). คืน True/False,
        หรือ None ถ้าเช็คไม่ได้ (ยังไม่เปิดโปรเจกต์อำเภอ/ไม่ใช่ชั้น PostGIS)"""
        if not hasattr(self, "poly_cb"):
            return None
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if lyr is None:
            return None
        try:
            dp = lyr.dataProvider()
            if dp is None or dp.name() != "postgres":
                return None
            from qgis.core import QgsDataSourceUri, QgsProviderRegistry
            uri = QgsDataSourceUri(dp.dataSourceUri())
            md = QgsProviderRegistry.instance().providerMetadata("postgres")
            conn = md.createConnection(uri.connectionInfo(True), {})
            rows = conn.executeSql(
                "SELECT (pg_has_role(current_user,'mlep_admin','MEMBER') "
                "OR current_setting('is_superuser')::bool)")
            v = rows[0][0] if rows and rows[0] else None
            return v in (True, "t", "true", "1", 1)
        except Exception:
            return None

    def toggle_admin_mode(self):
        """Ctrl+Shift+F12: สลับเข้า/ออกโหมดผู้ดูแล (ต้องเปิดหน้าต่างปลั๊กอินก่อน)"""
        if getattr(self, "dlg", None) is None:
            return
        if getattr(self, "_admin_on", False):
            self._set_admin_mode(False)
            self.iface.messageBar().pushInfo("MLEP", "ออกจากโหมดผู้ดูแลแล้ว")
            return
        ok = self._admin_role_ok()
        if not ok:
            # เช็คไม่ได้ หรือไม่ใช่แอดมิน -> เงียบ (ไม่เผยว่ามีฟีเจอร์)
            return
        self._set_admin_mode(True)
        self.iface.messageBar().pushMessage(
            "MLEP", "เข้าสู่โหมดผู้ดูแลแล้ว (กด Ctrl+Shift+F12 อีกครั้งเพื่อออก)", level=1, duration=5)

    def _set_admin_mode(self, on):
        self._admin_on = bool(on)
        if not on:
            self._admin_unlock_l1 = False
        for w in (getattr(self, "_admin_banner", None), getattr(self, "_admin_group", None)):
            if w is not None:
                w.setVisible(self._admin_on)
        self._admin_refresh_banner()
        self._fit_dialog_height()

    def _fit_dialog_height(self):
        """ย่อ/ขยายความสูงหน้าต่างให้พอดีเนื้อหา หลังซ่อน/โชว์กล่อง ADMIN
        Qt ไม่ย่อหน้าต่างให้เองเวลา setVisible(False) — ความสูงเดิมค้างไว้เป็นที่ว่าง
        (คงความกว้างที่ผู้ใช้ปรับไว้ ปรับเฉพาะความสูง)"""
        dlg = getattr(self, "dlg", None)
        if dlg is None:
            return
        try:
            lay = dlg.layout()
            if lay is not None:
                lay.activate()          # บังคับคำนวณ sizeHint ใหม่ทันที
            dlg.resize(dlg.width(), dlg.sizeHint().height())
        except Exception:
            pass

    def _admin_refresh_banner(self):
        b = getattr(self, "_admin_banner", None)
        if b is None:
            return
        b.setText("🔓 โหมดผู้ดูแล + ปลดล็อก L1 แล้ว — ระวัง!"
                  if getattr(self, "_admin_unlock_l1", False) else "🔓 โหมดผู้ดูแล (ADMIN)")

    def toggle_unlock_l1(self):
        self._admin_unlock_l1 = not getattr(self, "_admin_unlock_l1", False)
        self._admin_refresh_banner()
        btn = getattr(self, "_admin_unlock_btn", None)
        if btn is not None:
            btn.setText("🔒 ล็อก L1 กลับ" if self._admin_unlock_l1 else "🔓 ปลดล็อก L1-RTK/L1-TS")
        self.iface.messageBar().pushMessage(
            "ADMIN",
            "ปลดล็อก L1-RTK/L1-TS แล้ว — แก้ไข/ลบได้ทุกแปลง (ระวัง)"
            if self._admin_unlock_l1 else "ล็อก L1 กลับแล้ว",
            level=(2 if self._admin_unlock_l1 else 1), duration=5)

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.dlg.setWindowIcon(QtGui.QIcon(icon_path))
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro {self.version}")
        self.dlg.setMinimumWidth(360)
        root = QtWidgets.QVBoxLayout(self.dlg)
        root.setSpacing(6)

        # แถบผู้ดูแล (ซ่อนจนเข้าโหมด admin)
        self._admin_banner = QtWidgets.QLabel("🔓 โหมดผู้ดูแล (ADMIN)")
        self._admin_banner.setStyleSheet(
            "background-color:#b71c1c; color:white; font-weight:bold; padding:6px; border-radius:3px;")
        self._admin_banner.setAlignment(QtCore.Qt.AlignCenter)
        self._admin_banner.setVisible(False)
        root.addWidget(self._admin_banner)

        def mkbtn(text, slot, style="", tip=""):
            b = QtWidgets.QPushButton(text)
            b.setStyleSheet(style or "padding:5px;")
            b.setFixedHeight(34)   # สูงเท่ากันทุกปุ่ม (กันไทย/Latin/emoji เรนเดอร์สูงไม่เท่า)
            if tip:
                b.setToolTip(tip)
            b.clicked.connect(slot)
            return b

        # ---------- ชั้นข้อมูล (กระทัดรัด) ----------
        grp_layer = QtWidgets.QGroupBox("ชั้นข้อมูล")
        gl = QtWidgets.QGridLayout(grp_layer)
        gl.setHorizontalSpacing(6)
        gl.setVerticalSpacing(4)
        gl.setColumnStretch(0, 0)   # label ชิดซ้าย ไม่ยืด
        gl.setColumnStretch(1, 1)   # combo ดูดพื้นที่ว่างทั้งหมด -> label ชิด combo
        self.poly_cb = QtWidgets.QComboBox()
        self.point_cb = QtWidgets.QComboBox()
        gl.addWidget(QtWidgets.QLabel("แปลง:"), 0, 0)
        gl.addWidget(self.poly_cb, 0, 1)
        gl.addWidget(QtWidgets.QLabel("หมุด:"), 1, 0)
        gl.addWidget(self.point_cb, 1, 1)
        btn_refresh = mkbtn("🔄", self.refresh_layers, tip="Refresh Layers")
        btn_refresh.setFixedWidth(36)
        gl.addWidget(btn_refresh, 0, 2, 2, 1)
        root.addWidget(grp_layer)
        self.refresh_layers()
        # สลับชั้นเอง -> จำว่าผู้ใช้เลือก + ย้ายตัวเฝ้าไปชั้นใหม่ (ต่อทั้งสองช่อง)
        for _cb in (self.poly_cb, self.point_cb):
            try:
                _cb.currentIndexChanged.connect(self._on_layer_combo_changed)
            except Exception:
                pass

        # ---------- DOL search (คลิกแปลง -> เปิดเอกสาร) ----------
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn(
            "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image'),
            "background-color:#fff3e0; font-weight:bold; padding:8px; color:#e65100;"))
        r.addWidget(mkbtn(
            "📐 หลักฐานการรังวัด", lambda: self.start_dol_search('survey'),
            "background-color:#e3f2fd; font-weight:bold; padding:8px; color:#0d47a1;"))
        root.addLayout(r)

        # ---------- เลือก & ปรับแต่ง (หน้าเดียว) ----------
        grp_edit = QtWidgets.QGroupBox("เลือก / ปรับแต่ง")
        ve = QtWidgets.QVBoxLayout(grp_edit)
        ve.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("By Cluster ID", lambda: self.process_selection('cluster')))
        r.addWidget(mkbtn("By UTM", lambda: self.process_selection('utm')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Move", lambda: self.start_interactive('move')))
        r.addWidget(mkbtn("Rotate", lambda: self.start_interactive('rotate')))
        r.addWidget(mkbtn("Scale", lambda: self.start_interactive('scale')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Transform (2 จุด)", lambda: self.start_interactive('transform'),
                          "background-color:#ffccbc; font-weight:bold; padding:6px;"))
        r.addWidget(mkbtn("Move Node (Sync)", self.start_sync_vertex_tool,
                          "background-color:#e8f5e9; font-weight:bold; padding:6px;"))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("📏 Align Points", self.start_align_tool))
        r.addWidget(mkbtn("➕ Add Node", self.start_add_node,
                          "background-color:#e8f5e9; font-weight:bold; color:#1b5e20;"))
        ve.addLayout(r)
        root.addWidget(grp_edit)

        # ---------- จัดกลุ่ม / Score ----------
        grp_grp = QtWidgets.QGroupBox("จัดกลุ่ม / Score")
        vg = QtWidgets.QVBoxLayout(grp_grp)
        vg.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("📝 หมายเหตุ (REMARK)", self.set_remark_value,
                          "background-color:#fff3e0; padding:6px; color:#e65100;",
                          "ใส่/แก้ข้อความหมายเหตุให้แปลงที่เลือก (เลือกจากรายการที่ใช้บ่อย หรือพิมพ์เอง)"))
        r.addWidget(mkbtn("🔗 Sync Cluster ID", self.group_cluster_ids,
                          "background-color:#e3f2fd; padding:6px;"))
        vg.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Score = 1", lambda: self.set_score_value(1),
                          "background-color:#c8e6c9; font-weight:bold; color:#1b5e20; padding:6px;"))
        r.addWidget(mkbtn("Score = 0", lambda: self.set_score_value(0),
                          "background-color:#ffcdd2; font-weight:bold; color:#b71c1c; padding:6px;"))
        vg.addLayout(r)
        root.addWidget(grp_grp)

        # ---------- ผู้ดูแล (ADMIN) — ซ่อนจนกด Ctrl+Shift+F12 ----------
        self._admin_group = QtWidgets.QGroupBox("ผู้ดูแล (ADMIN)")
        self._admin_group.setStyleSheet(
            "QGroupBox{border:1px solid #b71c1c; margin-top:6px;} QGroupBox::title{color:#b71c1c;}")
        va = QtWidgets.QVBoxLayout(self._admin_group)
        va.setSpacing(5)
        self._admin_unlock_btn = mkbtn(
            "🔓 ปลดล็อก L1-RTK/L1-TS", self.toggle_unlock_l1,
            "background-color:#ffcdd2; font-weight:bold; color:#b71c1c; padding:6px;")
        va.addWidget(self._admin_unlock_btn)
        self._admin_btn_row = QtWidgets.QHBoxLayout()
        self._admin_btn_row.addWidget(mkbtn(
            "✏️ แก้ชื่อหมุด", self.start_rename_node,
            "background-color:#e1f5fe; font-weight:bold; color:#01579b; padding:6px;",
            "คลิกแปลง แล้วคลิกหมุดของแปลงนั้น เพื่อแก้ชื่อหมุด"))
        self._admin_btn_row.addWidget(mkbtn(
            "🗑 ลบ node", self.start_delete_node,
            "background-color:#fce4ec; font-weight:bold; color:#880e4f; padding:6px;",
            "คลิกแปลง แล้วคลิก node — ลบมุมแปลงพร้อมหมุดของแปลงนั้น"))
        va.addLayout(self._admin_btn_row)
        va.addWidget(mkbtn(
            "🗑🧨 ลบทั้งแปลง (+หมุดของแปลง)", self.start_delete_parcel,
            "background-color:#b71c1c; font-weight:bold; color:#ffffff; padding:6px;",
            "คลิกแปลงที่ต้องการลบ — ลบทั้งรูปแปลงและหมุดทุกจุดของแปลงนั้นพร้อมกัน"))
        self._admin_group.setVisible(False)
        root.addWidget(self._admin_group)

        # ---------- แถบ action (เห็นตลอด) ----------
        r = QtWidgets.QHBoxLayout()
        btn_reset = mkbtn("✖ Reset", self.cancel_transform)
        btn_undo = mkbtn("↺ Undo", self.undo_transform)
        for _b in (btn_reset, btn_undo):
            _b.setFixedHeight(34)   # บังคับสูงเท่ากัน (กัน emoji เรนเดอร์ไม่เท่า)
            r.addWidget(_b, 1)
        root.addLayout(r)
        root.addWidget(mkbtn("💾 บันทึก (Commit)", self.save_all_changes,
                             "background-color:#c8e6c9; font-weight:bold; padding:8px; color:#1b5e20;"))

        # ---------- footer ----------
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        root.addWidget(line)
        rf = QtWidgets.QHBoxLayout()
        btn_sc = mkbtn("⌨ ตั้งค่า Shortcut", self.open_shortcut_settings)
        btn_up = mkbtn("🚀 Check Update", self.update_plugin)
        for _b in (btn_sc, btn_up):
            _b.setFixedHeight(34)   # สูงเท่ากัน
            rf.addWidget(_b, 1)     # stretch เท่ากัน -> กว้างเท่ากัน
        root.addLayout(rf)
        lbl = QtWidgets.QLabel("ชาคฤตย์ จันทรสุกศรี · กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        f = QtGui.QFont()
        f.setPointSize(8)
        lbl.setFont(f)
        lbl.setAlignment(QtCore.Qt.AlignCenter)
        root.addWidget(lbl)
        self._load_shortcuts()   # ผูก shortcut ที่บันทึกไว้

        # refresh combo เลเยอร์อัตโนมัติเมื่อโปรเจกต์เพิ่ม/ลบเลเยอร์ (disconnect ใน unload)
        proj = QgsProject.instance()
        for sig in (proj.layersAdded, proj.layersRemoved):
            try:
                sig.connect(self._project_layers_changed)
                self._signal_conns.append((sig, self._project_layers_changed))
            except Exception:
                pass

    # ============ DOL iLands: ค้นหาเอกสารจากแปลง ============
    def start_dol_search(self, mode='image'):
        """เปิด map tool คลิกเลือกแปลง -> mode 'image'=ภาพลักษณ์(public) / 'survey'=หลักฐานรังวัด(login)"""
        self._dol_mode = mode
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if lyr is None:
            self._ask(
                QtWidgets.QMessageBox.Warning, "ไม่พบเลเยอร์", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        try:
            if lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
                self._ask(
                    QtWidgets.QMessageBox.Warning, "เลเยอร์ไม่ถูกต้อง", f"เลเยอร์ '{lyr.name()}' ไม่ใช่ Polygon")
                return
        except Exception:
            pass
        self._dol_clear_highlight()
        canvas = self.iface.mapCanvas()
        # ล็อกให้คลิก/ไฮไลต์ได้เฉพาะแปลงในเลเยอร์ที่เลือกในปลั๊กอินเท่านั้น
        self.temp_tool = PolygonPickTool(
            canvas, lyr, self._on_polygon_picked, self._dol_on_hover)
        canvas.setMapTool(self.temp_tool)
        what = "ภาพลักษณ์" if mode == 'image' else "หลักฐานการรังวัด"
        self.iface.messageBar().pushInfo(
            "DOL", f"คลิกบนแปลงในเลเยอร์ '{lyr.name()}' เพื่อค้นหา{what} (Esc เพื่อยกเลิก)")

    def _on_polygon_picked(self, feat, layer):
        """อ่าน attribute UTM ของแปลงที่คลิก (จากเลเยอร์ที่เลือก) แล้วยิงค้นหา"""
        def gv(name):
            try:
                if feat.fields().indexOf(name) < 0:
                    return ""
                v = feat[name]
                return "" if v is None else str(v).strip()
            except Exception:
                return ""

        m1, m2, m3 = gv("UTMMAP1"), gv("UTMMAP2"), gv("UTMMAP3")
        m4 = gv("UTMMAP4") or "00"
        scale = gv("UTMSCALE")
        landno = gv("LANDNO")
        self.iface.actionSelect().trigger()  # คืน cursor ปกติ

        # ไฮไลต์แปลงที่คลิกทันที (กรอบแดง)
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

        if not m1 or not m2 or not m3 or not scale or not landno:
            self._dol_clear_highlight()
            self._ask(
                QtWidgets.QMessageBox.Warning, "ข้อมูลแปลงไม่ครบ",
                f"แปลงนี้ไม่มี attribute ระวางครบ\n"
                f"UTMMAP={m1} {m2} {m3} {m4} | SCALE={scale} | LANDNO={landno}")
            return

        # centroid ของแปลงที่คลิก (แปลงเป็น datum 24047) -> ใช้แก้ปัญหา "ระวางคร่อมสาขา"
        # ที่ LAND_NO ซ้ำข้ามสาขา (เลือกแปลงที่ใกล้จุดคลิกสุด แทนการหยิบตัวแรกมั่ว)
        near_xy = None
        try:
            c = feat.geometry().centroid().asPoint()
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            if layer.crs() != dst:
                c = QgsCoordinateTransform(layer.crs(), dst, QgsProject.instance()).transform(c)
            near_xy = (c.x(), c.y())
        except Exception:
            near_xy = None

        attrs = {"m1": m1, "m2": m2, "m3": m3, "m4": m4,
                 "scale": scale, "landno": landno, "near_xy": near_xy}
        self._dol_attrs = attrs   # เก็บไว้ใช้ค้นหลักฐานรังวัด (ต้องใช้ utmmap เดิม)

        # ★ กันยิงซ้อน (2026-08-06): ถ้ากดค้นหาใหม่ระหว่างตัวเก่ายังทำงาน
        #   การผูก self._dol_worker ตัวใหม่ทับ = ตัวเก่าเหลือ ref 0 ตอน run() จบ -> sip ลบ QThread
        #   ทั้งที่ยังไม่ finish -> Qt เรียก qFatal("QThread: Destroyed while thread is still running")
        #   = QGIS ดับทันที งานที่ยังไม่บันทึกหายทั้งหมด
        _w0 = getattr(self, "_dol_worker", None)
        if _w0 is not None:
            try:
                if _w0.isRunning():
                    self.iface.messageBar().pushMessage(
                        "DOL", "กำลังค้นหาอยู่ — รอผลก่อนแล้วค่อยค้นใหม่", level=1, duration=5)
                    return
            except Exception:
                pass

        self._dol_busy = QtWidgets.QProgressDialog(
            f"กำลังค้นหา PARCEL_SEQ...\nระวาง {m1} {m2} {m3}-{m4} ที่ดิน {landno}",
            None, 0, 0, self.dlg)
        self._dol_busy.setWindowTitle("DOL")
        self._dol_busy.setCancelButton(None)
        self._dol_busy.setWindowModality(QtCore.Qt.WindowModal)
        self._dol_busy.show()

        # ถือ ref ไว้ในลิสต์เหมือน _run_net (กัน GC เก็บ worker ระหว่างรัน) แล้วปล่อยตอน finished
        w = ParcelLookupWorker(attrs, zone=47)
        self._dol_worker = w
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)

        def _drop_worker(_w=w):
            try:
                self._net_workers.remove(_w)
            except Exception:
                pass
            try:
                _w.deleteLater()       # finished ยิงหลัง QThreadPrivate::finish() แล้ว -> ลบปลอดภัย
            except Exception:
                pass
        w.finished.connect(_drop_worker)
        w.done.connect(self._on_dol_done)
        w.fail.connect(self._on_dol_fail)
        w.start()

    def _on_dol_done(self, res):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()  # รันเสร็จ -> ลบไฮไลต์
        if not res:
            self._ask(
                QtWidgets.QMessageBox.Information, "ไม่พบแปลง", "ไม่พบแปลงในระบบ (ตรวจเลขระวาง / zone UTM)")
            return

        if getattr(self, "_dol_mode", "image") == "survey":
            self._open_survey(res)
            return

        # ภาพลักษณ์ -> เปิดทันที (ไม่เด้ง popup)
        if res.get("doc_url"):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(res["doc_url"]))
        warn = "" if res.get("verified") else "  ⚠️ MAP_PARCEL_SEQ ไม่ตรง"
        if res.get("match_count", 1) > 1:
            warn += f"  🔀 ระวางคร่อม {res['match_count']} สาขา (เลือกใกล้จุดคลิกสุด)"
        self.iface.messageBar().pushMessage(
            "DOL", f"โฉนด {res.get('parcel_no')} | {res.get('office','')} "
                   f"({res.get('city','')}) — เปิดภาพลักษณ์แล้ว{warn}", level=3, duration=8)

    # ---------- ตัวช่วยรัน network ใน thread แยก (กัน QGIS ค้างเมื่อ server ช้า) ----------
    def _run_net(self, msg, fn, on_done, on_fail):
        """รัน fn (blocking network) ใน QThread + โชว์ progress dialog
        on_done(result) / on_fail(exception) ถูกเรียกบน main thread"""
        busy = QtWidgets.QProgressDialog(msg, None, 0, 0, self.dlg)
        busy.setWindowTitle("Multi-Layer Edit Pro")
        busy.setCancelButton(None)
        busy.setWindowModality(QtCore.Qt.WindowModal)
        busy.show()
        w = _FnWorker(fn)
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)   # กัน GC เก็บ worker ระหว่างรัน

        def _cleanup():
            busy.close()
            try:
                self._net_workers.remove(w)
            except ValueError:
                pass
            w.deleteLater()

        def _ok(res):
            _cleanup()
            on_done(res)

        def _err(e):
            _cleanup()
            on_fail(e)

        w.done.connect(_ok)
        w.fail.connect(_err)
        w.start()

    # ---------- หลักฐานการรังวัด (ต้อง login) ----------
    def _dol_ask_credentials(self):
        """popup ขอ user/pass (UI อย่างเดียว — network ไปทำใน thread แยก)
        -> (user, pass) หรือ None ถ้ายกเลิก/กรอกไม่ครบ"""
        dlg = QtWidgets.QDialog(self.iface.mainWindow())
        dlg.setWindowTitle("เข้าสู่ระบบ DOL iLands")
        dlg.setMinimumWidth(320)
        form = QtWidgets.QFormLayout(dlg)
        ed_user = QtWidgets.QLineEdit()
        ed_pass = QtWidgets.QLineEdit()
        ed_pass.setEchoMode(QtWidgets.QLineEdit.Password)
        form.addRow("ผู้ใช้:", ed_user)
        form.addRow("รหัสผ่าน:", ed_pass)
        note = QtWidgets.QLabel("🔒 ไม่เก็บรหัสถาวร — ปิด QGIS แล้วต้องเข้าสู่ระบบใหม่")
        note.setStyleSheet("color:#666; font-size:11px;")
        form.addRow(note)
        bb = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        form.addRow(bb)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        ed_user.setFocus()
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return None
        u, p = ed_user.text().strip(), ed_pass.text()
        if not u or not p:
            return None
        return (u, p)

    def _cadastral_label(self, rec, i):
        """สร้างข้อความบรรยาย 1 รายการรังวัด (โชว์ field ที่มี)"""
        parts = []
        for k in ("CADASTRAL_NO", "CADASTRALNO", "SURVEY_NO", "SURVEYNO",
                  "TYPE_OF_SURVEY", "TYPEOFSURVEY", "SCALE", "SHEET_CODE",
                  "SHEETCODE", "SURVEY_DATE", "SURVEYDATE", "UTMMAP4"):
            v = rec.get(k)
            if v not in (None, "", "null"):
                parts.append(f"{k}={v}")
        label = " | ".join(parts) if parts else "(ไม่มีรายละเอียด)"
        return f"{i + 1}. {label}  [seq {rec.get('CADASTRAL_SEQ')}]"

    def _choose_cadastral(self, recs):
        """หลายรายการรังวัด -> popup ให้เลือก (คืน record หรือ None)"""
        items = [self._cadastral_label(rec, i) for i, rec in enumerate(recs)]
        item, ok = QtWidgets.QInputDialog.getItem(
            self.iface.mainWindow(), "เลือกหลักฐานการรังวัด",
            f"แปลงนี้มี {len(recs)} รายการ — เลือกที่ต้องการเปิด:", items, 0, False)
        if not ok:
            return None
        return recs[items.index(item)]

    def _open_survey(self, res):
        """ค้นหลักฐานรังวัดจากแปลงที่คลิก (login ถ้าจำเป็น) แล้วเปิด viewer; หลายรายการ -> ให้เลือก
        network ทั้งหมด (login + ค้นหา) รันใน thread แยกผ่าน _run_net — เดิม block UI สูงสุด 30 วิ"""
        from . import dol_api
        attrs = getattr(self, "_dol_attrs", {}) or {}
        prov = dol_api.province_code_from_city(res.get("city", ""))
        office = res.get("office_seq")
        if not prov or not office:
            known = " ".join(dol_api.PROVINCE_CODE.keys())
            self._ask(
                QtWidgets.QMessageBox.Warning, "หลักฐานการรังวัด",
                f"ยังไม่รองรับจังหวัดของแปลงนี้ ({res.get('city','')})\n"
                f"ปัจจุบันรองรับ: {known}\n"
                "(รหัสจังหวัดภายในระบบ DOL ไม่ตรงรหัสมาตรฐาน ต้องเก็บเพิ่มจากระบบจริง)")
            return
        self._survey_ctx = {"attrs": attrs, "prov": prov, "office": office, "retried": False}
        self._survey_step()

    def _survey_step(self):
        """ขั้น login: ถ้ายังไม่ login -> ขอรหัส (UI) แล้ว login ใน thread แยก จากนั้นค่อยค้นหา"""
        from . import dol_api
        if dol_api.is_logged_in():
            self._survey_search()
            return
        creds = self._dol_ask_credentials()
        if not creds:
            return
        u, p = creds
        self._run_net("กำลังเข้าสู่ระบบ DOL...",
                      lambda: dol_api.login(u, p),
                      lambda _s: self._survey_search(),
                      self._survey_login_failed)

    def _survey_login_failed(self, e):
        from . import dol_api
        if isinstance(e, dol_api.DOLAuthError):
            self._ask(QtWidgets.QMessageBox.Warning, "เข้าสู่ระบบไม่สำเร็จ", str(e))
        else:
            self._ask(QtWidgets.QMessageBox.Critical, "เข้าสู่ระบบผิดพลาด", str(e))

    def _survey_search(self):
        from . import dol_api
        ctx = self._survey_ctx
        a = ctx["attrs"]
        self._run_net(
            "กำลังค้นหาหลักฐานการรังวัด...",
            lambda: dol_api.search_cadastral(
                a.get("m1"), a.get("m2"), a.get("m3"), a.get("m4"),
                a.get("scale"), a.get("landno"), ctx["prov"], ctx["office"], zone=47),
            self._survey_show, self._survey_failed)

    def _survey_failed(self, e):
        from . import dol_api
        if isinstance(e, dol_api.DOLAuthError):
            dol_api.logout()
            ctx = self._survey_ctx
            if not ctx["retried"]:
                ctx["retried"] = True
                self._ask(QtWidgets.QMessageBox.Information, "เข้าสู่ระบบใหม่", str(e))
                self._survey_step()   # ขอ login ใหม่ แล้วค้นอีกครั้ง (retry ครั้งเดียวเหมือนเดิม)
                return
            self._ask(QtWidgets.QMessageBox.Warning, "หลักฐานการรังวัด", str(e))
        else:
            self._ask(QtWidgets.QMessageBox.Critical, "ค้นหารังวัดผิดพลาด", str(e))

    def _survey_show(self, recs):
        from . import dol_api
        ctx = self._survey_ctx
        a = ctx["attrs"]
        if not recs:
            self._ask(
                QtWidgets.QMessageBox.Information, "ไม่พบหลักฐานการรังวัด",
                "ไม่พบหลักฐานการรังวัดของแปลงนี้\n"
                f"(ค้นด้วยระวาง {a.get('m1')} {a.get('m2')} {a.get('m3')}-"
                f"{a.get('m4')} ที่ดิน {a.get('landno')} • สนง.{ctx['office']})")
            return
        rec = recs[0] if len(recs) == 1 else self._choose_cadastral(recs)
        if rec is None:
            return
        url = dol_api.survey_doc_url(rec.get("CADASTRAL_SEQ"), "1")
        QtGui.QDesktopServices.openUrl(QtCore.QUrl(url))
        self.iface.messageBar().pushMessage(
            "DOL", f"เปิดหลักฐานการรังวัด (พบ {len(recs)} รายการ) — "
                   f"CADASTRAL_SEQ {rec.get('CADASTRAL_SEQ')}", level=3, duration=8)

    def _on_dol_fail(self, msg):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()
        self._ask(QtWidgets.QMessageBox.Critical, "DOL ผิดพลาด", msg)

    def _dol_highlight_feature(self, geom, layer):
        """ไฮไลต์แปลงบนแผนที่ด้วยกรอบแดง"""
        self._dol_clear_highlight()
        if geom is None or geom.isEmpty():
            return
        canvas = self.iface.mapCanvas()
        rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(255, 0, 0))
        rb.setFillColor(QtGui.QColor(255, 0, 0, 50))
        rb.setWidth(3)
        rb.setToGeometry(geom, layer)
        rb.show()
        self._dol_highlight = rb
        # ไม่เรียก canvas.refresh() — rubber band วาดตัวเองอยู่แล้ว (เดิม refresh ทั้งแมพทุกครั้งที่ hover แปลง = หน่วง)

    def _dol_clear_highlight(self):
        rb = getattr(self, "_dol_highlight", None)
        if rb is not None:
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
            self._dol_highlight = None

    def _dol_on_hover(self, feat, layer):
        """ไฮไลต์แปลงใต้เมาส์ก่อนคลิก (ตัวช่วยตัดสินใจ)"""
        if feat is None:
            self._dol_clear_highlight()
            return
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                lyr.selectByIds(ids)
        self.iface.mapCanvas().refresh()

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def refresh_layers(self):
        # แปลง = เฉพาะเลเยอร์ Polygon, หมุด = เฉพาะเลเยอร์ Point
        prev = (self.poly_cb.currentData(), self.point_cb.currentData())
        self._refreshing = True
        try:
            self._refresh_layers_inner(prev)
        finally:
            self._refreshing = False
        self._arm_pair_watch()

    def _refresh_layers_inner(self, prev):
        self.poly_cb.clear(); self.point_cb.clear()
        self._field_cache.clear()   # รายชื่อเลเยอร์เปลี่ยน -> ล้าง cache field กันชื่อค้าง
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                gt = lyr.geometryType()   # มีเฉพาะ vector layer (raster -> error -> ข้าม)
            except Exception:
                continue
            if gt == QgsWkbTypes.PolygonGeometry:
                self.poly_cb.addItem(lyr.name(), lyr.id())
            elif gt == QgsWkbTypes.PointGeometry:
                self.point_cb.addItem(lyr.name(), lyr.id())
        # คงเลเยอร์ที่เลือกไว้เดิม (เดิม refresh แล้วเด้งกลับตัวแรกเสมอ)
        ok = [False, False]
        for n, (cb, pid) in enumerate(zip((self.poly_cb, self.point_cb), prev)):
            if pid:
                i = cb.findData(pid)
                if i >= 0:
                    cb.setCurrentIndex(i)
                    ok[n] = True
        # ★ 1.9.4 เกณฑ์เรียก auto-pick — เดิมใช้ธง "restored" ตัวเดียวร่วมกันทั้งสองช่อง
        #   บั๊กเดิม: ลบชั้นหมุดออกแล้วเพิ่มกลับ (PostGIS หลุด/ลากกลับจาก Browser) QGIS ออก layer id ใหม่
        #   -> ช่องหมุดกู้ไม่ได้ ตกไป index 0 = CT_<สาขา> แต่ช่องแปลงกู้ได้ -> restored=True -> ข้าม auto-pick
        #   -> รอบถัดไป prev กลายเป็น CT_id ซึ่ง "กู้สำเร็จ" ทุกครั้ง -> ค้างที่ CT ตลอดทั้ง session
        #   -> CT ไม่มีคอลัมน์ UTM -> _pairing_issues คืน None -> ตัวเตือนตายสนิท (บั๊กเดิมใต้เลขเวอร์ชันใหม่)
        if not self._user_picked:
            self._auto_pick_pair()                  # ยังไม่เคยเลือกเอง -> เลือกใหม่ได้ทั้งคู่ (ซ่อมตัวเอง)
        elif not all(ok):
            self._auto_pick_pair(fill_poly=not ok[0], fill_point=not ok[1])   # เติมเฉพาะช่องที่ของหาย

    def _on_layer_combo_changed(self, *_a):
        """ผู้ใช้สลับชั้นเอง -> จำไว้ว่าอย่าไปเลือกให้ใหม่ + ย้ายตัวเฝ้าไปชั้นใหม่
        (_refreshing กัน setCurrentIndex ที่โค้ดเราสั่งเองตอน refresh ไปนับเป็น 'ผู้ใช้เลือก')"""
        if not getattr(self, "_refreshing", False):
            self._user_picked = True
        self._arm_pair_watch()

    def _auto_pick_pair(self, fill_poly=True, fill_point=True):
        """เลือกชั้นแปลง+หมุดให้อัตโนมัติจากชื่อ <สาขา>_POLYGON / <สาขา>_POINT
        จับคู่โดย "ชื่อสาขาต้องตรงกัน" ไม่ใช่แค่ลงท้ายถูก — กันจับผิดคู่เมื่อโปรเจกต์มีหลายสาขา
        และกันหยิบ LandsMaps_<สาขา> ซึ่งเป็นชั้น polygon เหมือนกันแต่ไม่ใช่ชั้นทำงาน
        fill_poly/fill_point: เติมเฉพาะช่องที่ระบุ (ใช้ตอนของเดิมหายไปข้างเดียว)"""
        try:
            polys, points = {}, {}
            for l in QgsProject.instance().mapLayers().values():
                try:
                    gt = l.geometryType()
                except Exception:
                    continue            # raster/ชั้นที่ไม่มี geometryType
                up = l.name().strip().upper()
                if gt == QgsWkbTypes.PolygonGeometry and up.endswith("_POLYGON"):
                    polys.setdefault(up[:-8], l)
                elif gt == QgsWkbTypes.PointGeometry and up.endswith("_POINT"):
                    points.setdefault(up[:-6], l)
            pairs = sorted(set(polys) & set(points))
            if not pairs:
                return                  # ไม่ตรงรูปแบบ -> ปล่อยให้ผู้ใช้เลือกเอง
            key = pairs[0]
            targets = []
            if fill_poly:
                targets.append((self.poly_cb, polys[key]))
            if fill_point:
                targets.append((self.point_cb, points[key]))
            # หา index ให้ครบก่อนค่อยเซ็ต — กันกรณีพังกลางคันแล้วเหลือเลือกครึ่งเดียว
            plan = [(cb, i) for cb, lyr in targets
                    for i in (cb.findData(lyr.id()),) if i >= 0]
            if len(plan) != len(targets):
                return
            changed = any(cb.currentIndex() != i for cb, i in plan)
            for cb, i in plan:
                cb.setCurrentIndex(i)
            if changed:                 # แจ้งทุกครั้งที่เลือกให้จริง (เดิมแจ้งเฉพาะตอนมีหลายสาขา
                                        #  -> โปรเจกต์สาขาเดียวเงียบสนิท พนักงานไม่เห็นว่าฟีเจอร์ทำงาน)
                extra = f" (โปรเจกต์นี้มี {len(pairs)} สาขา — เปลี่ยนได้ที่กล่องด้านบน)" if len(pairs) > 1 else ""
                self.iface.messageBar().pushMessage(
                    "MLEP", f"เลือกชั้นให้อัตโนมัติ: แปลง '{polys[key].name()}' • หมุด '{points[key].name()}'{extra}",
                    level=0, duration=8)
        except Exception:
            pass                        # เลือกไม่ได้ -> ปล่อยให้ผู้ใช้เลือกเอง

    def _arm_pair_watch(self, *_a):
        """ติดตัวเฝ้า "มุมแปลงไม่มีหมุด" กับชั้นแปลงที่เลือก ตั้งแต่เปิดปลั๊กอิน
        (เดิม _watch_layer_editing ถูกเรียกเฉพาะตอนใช้เครื่องมือของปลั๊กอิน -> คนที่ใช้
        Vertex Tool ของ QGIS ล้วน ๆ แล้วกด Save ของ QGIS ไม่เคยถูกเฝ้าเลย = ช่องโหว่ตัวจริง)"""
        try:
            for _l in (QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                       QgsProject.instance().mapLayer(self.point_cb.currentData())):
                self._watch_layer_editing(_l)   # เฝ้าทั้งชั้นแปลงและชั้นหมุด
        except Exception:
            pass

    def _project_layers_changed(self, *_a):
        """เลเยอร์ในโปรเจกต์เพิ่ม/หาย -> refresh combo อัตโนมัติ (เดิมต้องกดปุ่ม 🔄 เอง)"""
        # เงาอ้างถึง layer ที่ cache ไว้ตอนคลิกแรก — ถ้าเลเยอร์นั้นเพิ่งถูกลบ
        # การวาดเฟรมถัดไปจะพังทุกครั้งที่ขยับเมาส์ (C++ object ถูกลบไปแล้ว) -> ทิ้งเงาก่อน
        self._preview_clear()
        if self.dlg is not None:
            try:
                self.refresh_layers()
            except Exception:
                pass
    def _ct_layers(self, exclude=()):
        """ชั้นหมุดหลักฐาน (CT / control point) ในโปรเจกต์ — เอาไว้ให้ snap ติดตอนแก้ไข
        หาแบบอัตโนมัติจากชื่อชั้น (ชั้นที่ส่งมอบชื่อ CT_<สาขา>; ต้นทางชื่อ <สาขา>_PointXY)
        เอาเฉพาะชั้นจุด และไม่ซ้ำกับชั้นที่เลือกไว้ในกล่องปลั๊กอินอยู่แล้ว
        (จำกัดด้วยชื่อ ไม่ใช่เอาทุกชั้นจุด — ไม่งั้นจะเสียประโยชน์ของการจำกัด snap เฉพาะชั้นทำงาน)"""
        out = []
        ex = {l.id() for l in exclude if l}
        try:
            for l in QgsProject.instance().mapLayers().values():
                if l.id() in ex:
                    continue
                try:
                    if l.geometryType() != QgsWkbTypes.PointGeometry:
                        continue
                except Exception:
                    continue        # raster/ชั้นที่ไม่มี geometryType
                n = l.name().strip().upper()
                if n.startswith("CT_") or n == "CT" or "POINTXY" in n.replace("_", ""):
                    out.append(l)
        except Exception:
            pass
        return out

    # ชื่อชั้นที่ปลั๊กอิน "Line Draw & Measure (วาดเส้น & วัดระยะ)" สร้าง
    #   (CHK_Node-Topo-main/line_tools.py:39  LINE_LAYER_NAME)
    # ตัวมันเก็บชั้นด้วย layer id ภายในตัวเอง เราอ่านไม่ได้ -> จับด้วย "ชื่อชั้น"
    LINE_TOOL_LAYER = "เส้นที่วาด (Line)"
    LINE_TOOL_LABEL = "ระยะเส้น (Label)"      # ชั้นป้ายระยะ — ไม่ใช่เส้นจริง ไม่เอามา snap

    def _line_tool_layers(self, exclude=()):
        """ชั้น "เส้นที่วาด (Line)" ของปลั๊กอินวาดเส้น&วัดระยะ — เอาไว้ให้ snap ติดตอนแก้ไข

        (ผู้ใช้สั่ง 26 ส.ค. 69) พนักงานวาดเส้นอ้างอิง/เส้นวัดระยะไว้ แล้วอยากลากมุมแปลง
        หรือหมุดเข้าไปเกาะเส้นนั้นได้ตรง ๆ เหมือนที่ snap ติดชั้นหมุดหลักฐาน CT
        จับด้วย **ชื่อชั้น** เพราะเป็น memory layer ที่ปลั๊กอินอีกตัวสร้าง (ไม่มีคีย์ร่วมให้ยึด)
        เอาเฉพาะชั้นเส้น และไม่เอาชั้นป้ายระยะ (ชื่อคนละอัน แต่เป็น LineString เหมือนกัน)
        """
        out = []
        ex = {l.id() for l in exclude if l}
        try:
            for l in QgsProject.instance().mapLayers().values():
                if l.id() in ex:
                    continue
                try:
                    if l.geometryType() != QgsWkbTypes.LineGeometry:
                        continue
                except Exception:
                    continue        # raster/ชั้นที่ไม่มี geometryType
                n = (l.name() or "").strip()
                if n == self.LINE_TOOL_LABEL:
                    continue
                # ตรงชื่อเป๊ะ หรือขึ้นต้นด้วยชื่อนั้น (เผื่อผู้ใช้ทำสำเนา -> QGIS เติม " copy"/" (1)")
                if n == self.LINE_TOOL_LAYER or n.startswith(self.LINE_TOOL_LAYER):
                    out.append(l)
        except Exception:
            pass
        return out

    def setup_snapping(self):
        self.canvas = self.iface.mapCanvas()
        config = QgsProject.instance().snappingConfig()
        if not config.enabled():
            config.setEnabled(True)
            # ปรับความแรงในการดูด (Tolerance) เป็น 15-20 pixels
            config.setTolerance(20)
            config.setUnits(QgsTolerance.Pixels)
            # ให้ Snap ทั้งจุด (Vertex) และเส้น (Segment)
            config.setType(QgsSnappingConfig.VertexAndSegment)
        # จำกัด snap เฉพาะชั้นแปลง+หมุดที่เลือกในปลั๊กอิน — ต้องตั้ง "ทุกครั้ง" ไม่ใช่เฉพาะตอน snapping เริ่มปิด
        # (เดิมโค้ดก้อนนี้อยู่ใน `if not config.enabled():` -> ถ้าโปรเจกต์/ผู้ใช้เปิด snapping ค้างไว้อยู่แล้ว
        #  (ปกติเป็น AllLayers) จะถูกข้ามทั้งก้อน -> QGIS สร้าง snap index ทุกชั้นในวิว = ช้ามากบนชั้น
        #  PostgreSQL ใหญ่ และไม่ re-target เมื่อผู้ใช้สลับ combo เลเยอร์)
        work = [l for l in (QgsProject.instance().mapLayer(self.poly_cb.currentData()),
                            QgsProject.instance().mapLayer(self.point_cb.currentData())) if l]
        work += self._ct_layers(exclude=work)   # + ชั้นหมุดหลักฐาน CT ให้ snap ติดด้วย
        work += self._line_tool_layers(exclude=work)   # + ชั้นเส้นที่วาดจากปลั๊กอินวาดเส้น&วัดระยะ
        try:
            if not work:
                raise ValueError("no working layers")
            config.setMode(QgsSnappingConfig.AdvancedConfiguration)
            ils = QgsSnappingConfig.IndividualLayerSettings(
                True, QgsSnappingConfig.VertexAndSegment, 20, QgsTolerance.Pixels)
            config.clearIndividualLayerSettings()   # ล้างชั้นของรอบก่อน (กันชั้นเก่าค้างเมื่อสลับ combo)
            for l in work:
                config.setIndividualLayerSettings(l, ils)
        except Exception:
            config.setMode(QgsSnappingConfig.AllLayers)   # fallback API รุ่นเก่า/ไม่มีเลเยอร์
        QgsProject.instance().setSnappingConfig(config)

        self.snap_utils = self.canvas.snappingUtils()
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        
    def start_interactive(self, mode):
        # 0. ล้างเงาตัวอย่างของรอบก่อน (ต้องอยู่ก่อน early-return ข้อ 2 ไม่งั้นเงาค้างจอ)
        self._preview_clear()

        # 1. เลือก UTM ก่อน
        self.process_selection('utm')

        # 2. เช็คว่ามีอะไรถูกเลือกไหม
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_lyr or poly_lyr.selectedFeatureCount() == 0:
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกแปลงที่ต้องการก่อน", level=2, duration=10)
            return

        # 3. เคลียร์ Marker เก่า (แต่ไม่เคลียร์ Selection!)
        self.clear_markers()
        self.src_pts = []
        
        # 4. ตั้งค่า Tool
        self.mode = mode
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.temp_tool.canvasMoveEvent = self.handle_generic_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

        # 5. บอกวิธีใช้ + บอกว่ามีเงาตัวอย่างให้ดูก่อนยืนยัน
        hint = {
            'move': "คลิกจุดอ้างอิง → เลื่อนเมาส์ดูเงาว่าแปลงจะไปตกที่ไหน → คลิกจุดปลายทางเพื่อยืนยัน",
            'rotate': "คลิกจุดหมุน → คลิกจุดอ้างอิง → เลื่อนเมาส์ดูเงา → คลิกยืนยันมุม",
            'scale': "คลิกจุดหมุน → คลิกจุดอ้างอิง → เลื่อนเมาส์ดูเงา → คลิกยืนยันขนาด",
        }.get(mode)
        if hint:
            self.iface.messageBar().pushInfo(mode.capitalize(), f"{hint} (คลิกขวา = ยกเลิก)")

    def handle_click(self, point, button):
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        
        # 2. เลือกพิกัด: ถ้า Snap ติดใช้จุด Snap ถ้าไม่ติดใช้ point (ที่ว่าง) ตรงๆ
        pt = match.point() if match.isValid() and match.point().x() != 0 else point
        
        # กำหนดสี Marker: Snap=แดง, ที่ว่าง=น้ำเงิน
        color = QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255)

        # 3. วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setPenWidth(4)
        m.setColor(color)
        m.setIconType(QgsVertexMarker.ICON_X)
        self.markers.append(m)
        self.src_pts.append(QgsPointXY(pt.x(), pt.y())) # บังคับเป็น PointXY

        # 3.5 คลิกแรกของรอบ = จังหวะเตรียมเงาตัวอย่าง (ดึง geometry ครั้งเดียวจบ)
        #     ดึงตอนนี้ ไม่ใช่ตอนกดปุ่ม: selection ณ ตอนนี้คือของจริงแน่นอน
        #     (หลัง execute_tool มี restore_selection ตาม timer 100ms — กว่าคนจะคลิกใหม่ก็คืนค่าแล้ว)
        if len(self.src_pts) == 1 and not self._preview_items:
            self._preview_arm()

        # 4. ตรวจสอบจำนวนจุดตามโหมด
        limit = _CLICK_LIMIT.get(self.mode, 2)

        if len(self.src_pts) >= limit:
            self.execute_tool()
            
    def handle_generic_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือทั่วไป (แก้ไข Error) + ขยับเงาตัวอย่าง Move/Rotate/Scale"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return

        match = self.snap_utils.snapToMap(event.mapPoint())
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            # แทนที่จะใส่ None ให้ใช้ Match ว่างๆ แทนครับ
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # จุดของเงา = สูตรเดียวกับ handle_click เป๊ะ (รวม .x() != 0) -> เงาอยู่ตรงที่คลิกจะลงจริง
        pt = match.point() if match.isValid() and match.point().x() != 0 else event.mapPoint()
        self._preview_update(QgsPointXY(pt.x(), pt.y()))

    # ============ เงาตัวอย่าง (preview) ของ Move/Rotate/Scale ============
    def _preview_arm(self):
        """เตรียมเงาของรอบนี้: ดึง geometry ที่เลือก "ครั้งเดียว" + สร้าง rubber band ต่อเลเยอร์

        เก็บ geom เป็น CRS ของเลเยอร์ดิบๆ ไม่แปลง เพราะ execute_tool ก็ไม่แปลง —
        เงาต้องเหมือนของจริงเป๊ะ ไม่ใช่ "ถูกกว่าของจริง" (ดู _preview_geom)
        ห้ามย้ายการดึงนี้ไปไว้ใน mouse-move: บน PostgreSQL = 1 query ต่อเฟรมต่อเลเยอร์
        ซึ่งเป็นปัญหาที่ 1.7.0 เพิ่งไล่แก้ทั้งรุ่น"""
        self._preview_clear()
        if self.mode not in _PREVIEW_MODES:
            return
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in (poly_lyr, point_lyr) if l and l.selectedFeatureCount() > 0]
        if not layers:
            return

        # แปลงล็อกตัดจบตั้งแต่คลิกแรก: execute_tool ปฏิเสธ L1-RTK/L1-TS แน่นอนอยู่แล้ว
        # -> โชว์เงาว่าขยับได้ทั้งที่สุดท้ายมันไม่ขยับ = เงาโกหก จึงไม่โชว์แล้วบอกเหตุผลไปเลย
        # (แค่บอกล่วงหน้า ไม่บล็อก — คนตัดสินใจจริงยังเป็น execute_tool เหมือนเดิมทุกประการ)
        locked = self._preview_locked_type(poly_lyr)
        if locked and not self._admin_unlock_l1:          # ★ admin: โชว์เงา preview ได้ตามปกติ
            self.iface.messageBar().pushMessage(
                "MLEP Lock",
                f"แปลงที่เลือกมีประเภท {locked} ซึ่งเป็นพิกัดอ้างอิง ขยับไม่ได้ — "
                "จะไม่มีเงาตัวอย่างให้ (คลิกครบจุดแล้วระบบจะปฏิเสธ)", level=1, duration=8)
            return

        canvas = self.iface.mapCanvas()
        proj_crs = QgsProject.instance().crs()
        srcs, total, warn_crs = [], 0, False
        for lyr in layers:
            # request ชุดเดียวกับ execute_tool -> เงาครอบ feature ชุดเดียวกับที่จะถูกแก้จริง
            req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
            parts = []
            for f in lyr.getFeatures(req):
                g = f.geometry()
                if g.isNull():
                    continue                    # ข้ามแบบเดียวกับ execute_tool
                # แตก multipart ให้เหลือชิ้นเดี่ยวล้วน -> ของที่ส่งเข้า collectGeometry ชนิดเดียวกันหมด
                parts.extend(g.asGeometryCollection() if g.isMultipart() else [QgsGeometry(g)])
            if not parts:
                continue
            if lyr.crs() != proj_crs:
                warn_crs = True
            # รวมเป็นก้อนเดียวต่อเลเยอร์ -> ต่อเฟรมเรียก C++ ครั้งเดียว ไม่ว่าจะเลือกกี่แปลง
            coll = QgsGeometry.collectGeometry(parts)
            if coll is None or coll.isNull():
                continue
            # OPT (2026-08-07): นับด้วย C++ ครั้งเดียว แทนวน python ทีละ vertex
            try:
                total += coll.constGet().nCoordinates()
            except Exception:
                total += sum(1 for _ in coll.vertices())
            srcs.append((lyr, coll))

        # เลือกทั้งระวางแล้ว vertex บานปลาย -> ย่อเฉพาะ "ชั้นแปลง" เป็นกรอบรวม (convex hull)
        # ชั้นหมุดไม่ย่อ: 1 หมุด = 1 vertex ไม่ใช่ต้นเหตุความหน่วง และ hull ของหมุดจะกลายเป็นแผ่นทึบ
        heavy = total > _PREVIEW_VERTEX_BUDGET
        self._preview_heavy = heavy
        for lyr, coll in srcs:
            src = (coll.convexHull() if heavy and lyr.geometryType() == QgsWkbTypes.PolygonGeometry
                   else coll)
            if src is None or src.isNull():
                continue
            gtype = src.type()          # อ่านชนิดจาก geometry ตรงๆ -> band กับของที่ใส่ตรงกันเสมอ
            # ฟ้า (cyan) = สีเดียวที่ยังว่าง (แดง=Snap/DOL • น้ำเงิน=คลิกที่ว่าง • เหลือง=hover
            #  • แดงเข้ม=ล็อก • เขียว=เลือกแล้ว • ส้ม=vertex • ม่วง=snap หมุด)
            rb = QgsRubberBand(canvas, gtype)
            rb.setColor(QtGui.QColor(0, 200, 200))
            rb.setFillColor(QtGui.QColor(0, 200, 200, 45))
            rb.setWidth(2)
            if gtype == QgsWkbTypes.PointGeometry:
                rb.setIcon(QgsRubberBand.ICON_X)    # กากบาทให้เข้าชุดกับ Marker ตอนคลิก
                rb.setIconSize(8)
            rb.show()
            self._preview_items.append((lyr, src, rb, gtype))

        # จดว่าเงารอบนี้เป็นของเครื่องมือตัวไหน — ต้องอยู่หลัง setMapTool ของ start_interactive
        # (ตอนนี้ถูกเรียกจากคลิกแรกอยู่แล้ว จึงพ้นจังหวะนั้นแน่นอน) ดู _map_tool_changed
        if self._preview_items:
            self._preview_tool = self.temp_tool

        if warn_crs:
            # เงาจะลอยหลุดจอ — ไม่ใช่บั๊กของเงา แต่เป็นของ execute_tool ที่เอาค่าพิกัดโปรเจกต์
            # ไปบวกกับ geometry ของเลเยอร์ตรงๆ โดยไม่แปลง CRS (ของจริงก็จะเหวี่ยงแบบเดียวกัน)
            # ห้าม "แก้" ด้วยการใส่ QgsCoordinateTransform แค่ในเงา -> เงาถูก ของจริงผิด = แย่กว่าเดิม
            self.iface.messageBar().pushMessage(
                "MLEP", "เลเยอร์กับโปรเจกต์คนละระบบพิกัด (CRS) — เครื่องมือชุดนี้ไม่แปลง CRS "
                        "ทั้งเงาตัวอย่างและผลจริงจะคลาดเคลื่อนเหมือนกัน ควรตั้ง CRS ให้ตรงกันก่อน",
                level=1, duration=15)

    def _preview_locked_type(self, poly_lyr):
        """คืน 'L1-RTK' / 'L1-TS' ถ้าแปลงที่เลือกมีตัวที่ถูกล็อก • '' ถ้าไม่มี
        คิวรีเดียว NoGeometry ชุดเดียวกับ execute_tool — ยิงตอนคลิกแรกเท่านั้น ไม่ใช่ทุกเฟรม"""
        if not poly_lyr:
            return ""
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        ids = poly_lyr.selectedFeatureIds()
        if type_idx == -1 or not ids:
            return ""
        req = (QgsFeatureRequest().setFilterFids(ids)
               .setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([type_idx]))
        found = ""
        for f in poly_lyr.getFeatures(req):
            val = f.attribute(type_idx)
            if val is None:
                continue
            v = str(val).strip().upper()
            if v == "L1-RTK":
                return v            # เข้มสุด -> ตัดจบเลย
            if v == "L1-TS":
                found = v
        return found

    def _preview_geom(self, src, cur):
        """คำนวณ geometry ของเงา 1 ก้อน: copy จาก src แล้วแปลงตามตำแหน่งเมาส์ cur

        สูตรทุกบรรทัดลอกจาก execute_tool มาทั้งดุ้น รวมถึง "การไม่แปลง CRS" ด้วย —
        ตั้งใจให้เหมือนของจริงทุกกรณี ไม่ใช่ให้ถูกตามหลักการ ถ้าของจริงเพี้ยน เงาต้องเพี้ยนตาม
        ไม่งั้นเงาจะโกหกว่าผลลัพธ์จะออกมาดี"""
        p = self.src_pts
        g = QgsGeometry(src)   # copy ก่อนแตะ — QgsGeometry เป็น copy-on-write ต้นฉบับใน cache ไม่กระทบ

        # --- 1. Move ---
        if self.mode == 'move':
            g.translate(cur.x() - p[0].x(), cur.y() - p[0].y())

        # --- 2. Rotate (ลบหน้ามุมตามของจริง) ---
        #     ห้ามแก้เครื่องหมาย และห้ามเขียนใหม่ด้วย QTransform:
        #     QgsGeometry.rotate บวก = ตามเข็ม แต่ QTransform.rotate บวก = ทวนเข็ม (ตรงข้ามกัน)
        #     -> ถ้าเปลี่ยนมาใช้ QTransform โดยไม่พลิกเครื่องหมาย เงาจะหมุนกลับทางกับของจริง
        elif self.mode == 'rotate':
            a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
            a2 = math.atan2(cur.y()-p[0].y(), cur.x()-p[0].x())
            g.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))

        # --- 3. Scale ---
        elif self.mode == 'scale':
            d1 = math.sqrt(p[0].sqrDist(p[1]))
            d2 = math.sqrt(p[0].sqrDist(cur))
            if d1 > 0:      # d1 == 0 -> ของจริงข้าม changeGeometry ทั้งก้อน -> เงาต้องนิ่งที่เดิม
                s = d2 / d1
                # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                g.translate(-p[0].x(), -p[0].y())
                matrix = QtGui.QTransform(); matrix.scale(s, s)
                g.transform(matrix)
                g.translate(p[0].x(), p[0].y())
                # s == 0 (เมาส์ทับ p0) ของจริงยุบแปลงเป็นจุด -> เงาต้องยุบตาม ห้ามใส่ guard เพิ่ม
        return g

    def _preview_update(self, cur):
        """ขยับเงาตามเมาส์ — ถูกเรียกทุกเฟรม
        ห้ามยิง query และห้ามเรียก canvas.refresh() ในนี้ (rubber band วาดตัวเองอยู่แล้ว)
        ใช้แต่ geometry ที่ cache ไว้ตอน _preview_arm"""
        if not self._preview_items:
            return                       # ยังไม่คลิกแรก / โหมดไม่มีเงา / แปลงล็อก
        need = _CLICK_LIMIT.get(self.mode, 2) - 1
        if self.mode not in _PREVIEW_MODES or len(self.src_pts) != need:
            self._preview_hide()         # คลิกยังไม่พอ -> ไม่มีเงา
            return
        # snap ดูดในรัศมี 20 px -> เมาส์ขยับหลายพิกเซลแล้วได้จุดเดิม ไม่ต้องวาดซ้ำ
        key = (self.mode, cur.x(), cur.y())
        if key == self._preview_last:
            return
        self._preview_last = key
        for lyr, src, rb, _gt in self._preview_items:
            # ส่ง lyr เข้าไปด้วย -> band แปลง CRS เลเยอร์->จอ แบบเดียวกับที่ renderer ทำตอน commit
            rb.setToGeometry(self._preview_geom(src, cur), lyr)
        self._preview_msg(cur)

    def _preview_hide(self):
        """ซ่อนเงาชั่วคราว (คลิกยังไม่ครบ) โดยไม่ทิ้ง band/cache -> ไม่ต้องดึง geometry ใหม่
        _preview_last is None = ไม่มีเงาบนจออยู่แล้ว -> ออกเลย (กันทำงานซ้ำทุกเฟรมก่อนคลิกแรก)"""
        if self._preview_last is None:
            return
        for _lyr, _src, rb, gt in self._preview_items:
            try:
                rb.reset(gt)
            except Exception:
                pass
        self._preview_last = None
        self._preview_msg(None)

    def _preview_clear(self):
        """ลบเงาออกจากจอ + ทิ้ง cache — เรียกซ้ำได้เสมอ ปลอดภัยแม้ยังไม่เคยมีเงา
        ไม่แตะ layer ที่ cache ไว้เลย (แตะแค่ rubber band) -> เรียกตอนเลเยอร์ถูกลบไปแล้วก็ปลอดภัย"""
        had = bool(getattr(self, "_preview_items", [])) or self._preview_last is not None
        for _lyr, _src, rb, _gt in getattr(self, "_preview_items", []):
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
        self._preview_items = []
        self._preview_last = None
        self._preview_tool = None
        self._preview_heavy = False
        # ล้างแถบสถานะเฉพาะตอนที่เราเคยเขียนไว้จริง — สลับเครื่องมือตอนไม่ได้ใช้ปลั๊กอิน
        # ไม่ควรไปลบข้อความของ QGIS/ปลั๊กอินอื่นที่ค้างอยู่
        if had:
            self._preview_msg(None)

    def _preview_msg(self, cur):
        """ตัวเลขกำกับเงา (ระยะ/มุม/สเกล) -> แถบสถานะ • cur=None = ล้างข้อความ
        ไม่ใช้ message bar เพราะจะเด้ง widget ใหม่ทุกเฟรม — bar สงวนไว้ให้ตอนคลิก/จบงาน/error"""
        try:
            bar = self.iface.statusBarIface()
            if bar is None:
                return
            p = self.src_pts
            txt = ""
            if cur is None:
                pass
            elif self.mode == 'move' and len(p) >= 1:
                txt = f"Move: เลื่อน {math.sqrt(p[0].sqrDist(cur)):.3f} ม."
            elif self.mode == 'rotate' and len(p) >= 2:
                a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                a2 = math.atan2(cur.y()-p[0].y(), cur.x()-p[0].x())
                deg = (math.degrees(a2 - a1) + 180) % 360 - 180   # คุมช่วงเป็น -180..180 อ่านง่าย
                txt = f"Rotate: หมุน {deg:+.4f}° (+ = ทวนเข็มนาฬิกา)"
            elif self.mode == 'scale' and len(p) >= 2:
                d1 = math.sqrt(p[0].sqrDist(p[1]))
                d2 = math.sqrt(p[0].sqrDist(cur))
                txt = (f"Scale: สเกล {d2/d1:.6f} ({d1:.3f} → {d2:.3f} ม.)" if d1 > 0
                       else "Scale: จุดอ้างอิงทับจุดหมุน — ปรับสเกลไม่ได้ (คลิกขวา = ยกเลิก)")
            # เงาถูกย่อ -> บอกไปตรงๆ ไม่งั้นผู้ใช้เห็นกรอบแทนแปลงแล้วนึกว่าเสีย
            if txt and self._preview_heavy:
                txt += "  •  เงาย่อเป็นกรอบรวม (แปลงเยอะ) — ผลจริงยังแก้ครบทุกแปลง"
            bar.showMessage(txt)
        except Exception:
            pass   # แถบสถานะเป็นของแถม — หายไปได้ ขอแค่เงายังทำงาน

    def execute_tool(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        
        if not layers:
            self.cancel_transform()
            return
            
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self.last_layers = layers
        p = self.src_pts

        # ★ OPT (2026-08-07): ผลของ "P2/P4 อยู่บน node ของแปลง L1-RTK ไหม" ไม่ขึ้นกับ feature ที่วนอยู่
        #   (p[1]/p[3] คงที่ทั้ง operation) แต่เดิมถูกเรียกซ้ำ "ในลูป" ทั้งฝั่งแปลงและฝั่งหมุด
        #   -> ยิง setFilterRect เข้า PostGIS 2 ครั้ง/feature · กลุ่ม 50 แปลง+300 หมุด ≈ 700 round-trip
        #   คิดครั้งเดียวแบบ lazy (คิดต่อเมื่อเจอเคส L1-TS จริง) แล้วใช้ซ้ำ
        _rtk_ok_cache = {}

        def _rtk_ends_ok():
            """P2 และ P4 อยู่บน node ของแปลง L1-RTK ทั้งคู่ไหม (คิดครั้งเดียวต่อ operation)"""
            if 'v' not in _rtk_ok_cache:
                try:
                    _rtk_ok_cache['v'] = bool(
                        len(p) >= 4
                        and self._is_point_on_rtk_node(poly_lyr, p[1])
                        and self._is_point_on_rtk_node(poly_lyr, p[3]))
                except Exception:
                    _rtk_ok_cache['v'] = False
            return _rtk_ok_cache['v']

        # ─── ตรวจสอบกฎการล็อกแปลง L1-RTK / L1-TS ───
        if poly_lyr:
            type_idx = self._field_index(poly_lyr.fields(), 'type')
            if type_idx != -1:
                poly_ids = poly_lyr.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_lyr.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        # ★ admin ปลดล็อก L1: ข้ามด่านล็อกแปลง polygon ทั้งก้อน (เดิมเช็ก admin เฉพาะฝั่งหมุด 1670)
                        if val is not None and not self._admin_unlock_l1:
                            val_str = str(val).strip().upper()
                            if val_str == "L1-RTK":
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-RTK ซึ่งเป็นพิกัดอ้างอิงหลัก ไม่สามารถขยับได้!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return
                            elif val_str == "L1-TS":
                                # ยกเว้นกรณีใช้ปุ่ม transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                                if self.mode == 'transform' and _rtk_ends_ok():
                                    continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                                        
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-TS ไม่สามารถขยับได้ ยกเว้นใช้โหมด Transform (2 Pts) ไปต่อกับ L1-RTK เท่านั้น!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return

        # ตรวจสอบสิทธิ์การขยับพิกัดผ่านจุดหมุด (กรณีจุดหมุดถูกเลือก)
        if point_lyr and point_lyr.selectedFeatureCount() > 0 and poly_lyr:
            # ตาราง UTM ล็อกทั้งหมดในคิวรีเดียว (เดิม query ต่อค่า UTM — N round-trips บน PostgreSQL)
            locked_map = self._locked_utm_map(poly_lyr)
            # ★ ดึงเฉพาะคอลัมน์ UTM ไม่เอา geometry — เช็ค lock ใช้แค่ค่า UTM
            #   (เดิม selectedFeatures() ดึงทุก attribute + geometry ของทุกหมุดที่เลือก)
            _sel_ids = point_lyr.selectedFeatureIds() if locked_map else []
            _ureq = QgsFeatureRequest().setFilterFids(_sel_ids).setFlags(QgsFeatureRequest.NoGeometry)
            _uf = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if _uf:
                _ui = point_lyr.fields().indexOf(_uf)
                if _ui >= 0:
                    _ureq.setSubsetOfAttributes([_ui])
            for pt_f in (point_lyr.getFeatures(_ureq) if _sel_ids else []):
                is_locked, type_str = self._is_point_feature_locked(pt_f, locked_map, _uf)
                if is_locked and not self._admin_unlock_l1:
                    # ข้อยกเว้นเฉพาะโหมด transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                    if type_str == "L1-TS" and self.mode == 'transform' and _rtk_ends_ok():
                        continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                            
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return
                    else:
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return

        # เปิด edit ทั้งเลเยอร์แปลง+หมุดที่ตั้งค่าไว้ แยกจากเงื่อนไข selection
        # (แก้: บางทีหมุดไม่ถูกเลือก -> point layer ไม่ขึ้น edit)
        # ★ fail-closed (2026-08-06): เดิมไม่เช็คผล startEditing -> เลเยอร์ที่เปิดแก้ไม่ได้
        #   (สิทธิ์ไม่พอ/read-only) จะเงียบ แล้วอีกเลเยอร์ถูกแก้ฝ่ายเดียว = แปลงกับหมุดหลุดคู่กัน
        for _l in (poly_lyr, point_lyr):
            if not _l or _l.isEditable() or _l.startEditing():
                continue
            if _l in layers:                 # เลเยอร์ที่ "จะถูกเขียนจริง" -> เปิดไม่ได้ = หยุดทั้งงาน
                self.iface.messageBar().pushMessage(
                    "MLEP Error",
                    f"เปิดโหมดแก้ไข '{_l.name()}' ไม่ได้ (สิทธิ์ไม่พอ / เลเยอร์อ่านอย่างเดียว) "
                    "— ยกเลิกทั้งงาน เพื่อไม่ให้แปลงกับหมุดหลุดคู่กัน", level=2, duration=0)
                self.cancel_transform()
                return
            # ★ เลเยอร์ที่ไม่มีอะไรถูกเลือก = ไม่ถูกเขียนอยู่แล้ว -> แค่เตือน ไม่บล็อกงาน
            #   (release gate: เดิมบล็อกทั้ง gesture ทั้งที่เลเยอร์นั้นไม่เกี่ยวข้องเลย)
            self.iface.messageBar().pushMessage(
                "MLEP", f"เปิดโหมดแก้ไข '{_l.name()}' ไม่ได้ (ไม่มีสิ่งที่เลือกในชั้นนี้ จึงทำงานต่อได้)",
                level=1, duration=6)

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        _done = []               # เลเยอร์ที่แก้เสร็จแล้ว (ไว้ย้อนถ้าเลเยอร์ถัดไปพัง)
        for lyr in layers:
            lyr.beginEditCommand(f"MLEP {self.mode}")
            
            try:
                # Optimize: ดึงเฉพาะ Geometry และรวบรวมเป็น list ก่อนวนลูปแก้ไข เพื่อป้องกันปัญหา cursor ล็อกขณะเขียนข้อมูล
                req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
                features = list(lyr.getFeatures(req))
                # ★ เช็คผลทุกการเขียน (2026-08-06): changeGeometry/moveVertex คืน False ได้เงียบ ๆ
                #   (provider ปฏิเสธ/ฟีเจอร์หาย) -> เดิมนับว่าสำเร็จ = อีกเลเยอร์ขยับฝ่ายเดียว
                #   โยน RuntimeError ให้ except ด้านล่างย้อน "ทั้งชุด" ตามกติกาทั้งคู่หรือไม่ทำเลย
                #   (นิยามครั้งเดียวต่อเลเยอร์ ไม่สร้างใหม่ทุก feature)
                def _w(ok, fid_, what=""):
                    if not ok:
                        raise RuntimeError(f"เขียนรูปทรงไม่สำเร็จที่ feature {fid_} {what}")

                for f in features:
                    geom = f.geometry()
                    if geom.isNull(): continue

                    # --- 1. Move ---
                    if self.mode == 'move' and len(p) >= 2:
                        dx, dy = p[1].x() - p[0].x(), p[1].y() - p[0].y()
                        geom.translate(dx, dy)
                        _w(lyr.changeGeometry(f.id(), geom), f.id(), "(move)")

                    # --- 2. Rotate (ใส่ลบหน้ามุมตามที่ตกลงกัน) ---
                    elif self.mode == 'rotate' and len(p) >= 3:
                        a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                        a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
                        geom.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))
                        _w(lyr.changeGeometry(f.id(), geom), f.id(), "(rotate)")

                    # --- 3. Scale (ปรับใหม่ให้ชัวร์) ---
                    elif self.mode == 'scale' and len(p) >= 3:
                        d1 = math.sqrt(p[0].sqrDist(p[1]))
                        d2 = math.sqrt(p[0].sqrDist(p[2]))
                        if d1 > 0:
                            s = d2 / d1
                            # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                            geom.translate(-p[0].x(), -p[0].y())
                            matrix = QtGui.QTransform(); matrix.scale(s, s)
                            geom.transform(matrix)
                            geom.translate(p[0].x(), p[0].y())
                            _w(lyr.changeGeometry(f.id(), geom), f.id(), "(scale)")

                    # --- 4. Transform ---
                    elif self.mode == 'transform' and len(p) >= 4:
                        self.apply_similarity_direct(lyr, f, p)

                    # --- 5. Move Node (Optimized via C++ closestVertex) ---
                    elif self.mode == 'modify_node' and len(p) >= 2:
                        closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(p[0])
                        if sqr_dist < 0.000001:  # threshold 0.001 (sqrDist = 0.001 ** 2)
                            if vertex_idx >= 0:
                                _w(lyr.moveVertex(p[1].x(), p[1].y(), f.id(), vertex_idx), f.id(), "(move node)")
                
                lyr.endEditCommand()
                _done.append(lyr)                 # สำเร็จแล้ว (ถูก push ลง undo-stack)
            except Exception as e:
                # ★ ทั้งคู่หรือไม่ทำเลย (2026-08-06): เดิม destroy เฉพาะเลเยอร์ที่พัง แล้ว "ลูปเดินต่อ"
                #   ไปแปลงอีกเลเยอร์ => แปลงไม่ขยับ แต่หมุดขยับทั้งกลุ่ม = ผิดกติกาเหล็กทั้งชุด
                #   ตอนนี้: ย้อนเลเยอร์ที่ทำสำเร็จไปแล้วด้วย (undo ตาม delta จาก baseline) แล้วหยุด
                lyr.destroyEditCommand()
                for _d in _done:
                    try:
                        _base = (self._op_baseline or {}).get(_d.id())
                        _n = _d.undoStack().index() - (_base[1] if _base else _d.undoStack().index())
                        for _ in range(max(0, _n)):
                            _d.undoStack().undo()
                    except Exception:
                        pass
                self._ask(
                    QtWidgets.QMessageBox.Critical, "ยกเลิกทั้งการทำงาน",
                    f"เกิดข้อผิดพลาดที่เลเยอร์ '{lyr.name()}': {e}\n\n"
                    "ย้อนกลับให้ทั้งหมดแล้ว (แปลงและหมุดยังตรงกันเหมือนเดิม) — กรุณาลองใหม่")
                print(f"Error in execute_tool for layer {lyr.name()}: {e}")
                break

        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        self.iface.mapCanvas().refresh()
        self.clear_markers()
        # ทิ้งเงา (geometry ใน cache เป็นของก่อนแก้ = ล้าสมัยแล้ว)
        # ไม่ขยับ cache ตามสูตรที่เพิ่งแก้ เพราะถ้า changeGeometry ล้มเหลวเงียบๆ เงาจะโกหกทันที
        # -> คลิกแรกของรอบหน้าไปดึงของจริงมาใหม่ ช้ากว่านิดเดียว (1 คิวรีต่อรอบ) แต่ไม่มีทางโกหก
        self._preview_clear()
        self.src_pts = []
        if self.mode == 'transform' :
            self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def apply_similarity_direct(self, lyr, f, p):
        """คำนวณ Transform แบบ Matrix (Similarity)"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        # x' = ax - by + tx , y' = bx + ay + ty
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        lyr.changeGeometry(f.id(), geom)

    @staticmethod
    def _field_index(fields, names):
        """index ของฟิลด์แรกที่ชื่อ (ตัวพิมพ์เล็ก) อยู่ใน names; -1 ถ้าไม่พบ
        names = str (ชื่อเดียว) หรือ set ของชื่อ"""
        if isinstance(names, str):
            names = {names}
        for i, f in enumerate(fields):
            if f.name().lower() in names:
                return i
        return -1

    def _is_point_on_rtk_node(self, poly_lyr, point_xy):
        """ตรวจสอบว่าพิกัด point_xy อยู่บน Node ของแปลงประเภท L1-RTK หรือไม่"""
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        if type_idx == -1:
            return False

        # สี่เหลี่ยมตรงๆ (เลี่ยง buffer() ที่สร้าง geometry วงกลมทิ้ง)
        search_rect = QgsRectangle(point_xy.x() - 0.05, point_xy.y() - 0.05,
                                   point_xy.x() + 0.05, point_xy.y() + 0.05)
        # ดึง geometry มาในคิวรีเดียว (เดิม query แบบ NoGeometry แล้วค่อย getFeature ซ้ำต่อ candidate)
        req = QgsFeatureRequest().setFilterRect(search_rect).setSubsetOfAttributes([type_idx])
        for feat in poly_lyr.getFeatures(req):
            val = feat.attribute(type_idx)
            if val is not None and str(val).strip().upper() == "L1-RTK":
                geom = feat.geometry()
                if geom and not geom.isNull():
                    _cp, vertex_idx, _pi, _ni, sqr_dist = geom.closestVertex(point_xy)
                    if sqr_dist < 0.0025:  # 0.05 ** 2
                        return True
        return False

    def _locked_utm_map(self, poly_lyr):
        """ดึงค่า UTM ของแปลงล็อก (L1-RTK/L1-TS) ทั้งเลเยอร์ใน "คิวรีเดียว" -> dict {utm: type}
        filter ฝั่ง server + NoGeometry — แทนการยิง query เทียบ UTM ต่อหมุด/ต่อค่า
        (บน PostgreSQL เดิมคือ 1 round-trip ต่อค่า UTM ที่ไม่ซ้ำ → เหลือ 1 ครั้งต่อ operation)
        ถ้า UTM เดียวกันมีทั้ง L1-RTK และ L1-TS จะเก็บ L1-RTK (เข้มกว่า)

        CACHE ต่อ edit-session: คิวรีนี้ดึงแปลงล็อก "ทั้งอำเภอ" (ปทุม 90,691 / คลองหลวง 69,284 แถว) และถูกเรียกใหม่
        ทุก gesture — ทุกครั้งที่ลากกล่อง Move Node, ทุก commit Move/Rotate/Scale, ทุก commit Align — บน PostgreSQL
        คือ scan ตารางใหญ่ + ส่งข้ามเน็ตซ้ำๆ. ตาราง UTM ล็อกจะเปลี่ยนได้ก็ต่อเมื่อคอลัมน์ Type เปลี่ยน ซึ่ง
        พนักงานไม่มีสิทธิ์แก้ (GRANT UPDATE เฉพาะ geom/SCORE/REMARK/cluster_id) และมีแต่ pipeline ที่เขียน
        -> ดึงครั้งเดียวพอ. ล้าง cache เมื่อเลเยอร์ commit/rollback/เปิดแก้ใหม่ (ดู _watch_layer_editing)"""
        _lid = poly_lyr.id() if poly_lyr else None
        _c = getattr(self, "_locked_cache", None)
        if _c is not None and _c.get("lid") == _lid:
            return _c["map"]
        utm_field = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        type_field = self._resolve_field(poly_lyr, {'type'})
        if not utm_field or not type_field:
            return {}
        fields = poly_lyr.fields()
        u_idx = fields.indexFromName(utm_field)
        t_idx = fields.indexFromName(type_field)
        expr = (f"upper(trim({QgsExpression.quotedColumnRef(type_field)})) "
                "IN ('L1-RTK','L1-TS')")
        req = (QgsFeatureRequest().setFilterExpression(expr)
               .setFlags(QgsFeatureRequest.NoGeometry)
               .setSubsetOfAttributes([u_idx, t_idx]))
        locked = {}
        for f in poly_lyr.getFeatures(req):
            u, t = f.attribute(u_idx), f.attribute(t_idx)
            if u is None or t is None:
                continue
            key = _norm_utm(u)
            t_str = str(t).strip().upper()
            if t_str == "L1-RTK" or key not in locked:
                locked[key] = t_str
        self._locked_cache = {"lid": _lid, "map": locked}   # ใช้ซ้ำทั้ง session (ล้างตอน commit/rollback/เริ่มแก้)
        self._watch_layer_editing(poly_lyr)                 # ให้แน่ใจว่ามี signal มาล้าง cache
        return locked

    def _is_point_feature_locked(self, point_f, locked_map, utm_field=None):
        """ตรวจสอบว่าหมุดนี้เชื่อมโยงกับแปลงที่ถูกล็อก (L1-RTK/L1-TS) ผ่านฟิลด์ UTM
        locked_map: dict {utm: type} จาก _locked_utm_map (prefetch คิวรีเดียวต่อ operation)"""
        if not locked_map:
            return False, None
        # OPT (2026-08-07): ผู้เรียกที่วนหลายหมุดส่งชื่อฟิลด์ที่ resolve แล้วมาได้ (utm_field)
        #   -> ไม่ต้องสแกน fields() + lower() ใหม่ทุกหมุด
        point_utm_field = utm_field
        if not point_utm_field:
            point_utm_field = next(
                (f.name() for f in point_f.fields()
                 if f.name().lower() in _UTM_FIELD_NAMES),
                None
            )
        if not point_utm_field:
            return False, None
        utm_val = point_f[point_utm_field]
        if utm_val is None:
            return False, None
        t = locked_map.get(_norm_utm(utm_val))
        return (True, t) if t else (False, None)

    def set_score_value(self, value):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย score จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())

        # ตรวจสอบกฎการห้ามใส่ Score ให้กับแปลง L1-RTK และ L1-TS
        if poly_layer:
            type_idx = self._field_index(poly_layer.fields(), 'type')
            if type_idx != -1:
                poly_ids = poly_layer.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_layer.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str in ("L1-RTK", "L1-TS") and not self._admin_unlock_l1:
                                self.iface.messageBar().pushMessage(
                                    "Score Blocked",
                                    f"แปลง {f.id()} เป็นประเภท {val_str} ไม่อนุญาตให้ตั้งค่า Score!",
                                    level=2, duration=10
                                )
                                return

        # ★ ด่านฝั่ง "หมุด" (2026-08-06): ถ้าเลือกเฉพาะหมุด (ไม่ได้เลือกแปลง) ด่านบนจะข้ามทั้งก้อน
        #   เพราะ process_selection('utm') จะ return ทันทีเมื่อชั้นแปลงไม่มี selection
        #   -> เดิมเขียน Score ทับหมุดของแปลง L1 ได้ · ใช้กลไกเดียวกับ execute_tool
        if point_layer and point_layer.selectedFeatureCount() > 0 and poly_layer:
            locked_map = self._locked_utm_map(poly_layer)     # cache ทั้ง session (~0ms เมื่ออุ่น)
            if locked_map:
                _uf = self._resolve_field(point_layer, _UTM_FIELD_NAMES)
                _req = QgsFeatureRequest().setFilterFids(point_layer.selectedFeatureIds()) \
                                          .setFlags(QgsFeatureRequest.NoGeometry)
                if _uf:
                    _ui = point_layer.fields().indexOf(_uf)
                    if _ui >= 0:
                        _req.setSubsetOfAttributes([_ui])
                for _pf in point_layer.getFeatures(_req):
                    _locked, _tp = self._is_point_feature_locked(_pf, locked_map, _uf)
                    if _locked and not self._admin_unlock_l1:
                        self.iface.messageBar().pushMessage(
                            "Score Blocked",
                            f"มีหมุดของแปลงประเภท {_tp} อยู่ในสิ่งที่เลือก — ไม่อนุญาตให้ตั้งค่า Score!",
                            level=2, duration=10)
                        return

        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return

        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            # ตรวจสอบว่าเลเยอร์อยู่ในโหมดแก้ไขหรือไม่
            if not lyr.isEditable():
                lyr.startEditing()
            
            # เริ่มบันทึกคำสั่งสำหรับ Undo
            lyr.beginEditCommand(f"Change Score to {value}")
            try:
                # ค้นหา index ของฟิลด์ Score
                idx = -1
                for i, field in enumerate(lyr.fields()):
                    if field.name().lower() == 'score':
                        idx = i
                        break
                
                if idx != -1:
                    # Optimize: วนลูปแก้เฉพาะค่า Attribute ผ่าน ID โดยตรงเพื่อความรวดเร็วและใช้แรมน้อย
                    for fid in lyr.selectedFeatureIds():
                        lyr.changeAttributeValue(fid, idx, value)
                    lyr.endEditCommand() # ปิดคำสั่ง (จะถูกส่งเข้า Undo Stack ของ QGIS)
                else:
                    lyr.destroyEditCommand()
                    self.iface.messageBar().pushMessage("Error", f"ไม่พบฟิลด์ Score ใน {lyr.name()}", level=2, duration=0)
            except Exception as e:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"Error Change Score: {e}", level=2, duration=0)

        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    # ข้อความหมายเหตุที่พนักงานใช้บ่อย — ดึงจากค่าจริงในฐานข้อมูล (ปทุม+องครักษ์ รวม ~2,950 แถว)
    # ★ ที่ทำเป็นรายการให้เลือก เพราะของเดิมพิมพ์มือแล้วความหมายเดียวกันเขียนได้หลายแบบ
    #   ("ซ้อน RTK / ทับ RTK / ทับซ้อนกับ RTK / แปลงทับ RTK / แปลงซ้ำ RTK") ทำให้สรุปยอดทีหลังไม่ได้
    REMARK_PRESETS = [
        "ซ้อน RTK",
        "ซ้อน L1",
        "เนื้อที่ผิด",
        "เนื้อที่เกินเกณฑ์",
        "ขึ้นรูปแปลงผิด",
        "หมุดไม่ครบ",
        "หมุดสลับตำแหน่ง",
        "แปลงพิพาท",
        "เป็น L1 แล้ว",
        "ไม่ได้ขึ้นรูปแปลงใบต่อ",
        "รอตรวจสอบ",
    ]

    def set_remark_value(self):
        """ใส่/แก้ "หมายเหตุ" (REMARK) ให้แปลงที่เลือก

        - เลือกจากรายการที่ใช้บ่อย หรือพิมพ์เองก็ได้ (ช่องแก้ไขได้)
        - ถ้าแปลงที่เลือกมีหมายเหตุเดิมเหมือนกันทั้งหมด จะเติมค่านั้นไว้ให้แก้ต่อ
        - เว้นว่าง = ลบหมายเหตุออก
        - เขียนเฉพาะ "ชั้นแปลง" (ชั้นหมุดไม่มีคอลัมน์ REMARK)
        """
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_layer:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน", level=2, duration=6)
            return
        fids = poly_layer.selectedFeatureIds()
        if not fids:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", "ยังไม่ได้เลือกแปลง — เลือกแปลงที่ต้องการใส่หมายเหตุก่อน", level=1, duration=6)
            return
        idx = self._field_index(poly_layer.fields(), "remark")
        if idx == -1:
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", f"ไม่พบคอลัมน์ REMARK ในเลเยอร์ {poly_layer.name()}", level=2, duration=8)
            return

        # ค่าเดิม: ถ้าทุกแปลงที่เลือกมีค่าเดียวกัน ให้เติมไว้ในช่อง (แก้ต่อได้เลย)
        cur = None
        try:
            req = (QgsFeatureRequest().setFilterFids(fids)
                   .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([idx]))
            vals = set()
            for ft in poly_layer.getFeatures(req):
                v = ft.attribute(idx)
                vals.add("" if v is None else str(v).strip())
                if len(vals) > 1:
                    break
            if len(vals) == 1:
                cur = vals.pop()
        except Exception:
            cur = None

        items = list(self.REMARK_PRESETS)
        if cur and cur not in items:
            items.insert(0, cur)
        try:
            start = items.index(cur) if cur in items else 0
        except Exception:
            start = 0
        txt, ok = QtWidgets.QInputDialog.getItem(
            self.iface.mainWindow(), "หมายเหตุ (REMARK)",
            f"ใส่หมายเหตุให้แปลงที่เลือก {len(fids):,} แปลง\n"
            "(เลือกจากรายการ หรือพิมพ์เอง • เว้นว่าง = ลบหมายเหตุ)",
            items, start, True)
        if not ok:
            return
        txt = (txt or "").strip()

        if not poly_layer.isEditable() and not poly_layer.startEditing():
            self.iface.messageBar().pushMessage(
                "หมายเหตุ", f"เปิดโหมดแก้ไข {poly_layer.name()} ไม่ได้ (สิทธิ์ไม่พอ?)", level=2, duration=8)
            return
        self.stored_selection = {poly_layer.id(): list(fids)}
        self._op_begin([poly_layer])
        poly_layer.beginEditCommand("Set REMARK")
        n = 0
        try:
            for fid in fids:
                if poly_layer.changeAttributeValue(fid, idx, txt if txt else None):
                    n += 1
            poly_layer.endEditCommand()
        except Exception as e:
            poly_layer.destroyEditCommand()
            self._op_commit()
            self.iface.messageBar().pushMessage("หมายเหตุ", f"ผิดพลาด: {e}", level=2, duration=0)
            return
        self._op_commit()
        self.iface.messageBar().pushMessage(
            "หมายเหตุ",
            (f"ลบหมายเหตุของ {n:,} แปลงแล้ว" if not txt else f"ใส่หมายเหตุ \"{txt}\" ให้ {n:,} แปลงแล้ว")
            + " • กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล", level=0, duration=8)
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def group_cluster_ids(self):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย cluster id จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        # ★ ด่าน L1 (2026-08-06): เดิมไม่มีเลย ทั้งที่ set_score_value ซึ่งใช้ selection ชุดเดียวกันมีด่าน
        #   -> cluster_id ของแปลงอ้างอิง (และหมุดของมัน) ถูกเขียนทับได้เงียบ ๆ
        #   ★ "ข้ามเฉพาะแปลง L1" ไม่ใช่ยกเลิกทั้งงาน (แก้ตาม release gate 2026-08-06):
        #     กลุ่มระวางส่วนใหญ่มีแปลง L1 ปนอยู่ด้วยเป็นปกติ ถ้ายกเลิกทั้งงานจะใช้ปุ่มนี้แทบไม่ได้เลย
        #     (ใช้แนวเดียวกับ Add Node ที่ข้ามแปลงล็อกแล้วทำแปลงที่เหลือต่อ)
        _skip_fids = set()
        _t_idx = self._field_index(poly_layer.fields(), 'type')
        if _t_idx != -1 and not self._admin_unlock_l1:
            _req_t = (QgsFeatureRequest().setFilterFids(poly_layer.selectedFeatureIds())
                      .setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([_t_idx]))
            for _f in poly_layer.getFeatures(_req_t):
                _v = _f.attribute(_t_idx)
                if _v is not None and str(_v).strip().upper() in ("L1-RTK", "L1-TS"):
                    _skip_fids.add(_f.id())
            if _skip_fids:
                self.iface.messageBar().pushMessage(
                    "Cluster", f"ข้ามแปลงอ้างอิง L1 จำนวน {len(_skip_fids)} แปลง (ไม่ตั้ง cluster_id ให้) "
                               "— แปลงที่เหลือตั้งค่าให้ตามปกติ", level=1, duration=8)
                if len(_skip_fids) >= poly_layer.selectedFeatureCount():
                    return                      # เลือกมาแต่แปลง L1 -> ไม่มีอะไรให้ทำ
        fields = [f.name() for f in poly_layer.fields()]
        target_field = next((f for f in fields if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
        if not target_field: return
        
        # Optimize: ดึงค่าเฉพาะ Attribute ฟิลด์แรกที่เลือกโดยไม่ต้องดึงพิกัดเพื่อประหยัดหน่วยความจำ
        _usable = [i for i in poly_layer.selectedFeatureIds() if i not in _skip_fids]
        if not _usable:
            return
        first_id = _usable[0]
        f_idx = poly_layer.fields().indexFromName(target_field)
        req = QgsFeatureRequest().setFilterFid(first_id).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([f_idx])
        first_feat = next(poly_layer.getFeatures(req), None)
        if not first_feat: return
        main_val = first_feat[target_field]

        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์ (เดิมไม่ track -> undo เพี้ยน)
        for lyr in layers:
            if not lyr.isEditable():
                lyr.startEditing()
            lyr.beginEditCommand("Group Cluster ID")
            try:
                lyr_f = [f.name() for f in lyr.fields()]
                lyr_t = next((f for f in lyr_f if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
                if lyr_t:
                    idx = lyr.fields().indexFromName(lyr_t)
                    # Optimize: แก้ไขเฉพาะค่า Attribute ผ่าน IDs โดยตรง
                    for fid in lyr.selectedFeatureIds():
                        if lyr.id() == poly_layer.id() and fid in _skip_fids:
                            continue          # แปลงอ้างอิง L1 -> ไม่แตะ
                        lyr.changeAttributeValue(fid, idx, main_val)
                lyr.endEditCommand()
            except Exception as e:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"Error Group Cluster ID: {e}", level=2, duration=0)
        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        """ล้างค่าหน้าจอและทำลายตัวช่วย Snap อย่างปลอดภัย"""
        if hasattr(self, 'snap_indicator') and self.snap_indicator:
            # ล้างสัญลักษณ์บนหน้าจอก่อนทำลาย Object
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            self.snap_indicator = None

        self.clear_rubber_band()
        self._preview_clear()
        self._dol_clear_highlight()
        self._align_picked_ids = set()
        self._align_clear_highlight()
        
        # รีเซ็ตเครื่องมือ Semi-Auto (ถ้ามี)
        if hasattr(self, 'temp_tool') and self.temp_tool:
            if hasattr(self.temp_tool, 'reset_tool'):
                try:
                    self.temp_tool.reset_tool()
                except Exception:
                    pass

        if hasattr(self, 'markers'):
            for m in self.markers:
                if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []
        self.src_pts = []

        # ล้าง feature ที่ถูกเลือกไว้ในทุกเลเยอร์ของ QGIS
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if isinstance(lyr, QgsVectorLayer) and lyr.selectedFeatureCount():
                    lyr.removeSelection()
            except Exception:
                pass

        self.iface.mapCanvas().refresh()
        self.iface.actionSelect().trigger()

    # ============ ระบบ Undo: นับ undo-command ต่อเลเยอร์ ต่อ operation ============
    def _watch_layer_editing(self, lyr):
        """ต่อ signal commit/rollback ของเลเยอร์ (ครั้งเดียวต่อเลเยอร์) เพื่อรู้ว่าตอนปิด edit
        กด Save (commit) หรือ Discard (rollback) — ใช้ตัดสินตอน undo เจอเลเยอร์ที่ถูกปิด"""
        if lyr is None:
            return
        lid = lyr.id()
        if lid in self._signal_layers:
            return
        self._signal_layers.add(lid)

        # cache ตาราง UTM ล็อก (_locked_utm_map) ล้างเฉพาะ on_fields (คอลัมน์เปลี่ยน) — ★ ไม่ล้างตอน commit/rollback/start
        #   (แก้ freeze ~1s หลังทุก Save · 2026-08-04): ชุดแปลงล็อก L1-RTK/L1-TS เปลี่ยนได้เฉพาะเมื่อคอลัมน์
        #   Type เปลี่ยน ซึ่งพนักงานแก้ไม่ได้ (GRANT เฉพาะ geom/SCORE/REMARK/cluster_id) -> cache ใช้ได้ทั้ง
        #   session · เดิมล้างทุก commit ทำให้ op ถัดไปดึงแปลง L1 ~90k ใหม่ = ค้าง ~1s หลัง Save ทุกครั้ง
        #   (วัดจริง execute_tool 925-997ms ครั้งแรก/หลัง Save -> 46-75ms เมื่อ cache ร้อน) · การสลับเลเยอร์
        #   จัดการด้วย lid-check ใน _locked_utm_map อยู่แล้ว ไม่ต้องพึ่ง signal นี้
        # ★ ทุก slot ต้องรับ *_a ทิ้ง: QGIS 3.32+ ส่ง argument มากับ beforeCommitChanges(bool)
        #   ถ้าไม่รับ PyQt จะยัดเป็น positional แรก -> ทับ default _lid (กลายเป็น True) -> guard พังเงียบ ๆ
        def on_commit(*_a, _lid=lid):
            self._edit_end[_lid] = 'commit'
            # นับ commit — commitChanges reset undo index เป็น 0 แล้วนับใหม่
            # เทียบ index อย่างเดียวมองไม่เห็นว่ามี Save แทรก (index อาจวนกลับมาเท่าเดิมพอดี)
            self._commit_seq[_lid] = self._commit_seq.get(_lid, 0) + 1
            # (ไม่ล้าง _locked_cache — ดูเหตุผลด้านบน)

        def on_rollback(*_a, _lid=lid):
            self._edit_end[_lid] = 'rollback'
            # (ไม่ล้าง _locked_cache — Type ไม่เปลี่ยนตอน rollback)

        def on_start(*_a, _lid=lid):
            self._edit_end.pop(_lid, None)   # เปิด edit ใหม่ -> ล้างสถานะเก่า
            # ★ ไม่ล้าง _locked_cache ที่นี่ (แก้ freeze ~1s หลังทุก Save · 2026-08-04):
            #   save_all_changes commit แล้วเรียก lyr.startEditing() ทันที (main.py ~2470) -> fire on_start
            #   ทุก Save · ถ้าล้าง cache ที่นี่ op ถัดไปจะดึงแปลง L1 ~90k ใหม่ = ค้าง ~1s (เท่ากับล้างตอน commit)
            #   · Type เปลี่ยนไม่ได้จากพนักงาน -> cache ใช้ต่อได้ · เหลือล้างเฉพาะ on_fields (โครงสร้างคอลัมน์เปลี่ยน)
            self._pending_pair_warn = None

        def on_fields(*_a, _lid=lid):
            # field ของเลเยอร์เปลี่ยน (เพิ่ม/ลบคอลัมน์) -> cache ชื่อ field / ตาราง lock ใช้ต่อไม่ได้
            self._field_cache = {k: v for k, v in self._field_cache.items() if k[0] != _lid}
            self._locked_cache = None

        # ---- เฝ้า "มุมแปลงไม่มีหมุด" ทุกช่องทางที่บันทึก ----
        # ปุ่ม Save ของปลั๊กอินถามก่อนบันทึกได้ (ยับยั้งได้จริง) แต่ Save Layer Edits /
        # ปิดโหมดแก้ไข ของ QGIS เอง ไม่ผ่านโค้ดเรา -> เดิมข้ามด่านไปทั้งหมด
        # QGIS ไม่มีกลไกให้ปลั๊กอิน "ยกเลิก" การ commit (beforeCommitChanges เป็น signal เปล่า
        # ยับยั้งไม่ได้ และไม่มี setAllowCommit) -> ทำได้ดีที่สุดคือ "ตรวจก่อน เตือนทันทีหลัง"
        def on_before_commit_check(*_a, _lid=lid):
            """ตรวจตอน buffer ยังอยู่ แต่ยังไม่เปิด dialog (ห้ามเด้ง UI ระหว่าง commit)"""
            self._pending_pair_warn = None
            try:
                if self._pair_warn_ack:
                    return                      # ปุ่มปลั๊กอินถามไปแล้ว ผู้ใช้ตอบ "บันทึกต่อ"
                poly = QgsProject.instance().mapLayer(self.poly_cb.currentData())
                point = QgsProject.instance().mapLayer(self.point_cb.currentData())
                # ★ รับ commit ของ "ชั้นหมุด" ด้วย — เดิมเช็คเฉพาะชั้นแปลง
                #   -> เซฟที่แก้แต่หมุด (ย้าย/ลบด้วยเครื่องมือ QGIS) ไม่ถูกตรวจเลย
                if _lid not in {l.id() for l in (poly, point) if l is not None}:
                    return                      # ไม่ใช่ชั้นทำงานที่เลือกอยู่ -> ไม่เกี่ยว
                iss = self._pairing_issues(poly, point)
                if iss and iss[0]:
                    self._pending_pair_warn = iss
            except Exception:
                pass                            # ตรวจไม่ได้ -> อย่าไปขวางการบันทึก

        def on_after_commit_warn(*_a, _lid=lid):
            """บันทึกไปแล้ว (ยับยั้งไม่ได้) -> เตือนทันทีพร้อมบอกวิธีแก้"""
            iss = self._pending_pair_warn
            self._pending_pair_warn = None
            if not iss:
                return
            try:
                bad, checked, sample = iss
                self.iface.messageBar().pushMessage(
                    "⚠️ มุมแปลงไม่มีหมุด",
                    f"บันทึกไปแล้ว {bad:,} มุม (จาก {checked:,} ที่ตรวจ) ไม่มีหมุดของแปลงเดียวกันทับอยู่ "
                    "— ดูรายละเอียดในหน้าต่างที่เด้งขึ้น", level=2, duration=0)
                lines = "\n".join("• " + s for s in sample)
                _txt = (f"บันทึกลงฐานข้อมูลเรียบร้อยแล้ว แต่ตรวจพบ {bad:,} มุม "
                        f"(จาก {checked:,} มุมที่ตรวจ) ที่ไม่มีหมุดของแปลงเดียวกันทับอยู่\n\n{lines}\n\n"
                        "สาเหตุที่พบบ่อยที่สุด:\n"
                        "• ใช้เครื่องมือ Vertex Tool / แก้รูปร่าง ของ QGIS เพิ่มมุมแปลงโดยตรง\n"
                        "  → เครื่องมือของ QGIS ไม่สร้างหมุดให้ ต้องใช้ปุ่ม \"➕ Add Node\" ของปลั๊กอินเท่านั้น\n"
                        "• กด Undo ของ QGIS (เมนู Edit / แถบเครื่องมือ) ซึ่งย้อนแค่ชั้นเดียว\n\n"
                        "วิธีแก้: ใช้ \"➕ Add Node\" เพิ่มหมุดที่มุมเหล่านั้น แล้วบันทึกอีกครั้ง")
                # ★ ห้ามเปิด modal "ระหว่าง" สัญญาณ afterCommitChanges (commitChanges ยังอยู่บน stack)
                #   -> เลื่อนออกไปหลัง event loop กลับมาว่าง + ใช้ _ask ให้กล่องขึ้นหน้าสุดเสมอ (2026-08-05)
                QtCore.QTimer.singleShot(0, lambda: self._ask(
                    QtWidgets.QMessageBox.Warning, "บันทึกแล้ว แต่พบมุมแปลงที่ไม่มีหมุด", _txt))
            except Exception:
                pass

        for sig_name, slot in (("beforeCommitChanges", on_before_commit_check),
                               ("afterCommitChanges", on_after_commit_warn)):
            sig = getattr(lyr, sig_name, None)
            if sig is None:
                continue
            try:
                sig.connect(slot)
                self._signal_conns.append((sig, slot))
            except Exception:
                pass

        # ต่อแยกทีละ signal (try ของใครของมัน) — ถ้าชื่อ signal ใดต่างใน QGIS บางรุ่น
        # ตัวที่เหลือยังทำงาน (อย่างน้อย degrade เป็น "บล็อกเมื่อเลเยอร์ปิด" ซึ่งปลอดภัย)
        # ★ ห้ามต่อ on_commit กับ beforeCommitChanges (2026-08-06): QGIS ยิง signal นั้น "ก่อน" เขียนจริง
        #   ยิงแม้การบันทึกจะล้มเหลวในภายหลัง -> _commit_seq เพิ่มทั้งที่ไม่ได้เซฟ = ระบบเข้าใจว่า
        #   "มี Save แทรกหลังงานนี้" แล้วบล็อกปุ่ม Undo ของปลั๊กอิน ทั้งที่ผู้ใช้ยิ่งต้องใช้ Undo ตอนนั้น
        #   (afterCommitChanges ยิงเฉพาะตอน commit สำเร็จจริง จึงเป็นตัวนับที่ถูกต้อง)
        for sig_name, slot in (("afterCommitChanges", on_commit),
                               ("afterRollBack", on_rollback),
                               ("beforeRollBack", on_rollback),
                               ("editingStarted", on_start),
                               ("updatedFields", on_fields)):
            sig = getattr(lyr, sig_name, None)
            if sig is None:
                continue
            try:
                sig.connect(slot)
                self._signal_conns.append((sig, slot))
            except Exception:
                pass

    def _op_begin(self, layers):
        """บันทึกตำแหน่ง undo-stack ปัจจุบันของแต่ละเลเยอร์ ก่อนเริ่ม operation (ไว้คำนวณ delta)
        + ต่อ signal ดักการปิด edit (Save/Discard) ของเลเยอร์เหล่านั้น"""
        baseline = {}
        for lyr in layers:
            if lyr is None:
                continue
            try:
                baseline[lyr.id()] = (lyr, lyr.undoStack().index())
                self._watch_layer_editing(lyr)
            except Exception:
                pass
        self._op_baseline = baseline

    def _op_commit(self):
        """ปิด operation: เลเยอร์ไหนถูก push undo-command เพิ่ม (delta>0) เก็บเป็น 1 รายการในประวัติ
        delta คำนวณจาก index ของ QUndoStack -> empty command (ไม่ถูก push) จะได้ delta=0 อัตโนมัติ"""
        base = self._op_baseline
        self._op_baseline = None
        if not base:
            return
        op = []
        for lyr, before in base.values():
            try:
                after = lyr.undoStack().index()
                delta = after - before
            except Exception:
                delta, after = 0, None
            if delta > 0:
                # เก็บ "ชื่อ" + "index ปลายทาง" ไว้ด้วย:
                #   ชื่อ  -> ใช้ในข้อความเมื่อเลเยอร์ถูกถอดออกจากโปรเจกต์แล้ว
                #            (เรียก .name() บน object ที่ C++ ลบไปแล้ว = RuntimeError)
                #   index -> ใช้ตรวจว่ามี edit อื่นแทรกหลัง operation หรือไม่ (ถ้ามี ห้ามย้อนแบบตาบอด)
                try:
                    _nm = lyr.name()
                except Exception:
                    _nm = "?"
                # seq = จำนวน commit ตอนจบ op (เปลี่ยน = มี Save แทรกหลัง op)
                # cmd = pointer ของ undo command บนสุด (เปลี่ยนทั้งที่ index เท่าเดิม =
                #        stack ถูก truncate แล้วแทนด้วยงานอื่น — undo k ครั้งแล้วแก้ใหม่ k งาน)
                _seq = self._commit_seq.get(lyr.id(), 0)
                _cmd = None
                try:
                    if after and after > 0:
                        from qgis.PyQt import sip as _sip
                        _c = lyr.undoStack().command(after - 1)
                        if _c is not None:
                            _cmd = _sip.unwrapinstance(_c)
                except Exception:
                    _cmd = None
                op.append((lyr, delta, _nm, after, _seq, _cmd))
        if op:
            self.op_history.append(op)
            if len(self.op_history) > 100:   # กันโตไม่จำกัด
                self.op_history.pop(0)
            self.last_layers = [e[0] for e in op]   # เผื่อโค้ดอื่นอ้างอิง

    def undo_transform(self):
        """ย้อน operation ล่าสุดของปลั๊กอิน — ย้อนแต่ละเลเยอร์ตามจำนวน step ที่มัน push จริง
        Guard: ถ้ามีเลเยอร์ในรายการถูกปิด edit ไปแล้ว (ประวัติหาย) จะแยกเคส
          • Save  -> บล็อก (popup เตือน) เพราะย้อนเลเยอร์เดียวจะทำให้ไม่ตรงกัน
          • Discard -> popup ถามว่าจะย้อนเลเยอร์ที่ยังเปิดอยู่กลับ "จุดเริ่มเปิดแก้ไข" ให้ตรงกันไหม"""
        if not self.op_history:
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการล่าสุดให้ย้อนกลับ", level=2, duration=10)
            return

        op = self.op_history[-1]   # ยังไม่ pop เผื่อบล็อก/ยกเลิก
        live, saved_gone, disc_gone, unknown_gone = [], [], [], []
        stale = []   # เลเยอร์ที่มี edit "อื่น" แทรกหลัง operation ของปลั๊กอิน
        for entry in op:
            lyr, n = entry[0], entry[1]
            nm  = entry[2] if len(entry) > 2 else None
            end = entry[3] if len(entry) > 3 else None
            seq = entry[4] if len(entry) > 4 else None
            cmd = entry[5] if len(entry) > 5 else None
            if lyr is None:
                continue
            try:
                if nm is None:
                    nm = lyr.name()
                if lyr.isEditable() and lyr.undoStack().canUndo():
                    # ★ 3 ด่านก่อนยอมย้อน (เดิมย้อน top-n แบบตาบอด):
                    # (1) มี Save แทรกหลัง op ไหม — commitChanges reset index เป็น 0 แล้วนับใหม่
                    #     index อาจกลับมาเท่า end พอดี -> ต้องเทียบตัวนับ commit ไม่ใช่ index
                    if seq is not None and self._commit_seq.get(lyr.id(), 0) != seq:
                        saved_gone.append(nm)      # op ถูกบันทึกลง DB ไปแล้ว ย้อนใน stack ไม่ได้
                        continue
                    cur = lyr.undoStack().index()
                    # (2) index ไม่ตรง = มีงานแทรก (บวก) หรือถูกย้อนไปแล้วด้วย QGIS (ลบ)
                    if end is not None and cur != end:
                        stale.append((nm, cur - end))
                        continue
                    # (3) index ตรง แต่ command บนสุดถูกแทนที่ (undo k ครั้ง + แก้ใหม่ k งาน
                    #     -> QUndoStack ตัดของเดิมทิ้งแล้วแทน index กลับมาเท่าเดิมพอดี)
                    if cmd is not None:
                        try:
                            from qgis.PyQt import sip as _sip
                            _c = lyr.undoStack().command(end - 1) if end and end > 0 else None
                            if _c is None or _sip.unwrapinstance(_c) != cmd:
                                stale.append((nm, 0))
                                continue
                        except Exception:
                            pass
                    live.append((lyr, n))          # ยังย้อนผ่าน stack ได้อย่างปลอดภัย
                else:
                    ev = self._edit_end.get(lyr.id())
                    if ev == 'rollback':
                        disc_gone.append(nm)       # ปิดแบบ Discard
                    elif ev == 'commit':
                        saved_gone.append(nm)      # ปิดแบบ Save
                    else:
                        unknown_gone.append(nm)    # ไม่รู้สถานะ -> กันไว้เหมือน Save
            except RuntimeError:
                # เลเยอร์ถูกถอดออกจากโปรเจกต์ไปแล้ว (C++ object ตาย) — เดิมตรงนี้ทำให้ Undo crash
                unknown_gone.append(nm or "เลเยอร์ที่ถูกถอดออกแล้ว")
            except Exception:
                unknown_gone.append(nm or "?")

        if stale:
            fwd = [(n, d) for n, d in stale if d >= 0]     # มีงานอื่นแทรก/แทนที่
            back = [(n, d) for n, d in stale if d < 0]     # ผู้ใช้ย้อนด้วย QGIS ไปแล้ว
            if fwd:
                _names = ", ".join(f"{n} (แทรก {d} ขั้น)" if d > 0 else f"{n} (งานถูกแทนที่)"
                                   for n, d in fwd)
                self._ask(
                    QtWidgets.QMessageBox.Warning, "ย้อนกลับไม่ได้",
                    f"มีการแก้ไขอื่นเกิดขึ้นหลังงานล่าสุดของปลั๊กอิน ({_names})\n\n"
                    "ถ้าย้อนตอนนี้จะไปย้อน 'งานอื่น' แทนงานของปลั๊กอิน และทำให้ชั้นแปลง/หมุดไม่ตรงกัน\n"
                    "ให้ใช้ Undo ของ QGIS (เมนู Edit → Undo) ย้อนงานล่าสุดออกก่อน แล้วกดปุ่มนี้อีกครั้ง")
            else:
                _names = ", ".join(f"{n} ({-d} ขั้น)" for n, d in back)
                self._ask(
                    QtWidgets.QMessageBox.Information, "ย้อนไปแล้วด้วย QGIS",
                    f"งานล่าสุดของปลั๊กอินถูกย้อนด้วย Undo ของ QGIS ไปแล้วบางส่วน ({_names})\n\n"
                    "ใช้ Edit → Undo/Redo ของ QGIS จัดการส่วนที่เหลือ\n"
                    "หรือกด Redo กลับมาให้ครบก่อน แล้วค่อยใช้ Undo ของปลั๊กอิน")
            return

        # ---- เคสปกติ: ทุกเลเยอร์ยังเปิดอยู่ -> ย้อนตาม step ----
        if not (saved_gone or disc_gone or unknown_gone):
            self.op_history.pop()
            for lyr, n in live:
                stack = lyr.undoStack()
                for _ in range(n):
                    if not stack.canUndo():
                        break
                    stack.undo()
            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดเรียบร้อยแล้ว", level=1, duration=8)
            return

        # ---- มีเลเยอร์ปิด+Save (หรือไม่รู้สถานะ) -> บล็อก (popup เตือน) ----
        if saved_gone or unknown_gone:
            names = ", ".join(saved_gone + unknown_gone)
            self._ask(
                QtWidgets.QMessageBox.Warning, "ย้อนกลับไม่ได้",
                f"เลเยอร์ '{names}' ถูกปิดแก้ไข/บันทึกไปแล้ว — ประวัติ undo หายไป\n\n"
                "ย้อนอัตโนมัติไม่ได้ เพราะจะทำให้ 2 เลเยอร์ไม่ตรงกัน\n"
                "ให้เปิด Toggle Editing ของเลเยอร์นั้นก่อน แล้วแก้ด้วยตนเอง")
            return   # ไม่ pop ไม่ย้อนอะไร

        # ---- เลเยอร์ที่หายเป็น Discard ทั้งหมด ----
        disc_names = ", ".join(disc_gone)
        if not live:
            # ทั้ง op เป็น Discard -> ทุกเลเยอร์กลับจุดเริ่มอยู่แล้ว ไม่ต้องทำอะไร
            self.op_history.pop()
            self.iface.messageBar().pushMessage(
                "Undo", f"เลเยอร์ '{disc_names}' ถูกปิดแบบไม่เซฟ — ข้อมูลกลับจุดเริ่มแล้ว ไม่ต้องย้อนเพิ่ม",
                level=1, duration=10)
            return

        # มีทั้ง Discard และเลเยอร์ที่ยังเปิด -> ถามว่าจะย้อนเลเยอร์ที่เปิดกลับจุดเริ่มให้ตรงกันไหม
        live_names = ", ".join(l.name() for l, _ in live)
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "เลเยอร์ถูกปิดแบบไม่เซฟ",
            f"เลเยอร์ '{disc_names}' ถูกปิดแก้ไขแบบไม่บันทึก → ข้อมูลกลับไป "
            "'จุดเริ่มเปิดแก้ไข' แล้ว (ไม่ใช่แค่ครั้งล่าสุด)\n\n"
            f"ต้องการย้อนเลเยอร์ที่ยังเปิดอยู่ ('{live_names}') กลับไปจุดเริ่มด้วย "
            "เพื่อให้ทั้งสองตรงกันไหม?\n"
            "⚠️ งานทั้งหมดที่ทำไว้ในเลเยอร์นี้ (ตั้งแต่เปิดแก้ไข) จะถูกย้อนทิ้ง",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No)
        if ans == QtWidgets.QMessageBox.Yes:
            for lyr, _n in live:
                stack = lyr.undoStack()
                while stack.canUndo():      # ย้อนสุด -> จุดเริ่ม session
                    stack.undo()
            self.op_history.clear()          # ทุกอย่างถูกย้อนหมดแล้ว
            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage(
                "Undo", "ย้อนทั้งสองเลเยอร์กลับจุดเริ่มเปิดแก้ไขแล้ว", level=1, duration=8)
        # No -> ไม่ทำอะไร (คงสถานะไว้)

    def _tool_layers_ok(self, tool_poly, title):
        """ยืนยันว่า "เลเยอร์ตอนกดเครื่องมือ" กับ "เลเยอร์ในคอมโบตอนนี้" ยังเป็นตัวเดียวกัน

        ★ 2026-08-06: เครื่องมือ node (แก้ชื่อ/ลบ node/Add Node) ส่ง fid + พิกัดที่คิดจาก "เลเยอร์ตอน arm"
          แต่ตัว execute กลับไปอ่านเลเยอร์จากคอมโบใหม่ · ถ้าผู้ใช้สลับคอมโบระหว่างกดปุ่มกับคลิก
          = เอา fid/พิกัดของชั้นหนึ่งไปเขียนอีกชั้น (คนละ CRS ก็เป็นไปได้) -> ข้อมูลพังเงียบ ๆ
          คืน (poly, point) ถ้าตรงกัน · None ถ้าไม่ตรง (แจ้งให้กดปุ่มใหม่)"""
        poly = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if poly is None or point is None:
            self.iface.messageBar().pushMessage(
                title, "ยังไม่ได้เลือกชั้นแปลง/ชั้นหมุดให้ครบ", level=2, duration=6)
            return None
        tool_point = getattr(getattr(self, "temp_tool", None), "point_lyr", None)
        if (tool_poly is not None and tool_poly.id() != poly.id()) or \
           (tool_point is not None and tool_point.id() != point.id()):
            self.iface.messageBar().pushMessage(
                title, "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดเครื่องมือ — ยกเลิกเพื่อกันแก้ผิดชั้น "
                       "(กดปุ่มเครื่องมือใหม่อีกครั้ง)", level=2, duration=8)
            return None
        return poly, point

    # ============ กล่องข้อความที่ "มองเห็นแน่นอน" ============
    def _ask(self, icon, title, text, buttons=None, default=None):
        """เปิด QMessageBox โดยผูก parent กับ "หน้าต่างหลักของ QGIS" แล้วบังคับยกขึ้นหน้าสุด

        🔴 เหตุการณ์จริง 2026-08-05 ~19:03 (พนักงาน saranya): กดบันทึกหลังแก้งานสะสม ~20 นาที
           แล้วโปรแกรม "ค้าง" จนต้อง kill ทิ้ง — งานทั้ง 20 นาทีหาย (ฐานข้อมูลไม่ได้รับสักแถว)
           ต้นเหตุ: กล่องยืนยัน "พบมุมแปลงที่ไม่มีหมุด" ผูก parent ไว้กับ self.dlg (หน้าต่างปลั๊กอิน)
           ซึ่งอาจถูกย่อ/ถูกบังอยู่หลังหน้าต่างหลัก · กล่องนี้เป็น application-modal = บล็อกทั้ง QGIS
           ผู้ใช้จึงเห็นเป็น "โปรแกรมค้าง" ทั้งที่จริงระบบกำลังรอคำตอบจากกล่องที่มองไม่เห็น
           (บันทึกยืนยัน: 18:31-18:41 บันทึกทีละน้อยผ่านฉลุย เพราะไม่มีมุมขาดหมุด = กล่องไม่เด้ง)
        ⇒ ทุกกล่องที่อยู่ "เส้นทางบันทึก" และกล่องยืนยันสิ่งที่ทำลายข้อมูล ต้องผ่านฟังก์ชันนี้เท่านั้น
        """
        if buttons is None:
            # ★ ให้ default ตรงกับ static API เดิม (2026-08-06): QMessageBox.question() ดีฟอลต์ Yes|No
            #   ถ้าปล่อยเป็น Ok กล่องคำถามจะมีปุ่มเดียว แล้วโค้ดที่เทียบ `!= Yes` จะเป็นจริงเสมอ
            #   (เกือบทำ self-update ตายถาวรทั้งกรม — จับได้ตอน release gate)
            buttons = (QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
                       if icon == QtWidgets.QMessageBox.Question else QtWidgets.QMessageBox.Ok)
        parent = None
        try:
            parent = self.iface.mainWindow()
        except Exception:
            parent = None
        box = QtWidgets.QMessageBox(icon, title, text, buttons, parent)
        if default is not None:
            box.setDefaultButton(default)
        try:
            box.setWindowModality(QtCore.Qt.ApplicationModal)
            box.show()
            box.raise_()               # ยกขึ้นเหนือหน้าต่างอื่น
            box.activateWindow()       # และให้โฟกัส (กันไปโผล่หลังจอ)
            # ยกซ้ำอีกครั้งหลัง event loop map หน้าต่างจริง — บาง window manager กิน raise แรก
            # (กล่องเป็น sibling ของหน้าต่างปลั๊กอินแล้ว ไม่ใช่ลูก จึงต้องยกเองให้แน่)
            QtCore.QTimer.singleShot(0, lambda: (box.raise_(), box.activateWindow()))
        except Exception:
            pass
        return box.exec_()

    def _pairing_issues(self, poly_lyr, point_lyr, cap=2000):
        """ตรวจกติกาเหล็ก "ทุก node ต้องมีหมุดของแปลงเดียวกันทับ" เฉพาะแปลงที่ค้างอยู่ใน edit buffer
        (ยังไม่ commit) -> คืน (n_bad, n_checked, ตัวอย่าง) หรือ None ถ้าตรวจไม่ได้/ข้าม.

        ตรวจ "ผลลัพธ์" ไม่ใช่ "สาเหตุ" จึงดักได้ทุกทางที่ทำแปลงกับหมุดหลุดคู่กัน:
          • กด Ctrl+Z ของ QGIS (undo แค่เลเยอร์ที่ active -> อีกชั้นยังค้างใน buffer)
          • Align ดึงมุมแปลงข้างเคียงตามเส้น แต่หมุดของแปลงนั้นไม่ได้ถูกเลือกให้ย้ายด้วย
          • เพิ่ม node แล้วหมุดใหม่เข้าไม่ได้ (เช่นสิทธิ์ INSERT ไม่พอ)
          • ใช้เครื่องมือแก้ไขของ QGIS ตรงๆ โดยไม่ผ่านปลั๊กอิน
        คิวรีเดียว (ดึงหมุดของ UTM ที่เกี่ยวทั้งชุด) แล้วเทียบในหน่วยความจำ -> ไม่ยิง DB ต่อแปลง

        ★ มีเพดานเวลา `budget` วินาที (2026-08-05): ด่านนี้เป็นแค่ "ตัวเตือน" ห้ามมีทางทำให้บันทึกค้าง
          เกินเวลา -> คืน None = ข้ามการเตือน แล้วปล่อยให้บันทึกเดินต่อ (ไม่ได้ทำข้อมูลเสีย)"""
        _t0 = time.monotonic()
        budget = float(getattr(self, "_pairing_budget_s", 8.0))
        try:
            if not poly_lyr or not point_lyr:
                return None
            # ★ รองรับ "แก้ชั้นหมุดอย่างเดียว" ด้วย — เดิมบังคับว่าชั้นแปลงต้องเปิดแก้ไข
            #   -> ย้าย/ลบหมุดด้วยเครื่องมือ QGIS โดยไม่แตะแปลง = ตรวจไม่ได้เลย
            if not (poly_lyr.isEditable() or point_lyr.isEditable()):
                return None
            buf = poly_lyr.editBuffer() if poly_lyr.isEditable() else None
            fids = (set(buf.changedGeometries().keys()) | set(buf.addedFeatures().keys())) if buf is not None else set()
            if len(fids) > cap:
                return None                      # แก้เยอะเกิน -> ข้าม (กันหน่วงตอน Save)
            pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
            tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
            if not pu or not tu:
                return None
            polys = {}
            if fids:
                for f in poly_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(fids))):
                    u = f[pu]
                    if u is None:
                        continue
                    polys[f.id()] = (_norm_utm(u), f.geometry())
            # ★ การแก้ฝั่ง "ชั้นหมุด" (ย้าย/เพิ่ม/ลบ) -> ดึงแปลงของ UTM ที่หมุดถูกแตะมาตรวจด้วย
            touched_mk = []                  # [(utm, x, y)] หมุดที่ผู้ใช้ เพิ่ม/ย้าย ในรอบนี้
            try:
                pbuf = point_lyr.editBuffer() if point_lyr.isEditable() else None
                if pbuf is not None:
                    extra = set()
                    ch = set(pbuf.changedGeometries().keys()) | set(pbuf.addedFeatures().keys())
                    if ch and len(ch) <= cap:
                        for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(ch))):
                            u = f[tu]
                            if u is not None:
                                extra.add(_norm_utm(u))
                                # ★ เก็บไว้ตรวจ "หมุดลอย" เฉพาะหมุดที่ผู้ใช้เพิ่ง เพิ่ม/ย้าย ในรอบนี้
                                #   (ไม่ตรวจหมุดเก่าทั้งชั้น — หมุดเสียที่ติดมากับข้อมูลเดิมไม่ใช่
                                #    ความผิดของการบันทึกครั้งนี้ ถ้าเตือนด้วยจะกลายเป็น noise
                                #    จนพนักงานกด "บันทึกต่อ" ทิ้งโดยไม่อ่าน)
                                try:
                                    _g = f.geometry()
                                    if _g is not None and not _g.isEmpty():
                                        _p = _g.asPoint()
                                        touched_mk.append((_norm_utm(u),
                                                           round(_p.x(), 3), round(_p.y(), 3)))
                                except Exception:
                                    pass
                    dels = list(pbuf.deletedFeatureIds())
                    if dels and len(dels) <= cap:
                        # หมุดที่ถูกลบหายจาก layer แล้ว -> อ่านค่า UTM เดิมจาก provider
                        for f in point_lyr.dataProvider().getFeatures(QgsFeatureRequest().setFilterFids(dels)):
                            u = f[tu]
                            if u is not None:
                                extra.add(_norm_utm(u))
                    extra -= {u for u, _g in polys.values()}
                    if extra and len(extra) + len(polys) <= cap:
                        qs0 = ",".join(QgsExpression.quotedValue(u) for u in extra)
                        e0 = f"{QgsExpression.quotedColumnRef(pu)} IN ({qs0})"
                        for f in poly_lyr.getFeatures(QgsFeatureRequest().setFilterExpression(e0)):
                            if f.id() not in polys:
                                u = f[pu]
                                if u is not None:
                                    polys[f.id()] = (_norm_utm(u), f.geometry())
                            if len(polys) > cap:
                                break
            except Exception:
                pass
            if not polys:
                return None
            utms = {u for u, _g in polys.values()}
            qs = ",".join(QgsExpression.quotedValue(u) for u in utms)
            expr = f"{QgsExpression.quotedColumnRef(tu)} IN ({qs})"
            # ★ จำกัดด้วยกรอบพื้นที่ของแปลงที่กำลังแก้ ก่อนกรองด้วย UTM
            #   คอลัมน์ UTM ไม่มี index -> WHERE "UTM" IN (...) เป็น seq scan ทั้งตาราง
            #   (วัดจริงบน Pathum_POINT 1.18 ล้านจุด: 27,204 buffers / 63-155 ms ต่อการกด Save 1 ครั้ง)
            #   ใส่ bbox ด้วย -> PostGIS ใช้ GiST index ที่มีอยู่แล้ว: 1,227 buffers / 4 ms
            #   วัดผ่าน QGIS จริง 157.5 -> 6.3 ms = เร็วขึ้น 25 เท่า และได้ผลลัพธ์เท่าเดิมทุกจุด
            #   ปลอดภัย: หมุดที่เราสนใจคือหมุดที่ทับ "มุมของแปลงที่แก้" ซึ่งอยู่ในกรอบแปลงเสมอ
            #   หมุด UTM เดียวกันที่อยู่นอกกรอบ ไม่มีทางทับมุมแปลงนั้นได้ -> ตัดทิ้งไม่กระทบคำตอบ
            #   ต้องใช้คู่กับ expression เสมอ (bbox อย่างเดียวจะกวาดหมุดแปลงอื่นมาด้วย)
            req = QgsFeatureRequest().setFilterExpression(expr)
            try:
                bbox = QgsRectangle()
                for _f, (_u, _g) in polys.items():
                    if _g is not None and not _g.isNull() and not _g.isEmpty():
                        bbox.combineExtentWith(_g.boundingBox())
                # ★ ใช้ bbox เฉพาะตอนที่กรอบ "แคบพอ" เท่านั้น
                #   ถ้าแปลงที่แก้กระจายทั่วอำเภอ กรอบจะกว้างจน GiST คัดอะไรแทบไม่ได้ แล้วกลับช้ากว่าเดิม
                #   (วัดจริง: กรอบ 19 กม. -> 220 ms เทียบกับไม่ใช้ bbox 78 ms = แย่ลง 2.8 เท่า)
                #   ข้อมูลการบันทึกจริง 422 ครั้ง: กรอบเฉลี่ย 163 ม. / p95 625 ม. / สูงสุด 1,358 ม.
                #   -> เกณฑ์ 5 กม. เผื่อไว้เกือบ 4 เท่าของเคสแย่สุดที่เคยเกิดจริง
                if not bbox.isNull() and max(bbox.width(), bbox.height()) <= 5000.0:
                    bbox.grow(1.0)               # เผื่อ 1 เมตร กันปัดเศษที่ขอบกรอบ
                    req.setFilterRect(bbox)
            except Exception:
                pass                             # หา bbox ไม่ได้ -> ใช้ expression อย่างเดียวเหมือนเดิม
            mk = {}                              # {utm: {(x,y) ปัดมิลลิเมตร}} — สถานะรวม buffer ที่ยังไม่ commit
            _n = 0
            for f in point_lyr.getFeatures(req):
                _n += 1
                if (_n & 1023) == 0 and time.monotonic() - _t0 > budget:
                    return None                  # เกินเพดานเวลา -> ข้ามการเตือน อย่าขวางการบันทึก
                u = f[tu]; g = f.geometry()
                if u is None or g is None or g.isEmpty():
                    continue
                p = g.asPoint()
                mk.setdefault(_norm_utm(u), set()).add((round(p.x(), 3), round(p.y(), 3)))
            bad = 0; checked = 0; sample = []
            vtx = {}                             # utm -> set((x,y)) ของมุมแปลงที่กำลังจะบันทึก
            for _fid, (u, g) in polys.items():
                if g is None or g.isNull():
                    continue
                if time.monotonic() - _t0 > budget:
                    return None                  # เกินเพดานเวลา -> ข้ามการเตือน
                S = mk.get(u, set())
                V = vtx.setdefault(u, set())
                for v in g.vertices():
                    checked += 1
                    _k = (round(v.x(), 3), round(v.y(), 3))
                    V.add(_k)
                    if _k not in S:
                        bad += 1
                        if len(sample) < 5:
                            sample.append(f"ระวาง/UTM {u} ที่ {v.x():.2f}, {v.y():.2f}")
            # ★ ตรวจอีกด้านของกติกาเหล็ก (2026-08-06): "หมุดต้องอยู่บนมุมแปลงของตัวเอง"
            #   เดิมตรวจทางเดียว (มุม->หมุด) จึงมองไม่เห็น "หมุดลอย" ที่ผู้ใช้เพิ่ง เพิ่ม/ย้าย ผิดที่
            #   ★ ตรวจเฉพาะหมุดที่แตะรอบนี้ (ไม่ใช่ทั้งชั้น) เพื่อไม่ให้ข้อมูลเก่าที่เสียอยู่แล้ว
            #     มาทำให้กล่องเตือนเด้งทุกครั้งจนคนเลิกอ่าน · ใช้ข้อมูลในหน่วยความจำ ไม่มีคิวรีเพิ่ม
            for (u, mx, my) in touched_mk:
                V = vtx.get(u)
                if V is None:
                    continue                     # แปลงของหมุดนี้ไม่ได้อยู่ในชุดที่ตรวจ -> ข้าม
                if (mx, my) not in V:
                    bad += 1
                    if len(sample) < 5:
                        sample.append(f"หมุดที่เพิ่งแก้ไม่ทับมุมแปลง — ระวาง/UTM {u} ที่ {mx:.2f}, {my:.2f}")
            return bad, checked, sample
        except Exception:
            return None                          # ตรวจไม่ได้ -> อย่าไปขวางการบันทึก

    def save_all_changes(self):
        """commit ทั้งสองเลเยอร์ — เช็คผลจริงจาก provider (บน PostgreSQL commit ล้มเหลวได้:
        สิทธิ์ไม่พอ / constraint / connection หลุด) เดิมไม่เช็คเลยขึ้น 'สำเร็จ' เสมอ
        + ก่อน commit เตือนถ้าสิ่งที่จะบันทึกมี node ที่ไม่มีหมุดคู่ (ดู _pairing_issues)"""
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        # ★ ระหว่างตรวจกติกาเหล็ก อาจใช้เวลาสักครู่บนงานก้อนใหญ่ -> ขึ้น cursor นาฬิกาทราย
        #   ให้เห็นว่า "กำลังทำงาน" ไม่ใช่ "ค้าง" (2026-08-05)
        try:
            QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
            iss = self._pairing_issues(poly_lyr, point_lyr)
        finally:
            try:
                QtWidgets.QApplication.restoreOverrideCursor()
            except Exception:
                pass
        if iss and iss[0]:
            bad, checked, sample = iss
            lines = "\n".join("• " + s for s in sample)
            # ★ ใช้ _ask (parent = หน้าต่างหลัก + ยกขึ้นหน้าสุด) — เดิมผูกกับ self.dlg
            #   แล้วกล่องไปโผล่หลังจอ = ผู้ใช้เห็นเป็นโปรแกรมค้าง (เหตุ 19:03 น. 5 ส.ค. 69)
            ans = self._ask(
                QtWidgets.QMessageBox.Question, "ตรวจพบมุมแปลงที่ไม่มีหมุด",
                f"ในงานที่กำลังจะบันทึก พบ {bad:,} มุม (จาก {checked:,} มุมที่ตรวจ) "
                f"ที่ไม่มีหมุดของแปลงเดียวกันทับอยู่\n\n{lines}\n\n"
                "สาเหตุที่พบบ่อย:\n"
                "• กด Ctrl+Z ของ QGIS (ย้อนแค่ชั้นที่เลือกอยู่ อีกชั้นไม่ย้อนตาม) — ใช้ปุ่ม Undo ของปลั๊กอินแทน\n"
                "• Align ดึงมุมแปลงข้างเคียงไปตามเส้น แต่หมุดของแปลงนั้นไม่ได้ถูกเลือกให้ย้ายด้วย\n"
                "• เพิ่ม node แล้วหมุดใหม่เข้าไม่สำเร็จ\n\n"
                "ยังต้องการบันทึกต่อหรือไม่?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if ans != QtWidgets.QMessageBox.Yes:
                return
        failed = []   # [(ชื่อเลเยอร์, ข้อความ error)]
        saved = []    # ชื่อเลเยอร์ที่ "ลงฐานข้อมูลจริงแล้ว" (ย้อนกลับไม่ได้)
        # ปุ่มนี้ตรวจ+ถามไปแล้ว -> กัน hook beforeCommitChanges เตือนซ้ำ (reset เสมอใน finally)
        self._pair_warn_ack = True
        try:
            for lyr in [poly_lyr, point_lyr]:
                if lyr and lyr.isEditable():
                    # ★ นับเป็น "ลง DB จริง (ย้อนไม่ได้)" เฉพาะเลเยอร์ที่มีการแก้ค้างอยู่จริง
                    #   (commit เลเยอร์ที่ไม่มีอะไรแก้ = no-op สำเร็จเสมอ — ไม่ควรไปโผล่ใน
                    #    dialog "บันทึกบางส่วน" ให้คนตกใจ + ลบประวัติ undo ฟรี)
                    try:
                        had_changes = lyr.isModified()
                    except Exception:
                        had_changes = True          # ไม่รู้ = ถือว่ามี (ระวังไว้ก่อน)
                    if lyr.commitChanges():
                        if had_changes:
                            saved.append(lyr.name())
                        lyr.startEditing()
                    else:
                        failed.append((lyr.name(), "\n".join(lyr.commitErrors())))
                        # ★ หยุดทันที — อย่า commit เลเยอร์ถัดไป (2026-08-05)
                        #   ตอนตัวแรกล้ม ยังไม่มีอะไรลง DB เลย -> หยุด = ทั้งคู่ยังอยู่ใน buffer
                        #   ปลอดภัย ("ไม่มีอะไรเซฟ ลองใหม่") · เดิมไหลไป commit ตัวที่สอง =
                        #   สร้าง desync ถาวรที่หลีกเลี่ยงได้ (หมุดลงแต่แปลงไม่ลง)
                        break
        finally:
            self._pair_warn_ack = False
        if failed:
            names = ", ".join(n for n, _ in failed)
            detail = "\n\n".join(f"• {n}:\n{e}" for n, e in failed)
            if saved:
                # ★ บันทึกสำเร็จ "ครึ่งเดียว" (2026-08-04): QGIS commit ทีละเลเยอร์ ไม่มี transaction ร่วม
                #   ⇒ ย้อนเลเยอร์ที่ลงไปแล้วอัตโนมัติไม่ได้ · เดิมข้อความบอกว่า "ข้อมูลยังไม่ถูกเซฟ" ทุกกรณี
                #   = หลอก เพราะอีกเลเยอร์ลง DB ถาวรไปแล้ว ⇒ แปลงกับหมุดไม่ตรงกันโดยไม่มีใครรู้
                #   undo ของเลเยอร์ที่ commit ไปแล้วถูก QGIS ล้าง ⇒ ประวัติ undo ใช้ต่อไม่ได้ ต้องเคลียร์
                self.op_history.clear()
                self._op_baseline = None
                self._ask(
                    QtWidgets.QMessageBox.Critical, "⚠️ บันทึกสำเร็จเพียงบางส่วน",
                    f"✅ ลงฐานข้อมูลแล้ว (ย้อนไม่ได้): {', '.join(saved)}\n"
                    f"❌ บันทึกไม่สำเร็จ: {names}\n\n"
                    f"ตอนนี้ข้อมูล 'แปลง' กับ 'หมุด' ในฐานข้อมูลอาจไม่ตรงกัน\n"
                    f"• งานของเลเยอร์ที่ล้มยังอยู่ใน edit buffer — กด 💾 บันทึก อีกครั้ง\n"
                    f"• ถ้ายังไม่สำเร็จ ให้แจ้งผู้ดูแลทันที และ **อย่ากด Discard / อย่าปิดโปรแกรม**\n"
                    f"  (ถ้าปิด งานส่วนที่ยังไม่ลงจะหาย และข้อมูลจะไม่ตรงกันถาวร)\n\n{detail}")
            else:
                # ไม่มีเลเยอร์ไหนลงเลย -> buffer ครบทั้งคู่ ปลอดภัย ไม่ต้องเคลียร์ประวัติ undo
                self._ask(
                    QtWidgets.QMessageBox.Critical, "บันทึกไม่สำเร็จ",
                    f"เลเยอร์ '{names}' บันทึกลงฐานข้อมูลไม่สำเร็จ — ข้อมูลยังไม่ถูกเซฟ!\n"
                    f"งานที่แก้ไว้ยังอยู่ใน edit buffer (ยังไม่หาย)\n\n{detail}")
            return
        if not saved:
            # ไม่มีเลเยอร์ไหนถูก commit จริง (ไม่ได้อยู่ในโหมดแก้ไข / ไม่มีการแก้ค้าง)
            # -> อย่ารายงานว่า "บันทึกสำเร็จ" และอย่าล้างประวัติ undo (2026-08-05)
            self.iface.messageBar().pushMessage(
                "Save", "ไม่มีการแก้ไขค้างอยู่ — ไม่มีอะไรต้องบันทึก", level=0, duration=4)
            return
        # commitChanges ล้าง undo-stack ของ QGIS -> ประวัติเก่าย้อนไม่ได้แล้ว เคลียร์ทิ้ง
        self.op_history.clear()
        self._op_baseline = None
        self._unsaved_since = None      # บันทึกแล้ว -> เริ่มนับเวลางานค้างใหม่
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3, duration=3)

    def _auto_check_update(self):
        """เช็คเวอร์ชันใหม่ให้อัตโนมัติ — ครั้งเดียวต่อการเปิด QGIS
        เงียบสนิทถ้าเป็นเวอร์ชันล่าสุดอยู่แล้ว หรือเน็ตไม่ถึง (ไม่มี dialog/progress ใด ๆ)
        เจอของใหม่เท่านั้นถึงจะถามว่าจะอัปเดตไหม
        (เดิมต้องกดปุ่ม 🚀 Check Update เอง -> ของใหม่ไม่ถึงพนักงานจนกว่าจะมีคนไล่บอกทีละคน)"""
        if getattr(self, "_auto_upd_done", False):
            return
        self._auto_upd_done = True

        def _check():
            res = requests.get(UPDATE_V_URL, timeout=8)
            res.raise_for_status()
            return res.text.strip()

        w = _FnWorker(_check)
        if not hasattr(self, "_net_workers"):
            self._net_workers = []
        self._net_workers.append(w)      # กัน GC เก็บ worker ระหว่างรัน

        def _cleanup():
            try:
                self._net_workers.remove(w)
            except ValueError:
                pass
            w.deleteLater()

        def _ok(new_version):
            _cleanup()
            try:
                if _vkey(new_version) > _vkey(self.version):
                    self.prompt_update(new_version, UPDATE_Z_URL)
            except Exception:
                pass

        w.done.connect(_ok)
        w.fail.connect(lambda _e: _cleanup())    # เน็ตไม่ถึง/GitHub ล่ม = เงียบ ไม่กวนผู้ใช้
        w.start()

    def update_plugin(self):
        """เช็คเวอร์ชันใหม่จาก GitHub — ทำใน thread แยก (เดิม block UI บน main thread)"""
        V_URL = UPDATE_V_URL
        Z_URL = UPDATE_Z_URL

        def _check():
            res = requests.get(V_URL, timeout=8)
            res.raise_for_status()
            return res.text.strip()

        def _got(new_version):
            if _vkey(new_version) > _vkey(self.version):
                self.prompt_update(new_version, Z_URL)
            else:
                self._ask(
                    QtWidgets.QMessageBox.Information, "Update", f"คุณใช้เวอร์ชันล่าสุดแล้ว (v{self.version})")

        def _err(e):
            self._ask(QtWidgets.QMessageBox.Warning, "Update Error", f"ไม่สามารถตรวจสอบอัปเดตได้:\n{e}")

        self._run_net("กำลังตรวจสอบเวอร์ชันใหม่...", _check, _got, _err)

    def prompt_update(self, new_version, download_url):
        if self._ask(
                QtWidgets.QMessageBox.Question, "Update",
                f"พบเวอร์ชันใหม่ {new_version} ต้องการอัปเดตไหม?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                QtWidgets.QMessageBox.No) != QtWidgets.QMessageBox.Yes:
            return

        def _download():
            """โหลด -> ตรวจของในซิปก่อน -> แตกลง temp -> สลับทับของเดิม (มีสำเนาเดิมไว้กู้)
            เดิม: extractall ทับของจริงสด ๆ โดยไม่ตรวจอะไรเลย ->
              (ก) วันไหนอัปซิปผิดตัว จะ downgrade ทั้งกรมโดยไม่มีอะไรดัก
              (ข) เน็ตหลุดกลางคัน = ปลั๊กอินเหลือครึ่ง ๆ กู้เองไม่ได้"""
            here = os.path.dirname(__file__)                 # .../plugins/Multi_Layer_Edit_Pro
            plugins_dir = os.path.dirname(here)
            name = os.path.basename(here)

            r = requests.get(download_url, timeout=120)
            r.raise_for_status()
            z = zipfile.ZipFile(io.BytesIO(r.content))       # ซิปเสีย -> โยน error ตั้งแต่ตรงนี้
            bad = z.testzip()
            if bad:
                raise RuntimeError(f"ไฟล์ในซิปเสีย: {bad}")

            # ---- ตรวจว่าซิปเป็นเวอร์ชันที่โฆษณาไว้จริง ----
            meta_path = f"{name}/metadata.txt"
            if meta_path not in z.namelist():
                raise RuntimeError(f"ซิปไม่มี {meta_path} — โครงไฟล์ไม่ถูกต้อง")
            zver = ""
            for line in z.read(meta_path).decode("utf-8", "replace").splitlines():
                if line.strip().startswith("version="):
                    zver = line.split("=", 1)[1].strip()
                    break
            if _vkey(zver) != _vkey(new_version):
                raise RuntimeError(
                    f"ซิปเป็นเวอร์ชัน {zver} แต่ประกาศไว้ว่า {new_version} — ยกเลิกการติดตั้ง")
            if _vkey(zver) <= _vkey(self.version):
                raise RuntimeError(
                    f"ซิปเป็นเวอร์ชัน {zver} ซึ่งไม่ใหม่กว่าของที่ใช้อยู่ ({self.version}) — ยกเลิก กัน downgrade")

            # ---- แตกลง temp ก่อน แล้วค่อยสลับ ----
            import shutil, tempfile
            tmp = tempfile.mkdtemp(prefix=".mlep_upd_", dir=plugins_dir)
            try:
                z.extractall(tmp)
                src = os.path.join(tmp, name)
                if not os.path.isdir(src) or not os.path.exists(os.path.join(src, "main.py")):
                    raise RuntimeError("ซิปแตกออกมาไม่ครบ (ไม่พบ main.py)")
                backup = os.path.join(plugins_dir, name + "_bak_update")
                if os.path.exists(backup):
                    shutil.rmtree(backup, ignore_errors=True)
                os.rename(here, backup)                      # เก็บของเดิมไว้ก่อน
                try:
                    os.rename(src, here)                     # สลับของใหม่เข้าที่
                except Exception:
                    os.rename(backup, here)                  # สลับไม่สำเร็จ -> คืนของเดิมทันที
                    raise
                shutil.rmtree(backup, ignore_errors=True)
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
            return zver

        def _ok(zver):
            self._ask(
                QtWidgets.QMessageBox.Information, "Done", f"อัปเดตเป็นเวอร์ชัน {zver} เรียบร้อยแล้ว\n\nกรุณาปิด QGIS แล้วเปิดใหม่")

        def _err(e):
            self._ask(QtWidgets.QMessageBox.Critical, "Update Error", f"การดาวน์โหลดล้มเหลว:\n{e}")

        self._run_net(f"กำลังดาวน์โหลดเวอร์ชัน {new_version}...", _download, _ok, _err)

    def process_selection(self, mode):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        selected_ids = poly_layer.selectedFeatureIds()
        if not selected_ids: return

        # ★ ข้ามงานซ้ำเมื่อ "สิ่งที่เลือกไม่เปลี่ยน" (2026-08-06) — วัดจริง 104-171 ms ต่อครั้ง
        #   ถูกเรียกตอน "เริ่ม" ทุกเครื่องมือ (Move/Rotate/Scale/Transform/Score/Cluster/Move Node)
        #   ทำงานซ้ำบนกลุ่มเดิมจึงจ่ายค่านี้ซ้ำโดยไม่ได้อะไรเพิ่ม · ผลลัพธ์เหมือนเดิมทุกประการ จึงข้ามได้ปลอดภัย
        _key = None
        try:
            # ★ ต้องเทียบ "ตัวตน" ของหมุดที่เลือก ไม่ใช่จำนวน (2026-08-06 release gate)
            #   ถ้าใช้จำนวน: เปลี่ยนชุดหมุดเป็นชุดใหม่ที่ 'จำนวนเท่ากัน' จะถูกมองว่าเหมือนเดิม -> ไม่แก้ให้
            _key = (poly_layer.id(), point_layer.id() if point_layer else None,
                    mode, frozenset(selected_ids),
                    frozenset(point_layer.selectedFeatureIds()) if point_layer else None)
            if getattr(self, "_procsel_key", None) == _key:
                return
        except Exception:
            _key = None
        
        fields = poly_layer.fields()
        target_names = (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])
        target = None
        target_idx = -1
        for i, field in enumerate(fields):
            if field.name().lower() in target_names:
                target = field.name()
                target_idx = i
                break
        if target_idx == -1: return
        
        # Optimize: ดึงเฉพาะข้อมูล Attribute ของฟิลด์ที่กำหนดโดยไม่ดึงพิกัดเพื่อประหยัดหน่วยความจำ
        req = QgsFeatureRequest().setFilterFids(selected_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([target_idx])
        vals = set()
        for f in poly_layer.getFeatures(req):
            val = f.attribute(target_idx)
            # ★ NULL จาก provider ไม่ใช่ Python None เสมอไป (PyQt5 ส่งเป็น QVariant ว่าง) (2026-08-06)
            #   เดิมเช็คแค่ `is not None` -> ค่า NULL ลอดเข้าไปเป็นสตริง 'NULL' ในลิสต์ IN(...)
            #   ทำให้ได้เงื่อนไขที่ไม่มีวันตรงกับใคร (และรบกวนการเลือกทั้งชุด)
            if val is None:
                continue
            _sv = str(val).strip()
            if not _sv or _sv.upper() in ("NULL", "NONE", "NAN"):
                continue
            # quotedValue escape ค่าให้ถูกต้อง (เดิมต่อ string เอง -> ค่าที่มี ' ทำ expression พัง)
            vals.add(QgsExpression.quotedValue(_sv))

        if vals:
            _in_list = ",".join(sorted(vals))      # OPT: sort+join ครั้งเดียว ใช้ทั้งสองเลเยอร์
            expr = f'{QgsExpression.quotedColumnRef(target)} IN ({_in_list})'
            poly_layer.selectByExpression(expr)
            if point_layer:
                # ★ ชั้นหมุดอาจใช้ชื่อ field ต่างจากชั้นแปลง (utm vs utm_code)
                #   เดิมยิง expression ของชั้นแปลงใส่ตรง ๆ -> field ไม่ตรง = selection หมุดถูกล้างเงียบ
                #   เลือกชื่อเดียวกับฝั่งแปลงก่อน (กันเคสชั้นหมุดมีหลาย field เข้าข่าย
                #   เช่นมีทั้ง utm_id (เลขรัน) กับ utm (รหัสระวาง) แล้วสุ่มได้ตัวผิดตามลำดับ schema)
                _cand = (_UTM_FIELD_NAMES if mode != 'cluster'
                         else {'cluster_id', 'clusterid', 'id_cluster'})
                _ptf = next((fl.name() for fl in point_layer.fields()
                             if fl.name().lower() == target.lower()), None) \
                       or self._resolve_field(point_layer, _cand)
                if _ptf:
                    point_layer.selectByExpression(
                        f'{QgsExpression.quotedColumnRef(_ptf)} IN ({_in_list})')
                else:
                    # หา field ไม่ได้ -> ล้าง selection ฝั่งหมุด (พฤติกรรมเดิมก่อน 1.9.5)
                    # ห้ามปล่อยค้าง: Score/Cluster เขียนใส่ "ทุกหมุดที่ถูกเลือกอยู่" —
                    # selection เก่าที่ไม่เกี่ยวจะโดนเขียนทับเงียบ ๆ
                    point_layer.removeSelection()
                    self.iface.messageBar().pushMessage(
                        "MLEP", f"ชั้นหมุด '{point_layer.name()}' ไม่มีคอลัมน์ UTM/Cluster "
                                "ที่รู้จัก — ไม่ได้เลือกหมุดให้", level=1, duration=6)
            self.iface.mapCanvas().refresh()
            # จำสถานะปลายทางไว้ (รวมจำนวนหมุดที่เพิ่งเลือก) -> รอบหน้าที่เหมือนเดิมจะข้ามทั้งก้อน
            if _key is not None:
                try:
                    # เก็บ "สถานะหลังขยาย selection แล้ว" (ทั้งสองชั้น) — รอบหน้าที่เข้ามาด้วยสถานะนี้
                    # จะข้ามได้ถูกต้อง · เก็บจากค่าปัจจุบันจริง ไม่ reuse ค่าก่อนขยาย
                    self._procsel_key = (poly_layer.id(),
                                         point_layer.id() if point_layer else None, mode,
                                         frozenset(poly_layer.selectedFeatureIds()),
                                         frozenset(point_layer.selectedFeatureIds()) if point_layer else None)
                except Exception:
                    self._procsel_key = None

    # ============ Add Node: เพิ่ม node ให้แปลง + เพิ่มหมุด (ระวางจากแปลง, ชื่อจากหมุดเดิม) ============
    def start_add_node(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_lyr or poly_lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, "Add Node", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        if not point_lyr or point_lyr.geometryType() != QgsWkbTypes.PointGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, "Add Node", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        self.cancel_transform()
        self.temp_tool = AddNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Add Node", f"คลิกเลือกแปลงใน '{poly_lyr.name()}' (เลือก 1 แปลง • คลิกแปลงอื่น = เปลี่ยน) "
                        "แล้วคลิกที่หมุด (snap ให้อัตโนมัติ) เพื่อเพิ่ม node • คลิกขวา/Esc = ยกเลิก")

    def _marker_exists_here(self, point_lyr, poly_feat, xy, utm_fields, tol=0.01):
        """แปลงนี้มีหมุดของตัวเองอยู่ที่พิกัดนี้แล้วหรือยัง (ใช้กัน Add Node สร้างหมุดซ้อน)
        เทียบด้วย "ระวางเดียวกัน + อยู่ในระยะ tol" — ไม่ใช่แค่ตำแหน่ง เพราะมุมร่วมของแปลงข้างเคียง
        ต้องมีหมุดของตัวเองได้ (คนละ UTM = คนละหมุด ถือว่าไม่ซ้ำ)"""
        try:
            key = [f for f in utm_fields
                   if point_lyr.fields().indexOf(f) >= 0 and poly_feat.fields().indexOf(f) >= 0]
            if not key:
                return False                      # ไม่มีคีย์ให้เทียบ -> อย่าไปขวางการเพิ่ม
            rect = QgsRectangle(xy.x() - tol, xy.y() - tol, xy.x() + tol, xy.y() + tol)
            req = QgsFeatureRequest().setFilterRect(rect)
            for f in point_lyr.getFeatures(req):
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                if g.asPoint().distance(xy) > tol:
                    continue
                if all(str(f[k] or "") == str(poly_feat[k] or "") for k in key):
                    return True
        except Exception:
            return False                          # เช็คไม่ได้ -> ทำงานเหมือนเดิม
        return False

    # ---------- เครื่องมือผู้ดูแล: แก้ชื่อหมุด / ลบ node ----------
    def _admin_ready(self, title):
        """คืน (poly_lyr, point_lyr) ถ้าพร้อมใช้เครื่องมือ admin, ไม่งั้น None"""
        if not getattr(self, "_admin_on", False):
            return None
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_lyr or poly_lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, title, "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return None
        if not point_lyr or point_lyr.geometryType() != QgsWkbTypes.PointGeometry:
            self._ask(QtWidgets.QMessageBox.Warning, title, "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return None
        return poly_lyr, point_lyr

    def _admin_find_marker(self, poly_lyr, point_lyr, poly_feat, xy, tol=0.05):
        """หา "หมุดของแปลงนี้" ที่พิกัด xy (UTM ตรงกับแปลง) — มุมร่วมมีหลายหมุดซ้อน
        การเลือกแปลงก่อนจึงเป็นตัวชี้ว่าจะจัดการหมุดของแปลงไหน"""
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        if not pu or not tu:
            return None
        target = _norm_utm(poly_feat[pu])
        rect = QgsRectangle(xy.x() - tol, xy.y() - tol, xy.x() + tol, xy.y() + tol)
        for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            if _norm_utm(f[tu]) == target:
                return f
        return None

    def _rename_node_execute(self, poly_lyr, fid, snap_xy):
        """แก้ชื่อ (BND_NAME) ของหมุด "ของแปลงที่เลือก" ณ จุดที่คลิก"""
        ready = self._admin_ready("แก้ชื่อหมุด")
        if not ready:
            return False
        _chk = self._tool_layers_ok(poly_lyr, "แก้ชื่อหมุด")   # กันสลับคอมโบหลัง arm
        if _chk is None:
            return False
        poly_lyr, point_lyr = _chk
        pf = poly_lyr.getFeature(fid)
        if not pf.isValid():
            return False
        mk = self._admin_find_marker(poly_lyr, point_lyr, pf, snap_xy)
        if mk is None:
            self.iface.messageBar().pushMessage(
                "แก้ชื่อหมุด", "ตรงนี้ไม่มีหมุด 'ของแปลงที่เลือก' (ระวางไม่ตรงกัน)", level=1, duration=6)
            return False
        nf = self._addnode_name_field(point_lyr)
        if nf is None:
            self.iface.messageBar().pushMessage(
                "แก้ชื่อหมุด", "ชั้นหมุดไม่มีคอลัมน์ชื่อ (BND_NAME)", level=2, duration=6)
            return False
        old = "" if mk[nf] is None else str(mk[nf])
        new, ok = QtWidgets.QInputDialog.getText(
            self.iface.mainWindow(), "แก้ชื่อหมุด",
            f"ระวาง/UTM: {pf[self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)]}\n"
            f"หมุด gid {mk.id()} — ชื่อเดิม: {old or '(ว่าง)'}\n\nชื่อใหม่:", text=old)
        if not ok:
            return False
        new = new.strip()
        if new == old:
            return False
        if not point_lyr.isEditable():
            point_lyr.startEditing()
        self._op_begin([point_lyr])
        point_lyr.beginEditCommand("Rename Marker")
        try:
            point_lyr.changeAttributeValue(mk.id(), point_lyr.fields().indexOf(nf), new, old)
        finally:
            point_lyr.endEditCommand()
        self._op_commit()
        # การเปลี่ยนชื่อถูกบันทึกลง <D>_Move_Log โดย trigger log_move (action='renamed') ตอนกดบันทึก
        self.iface.messageBar().pushMessage(
            "แก้ชื่อหมุด", f"เปลี่ยน '{old or '(ว่าง)'}' -> '{new}' แล้ว • กด 💾 บันทึก เพื่อยืนยัน",
            level=0, duration=6)
        return True

    def _delete_node_execute(self, poly_lyr, fid, snap_xy):
        """ลบ node ของแปลงที่เลือก + หมุดของแปลงนั้นพร้อมกัน (ตรงข้าม Add Node)"""
        ready = self._admin_ready("ลบ node")
        if not ready:
            return False
        _chk = self._tool_layers_ok(poly_lyr, "ลบ node")       # กันสลับคอมโบหลัง arm
        if _chk is None:
            return False
        poly_lyr, point_lyr = _chk
        pf = poly_lyr.getFeature(fid)
        if not pf.isValid():
            return False
        geom = pf.geometry()
        proj = QgsProject.instance()
        to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj)
                   if poly_lyr.crs() != point_lyr.crs() else None)
        xy_poly = to_poly.transform(snap_xy) if to_poly else QgsPointXY(snap_xy)
        cv = geom.closestVertex(xy_poly)      # (point, vidx, prev, next, sqrDist)
        if cv[1] < 0 or cv[4] is None or cv[4] > 0.0025:      # เกิน 5 ซม.
            self.iface.messageBar().pushMessage(
                "ลบ node", "ตรงนี้ไม่มีมุมของแปลงที่เลือก (คลิกให้ตรงมุมแปลง)", level=1, duration=6)
            return False
        # ★ ต้องนับมุด "เฉพาะวง (ring) ที่คลิก" ไม่ใช่ทั้ง geometry (2026-08-06)
        #   แปลงที่มีรู/multipart: ทั้งก้อนอาจ 10 มุม แต่วงที่คลิกเหลือ 3 -> QGIS จะลบ "ทั้งวง" ทิ้ง
        #   (คืนค่า Success ปกติ) ขณะที่เราลบหมุดแค่ตัวเดียว = รูหาย เนื้อที่เปลี่ยน หมุดกำพร้าค้าง
        nvtx = None
        try:
            _ok, _vid = geom.vertexIdFromVertexNr(cv[1])
            if _ok:
                nvtx = geom.constGet().vertexCount(_vid.part, _vid.ring)
        except Exception:
            nvtx = None
        if nvtx is None:                                   # API ไม่รองรับ -> ใช้ทั้งก้อน (อนุรักษ์)
            nvtx = sum(1 for _ in geom.vertices())
        if nvtx <= 4:      # สามเหลี่ยม (3 มุม + ปิดวง) -> ลบแล้วไม่เป็นรูปปิด
            self.iface.messageBar().pushMessage(
                "ลบ node", "วงของแปลงตรงนี้เหลือ 3 มุม — ลบอีกไม่ได้ (รูปแปลงจะไม่สมบูรณ์)",
                level=2, duration=8)
            return False
        mk = self._admin_find_marker(poly_lyr, point_lyr, pf, snap_xy)
        nm = ""
        nfld = self._addnode_name_field(point_lyr)
        if mk is not None and nfld is not None and mk[nfld] is not None:
            nm = str(mk[nfld])
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ยืนยันลบ node",
            f"ระวาง/UTM: {pf[pu] if pu else '?'}\n"
            f"พิกัด: {xy_poly.x():.3f}, {xy_poly.y():.3f}\n"
            f"หมุดที่จะลบด้วย: {('gid ' + str(mk.id()) + ' ชื่อ ' + (nm or '(ไม่มีชื่อ)')) if mk else 'ไม่มี (ลบเฉพาะมุมแปลง)'}\n\n"
            "ลบมุมแปลงนี้พร้อมหมุดของแปลงนี้?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        lyrs = [poly_lyr] + ([point_lyr] if mk is not None else [])
        for l in lyrs:
            if not l.isEditable():
                l.startEditing()
        self._op_begin(lyrs)
        poly_lyr.beginEditCommand("Delete Node")
        if mk is not None:
            point_lyr.beginEditCommand("Delete Marker")
        okv = False
        try:
            _r = poly_lyr.deleteVertex(fid, cv[1])
            # ★ deleteVertex คืน enum Qgis.VectorEditResult ไม่ใช่ bool — และ Success มีค่า 0
            #   ถ้าเช็คแบบ truthiness จะกลายเป็น "ล้มเหลว" ทั้งที่ลบสำเร็จ
            #   -> เดิมทีจะไม่ลบหมุดตาม แต่มุมแปลงหายไปแล้ว = หมุดลอยค้าง (desync เงียบ)
            okv = _r if isinstance(_r, bool) else (int(_r) == 0)
            if okv and mk is not None:
                if not point_lyr.deleteFeature(mk.id()):
                    okv = False        # ลบหมุดไม่ได้ -> ถือว่าทั้ง operation ล้มเหลว (กันหลุดคู่)
        finally:
            # ★ ครึ่งทางต้องย้อนกลับ (2026-08-04): เดิม endEditCommand ทุกกรณี ⇒ ถ้ามุมถูกลบสำเร็จ
            #   แต่ลบหมุดไม่สำเร็จ การลบมุมจะถูก "ยืนยัน" ค้างไว้ = มุมหาย หมุดลอย (desync เงียบ)
            #   ทั้งที่ข้อความแจ้งว่า "ไม่สำเร็จ" -> พนักงานเข้าใจว่าไม่มีอะไรเกิดขึ้น
            #   destroyEditCommand ย้อนทุกการแก้ใน command นี้ทิ้ง -> กลับสู่สภาพก่อนกดลบจริง ๆ
            if okv:
                poly_lyr.endEditCommand()
                if mk is not None:
                    point_lyr.endEditCommand()
            else:
                poly_lyr.destroyEditCommand()
                if mk is not None:
                    point_lyr.destroyEditCommand()
        self._op_commit()
        if not okv:
            self.iface.messageBar().pushMessage(
                "ลบ node", "ลบไม่สำเร็จ — ย้อนกลับให้แล้ว (มุมแปลงและหมุดยังครบเหมือนเดิม)",
                level=2, duration=8)
            return False
        # การลบถูกบันทึกลง <D>_Move_Log เอง: หมุด -> trigger trg_log_delete (เก็บ geom เดิม),
        # แปลง -> trg_log_move action='reshaped' (เก็บ geom ก่อน/หลัง) ตอนกดบันทึก
        self.iface.messageBar().pushMessage(
            "ลบ node", "ลบมุมแปลง + หมุดของแปลงนี้แล้ว • กด 💾 บันทึก เพื่อยืนยัน", level=0, duration=6)
        return True

    def start_rename_node(self):
        ready = self._admin_ready("แก้ชื่อหมุด")
        if not ready:
            return
        poly_lyr, point_lyr = ready
        self.cancel_transform()
        self.setup_snapping()
        self.temp_tool = RenameNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "แก้ชื่อหมุด", "คลิกเลือกแปลง แล้วคลิกที่หมุดของแปลงนั้นเพื่อแก้ชื่อ • คลิกขวา/Esc = ออก")

    def start_delete_node(self):
        ready = self._admin_ready("ลบ node")
        if not ready:
            return
        poly_lyr, point_lyr = ready
        self.cancel_transform()
        self.setup_snapping()
        self.temp_tool = DeleteNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "ลบ node", "คลิกเลือกแปลง แล้วคลิกที่ node เพื่อลบมุม+หมุดของแปลงนั้น • คลิกขวา/Esc = ออก")

    # ---------- ผู้ดูแล: ลบทั้งแปลง (รูปแปลง + หมุดของแปลงนั้น) ----------
    def start_delete_parcel(self):
        ready = self._admin_ready("ลบทั้งแปลง")
        if not ready:
            return
        poly_lyr, point_lyr = ready
        self.cancel_transform()
        self._dol_clear_highlight()
        # ★ จำคู่เลเยอร์ตอน arm — ถ้าคอมโบถูกสลับก่อนคลิก ให้ยกเลิก (กันหาหมุดผิดชั้น)
        self._delparcel_lids = (poly_lyr.id(), point_lyr.id())
        canvas = self.iface.mapCanvas()
        # ใช้ตัวเลือกแปลงตัวเดียวกับปุ่มค้นหาภาพลักษณ์ — มี popup ให้เลือกเมื่อแปลงซ้อนกัน
        self.temp_tool = PolygonPickTool(
            canvas, poly_lyr, self._delete_parcel_picked, self._dol_on_hover)
        canvas.setMapTool(self.temp_tool)
        self.iface.messageBar().pushMessage(
            "ลบทั้งแปลง", f"⚠️ คลิกแปลงใน '{poly_lyr.name()}' ที่ต้องการลบ "
                          "(ลบรูปแปลง + หมุดของแปลงนั้นทั้งหมด) • Esc = ยกเลิก", level=2, duration=10)

    def _delete_parcel_picked(self, feat, layer):
        """callback จาก PolygonPickTool — คืน cursor ปกติแล้วเข้าขั้นยืนยัน/ลบ"""
        self.iface.actionSelect().trigger()
        self._dol_clear_highlight()
        ready = self._admin_ready("ลบทั้งแปลง")
        if not ready:
            return
        poly_lyr, point_lyr = ready
        # ★ ทั้งคู่ต้องเป็นเลเยอร์เดิมตอนกดปุ่ม (กันสลับคอมโบ "ชั้นหมุด" ระหว่าง arm→คลิก
        #   ซึ่งจะทำให้หาหมุดในชั้นผิด = ลบแปลงแต่หมุดจริงค้าง — 2026-08-05)
        armed = getattr(self, "_delparcel_lids", None)
        if armed != (poly_lyr.id(), point_lyr.id()) or (layer is not None and layer.id() != poly_lyr.id()):
            self._ask(
                QtWidgets.QMessageBox.Warning, "ลบทั้งแปลง",
                "ชั้นข้อมูลถูกเปลี่ยนหลังจากกดปุ่ม (หรือแปลงที่คลิกอยู่คนละชั้น) — ยกเลิก\n"
                "กดปุ่ม 🗑🧨 ใหม่อีกครั้ง")
            return
        self._delete_parcel_execute(poly_lyr, point_lyr, feat)

    def _parcel_markers(self, poly_lyr, point_lyr, feat):
        """คืน dict {mk_ids, n_on_node, utm_norm, n_twin, n_vtx} = หมุด "ของแปลงนี้" (UTM ตรงกับแปลง)
        หรือ None = ตรวจไม่ได้ (คีย์ว่าง/NULL หรือ query ล้ม) -> ผู้เรียกต้องยกเลิกการลบ (fail-closed)
        ค้น 2 ทางแล้วรวมกัน กันพลาด:
          (1) expression บน UTM  -> ได้ครบแม้หมุดหลงอยู่นอกขอบเขตแปลง
          (2) กวาดตามขอบเขตแปลง + เทียบ _norm_utm -> กันเคสค่า UTM เขียนต่างรูปแบบเล็กน้อย
        n_twin = จำนวนแปลงในชั้นที่ถือ UTM เดียวกัน (>1 = คีย์ซ้ำ ห้ามลบ) · n_vtx = จำนวนมุมแปลง"""
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        pu = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        if not tu or not pu:
            return None
        utm_raw = feat[pu]
        utm_norm = _norm_utm(utm_raw)
        # ★ NULL/ว่าง = ลบอัตโนมัติไม่ได้ (2026-08-05): _norm_utm(NULL) คืนสตริง 'None'/'NULL'
        #   ซึ่ง truthy — ถ้าปล่อยผ่าน การกวาด bbox จะจับ "หมุดคีย์ว่างของแปลงข้างเคียง" มาลบด้วย
        if not utm_norm or utm_norm.upper() in ("NONE", "NULL", "NAN"):
            return None
        # fail-closed ทั้งฟังก์ชัน: query พัง = คืน None (ยกเลิกการลบ) — ห้ามลบทั้งที่รายชื่อหมุดไม่ครบ
        # (provider อาจคืน iterator ว่าง/สั้นแบบเงียบ ๆ ตอนหลุด connection — กันเพิ่มด้วย n_vtx เทียบใน dialog)
        try:
            ids = {}
            req = QgsFeatureRequest().setFilterExpression(
                f"{QgsExpression.quotedColumnRef(tu)} = {QgsExpression.quotedValue(str(utm_raw).strip())}")
            for f in point_lyr.getFeatures(req):
                ids[f.id()] = f.geometry()
            geom = feat.geometry()
            bb = geom.boundingBox()
            bb.grow(1.0)          # เผื่อหมุดที่นั่งพอดีขอบ
            for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(bb)):
                if f.id() not in ids and _norm_utm(f[tu]) == utm_norm:
                    ids[f.id()] = f.geometry()
            # แปลงคีย์ซ้ำ (แฝด): ลบหมุดตาม UTM จะพังแปลงแฝดด้วย -> นับไว้ให้ execute ปฏิเสธ
            n_twin = 0
            preq = (QgsFeatureRequest().setFilterExpression(
                        f"{QgsExpression.quotedColumnRef(pu)} = {QgsExpression.quotedValue(str(utm_raw).strip())}")
                    .setFlags(QgsFeatureRequest.NoGeometry).setNoAttributes())
            for _pf in poly_lyr.getFeatures(preq):
                n_twin += 1
        except Exception:
            return None
        # นับหมุดที่ทับมุมแปลงจริง + จำนวนมุมแปลง (โชว์ในกล่องยืนยันให้คนเห็นว่าครบไหม)
        n_on_node = 0
        g = feat.geometry()
        for gm in ids.values():
            try:
                if gm is None or gm.isNull():
                    continue
                cv = g.closestVertex(gm.asPoint())
                if cv[4] is not None and cv[4] < 0.0001:      # ทับมุมแปลง < 1 ซม.
                    n_on_node += 1
            except Exception:
                continue          # หมุด geometry แปลก (multipoint/พัง) ข้ามตัวนั้น ไม่ล้มการนับทั้งชุด
        try:
            n_vtx = sum(1 for _ in g.vertices())
        except Exception:
            n_vtx = 0
        return {"mk_ids": list(ids.keys()), "n_on_node": n_on_node,
                "utm_norm": utm_norm, "n_twin": n_twin, "n_vtx": n_vtx}

    def _delete_parcel_execute(self, poly_lyr, point_lyr, feat):
        """ลบรูปแปลง + หมุดของแปลงนั้นพร้อมกัน (ทั้งคู่หรือไม่ทำเลย)"""
        if feat is None or not feat.isValid():
            return False
        info = self._parcel_markers(poly_lyr, point_lyr, feat)
        if info is None:
            self._ask(
                QtWidgets.QMessageBox.Warning, "ลบทั้งแปลง",
                "อ่านค่า UTM/รายชื่อหมุดของแปลงนี้ไม่ได้ (คีย์ว่าง หรือ query ล้มเหลว)\n"
                "— ยกเลิกการลบ (กันลบผิดแปลง/ลบหมุดไม่ครบ)")
            return False
        mk_ids, n_on_node = info["mk_ids"], info["n_on_node"]
        utm_norm, n_twin, n_vtx = info["utm_norm"], info["n_twin"], info["n_vtx"]
        if n_twin > 1:
            self._ask(
                QtWidgets.QMessageBox.Warning, "ลบทั้งแปลง",
                f"พบแปลงคีย์ซ้ำ (UTM เดียวกัน {n_twin} แปลง) — ลบอัตโนมัติไม่ได้\n"
                "เพราะหมุดถูกแชร์ตามคีย์ ลบแล้วแปลงแฝดจะหมุดหาย · แก้คีย์ซ้ำก่อน")
            return False
        if not mk_ids:
            a0 = self._ask(
                QtWidgets.QMessageBox.Question, "ลบทั้งแปลง — ผิดปกติ",
                "ไม่พบหมุดของแปลงนี้เลย (ตามกติกาเหล็ก ทุกมุมควรมีหมุด)\n"
                "อาจเลือกชั้นหมุดผิด หรือการค้นหมุดล้มเหลวเงียบ ๆ\n\n"
                "ยืนยันลบ 'เฉพาะรูปแปลง' โดยไม่แตะหมุดเลย?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if a0 != QtWidgets.QMessageBox.Yes:
                return False

        def gv(name):
            try:
                if feat.fields().indexOf(name) < 0:
                    return ""
                v = feat[name]
                return "" if v is None else str(v).strip()
            except Exception:
                return ""

        tp = self._poly_type_str(poly_lyr, feat)
        try:
            area_m2 = feat.geometry().area()
        except Exception:
            area_m2 = 0.0
        warn_ref = tp in ("L1-RTK", "L1-TS", "CT-RTK")
        # ★ แปลงอ้างอิง: ต้องกด "🔓 ปลดล็อก L1" ก่อนถึงลบได้ (สอดคล้องกับทุกเครื่องมือ admin
        #   ที่แตะ L1 — double-confirm อย่างเดียวยังง่ายไปสำหรับ destructive · 2026-08-05)
        if warn_ref and not self._admin_unlock_l1:
            self._ask(
                QtWidgets.QMessageBox.Warning, "ลบทั้งแปลง",
                f"แปลงนี้เป็น {tp} (ชั้นอ้างอิงพิกัดหลัก)\n"
                "ต้องกดปุ่ม 🔓 ปลดล็อก L1-RTK/L1-TS ก่อน จึงจะลบได้")
            return False
        head = ("🔴 แปลงนี้เป็น " + tp + " = ชั้นอ้างอิงพิกัดหลัก!\n"
                "ลบแล้วจะเสียหมุดอ้างอิงที่แปลงข้างเคียงใช้ยึด\n\n") if warn_ref else ""
        ans = self._ask(
            QtWidgets.QMessageBox.Question, "ยืนยันลบทั้งแปลง",
            f"{head}"
            f"ระวาง {gv('UTMMAP1')} {gv('UTMMAP2')} {gv('UTMMAP3')}-{gv('UTMMAP4') or '00'}"
            f"  มาตราส่วน {gv('UTMSCALE')}\n"
            f"เลขที่ดิน {gv('LANDNO')}  |  ประเภท {tp or '-'}  |  เนื้อที่รูป {area_m2:,.1f} ตร.ม.\n"
            f"UTM: {utm_norm}\n\n"
            f"จะลบ: รูปแปลง 1 แปลง + หมุดของแปลงนี้ {len(mk_ids)} จุด"
            f" (ทับมุมแปลง {n_on_node}/{n_vtx} มุม"
            + ("" if n_on_node >= max(n_vtx - 1, 0) else " ⚠️ ไม่ครบทุกมุม — เช็คชั้นหมุดก่อน")
            + ")\n\n"
            f"ลบทั้งแปลงนี้?",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if ans != QtWidgets.QMessageBox.Yes:
            return False
        if warn_ref:
            a2 = self._ask(
                QtWidgets.QMessageBox.Question, "ยืนยันอีกครั้ง (แปลงอ้างอิง)",
                f"ยืนยันซ้ำ: แปลง {tp} เลขที่ดิน {gv('LANDNO')} จะถูกลบถาวรเมื่อกดบันทึก\n\nแน่ใจหรือไม่?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
            if a2 != QtWidgets.QMessageBox.Yes:
                return False

        lyrs = [poly_lyr] + ([point_lyr] if mk_ids else [])
        for l in lyrs:
            if not l.isEditable():
                l.startEditing()
        self._op_begin(lyrs)
        poly_lyr.beginEditCommand("Delete Parcel")
        if mk_ids:
            point_lyr.beginEditCommand("Delete Parcel Markers")
        ok = False
        try:
            ok = bool(poly_lyr.deleteFeature(feat.id()))
            if ok and mk_ids:
                if not point_lyr.deleteFeatures(mk_ids):
                    ok = False        # ลบหมุดไม่ครบ -> ถือว่าล้มทั้ง operation (กันแปลงหายแต่หมุดค้าง)
        finally:
            # ทั้งคู่หรือไม่ทำเลย: ถ้าครึ่งทาง ย้อนทิ้งทั้ง command (เหมือนด่านของ "ลบ node")
            if ok:
                poly_lyr.endEditCommand()
                if mk_ids:
                    point_lyr.endEditCommand()
            else:
                poly_lyr.destroyEditCommand()
                if mk_ids:
                    point_lyr.destroyEditCommand()
        self._op_commit()
        if not ok:
            self.iface.messageBar().pushMessage(
                "ลบทั้งแปลง", "ลบไม่สำเร็จ — ย้อนกลับให้แล้ว (แปลงและหมุดยังอยู่ครบ)",
                level=2, duration=8)
            return False
        self.iface.mapCanvas().refresh()
        # การลบถูกบันทึกใน <D>_Move_Log ผ่าน trg_log_delete (เก็บ geom เดิมไว้ กู้คืนได้) ตอนกดบันทึก
        self.iface.messageBar().pushMessage(
            "ลบทั้งแปลง", f"ลบแปลง (เลขที่ดิน {gv('LANDNO')}) + หมุด {len(mk_ids)} จุดแล้ว "
                          "• กด 💾 บันทึก เพื่อยืนยันลงฐานข้อมูล", level=0, duration=8)
        return True

    def _addnode_name_field(self, point_lyr):
        """หา field ชื่อหมุด: ใช้ BND_NAME ก่อน ถ้าไม่มีหาฟิลด์ที่มีคำว่า NAME"""
        flds = point_lyr.fields()
        if flds.indexOf("BND_NAME") >= 0:
            return "BND_NAME"
        for f in flds:
            if "NAME" in f.name().upper():
                return f.name()
        return None

    def _poly_type_str(self, poly_lyr, feat):
        """คืนค่าฟิลด์ type (ตัวพิมพ์ใหญ่) ของแปลง หรือ '' ถ้าไม่มี — ใช้เช็ค L1-RTK/L1-TS
        เรียกทุก mouse-move ตอน hover (Add Node/Move Node) -> หา field ผ่าน cache"""
        name = self._resolve_field(poly_lyr, {'type'})
        if not name:
            return ""
        v = feat[name]
        return "" if v is None else str(v).strip().upper()

    def start_sync_vertex_tool(self):
        """เริ่มการทำงานของ SyncVertexTool (ย้ายหมุดทีละหลายอัน)"""
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        # ★ ต้องมีครบทั้งคู่ (2026-08-06): เดิม "แปลงหรือหมุด" อย่างใดอย่างหนึ่งก็ผ่าน
        #   -> ถ้าชั้นแปลงว่าง ด่านล็อก L1 ใน map_tools (ซึ่งอิงชั้นแปลง) ถูกข้ามทั้งหมด = ลากหมุด
        #   ของแปลงอ้างอิงได้ · และการย้าย node ฝั่งเดียวทำให้แปลงกับหมุดหลุดคู่กัน
        if not poly_lyr or not point_lyr:
            self.iface.messageBar().pushMessage(
                "Move Node", "ต้องเลือกทั้งเลเยอร์แปลง (Polygon) และเลเยอร์หมุด (Point) ก่อน "
                             "— เครื่องมือนี้ย้ายมุมแปลงกับหมุดพร้อมกัน", level=2, duration=8)
            return
            
        if self.temp_tool:
            try:
                self.temp_tool.deactivate()
            except Exception:
                pass
                
        # ถ้ามีแปลงถูก Select อยู่ ให้เรียกใช้ Select by UTM อัตโนมัติ เพื่อให้หมุดติด Select สีเหลืองไปด้วย
        if poly_lyr and poly_lyr.selectedFeatureCount() > 0:
            self.process_selection('utm')

        self.mode = 'modify_node'
        # ★ การลากหลายหมุดของ SyncVertexTool เช็ค match.isValid() จาก snapping
        #   ถ้าโปรเจกต์ปิด snap ไว้และนี่คือเครื่องมือแรกของ session -> ลากไม่ติดแบบเงียบ ๆ
        self.setup_snapping()
        self.temp_tool = SyncVertexTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Move Node",
            "คลิกหมุด → คลิกตำแหน่งใหม่เพื่อย้าย • หลายหมุด: ลากกล่องเลือกแล้วลากย้าย (Shift+ลาก = เลือกเพิ่ม) • คลิกขวา = เสร็จ")

    def _movenodes_execute(self, selected_vertices, dx, dy):
        """ประมวลผลการย้ายพิกัดหมุดหลายเลเยอร์พร้อมกัน"""
        if not selected_vertices:
            return False
            
        layers = set()
        for v in selected_vertices:
            layers.add(v['layer'])

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            if not lyr.isEditable():
                lyr.startEditing()
            lyr.beginEditCommand("Move Nodes (Sync)")
            
        try:
            proj = QgsProject.instance()
            # สร้าง transform ครั้งเดียวต่อเลเยอร์ (เดิมสร้างใหม่ทุก vertex ในลูป)
            xform_cache = {}
            for _lyr in layers:
                xform_cache[_lyr.id()] = (QgsCoordinateTransform(proj.crs(), _lyr.crs(), proj)
                                          if _lyr.crs() != proj.crs() else None)
            # ดึง geometry ของ polygon/line ที่ต้องแก้ทั้งหมดใน "คิวรีเดียวต่อเลเยอร์"
            # (เดิมดึงทีละ feature — บน PostgreSQL = 1 round-trip ต่อ feature)
            geom_updates = {}
            need = {}
            for v in selected_vertices:
                if v['vidx'] >= 0:
                    need.setdefault(v['layer'], set()).add(v['fid'])
            for _lyr, _fids in need.items():
                req = QgsFeatureRequest().setFilterFids(list(_fids)).setNoAttributes()
                for f in _lyr.getFeatures(req):
                    geom_updates[(_lyr.id(), f.id())] = f.geometry()

            for v in selected_vertices:
                lyr = v['layer']
                fid = v['fid']
                vidx = v['vidx']
                pt = v['pt']

                # แปลงพิกัดใหม่กลับไปเป็น CRS ของเลเยอร์เป้าหมาย (ใช้ transform ที่ cache ไว้)
                to_lyr = xform_cache.get(lyr.id())
                new_map_pt = QgsPointXY(pt.x() + dx, pt.y() + dy)
                new_lyr_pt = to_lyr.transform(new_map_pt) if to_lyr else new_map_pt

                key = (lyr.id(), fid)

                if vidx >= 0:
                    # Polygon หรือ Line (ย้ายเฉพาะ vertex นั้นๆ)
                    geom = geom_updates.get(key)
                    if geom is None:
                        continue   # feature หายไประหว่างทำงาน (เดิมจะ crash ด้วย StopIteration)
                    geom.moveVertex(new_lyr_pt.x(), new_lyr_pt.y(), vidx)
                else:
                    # Point (ย้ายทั้ง geometry)
                    geom_updates[key] = QgsGeometry.fromPointXY(new_lyr_pt)

            # นำ geometry ที่แก้ไขแล้วไปอัปเดต โดยใช้ changeGeometry เพื่อข้ามระบบ Topological Editing ของ QGIS
            # (ป้องกันไม่ให้หมุดแปลงข้างเคียงขยับตาม หากไม่ได้ถูกเลือกไว้)
            for v in selected_vertices:
                lyr = v['layer']
                fid = v['fid']
                key = (lyr.id(), fid)
                if key in geom_updates:
                    lyr.changeGeometry(fid, geom_updates[key])
                    del geom_updates[key]  # ป้องกันการรันซ้ำ
                    
            for lyr in layers:
                lyr.endEditCommand()

            self._op_commit()   # ปิด operation -> เก็บประวัติ undo
            self.iface.mapCanvas().refresh()
            return True
        except Exception as e:
            for lyr in layers:
                lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline (delta=0 -> ไม่บันทึก)
            self.iface.messageBar().pushMessage("Error", f"Move Nodes Error: {e}", level=2, duration=0)
            return False

    def _addnode_execute(self, poly_lyr, fids, ins_xy):
        """เพิ่ม node ให้ทุกแปลงที่เลือก + สร้างหมุดใหม่ (ระวางจากแปลง, ชื่อจากหมุดเดิม ณ จุด snap)
        ins_xy = พิกัดหมุดที่ snap ติด (CRS เลเยอร์หมุด). คืน True ถ้าสำเร็จ"""
        _chk = self._tool_layers_ok(poly_lyr, "Add Node")      # กันสลับคอมโบหลัง arm
        if _chk is None:
            return False
        _, point_lyr = _chk
        proj = QgsProject.instance()
        name_field = self._addnode_name_field(point_lyr)

        # รวมชื่อจากหมุดที่ตำแหน่งเดียวกัน (coincident กับจุด snap ≤5ซม.) -> หลายชื่อให้ popup เลือก
        COINC = 0.05
        rect = QgsRectangle(ins_xy.x() - COINC, ins_xy.y() - COINC,
                            ins_xy.x() + COINC, ins_xy.y() + COINC)
        names = []
        for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            nm = "" if name_field is None else str(f[name_field] or "").strip()
            if nm and nm not in names:
                names.append(nm)
        if len(names) <= 1:
            chosen = names[0] if names else ""
        else:
            chosen, ok = QtWidgets.QInputDialog.getItem(
                self.iface.mainWindow(), "เลือกชื่อหมุด",
                "ตำแหน่งนี้มีหลายหมุดหลายชื่อ — เลือกชื่อที่ต้องการ:", names, 0, False)
            if not ok:
                return False

        # พิกัดสำหรับแทรก node เข้า polygon (CRS เลเยอร์แปลง)
        to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj)
                   if poly_lyr.crs() != point_lyr.crs() else None)
        ins_poly = to_poly.transform(ins_xy) if to_poly else QgsPointXY(ins_xy)

        utm_fields = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO", "UTM"]
        if not poly_lyr.isEditable():
            poly_lyr.startEditing()
        if not point_lyr.isEditable():
            point_lyr.startEditing()
        self._op_begin([poly_lyr, point_lyr])   # เริ่มนับ undo-step ต่อเลเยอร์
        poly_lyr.beginEditCommand("Add Node")
        point_lyr.beginEditCommand("Add Marker")
        n_node = n_pt = n_skip = n_fail = 0
        try:
            for fid in fids:
                pf = poly_lyr.getFeature(fid)
                if not pf.isValid():
                    continue
                # กันชน: ห้ามเพิ่ม node ให้แปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
                tp = self._poly_type_str(poly_lyr, pf)
                if tp in ("L1-RTK", "L1-TS") and not self._admin_unlock_l1:
                    self.iface.messageBar().pushMessage(
                        "Add Node", f"ข้ามแปลง {fid}: เป็น {tp} (พิกัดอ้างอิง ห้ามเพิ่ม node)",
                        level=2, duration=6)
                    continue
                geom = pf.geometry()
                # ถ้าแปลงมี vertex ตรงนั้นแล้ว ไม่ต้องแทรกซ้ำ (แต่ยังเพิ่มหมุด)
                cv = geom.closestVertex(ins_poly)
                has_vertex = cv[4] is not None and cv[4] < 0.0001   # < 1 ซม.
                _ins_at = None            # index ของ vertex ที่เพิ่งแทรก (ไว้ย้อนถ้าหมุดเข้าไม่ได้)
                if not has_vertex:
                    seg = geom.closestSegmentWithContext(ins_poly)
                    # ★ เพดานระยะ (2026-08-06): เดิมไม่เช็ค seg[0] (ระยะยกกำลังสองถึงขอบแปลง)
                    #   -> คลิกหมุดที่อยู่ไกลจากแปลงที่เลือก ก็แทรกมุมให้ = รูปแปลงบิดไปหาหมุดนั้น
                    if seg[0] is not None and seg[0] > (self.ADDNODE_MAX_DIST ** 2):
                        n_fail += 1
                        self.iface.messageBar().pushMessage(
                            "Add Node",
                            f"ข้ามแปลง {fid}: จุดที่คลิกห่างจากขอบแปลงนี้ {math.sqrt(seg[0]):.2f} ม. "
                            f"(เกิน {self.ADDNODE_MAX_DIST:.0f} ม.)",
                            level=1, duration=8)
                        continue
                    if poly_lyr.insertVertex(ins_poly.x(), ins_poly.y(), fid, seg[2]):
                        n_node += 1
                        _ins_at = seg[2]
                    else:
                        # ★ แทรกมุมไม่สำเร็จ -> ห้ามเพิ่มหมุด (2026-08-04)
                        #   เดิมไหลต่อไป addFeature เสมอ = ได้หมุดลอยที่ไม่มีมุมแปลงรองรับ (ผิดกติกาเหล็ก)
                        n_fail += 1
                        continue
                # ★ กันหมุดซ้ำ: ถ้าแปลงนี้มีหมุดของตัวเองอยู่ตรงนั้นแล้ว อย่าเพิ่มอีก
                #   (เดิม has_vertex กันแค่ไม่ให้แทรก vertex ซ้ำ แต่ยัง addFeature เสมอ
                #    -> คลิก Add Node ซ้ำจุดเดิม/คลิกแปลงที่มีหมุดครบแล้ว = ได้หมุดซ้อนกัน)
                if self._marker_exists_here(point_lyr, pf, ins_xy, utm_fields):
                    n_skip += 1
                    continue
                # เพิ่มหมุดใหม่: ระวางจากแปลง + ชื่อที่เลือก
                nf = QgsFeature(point_lyr.fields())
                nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ins_xy)))
                for fld in utm_fields:
                    pi = point_lyr.fields().indexOf(fld)
                    qi = poly_lyr.fields().indexOf(fld)
                    if pi >= 0 and qi >= 0:
                        nf.setAttribute(pi, pf.attribute(qi))
                if name_field is not None and chosen:
                    nf.setAttribute(point_lyr.fields().indexOf(name_field), chosen)
                # provenance: ติดป้ายว่าหมุดนี้ "คนเพิ่ม" (addFeature() ไม่ผ่าน attribute form -> form default ไม่ยิง)
                # ตั้งแค่ EDIT_SRC เท่านั้น — "ใคร/เมื่อไหร่" ปล่อยให้ PG trigger tag_added_point() เขียนเอง:
                #   EDITED_BY = session_user  (PG role ของพนักงานจริง เช่น phuwanart_boo — แม่นกว่า OS login
                #                              ของเครื่องที่อาจเป็นบัญชีกลาง เช่น 'dol-workspace') ปลอมจาก client ไม่ได้
                #   EDITED_AT = now()         (เวลา server ไม่ใช่นาฬิกาเครื่อง client)
                # (indexOf: ไม่มีคอลัมน์ -> -1 -> ข้าม, ปลอดภัยกับเลเยอร์ที่ไม่มี provenance)
                _pidx = point_lyr.fields().indexOf("EDIT_SRC")
                if _pidx >= 0:
                    nf.setAttribute(_pidx, "added")
                if point_lyr.addFeature(nf):
                    n_pt += 1
                else:
                    # ★ หมุดเข้าไม่ได้ (สิทธิ์ INSERT ไม่พอ/provider ปฏิเสธ) -> ย้อนมุมที่เพิ่งแทรกออก
                    #   (2026-08-04) ไม่งั้นเหลือมุมเปลือยไม่มีหมุด = ผิดกติกาเหล็กอีกด้าน
                    n_fail += 1
                    if _ins_at is not None:
                        # ★ deleteVertex คืน enum Qgis.VectorEditResult (Success==0) และไม่ raise
                        #   -> ต้องเช็คผลจริง (แบบเดียวกับ _delete_node_execute) · ถ้าย้อนไม่สำเร็จ
                        #   = เหลือมุมเปลือย ให้แจ้งดัง ๆ ไม่ปล่อยเงียบ (2026-08-05)
                        _rv = poly_lyr.deleteVertex(fid, _ins_at)
                        if (_rv if isinstance(_rv, bool) else int(_rv) == 0):
                            n_node -= 1
                        else:
                            self.iface.messageBar().pushMessage(
                                "Add Node", f"แปลง {fid}: หมุดเข้าไม่ได้และย้อนมุมที่แทรกไม่สำเร็จ "
                                            "— มุมนี้ยังไม่มีหมุด (กด Undo แล้วลองใหม่)",
                                level=2, duration=10)
            poly_lyr.endEditCommand()
            point_lyr.endEditCommand()
            self._op_commit()   # ปิด operation -> เก็บประวัติ undo (แปลงที่ vertex มีอยู่แล้ว delta=0 ข้ามเอง)
        except Exception as e:
            poly_lyr.destroyEditCommand()
            point_lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline
            self.iface.messageBar().pushMessage("Add Node Error", f"{e}", level=2, duration=0)
            return False

        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushMessage(
            "Add Node", f"เพิ่ม node {n_node} แปลง + หมุด {n_pt} จุด (ชื่อ '{chosen or '-'}')"
                        + (f" • ข้าม {n_skip} จุดที่มีหมุดอยู่แล้ว" if n_skip else "")
                        + (f" • ⚠️ ทำไม่สำเร็จ {n_fail} แปลง (ย้อนกลับให้แล้ว ไม่มีมุม/หมุดค้าง)" if n_fail else ""),
            level=(2 if n_fail else 3), duration=(12 if n_fail else 8))
        # ★ คืนค่าตามงานที่ทำจริง (2026-08-06): มีเส้นทางที่ข้ามทุกแปลง (เกินเพดานระยะ/แทรกมุมไม่ได้)
        #   เดิมคืน True เสมอ -> เครื่องมือรายงานว่าสำเร็จทั้งที่ไม่มีอะไรเกิดขึ้น
        return (n_node > 0 or n_pt > 0)

    def start_align_tool(self):
        self.cancel_transform()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            self._ask(QtWidgets.QMessageBox.Warning, "Align", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        # ★ ต้องมีชั้นแปลงด้วย (2026-08-06): เดิมบังคับแค่ชั้นหมุด -> ถ้าชั้นแปลงว่าง Align จะ
        #   "ย้ายหมุดอย่างเดียว" (PASS 2) โดยไม่เชื่อมมุมแปลง (PASS 3 ถูกข้าม) = แปลงกับหมุดหลุดคู่กัน
        #   และด่านล็อก L1 ซึ่งอิงชั้นแปลง ก็ถูกข้ามไปด้วย = ลากหมุดอ้างอิงได้
        _poly_chk = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not _poly_chk:
            self._ask(QtWidgets.QMessageBox.Warning, "Align",
                      "กรุณาเลือกเลเยอร์แปลง (Polygon) ด้วย\n"
                      "Align ต้องใช้ชั้นแปลงเพื่อเชื่อมมุมแปลงตามหมุด และเพื่อตรวจการล็อกแปลงอ้างอิง L1")
            return
        self.mode = 'align_box'
        self.canvas = self.iface.mapCanvas()
        self._align_max_par = None          # อ่าน QSettings ใหม่รอบนี้ (เผื่อผู้ใช้เพิ่งแก้ค่า)
        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.temp_tool = BoxSelectTool(self.iface.mapCanvas(), self._align_add_box,
                                       self.finish_align_selection, self._align_cancel)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", "ลากกล่องครอบหมุด (ครอบหลายรอบได้ • Ctrl+ลาก = เอาออก) แล้วคลิกขวาเพื่อเลือกเสร็จ")

    def _align_add_box(self, rect_map, remove):
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            return
        proj = QgsProject.instance()
        rect_lyr = rect_map
        if point_lyr.crs() != proj.crs():
            try:
                rect_lyr = QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj).transformBoundingBox(rect_map)
            except Exception:
                rect_lyr = rect_map
        ids = set(getattr(self, "_align_picked_ids", set()))
        req = QgsFeatureRequest().setFilterRect(rect_lyr).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            ids.discard(f.id()) if remove else ids.add(f.id())
        # ★ เพดานจำนวนหมุด (2026-08-06) — เท่ากับ Move Node ที่จำกัด 800 ไว้ตั้งแต่ 1.9.5 "กันเครื่องค้าง"
        #   เดิม Align ไม่มีเพดาน: ครอบกว้าง ๆ ที = สร้าง QgsVertexMarker เท่าจำนวนหมุด + วนงานหนักทุก pass
        if not remove and len(ids) > self.ALIGN_MAX_PICK:
            self.iface.messageBar().pushMessage(
                "Align", f"เลือกได้สูงสุด {self.ALIGN_MAX_PICK:,} จุด (กล่องนี้ทำให้เกิน {len(ids):,}) "
                         "— ยกเลิกกล่องล่าสุด ลองครอบให้แคบลง", level=2, duration=8)
            return
        self._align_picked_ids = ids
        self._align_refresh_highlight()
        self.iface.messageBar().pushInfo("Align", f"เลือกหมุด {len(ids)} จุด (คลิกขวา = เสร็จ)")

    def _align_refresh_highlight(self):
        self._align_clear_highlight()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        ids = getattr(self, "_align_picked_ids", None)
        if not point_lyr or not ids:
            return
        proj = QgsProject.instance()
        xform = None
        if point_lyr.crs() != proj.crs():
            try:
                xform = QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
            except Exception:
                xform = None
        self._align_markers = []
        req = QgsFeatureRequest().setFilterFids(list(ids)).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            xy = f.geometry().asPoint()
            if xform is not None:
                try:
                    xy = xform.transform(xy)
                except Exception:
                    pass
            mk = QgsVertexMarker(self.iface.mapCanvas())
            mk.setCenter(QgsPointXY(xy))
            mk.setColor(QtGui.QColor(0, 120, 255))
            mk.setIconType(QgsVertexMarker.ICON_BOX)
            mk.setPenWidth(3)
            mk.setIconSize(10)
            self._align_markers.append(mk)

    def _align_clear_highlight(self):
        for mk in getattr(self, "_align_markers", []):
            try:
                self.iface.mapCanvas().scene().removeItem(mk)
            except Exception:
                pass
        self._align_markers = []

    def _align_cancel(self):
        """ยกเลิกโหมด Align (Esc): ล้างข้อความแนะนำที่ค้าง แล้วรีเซ็ต"""
        try:
            self.iface.messageBar().clearWidgets()
        except Exception:
            pass
        self.cancel_transform()

    def finish_align_selection(self):
        """คลิกขวา = จบการเลือกหมุด -> เข้าโหมดลากเส้น 2 จุด (หมุดที่เลือกจะวิ่งไปหาเส้นที่ลาก
        หมุด/มุมที่ไม่ได้เลือกอยู่กับที่ -> แปลงยังต่อกับของเดิม)"""
        if not getattr(self, "_align_picked_ids", None):
            self.iface.messageBar().pushMessage("Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน", level=1, duration=6)
            return
        self.mode = 'align_point_driven'
        self.src_pts = []
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.canvas)
        self.temp_tool.canvasClicked.connect(self.handle_align_click)
        self.temp_tool.canvasMoveEvent = self.handle_align_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", f"เลือกหมุด {len(self._align_picked_ids)} จุด → คลิก 2 จุดสร้างเส้นแนว (Esc = ยกเลิก)")

    def handle_align_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือ Align (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
        # แก้จาก self.snapping_utils เป็น self.snap_utils
        if not hasattr(self, 'snap_utils'):
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # Logic สำหรับวาด Rubber Band เส้นยางยืด (ถ้ามี)
        if hasattr(self, 'rubber_band') and self.rubber_band and len(self.src_pts) == 1:
            curr_pt = match.point() if match.isValid() else event.mapPoint()
            self.rubber_band.removeLastPoint()
            self.rubber_band.addPoint(curr_pt)
            
    def handle_align_click(self, point, button):
        """จัดการการคลิกจุด P1 และ P2 สำหรับสร้างแนวเส้น (รองรับที่ว่าง)"""
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        # 2. ถ้า Snap ไม่ติด ให้ใช้พิกัดที่คลิกจริง (point)
        pt = match.point() if match.isValid() else point
        
        self.src_pts.append(QgsPointXY(pt.x(), pt.y()))
        
        # วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        m.setPenWidth(5)
        self.markers.append(m)
        
        if len(self.src_pts) == 1:
            self.clear_rubber_band()
            self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            self.rubber_band.setColor(QtGui.QColor(255, 0, 0))
            self.rubber_band.setWidth(2)
            self.rubber_band.addPoint(pt)
            self.rubber_band.addPoint(pt)

        if len(self.src_pts) == 2:
            self.execute_point_node_alignment()
            # ทำความสะอาดหน้าจอหลังเสร็จงาน
            self.clear_markers()
            self.clear_rubber_band()
            self.src_pts = []
            
    def clear_rubber_band(self):
        """ลบ Rubber Band ออกจากหน้าจอและหน่วยความจำอย่างเด็ดขาด"""
        if self.rubber_band:
            self.rubber_band.hide() # ซ่อนทันที
            self.iface.mapCanvas().scene().removeItem(self.rubber_band) # ลบออกจาก Scene
            self.rubber_band = None # คืนค่าว่าง
            
    def _prefetch_align_polys(self, poly_lyr, target_points, pad):
        """ดึงแปลงรอบหมุดที่เลือกทั้งหมดใน "คิวรีเดียว" + สร้าง spatial index ในหน่วยความจำ
        -> {'index': QgsSpatialIndex, 'geoms': {fid: QgsGeometry}, 'types': {fid: TYPE upper}}
        (เดิม _side_edge_dir และ weld PASS 3 ยิง query ต่อหมุด — บน PostgreSQL = N round-trips)"""
        rect = None
        for pt_f in target_points:
            g = pt_f.geometry()
            if g is None or g.isNull():
                continue
            p = g.asPoint()
            r = QgsRectangle(p.x() - pad, p.y() - pad, p.x() + pad, p.y() + pad)
            if rect is None:
                rect = QgsRectangle(r)
            else:
                rect.combineExtentWith(r)
        cache = {'index': QgsSpatialIndex(), 'geoms': {}, 'types': {}, 'utm': {}, 'rect': None}
        if rect is None:
            return cache
        cache['rect'] = QgsRectangle(rect)
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        # ★ ดึง UTM มาด้วย (2026-08-06) — PASS 3 ต้องใช้หา "หมุดของแปลงเพื่อนบ้าน" ที่ต้องย้ายตามมุม
        _uf = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        utm_idx = poly_lyr.fields().indexOf(_uf) if _uf else -1
        req = QgsFeatureRequest().setFilterRect(rect)
        req.setSubsetOfAttributes([i for i in (type_idx, utm_idx) if i != -1])
        for f in poly_lyr.getFeatures(req):
            g = f.geometry()
            if g is None or g.isNull():
                continue
            cache['geoms'][f.id()] = QgsGeometry(g)
            if type_idx != -1:
                v = f.attribute(type_idx)
                cache['types'][f.id()] = "" if v is None else str(v).strip().upper()
            if utm_idx != -1:
                u = f.attribute(utm_idx)
                cache['utm'][f.id()] = "" if u is None else _norm_utm(u)
            cache['index'].addFeature(f)
        return cache

    def _align_marker_index(self, point_lyr, rect):
        """คิวรีเดียว: หมุดในกรอบ -> {(x มม., y มม., utm): [fid, ...]}  (ใช้หาหมุดคู่ของมุมที่ถูก weld)"""
        idx = {}
        if point_lyr is None or rect is None:
            return idx
        tu = self._resolve_field(point_lyr, _UTM_FIELD_NAMES)
        if not tu:
            return idx
        ti = point_lyr.fields().indexOf(tu)
        r = QgsRectangle(rect)
        r.grow(1.0)
        req = QgsFeatureRequest().setFilterRect(r)
        if ti >= 0:
            req.setSubsetOfAttributes([ti])
        for f in point_lyr.getFeatures(req):
            g = f.geometry()
            if g is None or g.isNull():
                continue
            try:
                p = g.asPoint()
            except Exception:
                continue
            u = _norm_utm(f.attribute(ti)) if ti >= 0 else ""
            idx.setdefault((round(p.x(), 3), round(p.y(), 3), u), []).append(f.id())
        return idx

    def _side_edge_dir(self, old_xy, poly_cache, line_dx, line_dy):
        """ทิศของขอบแปลงที่ vertex old_xy โดยเลือกขอบที่ไม่ขนานกับเส้นเป้าหมาย -> (ux,uy) หรือ None
        ค้นจาก poly_cache ที่ prefetch ไว้ (ไม่ยิง query ต่อหมุดแล้ว)"""
        if not poly_cache or not poly_cache['geoms']:
            return None
        lmag = math.hypot(line_dx, line_dy)
        if lmag == 0:
            return None
        lux, luy = line_dx / lmag, line_dy / lmag
        EPS = 0.05
        rect = QgsRectangle(old_xy.x() - 1.0, old_xy.y() - 1.0,
                            old_xy.x() + 1.0, old_xy.y() + 1.0)
        best = None  # (parallelness, ux, uy)
        for fid in poly_cache['index'].intersects(rect):
            g = poly_cache['geoms'].get(fid)
            if g is None:
                continue
            try:
                if g.isMultipart():
                    rings = [poly[0] for poly in g.asMultiPolygon() if poly]
                else:
                    pg = g.asPolygon()
                    rings = [pg[0]] if pg else []
            except Exception:
                rings = []
            for ring in rings:
                if len(ring) > 1 and ring[0] == ring[-1]:
                    ring = ring[:-1]
                n = len(ring)
                if n < 3:
                    continue
                vi = -1
                for idx, v in enumerate(ring):
                    if abs(v.x() - old_xy.x()) <= EPS and abs(v.y() - old_xy.y()) <= EPS:
                        vi = idx
                        break
                if vi < 0:
                    continue
                v = ring[vi]
                for nb in (ring[(vi - 1) % n], ring[(vi + 1) % n]):
                    ex, ey = nb.x() - v.x(), nb.y() - v.y()
                    emag = math.hypot(ex, ey)
                    if emag < 1e-9:
                        continue
                    ux, uy = ex / emag, ey / emag
                    par = abs(ux * lux + uy * luy)   # 1 = ขนานกับเส้นเป้าหมาย
                    if best is None or par < best[0]:
                        best = (par, ux, uy)
        return (best[1], best[2]) if best else None

    def _align_new_point(self, old_xy, poly_cache, p1, dx, dy, projfn):
        """ย้ายมุมไป 'ตามแนวขอบข้าง' (ขอบที่ต่อไปหมุดที่ไม่ได้เลือก) จนชนเส้นแนว -> ขอบนั้นคงมุมเดิม
        จะตามขอบ "เฉพาะตอนขอบตั้งฉากกับเส้นแนวพอควร" เท่านั้น (par ต่ำ) — ไม่งั้นตามขอบที่เอียงตื้น
        หมุดจะ 'ไถลออกข้าง' ไกล -> ใช้ฉายตั้งฉากแทน (ปลอดภัย ขยับน้อยสุด)"""
        perp = projfn(old_xy.x(), old_xy.y())
        lmag = math.hypot(dx, dy)
        if not poly_cache or lmag == 0:
            return perp
        sd = self._side_edge_dir(old_xy, poly_cache, dx, dy)   # ทิศขอบที่ตั้งฉากกับเส้นแนวที่สุด
        if sd is None:
            return perp
        ux, uy = sd
        lux, luy = dx / lmag, dy / lmag
        par = abs(ux * lux + uy * luy)   # 1 = ขนานเส้นแนว, 0 = ตั้งฉาก
        # ตามขอบเฉพาะขอบที่ตั้งฉากกับเส้นแนว >~60° (par<0.5) -> ไถลข้างไม่เกิน ~0.58 เท่าระยะตั้งฉาก
        # OPT (2026-08-07): เดิมสร้าง QSettings + อ่าน ini ใหม่ทุกหมุด -> อ่านครั้งเดียวต่อ operation
        max_par = getattr(self, '_align_max_par', None)
        if max_par is None:
            try:
                max_par = QtCore.QSettings().value("MultiLayerEditPro/Align/EdgeFollowMaxPar", 0.5, float)
            except Exception:
                max_par = 0.5
            self._align_max_par = max_par
        if par >= max_par:
            return perp
        den = dx * uy - dy * ux
        if abs(den) < 1e-9:
            return perp
        s = ((old_xy.x() - p1.x()) * uy - (old_xy.y() - p1.y()) * ux) / den
        return QgsPointXY(p1.x() + s * dx, p1.y() + s * dy)

    def execute_point_node_alignment(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            return

        p1, p2 = self.src_pts[0], self.src_pts[1]
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag_sq = dx**2 + dy**2
        if mag_sq == 0:
            return

        def get_projected_pt(old_x, old_y):
            u = ((old_x - p1.x()) * dx + (old_y - p1.y()) * dy) / mag_sq
            return QgsPointXY(p1.x() + u * dx, p1.y() + u * dy)

        # ===== หมุดที่จะ align = หมุดที่เลือกด้วยกล่อง (box-select) =====
        picked = getattr(self, "_align_picked_ids", None)
        if picked:
            target_points = list(point_lyr.getFeatures(
                QgsFeatureRequest().setFilterFids(list(picked))))
        else:
            target_points = list(point_lyr.selectedFeatures())   # fallback: หมุดที่ select ไว้

        if not target_points:
            self.iface.messageBar().pushMessage(
                "Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน",
                level=1, duration=6)
            return

        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in (point_lyr, poly_lyr) if lyr}

        # weld node แปลงแบบ junction-aware (วัดระยะจาก "หมุดที่เลือก" -> node แปลง)
        #   ≤ AUTO_TOL      : ร่วมมุมแน่ -> รวมเข้าหมุดอัตโนมัติ (junction หลายแปลงรวมเป็นจุดเดียว)
        #   AUTO_TOL-ASK_TOL: น่าจะร่วมมุมแต่ไม่ snap -> เก็บไว้ถาม (popup ครั้งเดียว)
        #   > ASK_TOL       : คนละมุม/แปลงไม่เกี่ยว -> ไม่แตะ
        # (ค่า default จากการวัด data จริง: 74% ของมุมร่วม snap ≤2มม. • ปรับเป็น setting ได้ภายหลัง)
        s = QtCore.QSettings()
        AUTO_TOL = s.value("MultiLayerEditPro/Align/AutoMergeTol", 0.03, float)
        ASK_TOL = s.value("MultiLayerEditPro/Align/AskTol", 0.30, float)

        # ===== Prefetch ครั้งเดียว: แปลงรอบหมุดทั้งหมด + ตาราง UTM ล็อก =====
        # (เดิม _side_edge_dir + weld PASS 3 + เช็คล็อก ยิง query ต่อหมุด — บน PostgreSQL = N round-trips)
        poly_cache = (self._prefetch_align_polys(poly_lyr, target_points, max(1.0, ASK_TOL))
                      if poly_lyr else None)
        locked_map = self._locked_utm_map(poly_lyr) if poly_lyr else {}

        self._op_begin([point_lyr, poly_lyr])   # เริ่มนับ undo-step ต่อเลเยอร์
        if not point_lyr.isEditable(): point_lyr.startEditing()
        point_lyr.beginEditCommand("Align Points to Line")
        if poly_lyr:
            if not poly_lyr.isEditable(): poly_lyr.startEditing()
            poly_lyr.beginEditCommand("Align Nodes to Line")

        try:
            # ===== PASS 1: คำนวณตำแหน่งใหม่ของทุกหมุดจาก geometry "เดิม" (ก่อนแก้ไขใดๆ) =====
            moves = []   # [(pt_id, old_xy, new_pt)]
            calc_cache = {}  # Cache เพื่อให้หมุดที่ซ้อนกัน (ห่างไม่เกินมิลลิเมตร) ได้ค่า new_pt เดียวกัน
            for pt_f in target_points:
                old_xy = pt_f.geometry().asPoint()
                # ข้ามถ้าหมุดเชื่อมโยงกับแปลงที่ล็อก
                if poly_lyr and locked_map:
                    is_locked, type_str = self._is_point_feature_locked(pt_f, locked_map)
                    if is_locked and not self._admin_unlock_l1:   # ★ admin: ให้ Align ย้ายหมุด L1 ได้
                        self.iface.messageBar().pushMessage(
                            "Align Warning",
                            f"ข้ามการย้ายจุดหมุด {pt_f.id()} เนื่องจากเชื่อมโยงกับแปลงประเภท {type_str} (ถูกล็อก)",
                            level=2, duration=5)
                        continue
                
                key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
                if key in calc_cache:
                    new_pt = calc_cache[key]
                else:
                    # ย้ายตามแนวขอบข้าง (คงมุมขอบที่ต่อหมุดที่ไม่ได้เลือก) -> ถ้าทำไม่ได้ฉายตั้งฉาก
                    new_pt = self._align_new_point(old_xy, poly_cache, p1, dx, dy, get_projected_pt)
                    calc_cache[key] = new_pt
                    
                moves.append((pt_f.id(), old_xy, new_pt))

            # ===== PASS 2: ขยับหมุดทั้งหมด =====
            for pt_id, old_xy, new_pt in moves:
                point_lyr.changeGeometry(pt_id, QgsGeometry.fromPointXY(new_pt))

            # ===== PASS 3: weld node ของ polygon (junction-aware) =====
            # ใช้ spatial index จาก poly_cache ที่ prefetch ไว้ (เดิมยิง query ต่อหมุด)
            if poly_lyr and poly_cache:
                # รวบรวมผู้สมัคร: node แปลง -> (จุดปลายทาง, ระยะถึงหมุดที่ใกล้สุด)
                cand = {}      # (poly_id, vidx) -> (new_pt, dist)
                seen = set()
                for pt_id, old_xy, new_pt in moves:
                    key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
                    if key in seen:
                        continue
                    seen.add(key)
                    search_rect = QgsRectangle(old_xy.x() - ASK_TOL, old_xy.y() - ASK_TOL,
                                               old_xy.x() + ASK_TOL, old_xy.y() + ASK_TOL)
                    for pid in poly_cache['index'].intersects(search_rect):
                        if (poly_cache['types'].get(pid, "") in ("L1-RTK", "L1-TS")
                                and not self._admin_unlock_l1):   # ★ admin: weld node L1 ได้
                            continue                      # ข้ามแปลงอ้างอิงที่ล็อก (เงียบ)
                        geom = poly_cache['geoms'].get(pid)
                        if geom is None or geom.isNull():
                            continue
                        _cp, vidx, _pi, _ni, sqr = geom.closestVertex(old_xy)
                        if vidx < 0 or sqr is None:
                            continue
                        d = math.sqrt(sqr)
                        if d > ASK_TOL:
                            continue
                        vk = (pid, vidx)
                        if vk not in cand or d < cand[vk][1]:   # เก็บหมุดที่ใกล้ node นี้สุด
                            cand[vk] = (new_pt, d)

                auto = [(pid, vi, npt) for (pid, vi), (npt, d) in cand.items() if d <= AUTO_TOL]
                ask = [(pid, vi, npt, d) for (pid, vi), (npt, d) in cand.items() if AUTO_TOL < d <= ASK_TOL]

                # ★ หมุดของ "แปลงเพื่อนบ้าน" ต้องตามมุมไปด้วย (2026-08-06)
                #   เดิม weld ลากมุมของแปลง B ไปที่ตำแหน่งใหม่ของหมุดแปลง A แต่ไม่ขยับหมุดของ B เอง
                #   -> มุม B ไม่มีหมุดทับ + หมุด B ค้างอยู่จุดเก่า = ผิดกติกาเหล็กสองด้านพร้อมกัน
                try:
                    _mk_idx = self._align_marker_index(point_lyr, poly_cache.get('rect'))
                except Exception:
                    _mk_idx = {}      # คิวรีล้ม -> ไม่ลากหมุดเพื่อนบ้าน (ยัง weld ได้ตามเดิม)
                _already = {pt_id for pt_id, _o, _n in moves}      # หมุดที่ PASS 2 ย้ายไปแล้ว
                _welded_mk = 0

                def _drag_pair_markers(pid, vi, npt):
                    """ย้ายหมุด "ของแปลง pid" ที่นั่งอยู่บนมุมเดิม vi ไปที่ npt ด้วย"""
                    nonlocal _welded_mk
                    g0 = poly_cache['geoms'].get(pid)          # snapshot ก่อนแก้ -> ได้พิกัดมุมเดิม
                    u = poly_cache.get('utm', {}).get(pid, "")
                    if g0 is None or not u:
                        return
                    try:
                        v0 = g0.vertexAt(vi)
                    except Exception:
                        return
                    for mid in _mk_idx.get((round(v0.x(), 3), round(v0.y(), 3), u), []):
                        if mid in _already:
                            continue                            # ถูกย้ายไปแล้วใน PASS 2
                        if point_lyr.changeGeometry(mid, QgsGeometry.fromPointXY(npt)):
                            _already.add(mid)
                            _welded_mk += 1

                # 3a: รวมอัตโนมัติ (≤ AUTO_TOL) — junction หลายแปลงไปจุดเดียว ปิด gap
                for pid, vi, npt in auto:
                    # ★ ลากหมุดคู่เฉพาะเมื่อมุมถูกย้ายสำเร็จจริง (ไม่งั้นหมุดวิ่งไปแต่มุมอยู่ที่เดิม)
                    if poly_lyr.moveVertex(npt.x(), npt.y(), pid, vi):
                        _drag_pair_markers(pid, vi, npt)

                # 3b: มุมที่ใกล้แต่ไม่ snap -> popup ถามครั้งเดียว ว่าจะรวมให้ไหม
                if ask:
                    ds = [d for *_, d in ask]
                    msg = (f"พบ {len(ask)} มุมแปลงที่อยู่ใกล้หมุดแต่ไม่ snap "
                           f"(เหลื่อม {min(ds)*100:.1f}–{max(ds)*100:.1f} ซม.)\n\n"
                           "ต้องการ 'รวม' มุมเหล่านี้เข้ากับหมุดด้วยไหม?\n"
                           "• Yes = รวมให้ (ปิด gap ที่มุมร่วม)\n"
                           "• No = ปล่อยไว้ (ขยับเฉพาะมุมที่ snap สนิท)")
                    ans = self._ask(
                        QtWidgets.QMessageBox.Question, "พบมุมแปลงไม่ snap", msg,
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                        QtWidgets.QMessageBox.No)
                    if ans == QtWidgets.QMessageBox.Yes:
                        for pid, vi, npt, _d in ask:
                            if poly_lyr.moveVertex(npt.x(), npt.y(), pid, vi):
                                _drag_pair_markers(pid, vi, npt)

                if _welded_mk:
                    self.iface.messageBar().pushMessage(
                        "Align", f"ย้ายหมุดของแปลงข้างเคียงตามมุมที่เชื่อมด้วย {_welded_mk} จุด "
                                 "(กันมุมไม่มีหมุด/หมุดลอย)", level=0, duration=8)

            # ปิด Command ทั้งสองเลเยอร์
            point_lyr.endEditCommand()
            if poly_lyr:
                poly_lyr.endEditCommand()
            self._op_commit()   # ปิด operation -> เก็บประวัติ undo

        except Exception as e:
            point_lyr.destroyEditCommand()
            if poly_lyr: poly_lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline
            self.iface.messageBar().pushMessage("Align Error", f"เกิดข้อผิดพลาด: {e}", level=2, duration=0)
            print(f"Align Error: {e}")

        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.canvas.refresh()
        self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)


# ============================================================
#  DOL iLands — เครื่องมือคลิกเลือกแปลง + worker เรียก API
# ============================================================
from .map_tools import (BoxSelectTool, PolygonPickTool, AddNodeTool, SyncVertexTool,
                        RenameNodeTool, DeleteNodeTool)

class _FnWorker(QtCore.QThread):
    """รัน callable (blocking network/IO) ใน thread แยก — done(result) / fail(exception)
    ใช้ผ่าน MultiLayerEditPro._run_net เพื่อไม่ให้ QGIS ค้างระหว่างรอ server"""
    done = QtCore.pyqtSignal(object)
    fail = QtCore.pyqtSignal(object)

    def __init__(self, fn):
        super().__init__()
        self._fn = fn

    def run(self):
        try:
            self.done.emit(self._fn())
        except Exception as e:
            self.fail.emit(e)


class ParcelLookupWorker(QtCore.QThread):
    """ระวาง(attribute) -> PARCEL_SEQ ผ่าน ArcGIS + UDM (public, ไม่ต้อง login)"""
    done = QtCore.pyqtSignal(object)   # dict หรือ None
    fail = QtCore.pyqtSignal(str)

    def __init__(self, attrs, zone=47):
        super().__init__()
        self.attrs = attrs
        self.zone = zone

    def run(self):
        from . import dol_api
        try:
            a = self.attrs
            res = dol_api.lookup_parcel_by_rawang(
                a["m1"], a["m2"], a["m3"], a["m4"], a["scale"], a["landno"],
                zone=self.zone, near_xy=a.get("near_xy"))
            self.done.emit(res)
        except Exception as e:
            self.fail.emit(f"ค้นหาไม่สำเร็จ: {e}")
