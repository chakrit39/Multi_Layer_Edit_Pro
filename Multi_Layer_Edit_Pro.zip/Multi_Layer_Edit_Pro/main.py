import os
import re
import math
import requests
import zipfile
import io
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import (QgsProject, QgsPointXY, QgsPoint, QgsGeometry, QgsPointLocator,
                       QgsSnappingConfig, QgsTolerance, QgsLineString, QgsWkbTypes, QgsFeatureRequest)
from qgis.gui import QgsMapToolEmitPoint, QgsVertexMarker, QgsRubberBand, QgsSnapIndicator
from qgis.utils import iface

class MultiLayerEditPro:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = [] 
        self.temp_tool = None
        self.last_layers = []
        self.mode = "" 
        self.version = "1.1.1"
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล
        
        self.rubber_band = None
        self.markers = []
        self.src_pts = []
        
    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", self.action)
        self.clear_markers()

    def run(self):
        if self.dlg is None: self.create_dialog()
        self.dlg.show()

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.dlg.setWindowIcon(QtGui.QIcon(icon_path))
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro v{self.version}")
        self.dlg.setMinimumWidth(480)
        layout = QtWidgets.QVBoxLayout(self.dlg)
        
        layout.addWidget(QtWidgets.QLabel("<b>1. ตั้งค่าชั้นข้อมูล</b>"))
        self.poly_cb = QtWidgets.QComboBox(); self.point_cb = QtWidgets.QComboBox()
        layout.addWidget(QtWidgets.QLabel("เลเยอร์แปลง (Polygon):")); layout.addWidget(self.poly_cb)
        layout.addWidget(QtWidgets.QLabel("เลเยอร์หมุด (Point):")); layout.addWidget(self.point_cb)
        btn_refresh = QtWidgets.QPushButton("Refresh Layers"); btn_refresh.clicked.connect(self.refresh_layers); layout.addWidget(btn_refresh)
        self.refresh_layers()
        layout.addSpacing(10)
        
        layout.addWidget(QtWidgets.QLabel("<b>2. เลือกกลุ่มข้อมูล</b>"))
        h_sel = QtWidgets.QHBoxLayout()
        btn_c = QtWidgets.QPushButton("By Cluster ID"); btn_c.clicked.connect(lambda: self.process_selection('cluster'))
        btn_u = QtWidgets.QPushButton("By UTM"); btn_u.clicked.connect(lambda: self.process_selection('utm'))
        h_sel.addWidget(btn_c); h_sel.addWidget(btn_u); layout.addLayout(h_sel)
        layout.addSpacing(10)

        layout.addWidget(QtWidgets.QLabel("<b>3. เครื่องมือปรับแต่งทั่วไป</b>"))
        grid_tools = QtWidgets.QGridLayout()
        btn_move = QtWidgets.QPushButton("Move"); btn_move.clicked.connect(lambda: self.start_interactive('move'))
        btn_rot = QtWidgets.QPushButton("Rotate"); btn_rot.clicked.connect(lambda: self.start_interactive('rotate'))
        btn_scale = QtWidgets.QPushButton("Scale"); btn_scale.clicked.connect(lambda: self.start_interactive('scale'))
        grid_tools.addWidget(btn_move, 0, 0); grid_tools.addWidget(btn_rot, 0, 1); grid_tools.addWidget(btn_scale, 0, 2)
        layout.addLayout(grid_tools); layout.addSpacing(10)

        h_row_45 = QtWidgets.QHBoxLayout()
        v_col4 = QtWidgets.QVBoxLayout(); v_col4.addWidget(QtWidgets.QLabel("<b>4. Transform (2 Pts)</b>"))
        btn_t = QtWidgets.QPushButton("Start Transform"); btn_t.setStyleSheet("background-color: #ffccbc; font-weight: bold; padding: 10px;")
        btn_t.clicked.connect(lambda: self.start_interactive('transform')); v_col4.addWidget(btn_t); h_row_45.addLayout(v_col4)
        v_col5 = QtWidgets.QVBoxLayout(); v_col5.addWidget(QtWidgets.QLabel("<b>5. Move Node (Sync)</b>"))
        btn_node = QtWidgets.QPushButton("Move Node"); btn_node.setStyleSheet("background-color: #e8f5e9; font-weight: bold; padding: 10px;")
        btn_node.clicked.connect(lambda: self.start_interactive('modify_node')); v_col5.addWidget(btn_node); h_row_45.addLayout(v_col5)
        layout.addLayout(h_row_45); layout.addSpacing(10)

        h_row_67 = QtWidgets.QHBoxLayout()
        v_col6 = QtWidgets.QVBoxLayout(); v_col6.addWidget(QtWidgets.QLabel("<b>6. จัดกลุ่ม Cluster</b>"))
        btn_group_id = QtWidgets.QPushButton("Sync Cluster ID"); btn_group_id.setStyleSheet("background-color: #e3f2fd; padding: 10px;")
        btn_group_id.clicked.connect(self.group_cluster_ids); v_col6.addWidget(btn_group_id); h_row_67.addLayout(v_col6)
        
        v_col7 = QtWidgets.QVBoxLayout()
        v_col7.addWidget(QtWidgets.QLabel("<b>7. ตั้งค่า Score</b>"))
        h_score_layout = QtWidgets.QHBoxLayout()
        # ปุ่ม Score 1 สีเขียว
        btn_score_1 = QtWidgets.QPushButton("Score = 1")
        btn_score_1.setStyleSheet("""
            QPushButton {
                background-color: #c8e6c9; 
                font-weight: bold; 
                color: #1b5e20;
                padding: 10px;
            }
            QPushButton:hover { background-color: #a5d6a7; }
        """)
        btn_score_1.clicked.connect(lambda: self.set_score_value(1))
        
        # ปุ่ม Score 0 สีแดง
        btn_score_0 = QtWidgets.QPushButton("Score = 0")
        btn_score_0.setStyleSheet("""
            QPushButton {
                background-color: #ffcdd2; 
                font-weight: bold; 
                color: #b71c1c;
                padding: 10px;
            }
            QPushButton:hover { background-color: #ef9a9a; }
        """)
        btn_score_0.clicked.connect(lambda: self.set_score_value(0))
        h_score_layout.addWidget(btn_score_1)
        h_score_layout.addWidget(btn_score_0)
        v_col7.addLayout(h_score_layout)
        h_row_67.addLayout(v_col7)
        layout.addLayout(h_row_67)
        
        
        layout.addSpacing(10)
        btn_align = QtWidgets.QPushButton("📏 Align Selected Points to Line"); btn_align.setStyleSheet("padding: 10px;")
        btn_align.clicked.connect(self.start_align_tool)
        layout.addWidget(btn_align)

        layout.addSpacing(10)
        h_ctrl = QtWidgets.QHBoxLayout()
        btn_rs = QtWidgets.QPushButton("✖ Reset / Cancel"); btn_rs.setStyleSheet("padding: 10px;"); btn_rs.clicked.connect(self.cancel_transform) 
        btn_un = QtWidgets.QPushButton("↺ Undo Last"); btn_un.setStyleSheet("padding: 10px;"); btn_un.clicked.connect(self.undo_transform) 
        h_ctrl.addWidget(btn_rs); h_ctrl.addWidget(btn_un); layout.addLayout(h_ctrl)
        
        btn_s = QtWidgets.QPushButton("💾 Save Changes (Commit)"); btn_s.setStyleSheet("background-color: #c8e6c9; font-weight: bold; padding: 10px; color: #1b5e20;")
        btn_s.clicked.connect(self.save_all_changes); layout.addWidget(btn_s)

        layout.addSpacing(5)
        line = QtWidgets.QFrame(); line.setFrameShape(QtWidgets.QFrame.HLine); layout.addWidget(line)
        layout.addSpacing(5)
        btn_upd = QtWidgets.QPushButton("🚀 Check Update"); btn_upd.clicked.connect(self.update_plugin); layout.addWidget(btn_upd)
        lbl_author = QtWidgets.QLabel("จัดทำโดย: ชาคฤตย์ จันทรสุกศรี"); lbl_dept = QtWidgets.QLabel("กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        font = QtGui.QFont(); font.setPointSize(9); lbl_author.setFont(font); lbl_dept.setFont(font)
        lbl_author.setAlignment(QtCore.Qt.AlignCenter)
        lbl_dept.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(lbl_author); layout.addWidget(lbl_dept)
    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                lyr.selectByIds(ids)
        self.iface.mapCanvas().refresh()

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def refresh_layers(self):
        self.poly_cb.clear(); self.point_cb.clear()
        for lyr in QgsProject.instance().mapLayers().values():
            self.poly_cb.addItem(lyr.name(), lyr.id()); self.point_cb.addItem(lyr.name(), lyr.id())
    def setup_snapping(self):
        self.canvas = self.iface.mapCanvas()
        config = QgsProject.instance().snappingConfig()
        if not config.enabled():
            config.setEnabled(True)
            config.setMode(QgsSnappingConfig.AllLayers)
            # ปรับความแรงในการดูด (Tolerance) เป็น 15-20 pixels
            config.setTolerance(20) 
            config.setUnits(QgsTolerance.Pixels)
            # ให้ Snap ทั้งจุด (Vertex) และเส้น (Segment)
            config.setType(QgsSnappingConfig.VertexAndSegment) 
            QgsProject.instance().setSnappingConfig(config)
        
        self.snap_utils = self.canvas.snappingUtils()
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        
    def start_interactive(self, mode):
        # 1. เลือก UTM ก่อน
        self.process_selection('utm')
        
        # 2. เช็คว่ามีอะไรถูกเลือกไหม
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_lyr or poly_lyr.selectedFeatureCount() == 0:
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกแปลงที่ต้องการก่อน", level=2, duration=10)
            return

        # 3. เคลียร์ Marker เก่า (แต่ไม่เคลียร์ Selection!)
        self.clear_markers()
        self.src_pts = []
        
        # 4. ตั้งค่า Tool
        self.mode = mode
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.temp_tool.canvasMoveEvent = self.handle_generic_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_click(self, point, button):
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        
        # 2. เลือกพิกัด: ถ้า Snap ติดใช้จุด Snap ถ้าไม่ติดใช้ point (ที่ว่าง) ตรงๆ
        pt = match.point() if match.isValid() and match.point().x() != 0 else point
        
        # กำหนดสี Marker: Snap=แดง, ที่ว่าง=น้ำเงิน
        color = QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255)

        # 3. วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setPenWidth(4)
        m.setColor(color)
        m.setIconType(QgsVertexMarker.ICON_X)
        self.markers.append(m)
        self.src_pts.append(QgsPointXY(pt.x(), pt.y())) # บังคับเป็น PointXY
        
        # 4. ตรวจสอบจำนวนจุดตามโหมด
        limit = {'move': 2, 'modify_node': 2, 'rotate': 3, 'scale': 3, 'transform': 4}.get(self.mode, 2)
        
        if len(self.src_pts) >= limit:
            self.execute_tool()
            
    def handle_generic_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือทั่วไป (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            # แทนที่จะใส่ None ให้ใช้ Match ว่างๆ แทนครับ
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            
    def execute_tool(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        
        if not layers:
            self.cancel_transform()
            return
            
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self.last_layers = layers
        p = self.src_pts

        for lyr in layers:
            if not lyr.isEditable(): lyr.startEditing()
            lyr.beginEditCommand(f"MLEP {self.mode}")
            
            for f in lyr.selectedFeatures():
                geom = f.geometry()
                if geom.isNull(): continue

                # --- 1. Move ---
                if self.mode == 'move' and len(p) >= 2:
                    dx, dy = p[1].x() - p[0].x(), p[1].y() - p[0].y()
                    geom.translate(dx, dy)
                    lyr.changeGeometry(f.id(), geom)

                # --- 2. Rotate (ใส่ลบหน้ามุมตามที่ตกลงกัน) ---
                elif self.mode == 'rotate' and len(p) >= 3:
                    a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                    a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
                    geom.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))
                    lyr.changeGeometry(f.id(), geom)

                # --- 3. Scale (ปรับใหม่ให้ชัวร์) ---
                elif self.mode == 'scale' and len(p) >= 3:
                    d1 = math.sqrt(p[0].sqrDist(p[1]))
                    d2 = math.sqrt(p[0].sqrDist(p[2]))
                    if d1 > 0:
                        s = d2 / d1
                        # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                        geom.translate(-p[0].x(), -p[0].y())
                        matrix = QtGui.QTransform(); matrix.scale(s, s)
                        geom.transform(matrix)
                        geom.translate(p[0].x(), p[0].y())
                        lyr.changeGeometry(f.id(), geom)

                # --- 4. Transform ---
                elif self.mode == 'transform' and len(p) >= 4:
                    self.apply_similarity_direct(lyr, f, p)

                # --- 5. Move Node (แก้ Error sqrDist) ---
                elif self.mode == 'modify_node' and len(p) >= 2:
                    threshold = 0.001
                    # แปลง p[0] เป็น QgsPoint เพื่อให้เทียบกับ v (QgsPoint) ได้
                    p0_fixed = QgsPoint(p[0].x(), p[0].y())
                    ver_idx = 0
                    for v in geom.vertices():
                        # ใช้ distance (จาก QgsPoint) แทน sqrDist (จาก QgsPointXY)
                        if v.distance(p0_fixed) < threshold:
                            lyr.moveVertex(p[1].x(), p[1].y(), f.id(), ver_idx)
                        ver_idx += 1
            
            lyr.endEditCommand()

        self.iface.mapCanvas().refresh()
        self.clear_markers()
        self.src_pts = []
        if self.mode == 'transform' :
            self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def apply_similarity_direct(self, lyr, f, p):
        """คำนวณ Transform แบบ Matrix (Similarity)"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        # x' = ax - by + tx , y' = bx + ay + ty
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        lyr.changeGeometry(f.id(), geom)

    def apply_similarity_geometry(self, lyr, f, p):
        """แก้ไขข้อ 4: ใช้ Matrix Transform ป้องกันรูปหาย/จุดรวมกัน"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        lyr.changeGeometry(f.id(), geom)

    def set_score_value(self, value):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return

        # เก็บรายชื่อเลเยอร์ไว้ให้ปุ่ม Undo รู้ว่าจะต้องไปย้อนที่เลเยอร์ไหน
        self.last_layers = layers 
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        for lyr in layers:
            # ตรวจสอบว่าเลเยอร์อยู่ในโหมดแก้ไขหรือไม่
            if not lyr.isEditable(): 
                lyr.startEditing()
            
            # เริ่มบันทึกคำสั่งสำหรับ Undo
            lyr.beginEditCommand(f"Change Score to {value}")
            
            # แทนที่การเช็ค index แบบเดิม
            idx = -1
            for i, field in enumerate(lyr.fields()):
                if field.name().lower() == 'score':
                    idx = i
                    break
            
            if idx != -1:
                for f in lyr.selectedFeatures():
                    lyr.changeAttributeValue(f.id(), idx, value)
                lyr.endEditCommand() # ปิดคำสั่ง (จะถูกส่งเข้า Undo Stack ของ QGIS)
            else:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"ไม่พบฟิลด์ Score ใน {lyr.name()}", level=3, duration=10)

        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def group_cluster_ids(self):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        fields = [f.name() for f in poly_layer.fields()]
        target_field = next((f for f in fields if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
        if not target_field: return
        main_val = poly_layer.selectedFeatures()[0][target_field]
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        for lyr in layers:
            lyr.beginEditCommand("Group Cluster ID")
            lyr_f = [f.name() for f in lyr.fields()]
            lyr_t = next((f for f in lyr_f if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
            if lyr_t:
                idx = lyr.fields().indexFromName(lyr_t)
                for f in lyr.selectedFeatures(): lyr.changeAttributeValue(f.id(), idx, main_val)
            lyr.endEditCommand()
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        """ล้างค่าหน้าจอและทำลายตัวช่วย Snap อย่างปลอดภัย"""
        if hasattr(self, 'snap_indicator') and self.snap_indicator:
            # ล้างสัญลักษณ์บนหน้าจอก่อนทำลาย Object
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            self.snap_indicator = None 
            
        self.clear_rubber_band()
        
        if hasattr(self, 'markers'):
            for m in self.markers:
                if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []
        self.src_pts = []
        
        self.iface.mapCanvas().refresh()
        self.iface.actionSelect().trigger()

    def undo_transform(self):
        """ย้อนกลับการแก้ไขล่าสุดในทุกเลเยอร์ที่ถูกบันทึกไว้ใน self.last_layers"""
        if not self.last_layers:
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการล่าสุดให้ย้อนกลับ", level=2, duration=10)
            return

        for lyr in self.last_layers:
            if lyr and lyr.isEditable():
                # สั่งให้ Stack ของเลเยอร์นั้นๆ ย้อนกลับ 1 ขั้น
                lyr.undoStack().undo()
        
        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดเรียบร้อยแล้ว", level=1, duration=10)

    def save_all_changes(self):
        for lyr in [QgsProject.instance().mapLayer(self.poly_cb.currentData()), QgsProject.instance().mapLayer(self.point_cb.currentData())]:
            if lyr and lyr.isEditable(): lyr.commitChanges(); lyr.startEditing()
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3, duration=3)

    def update_plugin(self):
        V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
        Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"
        try:
            res = requests.get(V_URL, timeout=5)
            if res.text.strip() > self.version:
                if QtWidgets.QMessageBox.question(self.dlg, "Update", "พบเวอร์ชันใหม่ ต้องการอัปเดตไหม?") == QtWidgets.QMessageBox.Yes:
                    r = requests.get(Z_URL); z = zipfile.ZipFile(io.BytesIO(r.content))
                    z.extractall(os.path.dirname(os.path.dirname(__file__)))
                    QtWidgets.QMessageBox.information(self.dlg, "Done", "อัปเดตแล้ว! กรุณา Restart QGIS")
            else: QtWidgets.QMessageBox.information(self.dlg, "Update", "คุณใช้เวอร์ชันล่าสุดแล้ว")
        except: pass

    def process_selection(self, mode):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        sel = poly_layer.selectedFeatures()
        if not sel: return
        fields = [f.name() for f in poly_layer.fields()]
        target = next((f for f in fields if f.lower() in (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])), None)
        if not target: return
        v_list = [f"'{f[target]}'" if isinstance(f[target], str) else str(f[target]) for f in sel if f[target] is not None]
        if v_list:
            expr = f'"{target}" IN ({",".join(list(set(v_list)))})'
            poly_layer.selectByExpression(expr)
            if point_layer: point_layer.selectByExpression(expr)
            self.iface.mapCanvas().refresh()
            
    def start_align_tool(self):
        self.cancel_transform()
        self.mode = 'align_point_driven'
        self.setup_snapping() # เรียกใช้ระบบ Snap  
        self.temp_tool = QgsMapToolEmitPoint(self.canvas)
        self.temp_tool.canvasClicked.connect(self.handle_align_click)
        self.temp_tool.canvasMoveEvent = self.handle_align_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_align_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือ Align (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
        # แก้จาก self.snapping_utils เป็น self.snap_utils
        if not hasattr(self, 'snap_utils'):
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # Logic สำหรับวาด Rubber Band เส้นยางยืด (ถ้ามี)
        if hasattr(self, 'rubber_band') and self.rubber_band and len(self.src_pts) == 1:
            curr_pt = match.point() if match.isValid() else event.mapPoint()
            self.rubber_band.removeLastPoint()
            self.rubber_band.addPoint(curr_pt)
            
    def handle_align_click(self, point, button):
        """จัดการการคลิกจุด P1 และ P2 สำหรับสร้างแนวเส้น (รองรับที่ว่าง)"""
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        # 2. ถ้า Snap ไม่ติด ให้ใช้พิกัดที่คลิกจริง (point)
        pt = match.point() if match.isValid() else point
        
        self.src_pts.append(QgsPointXY(pt.x(), pt.y()))
        
        # วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        m.setPenWidth(5)
        self.markers.append(m)
        
        if len(self.src_pts) == 1:
            self.clear_rubber_band()
            self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            self.rubber_band.setColor(QtGui.QColor(255, 0, 0))
            self.rubber_band.setWidth(2)
            self.rubber_band.addPoint(pt)
            self.rubber_band.addPoint(pt)

        if len(self.src_pts) == 2:
            self.execute_point_node_alignment()
            # ทำความสะอาดหน้าจอหลังเสร็จงาน
            self.clear_markers()
            self.clear_rubber_band()
            self.src_pts = []
            
    def clear_rubber_band(self):
        """ลบ Rubber Band ออกจากหน้าจอและหน่วยความจำอย่างเด็ดขาด"""
        if self.rubber_band:
            self.rubber_band.hide() # ซ่อนทันที
            self.iface.mapCanvas().scene().removeItem(self.rubber_band) # ลบออกจาก Scene
            self.rubber_band = None # คืนค่าว่าง
            
    def execute_point_node_alignment(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        if not point_lyr or point_lyr.selectedFeatureCount() == 0:
            return

        # --- แก้ไขจุดที่ทำให้เกิด NameError ---
        self.last_layers = []
        if point_lyr: self.last_layers.append(point_lyr)
        if poly_lyr: self.last_layers.append(poly_lyr)
        
        # ใช้ self.last_layers แทนคำว่า layers
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in self.last_layers}
        
        p1, p2 = self.src_pts[0], self.src_pts[1]
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag_sq = dx**2 + dy**2
        if mag_sq == 0: return

        def get_projected_pt(old_x, old_y):
            u = ((old_x - p1.x()) * dx + (old_y - p1.y()) * dy) / mag_sq
            return QgsPointXY(p1.x() + u * dx, p1.y() + u * dy)

        # --- ส่วนแก้ไข: เปิด Edit Mode และ Command ให้ทั้งสองเลเยอร์ ---
        if not point_lyr.isEditable(): point_lyr.startEditing()
        point_lyr.beginEditCommand("Align Points to Line")
        
        if poly_lyr:
            if not poly_lyr.isEditable(): poly_lyr.startEditing()
            poly_lyr.beginEditCommand("Align Nodes to Line") # เพิ่มบรรทัดนี้

        try:
            for pt_f in point_lyr.selectedFeatures():
                old_geom = pt_f.geometry()
                old_xy = old_geom.asPoint()
                new_pt = get_projected_pt(old_xy.x(), old_xy.y())
                
                # ย้าย Point
                point_lyr.changeGeometry(pt_f.id(), QgsGeometry.fromPointXY(new_pt))

                # ย้าย Node ใน Polygon
                if poly_lyr:
                    search_rect = old_geom.buffer(0.01, 5).boundingBox()
                    p_old_obj = QgsPoint(old_xy.x(), old_xy.y())
                    
                    for poly_f in poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(search_rect)):
                        geom = poly_f.geometry()
                        ver_idx = 0
                        for v in geom.vertices():
                            if v.distance(p_old_obj) < 0.005:
                                # คำสั่งนี้จะถูกบันทึกเข้า Undo Stack ของ Polygon แล้ว
                                poly_lyr.moveVertex(new_pt.x(), new_pt.y(), poly_f.id(), ver_idx)
                            ver_idx += 1

            # ปิด Command ทั้งสองเลเยอร์
            point_lyr.endEditCommand()
            if poly_lyr:
                poly_lyr.endEditCommand() # เพิ่มบรรทัดนี้
                
        except Exception as e:
            point_lyr.destroyEditCommand()
            if poly_lyr: poly_lyr.destroyEditCommand()
            print(f"Align Error: {e}")

        self.canvas.refresh()
        self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)