import os
import math
import requests
import zipfile
import io
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import (QgsProject, QgsPointXY, QgsGeometry, QgsPointLocator,
                       QgsSnappingConfig, QgsTolerance, QgsWkbTypes,
                       QgsFeatureRequest, QgsVectorLayer)
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsVertexMarker, QgsRubberBand, QgsSnapIndicator
from qgis.core import QgsRectangle, QgsCoordinateTransform
from qgis.utils import iface


class MultiLayerEditPro:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = [] 
        self.temp_tool = None
        self.last_layers = []
        self.mode = "" 
        self.version = "1.3.5"
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล
        
        self.rubber_band = None
        self.markers = []
        self.src_pts = []
        self._dol_highlight = None  # rubber band ไฮไลต์แปลงที่ค้นหา
        self._align_picked_ids = set()  # หมุดที่เลือกด้วยกล่อง (Align)
        self._align_markers = []
        self._shortcuts = []  # QShortcut ที่ผูกไว้

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", self.action)
        self.clear_markers()
        self._dol_clear_highlight()
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None); sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        if hasattr(self, 'temp_tool') and self.temp_tool:
            canvas = self.iface.mapCanvas()
            if canvas and canvas.mapTool() == self.temp_tool:
                canvas.unsetMapTool(self.temp_tool)

    def run(self):
        if self.dlg is None: self.create_dialog()
        self.dlg.show()

    # ============ Shortcut ปุ่มต่าง ๆ ============
    def _shortcut_actions(self):
        """รายการ action ที่ตั้ง shortcut ได้: (id, label, callable)"""
        return [
            ("dol_search", "🔍 ค้นหาภาพลักษณ์", self.start_dol_search),
            ("by_cluster", "By Cluster ID", lambda: self.process_selection('cluster')),
            ("by_utm", "By UTM", lambda: self.process_selection('utm')),
            ("move", "Move", lambda: self.start_interactive('move')),
            ("rotate", "Rotate", lambda: self.start_interactive('rotate')),
            ("scale", "Scale", lambda: self.start_interactive('scale')),
            ("transform", "Transform (2 จุด)", lambda: self.start_interactive('transform')),
            ("modify_node", "Move Node (Sync)", lambda: self.start_interactive('modify_node')),
            ("align", "Align Points to Line", self.start_align_tool),
            ("sync_cluster", "Sync Cluster ID", self.group_cluster_ids),
            ("score1", "Score = 1", lambda: self.set_score_value(1)),
            ("score0", "Score = 0", lambda: self.set_score_value(0)),
            ("reset", "Reset", self.cancel_transform),
            ("undo", "Undo", self.undo_transform),
            ("save", "บันทึก (Commit)", self.save_all_changes),
        ]

    def _load_shortcuts(self):
        """อ่าน QSettings -> สร้าง QShortcut ผูกกับ main window (ทำงานทั้งแอปขณะใช้ QGIS)"""
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None); sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        mw = self.iface.mainWindow()
        for aid, label, slot in self._shortcut_actions():
            seq = s.value(k + aid, "", str)
            if not seq:
                continue
            sc = QtWidgets.QShortcut(QtGui.QKeySequence(seq), mw)
            sc.setContext(QtCore.Qt.ApplicationShortcut)
            sc.activated.connect(slot)
            self._shortcuts.append(sc)

    def open_shortcut_settings(self):
        """popup ตั้งค่า shortcut แต่ละปุ่ม"""
        dlg = QtWidgets.QDialog(self.dlg)
        dlg.setWindowTitle("⌨ ตั้งค่า Shortcut")
        dlg.setMinimumWidth(380)
        v = QtWidgets.QVBoxLayout(dlg)
        v.addWidget(QtWidgets.QLabel(
            "คลิกในช่องแล้วกดคีย์ที่ต้องการ (เว้นว่าง = ไม่ใช้)\nทำงานทั้งแอปขณะใช้ QGIS"))
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        form = QtWidgets.QFormLayout()
        editors = {}
        for aid, label, slot in self._shortcut_actions():
            ed = QtWidgets.QKeySequenceEdit(QtGui.QKeySequence(s.value(k + aid, "", str)))
            editors[aid] = ed
            btn_clr = QtWidgets.QPushButton("✖"); btn_clr.setFixedWidth(28)
            btn_clr.clicked.connect(ed.clear)
            row = QtWidgets.QHBoxLayout(); row.addWidget(ed, 1); row.addWidget(btn_clr, 0)
            w = QtWidgets.QWidget(); w.setLayout(row)
            form.addRow(label + ":", w)
        inner = QtWidgets.QWidget(); inner.setLayout(form)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(inner)
        v.addWidget(scroll)
        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        v.addWidget(btns)
        btns.accepted.connect(dlg.accept); btns.rejected.connect(dlg.reject)
        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            seen, dup = {}, set()
            for aid, ed in editors.items():
                seq = ed.keySequence().toString()
                if seq:
                    if seq in seen:
                        dup.add(seq)
                    seen[seq] = aid
                s.setValue(k + aid, seq)
            self._load_shortcuts()
            msg = "บันทึก shortcut แล้ว ✅"
            if dup:
                msg += f"\n⚠️ มีคีย์ซ้ำ: {', '.join(dup)} (อาจทำงานไม่ครบ)"
            QtWidgets.QMessageBox.information(self.dlg, "Shortcut", msg)

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.dlg.setWindowIcon(QtGui.QIcon(icon_path))
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro {self.version}")
        self.dlg.setMinimumWidth(360)
        root = QtWidgets.QVBoxLayout(self.dlg)
        root.setSpacing(6)

        def mkbtn(text, slot, style="", tip=""):
            b = QtWidgets.QPushButton(text)
            b.setStyleSheet(style or "padding:5px;")
            b.setFixedHeight(34)   # สูงเท่ากันทุกปุ่ม (กันไทย/Latin/emoji เรนเดอร์สูงไม่เท่า)
            if tip:
                b.setToolTip(tip)
            b.clicked.connect(slot)
            return b

        # ---------- ชั้นข้อมูล (กระทัดรัด) ----------
        grp_layer = QtWidgets.QGroupBox("ชั้นข้อมูล")
        gl = QtWidgets.QGridLayout(grp_layer)
        gl.setHorizontalSpacing(6)
        gl.setVerticalSpacing(4)
        gl.setColumnStretch(0, 0)   # label ชิดซ้าย ไม่ยืด
        gl.setColumnStretch(1, 1)   # combo ดูดพื้นที่ว่างทั้งหมด -> label ชิด combo
        self.poly_cb = QtWidgets.QComboBox()
        self.point_cb = QtWidgets.QComboBox()
        gl.addWidget(QtWidgets.QLabel("แปลง:"), 0, 0)
        gl.addWidget(self.poly_cb, 0, 1)
        gl.addWidget(QtWidgets.QLabel("หมุด:"), 1, 0)
        gl.addWidget(self.point_cb, 1, 1)
        btn_refresh = mkbtn("🔄", self.refresh_layers, tip="Refresh Layers")
        btn_refresh.setFixedWidth(36)
        gl.addWidget(btn_refresh, 0, 2, 2, 1)
        root.addWidget(grp_layer)
        self.refresh_layers()

        # ---------- DOL search (เด่น เต็มกว้าง, public) ----------
        root.addWidget(mkbtn(
            "🔍 ค้นหาภาพลักษณ์", self.start_dol_search,
            "background-color:#fff3e0; font-weight:bold; padding:8px; color:#e65100;"))

        # ---------- เลือก & ปรับแต่ง (หน้าเดียว) ----------
        grp_edit = QtWidgets.QGroupBox("เลือก / ปรับแต่ง")
        ve = QtWidgets.QVBoxLayout(grp_edit)
        ve.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("By Cluster ID", lambda: self.process_selection('cluster')))
        r.addWidget(mkbtn("By UTM", lambda: self.process_selection('utm')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Move", lambda: self.start_interactive('move')))
        r.addWidget(mkbtn("Rotate", lambda: self.start_interactive('rotate')))
        r.addWidget(mkbtn("Scale", lambda: self.start_interactive('scale')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Transform (2 จุด)", lambda: self.start_interactive('transform'),
                          "background-color:#ffccbc; font-weight:bold; padding:6px;"))
        r.addWidget(mkbtn("Move Node (Sync)", lambda: self.start_interactive('modify_node'),
                          "background-color:#e8f5e9; font-weight:bold; padding:6px;"))
        ve.addLayout(r)
        ve.addWidget(mkbtn("📏 Align Points to Line", self.start_align_tool))
        root.addWidget(grp_edit)

        # ---------- จัดกลุ่ม / Score ----------
        grp_grp = QtWidgets.QGroupBox("จัดกลุ่ม / Score")
        vg = QtWidgets.QVBoxLayout(grp_grp)
        vg.setSpacing(5)
        vg.addWidget(mkbtn("🔗 Sync Cluster ID", self.group_cluster_ids,
                           "background-color:#e3f2fd; padding:6px;"))
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Score = 1", lambda: self.set_score_value(1),
                          "background-color:#c8e6c9; font-weight:bold; color:#1b5e20; padding:6px;"))
        r.addWidget(mkbtn("Score = 0", lambda: self.set_score_value(0),
                          "background-color:#ffcdd2; font-weight:bold; color:#b71c1c; padding:6px;"))
        vg.addLayout(r)
        root.addWidget(grp_grp)

        # ---------- แถบ action (เห็นตลอด) ----------
        r = QtWidgets.QHBoxLayout()
        btn_reset = mkbtn("✖ Reset", self.cancel_transform)
        btn_undo = mkbtn("↺ Undo", self.undo_transform)
        for _b in (btn_reset, btn_undo):
            _b.setFixedHeight(34)   # บังคับสูงเท่ากัน (กัน emoji เรนเดอร์ไม่เท่า)
            r.addWidget(_b, 1)
        root.addLayout(r)
        root.addWidget(mkbtn("💾 บันทึก (Commit)", self.save_all_changes,
                             "background-color:#c8e6c9; font-weight:bold; padding:8px; color:#1b5e20;"))

        # ---------- footer ----------
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        root.addWidget(line)
        rf = QtWidgets.QHBoxLayout()
        btn_sc = mkbtn("⌨ ตั้งค่า Shortcut", self.open_shortcut_settings)
        btn_up = mkbtn("🚀 Check Update", self.update_plugin)
        for _b in (btn_sc, btn_up):
            _b.setFixedHeight(34)   # สูงเท่ากัน
            rf.addWidget(_b, 1)     # stretch เท่ากัน -> กว้างเท่ากัน
        root.addLayout(rf)
        lbl = QtWidgets.QLabel("ชาคฤตย์ จันทรสุกศรี · กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        f = QtGui.QFont()
        f.setPointSize(8)
        lbl.setFont(f)
        lbl.setAlignment(QtCore.Qt.AlignCenter)
        root.addWidget(lbl)
        self._load_shortcuts()   # ผูก shortcut ที่บันทึกไว้

    # ============ DOL iLands: ค้นหาโฉนดด้วยเลขระวาง ============
    def start_dol_search(self):
        """เปิด map tool: เปลี่ยน cursor ให้คลิกเลือกแปลงที่จะค้นหา (public ไม่ต้อง login)"""
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if lyr is None:
            QtWidgets.QMessageBox.warning(
                self.dlg, "ไม่พบเลเยอร์", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        try:
            if lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
                QtWidgets.QMessageBox.warning(
                    self.dlg, "เลเยอร์ไม่ถูกต้อง", f"เลเยอร์ '{lyr.name()}' ไม่ใช่ Polygon")
                return
        except Exception:
            pass
        self._dol_clear_highlight()
        canvas = self.iface.mapCanvas()
        # ล็อกให้คลิก/ไฮไลต์ได้เฉพาะแปลงในเลเยอร์ที่เลือกในปลั๊กอินเท่านั้น
        self.temp_tool = PolygonPickTool(
            canvas, lyr, self._on_polygon_picked, self._dol_on_hover)
        canvas.setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "DOL", f"คลิกบนแปลงในเลเยอร์ '{lyr.name()}' เพื่อค้นหาโฉนด (Esc เพื่อยกเลิก)")

    def _on_polygon_picked(self, feat, layer):
        """อ่าน attribute UTM ของแปลงที่คลิก (จากเลเยอร์ที่เลือก) แล้วยิงค้นหา"""
        def gv(name):
            try:
                if feat.fields().indexOf(name) < 0:
                    return ""
                v = feat[name]
                return "" if v is None else str(v).strip()
            except Exception:
                return ""

        m1, m2, m3 = gv("UTMMAP1"), gv("UTMMAP2"), gv("UTMMAP3")
        m4 = gv("UTMMAP4") or "00"
        scale = gv("UTMSCALE")
        landno = gv("LANDNO")
        self.iface.actionSelect().trigger()  # คืน cursor ปกติ

        # ไฮไลต์แปลงที่คลิกทันที (กรอบแดง)
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

        if not m1 or not m2 or not m3 or not scale or not landno:
            self._dol_clear_highlight()
            QtWidgets.QMessageBox.warning(
                self.dlg, "ข้อมูลแปลงไม่ครบ",
                f"แปลงนี้ไม่มี attribute ระวางครบ\n"
                f"UTMMAP={m1} {m2} {m3} {m4} | SCALE={scale} | LANDNO={landno}")
            return

        attrs = {"m1": m1, "m2": m2, "m3": m3, "m4": m4,
                 "scale": scale, "landno": landno}

        self._dol_busy = QtWidgets.QProgressDialog(
            f"กำลังค้นหา PARCEL_SEQ...\nระวาง {m1} {m2} {m3}-{m4} ที่ดิน {landno}",
            None, 0, 0, self.dlg)
        self._dol_busy.setWindowTitle("DOL")
        self._dol_busy.setCancelButton(None)
        self._dol_busy.setWindowModality(QtCore.Qt.WindowModal)
        self._dol_busy.show()

        self._dol_worker = ParcelLookupWorker(attrs, zone=47)
        self._dol_worker.done.connect(self._on_dol_done)
        self._dol_worker.fail.connect(self._on_dol_fail)
        self._dol_worker.start()

    def _on_dol_done(self, res):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()  # รันเสร็จ -> ลบไฮไลต์
        if not res:
            QtWidgets.QMessageBox.information(
                self.dlg, "ไม่พบแปลง", "ไม่พบแปลงในระบบ (ตรวจเลขระวาง / zone UTM)")
            return

        # เจอแล้ว -> เปิดภาพลักษณ์ทันที (ไม่เด้ง popup)
        if res.get("doc_url"):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(res["doc_url"]))
        warn = "" if res.get("verified") else "  ⚠️ MAP_PARCEL_SEQ ไม่ตรง"
        self.iface.messageBar().pushMessage(
            "DOL", f"PARCEL_SEQ {res.get('parcel_seq')} | โฉนด {res.get('parcel_no')} "
                   f"({res.get('city','')}) — เปิดภาพลักษณ์แล้ว{warn}", level=3, duration=8)

    def _on_dol_fail(self, msg):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()
        QtWidgets.QMessageBox.critical(self.dlg, "DOL ผิดพลาด", msg)

    def _dol_highlight_feature(self, geom, layer):
        """ไฮไลต์แปลงบนแผนที่ด้วยกรอบแดง"""
        self._dol_clear_highlight()
        if geom is None or geom.isEmpty():
            return
        canvas = self.iface.mapCanvas()
        rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(255, 0, 0))
        rb.setFillColor(QtGui.QColor(255, 0, 0, 50))
        rb.setWidth(3)
        rb.setToGeometry(geom, layer)
        rb.show()
        self._dol_highlight = rb
        canvas.refresh()

    def _dol_clear_highlight(self):
        rb = getattr(self, "_dol_highlight", None)
        if rb is not None:
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
            self._dol_highlight = None

    def _dol_on_hover(self, feat, layer):
        """ไฮไลต์แปลงใต้เมาส์ก่อนคลิก (ตัวช่วยตัดสินใจ)"""
        if feat is None:
            self._dol_clear_highlight()
            return
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                lyr.selectByIds(ids)
        self.iface.mapCanvas().refresh()

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def refresh_layers(self):
        # แปลง = เฉพาะเลเยอร์ Polygon, หมุด = เฉพาะเลเยอร์ Point
        self.poly_cb.clear(); self.point_cb.clear()
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                gt = lyr.geometryType()   # มีเฉพาะ vector layer (raster -> error -> ข้าม)
            except Exception:
                continue
            if gt == QgsWkbTypes.PolygonGeometry:
                self.poly_cb.addItem(lyr.name(), lyr.id())
            elif gt == QgsWkbTypes.PointGeometry:
                self.point_cb.addItem(lyr.name(), lyr.id())
    def setup_snapping(self):
        self.canvas = self.iface.mapCanvas()
        config = QgsProject.instance().snappingConfig()
        if not config.enabled():
            config.setEnabled(True)
            config.setMode(QgsSnappingConfig.AllLayers)
            # ปรับความแรงในการดูด (Tolerance) เป็น 15-20 pixels
            config.setTolerance(20) 
            config.setUnits(QgsTolerance.Pixels)
            # ให้ Snap ทั้งจุด (Vertex) และเส้น (Segment)
            config.setType(QgsSnappingConfig.VertexAndSegment) 
            QgsProject.instance().setSnappingConfig(config)
        
        self.snap_utils = self.canvas.snappingUtils()
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        
    def start_interactive(self, mode):
        # 1. เลือก UTM ก่อน
        self.process_selection('utm')
        
        # 2. เช็คว่ามีอะไรถูกเลือกไหม
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_lyr or poly_lyr.selectedFeatureCount() == 0:
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกแปลงที่ต้องการก่อน", level=2, duration=10)
            return

        # 3. เคลียร์ Marker เก่า (แต่ไม่เคลียร์ Selection!)
        self.clear_markers()
        self.src_pts = []
        
        # 4. ตั้งค่า Tool
        self.mode = mode
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.temp_tool.canvasMoveEvent = self.handle_generic_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_click(self, point, button):
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        
        # 2. เลือกพิกัด: ถ้า Snap ติดใช้จุด Snap ถ้าไม่ติดใช้ point (ที่ว่าง) ตรงๆ
        pt = match.point() if match.isValid() and match.point().x() != 0 else point
        
        # กำหนดสี Marker: Snap=แดง, ที่ว่าง=น้ำเงิน
        color = QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255)

        # 3. วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setPenWidth(4)
        m.setColor(color)
        m.setIconType(QgsVertexMarker.ICON_X)
        self.markers.append(m)
        self.src_pts.append(QgsPointXY(pt.x(), pt.y())) # บังคับเป็น PointXY
        
        # 4. ตรวจสอบจำนวนจุดตามโหมด
        limit = {'move': 2, 'modify_node': 2, 'rotate': 3, 'scale': 3, 'transform': 4}.get(self.mode, 2)
        
        if len(self.src_pts) >= limit:
            self.execute_tool()
            
    def handle_generic_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือทั่วไป (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            # แทนที่จะใส่ None ให้ใช้ Match ว่างๆ แทนครับ
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            
    def execute_tool(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        
        if not layers:
            self.cancel_transform()
            return
            
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self.last_layers = layers
        p = self.src_pts

        # ─── ตรวจสอบกฎการล็อกแปลง L1-RTK / L1-TS ───
        if poly_lyr:
            type_idx = -1
            for i, field in enumerate(poly_lyr.fields()):
                if field.name().lower() == 'type':
                    type_idx = i
                    break
            if type_idx != -1:
                poly_ids = poly_lyr.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_lyr.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str == "L1-RTK":
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-RTK ซึ่งเป็นพิกัดอ้างอิงหลัก ไม่สามารถขยับได้!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return
                            elif val_str == "L1-TS":
                                # ยกเว้นกรณีใช้ปุ่ม transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                                if self.mode == 'transform' and len(p) >= 4:
                                    p2, p4 = p[1], p[3]
                                    if self._is_point_on_rtk_node(poly_lyr, p2) and self._is_point_on_rtk_node(poly_lyr, p4):
                                        continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                                        
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-TS ไม่สามารถขยับได้ ยกเว้นใช้โหมด Transform (2 Pts) ไปต่อกับ L1-RTK เท่านั้น!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return

        # ตรวจสอบสิทธิ์การขยับพิกัดผ่านจุดหมุด (กรณีจุดหมุดถูกเลือก)
        if point_lyr and point_lyr.selectedFeatureCount() > 0 and poly_lyr:
            for pt_f in point_lyr.selectedFeatures():
                is_locked, type_str = self._is_point_feature_locked(poly_lyr, pt_f)
                if is_locked:
                    # ข้อยกเว้นเฉพาะโหมด transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                    if type_str == "L1-TS" and self.mode == 'transform' and len(p) >= 4:
                        p2, p4 = p[1], p[3]
                        if self._is_point_on_rtk_node(poly_lyr, p2) and self._is_point_on_rtk_node(poly_lyr, p4):
                            continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                            
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return
                    else:
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return

        # เปิด edit ทั้งเลเยอร์แปลง+หมุดที่ตั้งค่าไว้ แยกจากเงื่อนไข selection
        # (แก้: บางทีหมุดไม่ถูกเลือก -> point layer ไม่ขึ้น edit)
        for _l in (poly_lyr, point_lyr):
            if _l and not _l.isEditable():
                _l.startEditing()

        for lyr in layers:
            if not lyr.isEditable(): lyr.startEditing()
            lyr.beginEditCommand(f"MLEP {self.mode}")
            
            try:
                # Optimize: ดึงเฉพาะ Geometry และรวบรวมเป็น list ก่อนวนลูปแก้ไข เพื่อป้องกันปัญหา cursor ล็อกขณะเขียนข้อมูล
                req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
                features = list(lyr.getFeatures(req))
                for f in features:
                    geom = f.geometry()
                    if geom.isNull(): continue

                    # --- 1. Move ---
                    if self.mode == 'move' and len(p) >= 2:
                        dx, dy = p[1].x() - p[0].x(), p[1].y() - p[0].y()
                        geom.translate(dx, dy)
                        lyr.changeGeometry(f.id(), geom)

                    # --- 2. Rotate (ใส่ลบหน้ามุมตามที่ตกลงกัน) ---
                    elif self.mode == 'rotate' and len(p) >= 3:
                        a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                        a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
                        geom.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))
                        lyr.changeGeometry(f.id(), geom)

                    # --- 3. Scale (ปรับใหม่ให้ชัวร์) ---
                    elif self.mode == 'scale' and len(p) >= 3:
                        d1 = math.sqrt(p[0].sqrDist(p[1]))
                        d2 = math.sqrt(p[0].sqrDist(p[2]))
                        if d1 > 0:
                            s = d2 / d1
                            # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                            geom.translate(-p[0].x(), -p[0].y())
                            matrix = QtGui.QTransform(); matrix.scale(s, s)
                            geom.transform(matrix)
                            geom.translate(p[0].x(), p[0].y())
                            lyr.changeGeometry(f.id(), geom)

                    # --- 4. Transform ---
                    elif self.mode == 'transform' and len(p) >= 4:
                        self.apply_similarity_direct(lyr, f, p)

                    # --- 5. Move Node (Optimized via C++ closestVertex) ---
                    elif self.mode == 'modify_node' and len(p) >= 2:
                        closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(p[0])
                        if sqr_dist < 0.000001:  # threshold 0.001 (sqrDist = 0.001 ** 2)
                            if vertex_idx >= 0:
                                lyr.moveVertex(p[1].x(), p[1].y(), f.id(), vertex_idx)
                
                lyr.endEditCommand()
            except Exception as e:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("MLEP Error", f"เกิดข้อผิดพลาดใน {lyr.name()}: {e}", level=2, duration=0)
                print(f"Error in execute_tool for layer {lyr.name()}: {e}")

        self.iface.mapCanvas().refresh()
        self.clear_markers()
        self.src_pts = []
        if self.mode == 'transform' :
            self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def apply_similarity_direct(self, lyr, f, p):
        """คำนวณ Transform แบบ Matrix (Similarity)"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        # x' = ax - by + tx , y' = bx + ay + ty
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        lyr.changeGeometry(f.id(), geom)

    def _is_point_on_rtk_node(self, poly_lyr, point_xy):
        """ตรวจสอบว่าพิกัด point_xy อยู่บน Node ของแปลงประเภท L1-RTK หรือไม่"""
        search_rect = QgsGeometry.fromPointXY(point_xy).buffer(0.05, 5).boundingBox()
        
        type_idx = -1
        for i, field in enumerate(poly_lyr.fields()):
            if field.name().lower() == 'type':
                type_idx = i
                break
        if type_idx == -1:
            return False
            
        req = QgsFeatureRequest().setFilterRect(search_rect).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
        for feat in poly_lyr.getFeatures(req):
            val = feat.attribute(type_idx)
            if val is not None and str(val).strip().upper() == "L1-RTK":
                geom_feat = poly_lyr.getFeature(feat.id())
                geom = geom_feat.geometry()
                if geom and not geom.isNull():
                    closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(point_xy)
                    if sqr_dist < 0.0025: # 0.05 ** 2
                        return True
        return False

    def _is_point_feature_locked(self, poly_lyr, point_f):
        """ตรวจสอบว่าฟีเจอร์จุดหมุดนี้เชื่อมโยงกับแปลงที่ถูกล็อก (L1-RTK หรือ L1-TS) หรือไม่ ผ่านฟิลด์ UTM"""
        point_utm_field = next(
            (f.name() for f in point_f.fields()
             if f.name().lower() in {'utm', 'utm_code', 'utm_id'}),
            None
        )
        poly_utm_field = next(
            (f.name() for f in poly_lyr.fields()
             if f.name().lower() in {'utm', 'utm_code', 'utm_id'}),
            None
        )
        poly_type_field = next(
            (f.name() for f in poly_lyr.fields()
             if f.name().lower() == 'type'),
            None
        )
        
        if not point_utm_field or not poly_utm_field or not poly_type_field:
            return False, None
            
        utm_val = point_f[point_utm_field]
        if utm_val is None:
            return False, None
            
        expr = f'"{poly_utm_field}" = \'{str(utm_val).strip()}\''
        req = QgsFeatureRequest().setFilterExpression(expr).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([poly_lyr.fields().indexFromName(poly_type_field)])
        
        for poly_feat in poly_lyr.getFeatures(req):
            val = poly_feat[poly_type_field]
            if val is not None:
                val_str = str(val).strip().upper()
                if val_str in ("L1-RTK", "L1-TS"):
                    return True, val_str
                    
        return False, None

    def set_score_value(self, value):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย score จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())

        # ตรวจสอบกฎการห้ามใส่ Score ให้กับแปลง L1-RTK และ L1-TS
        if poly_layer:
            type_idx = -1
            for i, field in enumerate(poly_layer.fields()):
                if field.name().lower() == 'type':
                    type_idx = i
                    break
            if type_idx != -1:
                poly_ids = poly_layer.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_layer.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str in ("L1-RTK", "L1-TS"):
                                self.iface.messageBar().pushMessage(
                                    "Score Blocked", 
                                    f"แปลง {f.id()} เป็นประเภท {val_str} ไม่อนุญาตให้ตั้งค่า Score!", 
                                    level=2, duration=10
                                )
                                return
                                
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return

        # เก็บรายชื่อเลเยอร์ไว้ให้ปุ่ม Undo รู้ว่าจะต้องไปย้อนที่เลเยอร์ไหน
        self.last_layers = layers 
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        for lyr in layers:
            # ตรวจสอบว่าเลเยอร์อยู่ในโหมดแก้ไขหรือไม่
            if not lyr.isEditable(): 
                lyr.startEditing()
            
            # เริ่มบันทึกคำสั่งสำหรับ Undo
            lyr.beginEditCommand(f"Change Score to {value}")
            
            # ค้นหา index ของฟิลด์ Score
            idx = -1
            for i, field in enumerate(lyr.fields()):
                if field.name().lower() == 'score':
                    idx = i
                    break
            
            if idx != -1:
                # Optimize: วนลูปแก้เฉพาะค่า Attribute ผ่าน ID โดยตรงเพื่อความรวดเร็วและใช้แรมน้อย
                for fid in lyr.selectedFeatureIds():
                    lyr.changeAttributeValue(fid, idx, value)
                lyr.endEditCommand() # ปิดคำสั่ง (จะถูกส่งเข้า Undo Stack ของ QGIS)
            else:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"ไม่พบฟิลด์ Score ใน {lyr.name()}", level=2, duration=0)

        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def group_cluster_ids(self):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย cluster id จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        fields = [f.name() for f in poly_layer.fields()]
        target_field = next((f for f in fields if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
        if not target_field: return
        
        # Optimize: ดึงค่าเฉพาะ Attribute ฟิลด์แรกที่เลือกโดยไม่ต้องดึงพิกัดเพื่อประหยัดหน่วยความจำ
        first_id = poly_layer.selectedFeatureIds()[0]
        f_idx = poly_layer.fields().indexFromName(target_field)
        req = QgsFeatureRequest().setFilterFid(first_id).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([f_idx])
        first_feat = next(poly_layer.getFeatures(req), None)
        if not first_feat: return
        main_val = first_feat[target_field]

        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        for lyr in layers:
            lyr.beginEditCommand("Group Cluster ID")
            lyr_f = [f.name() for f in lyr.fields()]
            lyr_t = next((f for f in lyr_f if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
            if lyr_t:
                idx = lyr.fields().indexFromName(lyr_t)
                # Optimize: แก้ไขเฉพาะค่า Attribute ผ่าน IDs โดยตรง
                for fid in lyr.selectedFeatureIds():
                    lyr.changeAttributeValue(fid, idx, main_val)
            lyr.endEditCommand()
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        """ล้างค่าหน้าจอและทำลายตัวช่วย Snap อย่างปลอดภัย"""
        if hasattr(self, 'snap_indicator') and self.snap_indicator:
            # ล้างสัญลักษณ์บนหน้าจอก่อนทำลาย Object
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            self.snap_indicator = None

        self.clear_rubber_band()
        self._dol_clear_highlight()
        self._align_picked_ids = set()
        self._align_clear_highlight()
        
        # รีเซ็ตเครื่องมือ Semi-Auto (ถ้ามี)
        if hasattr(self, 'temp_tool') and self.temp_tool:
            if hasattr(self.temp_tool, 'reset_tool'):
                try:
                    self.temp_tool.reset_tool()
                except Exception:
                    pass

        if hasattr(self, 'markers'):
            for m in self.markers:
                if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []
        self.src_pts = []

        # ล้าง feature ที่ถูกเลือกไว้ในทุกเลเยอร์ของ QGIS
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if isinstance(lyr, QgsVectorLayer) and lyr.selectedFeatureCount():
                    lyr.removeSelection()
            except Exception:
                pass

        self.iface.mapCanvas().refresh()
        self.iface.actionSelect().trigger()

    def undo_transform(self):
        """ย้อนกลับการแก้ไขล่าสุดในทุกเลเยอร์ที่ถูกบันทึกไว้ใน self.last_layers"""
        if not self.last_layers:
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการล่าสุดให้ย้อนกลับ", level=2, duration=10)
            return

        for lyr in self.last_layers:
            if lyr and lyr.isEditable():
                # สั่งให้ Stack ของเลเยอร์นั้นๆ ย้อนกลับ 1 ขั้น
                lyr.undoStack().undo()
        
        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดเรียบร้อยแล้ว", level=1, duration=10)

    def save_all_changes(self):
        for lyr in [QgsProject.instance().mapLayer(self.poly_cb.currentData()), QgsProject.instance().mapLayer(self.point_cb.currentData())]:
            if lyr and lyr.isEditable(): lyr.commitChanges(); lyr.startEditing()
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3, duration=3)

    def update_plugin(self):
        V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
        Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"

        def _vkey(v):
            try:
                return tuple(int(x) for x in str(v).strip().split("."))
            except Exception:
                return (0,)

        # ทำใน main thread (popup เด้งชัวร์) — เช็คเวอร์ชันเร็ว มี wait cursor พอ
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            res = requests.get(V_URL, timeout=8)
            new_version = res.text.strip()
        except Exception as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self.dlg, "Update Error", f"ไม่สามารถตรวจสอบอัปเดตได้:\n{e}")
            return
        QtWidgets.QApplication.restoreOverrideCursor()
        if _vkey(new_version) > _vkey(self.version):
            self.prompt_update(new_version, Z_URL)
        else:
            QtWidgets.QMessageBox.information(
                self.dlg, "Update", f"คุณใช้เวอร์ชันล่าสุดแล้ว (v{self.version})")

    def prompt_update(self, new_version, download_url):
        if QtWidgets.QMessageBox.question(
                self.dlg, "Update",
                f"พบเวอร์ชันใหม่ {new_version} ต้องการอัปเดตไหม?") != QtWidgets.QMessageBox.Yes:
            return
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            r = requests.get(download_url, timeout=60)
            z = zipfile.ZipFile(io.BytesIO(r.content))
            dest_dir = os.path.dirname(os.path.dirname(__file__))
            z.extractall(dest_dir)
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.information(self.dlg, "Done", "อัปเดตเสร็จแล้ว! กรุณา Restart QGIS")
        except Exception as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.critical(self.dlg, "Update Error", f"การดาวน์โหลดล้มเหลว:\n{e}")

    def process_selection(self, mode):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        selected_ids = poly_layer.selectedFeatureIds()
        if not selected_ids: return
        
        fields = poly_layer.fields()
        target_names = (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])
        target = None
        target_idx = -1
        for i, field in enumerate(fields):
            if field.name().lower() in target_names:
                target = field.name()
                target_idx = i
                break
        if target_idx == -1: return
        
        # Optimize: ดึงเฉพาะข้อมูล Attribute ของฟิลด์ที่กำหนดโดยไม่ดึงพิกัดเพื่อประหยัดหน่วยความจำ
        req = QgsFeatureRequest().setFilterFids(selected_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([target_idx])
        v_list = []
        for f in poly_layer.getFeatures(req):
            val = f.attribute(target_idx)
            if val is not None:
                v_list.append(f"'{val}'" if isinstance(val, str) else str(val))
        
        if v_list:
            expr = f'"{target}" IN ({",".join(list(set(v_list)))})'
            poly_layer.selectByExpression(expr)
            if point_layer: point_layer.selectByExpression(expr)
            self.iface.mapCanvas().refresh()

    def start_align_tool(self):
        self.cancel_transform()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            QtWidgets.QMessageBox.warning(self.dlg, "Align", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        self.mode = 'align_box'
        self.canvas = self.iface.mapCanvas()
        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.temp_tool = BoxSelectTool(self.iface.mapCanvas(), self._align_add_box,
                                       self.finish_align_selection, self._align_cancel)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", "ลากกล่องครอบหมุด (ครอบหลายรอบได้ • Ctrl+ลาก = เอาออก) แล้วคลิกขวาเพื่อเลือกเสร็จ")

    def _align_add_box(self, rect_map, remove):
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            return
        proj = QgsProject.instance()
        rect_lyr = rect_map
        if point_lyr.crs() != proj.crs():
            try:
                rect_lyr = QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj).transformBoundingBox(rect_map)
            except Exception:
                rect_lyr = rect_map
        ids = set(getattr(self, "_align_picked_ids", set()))
        req = QgsFeatureRequest().setFilterRect(rect_lyr).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            ids.discard(f.id()) if remove else ids.add(f.id())
        self._align_picked_ids = ids
        self._align_refresh_highlight()
        self.iface.messageBar().pushInfo("Align", f"เลือกหมุด {len(ids)} จุด (คลิกขวา = เสร็จ)")

    def _align_refresh_highlight(self):
        self._align_clear_highlight()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        ids = getattr(self, "_align_picked_ids", None)
        if not point_lyr or not ids:
            return
        proj = QgsProject.instance()
        xform = None
        if point_lyr.crs() != proj.crs():
            try:
                xform = QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
            except Exception:
                xform = None
        self._align_markers = []
        req = QgsFeatureRequest().setFilterFids(list(ids)).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            xy = f.geometry().asPoint()
            if xform is not None:
                try:
                    xy = xform.transform(xy)
                except Exception:
                    pass
            mk = QgsVertexMarker(self.iface.mapCanvas())
            mk.setCenter(QgsPointXY(xy))
            mk.setColor(QtGui.QColor(0, 120, 255))
            mk.setIconType(QgsVertexMarker.ICON_BOX)
            mk.setPenWidth(3)
            mk.setIconSize(10)
            self._align_markers.append(mk)

    def _align_clear_highlight(self):
        for mk in getattr(self, "_align_markers", []):
            try:
                self.iface.mapCanvas().scene().removeItem(mk)
            except Exception:
                pass
        self._align_markers = []

    def _align_cancel(self):
        """ยกเลิกโหมด Align (Esc): ล้างข้อความแนะนำที่ค้าง แล้วรีเซ็ต"""
        try:
            self.iface.messageBar().clearWidgets()
        except Exception:
            pass
        self.cancel_transform()

    def finish_align_selection(self):
        if not getattr(self, "_align_picked_ids", None):
            self.iface.messageBar().pushMessage("Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน", level=1, duration=6)
            return
        self.mode = 'align_point_driven'
        self.src_pts = []
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.canvas)
        self.temp_tool.canvasClicked.connect(self.handle_align_click)
        self.temp_tool.canvasMoveEvent = self.handle_align_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", f"เลือกหมุด {len(self._align_picked_ids)} จุด → คลิก 2 จุดสร้างเส้นแนว (Esc = ยกเลิก)")

    def handle_align_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือ Align (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
        # แก้จาก self.snapping_utils เป็น self.snap_utils
        if not hasattr(self, 'snap_utils'):
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # Logic สำหรับวาด Rubber Band เส้นยางยืด (ถ้ามี)
        if hasattr(self, 'rubber_band') and self.rubber_band and len(self.src_pts) == 1:
            curr_pt = match.point() if match.isValid() else event.mapPoint()
            self.rubber_band.removeLastPoint()
            self.rubber_band.addPoint(curr_pt)
            
    def handle_align_click(self, point, button):
        """จัดการการคลิกจุด P1 และ P2 สำหรับสร้างแนวเส้น (รองรับที่ว่าง)"""
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        # 2. ถ้า Snap ไม่ติด ให้ใช้พิกัดที่คลิกจริง (point)
        pt = match.point() if match.isValid() else point
        
        self.src_pts.append(QgsPointXY(pt.x(), pt.y()))
        
        # วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        m.setPenWidth(5)
        self.markers.append(m)
        
        if len(self.src_pts) == 1:
            self.clear_rubber_band()
            self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            self.rubber_band.setColor(QtGui.QColor(255, 0, 0))
            self.rubber_band.setWidth(2)
            self.rubber_band.addPoint(pt)
            self.rubber_band.addPoint(pt)

        if len(self.src_pts) == 2:
            self.execute_point_node_alignment()
            # ทำความสะอาดหน้าจอหลังเสร็จงาน
            self.clear_markers()
            self.clear_rubber_band()
            self.src_pts = []
            
    def clear_rubber_band(self):
        """ลบ Rubber Band ออกจากหน้าจอและหน่วยความจำอย่างเด็ดขาด"""
        if self.rubber_band:
            self.rubber_band.hide() # ซ่อนทันที
            self.iface.mapCanvas().scene().removeItem(self.rubber_band) # ลบออกจาก Scene
            self.rubber_band = None # คืนค่าว่าง
            
    def _side_edge_dir(self, old_xy, poly_lyr, line_dx, line_dy):
        """ทิศของขอบแปลงที่ vertex old_xy โดยเลือกขอบที่ไม่ขนานกับเส้นเป้าหมาย -> (ux,uy) หรือ None"""
        if not poly_lyr:
            return None
        lmag = math.hypot(line_dx, line_dy)
        if lmag == 0:
            return None
        lux, luy = line_dx / lmag, line_dy / lmag
        EPS = 0.05
        rect = QgsRectangle(old_xy.x() - 1.0, old_xy.y() - 1.0,
                            old_xy.x() + 1.0, old_xy.y() + 1.0)
        best = None  # (parallelness, ux, uy)
        for pf in poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            g = pf.geometry()
            try:
                if g.isMultipart():
                    rings = [poly[0] for poly in g.asMultiPolygon() if poly]
                else:
                    pg = g.asPolygon()
                    rings = [pg[0]] if pg else []
            except Exception:
                rings = []
            for ring in rings:
                if len(ring) > 1 and ring[0] == ring[-1]:
                    ring = ring[:-1]
                n = len(ring)
                if n < 3:
                    continue
                vi = -1
                for idx, v in enumerate(ring):
                    if abs(v.x() - old_xy.x()) <= EPS and abs(v.y() - old_xy.y()) <= EPS:
                        vi = idx
                        break
                if vi < 0:
                    continue
                v = ring[vi]
                for nb in (ring[(vi - 1) % n], ring[(vi + 1) % n]):
                    ex, ey = nb.x() - v.x(), nb.y() - v.y()
                    emag = math.hypot(ex, ey)
                    if emag < 1e-9:
                        continue
                    ux, uy = ex / emag, ey / emag
                    par = abs(ux * lux + uy * luy)   # 1 = ขนานกับเส้นเป้าหมาย
                    if best is None or par < best[0]:
                        best = (par, ux, uy)
        return (best[1], best[2]) if best else None

    def _align_new_point(self, old_xy, poly_lyr, p1, dx, dy, projfn):
        """ตำแหน่งใหม่ของหมุด = จุดตัดของ (ขอบเดิมผ่าน old_xy) กับ (เส้นเป้าหมาย A-B)
        ถ้าหาทิศขอบไม่ได้/ขนานกัน -> fall back เป็นฉายตั้งฉาก"""
        d = self._side_edge_dir(old_xy, poly_lyr, dx, dy)
        if d is not None:
            denom = d[0] * dy - d[1] * dx
            if abs(denom) > 1e-9:
                s = ((p1.x() - old_xy.x()) * dy - (p1.y() - old_xy.y()) * dx) / denom
                return QgsPointXY(old_xy.x() + s * d[0], old_xy.y() + s * d[1])
        return projfn(old_xy.x(), old_xy.y())   # fallback ตั้งฉาก

    def execute_point_node_alignment(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            return

        p1, p2 = self.src_pts[0], self.src_pts[1]
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag_sq = dx**2 + dy**2
        if mag_sq == 0:
            return

        def get_projected_pt(old_x, old_y):
            u = ((old_x - p1.x()) * dx + (old_y - p1.y()) * dy) / mag_sq
            return QgsPointXY(p1.x() + u * dx, p1.y() + u * dy)

        # ===== หมุดที่จะ align = หมุดที่เลือกด้วยกล่อง (box-select) =====
        picked = getattr(self, "_align_picked_ids", None)
        if picked:
            target_points = list(point_lyr.getFeatures(
                QgsFeatureRequest().setFilterFids(list(picked))))
        else:
            target_points = list(point_lyr.selectedFeatures())   # fallback: หมุดที่ select ไว้

        if not target_points:
            self.iface.messageBar().pushMessage(
                "Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน",
                level=1, duration=6)
            return

        self.last_layers = [l for l in (point_lyr, poly_lyr) if l]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in self.last_layers}

        if not point_lyr.isEditable(): point_lyr.startEditing()
        point_lyr.beginEditCommand("Align Points to Line")
        if poly_lyr:
            if not poly_lyr.isEditable(): poly_lyr.startEditing()
            poly_lyr.beginEditCommand("Align Nodes to Line")

        # ระยะยอมรับว่าเป็น "มุมเดียวกัน" (เมตร) — ดึง node/หมุดข้างเคียงที่มุมร่วม
        # คลาดกันเล็กน้อยให้ขยับตามไปพร้อมกัน กันขอบแยก (shared-boundary weld)
        NODE_TOL = 0.05
        NODE_TOL_SQ = NODE_TOL * NODE_TOL
        try:
            # ===== PASS 1: คำนวณตำแหน่งใหม่ของทุกหมุดจาก geometry "เดิม" (ก่อนแก้ไขใดๆ) =====
            # สำคัญ: หมุดที่ซ้อนพิกัดเดียวกันต้องได้ new_pt ตัวเดียวกัน และทิศขอบต้องอ่านจาก
            # แปลงที่ยังไม่ถูกขยับ — ไม่งั้นรอบหลังจะหา "ขอบเดิม" ไม่เจอแล้ว fallback คนละจุด
            moves = []   # [(pt_id, old_xy, new_pt)]
            for pt_f in target_points:
                old_xy = pt_f.geometry().asPoint()
                # ข้ามถ้าหมุดเชื่อมโยงกับแปลงที่ล็อก
                if poly_lyr:
                    is_locked, type_str = self._is_point_feature_locked(poly_lyr, pt_f)
                    if is_locked:
                        self.iface.messageBar().pushMessage(
                            "Align Warning",
                            f"ข้ามการย้ายจุดหมุด {pt_f.id()} เนื่องจากเชื่อมโยงกับแปลงประเภท {type_str} (ถูกล็อก)",
                            level=2, duration=5)
                        continue
                new_pt = self._align_new_point(old_xy, poly_lyr, p1, dx, dy, get_projected_pt)
                moves.append((pt_f.id(), old_xy, new_pt))

            # ===== PASS 2: ขยับหมุดทั้งหมด =====
            for pt_id, old_xy, new_pt in moves:
                point_lyr.changeGeometry(pt_id, QgsGeometry.fromPointXY(new_pt))

            # ===== PASS 3: ขยับ node ของ polygon (เชื่อมขอบ) — ทำครั้งเดียวต่อ 1 ตำแหน่ง =====
            if poly_lyr:
                poly_type_idx = -1
                for i, field in enumerate(poly_lyr.fields()):
                    if field.name().lower() == 'type':
                        poly_type_idx = i
                        break
                seen = set()   # ตำแหน่ง old_xy (ปัดมิลลิเมตร) ที่ทำแล้ว — กันซ้ำสำหรับหมุดซ้อน
                for pt_id, old_xy, new_pt in moves:
                    key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
                    if key in seen:
                        continue
                    seen.add(key)
                    search_rect = QgsRectangle(old_xy.x() - NODE_TOL, old_xy.y() - NODE_TOL,
                                               old_xy.x() + NODE_TOL, old_xy.y() + NODE_TOL)
                    # ดึงเป็น list ก่อน เพื่อกัน cursor ล็อกตอน moveVertex
                    for poly_f in list(poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(search_rect))):
                        # ข้ามแปลงที่ล็อกพิกัด
                        if poly_type_idx != -1:
                            val = poly_f.attribute(poly_type_idx)
                            if val is not None and str(val).strip().upper() in ("L1-RTK", "L1-TS"):
                                self.iface.messageBar().pushMessage(
                                    "Align Warning",
                                    f"ข้ามการย้ายโหนดของแปลง {poly_f.id()} เนื่องจากเป็นประเภทที่ถูกล็อก",
                                    level=2, duration=5)
                                continue
                        geom = poly_f.geometry()
                        closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(old_xy)
                        if sqr_dist <= NODE_TOL_SQ and vertex_idx >= 0:   # node ภายในระยะ "มุมเดียวกัน"
                            poly_lyr.moveVertex(new_pt.x(), new_pt.y(), poly_f.id(), vertex_idx)

            # ปิด Command ทั้งสองเลเยอร์
            point_lyr.endEditCommand()
            if poly_lyr:
                poly_lyr.endEditCommand()
                
        except Exception as e:
            point_lyr.destroyEditCommand()
            if poly_lyr: poly_lyr.destroyEditCommand()
            self.iface.messageBar().pushMessage("Align Error", f"เกิดข้อผิดพลาด: {e}", level=2, duration=0)
            print(f"Align Error: {e}")

        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.canvas.refresh()
        self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)


# ============================================================
#  DOL iLands — เครื่องมือคลิกเลือกแปลง + worker เรียก API
# ============================================================
class BoxSelectTool(QgsMapTool):
    """ลากกล่องเลือก point features (สะสมหลายรอบ); คลิกขวา=เสร็จ, Ctrl+ลาก=เอาออก, Esc=ยกเลิก"""

    def __init__(self, canvas, on_box, on_finish, on_cancel):
        super().__init__(canvas)
        self._canvas = canvas
        self._on_box = on_box
        self._on_finish = on_finish
        self._on_cancel = on_cancel
        self._start = None
        self._band = None
        self.setCursor(QtCore.Qt.CrossCursor)

    def canvasPressEvent(self, e):
        if e.button() == QtCore.Qt.LeftButton:
            self._start = self.toMapCoordinates(e.pos())
            self._band = QgsRubberBand(self._canvas, QgsWkbTypes.PolygonGeometry)
            self._band.setColor(QtGui.QColor(0, 120, 255))
            self._band.setFillColor(QtGui.QColor(0, 120, 255, 40))
            self._band.setWidth(2)

    def canvasMoveEvent(self, e):
        if self._start is None or self._band is None:
            return
        cur = self.toMapCoordinates(e.pos())
        self._band.setToGeometry(QgsGeometry.fromRect(QgsRectangle(self._start, cur)), None)

    def canvasReleaseEvent(self, e):
        if e.button() == QtCore.Qt.RightButton:
            self._clear_band(); self._start = None
            self._on_finish()
            return
        if e.button() == QtCore.Qt.LeftButton and self._start is not None:
            cur = self.toMapCoordinates(e.pos())
            rect = QgsRectangle(self._start, cur)
            self._clear_band(); self._start = None
            if rect.width() < 1e-9 and rect.height() < 1e-9:
                tol = self._canvas.mapUnitsPerPixel() * 6
                rect = QgsRectangle(cur.x() - tol, cur.y() - tol, cur.x() + tol, cur.y() + tol)
            remove = bool(e.modifiers() & QtCore.Qt.ControlModifier)
            self._on_box(rect, remove)

    def keyPressEvent(self, e):
        if e.key() == QtCore.Qt.Key_Escape:
            self._clear_band()
            self._on_cancel()

    def _clear_band(self):
        if self._band:
            try:
                self._canvas.scene().removeItem(self._band)
            except Exception:
                pass
            self._band = None

    def deactivate(self):
        self._clear_band()
        super().deactivate()


class PolygonPickTool(QgsMapTool):
    """cursor กากบาท + ไฮไลต์แปลงใต้เมาส์ (ก่อนคลิก) เป็นตัวช่วยตัดสินใจ
    คลิก = ส่ง feature กลับผ่าน click_cb ; เลื่อนเมาส์ = hover_cb"""

    def __init__(self, canvas, layer, click_cb, hover_cb):
        super().__init__(canvas)
        self._canvas = canvas
        self._layer = layer
        self._click_cb = click_cb
        self._hover_cb = hover_cb
        self._last_fid = None
        self._picked = False
        self.setCursor(QtCore.Qt.CrossCursor)
        # cache transform ครั้งเดียว (เดิมสร้างใหม่ทุก mouse-move ตอน hover)
        proj = QgsProject.instance()
        self._xform = None
        if layer.crs() != proj.crs():
            try:
                self._xform = QgsCoordinateTransform(proj.crs(), layer.crs(), proj)
            except Exception:
                self._xform = None

    def _feature_at(self, event):
        """หา feature ในเลเยอร์ที่เลือก ใต้ตำแหน่งเมาส์ (None ถ้าไม่มี)"""
        map_pt = self.toMapCoordinates(event.pos())   # CRS ของโปรเจกต์
        pt = map_pt
        if self._xform is not None:
            try:
                pt = self._xform.transform(map_pt)
            except Exception:
                pt = map_pt
        gp = QgsGeometry.fromPointXY(QgsPointXY(pt))

        tol = self._canvas.mapUnitsPerPixel() * 4
        rect = QgsRectangle(map_pt.x() - tol, map_pt.y() - tol,
                            map_pt.x() + tol, map_pt.y() + tol)
        if self._xform is not None:
            try:
                rect = self._xform.transformBoundingBox(rect)
            except Exception:
                pass

        found = fallback = None
        for f in self._layer.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            g = f.geometry()
            if fallback is None:
                fallback = f
            if g and g.contains(gp):
                found = f
                break
        return found or fallback

    def canvasMoveEvent(self, event):
        # ไฮไลต์แปลงใต้เมาส์ (อัปเดตเฉพาะเมื่อเปลี่ยนแปลง)
        feat = self._feature_at(event)
        fid = feat.id() if feat is not None else None
        if fid == self._last_fid:
            return
        self._last_fid = fid
        self._hover_cb(feat, self._layer)

    def canvasReleaseEvent(self, event):
        if event.button() != QtCore.Qt.LeftButton:
            return
        feat = self._feature_at(event)
        if feat is None:
            iface.messageBar().pushMessage(
                "DOL", "ไม่พบแปลงในเลเยอร์ที่เลือกตรงตำแหน่งที่คลิก ลองใหม่อีกครั้ง", level=1, duration=6)
            return
        self._picked = True
        self._click_cb(feat, self._layer)

    def deactivate(self):
        # ถ้าเลิกใช้เครื่องมือโดยไม่ได้คลิก -> ลบไฮไลต์ hover + ข้อความแนะนำที่ค้างอยู่
        if not self._picked:
            try:
                self._hover_cb(None, self._layer)
            except Exception:
                pass
            try:
                iface.messageBar().clearWidgets()
            except Exception:
                pass
        super().deactivate()


class ParcelLookupWorker(QtCore.QThread):
    """ระวาง(attribute) -> PARCEL_SEQ ผ่าน ArcGIS + UDM (public, ไม่ต้อง login)"""
    done = QtCore.pyqtSignal(object)   # dict หรือ None
    fail = QtCore.pyqtSignal(str)

    def __init__(self, attrs, zone=47):
        super().__init__()
        self.attrs = attrs
        self.zone = zone

    def run(self):
        from . import dol_api
        try:
            a = self.attrs
            res = dol_api.lookup_parcel_by_rawang(
                a["m1"], a["m2"], a["m3"], a["m4"], a["scale"], a["landno"],
                zone=self.zone)
            self.done.emit(res)
        except Exception as e:
            self.fail.emit(f"ค้นหาไม่สำเร็จ: {e}")
