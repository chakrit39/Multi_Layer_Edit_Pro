import os
import math
import requests
import zipfile
import io
from qgis.PyQt import QtWidgets, QtCore, QtGui
from qgis.core import (QgsProject, QgsPointXY, QgsGeometry, QgsPointLocator,
                       QgsSnappingConfig, QgsTolerance, QgsWkbTypes,
                       QgsFeatureRequest, QgsVectorLayer, QgsFeature)
from qgis.gui import QgsMapTool, QgsMapToolEmitPoint, QgsVertexMarker, QgsRubberBand, QgsSnapIndicator
from qgis.core import QgsRectangle, QgsCoordinateTransform, QgsCoordinateReferenceSystem
from qgis.utils import iface


# ประวัติการอัปเดต (ใหม่สุดอยู่บน) — ใช้เด้ง "What's New" หลังอัปเดตเวอร์ชัน
CHANGELOG = [
    ("1.6.2", ["Align: หมุดที่เลือกวิ่งไปหาเส้นแบบ 'ตามแนวขอบ' → ขอบที่ต่อหมุดที่ไม่ได้เลือกไม่เบี้ยวตาม (เดิมฉายตั้งฉากแล้วขอบเอียง)",
               "Align: weld มุมแปลงแบบ junction-aware — มุมร่วมรวมให้, มุมไม่ snap เด้งถาม, แปลงข้างเคียงที่ไม่เกี่ยวไม่โดนลาก (เดิมเหวี่ยง 5ซม.)"]),
    ("1.6.1", ["Undo: ย้อนทั้งเลเยอร์แปลง+หมุดให้ตรงกันเสมอ + กดซ้อนหลายครั้งได้ถูกต้อง (แก้ Sync Cluster ID ที่เดิม undo ไม่ติด)",
               "Undo: ถ้าเผลอปิดแก้ไขเลเยอร์ไป — ปิดแบบ Save จะเตือน • ปิดแบบ Discard จะถามว่าย้อนอีกเลเยอร์กลับจุดเริ่มให้ตรงกันไหม",
               "เพิ่มประสิทธิภาพ Move Node/Align ตอนเลือกหมุดเยอะ และ hover ค้นหาภาพลักษณ์ให้ลื่นขึ้น"]),
    ("1.6.0", ["Move Node โหมดใหม่: คลิกหมุดเดียว → คลิกตำแหน่งใหม่เพื่อย้าย (มีเส้นนำ)",
               "Move Node: ลากกล่องเลือกหลายหมุดแล้วลากย้าย (Shift+ลาก = เลือกเพิ่ม)",
               "แก้ค้นหาภาพลักษณ์/หลักฐานรังวัดขึ้น \"ข้อมูลแปลงไม่ครบ\" (อ่าน attribute แปลงที่คลิกไม่ครบบนบางชนิดข้อมูล)",
               "เพิ่มประสิทธิภาพการทำงาน (cache การหา field, ลดการ query ซ้ำ)"]),
    ("1.5.6", ["เพิ่มประสิทธิภาพการทำงานและความลื่นไหล"]),
    ("1.5.5", ["แก้ไข Move Node ดึงหมุดแปลงข้างเคียงตาม (หากมีการ Select แปลงเอาไว้ จะย้ายแค่แปลงที่ Select จริงๆ เท่านั้น)"]),
    ("1.5.4", ["เพิ่มเงื่อนไขเครื่องมือ Move Node: หากมีการ Select แปลงอยู่ จะจำกัดให้ย้ายได้เฉพาะมุมของแปลงที่ Select ไว้เท่านั้น"]),
    ("1.5.3", ["เพิ่มกันชน L1-RTK/L1-TS กลับเข้าไปในเครื่องมือ Move Node เพื่อป้องกันไม่ให้ถูกตีกรอบครอบไปขยับพิกัด"]),
    ("1.5.2", ["ปรับปรุงเครื่องมือ Move Node ให้รองรับการเลือกหมุดแบบสะสม (ตีกรอบเพิ่มได้เรื่อยๆ โดยไม่ต้องกดคีย์บอร์ด)"]),
    ("1.5.1", ["แก้บั๊กมุมแปลง (Polygon Node) ไม่ขยับตามหมุดตอนใช้ Move Node", "เพิ่มประสิทธิภาพการทำงานและความลื่นไหล"]),
    ("1.5.0", ["เพิ่มปุ่ม \"ค้นหาหลักฐานการรังวัด\" (ต้อง login — ใส่รหัสตอนใช้ ไม่เก็บถาวร)",
               "คลิกแปลง -> เปิดหลักฐานรังวัด • หลายรายการมี popup ให้เลือก",
               "ปรับปรุงประสิทธิภาพเครื่องมือ Align และเครื่องมืออื่นๆ (แก้ปัญหาค้าง/หน่วง)"]),
    ("1.4.4", ["เพิ่มระบบเด้ง \"มีอะไรใหม่\" สรุปการเปลี่ยนแปลงหลังอัปเดต"]),
    ("1.4.3", ["กันชน L1-RTK/L1-TS ในเครื่องมือ Add Node (hover แดง • เลือก/เพิ่มไม่ได้)"]),
    ("1.4.2", ["Add Node: เลือกได้ทีละ 1 แปลง",
               "เพิ่ม hover highlight แปลงใต้เมาส์"]),
    ("1.4.1", ["Add Node: ตัดคลิกขวา ใช้ snap เลือกหมุด (วงกลมแดง)"]),
    ("1.4.0", ["เพิ่มเครื่องมือ Add Node: เพิ่ม node + หมุด (ระวางจากแปลง, ชื่อจากหมุดเดิม, หลายชื่อมี popup เลือก)",
               "เปลี่ยนชื่อปุ่ม Align Points to Line → Align Points"]),
    ("1.3.7", ["Shortcut: ปลดคีย์เดิมของ QGIS ที่ชนได้ (ถามก่อนทำ)"]),
    ("1.3.6", ["ค้นหาภาพลักษณ์: แก้ปัญหาขึ้นผิดสาขา (ระวางคร่อมสาขา เลือกแปลงใกล้จุดคลิก)",
               "Shortcut: เตือนเมื่อคีย์ชนกับ QGIS"]),
    ("1.3.5", ["Align Points: ปรับระยะเชื่อม node เป็น 0.05 ม."]),
    ("1.3.4", ["Align Points: แก้หมุดที่ซ้อนกันกระเด็นแยก (คำนวณตำแหน่งก่อนแก้ไข)"]),
    ("1.3.3", ["Align Points: เพิ่มระยะเชื่อม node ของแปลงข้างเคียง"]),
    ("1.3.2", ["Clean/optimize โค้ด", "เอาเครื่องมือ Auto/Semi-Auto Transform ออก"]),
    ("1.3.1", ["Reset: เคลียร์ feature ที่เลือกทั้งหมดใน QGIS",
               "ปรับเวลาแสดง message bar (error ค้าง, อื่นๆ หายเอง)"]),
    ("1.3.0", ["UI หน้าเดียวกระทัดรัด", "ค้นหาภาพลักษณ์ DOL",
               "Align แบบ box-select", "ตั้งค่า Shortcut"]),
]


def _vkey(v):
    """แปลงเลขเวอร์ชัน '1.4.3' -> (1,4,3) เพื่อเทียบเชิงตัวเลข"""
    try:
        return tuple(int(x) for x in str(v).strip().split("."))
    except Exception:
        return (0,)


_UTM_FIELD_NAMES = {'utm', 'utm_code', 'utm_id'}


class MultiLayerEditPro:
    def __init__(self, iface):
        self.iface = iface
        self.dlg = None
        self.src_pts = []
        self.markers = []
        self.temp_tool = None
        self.last_layers = []   # เลเยอร์ที่แก้ล่าสุด (ใช้ refer ทั่วไป — undo ใช้ op_history แทน)
        # ประวัติการแก้ไขของปลั๊กอินสำหรับ Undo: แต่ละรายการ = [(layer, n_steps), ...] ใหม่สุดท้าย
        self.op_history = []
        self._op_baseline = None   # snapshot index ของ undo-stack ก่อนเริ่ม operation ปัจจุบัน
        # ดักสถานะตอนปิด edit ของแต่ละเลเยอร์ (รู้ว่ากด Save หรือ Discard) สำหรับ guard ตอน undo
        self._edit_end = {}        # layer_id -> 'commit' | 'rollback'
        self._signal_layers = set()
        self._signal_conns = []    # [(signal, slot)] ไว้ disconnect ตอน unload
        self.mode = ""
        self.version = "1.6.2"
        self.stored_selection = {} # สำหรับเก็บ Selection ระหว่างประมวลผล
        self.rubber_band = None
        self._dol_highlight = None  # rubber band ไฮไลต์แปลงที่ค้นหา
        self._align_picked_ids = set()  # หมุดที่เลือกด้วยกล่อง (Align)
        self._align_markers = []
        self._shortcuts = []  # QShortcut ที่ผูกไว้
        self._field_cache = {}  # memoize การหา field ตามชื่อ (สำหรับ hover path ที่เรียกทุกเฟรม)

    # ============ ตัวช่วยหา field (memoize ตาม layer.id) — ใช้ใน hover ที่เรียกถี่ ============
    def _resolve_field(self, layer, candidates):
        """คืนชื่อ field แรกที่ตรงกับ candidates (เทียบ lowercase) หรือ None — cache ตาม layer.id()
        ใช้กับ hot path เช่น _poly_type_str ที่ถูกเรียกทุก mouse-move
        (call site แบบครั้งเดียวต่อคลิกใช้ _field_index ได้ ไม่ต้องผ่าน cache นี้)"""
        ckey = (layer.id(), frozenset(candidates))
        if ckey in self._field_cache:
            return self._field_cache[ckey]
        name = next((f.name() for f in layer.fields()
                     if f.name().lower() in candidates), None)
        self._field_cache[ckey] = name
        return name

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.action = QtWidgets.QAction(QtGui.QIcon(icon_path), "Multi-Layer Edit Pro", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Multi-Layer Edit Pro", self.action)

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&Multi-Layer Edit Pro", self.action)
        self.clear_markers()
        self._dol_clear_highlight()
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None); sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        # ตัด signal commit/rollback ที่ต่อไว้ (กัน slot ทำงานหลัง unload)
        for sig, slot in getattr(self, "_signal_conns", []):
            try:
                sig.disconnect(slot)
            except Exception:
                pass
        self._signal_conns = []
        self._signal_layers = set()
        if hasattr(self, 'temp_tool') and self.temp_tool:
            canvas = self.iface.mapCanvas()
            if canvas and canvas.mapTool() == self.temp_tool:
                canvas.unsetMapTool(self.temp_tool)

    def run(self):
        if self.dlg is None: self.create_dialog()
        self.dlg.show()
        self._show_whats_new()

    def _show_whats_new(self):
        """เด้ง popup สรุปสิ่งที่เปลี่ยน เมื่อเปิดปลั๊กอินครั้งแรกหลังเวอร์ชันใหม่
        (เทียบกับเวอร์ชันที่เคยเห็นใน QSettings; ติดตั้งครั้งแรกจะเงียบ ตั้ง baseline ไว้)"""
        s = QtCore.QSettings()
        key = "MultiLayerEditPro/lastSeenVersion"
        last = s.value(key, "", str)
        if _vkey(self.version) <= _vkey(last):
            return                      # เคยเห็นแล้ว / ไม่ใช่เวอร์ชันใหม่
        s.setValue(key, self.version)   # บันทึกทันทีกันเด้งซ้ำ
        if last:
            # หา index ของเวอร์ชันล่าสุดที่เคยเห็น
            last_idx = next((i for i, (v, _) in enumerate(CHANGELOG) if _vkey(v) <= _vkey(last)), len(CHANGELOG))
            # โชว์สิ่งที่ใหม่กว่าทั้งหมด + ขอย้อนดูอดีตด้วยให้รวมเป็น 3 เวอร์ชันเป็นอย่างน้อย
            show_count = max(last_idx, 3)
            new_entries = CHANGELOG[:show_count]
            head = f"อัปเดตเป็นเวอร์ชัน {self.version} แล้ว 🎉"
        else:
            # ครั้งแรก -> โชว์ 3 เวอร์ชันล่าสุด
            new_entries = CHANGELOG[:3]
            head = f"ยินดีต้อนรับสู่เวอร์ชัน {self.version} 🎉"
        if not new_entries:
            return
        rows = []
        for v, items in new_entries:
            rows.append(f"<b>v{v}</b>")
            rows += [f"&nbsp;&nbsp;• {it}" for it in items]
            rows.append("")
        box = QtWidgets.QMessageBox(self.dlg or self.iface.mainWindow())
        box.setWindowTitle("Multi-Layer Edit Pro — มีอะไรใหม่ ✨")
        box.setTextFormat(QtCore.Qt.RichText)
        box.setText(head)
        box.setInformativeText("<br>".join(rows))
        box.setStandardButtons(QtWidgets.QMessageBox.Ok)
        box.exec_()

    # ============ Shortcut ปุ่มต่าง ๆ ============
    def _shortcut_actions(self):
        """รายการ action ที่ตั้ง shortcut ได้: (id, label, callable)"""
        return [
            ("dol_search", "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image')),
            ("dol_survey", "📐 ค้นหาหลักฐานการรังวัด", lambda: self.start_dol_search('survey')),
            ("by_cluster", "By Cluster ID", lambda: self.process_selection('cluster')),
            ("by_utm", "By UTM", lambda: self.process_selection('utm')),
            ("move", "Move", lambda: self.start_interactive('move')),
            ("rotate", "Rotate", lambda: self.start_interactive('rotate')),
            ("scale", "Scale", lambda: self.start_interactive('scale')),
            ("transform", "Transform (2 จุด)", lambda: self.start_interactive('transform')),
            ("modify_node", "Move Node (Sync)", self.start_sync_vertex_tool),
            ("align", "Align Points", self.start_align_tool),
            ("add_node", "Add Node", self.start_add_node),
            ("sync_cluster", "Sync Cluster ID", self.group_cluster_ids),
            ("score1", "Score = 1", lambda: self.set_score_value(1)),
            ("score0", "Score = 0", lambda: self.set_score_value(0)),
            ("reset", "Reset", self.cancel_transform),
            ("undo", "Undo", self.undo_transform),
            ("save", "บันทึก (Commit)", self.save_all_changes),
        ]

    def _load_shortcuts(self):
        """อ่าน QSettings -> สร้าง QShortcut ผูกกับ main window (ทำงานทั้งแอปขณะใช้ QGIS)"""
        for sc in getattr(self, "_shortcuts", []):
            try:
                sc.setParent(None); sc.deleteLater()
            except Exception:
                pass
        self._shortcuts = []
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        mw = self.iface.mainWindow()
        # ตั้งค่า Ctrl+Z เป็น Undo ของปลั๊กอิน (และปลดของ QGIS ออก) อัตโนมัติ 1 ครั้ง
        if not s.contains("MultiLayerEditPro/ShortcutUndoInit"):
            s.setValue("MultiLayerEditPro/ShortcutUndoInit", True)
            s.setValue(k + "undo", "Ctrl+Z")
            self._release_qgis_shortcuts(["Ctrl+Z"])
            
        for aid, label, slot in self._shortcut_actions():
            seq = s.value(k + aid, "", str)
            if not seq:
                continue
            sc = QtWidgets.QShortcut(QtGui.QKeySequence(seq), mw)
            sc.setContext(QtCore.Qt.ApplicationShortcut)
            sc.activated.connect(slot)
            self._shortcuts.append(sc)

    def open_shortcut_settings(self):
        """popup ตั้งค่า shortcut แต่ละปุ่ม"""
        dlg = QtWidgets.QDialog(self.dlg)
        dlg.setWindowTitle("⌨ ตั้งค่า Shortcut")
        dlg.setMinimumWidth(380)
        v = QtWidgets.QVBoxLayout(dlg)
        v.addWidget(QtWidgets.QLabel(
            "คลิกในช่องแล้วกดคีย์ที่ต้องการ (เว้นว่าง = ไม่ใช้)\nทำงานทั้งแอปขณะใช้ QGIS"))
        s = QtCore.QSettings()
        k = "MultiLayerEditPro/Shortcut/"
        form = QtWidgets.QFormLayout()
        editors = {}
        for aid, label, slot in self._shortcut_actions():
            ed = QtWidgets.QKeySequenceEdit(QtGui.QKeySequence(s.value(k + aid, "", str)))
            editors[aid] = ed
            btn_clr = QtWidgets.QPushButton("✖"); btn_clr.setFixedWidth(28)
            btn_clr.clicked.connect(ed.clear)
            row = QtWidgets.QHBoxLayout(); row.addWidget(ed, 1); row.addWidget(btn_clr, 0)
            w = QtWidgets.QWidget(); w.setLayout(row)
            form.addRow(label + ":", w)
        inner = QtWidgets.QWidget(); inner.setLayout(form)
        scroll = QtWidgets.QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(inner)
        v.addWidget(scroll)
        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        v.addWidget(btns)
        btns.accepted.connect(dlg.accept); btns.rejected.connect(dlg.reject)
        if dlg.exec_() == QtWidgets.QDialog.Accepted:
            qgis_keys = self._qgis_shortcut_keys()
            seen, dup, conflict = {}, set(), set()
            for aid, ed in editors.items():
                seq = ed.keySequence().toString()
                if seq:
                    if seq in seen:
                        dup.add(seq)
                    seen[seq] = aid
                    if seq in qgis_keys:
                        conflict.add(seq)
                s.setValue(k + aid, seq)
            self._load_shortcuts()
            msg = "บันทึก shortcut แล้ว ✅"
            if dup:
                msg += f"\n⚠️ คีย์ซ้ำกันเองในปลั๊กอิน: {', '.join(sorted(dup))}"
            if conflict:
                ck = ", ".join(sorted(conflict))
                ans = QtWidgets.QMessageBox.question(
                    self.dlg, "คีย์ชนกับ QGIS",
                    f"คีย์เหล่านี้ QGIS ใช้อยู่: {ck}\n"
                    "ถ้าปล่อยไว้ Qt จะถือว่ากำกวม → ปุ่มลัดอาจไม่ทำงาน\n\n"
                    "ต้องการให้ปลดคีย์เดิมของ QGIS ออก เพื่อให้ปลั๊กอินใช้คีย์นี้ได้ไหม?\n"
                    "(เปลี่ยนคีย์ลัด QGIS ถาวร — ย้อนคืนได้ที่ Settings → Keyboard Shortcuts)",
                    QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                    QtWidgets.QMessageBox.No)
                if ans == QtWidgets.QMessageBox.Yes:
                    released = self._release_qgis_shortcuts(conflict)
                    self._load_shortcuts()   # โหลดใหม่ให้คีย์ปลั๊กอินจับได้หลังปลดคีย์ QGIS
                    if released:
                        msg += f"\n✅ ปลดคีย์ QGIS แล้ว: {', '.join(sorted(released))}"
                    left = conflict - released
                    if left:
                        msg += (f"\n⚠️ ปลดไม่ได้: {', '.join(sorted(left))} "
                                "(แก้เองที่ Settings → Keyboard Shortcuts)")
                else:
                    msg += f"\n⚠️ ยังชนกับ QGIS: {ck} (ปุ่มลัดอาจไม่ทำงาน)"
            QtWidgets.QMessageBox.information(self.dlg, "Shortcut", msg)

    def _release_qgis_shortcuts(self, keys):
        """ปลดคีย์เดิมของ QGIS ที่ชน ผ่าน QgsShortcutsManager (บันทึกถาวร) -> set คีย์ที่ปลดได้"""
        released = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
        except Exception:
            return released
        for key in keys:
            seq = QtGui.QKeySequence(key)
            obj = None
            for getter in ("objectForSequence", "actionForSequence", "shortcutForSequence"):
                if hasattr(mgr, getter):
                    try:
                        obj = getattr(mgr, getter)(seq)
                    except Exception:
                        obj = None
                    if obj is not None:
                        break
            if obj is not None:
                try:
                    if mgr.setKeySequence(obj, ""):
                        released.add(key)
                except Exception:
                    pass
        return released

    def _qgis_shortcut_keys(self):
        """รวมคีย์ลัดที่ QGIS ใช้อยู่ (ไว้เตือนเมื่อตั้งคีย์ชนกันจน Qt ถือว่ากำกวม)"""
        keys = set()
        try:
            from qgis.gui import QgsGui
            mgr = QgsGui.shortcutsManager()
            for a in mgr.listActions():
                t = a.shortcut().toString()
                if t:
                    keys.add(t)
            for sc in mgr.listShortcuts():
                t = sc.key().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        try:
            for a in self.iface.mainWindow().findChildren(QtWidgets.QAction):
                t = a.shortcut().toString()
                if t:
                    keys.add(t)
        except Exception:
            pass
        return keys

    def create_dialog(self):
        self.dlg = QtWidgets.QDialog(self.iface.mainWindow())
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        self.dlg.setWindowIcon(QtGui.QIcon(icon_path))
        self.dlg.setWindowTitle(f"Multi-Layer Edit Pro {self.version}")
        self.dlg.setMinimumWidth(360)
        root = QtWidgets.QVBoxLayout(self.dlg)
        root.setSpacing(6)

        def mkbtn(text, slot, style="", tip=""):
            b = QtWidgets.QPushButton(text)
            b.setStyleSheet(style or "padding:5px;")
            b.setFixedHeight(34)   # สูงเท่ากันทุกปุ่ม (กันไทย/Latin/emoji เรนเดอร์สูงไม่เท่า)
            if tip:
                b.setToolTip(tip)
            b.clicked.connect(slot)
            return b

        # ---------- ชั้นข้อมูล (กระทัดรัด) ----------
        grp_layer = QtWidgets.QGroupBox("ชั้นข้อมูล")
        gl = QtWidgets.QGridLayout(grp_layer)
        gl.setHorizontalSpacing(6)
        gl.setVerticalSpacing(4)
        gl.setColumnStretch(0, 0)   # label ชิดซ้าย ไม่ยืด
        gl.setColumnStretch(1, 1)   # combo ดูดพื้นที่ว่างทั้งหมด -> label ชิด combo
        self.poly_cb = QtWidgets.QComboBox()
        self.point_cb = QtWidgets.QComboBox()
        gl.addWidget(QtWidgets.QLabel("แปลง:"), 0, 0)
        gl.addWidget(self.poly_cb, 0, 1)
        gl.addWidget(QtWidgets.QLabel("หมุด:"), 1, 0)
        gl.addWidget(self.point_cb, 1, 1)
        btn_refresh = mkbtn("🔄", self.refresh_layers, tip="Refresh Layers")
        btn_refresh.setFixedWidth(36)
        gl.addWidget(btn_refresh, 0, 2, 2, 1)
        root.addWidget(grp_layer)
        self.refresh_layers()

        # ---------- DOL search (คลิกแปลง -> เปิดเอกสาร) ----------
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn(
            "🔍 ค้นหาภาพลักษณ์", lambda: self.start_dol_search('image'),
            "background-color:#fff3e0; font-weight:bold; padding:8px; color:#e65100;"))
        r.addWidget(mkbtn(
            "📐 หลักฐานการรังวัด", lambda: self.start_dol_search('survey'),
            "background-color:#e3f2fd; font-weight:bold; padding:8px; color:#0d47a1;"))
        root.addLayout(r)

        # ---------- เลือก & ปรับแต่ง (หน้าเดียว) ----------
        grp_edit = QtWidgets.QGroupBox("เลือก / ปรับแต่ง")
        ve = QtWidgets.QVBoxLayout(grp_edit)
        ve.setSpacing(5)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("By Cluster ID", lambda: self.process_selection('cluster')))
        r.addWidget(mkbtn("By UTM", lambda: self.process_selection('utm')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Move", lambda: self.start_interactive('move')))
        r.addWidget(mkbtn("Rotate", lambda: self.start_interactive('rotate')))
        r.addWidget(mkbtn("Scale", lambda: self.start_interactive('scale')))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Transform (2 จุด)", lambda: self.start_interactive('transform'),
                          "background-color:#ffccbc; font-weight:bold; padding:6px;"))
        r.addWidget(mkbtn("Move Node (Sync)", self.start_sync_vertex_tool,
                          "background-color:#e8f5e9; font-weight:bold; padding:6px;"))
        ve.addLayout(r)
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("📏 Align Points", self.start_align_tool))
        r.addWidget(mkbtn("➕ Add Node", self.start_add_node,
                          "background-color:#e8f5e9; font-weight:bold; color:#1b5e20;"))
        ve.addLayout(r)
        root.addWidget(grp_edit)

        # ---------- จัดกลุ่ม / Score ----------
        grp_grp = QtWidgets.QGroupBox("จัดกลุ่ม / Score")
        vg = QtWidgets.QVBoxLayout(grp_grp)
        vg.setSpacing(5)
        vg.addWidget(mkbtn("🔗 Sync Cluster ID", self.group_cluster_ids,
                           "background-color:#e3f2fd; padding:6px;"))
        r = QtWidgets.QHBoxLayout()
        r.addWidget(mkbtn("Score = 1", lambda: self.set_score_value(1),
                          "background-color:#c8e6c9; font-weight:bold; color:#1b5e20; padding:6px;"))
        r.addWidget(mkbtn("Score = 0", lambda: self.set_score_value(0),
                          "background-color:#ffcdd2; font-weight:bold; color:#b71c1c; padding:6px;"))
        vg.addLayout(r)
        root.addWidget(grp_grp)

        # ---------- แถบ action (เห็นตลอด) ----------
        r = QtWidgets.QHBoxLayout()
        btn_reset = mkbtn("✖ Reset", self.cancel_transform)
        btn_undo = mkbtn("↺ Undo", self.undo_transform)
        for _b in (btn_reset, btn_undo):
            _b.setFixedHeight(34)   # บังคับสูงเท่ากัน (กัน emoji เรนเดอร์ไม่เท่า)
            r.addWidget(_b, 1)
        root.addLayout(r)
        root.addWidget(mkbtn("💾 บันทึก (Commit)", self.save_all_changes,
                             "background-color:#c8e6c9; font-weight:bold; padding:8px; color:#1b5e20;"))

        # ---------- footer ----------
        line = QtWidgets.QFrame()
        line.setFrameShape(QtWidgets.QFrame.HLine)
        root.addWidget(line)
        rf = QtWidgets.QHBoxLayout()
        btn_sc = mkbtn("⌨ ตั้งค่า Shortcut", self.open_shortcut_settings)
        btn_up = mkbtn("🚀 Check Update", self.update_plugin)
        for _b in (btn_sc, btn_up):
            _b.setFixedHeight(34)   # สูงเท่ากัน
            rf.addWidget(_b, 1)     # stretch เท่ากัน -> กว้างเท่ากัน
        root.addLayout(rf)
        lbl = QtWidgets.QLabel("ชาคฤตย์ จันทรสุกศรี · กองเทคโนโลยีทำแผนที่ กรมที่ดิน")
        f = QtGui.QFont()
        f.setPointSize(8)
        lbl.setFont(f)
        lbl.setAlignment(QtCore.Qt.AlignCenter)
        root.addWidget(lbl)
        self._load_shortcuts()   # ผูก shortcut ที่บันทึกไว้

    # ============ DOL iLands: ค้นหาเอกสารจากแปลง ============
    def start_dol_search(self, mode='image'):
        """เปิด map tool คลิกเลือกแปลง -> mode 'image'=ภาพลักษณ์(public) / 'survey'=หลักฐานรังวัด(login)"""
        self._dol_mode = mode
        lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if lyr is None:
            QtWidgets.QMessageBox.warning(
                self.dlg, "ไม่พบเลเยอร์", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        try:
            if lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
                QtWidgets.QMessageBox.warning(
                    self.dlg, "เลเยอร์ไม่ถูกต้อง", f"เลเยอร์ '{lyr.name()}' ไม่ใช่ Polygon")
                return
        except Exception:
            pass
        self._dol_clear_highlight()
        canvas = self.iface.mapCanvas()
        # ล็อกให้คลิก/ไฮไลต์ได้เฉพาะแปลงในเลเยอร์ที่เลือกในปลั๊กอินเท่านั้น
        self.temp_tool = PolygonPickTool(
            canvas, lyr, self._on_polygon_picked, self._dol_on_hover)
        canvas.setMapTool(self.temp_tool)
        what = "ภาพลักษณ์" if mode == 'image' else "หลักฐานการรังวัด"
        self.iface.messageBar().pushInfo(
            "DOL", f"คลิกบนแปลงในเลเยอร์ '{lyr.name()}' เพื่อค้นหา{what} (Esc เพื่อยกเลิก)")

    def _on_polygon_picked(self, feat, layer):
        """อ่าน attribute UTM ของแปลงที่คลิก (จากเลเยอร์ที่เลือก) แล้วยิงค้นหา"""
        def gv(name):
            try:
                if feat.fields().indexOf(name) < 0:
                    return ""
                v = feat[name]
                return "" if v is None else str(v).strip()
            except Exception:
                return ""

        m1, m2, m3 = gv("UTMMAP1"), gv("UTMMAP2"), gv("UTMMAP3")
        m4 = gv("UTMMAP4") or "00"
        scale = gv("UTMSCALE")
        landno = gv("LANDNO")
        self.iface.actionSelect().trigger()  # คืน cursor ปกติ

        # ไฮไลต์แปลงที่คลิกทันที (กรอบแดง)
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

        if not m1 or not m2 or not m3 or not scale or not landno:
            self._dol_clear_highlight()
            QtWidgets.QMessageBox.warning(
                self.dlg, "ข้อมูลแปลงไม่ครบ",
                f"แปลงนี้ไม่มี attribute ระวางครบ\n"
                f"UTMMAP={m1} {m2} {m3} {m4} | SCALE={scale} | LANDNO={landno}")
            return

        # centroid ของแปลงที่คลิก (แปลงเป็น datum 24047) -> ใช้แก้ปัญหา "ระวางคร่อมสาขา"
        # ที่ LAND_NO ซ้ำข้ามสาขา (เลือกแปลงที่ใกล้จุดคลิกสุด แทนการหยิบตัวแรกมั่ว)
        near_xy = None
        try:
            c = feat.geometry().centroid().asPoint()
            dst = QgsCoordinateReferenceSystem("EPSG:24047")
            if layer.crs() != dst:
                c = QgsCoordinateTransform(layer.crs(), dst, QgsProject.instance()).transform(c)
            near_xy = (c.x(), c.y())
        except Exception:
            near_xy = None

        attrs = {"m1": m1, "m2": m2, "m3": m3, "m4": m4,
                 "scale": scale, "landno": landno, "near_xy": near_xy}
        self._dol_attrs = attrs   # เก็บไว้ใช้ค้นหลักฐานรังวัด (ต้องใช้ utmmap เดิม)

        self._dol_busy = QtWidgets.QProgressDialog(
            f"กำลังค้นหา PARCEL_SEQ...\nระวาง {m1} {m2} {m3}-{m4} ที่ดิน {landno}",
            None, 0, 0, self.dlg)
        self._dol_busy.setWindowTitle("DOL")
        self._dol_busy.setCancelButton(None)
        self._dol_busy.setWindowModality(QtCore.Qt.WindowModal)
        self._dol_busy.show()

        self._dol_worker = ParcelLookupWorker(attrs, zone=47)
        self._dol_worker.done.connect(self._on_dol_done)
        self._dol_worker.fail.connect(self._on_dol_fail)
        self._dol_worker.start()

    def _on_dol_done(self, res):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()  # รันเสร็จ -> ลบไฮไลต์
        if not res:
            QtWidgets.QMessageBox.information(
                self.dlg, "ไม่พบแปลง", "ไม่พบแปลงในระบบ (ตรวจเลขระวาง / zone UTM)")
            return

        if getattr(self, "_dol_mode", "image") == "survey":
            self._open_survey(res)
            return

        # ภาพลักษณ์ -> เปิดทันที (ไม่เด้ง popup)
        if res.get("doc_url"):
            QtGui.QDesktopServices.openUrl(QtCore.QUrl(res["doc_url"]))
        warn = "" if res.get("verified") else "  ⚠️ MAP_PARCEL_SEQ ไม่ตรง"
        if res.get("match_count", 1) > 1:
            warn += f"  🔀 ระวางคร่อม {res['match_count']} สาขา (เลือกใกล้จุดคลิกสุด)"
        self.iface.messageBar().pushMessage(
            "DOL", f"โฉนด {res.get('parcel_no')} | {res.get('office','')} "
                   f"({res.get('city','')}) — เปิดภาพลักษณ์แล้ว{warn}", level=3, duration=8)

    # ---------- หลักฐานการรังวัด (ต้อง login) ----------
    def _dol_login_prompt(self):
        """popup ขอ user/pass แล้ว login (เก็บ session ใน memory เท่านั้น) -> True ถ้าสำเร็จ"""
        from . import dol_api
        dlg = QtWidgets.QDialog(self.dlg)
        dlg.setWindowTitle("เข้าสู่ระบบ DOL iLands")
        dlg.setMinimumWidth(320)
        form = QtWidgets.QFormLayout(dlg)
        ed_user = QtWidgets.QLineEdit()
        ed_pass = QtWidgets.QLineEdit()
        ed_pass.setEchoMode(QtWidgets.QLineEdit.Password)
        form.addRow("ผู้ใช้:", ed_user)
        form.addRow("รหัสผ่าน:", ed_pass)
        note = QtWidgets.QLabel("🔒 ไม่เก็บรหัสถาวร — ปิด QGIS แล้วต้องเข้าสู่ระบบใหม่")
        note.setStyleSheet("color:#666; font-size:11px;")
        form.addRow(note)
        bb = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        form.addRow(bb)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        ed_user.setFocus()
        if dlg.exec_() != QtWidgets.QDialog.Accepted:
            return False
        u, p = ed_user.text().strip(), ed_pass.text()
        if not u or not p:
            return False
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            dol_api.login(u, p)
        except dol_api.DOLAuthError as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self.dlg, "เข้าสู่ระบบไม่สำเร็จ", str(e))
            return False
        except Exception as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.critical(self.dlg, "เข้าสู่ระบบผิดพลาด", str(e))
            return False
        QtWidgets.QApplication.restoreOverrideCursor()
        return True

    def _cadastral_label(self, rec, i):
        """สร้างข้อความบรรยาย 1 รายการรังวัด (โชว์ field ที่มี)"""
        parts = []
        for k in ("CADASTRAL_NO", "CADASTRALNO", "SURVEY_NO", "SURVEYNO",
                  "TYPE_OF_SURVEY", "TYPEOFSURVEY", "SCALE", "SHEET_CODE",
                  "SHEETCODE", "SURVEY_DATE", "SURVEYDATE", "UTMMAP4"):
            v = rec.get(k)
            if v not in (None, "", "null"):
                parts.append(f"{k}={v}")
        label = " | ".join(parts) if parts else "(ไม่มีรายละเอียด)"
        return f"{i + 1}. {label}  [seq {rec.get('CADASTRAL_SEQ')}]"

    def _choose_cadastral(self, recs):
        """หลายรายการรังวัด -> popup ให้เลือก (คืน record หรือ None)"""
        items = [self._cadastral_label(rec, i) for i, rec in enumerate(recs)]
        item, ok = QtWidgets.QInputDialog.getItem(
            self.dlg, "เลือกหลักฐานการรังวัด",
            f"แปลงนี้มี {len(recs)} รายการ — เลือกที่ต้องการเปิด:", items, 0, False)
        if not ok:
            return None
        return recs[items.index(item)]

    def _open_survey(self, res):
        """ค้นหลักฐานรังวัดจากแปลงที่คลิก (login ถ้าจำเป็น) แล้วเปิด viewer; หลายรายการ -> ให้เลือก"""
        from . import dol_api
        attrs = getattr(self, "_dol_attrs", {}) or {}
        prov = dol_api.province_code_from_city(res.get("city", ""))
        office = res.get("office_seq")
        if not prov or not office:
            QtWidgets.QMessageBox.warning(
                self.dlg, "หลักฐานการรังวัด",
                f"ไม่ทราบจังหวัด/สำนักงานของแปลงนี้ ค้นหาไม่ได้\n({res.get('city','')})")
            return

        recs = None
        for attempt in range(2):
            if not dol_api.is_logged_in():
                if not self._dol_login_prompt():
                    return
            QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
            try:
                recs = dol_api.search_cadastral(
                    attrs.get("m1"), attrs.get("m2"), attrs.get("m3"), attrs.get("m4"),
                    attrs.get("scale"), attrs.get("landno"), prov, office, zone=47)
            except dol_api.DOLAuthError as e:
                QtWidgets.QApplication.restoreOverrideCursor()
                dol_api.logout()
                if attempt == 0:
                    QtWidgets.QMessageBox.information(self.dlg, "เข้าสู่ระบบใหม่", str(e))
                    continue          # ลอง login + ค้นใหม่อีกครั้ง
                QtWidgets.QMessageBox.warning(self.dlg, "หลักฐานการรังวัด", str(e))
                return
            except Exception as e:
                QtWidgets.QApplication.restoreOverrideCursor()
                QtWidgets.QMessageBox.critical(self.dlg, "ค้นหารังวัดผิดพลาด", str(e))
                return
            QtWidgets.QApplication.restoreOverrideCursor()
            break
        if recs is None:
            return

        if not recs:
            QtWidgets.QMessageBox.information(
                self.dlg, "ไม่พบหลักฐานการรังวัด",
                "ไม่พบหลักฐานการรังวัดของแปลงนี้\n"
                f"(ค้นด้วยระวาง {attrs.get('m1')} {attrs.get('m2')} {attrs.get('m3')}-"
                f"{attrs.get('m4')} ที่ดิน {attrs.get('landno')} • สนง.{office})")
            return

        rec = recs[0] if len(recs) == 1 else self._choose_cadastral(recs)
        if rec is None:
            return
        url = dol_api.survey_doc_url(rec.get("CADASTRAL_SEQ"), "1")
        QtGui.QDesktopServices.openUrl(QtCore.QUrl(url))
        self.iface.messageBar().pushMessage(
            "DOL", f"เปิดหลักฐานการรังวัด (พบ {len(recs)} รายการ) — "
                   f"CADASTRAL_SEQ {rec.get('CADASTRAL_SEQ')}", level=3, duration=8)

    def _on_dol_fail(self, msg):
        if getattr(self, "_dol_busy", None):
            self._dol_busy.close()
        self._dol_clear_highlight()
        QtWidgets.QMessageBox.critical(self.dlg, "DOL ผิดพลาด", msg)

    def _dol_highlight_feature(self, geom, layer):
        """ไฮไลต์แปลงบนแผนที่ด้วยกรอบแดง"""
        self._dol_clear_highlight()
        if geom is None or geom.isEmpty():
            return
        canvas = self.iface.mapCanvas()
        rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        rb.setColor(QtGui.QColor(255, 0, 0))
        rb.setFillColor(QtGui.QColor(255, 0, 0, 50))
        rb.setWidth(3)
        rb.setToGeometry(geom, layer)
        rb.show()
        self._dol_highlight = rb
        # ไม่เรียก canvas.refresh() — rubber band วาดตัวเองอยู่แล้ว (เดิม refresh ทั้งแมพทุกครั้งที่ hover แปลง = หน่วง)

    def _dol_clear_highlight(self):
        rb = getattr(self, "_dol_highlight", None)
        if rb is not None:
            try:
                rb.hide()
                self.iface.mapCanvas().scene().removeItem(rb)
            except Exception:
                pass
            self._dol_highlight = None

    def _dol_on_hover(self, feat, layer):
        """ไฮไลต์แปลงใต้เมาส์ก่อนคลิก (ตัวช่วยตัดสินใจ)"""
        if feat is None:
            self._dol_clear_highlight()
            return
        try:
            self._dol_highlight_feature(QgsGeometry(feat.geometry()), layer)
        except Exception:
            pass

    # --- หัวใจสำคัญ: ระบบป้องกัน Selection หาย ---
    def restore_selection(self):
        """บังคับคืนค่า Selection จากหน่วยความจำสำรอง"""
        for lyr_id, ids in self.stored_selection.items():
            lyr = QgsProject.instance().mapLayer(lyr_id)
            if lyr:
                lyr.selectByIds(ids)
        self.iface.mapCanvas().refresh()

    def set_select_tool(self):
        self.iface.actionSelect().trigger()

    def refresh_layers(self):
        # แปลง = เฉพาะเลเยอร์ Polygon, หมุด = เฉพาะเลเยอร์ Point
        self.poly_cb.clear(); self.point_cb.clear()
        self._field_cache.clear()   # รายชื่อเลเยอร์เปลี่ยน -> ล้าง cache field กันชื่อค้าง
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                gt = lyr.geometryType()   # มีเฉพาะ vector layer (raster -> error -> ข้าม)
            except Exception:
                continue
            if gt == QgsWkbTypes.PolygonGeometry:
                self.poly_cb.addItem(lyr.name(), lyr.id())
            elif gt == QgsWkbTypes.PointGeometry:
                self.point_cb.addItem(lyr.name(), lyr.id())
    def setup_snapping(self):
        self.canvas = self.iface.mapCanvas()
        config = QgsProject.instance().snappingConfig()
        if not config.enabled():
            config.setEnabled(True)
            config.setMode(QgsSnappingConfig.AllLayers)
            # ปรับความแรงในการดูด (Tolerance) เป็น 15-20 pixels
            config.setTolerance(20) 
            config.setUnits(QgsTolerance.Pixels)
            # ให้ Snap ทั้งจุด (Vertex) และเส้น (Segment)
            config.setType(QgsSnappingConfig.VertexAndSegment) 
            QgsProject.instance().setSnappingConfig(config)
        
        self.snap_utils = self.canvas.snappingUtils()
        self.snap_indicator = QgsSnapIndicator(self.canvas)
        
    def start_interactive(self, mode):
        # 1. เลือก UTM ก่อน
        self.process_selection('utm')
        
        # 2. เช็คว่ามีอะไรถูกเลือกไหม
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        if not poly_lyr or poly_lyr.selectedFeatureCount() == 0:
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกแปลงที่ต้องการก่อน", level=2, duration=10)
            return

        # 3. เคลียร์ Marker เก่า (แต่ไม่เคลียร์ Selection!)
        self.clear_markers()
        self.src_pts = []
        
        # 4. ตั้งค่า Tool
        self.mode = mode
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.iface.mapCanvas())
        self.temp_tool.canvasClicked.connect(self.handle_click)
        self.temp_tool.canvasMoveEvent = self.handle_generic_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)

    def handle_click(self, point, button):
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        
        # 2. เลือกพิกัด: ถ้า Snap ติดใช้จุด Snap ถ้าไม่ติดใช้ point (ที่ว่าง) ตรงๆ
        pt = match.point() if match.isValid() and match.point().x() != 0 else point
        
        # กำหนดสี Marker: Snap=แดง, ที่ว่าง=น้ำเงิน
        color = QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255)

        # 3. วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setPenWidth(4)
        m.setColor(color)
        m.setIconType(QgsVertexMarker.ICON_X)
        self.markers.append(m)
        self.src_pts.append(QgsPointXY(pt.x(), pt.y())) # บังคับเป็น PointXY
        
        # 4. ตรวจสอบจำนวนจุดตามโหมด
        limit = {'move': 2, 'modify_node': 2, 'rotate': 3, 'scale': 3, 'transform': 4}.get(self.mode, 2)
        
        if len(self.src_pts) >= limit:
            self.execute_tool()
            
    def handle_generic_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือทั่วไป (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            # แทนที่จะใส่ None ให้ใช้ Match ว่างๆ แทนครับ
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            
    def execute_tool(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        layers = [l for l in [poly_lyr, point_lyr] if l and l.selectedFeatureCount() > 0]
        
        if not layers:
            self.cancel_transform()
            return
            
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self.last_layers = layers
        p = self.src_pts

        # ─── ตรวจสอบกฎการล็อกแปลง L1-RTK / L1-TS ───
        if poly_lyr:
            type_idx = self._field_index(poly_lyr.fields(), 'type')
            if type_idx != -1:
                poly_ids = poly_lyr.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_lyr.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str == "L1-RTK":
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-RTK ซึ่งเป็นพิกัดอ้างอิงหลัก ไม่สามารถขยับได้!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return
                            elif val_str == "L1-TS":
                                # ยกเว้นกรณีใช้ปุ่ม transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                                if self.mode == 'transform' and len(p) >= 4:
                                    p2, p4 = p[1], p[3]
                                    if self._is_point_on_rtk_node(poly_lyr, p2) and self._is_point_on_rtk_node(poly_lyr, p4):
                                        continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                                        
                                self.iface.messageBar().pushMessage(
                                    "MLEP Lock", 
                                    f"แปลง {f.id()} เป็นประเภท L1-TS ไม่สามารถขยับได้ ยกเว้นใช้โหมด Transform (2 Pts) ไปต่อกับ L1-RTK เท่านั้น!", 
                                    level=2, duration=10
                                )
                                self.cancel_transform()
                                return

        # ตรวจสอบสิทธิ์การขยับพิกัดผ่านจุดหมุด (กรณีจุดหมุดถูกเลือก)
        if point_lyr and point_lyr.selectedFeatureCount() > 0 and poly_lyr:
            lock_cache = {}   # memoize ผลล็อกตามค่า UTM (ลด query ชั้นแปลงเมื่อหมุดเยอะ)
            for pt_f in point_lyr.selectedFeatures():
                is_locked, type_str = self._is_point_feature_locked(poly_lyr, pt_f, lock_cache)
                if is_locked:
                    # ข้อยกเว้นเฉพาะโหมด transform (2 pts) และจุดปลายทาง (P2, P4) แนบกับ L1-RTK
                    if type_str == "L1-TS" and self.mode == 'transform' and len(p) >= 4:
                        p2, p4 = p[1], p[3]
                        if self._is_point_on_rtk_node(poly_lyr, p2) and self._is_point_on_rtk_node(poly_lyr, p4):
                            continue # ผ่านเงื่อนไขพิเศษ ยอมให้ทำ
                            
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return
                    else:
                        self.iface.messageBar().pushMessage(
                            "MLEP Lock", 
                            f"จุดหมุด {pt_f.id()} อยู่บนแปลงประเภท {type_str} ซึ่งถูกล็อกขยับ!", 
                            level=2, duration=10
                        )
                        self.cancel_transform()
                        return

        # เปิด edit ทั้งเลเยอร์แปลง+หมุดที่ตั้งค่าไว้ แยกจากเงื่อนไข selection
        # (แก้: บางทีหมุดไม่ถูกเลือก -> point layer ไม่ขึ้น edit)
        for _l in (poly_lyr, point_lyr):
            if _l and not _l.isEditable():
                _l.startEditing()

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            if not lyr.isEditable(): lyr.startEditing()
            lyr.beginEditCommand(f"MLEP {self.mode}")
            
            try:
                # Optimize: ดึงเฉพาะ Geometry และรวบรวมเป็น list ก่อนวนลูปแก้ไข เพื่อป้องกันปัญหา cursor ล็อกขณะเขียนข้อมูล
                req = QgsFeatureRequest().setFilterFids(lyr.selectedFeatureIds()).setNoAttributes()
                features = list(lyr.getFeatures(req))
                for f in features:
                    geom = f.geometry()
                    if geom.isNull(): continue

                    # --- 1. Move ---
                    if self.mode == 'move' and len(p) >= 2:
                        dx, dy = p[1].x() - p[0].x(), p[1].y() - p[0].y()
                        geom.translate(dx, dy)
                        lyr.changeGeometry(f.id(), geom)

                    # --- 2. Rotate (ใส่ลบหน้ามุมตามที่ตกลงกัน) ---
                    elif self.mode == 'rotate' and len(p) >= 3:
                        a1 = math.atan2(p[1].y()-p[0].y(), p[1].x()-p[0].x())
                        a2 = math.atan2(p[2].y()-p[0].y(), p[2].x()-p[0].x())
                        geom.rotate(-math.degrees(a2 - a1), QgsPointXY(p[0].x(), p[0].y()))
                        lyr.changeGeometry(f.id(), geom)

                    # --- 3. Scale (ปรับใหม่ให้ชัวร์) ---
                    elif self.mode == 'scale' and len(p) >= 3:
                        d1 = math.sqrt(p[0].sqrDist(p[1]))
                        d2 = math.sqrt(p[0].sqrDist(p[2]))
                        if d1 > 0:
                            s = d2 / d1
                            # ย้ายเข้าจุดหมุน (p0) -> Scale -> ย้ายกลับ
                            geom.translate(-p[0].x(), -p[0].y())
                            matrix = QtGui.QTransform(); matrix.scale(s, s)
                            geom.transform(matrix)
                            geom.translate(p[0].x(), p[0].y())
                            lyr.changeGeometry(f.id(), geom)

                    # --- 4. Transform ---
                    elif self.mode == 'transform' and len(p) >= 4:
                        self.apply_similarity_direct(lyr, f, p)

                    # --- 5. Move Node (Optimized via C++ closestVertex) ---
                    elif self.mode == 'modify_node' and len(p) >= 2:
                        closest_pt, vertex_idx, prev_idx, next_idx, sqr_dist = geom.closestVertex(p[0])
                        if sqr_dist < 0.000001:  # threshold 0.001 (sqrDist = 0.001 ** 2)
                            if vertex_idx >= 0:
                                lyr.moveVertex(p[1].x(), p[1].y(), f.id(), vertex_idx)
                
                lyr.endEditCommand()
            except Exception as e:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("MLEP Error", f"เกิดข้อผิดพลาดใน {lyr.name()}: {e}", level=2, duration=0)
                print(f"Error in execute_tool for layer {lyr.name()}: {e}")

        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        self.iface.mapCanvas().refresh()
        self.clear_markers()
        self.src_pts = []
        if self.mode == 'transform' :
            self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def apply_similarity_direct(self, lyr, f, p):
        """คำนวณ Transform แบบ Matrix (Similarity)"""
        s1, d1, s2, d2 = p[0], p[1], p[2], p[3]
        dsx, dsy = s2.x() - s1.x(), s2.y() - s1.y()
        ddx, ddy = d2.x() - d1.x(), d2.y() - d1.y()
        mag_s_sq = dsx**2 + dsy**2
        if mag_s_sq == 0: return
        
        a = (dsx * ddx + dsy * ddy) / mag_s_sq
        b = (dsx * ddy - dsy * ddx) / mag_s_sq
        tx = d1.x() - (a * s1.x() - b * s1.y())
        ty = d1.y() - (b * s1.x() + a * s1.y())
        
        geom = f.geometry()
        # x' = ax - by + tx , y' = bx + ay + ty
        matrix = QtGui.QTransform(a, b, -b, a, tx, ty)
        geom.transform(matrix)
        lyr.changeGeometry(f.id(), geom)

    @staticmethod
    def _field_index(fields, names):
        """index ของฟิลด์แรกที่ชื่อ (ตัวพิมพ์เล็ก) อยู่ใน names; -1 ถ้าไม่พบ
        names = str (ชื่อเดียว) หรือ set ของชื่อ"""
        if isinstance(names, str):
            names = {names}
        for i, f in enumerate(fields):
            if f.name().lower() in names:
                return i
        return -1

    def _is_point_on_rtk_node(self, poly_lyr, point_xy):
        """ตรวจสอบว่าพิกัด point_xy อยู่บน Node ของแปลงประเภท L1-RTK หรือไม่"""
        type_idx = self._field_index(poly_lyr.fields(), 'type')
        if type_idx == -1:
            return False

        # สี่เหลี่ยมตรงๆ (เลี่ยง buffer() ที่สร้าง geometry วงกลมทิ้ง)
        search_rect = QgsRectangle(point_xy.x() - 0.05, point_xy.y() - 0.05,
                                   point_xy.x() + 0.05, point_xy.y() + 0.05)
        # ดึง geometry มาในคิวรีเดียว (เดิม query แบบ NoGeometry แล้วค่อย getFeature ซ้ำต่อ candidate)
        req = QgsFeatureRequest().setFilterRect(search_rect).setSubsetOfAttributes([type_idx])
        for feat in poly_lyr.getFeatures(req):
            val = feat.attribute(type_idx)
            if val is not None and str(val).strip().upper() == "L1-RTK":
                geom = feat.geometry()
                if geom and not geom.isNull():
                    _cp, vertex_idx, _pi, _ni, sqr_dist = geom.closestVertex(point_xy)
                    if sqr_dist < 0.0025:  # 0.05 ** 2
                        return True
        return False

    def _is_point_feature_locked(self, poly_lyr, point_f, cache=None):
        """ตรวจสอบว่าฟีเจอร์จุดหมุดนี้เชื่อมโยงกับแปลงที่ถูกล็อก (L1-RTK หรือ L1-TS) ผ่านฟิลด์ UTM
        ใช้ expression เทียบ UTM ตรงๆ (เหมือนพฤติกรรมเดิมเป๊ะ) — กันเคส match กว้างเกินจน blocking หมุดปกติ

        cache: dict {utm_str: (is_locked, type)} ส่งมาจาก caller ที่วนหลายหมุด -> memoize ผลตามค่า UTM
        (หมุดมักใช้ UTM ร่วมกันหลายตัว → query ลดจาก N เหลือเท่าจำนวน UTM ที่ต่างกัน, match เหมือนเดิม)"""
        point_utm_field = next(
            (f.name() for f in point_f.fields()
             if f.name().lower() in _UTM_FIELD_NAMES),
            None
        )
        poly_utm_field = self._resolve_field(poly_lyr, _UTM_FIELD_NAMES)
        poly_type_field = self._resolve_field(poly_lyr, {'type'})

        if not point_utm_field or not poly_utm_field or not poly_type_field:
            return False, None

        utm_val = point_f[point_utm_field]
        if utm_val is None:
            return False, None

        key = str(utm_val).strip()
        if cache is not None and key in cache:
            return cache[key]

        expr = f'"{poly_utm_field}" = \'{key}\''
        req = QgsFeatureRequest().setFilterExpression(expr).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([poly_lyr.fields().indexFromName(poly_type_field)])

        result = (False, None)
        for poly_feat in poly_lyr.getFeatures(req):
            val = poly_feat[poly_type_field]
            if val is not None:
                val_str = str(val).strip().upper()
                if val_str in ("L1-RTK", "L1-TS"):
                    result = (True, val_str)
                    break

        if cache is not None:
            cache[key] = result
        return result

    def set_score_value(self, value):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย score จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())

        # ตรวจสอบกฎการห้ามใส่ Score ให้กับแปลง L1-RTK และ L1-TS
        if poly_layer:
            type_idx = self._field_index(poly_layer.fields(), 'type')
            if type_idx != -1:
                poly_ids = poly_layer.selectedFeatureIds()
                if poly_ids:
                    req_type = QgsFeatureRequest().setFilterFids(poly_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([type_idx])
                    for f in poly_layer.getFeatures(req_type):
                        val = f.attribute(type_idx)
                        if val is not None:
                            val_str = str(val).strip().upper()
                            if val_str in ("L1-RTK", "L1-TS"):
                                self.iface.messageBar().pushMessage(
                                    "Score Blocked", 
                                    f"แปลง {f.id()} เป็นประเภท {val_str} ไม่อนุญาตให้ตั้งค่า Score!", 
                                    level=2, duration=10
                                )
                                return
                                
        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        if not layers: return

        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            # ตรวจสอบว่าเลเยอร์อยู่ในโหมดแก้ไขหรือไม่
            if not lyr.isEditable():
                lyr.startEditing()
            
            # เริ่มบันทึกคำสั่งสำหรับ Undo
            lyr.beginEditCommand(f"Change Score to {value}")
            
            # ค้นหา index ของฟิลด์ Score
            idx = -1
            for i, field in enumerate(lyr.fields()):
                if field.name().lower() == 'score':
                    idx = i
                    break
            
            if idx != -1:
                # Optimize: วนลูปแก้เฉพาะค่า Attribute ผ่าน ID โดยตรงเพื่อความรวดเร็วและใช้แรมน้อย
                for fid in lyr.selectedFeatureIds():
                    lyr.changeAttributeValue(fid, idx, value)
                lyr.endEditCommand() # ปิดคำสั่ง (จะถูกส่งเข้า Undo Stack ของ QGIS)
            else:
                lyr.destroyEditCommand()
                self.iface.messageBar().pushMessage("Error", f"ไม่พบฟิลด์ Score ใน {lyr.name()}", level=2, duration=0)

        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        self.iface.mapCanvas().refresh()
        QtCore.QTimer.singleShot(100, self.restore_selection)

    def group_cluster_ids(self):
        # บังคับเลือกกลุ่มด้วย By UTM ก่อน -> หมุดในกลุ่มถูกเลือกด้วย cluster id จะลงหมุดด้วย
        self.process_selection('utm')
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer or poly_layer.selectedFeatureCount() == 0: return
        fields = [f.name() for f in poly_layer.fields()]
        target_field = next((f for f in fields if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
        if not target_field: return
        
        # Optimize: ดึงค่าเฉพาะ Attribute ฟิลด์แรกที่เลือกโดยไม่ต้องดึงพิกัดเพื่อประหยัดหน่วยความจำ
        first_id = poly_layer.selectedFeatureIds()[0]
        f_idx = poly_layer.fields().indexFromName(target_field)
        req = QgsFeatureRequest().setFilterFid(first_id).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([f_idx])
        first_feat = next(poly_layer.getFeatures(req), None)
        if not first_feat: return
        main_val = first_feat[target_field]

        layers = [l for l in [poly_layer, point_layer] if l and l.selectedFeatureCount() > 0]
        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in layers}
        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์ (เดิมไม่ track -> undo เพี้ยน)
        for lyr in layers:
            if not lyr.isEditable():
                lyr.startEditing()
            lyr.beginEditCommand("Group Cluster ID")
            lyr_f = [f.name() for f in lyr.fields()]
            lyr_t = next((f for f in lyr_f if f.lower() in ['cluster_id', 'clusterid', 'id_cluster']), None)
            if lyr_t:
                idx = lyr.fields().indexFromName(lyr_t)
                # Optimize: แก้ไขเฉพาะค่า Attribute ผ่าน IDs โดยตรง
                for fid in lyr.selectedFeatureIds():
                    lyr.changeAttributeValue(fid, idx, main_val)
            lyr.endEditCommand()
        self._op_commit()   # ปิด operation -> เก็บประวัติ undo
        QtCore.QTimer.singleShot(100, self.restore_selection)
        self.set_select_tool()

    def clear_markers(self):
        for m in self.markers:
            if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []

    def cancel_transform(self):
        """ล้างค่าหน้าจอและทำลายตัวช่วย Snap อย่างปลอดภัย"""
        if hasattr(self, 'snap_indicator') and self.snap_indicator:
            # ล้างสัญลักษณ์บนหน้าจอก่อนทำลาย Object
            self.snap_indicator.setMatch(QgsPointLocator.Match())
            self.snap_indicator = None

        self.clear_rubber_band()
        self._dol_clear_highlight()
        self._align_picked_ids = set()
        self._align_clear_highlight()
        
        # รีเซ็ตเครื่องมือ Semi-Auto (ถ้ามี)
        if hasattr(self, 'temp_tool') and self.temp_tool:
            if hasattr(self.temp_tool, 'reset_tool'):
                try:
                    self.temp_tool.reset_tool()
                except Exception:
                    pass

        if hasattr(self, 'markers'):
            for m in self.markers:
                if m: self.iface.mapCanvas().scene().removeItem(m)
        self.markers = []
        self.src_pts = []

        # ล้าง feature ที่ถูกเลือกไว้ในทุกเลเยอร์ของ QGIS
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if isinstance(lyr, QgsVectorLayer) and lyr.selectedFeatureCount():
                    lyr.removeSelection()
            except Exception:
                pass

        self.iface.mapCanvas().refresh()
        self.iface.actionSelect().trigger()

    # ============ ระบบ Undo: นับ undo-command ต่อเลเยอร์ ต่อ operation ============
    def _watch_layer_editing(self, lyr):
        """ต่อ signal commit/rollback ของเลเยอร์ (ครั้งเดียวต่อเลเยอร์) เพื่อรู้ว่าตอนปิด edit
        กด Save (commit) หรือ Discard (rollback) — ใช้ตัดสินตอน undo เจอเลเยอร์ที่ถูกปิด"""
        if lyr is None:
            return
        lid = lyr.id()
        if lid in self._signal_layers:
            return
        self._signal_layers.add(lid)

        def on_commit(_lid=lid):
            self._edit_end[_lid] = 'commit'

        def on_rollback(_lid=lid):
            self._edit_end[_lid] = 'rollback'

        def on_start(_lid=lid):
            self._edit_end.pop(_lid, None)   # เปิด edit ใหม่ -> ล้างสถานะเก่า

        # ต่อแยกทีละ signal (try ของใครของมัน) — ถ้าชื่อ signal ใดต่างใน QGIS บางรุ่น
        # ตัวที่เหลือยังทำงาน (อย่างน้อย degrade เป็น "บล็อกเมื่อเลเยอร์ปิด" ซึ่งปลอดภัย)
        for sig_name, slot in (("afterCommitChanges", on_commit),
                               ("beforeCommitChanges", on_commit),
                               ("afterRollBack", on_rollback),
                               ("beforeRollBack", on_rollback),
                               ("editingStarted", on_start)):
            sig = getattr(lyr, sig_name, None)
            if sig is None:
                continue
            try:
                sig.connect(slot)
                self._signal_conns.append((sig, slot))
            except Exception:
                pass

    def _op_begin(self, layers):
        """บันทึกตำแหน่ง undo-stack ปัจจุบันของแต่ละเลเยอร์ ก่อนเริ่ม operation (ไว้คำนวณ delta)
        + ต่อ signal ดักการปิด edit (Save/Discard) ของเลเยอร์เหล่านั้น"""
        baseline = {}
        for lyr in layers:
            if lyr is None:
                continue
            try:
                baseline[lyr.id()] = (lyr, lyr.undoStack().index())
                self._watch_layer_editing(lyr)
            except Exception:
                pass
        self._op_baseline = baseline

    def _op_commit(self):
        """ปิด operation: เลเยอร์ไหนถูก push undo-command เพิ่ม (delta>0) เก็บเป็น 1 รายการในประวัติ
        delta คำนวณจาก index ของ QUndoStack -> empty command (ไม่ถูก push) จะได้ delta=0 อัตโนมัติ"""
        base = self._op_baseline
        self._op_baseline = None
        if not base:
            return
        op = []
        for lyr, before in base.values():
            try:
                delta = lyr.undoStack().index() - before
            except Exception:
                delta = 0
            if delta > 0:
                op.append((lyr, delta))
        if op:
            self.op_history.append(op)
            if len(self.op_history) > 100:   # กันโตไม่จำกัด
                self.op_history.pop(0)
            self.last_layers = [lyr for lyr, _ in op]   # เผื่อโค้ดอื่นอ้างอิง

    def undo_transform(self):
        """ย้อน operation ล่าสุดของปลั๊กอิน — ย้อนแต่ละเลเยอร์ตามจำนวน step ที่มัน push จริง
        Guard: ถ้ามีเลเยอร์ในรายการถูกปิด edit ไปแล้ว (ประวัติหาย) จะแยกเคส
          • Save  -> บล็อก (popup เตือน) เพราะย้อนเลเยอร์เดียวจะทำให้ไม่ตรงกัน
          • Discard -> popup ถามว่าจะย้อนเลเยอร์ที่ยังเปิดอยู่กลับ "จุดเริ่มเปิดแก้ไข" ให้ตรงกันไหม"""
        if not self.op_history:
            self.iface.messageBar().pushMessage("Undo", "ไม่มีรายการล่าสุดให้ย้อนกลับ", level=2, duration=10)
            return

        op = self.op_history[-1]   # ยังไม่ pop เผื่อบล็อก/ยกเลิก
        live, saved_gone, disc_gone, unknown_gone = [], [], [], []
        for lyr, n in op:
            if lyr is None:
                continue
            try:
                if lyr.isEditable() and lyr.undoStack().canUndo():
                    live.append((lyr, n))          # ยังย้อนผ่าน stack ได้
                else:
                    ev = self._edit_end.get(lyr.id())
                    if ev == 'rollback':
                        disc_gone.append(lyr)      # ปิดแบบ Discard
                    elif ev == 'commit':
                        saved_gone.append(lyr)     # ปิดแบบ Save
                    else:
                        unknown_gone.append(lyr)   # ไม่รู้สถานะ -> กันไว้เหมือน Save
            except Exception:
                unknown_gone.append(lyr)

        # ---- เคสปกติ: ทุกเลเยอร์ยังเปิดอยู่ -> ย้อนตาม step ----
        if not (saved_gone or disc_gone or unknown_gone):
            self.op_history.pop()
            for lyr, n in live:
                stack = lyr.undoStack()
                for _ in range(n):
                    if not stack.canUndo():
                        break
                    stack.undo()
            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage("Undo", "ย้อนกลับการทำงานล่าสุดเรียบร้อยแล้ว", level=1, duration=8)
            return

        # ---- มีเลเยอร์ปิด+Save (หรือไม่รู้สถานะ) -> บล็อก (popup เตือน) ----
        if saved_gone or unknown_gone:
            names = ", ".join(l.name() for l in (saved_gone + unknown_gone))
            QtWidgets.QMessageBox.warning(
                self.dlg, "ย้อนกลับไม่ได้",
                f"เลเยอร์ '{names}' ถูกปิดแก้ไข/บันทึกไปแล้ว — ประวัติ undo หายไป\n\n"
                "ย้อนอัตโนมัติไม่ได้ เพราะจะทำให้ 2 เลเยอร์ไม่ตรงกัน\n"
                "ให้เปิด Toggle Editing ของเลเยอร์นั้นก่อน แล้วแก้ด้วยตนเอง")
            return   # ไม่ pop ไม่ย้อนอะไร

        # ---- เลเยอร์ที่หายเป็น Discard ทั้งหมด ----
        disc_names = ", ".join(l.name() for l in disc_gone)
        if not live:
            # ทั้ง op เป็น Discard -> ทุกเลเยอร์กลับจุดเริ่มอยู่แล้ว ไม่ต้องทำอะไร
            self.op_history.pop()
            self.iface.messageBar().pushMessage(
                "Undo", f"เลเยอร์ '{disc_names}' ถูกปิดแบบไม่เซฟ — ข้อมูลกลับจุดเริ่มแล้ว ไม่ต้องย้อนเพิ่ม",
                level=1, duration=10)
            return

        # มีทั้ง Discard และเลเยอร์ที่ยังเปิด -> ถามว่าจะย้อนเลเยอร์ที่เปิดกลับจุดเริ่มให้ตรงกันไหม
        live_names = ", ".join(l.name() for l, _ in live)
        ans = QtWidgets.QMessageBox.question(
            self.dlg, "เลเยอร์ถูกปิดแบบไม่เซฟ",
            f"เลเยอร์ '{disc_names}' ถูกปิดแก้ไขแบบไม่บันทึก → ข้อมูลกลับไป "
            "'จุดเริ่มเปิดแก้ไข' แล้ว (ไม่ใช่แค่ครั้งล่าสุด)\n\n"
            f"ต้องการย้อนเลเยอร์ที่ยังเปิดอยู่ ('{live_names}') กลับไปจุดเริ่มด้วย "
            "เพื่อให้ทั้งสองตรงกันไหม?\n"
            "⚠️ งานทั้งหมดที่ทำไว้ในเลเยอร์นี้ (ตั้งแต่เปิดแก้ไข) จะถูกย้อนทิ้ง",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            QtWidgets.QMessageBox.No)
        if ans == QtWidgets.QMessageBox.Yes:
            for lyr, _n in live:
                stack = lyr.undoStack()
                while stack.canUndo():      # ย้อนสุด -> จุดเริ่ม session
                    stack.undo()
            self.op_history.clear()          # ทุกอย่างถูกย้อนหมดแล้ว
            self.iface.mapCanvas().refresh()
            self.iface.messageBar().pushMessage(
                "Undo", "ย้อนทั้งสองเลเยอร์กลับจุดเริ่มเปิดแก้ไขแล้ว", level=1, duration=8)
        # No -> ไม่ทำอะไร (คงสถานะไว้)

    def save_all_changes(self):
        for lyr in [QgsProject.instance().mapLayer(self.poly_cb.currentData()), QgsProject.instance().mapLayer(self.point_cb.currentData())]:
            if lyr and lyr.isEditable(): lyr.commitChanges(); lyr.startEditing()
        # commitChanges ล้าง undo-stack ของ QGIS -> ประวัติเก่าย้อนไม่ได้แล้ว เคลียร์ทิ้ง
        self.op_history.clear()
        self._op_baseline = None
        self.iface.messageBar().pushMessage("Save", "บันทึกสำเร็จ", level=3, duration=3)

    def update_plugin(self):
        V_URL = "https://raw.githubusercontent.com/chakrit39/Multi_Layer_Edit_Pro/refs/heads/main/version.txt"
        Z_URL = "https://github.com/chakrit39/Multi_Layer_Edit_Pro/raw/refs/heads/main/Multi_Layer_Edit_Pro.zip"

        def _vkey(v):
            try:
                return tuple(int(x) for x in str(v).strip().split("."))
            except Exception:
                return (0,)

        # ทำใน main thread (popup เด้งชัวร์) — เช็คเวอร์ชันเร็ว มี wait cursor พอ
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            res = requests.get(V_URL, timeout=8)
            new_version = res.text.strip()
        except Exception as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.warning(self.dlg, "Update Error", f"ไม่สามารถตรวจสอบอัปเดตได้:\n{e}")
            return
        QtWidgets.QApplication.restoreOverrideCursor()
        if _vkey(new_version) > _vkey(self.version):
            self.prompt_update(new_version, Z_URL)
        else:
            QtWidgets.QMessageBox.information(
                self.dlg, "Update", f"คุณใช้เวอร์ชันล่าสุดแล้ว (v{self.version})")

    def prompt_update(self, new_version, download_url):
        if QtWidgets.QMessageBox.question(
                self.dlg, "Update",
                f"พบเวอร์ชันใหม่ {new_version} ต้องการอัปเดตไหม?") != QtWidgets.QMessageBox.Yes:
            return
        QtWidgets.QApplication.setOverrideCursor(QtCore.Qt.WaitCursor)
        try:
            r = requests.get(download_url, timeout=60)
            z = zipfile.ZipFile(io.BytesIO(r.content))
            dest_dir = os.path.dirname(os.path.dirname(__file__))
            z.extractall(dest_dir)
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.information(self.dlg, "Done", "อัปเดตเสร็จแล้ว! กรุณา Restart QGIS")
        except Exception as e:
            QtWidgets.QApplication.restoreOverrideCursor()
            QtWidgets.QMessageBox.critical(self.dlg, "Update Error", f"การดาวน์โหลดล้มเหลว:\n{e}")

    def process_selection(self, mode):
        poly_layer = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_layer = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_layer: return
        selected_ids = poly_layer.selectedFeatureIds()
        if not selected_ids: return
        
        fields = poly_layer.fields()
        target_names = (['cluster_id', 'clusterid', 'id_cluster'] if mode == 'cluster' else ['utm', 'utm_code', 'utm_id'])
        target = None
        target_idx = -1
        for i, field in enumerate(fields):
            if field.name().lower() in target_names:
                target = field.name()
                target_idx = i
                break
        if target_idx == -1: return
        
        # Optimize: ดึงเฉพาะข้อมูล Attribute ของฟิลด์ที่กำหนดโดยไม่ดึงพิกัดเพื่อประหยัดหน่วยความจำ
        req = QgsFeatureRequest().setFilterFids(selected_ids).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([target_idx])
        v_list = []
        for f in poly_layer.getFeatures(req):
            val = f.attribute(target_idx)
            if val is not None:
                v_list.append(f"'{val}'" if isinstance(val, str) else str(val))
        
        if v_list:
            expr = f'"{target}" IN ({",".join(list(set(v_list)))})'
            poly_layer.selectByExpression(expr)
            if point_layer: point_layer.selectByExpression(expr)
            self.iface.mapCanvas().refresh()

    # ============ Add Node: เพิ่ม node ให้แปลง + เพิ่มหมุด (ระวางจากแปลง, ชื่อจากหมุดเดิม) ============
    def start_add_node(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not poly_lyr or poly_lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
            QtWidgets.QMessageBox.warning(self.dlg, "Add Node", "กรุณาเลือกเลเยอร์แปลง (Polygon) ก่อน")
            return
        if not point_lyr or point_lyr.geometryType() != QgsWkbTypes.PointGeometry:
            QtWidgets.QMessageBox.warning(self.dlg, "Add Node", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        self.cancel_transform()
        self.temp_tool = AddNodeTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Add Node", f"คลิกเลือกแปลงใน '{poly_lyr.name()}' (เลือก 1 แปลง • คลิกแปลงอื่น = เปลี่ยน) "
                        "แล้วคลิกที่หมุด (snap ให้อัตโนมัติ) เพื่อเพิ่ม node • คลิกขวา/Esc = ยกเลิก")

    def _addnode_name_field(self, point_lyr):
        """หา field ชื่อหมุด: ใช้ BND_NAME ก่อน ถ้าไม่มีหาฟิลด์ที่มีคำว่า NAME"""
        flds = point_lyr.fields()
        if flds.indexOf("BND_NAME") >= 0:
            return "BND_NAME"
        for f in flds:
            if "NAME" in f.name().upper():
                return f.name()
        return None

    def _poly_type_str(self, poly_lyr, feat):
        """คืนค่าฟิลด์ type (ตัวพิมพ์ใหญ่) ของแปลง หรือ '' ถ้าไม่มี — ใช้เช็ค L1-RTK/L1-TS
        เรียกทุก mouse-move ตอน hover (Add Node/Move Node) -> หา field ผ่าน cache"""
        name = self._resolve_field(poly_lyr, {'type'})
        if not name:
            return ""
        v = feat[name]
        return "" if v is None else str(v).strip().upper()

    def start_sync_vertex_tool(self):
        """เริ่มการทำงานของ SyncVertexTool (ย้ายหมุดทีละหลายอัน)"""
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        
        if not poly_lyr and not point_lyr:
            self.iface.messageBar().pushMessage("Warning", "กรุณาเลือกเลเยอร์แปลงหรือหมุดก่อน", level=2, duration=5)
            return
            
        if self.temp_tool:
            try:
                self.temp_tool.deactivate()
            except Exception:
                pass
                
        # ถ้ามีแปลงถูก Select อยู่ ให้เรียกใช้ Select by UTM อัตโนมัติ เพื่อให้หมุดติด Select สีเหลืองไปด้วย
        if poly_lyr and poly_lyr.selectedFeatureCount() > 0:
            self.process_selection('utm')

        self.mode = 'modify_node'
        self.temp_tool = SyncVertexTool(self.iface.mapCanvas(), self, poly_lyr, point_lyr)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Move Node",
            "คลิกหมุด → คลิกตำแหน่งใหม่เพื่อย้าย • หลายหมุด: ลากกล่องเลือกแล้วลากย้าย (Shift+ลาก = เลือกเพิ่ม) • คลิกขวา = เสร็จ")

    def _movenodes_execute(self, selected_vertices, dx, dy):
        """ประมวลผลการย้ายพิกัดหมุดหลายเลเยอร์พร้อมกัน"""
        if not selected_vertices:
            return False
            
        layers = set()
        for v in selected_vertices:
            layers.add(v['layer'])

        self._op_begin(layers)   # เริ่มนับ undo-step ต่อเลเยอร์
        for lyr in layers:
            if not lyr.isEditable():
                lyr.startEditing()
            lyr.beginEditCommand("Move Nodes (Sync)")
            
        try:
            proj = QgsProject.instance()
            # สร้าง transform ครั้งเดียวต่อเลเยอร์ (เดิมสร้างใหม่ทุก vertex ในลูป)
            xform_cache = {}
            for _lyr in layers:
                xform_cache[_lyr.id()] = (QgsCoordinateTransform(proj.crs(), _lyr.crs(), proj)
                                          if _lyr.crs() != proj.crs() else None)
            geom_updates = {}
            for v in selected_vertices:
                lyr = v['layer']
                fid = v['fid']
                vidx = v['vidx']
                pt = v['pt']

                # แปลงพิกัดใหม่กลับไปเป็น CRS ของเลเยอร์เป้าหมาย (ใช้ transform ที่ cache ไว้)
                to_lyr = xform_cache.get(lyr.id())
                new_map_pt = QgsPointXY(pt.x() + dx, pt.y() + dy)
                new_lyr_pt = to_lyr.transform(new_map_pt) if to_lyr else new_map_pt
                
                key = (lyr.id(), fid)
                
                if vidx >= 0:
                    # Polygon หรือ Line (ย้ายเฉพาะ vertex นั้นๆ)
                    if key not in geom_updates:
                        req = QgsFeatureRequest().setFilterFid(fid).setNoAttributes()
                        geom_updates[key] = next(lyr.getFeatures(req)).geometry()
                    geom = geom_updates[key]
                    geom.moveVertex(new_lyr_pt.x(), new_lyr_pt.y(), vidx)
                else:
                    # Point (ย้ายทั้ง geometry)
                    geom_updates[key] = QgsGeometry.fromPointXY(new_lyr_pt)

            # นำ geometry ที่แก้ไขแล้วไปอัปเดต โดยใช้ changeGeometry เพื่อข้ามระบบ Topological Editing ของ QGIS
            # (ป้องกันไม่ให้หมุดแปลงข้างเคียงขยับตาม หากไม่ได้ถูกเลือกไว้)
            for v in selected_vertices:
                lyr = v['layer']
                fid = v['fid']
                key = (lyr.id(), fid)
                if key in geom_updates:
                    lyr.changeGeometry(fid, geom_updates[key])
                    del geom_updates[key]  # ป้องกันการรันซ้ำ
                    
            for lyr in layers:
                lyr.endEditCommand()

            self._op_commit()   # ปิด operation -> เก็บประวัติ undo
            self.iface.mapCanvas().refresh()
            return True
        except Exception as e:
            for lyr in layers:
                lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline (delta=0 -> ไม่บันทึก)
            self.iface.messageBar().pushMessage("Error", f"Move Nodes Error: {e}", level=2, duration=0)
            return False

    def _addnode_execute(self, poly_lyr, fids, ins_xy):
        """เพิ่ม node ให้ทุกแปลงที่เลือก + สร้างหมุดใหม่ (ระวางจากแปลง, ชื่อจากหมุดเดิม ณ จุด snap)
        ins_xy = พิกัดหมุดที่ snap ติด (CRS เลเยอร์หมุด). คืน True ถ้าสำเร็จ"""
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            QtWidgets.QMessageBox.warning(self.dlg, "Add Node", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return False
        proj = QgsProject.instance()
        name_field = self._addnode_name_field(point_lyr)

        # รวมชื่อจากหมุดที่ตำแหน่งเดียวกัน (coincident กับจุด snap ≤5ซม.) -> หลายชื่อให้ popup เลือก
        COINC = 0.05
        rect = QgsRectangle(ins_xy.x() - COINC, ins_xy.y() - COINC,
                            ins_xy.x() + COINC, ins_xy.y() + COINC)
        names = []
        for f in point_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            nm = "" if name_field is None else str(f[name_field] or "").strip()
            if nm and nm not in names:
                names.append(nm)
        if len(names) <= 1:
            chosen = names[0] if names else ""
        else:
            chosen, ok = QtWidgets.QInputDialog.getItem(
                self.dlg, "เลือกชื่อหมุด",
                "ตำแหน่งนี้มีหลายหมุดหลายชื่อ — เลือกชื่อที่ต้องการ:", names, 0, False)
            if not ok:
                return False

        # พิกัดสำหรับแทรก node เข้า polygon (CRS เลเยอร์แปลง)
        to_poly = (QgsCoordinateTransform(point_lyr.crs(), poly_lyr.crs(), proj)
                   if poly_lyr.crs() != point_lyr.crs() else None)
        ins_poly = to_poly.transform(ins_xy) if to_poly else QgsPointXY(ins_xy)

        utm_fields = ["UTMMAP1", "UTMMAP2", "UTMMAP3", "UTMMAP4", "UTMSCALE", "LANDNO", "UTM"]
        if not poly_lyr.isEditable():
            poly_lyr.startEditing()
        if not point_lyr.isEditable():
            point_lyr.startEditing()
        self._op_begin([poly_lyr, point_lyr])   # เริ่มนับ undo-step ต่อเลเยอร์
        poly_lyr.beginEditCommand("Add Node")
        point_lyr.beginEditCommand("Add Marker")
        n_node = n_pt = 0
        try:
            for fid in fids:
                pf = poly_lyr.getFeature(fid)
                if not pf.isValid():
                    continue
                # กันชน: ห้ามเพิ่ม node ให้แปลงอ้างอิง L1-RTK / L1-TS (ห้ามแก้ geometry)
                tp = self._poly_type_str(poly_lyr, pf)
                if tp in ("L1-RTK", "L1-TS"):
                    self.iface.messageBar().pushMessage(
                        "Add Node", f"ข้ามแปลง {fid}: เป็น {tp} (พิกัดอ้างอิง ห้ามเพิ่ม node)",
                        level=2, duration=6)
                    continue
                geom = pf.geometry()
                # ถ้าแปลงมี vertex ตรงนั้นแล้ว ไม่ต้องแทรกซ้ำ (แต่ยังเพิ่มหมุด)
                cv = geom.closestVertex(ins_poly)
                has_vertex = cv[4] is not None and cv[4] < 0.0001   # < 1 ซม.
                if not has_vertex:
                    seg = geom.closestSegmentWithContext(ins_poly)
                    if poly_lyr.insertVertex(ins_poly.x(), ins_poly.y(), fid, seg[2]):
                        n_node += 1
                # เพิ่มหมุดใหม่: ระวางจากแปลง + ชื่อที่เลือก
                nf = QgsFeature(point_lyr.fields())
                nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(ins_xy)))
                for fld in utm_fields:
                    pi = point_lyr.fields().indexOf(fld)
                    qi = poly_lyr.fields().indexOf(fld)
                    if pi >= 0 and qi >= 0:
                        nf.setAttribute(pi, pf.attribute(qi))
                if name_field is not None and chosen:
                    nf.setAttribute(point_lyr.fields().indexOf(name_field), chosen)
                if point_lyr.addFeature(nf):
                    n_pt += 1
            poly_lyr.endEditCommand()
            point_lyr.endEditCommand()
            self._op_commit()   # ปิด operation -> เก็บประวัติ undo (แปลงที่ vertex มีอยู่แล้ว delta=0 ข้ามเอง)
        except Exception as e:
            poly_lyr.destroyEditCommand()
            point_lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline
            self.iface.messageBar().pushMessage("Add Node Error", f"{e}", level=2, duration=0)
            return False

        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushMessage(
            "Add Node", f"เพิ่ม node {n_node} แปลง + หมุด {n_pt} จุด (ชื่อ '{chosen or '-'}')",
            level=3, duration=8)
        return True

    def start_align_tool(self):
        self.cancel_transform()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            QtWidgets.QMessageBox.warning(self.dlg, "Align", "กรุณาเลือกเลเยอร์หมุด (Point) ก่อน")
            return
        self.mode = 'align_box'
        self.canvas = self.iface.mapCanvas()
        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.temp_tool = BoxSelectTool(self.iface.mapCanvas(), self._align_add_box,
                                       self.finish_align_selection, self._align_cancel)
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", "ลากกล่องครอบหมุด (ครอบหลายรอบได้ • Ctrl+ลาก = เอาออก) แล้วคลิกขวาเพื่อเลือกเสร็จ")

    def _align_add_box(self, rect_map, remove):
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            return
        proj = QgsProject.instance()
        rect_lyr = rect_map
        if point_lyr.crs() != proj.crs():
            try:
                rect_lyr = QgsCoordinateTransform(proj.crs(), point_lyr.crs(), proj).transformBoundingBox(rect_map)
            except Exception:
                rect_lyr = rect_map
        ids = set(getattr(self, "_align_picked_ids", set()))
        req = QgsFeatureRequest().setFilterRect(rect_lyr).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            ids.discard(f.id()) if remove else ids.add(f.id())
        self._align_picked_ids = ids
        self._align_refresh_highlight()
        self.iface.messageBar().pushInfo("Align", f"เลือกหมุด {len(ids)} จุด (คลิกขวา = เสร็จ)")

    def _align_refresh_highlight(self):
        self._align_clear_highlight()
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        ids = getattr(self, "_align_picked_ids", None)
        if not point_lyr or not ids:
            return
        proj = QgsProject.instance()
        xform = None
        if point_lyr.crs() != proj.crs():
            try:
                xform = QgsCoordinateTransform(point_lyr.crs(), proj.crs(), proj)
            except Exception:
                xform = None
        self._align_markers = []
        req = QgsFeatureRequest().setFilterFids(list(ids)).setNoAttributes()
        for f in point_lyr.getFeatures(req):
            xy = f.geometry().asPoint()
            if xform is not None:
                try:
                    xy = xform.transform(xy)
                except Exception:
                    pass
            mk = QgsVertexMarker(self.iface.mapCanvas())
            mk.setCenter(QgsPointXY(xy))
            mk.setColor(QtGui.QColor(0, 120, 255))
            mk.setIconType(QgsVertexMarker.ICON_BOX)
            mk.setPenWidth(3)
            mk.setIconSize(10)
            self._align_markers.append(mk)

    def _align_clear_highlight(self):
        for mk in getattr(self, "_align_markers", []):
            try:
                self.iface.mapCanvas().scene().removeItem(mk)
            except Exception:
                pass
        self._align_markers = []

    def _align_cancel(self):
        """ยกเลิกโหมด Align (Esc): ล้างข้อความแนะนำที่ค้าง แล้วรีเซ็ต"""
        try:
            self.iface.messageBar().clearWidgets()
        except Exception:
            pass
        self.cancel_transform()

    def finish_align_selection(self):
        """คลิกขวา = จบการเลือกหมุด -> เข้าโหมดลากเส้น 2 จุด (หมุดที่เลือกจะวิ่งไปหาเส้นที่ลาก
        หมุด/มุมที่ไม่ได้เลือกอยู่กับที่ -> แปลงยังต่อกับของเดิม)"""
        if not getattr(self, "_align_picked_ids", None):
            self.iface.messageBar().pushMessage("Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน", level=1, duration=6)
            return
        self.mode = 'align_point_driven'
        self.src_pts = []
        self.setup_snapping()
        self.temp_tool = QgsMapToolEmitPoint(self.canvas)
        self.temp_tool.canvasClicked.connect(self.handle_align_click)
        self.temp_tool.canvasMoveEvent = self.handle_align_mouse_move
        self.iface.mapCanvas().setMapTool(self.temp_tool)
        self.iface.messageBar().pushInfo(
            "Align", f"เลือกหมุด {len(self._align_picked_ids)} จุด → คลิก 2 จุดสร้างเส้นแนว (Esc = ยกเลิก)")

    def handle_align_mouse_move(self, event):
        """โชว์สี่เหลี่ยม Snap สำหรับเครื่องมือ Align (แก้ไข Error)"""
        if not hasattr(self, 'snap_indicator') or self.snap_indicator is None:
            return
        # แก้จาก self.snapping_utils เป็น self.snap_utils
        if not hasattr(self, 'snap_utils'):
            return
            
        match = self.snap_utils.snapToMap(event.mapPoint())
        
        if match.isValid():
            self.snap_indicator.setMatch(match)
        else:
            self.snap_indicator.setMatch(QgsPointLocator.Match())

        # Logic สำหรับวาด Rubber Band เส้นยางยืด (ถ้ามี)
        if hasattr(self, 'rubber_band') and self.rubber_band and len(self.src_pts) == 1:
            curr_pt = match.point() if match.isValid() else event.mapPoint()
            self.rubber_band.removeLastPoint()
            self.rubber_band.addPoint(curr_pt)
            
    def handle_align_click(self, point, button):
        """จัดการการคลิกจุด P1 และ P2 สำหรับสร้างแนวเส้น (รองรับที่ว่าง)"""
        if button == QtCore.Qt.RightButton:
            self.cancel_transform()
            return

        # 1. พยายาม Snap
        match = self.snap_utils.snapToMap(point)
        # 2. ถ้า Snap ไม่ติด ให้ใช้พิกัดที่คลิกจริง (point)
        pt = match.point() if match.isValid() else point
        
        self.src_pts.append(QgsPointXY(pt.x(), pt.y()))
        
        # วาง Marker
        m = QgsVertexMarker(self.canvas)
        m.setCenter(pt)
        m.setColor(QtGui.QColor(255, 0, 0) if match.isValid() else QtGui.QColor(0, 0, 255))
        m.setPenWidth(5)
        self.markers.append(m)
        
        if len(self.src_pts) == 1:
            self.clear_rubber_band()
            self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
            self.rubber_band.setColor(QtGui.QColor(255, 0, 0))
            self.rubber_band.setWidth(2)
            self.rubber_band.addPoint(pt)
            self.rubber_band.addPoint(pt)

        if len(self.src_pts) == 2:
            self.execute_point_node_alignment()
            # ทำความสะอาดหน้าจอหลังเสร็จงาน
            self.clear_markers()
            self.clear_rubber_band()
            self.src_pts = []
            
    def clear_rubber_band(self):
        """ลบ Rubber Band ออกจากหน้าจอและหน่วยความจำอย่างเด็ดขาด"""
        if self.rubber_band:
            self.rubber_band.hide() # ซ่อนทันที
            self.iface.mapCanvas().scene().removeItem(self.rubber_band) # ลบออกจาก Scene
            self.rubber_band = None # คืนค่าว่าง
            
    def _side_edge_dir(self, old_xy, poly_lyr, line_dx, line_dy):
        """ทิศของขอบแปลงที่ vertex old_xy โดยเลือกขอบที่ไม่ขนานกับเส้นเป้าหมาย -> (ux,uy) หรือ None"""
        if not poly_lyr:
            return None
        lmag = math.hypot(line_dx, line_dy)
        if lmag == 0:
            return None
        lux, luy = line_dx / lmag, line_dy / lmag
        EPS = 0.05
        rect = QgsRectangle(old_xy.x() - 1.0, old_xy.y() - 1.0,
                            old_xy.x() + 1.0, old_xy.y() + 1.0)
        best = None  # (parallelness, ux, uy)
        for pf in poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(rect)):
            g = pf.geometry()
            try:
                if g.isMultipart():
                    rings = [poly[0] for poly in g.asMultiPolygon() if poly]
                else:
                    pg = g.asPolygon()
                    rings = [pg[0]] if pg else []
            except Exception:
                rings = []
            for ring in rings:
                if len(ring) > 1 and ring[0] == ring[-1]:
                    ring = ring[:-1]
                n = len(ring)
                if n < 3:
                    continue
                vi = -1
                for idx, v in enumerate(ring):
                    if abs(v.x() - old_xy.x()) <= EPS and abs(v.y() - old_xy.y()) <= EPS:
                        vi = idx
                        break
                if vi < 0:
                    continue
                v = ring[vi]
                for nb in (ring[(vi - 1) % n], ring[(vi + 1) % n]):
                    ex, ey = nb.x() - v.x(), nb.y() - v.y()
                    emag = math.hypot(ex, ey)
                    if emag < 1e-9:
                        continue
                    ux, uy = ex / emag, ey / emag
                    par = abs(ux * lux + uy * luy)   # 1 = ขนานกับเส้นเป้าหมาย
                    if best is None or par < best[0]:
                        best = (par, ux, uy)
        return (best[1], best[2]) if best else None

    def _align_new_point(self, old_xy, poly_lyr, p1, dx, dy, projfn):
        """ย้ายมุมไป 'ตามแนวขอบข้าง' (ขอบที่ต่อไปหมุดที่ไม่ได้เลือก) จนชนเส้นแนว -> ขอบนั้นคงมุมเดิม
        จะตามขอบ "เฉพาะตอนขอบตั้งฉากกับเส้นแนวพอควร" เท่านั้น (par ต่ำ) — ไม่งั้นตามขอบที่เอียงตื้น
        หมุดจะ 'ไถลออกข้าง' ไกล -> ใช้ฉายตั้งฉากแทน (ปลอดภัย ขยับน้อยสุด)"""
        perp = projfn(old_xy.x(), old_xy.y())
        lmag = math.hypot(dx, dy)
        if poly_lyr is None or lmag == 0:
            return perp
        sd = self._side_edge_dir(old_xy, poly_lyr, dx, dy)   # ทิศขอบที่ตั้งฉากกับเส้นแนวที่สุด
        if sd is None:
            return perp
        ux, uy = sd
        lux, luy = dx / lmag, dy / lmag
        par = abs(ux * lux + uy * luy)   # 1 = ขนานเส้นแนว, 0 = ตั้งฉาก
        # ตามขอบเฉพาะขอบที่ตั้งฉากกับเส้นแนว >~60° (par<0.5) -> ไถลข้างไม่เกิน ~0.58 เท่าระยะตั้งฉาก
        max_par = QtCore.QSettings().value("MultiLayerEditPro/Align/EdgeFollowMaxPar", 0.5, float)
        if par >= max_par:
            return perp
        den = dx * uy - dy * ux
        if abs(den) < 1e-9:
            return perp
        s = ((old_xy.x() - p1.x()) * uy - (old_xy.y() - p1.y()) * ux) / den
        return QgsPointXY(p1.x() + s * dx, p1.y() + s * dy)

    def execute_point_node_alignment(self):
        poly_lyr = QgsProject.instance().mapLayer(self.poly_cb.currentData())
        point_lyr = QgsProject.instance().mapLayer(self.point_cb.currentData())
        if not point_lyr:
            return

        p1, p2 = self.src_pts[0], self.src_pts[1]
        dx = p2.x() - p1.x()
        dy = p2.y() - p1.y()
        mag_sq = dx**2 + dy**2
        if mag_sq == 0:
            return

        def get_projected_pt(old_x, old_y):
            u = ((old_x - p1.x()) * dx + (old_y - p1.y()) * dy) / mag_sq
            return QgsPointXY(p1.x() + u * dx, p1.y() + u * dy)

        # ===== หมุดที่จะ align = หมุดที่เลือกด้วยกล่อง (box-select) =====
        picked = getattr(self, "_align_picked_ids", None)
        if picked:
            target_points = list(point_lyr.getFeatures(
                QgsFeatureRequest().setFilterFids(list(picked))))
        else:
            target_points = list(point_lyr.selectedFeatures())   # fallback: หมุดที่ select ไว้

        if not target_points:
            self.iface.messageBar().pushMessage(
                "Align", "ยังไม่ได้เลือกหมุด — ลากกล่องครอบหมุดก่อน",
                level=1, duration=6)
            return

        self.stored_selection = {lyr.id(): lyr.selectedFeatureIds() for lyr in (point_lyr, poly_lyr) if lyr}

        self._op_begin([point_lyr, poly_lyr])   # เริ่มนับ undo-step ต่อเลเยอร์
        if not point_lyr.isEditable(): point_lyr.startEditing()
        point_lyr.beginEditCommand("Align Points to Line")
        if poly_lyr:
            if not poly_lyr.isEditable(): poly_lyr.startEditing()
            poly_lyr.beginEditCommand("Align Nodes to Line")

        # weld node แปลงแบบ junction-aware (วัดระยะจาก "หมุดที่เลือก" -> node แปลง)
        #   ≤ AUTO_TOL      : ร่วมมุมแน่ -> รวมเข้าหมุดอัตโนมัติ (junction หลายแปลงรวมเป็นจุดเดียว)
        #   AUTO_TOL-ASK_TOL: น่าจะร่วมมุมแต่ไม่ snap -> เก็บไว้ถาม (popup ครั้งเดียว)
        #   > ASK_TOL       : คนละมุม/แปลงไม่เกี่ยว -> ไม่แตะ
        # (ค่า default จากการวัด data จริง: 74% ของมุมร่วม snap ≤2มม. • ปรับเป็น setting ได้ภายหลัง)
        s = QtCore.QSettings()
        AUTO_TOL = s.value("MultiLayerEditPro/Align/AutoMergeTol", 0.03, float)
        ASK_TOL = s.value("MultiLayerEditPro/Align/AskTol", 0.30, float)
        try:
            # ===== PASS 1: คำนวณตำแหน่งใหม่ของทุกหมุดจาก geometry "เดิม" (ก่อนแก้ไขใดๆ) =====
            moves = []   # [(pt_id, old_xy, new_pt)]
            calc_cache = {}  # Cache เพื่อให้หมุดที่ซ้อนกัน (ห่างไม่เกินมิลลิเมตร) ได้ค่า new_pt เดียวกัน
            lock_cache = {}  # memoize ผลล็อกตามค่า UTM (ลด query ชั้นแปลงเมื่อหมุดเยอะ)
            for pt_f in target_points:
                old_xy = pt_f.geometry().asPoint()
                # ข้ามถ้าหมุดเชื่อมโยงกับแปลงที่ล็อก
                if poly_lyr:
                    is_locked, type_str = self._is_point_feature_locked(poly_lyr, pt_f, lock_cache)
                    if is_locked:
                        self.iface.messageBar().pushMessage(
                            "Align Warning",
                            f"ข้ามการย้ายจุดหมุด {pt_f.id()} เนื่องจากเชื่อมโยงกับแปลงประเภท {type_str} (ถูกล็อก)",
                            level=2, duration=5)
                        continue
                
                key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
                if key in calc_cache:
                    new_pt = calc_cache[key]
                else:
                    # ย้ายตามแนวขอบข้าง (คงมุมขอบที่ต่อหมุดที่ไม่ได้เลือก) -> ถ้าทำไม่ได้ฉายตั้งฉาก
                    new_pt = self._align_new_point(old_xy, poly_lyr, p1, dx, dy, get_projected_pt)
                    calc_cache[key] = new_pt
                    
                moves.append((pt_f.id(), old_xy, new_pt))

            # ===== PASS 2: ขยับหมุดทั้งหมด =====
            for pt_id, old_xy, new_pt in moves:
                point_lyr.changeGeometry(pt_id, QgsGeometry.fromPointXY(new_pt))

            # ===== PASS 3: weld node ของ polygon (junction-aware) =====
            if poly_lyr:
                poly_type_idx = self._field_index(poly_lyr.fields(), 'type')

                def _poly_locked(pf):
                    if poly_type_idx == -1:
                        return False
                    v = pf.attribute(poly_type_idx)
                    return v is not None and str(v).strip().upper() in ("L1-RTK", "L1-TS")

                # รวบรวมผู้สมัคร: node แปลง -> (จุดปลายทาง, ระยะถึงหมุดที่ใกล้สุด)
                cand = {}      # (poly_id, vidx) -> (new_pt, dist)
                seen = set()
                for pt_id, old_xy, new_pt in moves:
                    key = (round(old_xy.x(), 3), round(old_xy.y(), 3))
                    if key in seen:
                        continue
                    seen.add(key)
                    search_rect = QgsRectangle(old_xy.x() - ASK_TOL, old_xy.y() - ASK_TOL,
                                               old_xy.x() + ASK_TOL, old_xy.y() + ASK_TOL)
                    for poly_f in list(poly_lyr.getFeatures(QgsFeatureRequest().setFilterRect(search_rect))):
                        if _poly_locked(poly_f):          # ข้ามแปลงอ้างอิงที่ล็อก (เงียบ)
                            continue
                        geom = poly_f.geometry()
                        if geom is None or geom.isNull():
                            continue
                        _cp, vidx, _pi, _ni, sqr = geom.closestVertex(old_xy)
                        if vidx < 0 or sqr is None:
                            continue
                        d = math.sqrt(sqr)
                        if d > ASK_TOL:
                            continue
                        vk = (poly_f.id(), vidx)
                        if vk not in cand or d < cand[vk][1]:   # เก็บหมุดที่ใกล้ node นี้สุด
                            cand[vk] = (new_pt, d)

                auto = [(pid, vi, npt) for (pid, vi), (npt, d) in cand.items() if d <= AUTO_TOL]
                ask = [(pid, vi, npt, d) for (pid, vi), (npt, d) in cand.items() if AUTO_TOL < d <= ASK_TOL]

                # 3a: รวมอัตโนมัติ (≤ AUTO_TOL) — junction หลายแปลงไปจุดเดียว ปิด gap
                for pid, vi, npt in auto:
                    poly_lyr.moveVertex(npt.x(), npt.y(), pid, vi)

                # 3b: มุมที่ใกล้แต่ไม่ snap -> popup ถามครั้งเดียว ว่าจะรวมให้ไหม
                if ask:
                    ds = [d for *_, d in ask]
                    msg = (f"พบ {len(ask)} มุมแปลงที่อยู่ใกล้หมุดแต่ไม่ snap "
                           f"(เหลื่อม {min(ds)*100:.1f}–{max(ds)*100:.1f} ซม.)\n\n"
                           "ต้องการ 'รวม' มุมเหล่านี้เข้ากับหมุดด้วยไหม?\n"
                           "• Yes = รวมให้ (ปิด gap ที่มุมร่วม)\n"
                           "• No = ปล่อยไว้ (ขยับเฉพาะมุมที่ snap สนิท)")
                    ans = QtWidgets.QMessageBox.question(
                        self.dlg, "พบมุมแปลงไม่ snap", msg,
                        QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
                        QtWidgets.QMessageBox.No)
                    if ans == QtWidgets.QMessageBox.Yes:
                        for pid, vi, npt, _d in ask:
                            poly_lyr.moveVertex(npt.x(), npt.y(), pid, vi)

            # ปิด Command ทั้งสองเลเยอร์
            point_lyr.endEditCommand()
            if poly_lyr:
                poly_lyr.endEditCommand()
            self._op_commit()   # ปิด operation -> เก็บประวัติ undo

        except Exception as e:
            point_lyr.destroyEditCommand()
            if poly_lyr: poly_lyr.destroyEditCommand()
            self._op_commit()   # เคลียร์ baseline
            self.iface.messageBar().pushMessage("Align Error", f"เกิดข้อผิดพลาด: {e}", level=2, duration=0)
            print(f"Align Error: {e}")

        self._align_picked_ids = set()
        self._align_clear_highlight()
        self.canvas.refresh()
        self.iface.actionSelect().trigger()
        QtCore.QTimer.singleShot(100, self.restore_selection)


# ============================================================
#  DOL iLands — เครื่องมือคลิกเลือกแปลง + worker เรียก API
# ============================================================
from .map_tools import BoxSelectTool, PolygonPickTool, AddNodeTool, SyncVertexTool

class ParcelLookupWorker(QtCore.QThread):
    """ระวาง(attribute) -> PARCEL_SEQ ผ่าน ArcGIS + UDM (public, ไม่ต้อง login)"""
    done = QtCore.pyqtSignal(object)   # dict หรือ None
    fail = QtCore.pyqtSignal(str)

    def __init__(self, attrs, zone=47):
        super().__init__()
        self.attrs = attrs
        self.zone = zone

    def run(self):
        from . import dol_api
        try:
            a = self.attrs
            res = dol_api.lookup_parcel_by_rawang(
                a["m1"], a["m2"], a["m3"], a["m4"], a["scale"], a["landno"],
                zone=self.zone, near_xy=a.get("near_xy"))
            self.done.emit(res)
        except Exception as e:
            self.fail.emit(f"ค้นหาไม่สำเร็จ: {e}")
